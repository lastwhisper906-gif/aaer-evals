# GNRC 8-K — 0001437749-23-029637 filed 2023-11-01

## item codes, every 8-K on or before 2023-11-07

- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2023-11-07

- none on or before 2023-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-23-029637:8k_2_02:1]
EX-99.1
2
ex_588393.htm
EXHIBIT 99.1

[0001437749-23-029637:8k_2_02:2]
ex_588393.htm

[0001437749-23-029637:8k_2_02:3]
Exhibit 99.1

[0001437749-23-029637:8k_2_02:4]
Generac Reports Third Quarter 2023 Results

[0001437749-23-029637:8k_2_02:5]
Return to margin expansion and strong free cash flow generation; maintaining overall net sales and adjusted EBITDA outlook for full-year 2023

[0001437749-23-029637:8k_2_02:6]
WAUKESHA, WISCONSIN (November 1, 2023) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2023 and provided an update on its outlook for the full year 2023.

[0001437749-23-029637:8k_2_02:7]
Third Quarter 2023 Highlights

[0001437749-23-029637:8k_2_02:8]
|  | ● | Net sales decreased 2% to $1.07 billion during the third quarter of 2023 as compared to $1.09 billion in the prior-year third quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, decreased approximately 4%. |

[0001437749-23-029637:8k_2_02:9]
|  | - | Residential product sales declined 15% to $565 million as compared to $664 million last year. |

[0001437749-23-029637:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 24% to $385 million as compared to $311 million in the prior year. |

[0001437749-23-029637:8k_2_02:11]
|  | ● | Net income attributable to the Company during the third quarter was $60 million, or $0.97 per share, as compared to $58 million, or $0.83 per share, for the same period of 2022. |

[0001437749-23-029637:8k_2_02:12]
|  | ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $102 million, or $1.64 per share, as compared to $112 million, or $1.75 per share, in the third quarter of 2022. |

[0001437749-23-029637:8k_2_02:13]
|  | ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $189 million, or 17.6% of net sales, as compared to $184 million, or 16.9% of net sales, in the prior year. |

[0001437749-23-029637:8k_2_02:14]
|  | ● | Cash flow from operations was $140 million during the third quarter, as compared to $(56) million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $117 million as compared to $(73) million in the third quarter of 2022. |

[0001437749-23-029637:8k_2_02:15]
|  | ● | During the third quarter of 2023, the company repurchased 875,580 shares of its common stock for $100 million under its current share repurchase program. There is approximately $178 million remaining under the current repurchase program as of September 30, 2023. |

[0001437749-23-029637:8k_2_02:16]
“Our results in the third quarter reflect improving operating performance and validate the longer-term focus on our Powering A Smarter World strategic plan,” said Aaron Jagdfeld, President and Chief Executive Office. “We experienced a strong sequential increase in shipments of home standby generators during the quarter as higher activations are driving field inventories towards more sustainable levels. In addition, in home consultations for these products also remained strong during the quarter as category awareness continues to increase on the back of well-publicized grid stability concerns. Additionally, C&I product sales continued to experience significant growth over the prior year that once again exceeded our expectations. We also saw margins expand year-over-year and generated substantial free cash flow during the quarter, both of which are expected to continue into the fourth quarter.”

[0001437749-23-029637:8k_2_02:17]
Additional Third Quarter 2023 Consolidated Highlights

[0001437749-23-029637:8k_2_02:18]
Gross profit margin was 35.1% as compared to 33.2% in the prior-year third quarter. The increase in gross margin was primarily driven by lower raw material and logistics costs and production efficiencies. These margin benefits were partially offset by the impact of unfavorable sales mix.

[0001437749-23-029637:8k_2_02:19]
Operating expenses decreased by $2.6 million, or 0.9%, as compared to the third quarter of 2022. Excluding certain items for legal, regulatory, and clean energy product charges in the current and prior year, as disclosed in the accompanying reconciliation schedules, operating expenses increased by $30.6 million, or 14.0%, from the prior year primarily driven by increased employee and marketing costs in the current year and a favorable contingent consideration adjustment in the prior year.

[0001437749-23-029637:8k_2_02:20]
Provision for income taxes for the current year quarter was $19.4 million, or an effective tax rate of 24.3%, as compared to $11.6 million, or a 16.1% effective tax rate, for the prior year. The increase in the effective tax rate was primarily due to the prior year quarter including certain favorable discrete tax items and a larger benefit from equity compensation as compared to the current year quarter.

[0001437749-23-029637:8k_2_02:21]
Cash flow from operations was $140.1 million during the third quarter, as compared to $(56.0) million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $117.4 million as compared to $(73.5) million in the third quarter of 2022. The increase in free cash flow was primarily due to a significant use of cash for working capital in the prior year that did not repeat in the current year quarter, partially offset by higher interest payments and capital expenditures.

[0001437749-23-029637:8k_2_02:22]
Business Segment Results

[0001437749-23-029637:8k_2_02:23]
Domestic Segment

[0001437749-23-029637:8k_2_02:24]
Domestic segment total sales (including inter-segment sales) decreased 6% to $894.0 million as compared to $946.6 million in the prior year quarter, with minimal favorable impact from acquisitions. The decline was driven by lower residential product sales primarily due to lower home standby and portable generator shipments as compared to the prior year. This was partially offset by growth in C&I product sales, highlighted by strong shipments to industrial distributors and direct customers for “beyond standby” applications.

[0001437749-23-029637:8k_2_02:25]
Adjusted EBITDA for the segment was $160.3 million, or 17.9% of domestic segment total sales, as compared to $159.8 million in the prior year, or 16.9% of total sales. This margin improvement was primarily driven by favorable price and cost benefits, partially offset by unfavorable sales mix and higher employee and marketing expenses.

[0001437749-23-029637:8k_2_02:26]
International Segment

[0001437749-23-029637:8k_2_02:27]
International segment total sales (including inter-segment sales) increased 14% to $207.6 million as compared to $182.5 million in the prior year quarter, with acquisitions and foreign currency providing an approximate 11% favorable impact to revenue growth for the quarter. The 3% core total sales growth for the segment was driven by varying levels of C&I product growth in most regions, partially offset by weaker portable generator sales in Europe.

[0001437749-23-029637:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $28.3 million, or 13.6% of international segment total sales, as compared to $24.0 million, or 13.2% of total sales, in the prior year. This modest margin improvement was primarily driven by favorable price, cost and mix benefits.

[0001437749-23-029637:8k_2_02:29]
2023 Outlook Update

[0001437749-23-029637:8k_2_02:30]
The Company is maintaining its overall full-year 2023 net sales guidance for a decline of approximately -10 to -12% as compared to the prior year, which includes approximately 2% of net favorable impact from acquisitions and foreign currency.

[0001437749-23-029637:8k_2_02:31]
Additionally, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 5.0 to 6.0% for the full-year 2023 compared to the prior guidance range of 6.0 to 7.0%. The corresponding adjusted EBITDA margin is still expected to be approximately 15.5% to 16.5%, in line with the previous guidance.

[0001437749-23-029637:8k_2_02:32]
Operating and free cash flow generation are expected to return to strong levels for the full year, with conversion of adjusted net income to free cash flow expected to be well over 100%.

[0001437749-23-029637:8k_2_02:33]
Conference Call and Webcast

[0001437749-23-029637:8k_2_02:34]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, November 1, 2023 to discuss third quarter 2023 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIa6e8539444e2408eb5d52b8ff3526ea5. Individuals who wish to listen via telephone will be given dial-in information.

[0001437749-23-029637:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-23-029637:8k_2_02:36]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-23-029637:8k_2_02:37]
About Generac

[0001437749-23-029637:8k_2_02:38]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- & battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The Company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-23-029637:8k_2_02:39]
Forward-looking Information

[0001437749-23-029637:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-23-029637:8k_2_02:41]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-23-029637:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-23-029637:8k_2_02:43]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-23-029637:8k_2_02:44]
|  | ● | availability of both labor and key components from our manufacturing operations and global supply chain, including single-sourced components and contract manufacturers, needed in producing our products; |

[0001437749-23-029637:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-23-029637:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-23-029637:8k_2_02:47]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-23-029637:8k_2_02:48]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-23-029637:8k_2_02:49]
|  | ● | our dependence on our distribution network; |

[0001437749-23-029637:8k_2_02:50]
|  | ● | our ability to remain competitive by investing in, developing or adapting to changing technologies and manufacturing techniques, as well as protecting our intellectual property rights; |

[0001437749-23-029637:8k_2_02:51]
|  | ● | loss of our key management and employees; |

[0001437749-23-029637:8k_2_02:52]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-23-029637:8k_2_02:53]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-23-029637:8k_2_02:54]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |

[0001437749-23-029637:8k_2_02:55]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations; and |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-029637:8k_2_02:56]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2022 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-23-029637:8k_2_02:57]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-23-029637:8k_2_02:58]
Non-GAAP Financial Metrics

[0001437749-23-029637:8k_2_02:59]
Core Sales

[0001437749-23-029637:8k_2_02:60]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-23-029637:8k_2_02:61]
Adjusted EBITDA

[0001437749-23-029637:8k_2_02:62]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-029637:8k_2_02:63]
Adjusted Net Income

[0001437749-23-029637:8k_2_02:64]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-23-029637:8k_2_02:65]
Free Cash Flow

[0001437749-23-029637:8k_2_02:66]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-23-029637:8k_2_02:67]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-23-029637:8k_2_02:68]
SOURCE: Generac Holdings Inc.

[0001437749-23-029637:8k_2_02:69]
CONTACT:

[0001437749-23-029637:8k_2_02:70]
Michael W. Harris

[0001437749-23-029637:8k_2_02:71]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-23-029637:8k_2_02:72]
(262) 506-6064

[0001437749-23-029637:8k_2_02:73]
InvestorRelations@generac.com

[0001437749-23-029637:8k_2_02:74]
5

[0001437749-23-029637:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-029637:8k_2_02:76]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net sales |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |
| Costs of goods sold |  |  | 694,880 |  |  |  | 727,154 |  |  |  | 1,982,290 |  |  |  | 2,336,668 |  |
| Gross profit |  |  | 375,787 |  |  |  | 361,104 |  |  |  | 976,707 |  |  |  | 1,178,837 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 117,929 |  |  |  | 170,381 |  |  |  | 334,360 |  |  |  | 388,690 |  |
| Research and development |  |  | 43,312 |  |  |  | 39,985 |  |  |  | 129,074 |  |  |  | 121,328 |  |
| General and administrative |  |  | 83,052 |  |  |  | 37,464 |  |  |  | 199,108 |  |  |  | 132,036 |  |
| Amortization of intangibles |  |  | 26,718 |  |  |  | 25,751 |  |  |  | 78,934 |  |  |  | 77,681 |  |
| Total operating expenses |  |  | 271,011 |  |  |  | 273,581 |  |  |  | 741,476 |  |  |  | 719,735 |  |
| Income from operations |  |  | 104,776 |  |  |  | 87,523 |  |  |  | 235,231 |  |  |  | 459,102 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (24,707 | ) |  |  | (15,514 | ) |  |  | (72,862 | ) |  |  | (35,303 | ) |
| Investment income |  |  | 1,160 |  |  |  | 451 |  |  |  | 2,789 |  |  |  | 620 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (3,743 | ) |
| Other, net |  |  | (1,167 | ) |  |  | (420 | ) |  |  | (1,664 | ) |  |  | 331 |  |
| Total other expense, net |  |  | (24,714 | ) |  |  | (15,483 | ) |  |  | (71,737 | ) |  |  | (38,095 | ) |
| Income before provision for income taxes |  |  | 80,062 |  |  |  | 72,040 |  |  |  | 163,494 |  |  |  | 421,007 |  |
| Provision for income taxes |  |  | 19,428 |  |  |  | 11,594 |  |  |  | 43,184 |  |  |  | 86,028 |  |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 120,310 |  |  |  | 334,979 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | 2,305 |  |  |  | 6,492 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.98 |  |  | $ | 0.84 |  |  | $ | 1.74 |  |  | $ | 4.69 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,368,440 |  |  |  | 63,249,881 |  |  |  | 61,552,949 |  |  |  | 63,480,161 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.97 |  |  | $ | 0.83 |  |  | $ | 1.72 |  |  | $ | 4.61 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,091,163 |  |  |  | 64,267,638 |  |  |  | 62,362,743 |  |  |  | 64,630,346 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 37,041 |  |  | $ | 21,683 |  |  | $ | 141,463 |  |  | $ | 264,912 |  |

[0001437749-23-029637:8k_2_02:77]
6

[0001437749-23-029637:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-029637:8k_2_02:79]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 161,525 |  |  | $ | 132,723 |  |
| Accounts receivable, less allowance for credit losses of $29,580 and $27,664 at September 30, 2023 and December 31, 2022, respectively |  |  | 589,226 |  |  |  | 522,458 |  |
| Inventories |  |  | 1,311,129 |  |  |  | 1,405,384 |  |
| Prepaid expenses and other current assets |  |  | 105,169 |  |  |  | 121,783 |  |
| Total current assets |  |  | 2,167,049 |  |  |  | 2,182,348 |  |
| Property and equipment, net |  |  | 511,893 |  |  |  | 467,604 |  |
| Customer lists, net |  |  | 188,513 |  |  |  | 206,987 |  |
| Patents and technology, net |  |  | 426,552 |  |  |  | 454,757 |  |
| Other intangible assets, net |  |  | 30,317 |  |  |  | 41,719 |  |
| Tradenames, net |  |  | 219,012 |  |  |  | 227,251 |  |
| Goodwill |  |  | 1,417,564 |  |  |  | 1,400,880 |  |
| Deferred income taxes |  |  | 17,140 |  |  |  | 12,746 |  |
| Operating lease and other non-current assets |  |  | 188,301 |  |  |  | 175,170 |  |
| Total assets |  | $ | 5,166,341 |  |  | $ | 5,169,462 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 74,346 |  |  | $ | 48,990 |  |
| Accounts payable |  |  | 394,168 |  |  |  | 446,050 |  |
| Accrued wages and employee benefits |  |  | 56,454 |  |  |  | 45,741 |  |
| Accrued product warranty |  |  | 70,572 |  |  |  | 89,141 |  |
| Other accrued liabilities |  |  | 267,217 |  |  |  | 349,389 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 37,337 |  |  |  | 12,733 |  |
| Total current liabilities |  |  | 900,094 |  |  |  | 992,044 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,465,141 |  |  |  | 1,369,085 |  |
| Deferred income taxes |  |  | 113,390 |  |  |  | 125,691 |  |
| Deferred revenue |  |  | 160,264 |  |  |  | 143,726 |  |
| Operating lease and other long-term liabilities |  |  | 155,326 |  |  |  | 169,190 |  |
| Total liabilities |  |  | 2,794,215 |  |  |  | 2,799,736 |  |
| Redeemable noncontrolling interest |  |  | 5,639 |  |  |  | 110,471 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,108,913 and 72,701,257 shares issued at September 30, 2023 and December 31, 2022, respectively |  |  | 732 |  |  |  | 728 |  |
| Additional paid-in capital |  |  | 1,064,418 |  |  |  | 1,016,138 |  |
| Treasury stock, at cost, 11,739,423 and 11,284,350 shares at September 30, 2023 and December 31, 2022, respectively |  |  | (880,858 | ) |  |  | (808,491 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,423,346 |  |  |  | 2,316,224 |  |
| Accumulated other comprehensive loss |  |  | (41,614 | ) |  |  | (65,102 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,363,908 |  |  |  | 2,257,381 |  |
| Noncontrolling interests |  |  | 2,579 |  |  |  | 1,874 |  |
| Total stockholders’ equity |  |  | 2,366,487 |  |  |  | 2,259,255 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,166,341 |  |  | $ | 5,169,462 |  |

[0001437749-23-029637:8k_2_02:80]
7

[0001437749-23-029637:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-029637:8k_2_02:82]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 120,310 |  |  | $ | 334,979 |  |
| Adjustment to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 45,215 |  |  |  | 39,043 |  |
| Amortization of intangible assets |  |  | 78,934 |  |  |  | 77,681 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,902 |  |  |  | 2,261 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 3,743 |  |
| Deferred income taxes |  |  | (18,715 | ) |  |  | (83,272 | ) |
| Share-based compensation expense |  |  | 30,306 |  |  |  | 23,423 |  |
| Gain on disposal of assets |  |  | (538 | ) |  |  | (555 | ) |
| Other noncash charges |  |  | 380 |  |  |  | 7,037 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (68,975 | ) |  |  | (20,810 | ) |
| Inventories |  |  | 101,894 |  |  |  | (353,618 | ) |
| Other assets |  |  | 32,175 |  |  |  | (7,033 | ) |
| Accounts payable |  |  | (57,866 | ) |  |  | (136,289 | ) |
| Accrued wages and employee benefits |  |  | 10,244 |  |  |  | (17,418 | ) |
| Other accrued liabilities |  |  | (70,622 | ) |  |  | 105,544 |  |
| Excess tax benefits from equity awards |  |  | (920 | ) |  |  | (17,068 | ) |
| Net cash provided by (used in) operating activities |  |  | 204,724 |  |  |  | (42,352 | ) |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,933 |  |  |  | 2,049 |  |
| Proceeds from sale of investment |  |  | - |  |  |  | 1,308 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,533 |  |  |  | 2,745 |  |
| Contribution to equity method investment |  |  | (6,627 | ) |  |  | (14,930 | ) |
| Purchase of long-term investment |  |  | (2,592 | ) |  |  | - |  |
| Expenditures for property and equipment |  |  | (77,718 | ) |  |  | (64,833 | ) |
| Acquisition of business, net of cash acquired |  |  | (15,974 | ) |  |  | (11,421 | ) |
| Net cash used in investing activities |  |  | (98,445 | ) |  |  | (85,082 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 49,078 |  |  |  | 237,182 |  |
| Proceeds from long-term borrowings |  |  | 345,384 |  |  |  | 935,614 |  |
| Repayments of short-term borrowings |  |  | (25,910 | ) |  |  | (239,550 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (233,101 | ) |  |  | (540,481 | ) |
| Stock repurchases |  |  | (100,267 | ) |  |  | (123,900 | ) |
| Payment of contingent acquisition consideration |  |  | (4,979 | ) |  |  | (16,135 | ) |
| Payment of debt issuance costs |  |  | - |  |  |  | (10,330 | ) |
| Purchase of additional ownership interest |  |  | (104,844 | ) |  |  | (375 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | - |  |  |  | (309 | ) |
| Taxes paid related to equity awards |  |  | (10,068 | ) |  |  | (40,472 | ) |
| Proceeds from the exercise of stock options |  |  | 7,139 |  |  |  | 13,627 |  |
| Net cash (used in) provided by financing activities |  |  | (77,568 | ) |  |  | 214,871 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 91 |  |  |  | (4,865 | ) |
| Net increase in cash and cash equivalents |  |  | 28,802 |  |  |  | 82,572 |  |
| Cash and cash equivalents at beginning of period |  |  | 132,723 |  |  |  | 147,339 |  |
| Cash and cash equivalents at end of period |  | $ | 161,525 |  |  | $ | 229,911 |  |

[0001437749-23-029637:8k_2_02:83]
8

[0001437749-23-029637:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-029637:8k_2_02:85]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |  | Three Months Ended September 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 886,365 |  |  | $ | 7,640 |  |  | $ | 894,005 |  |  | $ | 931,132 |  |  | $ | 15,485 |  |  | $ | 946,617 |  |
| International |  |  | 184,302 |  |  |  | 23,293 |  |  |  | 207,595 |  |  |  | 157,126 |  |  |  | 25,416 |  |  |  | 182,542 |  |
| Intercompany elimination |  |  | - |  |  |  | (30,933 | ) |  |  | (30,933 | ) |  |  | - |  |  |  | (40,901 | ) |  |  | (40,901 | ) |
| Total net sales |  | $ | 1,070,667 |  |  | $ | - |  |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | - |  |  | $ | 1,088,258 |  |

[0001437749-23-029637:8k_2_02:86]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |  | Nine Months Ended September 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,395,292 |  |  | $ | 33,960 |  |  | $ | 2,429,252 |  |  | $ | 3,003,237 |  |  | $ | 44,742 |  |  | $ | 3,047,979 |  |
| International |  |  | 563,705 |  |  |  | 84,078 |  |  |  | 647,783 |  |  |  | 512,268 |  |  |  | 59,075 |  |  |  | 571,343 |  |
| Intercompany elimination |  |  | - |  |  |  | (118,038 | ) |  |  | (118,038 | ) |  |  | - |  |  |  | (103,817 | ) |  |  | (103,817 | ) |
| Total net sales |  | $ | 2,958,997 |  |  | $ | - |  |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |  | $ | - |  |  | $ | 3,515,505 |  |

[0001437749-23-029637:8k_2_02:87]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Residential products |  | $ | 565,087 |  |  | $ | 664,115 |  |  | $ | 1,482,538 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 384,533 |  |  |  | 311,186 |  |  |  | 1,131,876 |  |  |  | 899,263 |  |
| Other |  |  | 121,047 |  |  |  | 112,957 |  |  |  | 344,583 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |

[0001437749-23-029637:8k_2_02:88]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 160,270 |  |  | $ | 159,810 |  |  | $ | 331,134 |  |  | $ | 572,159 |  |
| International |  |  | 28,332 |  |  |  | 24,006 |  |  |  | 94,088 |  |  |  | 79,532 |  |
| Total adjusted EBITDA (1) |  | $ | 188,602 |  |  | $ | 183,816 |  |  | $ | 425,222 |  |  | $ | 651,691 |  |

[0001437749-23-029637:8k_2_02:89]
| (1) See reconciliation of Adjusted EBITDA to Net Income attributable to Generac Holdings Inc. on the following reconciliation schedule |

[0001437749-23-029637:8k_2_02:90]
9

[0001437749-23-029637:8k_2_02:91]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-029637:8k_2_02:92]
Net income to Adjusted EBITDA reconciliation

[0001437749-23-029637:8k_2_02:93]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | 2,305 |  |  |  | 6,492 |  |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 120,310 |  |  |  | 334,979 |  |
| Interest expense |  |  | 24,707 |  |  |  | 15,514 |  |  |  | 72,862 |  |  |  | 35,303 |  |
| Depreciation and amortization |  |  | 42,951 |  |  |  | 39,165 |  |  |  | 124,149 |  |  |  | 116,724 |  |
| Provision for income taxes |  |  | 19,428 |  |  |  | 11,594 |  |  |  | 43,184 |  |  |  | 86,028 |  |
| Non-cash write-down and other adjustments (1) |  |  | 2,055 |  |  |  | (6,840 | ) |  |  | (5,257 | ) |  |  | (10,025 | ) |
| Non-cash share-based compensation expense (2) |  |  | 9,927 |  |  |  | 6,861 |  |  |  | 30,306 |  |  |  | 23,423 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and credit facility fees (4) |  |  | 921 |  |  |  | 1,250 |  |  |  | 3,161 |  |  |  | 3,831 |  |
| Business optimization and other charges (5) |  |  | 5,291 |  |  |  | 622 |  |  |  | 8,151 |  |  |  | 3,371 |  |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  | 22,113 |  |  |  | 55,265 |  |  |  | 27,913 |  |  |  | 55,265 |  |
| Other |  |  | 575 |  |  |  | (61 | ) |  |  | 443 |  |  |  | (951 | ) |
| Adjusted EBITDA |  |  | 188,602 |  |  |  | 183,816 |  |  |  | 425,222 |  |  |  | 651,691 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 493 |  |  |  | 3,632 |  |  |  | 4,146 |  |  |  | 10,799 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 188,109 |  |  | $ | 180,184 |  |  | $ | 421,076 |  |  | $ | 640,892 |  |

[0001437749-23-029637:8k_2_02:94]
| (1) Includes gains/losses on the disposition of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
| (6) The amount recorded in the third quarter 2023 represents a provision for judgments, estimates of pre-judgment interest and costs, and legal expenses related to certain patent lawsuits. The amount recorded in the first quarter 2023 represents a provision of $5.8 million for a matter with the Consumer Product Safety Commission (CPSC) concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. The amount recorded in the third quarter of 2022 represents a specific bad debt provision of $17.9 million for a clean energy product customer that filed for bankruptcy as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters. |

[0001437749-23-029637:8k_2_02:95]
10

[0001437749-23-029637:8k_2_02:96]
Net income to Adjusted net income reconciliation

[0001437749-23-029637:8k_2_02:97]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | 2,305 |  |  |  | 6,492 |  |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 120,310 |  |  |  | 334,979 |  |
| Amortization of intangible assets |  |  | 26,718 |  |  |  | 25,751 |  |  |  | 78,934 |  |  |  | 77,681 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 981 |  |  |  | 974 |  |  |  | 2,902 |  |  |  | 2,261 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 356 |  |  |  | (7,605 | ) |  |  | 1,743 |  |  |  | (7,651 | ) |
| (Gain)/loss attributable to business or asset dispositions (8) |  |  | - |  |  |  | - |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (5) |  |  | 5,291 |  |  |  | 622 |  |  |  | 8,151 |  |  |  | 3,371 |  |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  | 22,113 |  |  |  | 55,265 |  |  |  | 27,913 |  |  |  | 55,265 |  |
| Tax effect of add backs |  |  | (13,887 | ) |  |  | (21,233 | ) |  |  | (28,476 | ) |  |  | (36,907 | ) |
| Adjusted net income |  |  | 102,206 |  |  |  | 114,220 |  |  |  | 211,358 |  |  |  | 432,513 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,031 |  |  |  | 2,305 |  |  |  | 7,199 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 101,949 |  |  | $ | 112,189 |  |  | $ | 209,053 |  |  | $ | 425,314 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.64 |  |  | $ | 1.75 |  |  | $ | 3.35 |  |  | $ | 6.58 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,091,163 |  |  |  | 64,267,638 |  |  |  | 62,362,743 |  |  |  | 64,630,346 |  |

[0001437749-23-029637:8k_2_02:98]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |

[0001437749-23-029637:8k_2_02:99]
Free Cash Flow Reconciliation

[0001437749-23-029637:8k_2_02:100]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net cash provided by operating activities |  | $ | 140,136 |  |  | $ | (56,045 | ) |  | $ | 204,724 |  |  | $ | (42,352 | ) |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,061 |  |  |  | 902 |  |  |  | 2,533 |  |  |  | 2,745 |  |
| Expenditures for property and equipment |  |  | (23,818 | ) |  |  | (18,330 | ) |  |  | (77,718 | ) |  |  | (64,833 | ) |
| Free cash flow |  | $ | 117,379 |  |  | $ | (73,473 | ) |  | $ | 129,539 |  |  | $ | (104,440 | ) |

[0001437749-23-029637:8k_2_02:101]
11
