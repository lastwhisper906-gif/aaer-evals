# GNRC notes — 0001437749-23-030646


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-23-030646:notes:1]
[same as prior period, unchanged from 0001437749-23-022513:notes:1]

[0001437749-23-030646:notes:2]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-23-030646:notes:3]
[same as prior period, unchanged from 0001437749-23-022513:notes:3]

[0001437749-23-030646:notes:4]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively "EEC"). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. ("Blue Pillar"), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |

[0001437749-23-030646:notes:5]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles ("GAAP"). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-23-030646:notes:6]
The condensed consolidated balance sheet as of  September 30, 2023, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2023 and 2022, have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-23-030646:notes:7]
[same as prior period, unchanged from 0001437749-23-022513:notes:7]

[0001437749-23-030646:notes:8]
[same as prior period, unchanged from 0001437749-23-022513:notes:8]

[0001437749-23-030646:notes:9]
[same as prior period, unchanged from 0001437749-23-022513:notes:9]

[0001437749-23-030646:notes:10]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC"). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-23-030646:notes:11]
[same as prior period, unchanged from 0001437749-23-022513:notes:11]

[0001437749-23-030646:notes:12]
[same as prior period, unchanged from 0001437749-23-022513:notes:12]

[0001437749-23-030646:notes:13]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market.

[0001437749-23-030646:notes:14]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized prior to  March 31, 2024, and there have not been any material changes to the balances acquired as of  September 30, 2023. The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  September 30, 2023. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-23-030646:notes:15]
[same as prior period, unchanged from 0001437749-23-022513:notes:15]

[0001437749-23-030646:notes:16]
[same as prior period, unchanged from 0001437749-23-022513:notes:16]

[0001437749-23-030646:notes:17]
[same as prior period, unchanged from 0001437749-23-022513:notes:17]

[0001437749-23-030646:notes:18]
The combined purchase price for these two acquisitions was $25,654, net of cash acquired. The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for EEC was finalized in the second quarter of 2023 and did not result in material adjustments to the Company's preliminary estimates. The Company will finalize the purchase accounting for Blue Pillar in the fourth quarter of 2023. Through the third quarter of 2023, the combined purchase price for EEC and Blue Pillar has increased to $27,456 due to working capital adjustments. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  September 30, 2023. Pro forma and other financial information are not presented as the effects of the 2022 acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-23-030646:notes:19]
[same as prior period, unchanged from 0001437749-23-022513:notes:19]

[0001437749-23-030646:notes:20]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries ("Pramac"). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price included $105,264 of initial consideration (which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023) and $11,490 of contingent deferred consideration to be paid in up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025.

[0001437749-23-030646:notes:21]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited ("Captiva"). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand.

[0001437749-23-030646:notes:22]
[same as prior period, unchanged from 0001437749-23-022513:notes:22]

[0001437749-23-030646:notes:23]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 5,688 |  |  | $ | 82,830 |  |  | $ | 110,471 |  |  | $ | 58,050 |  |
| Net income |  |  | 58 |  |  |  | 1,589 |  |  |  | 1,728 |  |  |  | 5,261 |  |
| Foreign currency translation |  |  | (153 | ) |  |  | (2,708 | ) |  |  | (689 | ) |  |  | (6,817 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | - |  |  |  | (116,754 | ) |  |  | (375 | ) |
| Redemption value adjustment |  |  | 46 |  |  |  | 5,225 |  |  |  | 10,883 |  |  |  | 30,817 |  |
| Balance at end of period |  | $ | 5,639 |  |  | $ | 86,936 |  |  | $ | 5,639 |  |  | $ | 86,936 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-23-030646:notes:24]
[same as prior period, unchanged from 0001437749-23-022513:notes:24]

[0001437749-23-030646:notes:25]
[same as prior period, unchanged from 0001437749-23-022513:notes:25]

[0001437749-23-030646:notes:26]
[same as prior period, unchanged from 0001437749-23-022513:notes:26]

[0001437749-23-030646:notes:27]
[same as prior period, unchanged from 0001437749-23-022513:notes:27]

[0001437749-23-030646:notes:28]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements which were still outstanding as of  September 30, 2023.

[0001437749-23-030646:notes:29]
[same as prior period, unchanged from 0001437749-23-022513:notes:29]

[0001437749-23-030646:notes:30]
The amount of gains, net of tax recognized, for the three and nine months ended  September 30, 2023, were $1,045 and $2,309, respectively. The amount of gains, net of tax recognized, for the three and nine months ended  September 30, 2022, were $13,757 and $39,614, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-23-030646:notes:31]
[same as prior period, unchanged from 0001437749-23-022513:notes:31]

[0001437749-23-030646:notes:32]
[same as prior period, unchanged from 0001437749-23-022513:notes:32]

[0001437749-23-030646:notes:33]
|  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Commodity contracts |  | $ | 9 |  |  | $ | - |  |
| Foreign currency contracts |  |  | (181 | ) |  |  | 94 |  |
| Interest rate swaps |  |  | 52,360 |  |  |  | 49,279 |  |

[0001437749-23-030646:notes:34]
In the condensed consolidated balance sheets, the fair value of the commodity contracts is included in prepaid expenses and other current assets. The fair value of the foreign currency contracts is included in other accrued liabilities at  September 30, 2023, and included in prepaid expenses and other current assets at  December 31, 2022. The fair value of the interest rate swaps is included in operating lease and other non-current assets. Excluding the impact of credit risk, the fair value of the derivative contracts as of  September 30, 2023, and  December 31, 2022, is an asset of $54,388 and $51,184, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-030646:notes:35]
[same as prior period, unchanged from 0001437749-23-022513:notes:35]

[0001437749-23-030646:notes:36]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-23-030646:notes:37]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $524,529, was $530,000 (Level 2) at  September 30, 2023, as calculated based on independent valuations which contain inputs and significant value drivers that are observable. The fair value of Term Loan A approximates the carrying value.

[0001437749-23-030646:notes:38]
[same as prior period, unchanged from 0001437749-23-022513:notes:38]

[0001437749-23-030646:notes:39]
[same as prior period, unchanged from 0001437749-23-022513:notes:39]

[0001437749-23-030646:notes:40]
Certain of the Company's business combinations involve potential payment of future consideration contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's condensed consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-23-030646:notes:41]
At  September 30, 2023, the fair value of contingent consideration for Chilicon Power LLC ("Chilicon") and Pramac is $38,746 and is included in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2022, the Company had contingent consideration of $49,500 in other accrued liabilities and $32,033 in other long-term liabilities in the condensed consolidated balance sheets. The earn-out period for the contingent consideration for Chilicon extends through  December 31, 2028. The earn-out period for the contingent consideration for Pramac extends through  December 31, 2025.

[0001437749-23-030646:notes:42]
[same as prior period, unchanged from 0001437749-23-022513:notes:42]

[0001437749-23-030646:notes:43]
| Beginning balance, January 1, 2023 |  | $ | 81,533 |  |
| Changes in fair value |  |  | - |  |
| Additional contingent consideration (1) |  |  | 11,490 |  |
| Payment of contingent consideration (2) |  |  | (53,786 | ) |
| Present value interest accretion |  |  | (491 | ) |
| Ending balance, September 30, 2023 |  | $ | 38,746 |  |

[0001437749-23-030646:notes:44]
[same as prior period, unchanged from 0001437749-23-022513:notes:44]

[0001437749-23-030646:notes:45]
(2) Includes payments of $479 in cash and $44,521 in shares for the ecobee acquisition, $4,286 in shares for the Chilicon acquisition, and $4,500 in cash for the Mean Green Products ("Mean Green") acquisition. The payment of common stock is accounted for as a non-cash item in the condensed consolidated statement of cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-23-030646:notes:46]
[same as prior period, unchanged from 0001437749-23-022513:notes:46]

[0001437749-23-030646:notes:47]
The following table presents a disclosure of changes in AOCL during the three and nine months ended  September 30, 2023 and 2022, net of tax:

[0001437749-23-030646:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |
| Other comprehensive income (loss) |  |  | (26,443 | ) | (1) |  |  | 1,045 |  | (2) |  |  | (25,398 | ) |
| Ending Balance – September 30, 2023 |  | $ | (80,366 | ) |  |  | $ | 38,752 |  |  |  | $ | (41,614 | ) |

[0001437749-23-030646:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |
| Other comprehensive income (loss) |  |  | (51,324 | ) | (3) |  |  | 13,757 |  | (4) |  |  | (37,567 | ) |
| Ending Balance – September 30, 2022 |  | $ | (157,969 | ) |  |  | $ | 37,563 |  |  |  | $ | (120,406 | ) |

[0001437749-23-030646:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 21,179 |  | (5) |  |  | 2,309 |  | (6) |  |  | 23,488 |  |
| Ending Balance – September 30, 2023 |  | $ | (80,366 | ) |  |  | $ | 38,752 |  |  |  | $ | (41,614 | ) |

[0001437749-23-030646:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) |  |  | (105,265 | ) | (3) |  |  | 39,614 |  | (7) |  |  | (65,651 | ) |
| Ending Balance – September 30, 2022 |  | $ | (157,969 | ) |  |  | $ | 37,563 |  |  |  | $ | (120,406 | ) |

[0001437749-23-030646:notes:52]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized gains of $1,394 on the interest rate swaps, net of tax effect of $(349) for the three months ended September 30, 2023. |

[0001437749-23-030646:notes:53]
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three and nine months ended September 30, 2022, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized gains of $18,404 on the interest rate swaps, net of tax effect of $(4,647) for the three months ended September 30, 2022. |
|  | (5) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (6) | Represents unrealized gains of $3,081 on the interest rate swaps, net of tax effect of $(772) for the nine months ended September 30, 2023. |
|  | (7) | Represents unrealized gains of $52,995 on the interest rate swaps, net of tax effect of $(13,381) for the nine months ended September 30, 2022. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-030646:notes:54]
[same as prior period, unchanged from 0001437749-23-022513:notes:54]

[0001437749-23-030646:notes:55]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and all acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations and the Company's various international acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-23-030646:notes:56]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices and solutions, and other power products designed for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The breakout of net sales between residential, C&I, and other products and services by reportable segment is as follows:

[0001437749-23-030646:notes:57]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

[0001437749-23-030646:notes:58]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

[0001437749-23-030646:notes:59]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |

[0001437749-23-030646:notes:60]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |

[0001437749-23-030646:notes:61]
[same as prior period, unchanged from 0001437749-23-022513:notes:61]

[0001437749-23-030646:notes:62]
[same as prior period, unchanged from 0001437749-23-022513:notes:62]

[0001437749-23-030646:notes:63]
[same as prior period, unchanged from 0001437749-23-022513:notes:63]

[0001437749-23-030646:notes:64]
[same as prior period, unchanged from 0001437749-23-022513:notes:64]

[0001437749-23-030646:notes:65]
|  |  | Three Months Ended September 30, 2023 |  |  | Three Months Ended September 30, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | - |  |  | $ | 1,070,667 |  |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | - |  |  | $ | 1,088,258 |  |
| Intersegment sales |  |  | 7,640 |  |  |  | 23,293 |  |  |  | (30,933 | ) |  |  | - |  |  |  | 15,485 |  |  |  | 25,416 |  |  |  | (40,901 | ) |  |  | - |  |
| Total sales |  | $ | 894,005 |  |  | $ | 207,595 |  |  | $ | (30,933 | ) |  | $ | 1,070,667 |  |  | $ | 946,617 |  |  | $ | 182,542 |  |  | $ | (40,901 | ) |  | $ | 1,088,258 |  |

[0001437749-23-030646:notes:66]
|  |  | Nine Months Ended September 30, 2023 |  |  | Nine Months Ended September 30, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | - |  |  | $ | 2,958,997 |  |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | - |  |  | $ | 3,515,505 |  |
| Intersegment sales |  |  | 33,960 |  |  |  | 84,078 |  |  |  | (118,038 | ) |  |  | - |  |  |  | 44,742 |  |  |  | 59,075 |  |  |  | (103,817 | ) |  |  | - |  |
| Total sales |  | $ | 2,429,252 |  |  | $ | 647,783 |  |  | $ | (118,038 | ) |  | $ | 2,958,997 |  |  | $ | 3,047,979 |  |  | $ | 571,343 |  |  | $ | (103,817 | ) |  | $ | 3,515,505 |  |

[0001437749-23-030646:notes:67]
Management evaluates the performance of the Company's segments based primarily on Adjusted EBITDA, which is reconciled to income before provision for income taxes below. The computation of Adjusted EBITDA is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, and certain other specific provisions noted below.

[0001437749-23-030646:notes:68]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 160,270 |  |  | $ | 159,810 |  |  | $ | 331,134 |  |  | $ | 572,159 |  |
| International |  |  | 28,332 |  |  |  | 24,006 |  |  |  | 94,088 |  |  |  | 79,532 |  |
| Total adjusted EBITDA |  | $ | 188,602 |  |  | $ | 183,816 |  |  | $ | 425,222 |  |  | $ | 651,691 |  |
| Interest expense |  |  | (24,707 | ) |  |  | (15,514 | ) |  |  | (72,862 | ) |  |  | (35,303 | ) |
| Depreciation and amortization |  |  | (42,951 | ) |  |  | (39,165 | ) |  |  | (124,149 | ) |  |  | (116,724 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (2,055 | ) |  |  | 6,840 |  |  |  | 5,257 |  |  |  | 10,025 |  |
| Non-cash share-based compensation expense (2) |  |  | (9,927 | ) |  |  | (6,861 | ) |  |  | (30,306 | ) |  |  | (23,423 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (3,743 | ) |
| Transaction costs and credit facility fees (4) |  |  | (921 | ) |  |  | (1,250 | ) |  |  | (3,161 | ) |  |  | (3,831 | ) |
| Business optimization and other charges (5) |  |  | (5,291 | ) |  |  | (622 | ) |  |  | (8,151 | ) |  |  | (3,371 | ) |
| Provision for regulatory, legal, and clean energy product charges (6) |  |  | (22,113 | ) |  |  | (55,265 | ) |  |  | (27,913 | ) |  |  | (55,265 | ) |
| Other |  |  | (575 | ) |  |  | 61 |  |  |  | (443 | ) |  |  | 951 |  |
| Income before provision for income taxes |  | $ | 80,062 |  |  | $ | 72,040 |  |  | $ | 163,494 |  |  | $ | 421,007 |  |

[0001437749-23-030646:notes:69]
[same as prior period, unchanged from 0001437749-23-022513:notes:69]

[0001437749-23-030646:notes:70]
[same as prior period, unchanged from 0001437749-23-022513:notes:70]

[0001437749-23-030646:notes:71]
|  | (3) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment. |
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (6) | The amount recorded in the third quarter 2023 represents a provision for judgments, estimates of pre-judgment interest and costs, and legal expenses related to certain patent lawsuits. The amount recorded in the first quarter 2023 represents a provision of $5,800 for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. The amount recorded in the third quarter of 2022 represents a specific bad debt provision of $17,926 for a clean energy product customer that filed for bankruptcy as well as a warranty provision of $37,338 to address certain clean energy product warranty-related matters. |

[0001437749-23-030646:notes:72]
The Company’s sales in the U.S. represented approximately 79% and 82% of total sales for the three months ended  September 30, 2023 and 2022, respectively. The Company's sales in the U.S. represented approximately 77% and 82% of total sales for the nine months ended  September 30, 2023 and 2022, respectively. Approximately 75% and 77% of the Company’s identifiable long-lived assets were located in the U.S. at  September 30, 2023, and  December 31, 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-23-030646:notes:73]
[same as prior period, unchanged from 0001437749-23-022513:notes:74]

[0001437749-23-030646:notes:74]
[same as prior period, unchanged from 0001437749-23-022513:notes:75]

[0001437749-23-030646:notes:75]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Raw material |  | $ | 766,826 |  |  | $ | 798,340 |  |
| Work-in-process |  |  | 14,365 |  |  |  | 14,899 |  |
| Finished goods |  |  | 529,938 |  |  |  | 592,145 |  |
| Total |  | $ | 1,311,129 |  |  | $ | 1,405,384 |  |

[0001437749-23-030646:notes:76]
[same as prior period, unchanged from 0001437749-23-022513:notes:77]

[0001437749-23-030646:notes:77]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Land and improvements |  | $ | 22,811 |  |  | $ | 22,589 |  |
| Buildings and improvements |  |  | 255,165 |  |  |  | 243,553 |  |
| Machinery and equipment |  |  | 261,170 |  |  |  | 229,593 |  |
| Dies and tools |  |  | 41,536 |  |  |  | 37,343 |  |
| Vehicles |  |  | 10,920 |  |  |  | 9,807 |  |
| Office equipment and systems |  |  | 178,364 |  |  |  | 148,166 |  |
| Leasehold improvements |  |  | 8,494 |  |  |  | 6,849 |  |
| Construction in progress |  |  | 59,536 |  |  |  | 52,522 |  |
| Gross property and equipment |  |  | 837,996 |  |  |  | 750,422 |  |
| Accumulated depreciation |  |  | (326,103 | ) |  |  | (282,818 | ) |
| Total |  | $ | 511,893 |  |  | $ | 467,604 |  |

[0001437749-23-030646:notes:78]
Total property and equipment includes finance leases of $27,168 and $24,719 on  September 30, 2023, and  December 31, 2022, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-23-030646:notes:79]
[same as prior period, unchanged from 0001437749-23-022513:notes:80]

[0001437749-23-030646:notes:80]
[same as prior period, unchanged from 0001437749-23-022513:notes:81]

[0001437749-23-030646:notes:81]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 122,222 |  |  | $ | 110,338 |  |  | $ | 138,011 |  |  | $ | 94,213 |  |
| Payments |  |  | (24,427 | ) |  |  | (22,677 | ) |  |  | (76,069 | ) |  |  | (54,135 | ) |
| Provision for warranty issued |  |  | 18,136 |  |  |  | 19,076 |  |  |  | 51,353 |  |  |  | 62,169 |  |
| Changes in estimates for pre-existing warranties (1) |  |  | 3,630 |  |  |  | 38,571 |  |  |  | 6,266 |  |  |  | 43,061 |  |
| Balance at end of period |  | $ | 119,561 |  |  | $ | 145,308 |  |  | $ | 119,561 |  |  | $ | 145,308 |  |

[0001437749-23-030646:notes:82]
(1) Includes a specific warranty provision recorded during the third quarter of 2022 in the amount of $37,338 to address certain clean energy product warranty-related matters.

[0001437749-23-030646:notes:83]
[same as prior period, unchanged from 0001437749-23-022513:notes:83]

[0001437749-23-030646:notes:84]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 140,922 |  |  | $ | 121,898 |  |  | $ | 132,813 |  |  | $ | 111,647 |  |
| Deferred revenue contracts issued |  |  | 10,615 |  |  |  | 10,324 |  |  |  | 30,774 |  |  |  | 31,202 |  |
| Amortization of deferred revenue contracts |  |  | (6,414 | ) |  |  | (5,470 | ) |  |  | (18,464 | ) |  |  | (16,097 | ) |
| Balance at end of period |  | $ | 145,123 |  |  | $ | 126,752 |  |  | $ | 145,123 |  |  | $ | 126,752 |  |

[0001437749-23-030646:notes:85]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  September 30, 2023, is as follows:

[0001437749-23-030646:notes:86]
| Remainder of 2023 |  | $ | 6,521 |  |
| 2024 |  |  | 27,066 |  |
| 2025 |  |  | 28,060 |  |
| 2026 |  |  | 24,554 |  |
| 2027 |  |  | 19,461 |  |
| After 2027 |  |  | 39,461 |  |
| Total |  | $ | 145,123 |  |

[0001437749-23-030646:notes:87]
[same as prior period, unchanged from 0001437749-23-022513:notes:87]

[0001437749-23-030646:notes:88]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 70,572 |  |  | $ | 89,141 |  |
| Long-term portion - other long-term liabilities |  |  | 48,989 |  |  |  | 48,870 |  |
| Total |  | $ | 119,561 |  |  | $ | 138,011 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 23,597 |  |  | $ | 30,291 |  |
| Long-term portion - Deferred revenue |  |  | 121,526 |  |  |  | 102,522 |  |
| Total |  | $ | 145,123 |  |  | $ | 132,813 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-030646:notes:89]
[same as prior period, unchanged from 0001437749-23-022513:notes:89]

[0001437749-23-030646:notes:90]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,871 and $33,551 on  September 30, 2023, and  December 31, 2022, respectively. During the nine months ended  September 30, 2023, the Company recognized revenue of $30,252 related to amounts included in the  December 31, 2022, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-030646:notes:91]
11.   Credit Agreements

[0001437749-23-030646:notes:92]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $74,346 and $48,990, respectively.

[0001437749-23-030646:notes:93]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-23-030646:notes:94]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,666 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 200,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 30,235 |  |  |  | 27,420 |  |
| Other |  |  | 5,909 |  |  |  | 966 |  |
| Total |  |  | 1,502,478 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 33,823 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,514 |  |  |  | 2,650 |  |
| Total |  | $ | 1,465,141 |  |  | $ | 1,369,085 |  |

[0001437749-23-030646:notes:95]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  September 30, 2023, are as follows:

[0001437749-23-030646:notes:96]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 200,000 |  |  |  | 800,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 200,000 |  |  | $ | 1,480,000 |  |

[0001437749-23-030646:notes:97]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments with the first maturity in  September 2023. Payment on the Tranche A Term Loan Facility is due on the last day of the quarter, or the following business day if the last day of the quarter is a non-business day.

[0001437749-23-030646:notes:98]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility ("Tranche B Term Loan Facility") and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate ("SOFR") rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  September 30, 2023, was 7.18%.

[0001437749-23-030646:notes:99]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2023, the Company’s net secured leverage ratio was 2.25 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-23-030646:notes:100]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new revolving facility with an available borrowing amount of $1,250,000 ("Revolving Facility"), terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-030646:notes:101]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  September 30, 2023, was 7.10%.

[0001437749-23-030646:notes:102]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2023, the Company’s total leverage ratio was 2.37 to 1.00, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2023.

[0001437749-23-030646:notes:103]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-23-030646:notes:104]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-030646:notes:105]
As of  September 30, 2023, there was $200,000 outstanding under the Revolving Facility, leaving $1,049,945 of unused capacity, net of outstanding letters of credit. Total availability on the Revolving Facility is reduced to $822,111 under the Company's most restrictive debt covenants.

[0001437749-23-030646:notes:106]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.


## us-gaap:TreasuryStockTextBlock

[0001437749-23-030646:notes:107]
[same as prior period, unchanged from 0001437749-23-022513:notes:107]

[0001437749-23-030646:notes:108]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allowed for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the third quarter of 2023, the Company repurchased 875,580 shares of its common stock for $100,267. There were no share repurchases under the program during the first and second quarters of 2023. During the third quarter of 2022, the Company repurchased 536,633 shares of its common stock for $123,900. There were no share repurchases under the program during the first and second quarters of 2022. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 12,624,293 shares of its common stock for $877,396 (at an average cost per share of $69.50). Periodically, the Company has reissued shares out of Treasury stock, including for earnout payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-030646:notes:109]
[same as prior period, unchanged from 0001437749-23-022513:notes:109]

[0001437749-23-030646:notes:110]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest”, to the condensed consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-23-030646:notes:111]
[same as prior period, unchanged from 0001437749-23-022513:notes:111]

[0001437749-23-030646:notes:112]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (46 | ) |  |  | (5,225 | ) |  |  | (10,883 | ) |  |  | (30,817 | ) |
| Net income attributable to common shareholders |  | $ | 60,331 |  |  | $ | 53,045 |  |  | $ | 107,122 |  |  | $ | 297,670 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,368,440 |  |  |  | 63,249,881 |  |  |  | 61,552,949 |  |  |  | 63,480,161 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 722,723 |  |  |  | 1,006,814 |  |  |  | 809,794 |  |  |  | 1,139,242 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | 10,943 |  |  |  | - |  |  |  | 10,943 |  |
| Diluted shares |  |  | 62,091,163 |  |  |  | 64,267,638 |  |  |  | 62,362,743 |  |  |  | 64,630,346 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.98 |  |  | $ | 0.84 |  |  | $ | 1.74 |  |  | $ | 4.69 |  |
| Diluted |  | $ | 0.97 |  |  | $ | 0.83 |  |  | $ | 1.72 |  |  | $ | 4.61 |  |

[0001437749-23-030646:notes:113]
(1) Excludes approximately 370,000 and 344,000 stock options and restricted stock awards for the three and nine months ended  September 30, 2023,respectively, because they would be anti-dilutive. Excludes approximately 85,000 and 44,000 stock options and restricted stock awards for the three and nine months ended  September 30, 2022, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-030646:notes:114]
[same as prior period, unchanged from 0001437749-23-022513:notes:114]

[0001437749-23-030646:notes:115]
The effective income tax rates for the nine months ended  September 30, 2023 and 2022, were 26.4% and 20.4%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation coupled with lower year-over-year pre-tax book income in the current year, and certain favorable discrete tax items in the prior year which did not repeat.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-030646:notes:116]
15. Commitments and Contingencies

[0001437749-23-030646:notes:117]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2023, and  December 31, 2022, was $168.5 million and $212.2 million, respectively.

[0001437749-23-030646:notes:118]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (“PHS”) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, PHS filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which PHS characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to PHS but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-23-030646:notes:119]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Generac Power disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

[0001437749-23-030646:notes:120]
Eight additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  July 5, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power and/or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative classes allegedly incurred. In some of these cases, the Company as well as Generac Power has been named as a defendant. The cases were filed in or removed to the federal district courts for the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386; Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034; Kates v. Generac Power Systems, Inc., et al., Case No. 23-cv-00892; and Zukas, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-00874), the Northern District of California (Moon v. Generac Power Systems, Inc., et al., Case No. 22-cv-09183; Hufton, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-02462), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203), and the Eastern District of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23-cv-00217). Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints.

[0001437749-23-030646:notes:121]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings in the Eastern District of Wisconsin. Plaintiffs filed their consolidated master complaint on  September 1, 2023, and the Company moved to dismiss on  October 31, 2023. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-23-030646:notes:122]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint, which raised an additional claim for alleged violation of federal securities law related to the Company’s disclosures concerning demand for home standby generators. The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-23-030646:notes:123]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief. On  May 2, 2023, the court consolidated the two actions. On  May 30, 2023, the court entered an order staying the consolidated action.

[0001437749-23-030646:notes:124]
Between  March 20, 2023, and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. On  June 1, 2023, the court entered an order consolidating the three actions, appointing lead plaintiffs’ counsel, and staying the consolidated actions. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-23-030646:notes:125]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-23-030646:notes:126]
On  November 30, 2022, the U.S. CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the CPSA, 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. The Company is cooperating fully with this investigation and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigation.

[0001437749-23-030646:notes:127]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump-sum payment of $5.4 million for past and future damages. On  August 23, 2023, the court issued its final judgment in favor of EcoFactor for $5.4 million, on a total lump-sum basis, together with interest and costs. ecobee filed a motion for judgment as a matter of law and intends to appeal the judgment. There are presently two remaining trials involving EcoFactor. EcoFactor claims ecobee infringes two patents in Case No. 22-cv-00033-ADA, which is scheduled for a jury trial in the Western District of Texas on  September 16, 2024, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023, in the District of Delaware. ecobee denies infringement and intends to vigorously defend each of the lawsuits.

[0001437749-23-030646:notes:128]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11.5 million. ecobee intends to file motions for judgment as a matter of law and an appeal of any adverse verdict.

[0001437749-23-030646:notes:129]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)). Spartronics made similar claims against Generac Power in third-party complaints in lawsuits Spartronics is defending brought by its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.); JC Global, Inc. v. Spartronics (M.D. Fla. 23-cv-1155); and Circuit Interruption Tech. v. Spartronics Vietnam, Inc., Case No. 23-cv-2140-WMW-DLM (D. Minn.)). Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and has sought and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.

[0001437749-23-030646:notes:130]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-23-030646:notes:131]
Item 5.           Other Information

[0001437749-23-030646:notes:132]
During the three months ended  September 30, 2023, no director or officer of the Company adopted, modified or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.
