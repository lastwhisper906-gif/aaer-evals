# GNRC 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001437749-15-003654:item_9a:1]
Item 9A.   Controls and Procedures

[0001437749-15-003654:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-15-003654:item_9a:3]
Disclosure controls and procedures are controls and other procedures that are designed to ensure that information required to be disclosed by us in reports we file or submit under the Securities Exchange Act of 1934 (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure.

[0001437749-15-003654:item_9a:4]
Our management, with the participation of our Chief Executive Officer and our Chief Financial Officer, has conducted an evaluation of the design and operation of our disclosure controls and procedures as defined in Rule 13a-15(e) and 15d-15(e) under the Exchange Act as of the end of the period covered by this report on Form 10-K. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective in providing reasonable assurance that the information required to be disclosed in this report on Form 10-K has been recorded, processed, summarized and reported as of the end of the period covered by this report on Form 10-K.

[0001437749-15-003654:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001437749-15-003654:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Our internal control over financial reporting is designed under the supervision of our Chief Executive Officer and Chief Financial Officer to provide reasonable assurance regarding the reliability of financial reporting and the preparation of the consolidated financial statements in accordance with U.S. GAAP.

[0001437749-15-003654:item_9a:7]
69

[0001437749-15-003654:item_9a:8]
Internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of the financial statements in accordance with U.S. GAAP, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the Company’s financial statements.

[0001437749-15-003654:item_9a:9]
There are inherent limitations to the effectiveness of any internal control over financial reporting, including the possibility of human error or the circumvention or overriding of the controls. Accordingly, even an effective internal control over financial reporting can provide only reasonable assurance of achieving its objective. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate, because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-15-003654:item_9a:10]
Under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, our management conducted an assessment of the effectiveness of internal control over financial reporting as of December 31, 2014 based on the criteria established in the 2013 Internal Control - Integrated Framework, issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, our management has concluded that our internal control over financial reporting was effective as of December 31, 2014. In conducting this assessment, our management excluded the Powermate and MAC businesses because they were not acquired until the third and fourth quarters of 2014, respectively.

[0001437749-15-003654:item_9a:11]
Our independent registered public accounting firm has issued an attestation report on our internal control over financial reporting as of December 31, 2014. Its report appears in the consolidated financial statements included in this Annual Report on Form 10-K on page 39.

[0001437749-15-003654:item_9a:12]
Changes in Internal Control Over Financial Reporting

[0001437749-15-003654:item_9a:13]
There have been no changes in our internal control over financial reporting that occurred during the three months ended December 31, 2014 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
