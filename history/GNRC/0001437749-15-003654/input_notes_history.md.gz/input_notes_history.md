# GNRC note change history — 0001437749-14-014607 → 0001437749-14-020036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001437749-14-020036:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2014 and December 31, 2013 was approximately $32,400 and $24,300 respectively.
  (was, 2014-08-07, similarity 0.9889):
[0001437749-14-014607:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2014 and December 31, 2013 was approximately $31,700 and $24,300 respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001437749-14-020036:note_history:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products. As a leader in power equipment serving residential, light-commercial, industrial, oil & gas, and construction markets, Generac’s power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2014-08-07, similarity 0.6158):
[0001437749-14-014607:note_history:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial and construction markets.

- changed (2014-11-07):
[0001437749-14-020036:note_history:3]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:
  (was, 2014-08-07, similarity 0.9547):
[0001437749-14-014607:note_history:3]
In the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of recent acquisitions include the following:

- added (2014-11-07):
[0001437749-14-020036:note_history:4]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

- changed (2014-11-07):
[0001437749-14-020036:note_history:5]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |
  (was, 2014-08-07, similarity 0.8609):
[0001437749-14-014607:note_history:5]
|  | ● | On December 8, 2012, the Company acquired Ottomotores, with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a significant market participant throughout all of Latin America. |

- changed (2014-11-07):
[0001437749-14-020036:note_history:6]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |
  (was, 2014-08-07, similarity 0.8648):
[0001437749-14-014607:note_history:6]
|  | ● | On August 1, 2013, the Company acquired Tower Light. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- added (2014-11-07):
[0001437749-14-020036:note_history:7]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |

- added (2014-11-07):
[0001437749-14-020036:note_history:8]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

- added (2014-11-07):
[0001437749-14-020036:note_history:9]
The condensed consolidated balance sheet as of September 30, 2014, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2014-11-07):
[0001437749-14-020036:note_history:10]
The following presents a tabular disclosure of changes in accumulated other comprehensive loss during the three and nine months ended September 30, 2014 and 2013, net of tax:
  (was, 2014-08-07, similarity 0.9358):
[0001437749-14-014607:note_history:10]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three and six months ended June 30, 2014 and 2013, net of tax:

- changed (2014-11-07):
[0001437749-14-020036:note_history:11]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |
  (was, 2014-08-07, similarity 0.7819):
[0001437749-14-014607:note_history:11]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

- changed (2014-11-07):
[0001437749-14-020036:note_history:12]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |
| Other comprehensive income before reclassifications |  |  | 867 |  |  |  | - |  |  |  | - |  |  |  | 867 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 376 |  |  |  | 376 |  |
| Net current-period other comprehensive income |  |  | 867 |  |  |  | - |  |  |  | 376 |  |  |  | 1,243 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |
  (was, 2014-08-07, similarity 0.882):
[0001437749-14-014607:note_history:12]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,005 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,024 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |

- changed (2014-11-07):
[0001437749-14-020036:note_history:13]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $393 net of tax benefit of $17 for the three months ended September 30, 2013. |
  (was, 2014-08-07, similarity 0.9674):
[0001437749-14-014607:note_history:13]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $1,049 net of tax benefit of $46 for the three months ended June 30, 2013 |

- changed (2014-11-07):
[0001437749-14-020036:note_history:14]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |
  (was, 2014-08-07, similarity 0.8804):
[0001437749-14-014607:note_history:14]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |
| Other comprehensive loss before reclassifications |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

- changed (2014-11-07):
[0001437749-14-020036:note_history:15]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 886 |  |  |  | - |  |  |  | - |  |  |  | 886 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,381 |  |  |  | 2,381 |  |
| Net current-period other comprehensive income |  |  | 886 |  |  |  | - |  |  |  | 2,381 |  |  |  | 3,267 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |
  (was, 2014-08-07, similarity 0.8797):
[0001437749-14-014607:note_history:15]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,003 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,022 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |

- changed (2014-11-07):
[0001437749-14-020036:note_history:16]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,490 net of tax benefit of $109 for the nine months ended September 30, 2013. |
  (was, 2014-08-07, similarity 0.9521):
[0001437749-14-014607:note_history:16]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,097 net of tax benefit of $92 for the six months ended June 30, 2013 |

- removed (2014-11-07):
[0001437749-14-014607:note_history:17]
|  | ● | On October 3, 2011, the Company acquired Magnum Products, a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products and distribution channels. |

- removed (2014-11-07):
[0001437749-14-014607:note_history:18]
The condensed consolidated balance sheet as of June 30, 2014, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the six months ended June 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001437749-14-020036:note_history:19]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,502 |  |  |  | 9,575 |  |
| Total |  | $ | 5,502 |  |  | $ | 9,575 |  |
  (was, 2014-08-07, similarity 0.972):
[0001437749-14-014607:note_history:19]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 6,509 |  |  |  | 9,575 |  |
| Total |  | $ | 6,509 |  |  | $ | 9,575 |  |

- added (2014-11-07):
[0001437749-14-020036:note_history:20]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,129,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (25,040 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,190 |  |  |  | 2,529 |  |
| Other |  |  | 459 |  |  |  | 1,026 |  |
| Total |  |  | 1,106,609 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 174 |  |  |  | 185 |  |
| Total |  | $ | 1,106,293 |  |  | $ | 1,175,349 |  |

- added (2014-11-07):
[0001437749-14-020036:note_history:21]
Prior to any voluntary prepayments, the New Term Loan amortized in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the New Term Loan Credit Agreement, falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net
      debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets. The Borrower’s net debt leverage ratio as of September 30, 2014 was below 3.00 to 1.00.

- changed (2014-11-07):
[0001437749-14-020036:note_history:22]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of September 30, 2014, no amounts were outstanding under the ABL Facility. As of September 30, 2014, the Company had $173,162 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.
  (was, 2014-08-07, similarity 0.9916):
[0001437749-14-014607:note_history:22]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of June 30, 2014, no amounts were outstanding under the ABL Facility. As of June 30, 2014, the Company had $197,959 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

- added (2014-11-07):
[0001437749-14-020036:note_history:23]
On February 11, 2013, the Company made an $80,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations on the Term Loan Credit Agreement.  As a result, the Company wrote off $1,839 of original issue discount and capitalized debt issuance costs during the first quarter of 2013.  On May 2, 2013, the Company made an additional $30,000 voluntary prepayment of existing debt with available cash on hand.  As a result, the Company wrote off $924 of original issue discount and capitalized debt issuance costs during the second quarter of 2013.

- changed (2014-11-07):
[0001437749-14-020036:note_history:24]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the nine months ended September 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its
      loans under the effective interest method.
  (was, 2014-08-07, similarity 0.9228):
[0001437749-14-014607:note_history:24]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the three and six months ended June 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on
      its loans under the effective interest method.

- changed (2014-11-07):
[0001437749-14-020036:note_history:25]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2014.
  (was, 2014-08-07, similarity 0.9266):
[0001437749-14-014607:note_history:25]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement.

- added (2014-11-07):
[0001437749-14-020036:note_history:26]
On September 30, 2014, the Company made a $50,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2015. As a result, the Company wrote off $1,836 of original issue discount and capitalized debt issuance costs during the third quarter of 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2014-11-07):
[0001437749-14-020036:note_history:27]
As of September 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $5,502 and $9,575, respectively.
  (was, 2014-08-07, similarity 0.9697):
[0001437749-14-014607:note_history:27]
As of June 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $6,509 and $9,575, respectively.

- removed (2014-11-07):
[0001437749-14-014607:note_history:28]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,179,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (27,235 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,421 |  |  |  | 2,529 |  |
| Other |  |  | 566 |  |  |  | 1,026 |  |
| Total |  |  | 1,154,752 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,154,316 |  |  | $ | 1,175,349 |  |

- removed (2014-11-07):
[0001437749-14-014607:note_history:29]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25
      basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-07):
[0001437749-14-020036:note_history:30]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,129,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (25,040 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,190 |  |  |  | 2,529 |  |
| Other |  |  | 459 |  |  |  | 1,026 |  |
| Total |  |  | 1,106,609 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 174 |  |  |  | 185 |  |
| Total |  | $ | 1,106,293 |  |  | $ | 1,175,349 |  |

- removed (2014-11-07):
[0001437749-14-014607:note_history:31]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,179,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (27,235 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,421 |  |  |  | 2,529 |  |
| Other |  |  | 566 |  |  |  | 1,026 |  |
| Total |  |  | 1,154,752 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,154,316 |  |  | $ | 1,175,349 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001437749-14-020036:note_history:32]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,502 |  |  |  | 9,575 |  |
| Total |  | $ | 5,502 |  |  | $ | 9,575 |  |
  (was, 2014-08-07, similarity 0.972):
[0001437749-14-014607:note_history:32]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 6,509 |  |  |  | 9,575 |  |
| Total |  | $ | 6,509 |  |  | $ | 9,575 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-11-07):
[0001437749-14-020036:note_history:33]
12. Subsequent Events

- added (2014-11-07):
[0001437749-14-020036:note_history:34]
On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC, with approximately 100 employees, is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market.
