# GNRC 8-K — 0001437749-15-002323 filed 2015-02-11

## item codes, every 8-K on or before 2015-02-27

- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2015-02-27

- none on or before 2015-02-27

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-002323:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-002323:8k_2_02:2]
ex99-1.htm

[0001437749-15-002323:8k_2_02:3]
Exhibit 99.1

[0001437749-15-002323:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2014 Results

[0001437749-15-002323:8k_2_02:5]
Home standby shipments exceed internal expectations and drive sequential quarterly sales improvement in residential products, as increased sales from C&I products further diversifies business

[0001437749-15-002323:8k_2_02:6]
WAUKESHA, WISCONSIN, (February 11, 2015) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its fourth quarter and full-year ended December 31, 2014. Additionally, the Company initiated its outlook for 2015.

[0001437749-15-002323:8k_2_02:7]
Fourth quarter 2014 Highlights

[0001437749-15-002323:8k_2_02:8]
| ● | Net sales increased by 7.4% to $404.0 million as compared to $376.2 million in the prior-year fourth quarter. |

[0001437749-15-002323:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales increased 17.1% to $185.0 million as compared to $157.9 million in the fourth quarter of 2013. The increase in sales was primarily driven by strength in oil & gas markets and the contributions from recent acquisitions, partially offset by a decline in shipments to certain telecom customers. |

[0001437749-15-002323:8k_2_02:10]
|  | - | Residential product sales declined slightly to $194.9 million from $199.1 million for the fourth quarter of 2013, as the current-year quarter faced a strong prior-year comparison that still benefited from the afterglow period of demand from Superstorm Sandy. Residential product sales for the fourth quarter of 2014 improved 6.1% on a sequential basis from $183.7 million in the third quarter of 2014. |

[0001437749-15-002323:8k_2_02:11]
| ● | Net income during the fourth quarter of 2014 was $49.4 million, or $0.70 per share, as compared to $48.5 million, or $0.69 per share, for the same period of 2013. Adjusted net income, as defined in the accompanying reconciliation schedules, was $68.4 million, or $0.98 per share, as compared to $77.5 million, or $1.11 per share, in the fourth quarter of 2013. |

[0001437749-15-002323:8k_2_02:12]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $92.2 million as compared to $103.6 million in the fourth quarter last year. |

[0001437749-15-002323:8k_2_02:13]
| ● | Cash flow from operations in the fourth quarter of 2014 was $110.5 million as compared to $104.7 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was a quarterly record of $98.5 million as compared to $88.2 million in the fourth quarter of 2013. |

[0001437749-15-002323:8k_2_02:14]
| ● | Total liquidity at December 31, 2014 was strong with cash and cash equivalents of $189.8 million and approximately $150 million available on the Company’s ABL revolving credit facility. Total net debt to adjusted EBITDA, as defined in the accompanying reconciliation schedules, at the end of the fourth quarter was 2.7 times. |

[0001437749-15-002323:8k_2_02:15]
Full-Year 2014 Highlights

[0001437749-15-002323:8k_2_02:16]
| ● | Net sales were $1.461 billion during 2014 as compared to $1.486 billion in 2013. |

[0001437749-15-002323:8k_2_02:17]
|  | - | Residential product sales were $722.2 million as compared to $843.7 million in the prior year. The prior year benefited from approximately $140 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during 2014. Excluding this benefit in the prior year, residential product sales increased approximately 3%. |

[0001437749-15-002323:8k_2_02:18]
|  | - | Commercial & Industrial product sales increased 14.4% to $652.2 million as compared to $569.9 million in 2013. The increase was primarily due to the contributions from recent acquisitions along with strength in oil & gas markets, partially offset by reduced capital spending with certain telecom customers and overall softness within Latin America. |

[0001437749-15-002323:8k_2_02:19]
| ● | Net income during 2014 was $174.6 million, or $2.49 per share, as compared to $174.5 million or $2.51 per share for 2013. Adjusted net income was $234.2 million, or $3.34 per share, as compared to $301.7 million, or $4.33 per share, in 2013. |

[0001437749-15-002323:8k_2_02:20]
| ● | Adjusted EBITDA for 2014 was $337.3 million as compared to $402.6 million last year. |

[0001437749-15-002323:8k_2_02:21]
| ● | Cash flow from operations during 2014 was $253.0 million as compared to $259.9 million in the prior year. Free cash flow was $218.3 million as compared to $229.2 million in 2013. |

[0001437749-15-002323:8k_2_02:22]
| ● | The Company acquired Pramac America, LLC in early September, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. In addition, the Company acquired MAC, Inc. and its related entities in early October, a leading manufacturer of premium-grade commercial and industrial mobile heaters within the U.S. and Canada. |

[0001437749-15-002323:8k_2_02:23]
| ● | Uses of cash during 2014 included $34.7 million for capital expenditures, $61.2 million related to acquisitions and $87.0 million for the pre-payment of term loan debt, including a $25.0 million payment made during the fourth quarter. |

[0001437749-15-002323:8k_2_02:24]
“Home standby generator sales exceeded our expectations during the fourth quarter, with activation rates proving to be resilient as we leveraged our innovative sales and marketing techniques to help create awareness for the product category in a below-normal power outage environment, ” said Aaron Jagdfeld, President and Chief Executive Officer. “For full-year 2014, organic sales improved over 2013 when excluding the approximately $140 million sales headwind in the prior year from Superstorm Sandy, allowing us to hold a new and higher baseline of demand despite certain of our end markets performing below our expectations during the year. In addition, the revenue base for our C&I products continued to increase in scale during 2014, and now represents nearly half of our total sales. We also once again generated a strong level of free cash flow, generating over $200 million for the third consecutive year. We enter 2015 as a more diversified company, with a strong balance sheet and free cash flow generation capability that provide us the flexibility to drive our Powering Ahead strategic plan forward.”

[0001437749-15-002323:8k_2_02:25]
Additional Fourth Quarter 2014 Highlights

[0001437749-15-002323:8k_2_02:26]
Residential product sales for the fourth quarter of 2014 improved on a sequential basis to $194.9 million from $183.7 million in the third quarter of 2014, primarily driven by a solid increase in home standby generators. Residential product sales declined slightly on a year-over-year basis from $199.1 million for the fourth quarter of 2013, which was a strong prior-year comparison that still benefited from the afterglow period of demand from the one-year anniversary of Superstorm Sandy. Also, the fourth quarter of 2014 continued to experience a power outage severity environment that remained well below normalized levels. These factors resulted in a modest year-over-year decline in both home standby and portable generator sales.

[0001437749-15-002323:8k_2_02:27]
C&I product sales for the fourth quarter of 2014 increased 17.1% to $185.0 million as compared to $157.9 million for the comparable period in 2013. The improvement was driven primarily by strength in oil & gas shipments and contributions from recent acquisitions, which was partially offset by a decline in telecom shipments resulting from reduced capital spending by certain customers.

[0001437749-15-002323:8k_2_02:28]
Gross margin for the fourth quarter of 2014 was 34.3% compared to 38.7% in the prior-year fourth quarter. The decline was driven by the combination of a higher mix of organic C&I product shipments, the impact from recent acquisitions, and a temporary increase in certain costs associated with the slowdown of activity in west coast ports as well as other overhead-related costs.

[0001437749-15-002323:8k_2_02:29]
Operating expenses for the fourth quarter of 2014 increased $4.8 million, or 8.9%, as compared to the fourth quarter of 2013. The increase was driven by the addition of recurring operating expenses associated with recent acquisitions, a more favorable adjustment to warranty reserves in the fourth quarter of 2013 as compared to the current year, and increased marketing and advertising expenses.

[0001437749-15-002323:8k_2_02:30]
2015 Outlook

[0001437749-15-002323:8k_2_02:31]
The Company is initiating guidance for 2015 with net sales expected to increase in the low-to-mid-single digit range as compared to the prior year. This top-line guidance assumes no material changes in the current macroeconomic environment and no major power outage events during 2015, but does assume a more normalized baseline level of power outage severity during the year. Adjusted EBITDA margins are expected to be approximately 23.5% to 24.0%, an improvement compared to 23.1% for 2014. Free cash flow generation is expected to remain strong in 2015 and grow from prior-year levels due to an attractive margin profile, low-cost of debt, favorable tax attributes and capital-efficient operating model.

[0001437749-15-002323:8k_2_02:32]
“We remain excited about the numerous secular growth opportunities for our products, including the substantial penetration opportunity that exists for residential and light commercial standby generators,” continued Mr. Jagdfeld. “While the near-term outlook in certain end-market verticals such as telecommunications and oil & gas point to softer demand, we are optimistic about the long-term need for our products used in these applications, as well as the opportunity to increase our share of the C&I market through our recently expanded product offering. In addition, we believe the overall secular shifts in the market toward natural gas generators and the rental of mobile power equipment remain in place. With our strong liquidity, we are confident in our ability to continue to invest in the future growth of the business, both organically and through acquisitions, while also further executing our diversification and international expansion strategies.”

[0001437749-15-002323:8k_2_02:33]
Conference Call and Webcaset

[0001437749-15-002323:8k_2_02:34]
Generac management will hold a conference call at 9:00 a.m. EST on Wednesday, February 11, 2015 to discuss highlights of the fourth quarter operating results. The conference call can be accessed by dialing (866) 515-2909 (domestic) or +1 (617) 399-5123 (international) and entering passcode 90373911.

[0001437749-15-002323:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-15-002323:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's web site. A telephonic replay will also be available approximately one hour after the call and can be accessed by dialing (888) 286-8010 (domestic) or +1 (617) 801-6888 (international) and entering passcode 42323330. The telephonic replay will be available for 30 days.

[0001437749-15-002323:8k_2_02:37]
About Generac

[0001437749-15-002323:8k_2_02:38]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-002323:8k_2_02:39]
Forward-looking Information

[0001437749-15-002323:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-15-002323:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-15-002323:8k_2_02:42]
|  | ● | demand for Generac products; |

[0001437749-15-002323:8k_2_02:43]
|  | ● | frequency and duration of power outages; |

[0001437749-15-002323:8k_2_02:44]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-15-002323:8k_2_02:45]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-15-002323:8k_2_02:46]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-15-002323:8k_2_02:47]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-15-002323:8k_2_02:48]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-15-002323:8k_2_02:49]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-15-002323:8k_2_02:50]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-15-002323:8k_2_02:51]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-15-002323:8k_2_02:52]
|  | ● | loss of key management and employees; |

[0001437749-15-002323:8k_2_02:53]
|  | ● | increase in product and other liability claims; and |

[0001437749-15-002323:8k_2_02:54]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-15-002323:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2013 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-002323:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-15-002323:8k_2_02:57]
Reconciliations to GAAP Financial Metrics

[0001437749-15-002323:8k_2_02:58]
Adjusted EBITDA

[0001437749-15-002323:8k_2_02:59]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's Amended and Restated Credit Agreement, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-15-002323:8k_2_02:60]
Adjusted Net Income

[0001437749-15-002323:8k_2_02:61]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, and certain other non-cash gains and losses.

[0001437749-15-002323:8k_2_02:62]
Free Cash Flow

[0001437749-15-002323:8k_2_02:63]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-15-002323:8k_2_02:64]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-15-002323:8k_2_02:65]
SOURCE: Generac Holdings Inc.

[0001437749-15-002323:8k_2_02:66]
CONTACT:

[0001437749-15-002323:8k_2_02:67]
Michael W. Harris

[0001437749-15-002323:8k_2_02:68]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-15-002323:8k_2_02:69]
Michael.Harris@Generac.com

[0001437749-15-002323:8k_2_02:70]
Generac Holdings Inc.

[0001437749-15-002323:8k_2_02:71]
Consolidated Statements of Comprehensive Income

[0001437749-15-002323:8k_2_02:72]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-002323:8k_2_02:73]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Audited) |  |
| Net sales |  | $ | 403,997 |  |  | $ | 376,236 |  |  | $ | 1,460,919 |  |  | $ | 1,485,765 |  |
| Costs of goods sold |  |  | 265,587 |  |  |  | 230,554 |  |  |  | 944,700 |  |  |  | 916,205 |  |
| Gross profit |  |  | 138,410 |  |  |  | 145,682 |  |  |  | 516,219 |  |  |  | 569,560 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 30,363 |  |  |  | 24,467 |  |  |  | 120,408 |  |  |  | 107,515 |  |
| Research and development |  |  | 7,914 |  |  |  | 8,379 |  |  |  | 31,494 |  |  |  | 29,271 |  |
| General and administrative |  |  | 15,715 |  |  |  | 15,332 |  |  |  | 54,795 |  |  |  | 55,490 |  |
| Amortization of intangibles |  |  | 5,303 |  |  |  | 6,286 |  |  |  | 21,024 |  |  |  | 25,819 |  |
| Gain on remeasurement of contingent consideration |  | – |  |  | – |  |  |  | (4,877 | ) |  | – |  |
| Total operating expenses |  |  | 59,295 |  |  |  | 54,464 |  |  |  | 222,844 |  |  |  | 218,095 |  |
| Income from operations |  |  | 79,115 |  |  |  | 91,218 |  |  |  | 293,375 |  |  |  | 351,465 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,804 | ) |  |  | (12,003 | ) |  |  | (47,215 | ) |  |  | (54,435 | ) |
| Loss on extinguishment of debt |  |  | (248 | ) |  | – |  |  |  | (2,084 | ) |  |  | (15,336 | ) |
| Investment income |  |  | 11 |  |  |  | 26 |  |  |  | 130 |  |  |  | 91 |  |
| Gain on change in contractual interest rate |  | – |  |  | – |  |  |  | 16,014 |  |  | – |  |
| Costs related to acquisition |  | – |  |  |  | (27 | ) |  |  | (396 | ) |  |  | (1,086 | ) |
| Other, net |  |  | (220 | ) |  |  | (756 | ) |  |  | (1,462 | ) |  |  | (1,983 | ) |
| Total other expense, net |  |  | (12,261 | ) |  |  | (12,760 | ) |  |  | (35,013 | ) |  |  | (72,749 | ) |
| Income before provision for income taxes |  |  | 66,854 |  |  |  | 78,458 |  |  |  | 258,362 |  |  |  | 278,716 |  |
| Provision for income taxes |  |  | 17,464 |  |  |  | 29,940 |  |  |  | 83,749 |  |  |  | 104,177 |  |
| Net income |  | $ | 49,390 |  |  | $ | 48,518 |  |  | $ | 174,613 |  |  | $ | 174,539 |  |
| Net income per common share - basic: |  | $ | 0.72 |  |  | $ | 0.71 |  |  | $ | 2.55 |  |  | $ | 2.56 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,598,310 |  |  |  | 68,203,811 |  |  |  | 68,538,248 |  |  |  | 68,081,632 |  |
| Net income per common share - diluted: |  | $ | 0.70 |  |  | $ | 0.69 |  |  | $ | 2.49 |  |  | $ | 2.51 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,170,300 |  |  |  | 69,918,699 |  |  |  | 70,171,044 |  |  |  | 69,667,529 |  |
| Dividends declared per share |  | $ – |  |  | $ – |  |  | $ | - |  |  | $ | 5.00 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of unrealized loss on interest rate swaps |  | $ – |  |  | $ – |  |  | $ – |  |  | $ | 2,381 |  |
| Foreign currency translation adjustment |  |  | (1,052 | ) |  |  | 352 |  |  |  | (3,082 | ) |  |  | 1,238 |  |
| Net unrealized gain (loss) on derivatives |  |  | (701 | ) |  |  | 774 |  |  |  | (1,420 | ) |  |  | 774 |  |
| Pension liability adjustment |  |  | (8,850 | ) |  |  | 7,688 |  |  |  | (8,850 | ) |  |  | 7,688 |  |
| Other comprehensive income (loss) |  |  | (10,603 | ) |  |  | 8,814 |  |  |  | (13,352 | ) |  |  | 12,081 |  |
| Comprehensive income |  | $ | 38,787 |  |  | $ | 57,332 |  |  | $ | 161,261 |  |  | $ | 186,620 |  |

[0001437749-15-002323:8k_2_02:74]
5

[0001437749-15-002323:8k_2_02:75]
Generac Holdings Inc.

[0001437749-15-002323:8k_2_02:76]
Consolidated Balance Sheets

[0001437749-15-002323:8k_2_02:77]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-002323:8k_2_02:78]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 189,761 |  |  | $ | 150,147 |  |
| Restricted cash |  | – |  |  |  | 6,645 |  |
| Accounts receivable, less allowance for doubtful accounts of $2,275 at December 31, 2014 and $2,658 at December 31, 2013 |  |  | 189,107 |  |  |  | 164,907 |  |
| Inventories |  |  | 319,385 |  |  |  | 300,253 |  |
| Deferred income taxes |  |  | 22,841 |  |  |  | 26,869 |  |
| Prepaid expenses and other assets |  |  | 9,384 |  |  |  | 5,358 |  |
| Total current assets |  |  | 730,478 |  |  |  | 654,179 |  |
| Property and equipment, net |  |  | 168,821 |  |  |  | 146,390 |  |
| Customer lists, net |  |  | 41,002 |  |  |  | 42,764 |  |
| Patents, net |  |  | 56,894 |  |  |  | 62,418 |  |
| Other intangible assets, net |  |  | 4,298 |  |  |  | 4,447 |  |
| Deferred financing costs, net |  |  | 16,243 |  |  |  | 20,051 |  |
| Trade names, net |  |  | 182,684 |  |  |  | 173,196 |  |
| Goodwill |  |  | 635,565 |  |  |  | 608,287 |  |
| Deferred income taxes |  |  | 56,310 |  |  |  | 85,104 |  |
| Other assets |  |  | 48 |  |  |  | 1,369 |  |
| Total assets |  | $ | 1,892,343 |  |  | $ | 1,798,205 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 5,359 |  |  | $ | 9,575 |  |
| Accounts payable |  |  | 132,248 |  |  |  | 109,238 |  |
| Accrued wages and employee benefits |  |  | 17,544 |  |  |  | 26,564 |  |
| Other accrued liabilities |  |  | 84,814 |  |  |  | 92,997 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 557 |  |  |  | 12,471 |  |
| Total current liabilities |  |  | 240,522 |  |  |  | 250,845 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,082,101 |  |  |  | 1,175,349 |  |
| Other long-term liabilities |  |  | 79,921 |  |  |  | 54,940 |  |
| Total liabilities |  |  | 1,402,544 |  |  |  | 1,481,134 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,122,271 and 68,767,367 shares issued at December 31, 2014 and 2013, respectively |  |  | 691 |  |  |  | 688 |  |
| Additional paid-in capital |  |  | 434,906 |  |  |  | 421,672 |  |
| Treasury stock, at cost, 198,312 and 163,458 shares at December 31, 2014 and 2013, respectively |  |  | (8,341 | ) |  |  | (6,571 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 280,426 |  |  |  | 105,813 |  |
| Accumulated other comprehensive loss |  |  | (15,767 | ) |  |  | (2,415 | ) |
| Total stockholders’ equity |  |  | 489,799 |  |  |  | 317,071 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,892,343 |  |  | $ | 1,798,205 |  |

[0001437749-15-002323:8k_2_02:79]
Generac Holdings Inc.

[0001437749-15-002323:8k_2_02:80]
Consolidated Statements of Cash Flows

[0001437749-15-002323:8k_2_02:81]
(Dollars in Thousands)

[0001437749-15-002323:8k_2_02:82]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 174,613 |  |  | $ | 174,539 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 13,706 |  |  |  | 10,955 |  |
| Amortization of intangible assets |  |  | 21,024 |  |  |  | 25,819 |  |
| Amortization of original issue discount |  |  | 3,599 |  |  |  | 2,074 |  |
| Amortization of deferred financing costs |  |  | 3,016 |  |  |  | 2,698 |  |
| Amortization of unrealized loss on interest rate swaps |  | – |  |  |  | 2,381 |  |
| Loss on extinguishment of debt |  |  | 2,084 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate |  |  | (16,014 | ) |  | – |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  | – |  |
| Provision for losses on accounts receivable |  |  | 672 |  |  |  | 1,037 |  |
| Deferred income taxes |  |  | 37,878 |  |  |  | 82,675 |  |
| Loss on disposal of property and equipment |  |  | 576 |  |  |  | 370 |  |
| Share-based compensation expense |  |  | 12,612 |  |  |  | 12,368 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (2,988 | ) |  |  | (5,257 | ) |
| Inventories |  |  | 3,508 |  |  |  | (52,488 | ) |
| Other assets |  |  | (5,960 | ) |  |  | (10,902 | ) |
| Accounts payable |  |  | 15,269 |  |  |  | (5,847 | ) |
| Accrued wages and employee benefits |  |  | (9,405 | ) |  |  | 6,248 |  |
| Other accrued liabilities |  |  | 14,645 |  |  |  | 9,491 |  |
| Excess tax benefits from equity awards |  |  | (10,972 | ) |  |  | (11,553 | ) |
| Net cash provided by operating activities |  |  | 252,986 |  |  |  | 259,944 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 394 |  |  |  | 80 |  |
| Expenditures for property and equipment |  |  | (34,689 | ) |  |  | (30,770 | ) |
| Proceeds from sale of business, net |  | – |  |  |  | 2,254 |  |
| Acquisition of business, net of cash acquired |  |  | (61,196 | ) |  |  | (116,113 | ) |
| Net cash used in investing activities |  |  | (95,491 | ) |  |  | (144,549 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 6,550 |  |  |  | 16,007 |  |
| Proceeds from long-term borrowings |  | – |  |  |  | 1,200,000 |  |
| Repayments of short-term borrowings |  |  | (26,444 | ) |  |  | (18,982 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (94,035 | ) |  |  | (901,184 | ) |
| Payment of debt issuance costs |  |  | (4 | ) |  |  | (22,376 | ) |
| Cash dividends paid |  |  | (902 | ) |  |  | (343,429 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,181 | ) |  |  | (15,020 | ) |
| Excess tax benefits from equity awards |  |  | 10,972 |  |  |  | 11,553 |  |
| Proceeds from exercise of stock options |  |  | 21 |  |  |  | 32 |  |
| Net cash used in financing activities |  |  | (116,023 | ) |  |  | (73,399 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,858 | ) |  |  | 128 |  |
| Net increase in cash and cash equivalents |  |  | 39,614 |  |  |  | 42,124 |  |
| Cash and cash equivalents at beginning of period |  |  | 150,147 |  |  |  | 108,023 |  |
| Cash and cash equivalents at end of period |  | $ | 189,761 |  |  | $ | 150,147 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 42,592 |  |  | $ | 55,828 |  |
| Income taxes |  |  | 34,283 |  |  |  | 25,821 |  |

[0001437749-15-002323:8k_2_02:83]
7

[0001437749-15-002323:8k_2_02:84]
Generac Holdings, Inc.

[0001437749-15-002323:8k_2_02:85]
Reconciliation Schedules

[0001437749-15-002323:8k_2_02:86]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-002323:8k_2_02:87]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income |  | $ | 49,390 |  |  | $ | 48,518 |  |  | $ | 174,613 |  |  | $ | 174,539 |  |
| Interest expense |  |  | 11,804 |  |  |  | 12,003 |  |  |  | 47,215 |  |  |  | 54,435 |  |
| Depreciation and amortization |  |  | 8,985 |  |  |  | 9,272 |  |  |  | 34,730 |  |  |  | 36,774 |  |
| Income taxes provision |  |  | 17,464 |  |  |  | 29,940 |  |  |  | 83,749 |  |  |  | 104,177 |  |
| Non-cash write-down and other charges (1) |  |  | 800 |  |  |  | 43 |  |  |  | (3,853 | ) |  |  | 78 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,209 |  |  |  | 2,897 |  |  |  | 12,612 |  |  |  | 12,368 |  |
| Loss on extinguishment of debt (3) |  |  | 248 |  |  | – |  |  |  | 2,084 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (4) |  | – |  |  | – |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | 261 |  |  |  | 835 |  |  |  | 1,851 |  |  |  | 3,863 |  |
| Other |  |  | 32 |  |  |  | 139 |  |  |  | 296 |  |  |  | 1,043 |  |
| Adjusted EBITDA |  | $ | 92,193 |  |  | $ | 103,647 |  |  | $ | 337,283 |  |  | $ | 402,613 |  |

[0001437749-15-002323:8k_2_02:88]
| (1) Includes losses (gains) on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. Additionally, the year ended December 31, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Includes share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) For the year ended December 31, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three months and year ended December 31, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (4) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-15-002323:8k_2_02:89]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income |  | $ | 49,390 |  |  | $ | 48,518 |  |  | $ | 174,613 |  |  | $ | 174,539 |  |
| Provision for income taxes |  |  | 17,464 |  |  |  | 29,940 |  |  |  | 83,749 |  |  |  | 104,177 |  |
| Income before provision for income taxes |  |  | 66,854 |  |  |  | 78,458 |  |  |  | 258,362 |  |  |  | 278,716 |  |
| Amortization of intangible assets |  |  | 5,303 |  |  |  | 6,286 |  |  |  | 21,024 |  |  |  | 25,819 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,770 |  |  |  | 1,225 |  |  |  | 6,615 |  |  |  | 4,772 |  |
| Loss on extinguishment of debt (6) |  |  | 248 |  |  | – |  |  |  | 2,084 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (7) |  | – |  |  | – |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 511 |  |  |  | 688 |  |  |  | (3,623 | ) |  |  | 2,842 |  |
| Adjusted net income before provision for income taxes |  |  | 74,686 |  |  |  | 86,657 |  |  |  | 268,448 |  |  |  | 327,485 |  |
| Cash income tax expense (9) |  |  | (6,253 | ) |  |  | (9,141 | ) |  |  | (34,283 | ) |  |  | (25,821 | ) |
| Adjusted net income |  | $ | 68,433 |  |  | $ | 77,516 |  |  | $ | 234,165 |  |  | $ | 301,664 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.98 |  |  | $ | 1.11 |  |  | $ | 3.34 |  |  | $ | 4.33 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,170,300 |  |  |  | 69,918,699 |  |  |  | 70,171,044 |  |  |  | 69,667,529 |  |

[0001437749-15-002323:8k_2_02:90]
| (6) For the year ended December 31, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three months and year ended December 31, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (7) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. The year ended December 31, 2014 also includes certain purchase accounting adjustments and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). |
| (9) Amounts for the twelve months ended December 31, 2014 and 2013 are based on actual cash income taxes paid during the full year ended 2014 and 2013, respectively, which equates to a cash income tax rate of 13.3% and 9.3%, respectively, for each year. |

[0001437749-15-002323:8k_2_02:91]
9

[0001437749-15-002323:8k_2_02:92]
Free Cash Flow Reconciliation

[0001437749-15-002323:8k_2_02:93]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 110,475 |  |  | $ | 104,731 |  |  | $ | 252,986 |  |  | $ | 259,944 |  |
| Expenditures for property and equipment |  |  | (11,967 | ) |  |  | (16,513 | ) |  |  | (34,689 | ) |  |  | (30,770 | ) |
| Free Cash Flow |  | $ | 98,508 |  |  | $ | 88,218 |  |  | $ | 218,297 |  |  | $ | 229,174 |  |

[0001437749-15-002323:8k_2_02:94]
Net Debt to Adjusted EBITDA Ratio

[0001437749-15-002323:8k_2_02:95]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  |  |  |  |  |  |  |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 5,359 |  |  | $ | 9,575 |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 557 |  |  |  | 12,471 |  |  |  |  |  |  |  |  |  |
| Long-term borrowings and capital lease obligations |  |  | 1,082,101 |  |  |  | 1,175,349 |  |  |  |  |  |  |  |  |  |
| Less: Cash |  |  | (189,761 | ) |  |  | (150,147 | ) |  |  |  |  |  |  |  |  |
| Net debt |  |  | 898,256 |  |  |  | 1,047,248 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA |  |  | 337,283 |  |  |  | 402,613 |  |  |  |  |  |  |  |  |  |
| Net debt to adjusted EBITDA ratio |  |  | 2.7 |  |  |  | 2.6 |  |  |  |  |  |  |  |  |  |

[0001437749-15-002323:8k_2_02:96]
10
