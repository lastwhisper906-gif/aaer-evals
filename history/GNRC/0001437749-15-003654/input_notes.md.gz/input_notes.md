# GNRC notes — 0001437749-15-003654


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-15-003654:notes:1]
| 1. | Description of Business |

[0001437749-15-003654:notes:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Subsidiary and the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-003654:notes:3]
Over the past several years, we have executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

[0001437749-15-003654:notes:4]
|  | ● | On October 3, 2011, we acquired substantially all the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for us as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |
|  | ● | On December 8, 2012, we acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |
|  | ● | On August 1, 2013, we acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |
|  | ● | On November 1, 2013, we purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW. |
|  | ● | On September 2, 2014, we acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |
|  | ● | On October 1, 2014, we acquired MAC, Inc. and its related entities (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-15-003654:notes:5]
2. Significant Accounting Policies

[0001437749-15-003654:notes:6]
Principles of Consolidation

[0001437749-15-003654:notes:7]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-15-003654:notes:8]
Cash and Cash Equivalents

[0001437749-15-003654:notes:9]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-15-003654:notes:10]
Restricted Cash

[0001437749-15-003654:notes:11]
Restricted cash represents cash transferred to an escrow account for the settlement of certain earn-out obligations associated with the Tower Light acquisition. See Note 3, “Acquisitions,” to the consolidated financial statements for additional details.

[0001437749-15-003654:notes:12]
Concentration of Credit Risk

[0001437749-15-003654:notes:13]
The Company maintains the majority of its cash in one commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-15-003654:notes:14]
One customer accounted for approximately 9% and 11% of accounts receivable at December 31, 2014 and 2013, respectively. No one customer accounted for greater than 8%, 6% and 7%, of net sales during the years ended December 31, 2014, 2013, or 2012, respectively.

[0001437749-15-003654:notes:15]
Accounts Receivable

[0001437749-15-003654:notes:16]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis.

[0001437749-15-003654:notes:17]
Inventories

[0001437749-15-003654:notes:18]
Inventories are stated at the lower of cost or market, with cost determined generally using the first-in, first-out method.

[0001437749-15-003654:notes:19]
Property and Equipment

[0001437749-15-003654:notes:20]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements.

[0001437749-15-003654:notes:21]
| Land improvements | 10 - 15 |
| Buildings and improvements | 10 - 40 |
| Leasehold improvements | 7 - 20 |
| Machinery and equipment | 5 - 20 |
| Dies and tools | 3 - 10 |
| Vehicles | 3 - 5 |
| Office equipment | 3 - 10 |

[0001437749-15-003654:notes:22]
Debt Issuance Costs

[0001437749-15-003654:notes:23]
Direct and incremental costs incurred in connection with the issuance of long-term debt are capitalized and amortized to interest expense over the terms of the related credit agreements. Debt discounts incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the catch-up approach of the effective interest method over the terms of the related credit agreements. Approximately $6,615, $4,772, and $3,759 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2014, 2013 and 2012, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization expense for the next five years is as follows: 2015, $7,012; 2016, $7,302; 2017, $7,550;
      2018, $7,505; 2019, $7,534.

[0001437749-15-003654:notes:24]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-15-003654:notes:25]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually on October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value may not be recoverable. The Company has the option to assess goodwill for impairment by first performing a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then further goodwill impairment testing is not required to be performed. If the Company
      determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform a two-step goodwill impairment test. In the first step, the fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired and no further analysis is necessary. If the fair value of the reporting unit is less than its book value, there is an indication of potential impairment and a second step is performed. When required, the second step of testing involves calculating the implied fair value of goodwill for the reporting unit. The implied fair value of goodwill is determined in the same manner as goodwill recognized in a business combination, which is the excess of the fair value of the reporting unit determined in step one over the fair value of its net assets and identifiable intangible assets as if
      the reporting unit had been acquired. If the carrying value of the reporting unit's goodwill exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. For reporting units with a negative book value (i.e., excess of liabilities over assets), qualitative factors are evaluated to determine whether it is necessary to perform the second step of the goodwill impairment test.

[0001437749-15-003654:notes:26]
Other indefinite-lived intangible assets consist of trade names. The Company tests the carrying value of these trade names by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the trade name is the discounted cash flows of the amount that would be paid had the Company not owned the trade name and instead licensed the trade name from another company. The Company conducts its annual impairment test for indefinite-lived intangible assets on October 31 of each year.

[0001437749-15-003654:notes:27]
The Company performed the required annual impairment tests for fiscal years 2014, 2013 and 2012 and found no impairment of goodwill or indefinite-lived trade names. There can be no assurance that future impairment tests will not result in a charge to earnings.

[0001437749-15-003654:notes:28]
Impairment of Long-Lived Assets

[0001437749-15-003654:notes:29]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and trade names). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset. Such analyses necessarily involve significant judgments.

[0001437749-15-003654:notes:30]
Income Taxes

[0001437749-15-003654:notes:31]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become
      deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income, and tax planning strategies, as appropriate, in making this assessment.

[0001437749-15-003654:notes:32]
Revenue Recognition

[0001437749-15-003654:notes:33]
Sales, net of estimated returns and allowances, are recognized upon shipment of product to the customer, which is generally when title passes, the Company has no further obligations, and the customer is required to pay. The Company, at the request of certain customers, will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customers take possession of the product. In these cases, the funds collected on product warehoused for these customers are recorded as a customer advance until the customer takes possession of the product and the Company’s obligation to deliver the goods is completed. Customer advances are included in accrued liabilities in the consolidated balance sheets.

[0001437749-15-003654:notes:34]
The Company provides for certain estimated sales promotions, discounts and incentive expenses which are recognized as a reduction of sales.

[0001437749-15-003654:notes:35]
Shipping and Handling Costs

[0001437749-15-003654:notes:36]
Shipping and handling costs billed to customers are included in net sales, and the related costs are included in cost of goods sold in the consolidated statements of comprehensive income.

[0001437749-15-003654:notes:37]
Advertising and Co-Op Advertising

[0001437749-15-003654:notes:38]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Total expenditures for advertising were $32,352, $19,910, and $13,360 for the years ended December 31, 2014, 2013, and 2012, respectively.

[0001437749-15-003654:notes:39]
Research and Development

[0001437749-15-003654:notes:40]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $31,494, $29,271, and $23,499 for the years ended December 31, 2014, 2013 and 2012, respectively.

[0001437749-15-003654:notes:41]
Foreign Currency Translation and Transactions

[0001437749-15-003654:notes:42]
Balance sheet amounts for non-U.S. Dollar functional currency businesses are translated into dollars at the rates of exchange in effect at fiscal year-end. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-15-003654:notes:43]
Fair Value of Financial Instruments

[0001437749-15-003654:notes:44]
The Financial Accounting Standards Board (FASB) Accounting Standards Update (ASC) 820-10, Fair Value Measurement, among other things, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as
      follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-15-003654:notes:45]
Assets and liabilities measured at fair value are based on the market approach, which are prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001437749-15-003654:notes:46]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued liabilities and short-term borrowings), excluding long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $1,080,599 was approximately $1,048,165 (Level 2) at December 31, 2014, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-15-003654:notes:47]
Use of Estimates

[0001437749-15-003654:notes:48]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-15-003654:notes:49]
Derivative Instruments and Hedging Activities

[0001437749-15-003654:notes:50]
The Company records derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies, and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-15-003654:notes:51]
Stock-Based Compensation

[0001437749-15-003654:notes:52]
Stock-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant.

[0001437749-15-003654:notes:53]
New Accounting Pronouncements

[0001437749-15-003654:notes:54]
In May 2014, the FASB issued ASU No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. The guidance is effective for the Company in 2017. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the
      standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-15-003654:notes:55]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-15-003654:notes:56]
3. Acquisitions

[0001437749-15-003654:notes:57]
Acquisition of MAC

[0001437749-15-003654:notes:58]
On October 1, 2014, a subsidiary of the Company acquired MAC for a purchase price, net of cash acquired of $55,690.  Headquartered in Bismarck, North Dakota, MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. This acquisition was funded solely by existing cash.

[0001437749-15-003654:notes:59]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2014 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $49,378 of intangible assets, including approximately $25,898 of goodwill, as of the acquisition date. The accompanying consolidated financial statements include the results of MAC from October 1, 2014 through December 31, 2014. The goodwill ascribed to this acquisition is not deductible for tax purposes.

[0001437749-15-003654:notes:60]
Acquisition of Tower Light

[0001437749-15-003654:notes:61]
On August 1, 2013, a subsidiary of the Company acquired all of the shares of Tower Light for a purchase price, net of cash acquired and inclusive of estimated earn-out payments, of $85,812. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. Tower Light has built a leading market position in the equipment rental markets by leveraging its broad product offering and strong global distribution network in over 50 countries worldwide.

[0001437749-15-003654:notes:62]
The net cash paid at closing was $80,239 and included a cash deposit of $6,645 into an escrow account to fund future earn-out payments required by the purchase agreement, which was recorded as restricted cash on the Company’s consolidated balance sheet as of December 31, 2013. The earn-out payment of $7,641 was finalized during the second quarter of 2014, resulting in a gain of $4,877, which was recorded in the consolidated statement of comprehensive income for the year ended December 31, 2014. The difference between the total escrow deposit and the Company’s final earn-out payment is reflected as an addition to the purchase price. Additionally, the cash paid at closing included an estimate of acquired working capital. This estimate was finalized during third quarter of 2013, resulting in a $300 decrease to the
      purchase price. The acquisition was funded solely by existing cash.

[0001437749-15-003654:notes:63]
The Company recorded a preliminary purchase price allocation during the third quarter of 2013 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $67,900 of intangible assets, including approximately $38,400 of goodwill. Based on revised purchase accounting estimates, an additional $9,328 of goodwill was recorded during the fourth quarter of 2013. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Tower Light from August 1, 2013 through December 31, 2014.

[0001437749-15-003654:notes:64]
Acquisition of Ottomotores

[0001437749-15-003654:notes:65]
On December 8, 2012, a subsidiary of the Company acquired all of the shares of Ottomotores. Ottomotores was founded in 1950 and is located in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets ranging in size from 15kW to 3,250kW and is a market participant throughout all of Latin America.

[0001437749-15-003654:notes:66]
The cash paid at closing of $44,769, net of cash acquired, included an estimate of acquired working capital. This estimate was finalized during the second quarter of 2013 to reflect actual working capital acquired as well as cash acquired and debt assumed, resulting in a $6,278 decrease to the purchase price. This acquisition was funded solely by existing cash.

[0001437749-15-003654:notes:67]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2012 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $16,100 of intangible assets, including approximately $5,050 of goodwill, as of the acquisition date. The purchase price allocation was finalized during the second quarter of 2013, resulting in an additional $2,590 of intangible assets and a $439 decrease to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes.

[0001437749-15-003654:notes:68]
Management considers these acquisitions to be immaterial for full required disclosure.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-15-003654:notes:69]
4. Derivative Instruments and Hedging Activities

[0001437749-15-003654:notes:70]
Commodities

[0001437749-15-003654:notes:71]
The primary objectives of the commodity risk management activities are to understand and mitigate the impact of potential price fluctuations on the Company’s financial results and its economic well-being. While the Company’s risk management objectives and strategies will be driven from an economic perspective, the Company attempts, where possible and practical, to ensure that the hedging strategies it engages in can be treated as “hedges” from an accounting perspective or otherwise result in accounting treatment where the earnings effect of the hedging instrument provides substantial offset (in the same period) to the earnings effect of the hedged item. Generally, these risk management transactions will involve the use of commodity derivatives to protect against exposure resulting from significant price fluctuations.

[0001437749-15-003654:notes:72]
The Company primarily utilizes commodity contracts with maturities of less than eighteen months. These are intended to offset the effect of price fluctuations on actual inventory purchases. Outstanding commodity forward contracts in place to hedge the Company’s projected commodity purchases were as follows:

[0001437749-15-003654:notes:73]
| As of December 31, 2014: |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | October 2, 2014 | October 1, 2014 |  | $ | 4,960 |  | December 31, 2015 |
| Copper | October 15, 2014 | November 1, 2014 |  | $ | 4,637 |  | December 31, 2015 |
| Copper | December 1, 2014 | December 1, 2014 |  | $ | 8,232 |  | December 31, 2015 |

[0001437749-15-003654:notes:74]
| As of December 31, 2013: |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | June 21, 2013 | October 1, 2013 |  | $ | 2,169 |  | June 30, 2014 |

[0001437749-15-003654:notes:75]
| As of December 31, 2012: |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | October 29, 2012 | January 1, 2013 |  | $ | 3,472 |  | September 30, 2013 |

[0001437749-15-003654:notes:76]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net gains (losses) recognized on such contracts in the consolidated statements of comprehensive income were $(629), $(605) and $386 for the years ended December 31, 2014, 2013, and 2012, respectively.

[0001437749-15-003654:notes:77]
Foreign Currencies

[0001437749-15-003654:notes:78]
The Company is exposed to foreign currency exchange risk as a result of transactions in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. There were no foreign currency hedge contracts outstanding during the year ended December 31, 2012. As of December 31, 2014 and 2013, the following foreign currency contracts were outstanding:

[0001437749-15-003654:notes:79]
| As of December 31, 2014: |  |  |  |  |
| Currency Denomination |  | Notional Amount |  |
| British Pound Sterling (GBP) to Euro |  | £ | 5,000 |  |

[0001437749-15-003654:notes:80]
| As of December 31, 2013: |  |
| Currency Denomination |  | Notional Amount |  |
| United States Dollar (USD) to Euro |  | $ | 650 |  |
| British Pound Sterling (GBP) to Euro |  | £ | 4,000 |  |

[0001437749-15-003654:notes:81]
Total net losses recognized in the consolidated statements of comprehensive income for the years ended December 31, 2014 and 2013 were $(149) and $(56), respectively.

[0001437749-15-003654:notes:82]
Interest Rate Swaps

[0001437749-15-003654:notes:83]
As of May 30, 2012, the date of a previous credit agreement refinancing, the Company had four interest rate swap agreements outstanding. Due to the incorporation of a new interest rate floor provision in the then new credit agreement, which constituted a change in critical terms, the Company concluded that as of May 30, 2012, the then outstanding swaps would no longer be highly effective in achieving offsetting changes in cash flows during the periods the hedges were designated. As a result, the Company was required to de-designate the four outstanding hedges as of May 30, 2012. Beginning May 31, 2012, the effective portion of the swaps prior to the change (i.e. amounts previously recorded in Accumulated Other Comprehensive Loss) were amortized into interest expense over the period of the originally designated hedged
      transactions which had various termination dates through October 2013. Future changes in fair value of these swaps were immediately recognized in the consolidated statements of comprehensive income as interest expense.

[0001437749-15-003654:notes:84]
On October 23, 2013, the Company entered into two interest rate swap agreements, and on May 19, 2014, the Company entered into one interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges. For derivatives that are designated and qualify as a cash flow hedge, the effective portion of the gain or loss on the derivative is reported as a component of accumulated other comprehensive loss. The cash flows of the swaps are recognized as adjustments to interest expense each period.  The ineffective portion of the derivatives’ change in fair value, if any, is immediately recognized in earnings. The Company assesses on an ongoing basis whether derivatives
      used in hedging transactions are highly effective in offsetting changes in cash flows of hedged items.  The effective dates of the swaps are July 1, 2014 with a notional amount of $100,000 each, a fixed LIBOR rate of 1.7370%, 1.7420% and 1.6195%, including a LIBOR floor of 0.75%, and all expire on July 1, 2018.

[0001437749-15-003654:notes:85]
The following table presents the fair value of the Company’s derivative assets (liabilities):

[0001437749-15-003654:notes:86]
|  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Interest rate swaps |  | $ | (1,045 | ) |  | $ | 1,236 |  |
| Commodity contracts |  |  | (515 | ) |  |  | 69 |  |
| Foreign currency contracts |  |  | (149 | ) |  |  | 56 |  |

[0001437749-15-003654:notes:87]
The fair value of the interest rate swaps, and the commodity and foreign currency contracts are included in other accrued liabilities and other assets in the consolidated balance sheets as of December 31, 2014 and 2013, respectively. Excluding the impact of credit risk, the fair value of the derivative contracts as of December 31, 2014 and 2013 is a liability of $(1,727) and an asset of $1,385, respectively, which represents the amount the Company would need to pay or would receive to exit the agreements on those dates.

[0001437749-15-003654:notes:88]
The following presents the impact of interest rate swaps, commodity contracts and foreign currency contracts on the consolidated statement of comprehensive income for the years ended December 31, 2014, 2013 and 2012:

[0001437749-15-003654:notes:89]
|  |  | Amount of Gain (Loss) Recognized in AOCI for the Year Ended December 31, |  | Location of Gain (Loss) Recognized in the Net Income (Loss) on Ineffective |  | Amount of Loss Reclassified from AOCI into Net Income for the Year Ended December 31, |  |  | Amount of Gain (Loss) Recognized in Net Income on Hedges (Ineffective Portion) for the Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  | Portion of Hedges |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Derivatives designated as hedging instruments |  |
| Interest rate swaps (1) |  | $ | (1,420 | ) |  | $ | 774 |  |  | $ | 365 |  | Interest Expense |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Derivatives not designated as hedging instruments |  |
| Interest rate swaps (2) |  | $ | - |  |  | $ | - |  |  | $ | - |  | Interest Expense |  | $ | - |  |  | $ | (2,381 | ) |  | $ | (2,082 | ) |  | $ | - |  |  | $ | 2,973 |  |  | $ | 1,695 |  |
| Commodity and foreign currency contracts |  | $ | - |  |  | $ | - |  |  | $ | - |  | Cost of goods sold |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (778 | ) |  | $ | (661 | ) |  | $ | 386 |  |

[0001437749-15-003654:notes:90]
| (1) | Amounts recorded for the year ended December 31, 2012 relate to the interest rate swap agreements outstanding prior to May 30, 2012, the date the hedging relationships for these agreements were terminated. |

[0001437749-15-003654:notes:91]
| (2) | Amounts recorded for the years ended December 31, 2013 and 2012 relate to interest rate swap agreements outstanding as of May 30, 2012, the date the hedging relationships for these agreements were terminated. |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-003654:notes:92]
5.  Fair Value Measurements

[0001437749-15-003654:notes:93]
Assets (liabilities) measured at fair value on a recurring basis are as follows:

[0001437749-15-003654:notes:94]
|  |  | Fair Value Measurement Using |  |
|  |  | Total December 31, 2014 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | (1,045 | ) |  | $ | - |  |  | $ | (1,045 | ) |
| Commodity contracts |  | $ | (515 | ) |  | $ | - |  |  | $ | (515 | ) |
| Foreign currency contracts |  | $ | (149 | ) |  | $ | - |  |  | $ | (149 | ) |

[0001437749-15-003654:notes:95]
|  |  | Fair Value Measurement Using |  |
|  |  | Total December 31, 2013 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | 1,236 |  |  | $ | - |  |  | $ | 1,236 |  |
| Commodity contracts |  | $ | 69 |  |  | $ | - |  |  | $ | 69 |  |
| Foreign currency contracts |  | $ | 56 |  |  | $ | - |  |  | $ | 56 |  |

[0001437749-15-003654:notes:96]
The valuation techniques used to measure the fair value of derivative contracts classified as Level 2, all of which have counterparties with high credit ratings, were valued based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-003654:notes:97]
6. Accumulated Other Comprehensive Loss

[0001437749-15-003654:notes:98]
The following presents a tabular disclosure of changes in accumulated other comprehensive income (loss) during the years ended December 31, 2014 and 2013, net of tax:

[0001437749-15-003654:notes:99]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance - January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (3,082 | ) |  |  | (8,922 | ) |  |  | (1,420 | ) |  |  | (13,424 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | 72 |  | (1) |  | - |  |  |  | 72 |  |
| Net current-period other comprehensive loss |  |  | (3,082 | ) |  |  | (8,850 | ) |  |  | (1,420 | ) |  |  | (13,352 | ) |
| Ending Balance - December 31, 2014 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |

[0001437749-15-003654:notes:100]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance - January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 1,238 |  |  |  | 6,994 |  |  |  | 774 |  |  |  | 9,006 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | 694 |  | (2) |  | 2,381 |  | (3) |  | 3,075 |  |
| Net current-period other comprehensive income |  |  | 1,238 |  |  |  | 7,688 |  |  |  | 3,155 |  |  |  | 12,081 |  |
| Ending Balance - December 31, 2013 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |

[0001437749-15-003654:notes:101]
|  | (1) | Represents the actuarial losses of $(106), net of tax benefit of $34, included in the computation of net periodic pension cost. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-15-003654:notes:102]
|  | (2) | Represents the actuarial losses of $(1,108), net of tax benefit of $414, included in the computation of net periodic pension cost. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-15-003654:notes:103]
|  | (3) | Represents amortization of unrealized losses on interest rate swaps to interest expense on the consolidated statements of comprehensive income of $(2,490), net of tax benefit of $109. See Note 11, “Credit Agreements,” to the consolidated financial statements for additional information. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-003654:notes:104]
7. Segment Reporting

[0001437749-15-003654:notes:105]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of power products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production and design processes, and methods of distribution. The Company’s sales in the United States represent approximately 84%, 88%, and 93% of total sales for the years ended December 31, 2014, 2013 and 2012, respectively. Approximately 91%, 90% and 94% of the Company’s identifiable long-lived assets are located in the United States as of December 31, 2014, 2013 and 2012, respectively.

[0001437749-15-003654:notes:106]
The Company's product offerings consist primarily of power products with a range of power output geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer usage. The breakout of net sales between residential, commercial & industrial, and other products is as follows:

[0001437749-15-003654:notes:107]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Residential products |  | $ | 722,206 |  |  | $ | 843,727 |  |  | $ | 705,444 |  |
| Commercial & industrial products |  |  | 652,216 |  |  |  | 569,890 |  |  |  | 410,341 |  |
| Other |  |  | 86,497 |  |  |  | 72,148 |  |  |  | 60,521 |  |
| Total |  | $ | 1,460,919 |  |  | $ | 1,485,765 |  |  | $ | 1,176,306 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-15-003654:notes:108]
8. Balance Sheet Details

[0001437749-15-003654:notes:109]
Inventories consist of the following:

[0001437749-15-003654:notes:110]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Raw material |  | $ | 184,407 |  |  | $ | 183,787 |  |
| Work-in-process |  |  | 8,798 |  |  |  | 9,620 |  |
| Finished goods |  |  | 135,567 |  |  |  | 113,404 |  |
| Reserves for excess and obsolescence |  |  | (9,387 | ) |  |  | (6,558 | ) |
| Total |  | $ | 319,385 |  |  | $ | 300,253 |  |

[0001437749-15-003654:notes:111]
As of December 31, 2014 and 2013, inventories totaling $12,497 and $6,504, respectively, were on consignment at customer locations.

[0001437749-15-003654:notes:112]
Property and equipment consists of the following:

[0001437749-15-003654:notes:113]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Land and improvements |  | $ | 7,803 |  |  | $ | 7,416 |  |
| Buildings and improvements |  |  | 102,254 |  |  |  | 96,161 |  |
| Machinery and equipment |  |  | 65,240 |  |  |  | 54,847 |  |
| Dies and tools |  |  | 16,897 |  |  |  | 17,071 |  |
| Vehicles |  |  | 1,383 |  |  |  | 1,979 |  |
| Office equipment |  |  | 21,990 |  |  |  | 17,304 |  |
| Leasehold improvements |  |  | 2,535 |  |  |  | 2,229 |  |
| Construction in progress |  |  | 20,120 |  |  |  | 9,724 |  |
| Gross property and equipment |  |  | 238,222 |  |  |  | 206,731 |  |
| Accumulated depreciation |  |  | (69,401 | ) |  |  | (60,341 | ) |
| Total |  | $ | 168,821 |  |  | $ | 146,390 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-15-003654:notes:114]
9. Goodwill and Intangible Assets

[0001437749-15-003654:notes:115]
The changes in the carrying amount of goodwill for the years ended December 31, 2014 and 2013 are as follows:

[0001437749-15-003654:notes:116]
|  |  | Year Ended December 31, 2014 |  |  | Year Ended December 31, 2013 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Balance at beginning of year |  | $ | 1,111,480 |  |  | $ | (503,193 | ) |  | $ | 608,287 |  |  | $ | 1,056,136 |  |  | $ | (503,193 | ) |  | $ | 552,943 |  |
| Acquisitions of businesses, net |  |  | 27,278 |  |  |  | - |  |  | $ | 27,278 |  |  |  | 56,605 |  |  |  | - |  |  | $ | 56,605 |  |
| Sale of business, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,261 | ) |  |  | - |  |  |  | (1,261 | ) |
| Balance at end of year |  | $ | 1,138,758 |  |  | $ | (503,193 | ) |  | $ | 635,565 |  |  | $ | 1,111,480 |  |  | $ | (503,193 | ) |  | $ | 608,287 |  |

[0001437749-15-003654:notes:117]
See Note 3, “Acquisitions,” to consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-15-003654:notes:118]
The following table summarizes intangible assets by major category as of December 31, 2014 and 2013:

[0001437749-15-003654:notes:119]
|  |  | Weighted Average |  |  | 2014 |  |  | 2013 |  |
|  |  | Amortization Years |  |  | Cost |  |  | Accumulated Impairment |  |  | Net Cost |  |  | Cost |  |  | Accumulated Impairment |  |  | Net Cost |  |
| Indefinite lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade names |  |  |  |  |  | $ | 192,073 |  |  | $ | (9,389 | ) |  | $ | 182,684 |  |  | $ | 182,585 |  |  | $ | (9,389 | ) |  | $ | 173,196 |  |

[0001437749-15-003654:notes:120]
|  |  |  |  |  |  | Cost |  |  | Accumulated Amortization |  |  | Amortized Cost |  |  | Cost |  |  | Accumulated Amortization |  |  | Amortized Cost |  |
| Finite lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade names |  |  | 0 |  |  | $ | 8,775 |  |  | $ | (8,775 | ) |  | $ | - |  |  | $ | 8,775 |  |  | $ | (8,775 | ) |  | $ | - |  |
| Customer lists |  |  | 8 |  |  |  | 304,180 |  |  |  | (263,178 | ) |  |  | 41,002 |  |  |  | 294,627 |  |  |  | (251,863 | ) |  |  | 42,764 |  |
| Patents |  |  | 15 |  |  |  | 121,341 |  |  |  | (64,447 | ) |  |  | 56,894 |  |  |  | 118,921 |  |  |  | (56,503 | ) |  |  | 62,418 |  |
| Unpatented technology |  |  | 13 |  |  |  | 13,169 |  |  |  | (10,435 | ) |  |  | 2,734 |  |  |  | 13,169 |  |  |  | (9,064 | ) |  |  | 4,105 |  |
| Software |  |  | 8 |  |  |  | 1,046 |  |  |  | (1,037 | ) |  |  | 9 |  |  |  | 1,046 |  |  |  | (912 | ) |  |  | 134 |  |
| Non-compete/other |  |  | 7 |  |  |  | 1,961 |  |  |  | (406 | ) |  |  | 1,555 |  |  |  | 345 |  |  |  | (137 | ) |  |  | 208 |  |
| Total finite lived intangible assets |  |  |  |  |  | $ | 450,472 |  |  | $ | (348,278 | ) |  | $ | 102,194 |  |  | $ | 436,883 |  |  | $ | (327,254 | ) |  | $ | 109,629 |  |

[0001437749-15-003654:notes:121]
Amortization of intangible assets was $21,024, $25,819 and $45,867 in 2014, 2013 and 2012, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2015, $20,965; 2016, $19,015; 2017, $15,624; 2018, $11,422; 2019, $9,600.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-15-003654:notes:122]
10. Product Warranty Obligations

[0001437749-15-003654:notes:123]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The Company also sells extended warranty coverage for certain product. The sales of extended warranties are recorded as deferred revenue, and we recognize the revenue from sales of extended warranties over the life of the contracts. The Company’s product warranty obligations, including deferred revenue related to extended warranty coverage, are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheets.

[0001437749-15-003654:notes:124]
The following is a tabular reconciliation of the product warranty liability, excluding the deferred revenue related to our extended warranty coverage:

[0001437749-15-003654:notes:125]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Balance at beginning of year |  | $ | 33,734 |  |  | $ | 36,111 |  |  | $ | 24,643 |  |
| Payments |  |  | (20,615 | ) |  |  | (18,484 | ) |  |  | (19,801 | ) |
| Provision for warranties issued |  |  | 22,890 |  |  |  | 33,707 |  |  |  | 34,173 |  |
| Changes in estimates for pre-existing warranties |  |  | (5,100 | ) |  |  | (17,600 | ) |  |  | (2,904 | ) |
| Balance at end of year |  | $ | 30,909 |  |  | $ | 33,734 |  |  | $ | 36,111 |  |

[0001437749-15-003654:notes:126]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-15-003654:notes:127]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Balance at beginning of year |  | $ | 23,092 |  |  | $ | 13,474 |  |  | $ | 9,737 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 7,343 |  |  |  | 11,998 |  |  |  | 5,547 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (3,242 | ) |  |  | (2,380 | ) |  |  | (1,810 | ) |
| Balance at end of year |  | $ | 27,193 |  |  | $ | 23,092 |  |  | $ | 13,474 |  |

[0001437749-15-003654:notes:128]
Product warranty obligations and warranty related deferred revenues are included in the balance sheets as follows:

[0001437749-15-003654:notes:129]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 24,143 |  |  | $ | 26,080 |  |
| Long-term portion - other long-term liabilities |  |  | 6,766 |  |  |  | 7,654 |  |
| Total |  | $ | 30,909 |  |  | $ | 33,734 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 4,519 |  |  | $ | 3,325 |  |
| Long-term portion - other long-term liabilities |  |  | 22,674 |  |  |  | 19,767 |  |
| Total |  | $ | 27,193 |  |  | $ | 23,092 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-003654:notes:130]
11. Credit Agreements

[0001437749-15-003654:notes:131]
The revolving credit facilities and credit agreements discussed below were outstanding for the periods described below. The Company refinanced this debt on February 9, 2012, amended and restated its credit agreements on May 30, 2012, and further amended and restated its credit agreements on May 31, 2013.

[0001437749-15-003654:notes:132]
Short-term borrowings are included in the balance sheets as follows:

[0001437749-15-003654:notes:133]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,359 |  |  |  | 9,575 |  |
| Total |  | $ | 5,359 |  |  | $ | 9,575 |  |

[0001437749-15-003654:notes:134]
Long-term borrowings are included in the balance sheets as follows:

[0001437749-15-003654:notes:135]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,104,000 |  |  | $ | 1,197,000 |  |
| Discount on debt |  |  | (23,861 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,059 |  |  |  | 2,529 |  |
| Other |  |  | 460 |  |  |  | 1,026 |  |
| Total |  |  | 1,082,658 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 389 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 168 |  |  |  | 185 |  |
| Total |  | $ | 1,082,101 |  |  | $ | 1,175,349 |  |

[0001437749-15-003654:notes:136]
Maturities of long-term borrowings outstanding at December 31, 2014, are as follows:

[0001437749-15-003654:notes:137]
| Year |  |  |  |  |  |
| 2015 |  | $ | 557 |  |
| 2016 |  |  | 254 |  |
| 2017 |  |  | 185 |  |
| 2018 |  |  | 191 |  |
| After 2018 |  |  | 1,105,332 |  |
| Total |  | $ | 1,106,519 |  |

[0001437749-15-003654:notes:138]
On February 9, 2012, a subsidiary of the Company entered into a credit agreement (Credit Agreement) with certain commercial banks and other lenders. The Credit Agreement provided for borrowings under a $150,000 revolving credit facility, a $325,000 tranche A term loan facility and a $250,000 tranche B term loan facility. The revolving credit facility and tranche A term loan facility were scheduled to mature in February 2017 and the tranche B term loan facility was scheduled to mature in February 2019. Proceeds received by the Company from loans made under the Credit Agreement were used for general corporate purposes and to repay in full all outstanding borrowings under the former credit agreement.

[0001437749-15-003654:notes:139]
On May 30, 2012, the Borrower amended and restated its then existing Credit Agreement by entering into a new credit agreement (Term Loan Credit Agreement) and a new revolving credit agreement (ABL Credit Agreement) with certain commercial banks and other lenders. The Term Loan Credit Agreement provided for a $900,000 term loan B credit facility and a $125,000 uncommitted incremental term loan facility (Term Loan). The ABL Credit Agreement provided for borrowings under a $150,000 senior secured ABL revolving credit facility. The Term Loan Credit Agreement was scheduled to mature in May 2018 and the ABL Credit Agreement was scheduled to mature in May 2017. Proceeds received by the Company from loans under the Term Loan Credit Agreement, together with cash on hand, were used to repay amounts outstanding under the Company’s previous Credit
      Agreement and pay a special cash dividend of $6.00 per share on the Company’s common stock (refer to Note 17, “Special Cash Dividend” to the consolidated financial statements for additional details). The interest rate on the Term Loan was based upon either a base rate plus an applicable margin of 4.00% or adjusted LIBOR rate plus an applicable margin of 5.00%, subject to a LIBOR floor of 1.25%.

[0001437749-15-003654:notes:140]
On May 31, 2013, the Borrower amended and restated its then existing Term Loan Credit Agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement) with certain commercial banks and other lenders. The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (New Term Loan) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous Term Loan Credit Agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock (refer to Note 17, “Special Cash Dividend” to the consolidated financial statements for additional details). Remaining funds from the New Term Loan
      were used for general corporate purposes and to pay related financing fees and expenses. The New Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which will be secured by a second priority lien.

[0001437749-15-003654:notes:141]
Prior to any voluntary prepayments, the New Term Loan amortized in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date of the New Term Loan on May 31, 2020. It initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the New Term Loan Credit Agreement, falls below 3.00 to 1.00 for that
      measurement period.

[0001437749-15-003654:notes:142]
As the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs during the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the consolidated balance sheets. The Borrower’s net debt leverage ratio as of December 31, 2014 continues to be below 3.00 to 1.00.

[0001437749-15-003654:notes:143]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends (but which permitted the payment of the special cash dividend described in Note 17, “Special Cash Dividend” to the consolidated financial statements). Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to
      pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

[0001437749-15-003654:notes:144]
The New Term Loan Credit Agreement contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA or bankruptcy or insolvency events or the occurrence of a change in control (defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

[0001437749-15-003654:notes:145]
Concurrent with the closing of the New Term Loan Credit Agreement on May 31, 2013, the Borrower amended its existing ABL Credit Agreement (New ABL Credit Agreement). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the ABL Credit Agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the
      Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company).

[0001437749-15-003654:notes:146]
Borrowings under the ABL facility bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) or (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of
      default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of December 31, 2014, no amounts were outstanding under the ABL Facility. As of December 31, 2014, the Company had $189,761 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

[0001437749-15-003654:notes:147]
In connection with the February 9, 2012 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $10,409 of new debt issuance costs, recorded $1,386 of fees paid to creditors as a debt discount, expensed $1,407 of transaction fees and wrote-off $2,902 of unamortized debt issuance costs relating to the former credit agreement. In connection with the May 30, 2012 refinancing, the Company capitalized $15,309 of new debt issuance costs, recorded $18,000 of fees paid to creditors as a debt discount, expensed $801 of transaction fees and wrote-off $9,198 of unamortized debt issuance costs relating to the Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the consolidated statement of comprehensive income for the year ended December 31,
      2012.

[0001437749-15-003654:notes:148]
In connection with the May 31, 2013 refinancing, the Company capitalized $21,824 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, expensed $7,100 of transaction fees and wrote-off $5,473 of unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the consolidated statement of comprehensive income for the year ended December 31, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its loans under the catch-up approach of the effective interest method.

[0001437749-15-003654:notes:149]
On February 11, 2013, the Company made an $80,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations on the Term Loan Credit Agreement. As a result, the Company wrote off $1,839 of original issue discount and capitalized debt issuance costs during the first quarter of 2013. On May 2, 2013, the Company made an additional $30,000 voluntary prepayment of existing debt with available cash on hand. As a result, the Company wrote off $924 of original issue discount and capitalized debt issuance costs during the second quarter of 2013.

[0001437749-15-003654:notes:150]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the New Term Loan of $12,000, $50,000 and $25,000, respectively, with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs during the year ended December 31, 2014 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-15-003654:notes:151]
As of December 31, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $5,359 and $9,575 respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-003654:notes:152]
12. Earnings Per Share

[0001437749-15-003654:notes:153]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, excluding unvested restricted shares. Except where the result would be anti-dilutive, dilutive earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table summarizes the basic and diluted earnings per share calculations:

[0001437749-15-003654:notes:154]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net income (numerator) |  | $ | 174,613 |  |  | $ | 174,539 |  |  | $ | 93,223 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,538,248 |  |  |  | 68,081,632 |  |  |  | 67,360,632 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,632,796 |  |  |  | 1,585,897 |  |  |  | 1,832,506 |  |
| Diluted |  |  | 70,171,044 |  |  |  | 69,667,529 |  |  |  | 69,193,138 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.55 |  |  | $ | 2.56 |  |  | $ | 1.38 |  |
| Diluted |  | $ | 2.49 |  |  | $ | 2.51 |  |  | $ | 1.35 |  |

[0001437749-15-003654:notes:155]
(1) Excludes approximately 81,600, 10,300 and 363,000 stock options and restricted stock awards for the years ended December 31, 2014, 2013 and 2012, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-003654:notes:156]
13. Income Taxes

[0001437749-15-003654:notes:157]
The Company’s provision for income taxes consists of the following:

[0001437749-15-003654:notes:158]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 38,161 |  |  | $ | 48,287 |  |  | $ | 34,170 |  |
| State |  |  | 1,645 |  |  |  | 5,648 |  |  |  | 3,854 |  |
| Foreign |  |  | 5,701 |  |  |  | 2,214 |  |  |  | 81 |  |
|  |  |  | 45,507 |  |  |  | 56,149 |  |  |  | 38,105 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 42,474 |  |  |  | 42,003 |  |  |  | 21,972 |  |
| State |  |  | (3,134 | ) |  |  | 5,523 |  |  |  | 3,048 |  |
| Foreign |  |  | (1,462 | ) |  |  | 167 |  |  |  | 25 |  |
|  |  |  | 37,878 |  |  |  | 47,693 |  |  |  | 25,045 |  |
| Change in valuation allowance |  |  | 364 |  |  |  | 335 |  |  |  | (21 | ) |
| Provision for income taxes |  | $ | 83,749 |  |  | $ | 104,177 |  |  | $ | 63,129 |  |

[0001437749-15-003654:notes:159]
The Company has been notified by the Internal Revenue Service of an income tax audit for the 2012 tax year. To date, field work has not commenced. As of December 31, 2014, due to the carryforward of net operating losses and research and development credits, the Company is open to U.S. Federal and state income tax examinations for the tax years 2006 through 2014. In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 2009 through 2014.

[0001437749-15-003654:notes:160]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-15-003654:notes:161]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  | $ | 23,624 |  |  | $ | 74,992 |  |
| Accrued expenses |  |  | 18,191 |  |  |  | 24,263 |  |
| Deferred revenue |  |  | 7,945 |  |  |  | 4,413 |  |
| Inventories |  |  | 6,306 |  |  |  | 4,483 |  |
| Pension obligations |  |  | 8,738 |  |  |  | 4,043 |  |
| Stock-based compensation |  |  | 8,628 |  |  |  | 6,609 |  |
| Operating loss and credit carryforwards |  |  | 10,047 |  |  |  | 976 |  |
| Other |  |  | 4,299 |  |  |  | 2,089 |  |
| Valuation allowance |  |  | (1,385 | ) |  |  | (1,021 | ) |
| Total deferred tax assets |  |  | 86,393 |  |  |  | 120,847 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 18,535 |  |  |  | 15,163 |  |
| Debt refinancing costs |  |  | 10,925 |  |  |  | 7,494 |  |
| Prepaid expenses |  |  | 1,032 |  |  |  | 1,183 |  |
| Total deferred tax liabilities |  |  | 30,492 |  |  |  | 23,840 |  |
| Net deferred tax assets |  | $ | 55,901 |  |  | $ | 97,007 |  |

[0001437749-15-003654:notes:162]
The net current and noncurrent components of deferred taxes included in the consolidated balance sheets are as follows:

[0001437749-15-003654:notes:163]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net current deferred tax assets |  | $ | 22,841 |  |  | $ | 26,869 |  |
| Net long-term deferred tax assets |  |  | 47,894 |  |  |  | 86,125 |  |
| Net long-term deferred tax liabilities |  |  | (13,449 | ) |  |  | (14,966 | ) |
| Valuation allowance |  |  | (1,385 | ) |  |  | (1,021 | ) |
| Net deferred tax assets |  | $ | 55,901 |  |  | $ | 97,007 |  |

[0001437749-15-003654:notes:164]
The net long-term deferred tax liabilities and valuation allowance are included in other long-term liabilities and deferred income taxes (noncurrent), respectively, in the consolidated balance sheets as of December 31, 2014 and 2013.

[0001437749-15-003654:notes:165]
Generac Brazil, acquired as part of the Ottomotores acquisition, has generated net operating losses for multiple years as part of the start-up of the business. The realizability of the deferred tax assets associated with these net operating losses is uncertain so a valuation allowance was recorded in the opening balance sheet as of December 8, 2012 as well as at December 31, 2014 and 2013.

[0001437749-15-003654:notes:166]
At December 31, 2014, the Company had state research and development credit, and state manufacturing credit carryforwards of approximately $15,610 and $2,424, respectively, which expire between 2017 and 2029.

[0001437749-15-003654:notes:167]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-15-003654:notes:168]
|  |  | December 31, |  |
|  |  | 2014 |  |
| Unrecognized tax benefit, beginning of period |  | $ | - |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 6,394 |  |
| Unrecognized tax benefit, end of period |  | $ | 6,394 |  |

[0001437749-15-003654:notes:169]
At December 31, 2013 and 2012, the Company had no reserves recorded for uncertain tax positions.

[0001437749-15-003654:notes:170]
The entire unrecognized tax benefit as of December 31, 2014, if recognized, would impact the effective tax rate.

[0001437749-15-003654:notes:171]
Interest and penalties are recorded as a component of income tax expense. As of December 31, 2014, total interest of approximately $86 and penalties of approximately $263 associated with net unrecognized tax benefits are included in the Company’s consolidated balance sheet. There were no interest or penalties related to income taxes that had been accrued or recognized as of and for the years ended December 31, 2013 and 2012.

[0001437749-15-003654:notes:172]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending December 31, 2015.

[0001437749-15-003654:notes:173]
The Company considers the earnings of certain non-U.S. subsidiaries to be indefinitely invested outside the United States on the basis of estimates that future domestic cash generation will be sufficient to meet future domestic cash needs and the Company’s specific plans for reinvestment of those subsidiary earnings. The Company has not provided for additional U.S. income taxes on approximately $9,139 of undistributed earnings of consolidated non-U.S. subsidiaries. It is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on such earnings.

[0001437749-15-003654:notes:174]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended December 31, 2014, 2013 and 2012 are as follows:

[0001437749-15-003654:notes:175]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| U.S. statutory rate |  |  | 35.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 3.1 |  |  |  | 3.7 |  |  |  | 4.1 |  |
| Valuation allowance |  |  | 0.2 |  |  |  | 0.2 |  |  |  | - |  |
| Research and development credits |  |  | (5.0 | ) |  |  | (0.6 | ) |  |  | (0.2 | ) |
| Other |  |  | (0.9 | ) |  |  | (0.9 | ) |  |  | 1.5 |  |
| Effective tax rate |  |  | 32.4 | % |  |  | 37.4 | % |  |  | 40.4 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-15-003654:notes:176]
14. Benefit Plans

[0001437749-15-003654:notes:177]
Medical and Dental Plan

[0001437749-15-003654:notes:178]
The Company maintains medical and dental benefit plans covering full-time domestic employees of the Company and their dependents. Certain plans are partially or fully self-funded plans under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $11,701, $9,500, and $8,741 for the years ended December 31, 2014, 2013, and 2012, respectively. During 2014, the Company paid premiums of $2,700 for other standard medical benefits covering certain full-time employees.

[0001437749-15-003654:notes:179]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-15-003654:notes:180]
Savings Plan

[0001437749-15-003654:notes:181]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees may defer receipt of a portion of their eligible compensation. The Company amended the 401(k) savings plans effective January 1, 2009, to add Company matching and non-elective contributions. The Company may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees. The Company may also contribute a non-elective contribution for eligible employees employed on December 31, 2008. Both Company matching contributions and non-elective contributions are subject to vesting. Forfeitures may be applied against plan expenses. The Company recognized $3,400, $3,300 and $3,000 of expense related to this plan in 2014, 2013 and 2012, respectively.

[0001437749-15-003654:notes:182]
Pension Plans

[0001437749-15-003654:notes:183]
The Company has a frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The benefits under the salaried plan are based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan are based on a unit amount at the date of termination multiplied by the participant’s years of credited service. The Company’s funding policy for the Pension Plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations.

[0001437749-15-003654:notes:184]
The Company uses a December 31 measurement date for the Pension Plans. The table that includes the accumulated benefit obligation; and reconciliation of the changes in projected benefit obligation, changes in plan assets and the funded status of the Pension Plans is as follows:

[0001437749-15-003654:notes:185]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Accumulated benefit obligation at end of period |  | $ | 68,376 |  |  | $ | 52,825 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 52,825 |  |  | $ | 59,744 |  |
| Interest cost |  |  | 2,591 |  |  |  | 2,423 |  |
| Net actuarial loss (gain) |  |  | 14,791 |  |  |  | (7,695 | ) |
| Benefits paid |  |  | (1,831 |  |  |  | (1,647 | ) |
| Projected benefit obligation at end of period |  | $ | 68,376 |  |  | $ | 52,825 |  |
| Change in plan assets |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 42,440 |  |  | $ | 36,570 |  |
| Actual return on plan assets |  |  | 3,110 |  |  |  | 6,465 |  |
| Company contributions |  |  | 1,733 |  |  |  | 1,052 |  |
| Benefits paid |  |  | (1,831 |  |  |  | (1,647 | ) |
| Fair value of plan assets at end of period |  | $ | 45,452 |  |  | $ | 42,440 |  |
| Funded status: accrued pension liability included in other long-term liabilities |  | $ | (22,924 |  |  | $ | (10,385 | ) |
| Amounts recognized in accumulated other comprehensive income |  |  |  |  |  |  |  |  |
| Net actuarial loss |  | $ | (13,243 |  |  | $ | (4,393 | ) |

[0001437749-15-003654:notes:186]
The actuarial loss for the Pension Plans that was amortized from AOCI into net periodic (benefit) cost during 2014 is $106. The amount in AOCI as of December 31, 2014 that is expected to be recognized as a component of net periodic pension expense during the next fiscal year is $1,228.

[0001437749-15-003654:notes:187]
The components of net periodic pension (benefit) cost is as follows:

[0001437749-15-003654:notes:188]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Components of net periodic pension (benefit) cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 2,591 |  |  | $ | 2,423 |  |  | $ | 2,453 |  |
| Expected return on plan assets |  |  | (2,933 | ) |  |  | (2,520 | ) |  |  | (2,398 | ) |
| Amortization of net loss |  |  | 106 |  |  |  | 1,108 |  |  |  | 909 |  |
| Net periodic pension (benefit) cost |  | $ | (236 | ) |  | $ | 1,011 |  |  | $ | 964 |  |

[0001437749-15-003654:notes:189]
Weighted-average assumptions used to determine the benefit obligations are as follows:

[0001437749-15-003654:notes:190]
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Discount rate - salaried pension plan |  |  | 3.97 | % |  |  | 4.98 | % |
| Discount rate - hourly pension plan |  |  | 3.99 | % |  |  | 5.01 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |

[0001437749-15-003654:notes:191]
|  | (1) | No compensation increase was assumed as the plans were frozen effective December 31, 2008. |

[0001437749-15-003654:notes:192]
Weighted-average assumptions used to determine net periodic pension (benefit) cost are as follows:

[0001437749-15-003654:notes:193]
|  |  | Year Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Discount rate |  |  | 5.01 | % |  |  | 4.14 | % |  |  | 4.65 | % |
| Expected long-term rate of return on plan assets |  |  | 6.88 |  |  |  | 6.95 |  |  |  | 7.57 |  |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |

[0001437749-15-003654:notes:194]
To determine the long-term rate of return assumption for plan assets, the Company studies historical markets and preserves the long-term historical relationships between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluates current market factors such as inflation and interest rates before it determines long-term capital market assumptions and reviews peer data and historical returns to check for reasonableness and appropriateness.

[0001437749-15-003654:notes:195]
The Pension Plan’s weighted-average asset allocation at December 31, 2014 and 2013, by asset category, is as follows:

[0001437749-15-003654:notes:196]
|  |  |  |  |  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Asset Category |  | Target |  |  | Dollars |  |  | % |  |  | Dollars |  |  | % |  |
| Fixed Income |  |  | 24 | % |  | $ | 7,400 |  |  |  | 16 | % |  | $ | 7,307 |  |  |  | 17 | % |
| Domestic equity |  |  | 49 | % |  |  | 24,373 |  |  |  | 54 | % |  |  | 23,903 |  |  |  | 56 | % |
| International equity |  |  | 17 | % |  |  | 8,869 |  |  |  | 19 | % |  |  | 7,424 |  |  |  | 18 | % |
| Real estate |  |  | 10 | % |  |  | 4,810 |  |  |  | 11 | % |  |  | 3,806 |  |  |  | 9 | % |
| Total |  |  | 100 | % |  | $ | 45,452 |  |  |  | 100 | % |  | $ | 42,440 |  |  |  | 100 | % |

[0001437749-15-003654:notes:197]
The fair values of the Pension Plan's assets at December 31, 2014 are as follows:

[0001437749-15-003654:notes:198]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual fund |  | $ | 42,267 |  |  | $ | 42,267 |  |  | $ | - |  |  | $ | - |  |
| Other investments |  |  | 3,185 |  |  |  | - |  |  |  | - |  |  |  | 3,185 |  |
| Total |  | $ | 45,452 |  |  | $ | 42,267 |  |  | $ | - |  |  | $ | 3,185 |  |

[0001437749-15-003654:notes:199]
The fair values of the Pension Plan's assets at December 31, 2013 are as follows:

[0001437749-15-003654:notes:200]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual fund |  | $ | 39,759 |  |  | $ | 39,759 |  |  | $ | - |  |  | $ | - |  |
| Collective trust |  |  | 2,681 |  |  |  | - |  |  |  | 2,681 |  |  |  | - |  |
| Total |  | $ | 42,440 |  |  | $ | 39,759 |  |  | $ | 2,681 |  |  | $ | - |  |

[0001437749-15-003654:notes:201]
A reconciliation of beginning and ending balances for Level 3 assets for the year ended December 31, 2014 is as follows:

[0001437749-15-003654:notes:202]
|  |  | Other Investments |  |
| Balance as of December 31, 2013 |  | $ | - |  |
| Purchases |  |  | 3,100 |  |
| Realized gains |  |  | 85 |  |
| Balance as of December 31, 2014 |  | $ | 3,185 |  |

[0001437749-15-003654:notes:203]
Mutual Funds - This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plan’s mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 1 of the fair value hierarchy.

[0001437749-15-003654:notes:204]
Other Investments - This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment. The Net Asset Value (NAV) is classified within Level 3 of the fair value hierarchy.

[0001437749-15-003654:notes:205]
Collective Trusts - This category includes public investment vehicles valued using the NAV provided by the administrator of the trust. The NAV is based on the value of the underlying assets owned by the trust, minus its liabilities, and then divided by the number of shares outstanding. The NAV of the trust is classified within Level 2 of the fair value hierarchy.

[0001437749-15-003654:notes:206]
The Company’s target allocation for equity securities and real estate is generally between 65% - 85%, with the remainder allocated primarily to bonds. The Company regularly reviews its actual asset allocation and periodically rebalances its investments to the targeted allocation when considered appropriate.

[0001437749-15-003654:notes:207]
The Company expects to make estimated contributions of $1,187 to the Pension Plans in 2015.

[0001437749-15-003654:notes:208]
The following benefit payments are expected to be paid from the Pension Plans:

[0001437749-15-003654:notes:209]
| Year |  |  |  |  |  |
| 2015 |  | $ | 1,888 |  |
| 2016 |  |  | 1,998 |  |
| 2017 |  |  | 2,185 |  |
| 2018 |  |  | 2,319 |  |
| 2019 |  |  | 2,430 |  |
| 2020 - 2024 |  |  | 14,500 |  |

[0001437749-15-003654:notes:210]
Certain of the Company’s foreign subsidiaries participate in local defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in accrued wages and employee benefits in the Company’s consolidated balance sheets and are not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-15-003654:notes:211]
15. Share Plans

[0001437749-15-003654:notes:212]
The Company adopted an equity incentive plan on February 10, 2010 in connection with its initial public offering. The plan, as amended, allows for granting of up to 9.1 million stock-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other stock-based awards, and performance-based compensation awards. Total share-based compensation expense related to the equity incentive plan was $12,612, $12,368 and $10,780 the years ended December 31, 2014, 2013 and 2012, respectively, net of estimated forfeitures, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-15-003654:notes:213]
Stock Options - Stock options granted in 2014 have an exercise price of between $42.20 per share and $59.01 per share, stock options granted in 2013 have an exercise price of between $29.81 per share and $48.36 per share, and the stock options granted in 2012 have an exercise price of between $15.94 per share and $32.05 per share. On June 21, 2013, the Company paid a special cash dividend of $5.00 per share on its common stock, and on June 29, 2012, the Company paid a special cash dividend of $6.00 per share on its common stock. In connection with these special dividends, and pursuant to the terms of the Company’s stock option plan, certain adjustments were made to stock options outstanding under the plan in order to avoid dilution of the intended benefits which would otherwise result as a consequence of the special dividend.
      As such, the strike price for all outstanding stock options as of the special dividend dates, were adjusted by the $5.00 and $6.00 special dividend amounts. There was no change to compensation expense as a result of these adjustments. Stock options issued in 2014, 2013 and 2012 vest in equal installments over four years, subject to the grantee’s continued employment or service and expire 10 years after the date of grant. Stock options issued in 2011 and 2010 vest in equal installments over five years, subject to the grantee’s continued employment or service and expire 10 years after the date of grant.

[0001437749-15-003654:notes:214]
Beginning in 2011, stock option exercises are net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 235,644, 323,427 and 667,041 in 2014, 2013 and 2012, respectively, and were based on the value of the stock on the exercise dates as determined based upon an average of the Company’s high and low stock sales price on the exercise dates. Total payments for the employees’ tax obligations to the taxing authorities were $10,411, $8,449 and $6,425 in 2014, 2013 and 2012, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. The net-share settlements had the effect of
      share repurchases by the Company as they reduced the number of shares that would have otherwise been issued.

[0001437749-15-003654:notes:215]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Since there is limited history for the Company’s stock, expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation
      expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history. The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2014, 2013 and 2012 are as follows:

[0001437749-15-003654:notes:216]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Weighted average grant date fair value |  | $ | 26.35 |  |  | $ | 16.30 |  |  | $ | 12.13 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 45 | % |  |  | 47 | % |  |  | 45 | % |
| Risk free interest rate |  |  | 1.90 | % |  |  | 1.21 | % |  |  | 1.22 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-15-003654:notes:217]
The Company periodically evaluates its forfeiture rates and updates the rates it uses in the determination of its stock-based compensation expense. The impact of the change to the forfeiture rates on non-cash compensation expense was immaterial for the years ended December 31, 2014, 2013 and 2012.

[0001437749-15-003654:notes:218]
A summary of the Company’s stock option activity and related information for the years ended December 31, 2014, 2013 and 2012 is as follows:

[0001437749-15-003654:notes:219]
|  |  | Number of Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2011 |  |  | 4,308,545 |  |  | $ | 13.36 |  |  |  | 8.2 |  |  | $ | 63,193 |  |
| Granted |  |  | 256,112 |  |  |  | 21.28 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1,113,827 | ) |  |  | 13.21 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | - |  |  |  | - |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (10,788 | ) |  |  | 20.52 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2012 |  |  | 3,440,042 |  |  |  | 8.44 |  |  |  | 9.5 |  |  | $ | 87,001 |  |
| Granted |  |  | 253,857 |  |  |  | 35.04 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (703,326 | ) |  |  | 6.05 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (1,625 | ) |  |  | 20.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (51,647 | ) |  |  | 17.02 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2013 |  |  | 2,937,301 |  |  |  | 5.74 |  |  |  | 9.5 |  |  | $ | 148,369 |  |
| Granted |  |  | 187,189 |  |  |  | 57.21 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (549,282 | ) |  |  | 3.44 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (259 | ) |  |  | 15.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (32,810 | ) |  |  | 12.68 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2014 |  |  | 2,542,139 |  |  |  | 9.94 |  |  |  | 8.5 |  |  | $ | 96,518 |  |
| Exercisable as of December 31, 2014 |  |  | 1,210,861 |  |  |  | 4.22 |  |  |  | 8.4 |  |  | $ | 52,014 |  |

[0001437749-15-003654:notes:220]
As of December 31, 2014, there was $7,794 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.4 years. Total share-based compensation cost related to the stock options for 2014, 2013 and 2012 was $8,509, $9,034 and $6,835, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-15-003654:notes:221]
Restricted Stock – For awards issued prior to 2012, restricted stock awards vest in full on the third anniversary of the date of grant, subject to the grantee’s continued employment. Restricted stock awards issued in 2012 and after, vest in equal installments over three years, subject to the grantee’s continued employment or service. Restricted stock also includes performance shares, which were awarded for the first time in 2014. The number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of revenue growth and EBITDA margin, from which grantees may earn from 0% to 200% of their target performance share award. The performance period for the 2014 awards covers the years 2014 through
      2016. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-15-003654:notes:222]
Restricted stock vesting is net-share settled such that the Company withholds shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes. In effect, the Company repurchases these shares and classifies as treasury stock, and uses the cash on behalf of the employees to satisfy the tax withholding requirements. Total shares withheld were approximately 34,854, 163,458 and zero in 2014, 2013 and 2012, respectively, and were based on the value of the stock on the vesting dates as determined based upon an average of the Company’s high and low stock sales price on the vesting dates. Total payments for the employees’ tax obligations to the taxing authorities were $1,770, $6,571 and zero in 2014, 2013 and 2012, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-15-003654:notes:223]
A summary of the Company's restricted share awards activity for the years ended December 31, 2014, 2013 and 2012 is as follows:

[0001437749-15-003654:notes:224]
|  |  | Shares |  |  | Weighted- Average Grant- Date Fair Value |  |
| Non-vested as of December 31, 2011 |  |  | 489,302 |  |  | $ | 13.93 |  |
| Granted |  |  | 195,771 |  |  |  | 26.94 |  |
| Vested |  |  | - |  |  |  | - |  |
| Forfeited |  |  | (20,002 | ) |  |  | 11.96 |  |
| Non-vested as of December 31, 2012 |  |  | 665,071 |  |  |  | 17.75 |  |
| Granted |  |  | 112,494 |  |  |  | 37.82 |  |
| Vested |  |  | (450,537 | ) |  |  | 14.21 |  |
| Forfeited |  |  | (22,622 | ) |  |  | 25.36 |  |
| Non-vested as of December 31, 2013 |  |  | 304,406 |  |  |  | 29.68 |  |
| Granted |  |  | 115,473 |  |  |  | 54.35 |  |
| Vested |  |  | (105,123 | ) |  |  | 28.31 |  |
| Forfeited |  |  | (47,472 | ) |  |  | 42.31 |  |
| Non-vested as of December 31, 2014 |  |  | 267,284 |  |  |  | 38.72 |  |

[0001437749-15-003654:notes:225]
As of December 31, 2014, there was $5,394 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.1 years. Total share-based compensation cost related to the restricted stock for 2014, 2013 and 2012 was $4,103, $3,074 and $3,645, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-15-003654:notes:226]
During 2014, 2013 and 2012, 8,869, 7,291 and 10,864 shares, respectively, of fully vested stock were granted to certain members of the Company’s board of directors as a component of their compensation for their service on the board. Total compensation cost for these share grants in 2014, 2013 and 2012 was $509, $260 and $300, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-15-003654:notes:227]
16. Commitments and Contingencies

[0001437749-15-003654:notes:228]
The Company leases certain computer equipment, automobiles, and warehouse space under operating leases with terms generally ranging between 3-5 years.

[0001437749-15-003654:notes:229]
The approximate aggregate minimum rental commitments at December 31, 2014, are as follows:

[0001437749-15-003654:notes:230]
| Year |  | Amount |  |
| 2015 |  | $ | 2,585 |  |
| 2016 |  |  | 2,567 |  |
| 2017 |  |  | 1,571 |  |
| 2018 |  |  | 264 |  |
| 2019 |  |  | - |  |
| Total |  | $ | 6,987 |  |

[0001437749-15-003654:notes:231]
Total rent expense for the years ended December 31, 2014, 2013 and 2012, which includes short-term data processing equipment rentals, was approximately $4,102, $2,457, and $2,870, respectively.

[0001437749-15-003654:notes:232]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits. The Company has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at December 31, 2014 and 2013 was approximately $26,100 and $24,300, respectively.

[0001437749-15-003654:notes:233]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## gnrc:SpecialCashDividendsTextBlock

[0001437749-15-003654:notes:234]
17. Special Cash Dividends

[0001437749-15-003654:notes:235]
On June 29, 2012, the Company used a portion of the proceeds from the May 30, 2012 debt refinancing (see Note 11, “Credit Agreements” to the consolidated financial statements) together with cash on its balance sheet to pay a special cash dividend of $6.00 per share on its common stock, resulting in payments totaling $404,332 to stockholders. Related dividends declared but unpaid as of December 31, 2014 of $731, which relate to dividends earned on unvested restricted stock awards, are included in other accrued liabilities in the consolidated balance sheet. Payment of these dividends will be made when the underlying restricted stock awards vest. The 2012 dividend was recorded as a reduction to additional paid-in capital as the Company had an accumulated deficit balance as of the dividend declaration
      date.

[0001437749-15-003654:notes:236]
On June 21, 2013, the Company used a portion of the proceeds from the May 31, 2013 debt refinancing (see Note 11, “Credit Agreements” to the consolidated financial statements) to pay a special cash dividend of $5.00 per share on its common stock, resulting in payments totaling $340,772 to stockholders. Related dividends declared but unpaid as of December 31, 2014 of $810, which relate to dividends earned on unvested restricted stock awards, are included in other accrued liabilities in the consolidated balance sheet. Payment of these dividends will be made when the underlying restricted stock awards vest. The balance of retained earnings as of the 2013 dividend declaration date was $4,934. As such, the dividends were first charged to retained earnings and dividends in excess of retained earnings were recorded as a
      reduction to additional paid-in capital.

[0001437749-15-003654:notes:237]
In connection with the special dividends, and pursuant to the terms of the Company’s stock option plan, certain adjustments were made to stock options outstanding under the plan in order to avoid dilution of the intended benefits which would otherwise result as a consequence of the special dividend. As such, the strike price for all outstanding stock options at that time of the dividend was modified by the $6.00 and $5.00 special dividend amount, respectively, for the 2012 and 2013 special dividends. There was no change to compensation expense as a result of this adjustment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-15-003654:notes:238]
18. Quarterly Financial Information (Unaudited)

[0001437749-15-003654:notes:239]
|  |  | Quarters Ended 2014 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 342,008 |  |  | $ | 362,609 |  |  | $ | 352,305 |  |  | $ | 403,997 |  |
| Gross profit |  |  | 119,514 |  |  |  | 128,012 |  |  |  | 130,283 |  |  |  | 138,410 |  |
| Operating income |  |  | 65,306 |  |  |  | 78,160 |  |  |  | 70,794 |  |  |  | 79,115 |  |
| Net income |  |  | 34,701 |  |  |  | 54,025 |  |  |  | 36,497 |  |  |  | 49,390 |  |
| Net income per common share, basic: |  | $ | 0.51 |  |  | $ | 0.79 |  |  | $ | 0.53 |  |  | $ | 0.72 |  |
| Net income per common share, diluted: |  | $ | 0.50 |  |  | $ | 0.77 |  |  | $ | 0.52 |  |  | $ | 0.70 |  |

[0001437749-15-003654:notes:240]
|  |  | Quarters Ended 2013 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 399,572 |  |  | $ | 346,688 |  |  | $ | 363,269 |  |  | $ | 376,236 |  |
| Gross profit |  |  | 153,462 |  |  |  | 130,953 |  |  |  | 139,463 |  |  |  | 145,682 |  |
| Operating income |  |  | 96,525 |  |  |  | 76,433 |  |  |  | 87,289 |  |  |  | 91,218 |  |
| Net income |  |  | 50,674 |  |  |  | 28,254 |  |  |  | 47,093 |  |  |  | 48,518 |  |
| Net income per common share, basic: |  | $ | 0.75 |  |  | $ | 0.41 |  |  | $ | 0.69 |  |  | $ | 0.71 |  |
| Net income per common share, diluted: |  | $ | 0.73 |  |  | $ | 0.40 |  |  | $ | 0.67 |  |  | $ | 0.69 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-15-003654:notes:241]
19. Valuation and Qualifying Accounts

[0001437749-15-003654:notes:242]
For the years ended December 31, 2014, 2013 and 2012:

[0001437749-15-003654:notes:243]
|  |  | Balance at Beginning of Year |  |  | Reserves Assumed in Acquisition |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Balance at End of Year |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,658 |  |  | $ | 209 |  |  | $ | 672 |  |  | $ | (1,264 | ) |  | $ | 2,275 |  |
| Reserves for inventory |  |  | 6,558 |  |  |  | 2,282 |  |  |  | 2,797 |  |  |  | (2,250 | ) |  |  | 9,387 |  |
| Valuation of deferred tax assets |  |  | 1,021 |  |  |  | - |  |  |  | 364 |  |  | - |  |  |  | 1,385 |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,166 |  |  | $ | 496 |  |  | $ | 1,037 |  |  | $ | (41 | ) |  | $ | 2,658 |  |
| Reserves for inventory |  |  | 6,999 |  |  |  | 1,131 |  |  |  | 72 |  |  |  | (1,644 | ) |  |  | 6,558 |  |
| Valuation of deferred tax assets |  |  | 806 |  |  |  | (120 | ) |  |  | 335 |  |  | - |  |  |  | 1,021 |  |
| Year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 789 |  |  | $ | 383 |  |  | $ | 204 |  |  | $ | (210 | ) |  | $ | 1,166 |  |
| Reserves for inventory |  |  | 4,717 |  |  |  | 1,694 |  |  |  | 1,785 |  |  |  | (1,197 | ) |  |  | 6,999 |  |
| Valuation of deferred tax assets |  |  | - |  |  |  | 827 |  |  |  | (21 | ) |  | - |  |  |  | 806 |  |

[0001437749-15-003654:notes:244]
(1) Deductions from the allowance for doubtful accounts equal accounts receivable written off, less recoveries, against the allowance. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of.
