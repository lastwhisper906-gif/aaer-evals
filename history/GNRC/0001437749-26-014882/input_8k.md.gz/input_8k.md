# GNRC 8-K — 0001437749-26-013726 filed 2026-04-29

## item codes, every 8-K on or before 2026-05-05

- 2026-04-29 0001437749-26-013726 — 2.02, 7.01, 9.01
- 2026-03-25 0001437749-26-009685 — 5.02, 7.01, 9.01
- 2026-02-11 0001437749-26-003700 — 2.02, 9.01
- 2025-10-29 0001437749-25-032069 — 2.02, 9.01
- 2025-07-30 0001437749-25-023858 — 2.02, 9.01
- 2025-07-02 0001437749-25-021956 — 1.01, 9.01
- 2025-06-13 0001437749-25-020324 — 5.07
- 2025-04-30 0001437749-25-013608 — 2.02, 9.01
- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2026-05-05

- none on or before 2026-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-26-013726:8k_2_02:1]
EX-99.1
2
ex_952511.htm
EXHIBIT 99.1

[0001437749-26-013726:8k_2_02:2]
ex_952511.htm

[0001437749-26-013726:8k_2_02:3]
Exhibit 99.1

[0001437749-26-013726:8k_2_02:4]
Generac Reports First Quarter 2026 Results

[0001437749-26-013726:8k_2_02:5]
Data center market execution drives significant sales growth and improved operating leverage results in robust adjusted EBITDA margin expansion; strong first quarter results and C&I momentum support increased outlook

[0001437749-26-013726:8k_2_02:6]
WAUKESHA, WISCONSIN (April 29, 2026) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2026, and provided an update on its outlook for the full year 2026.

[0001437749-26-013726:8k_2_02:7]
First Quarter 2026 Highlights

[0001437749-26-013726:8k_2_02:8]
| ● | Net sales increased 12% to $1.06 billion during the first quarter of 2026 as compared to $942 million in the prior year first quarter. Acquisitions, divestitures and foreign currency had a net favorable impact of 4% during the quarter. |

[0001437749-26-013726:8k_2_02:9]
|  | - | Residential segment external net sales increased approximately 1% to $549 million as compared to $543 million in the prior year. |

[0001437749-26-013726:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) segment external net sales increased approximately 28% to $510 million as compared to $399 million in the prior year. |

[0001437749-26-013726:8k_2_02:11]
| ● | Net income attributable to the Company during the first quarter was $73 million, or $1.24 per share, as compared to $44 million, or $0.73 per share, for the same period of 2025. |

[0001437749-26-013726:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $106 million, or $1.80 per share, as compared to $75 million, or $1.26 per share, in the first quarter of 2025. |

[0001437749-26-013726:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $193 million, or 18.3% of net sales, as compared to $150 million, or 15.9% of net sales, in the prior year. |

[0001437749-26-013726:8k_2_02:14]
| ● | Cash flow from operations was $119 million as compared to $58 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $90 million as compared to $27 million in the first quarter of 2025. |

[0001437749-26-013726:8k_2_02:15]
| ● | On January 5th, the Company completed the previously announced acquisition of Allmand, a leading manufacturer of mobile power equipment for C&I markets, headquartered in Holdrege, Nebraska. |

[0001437749-26-013726:8k_2_02:16]
| ● | On April 1st, the Company completed the previously announced acquisition of Enercon, a leading designer and manufacturer of generator enclosures and switchgear for C&I markets, headquartered in East Peoria, Illinois. |

[0001437749-26-013726:8k_2_02:17]
| ● | The Company is updating its full-year 2026 net sales growth guidance to be in the mid-to-high teens percent range as compared to the prior year, an increase from the previous guidance for growth in the mid-teens percent range. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be approximately 18.5 to 19.5%, an increase from the previous guidance range of 18.0 to 19.0%. |

[0001437749-26-013726:8k_2_02:18]
“Our first quarter results reflect significant growth in our C&I segment and strong adjusted EBITDA margin expansion as we continue to strategically create a more balanced business with improved scale,” said Aaron Jagdfeld, President and Chief Executive Officer. “We are continuing to build momentum in the large and rapidly growing data center end market as we are in the final stages of vendor approval with multiple hyperscale customers and have expanded our backlog for these products with both new and existing customers. Additionally, we completed the acquisition of Enercon earlier this month, which will increase our vertical integration and provide for further margin expansion in large megawatt backup power solutions. As a result of our growing backlog for data center customers, the Enercon acquisition, and our first quarter outperformance, we are increasing our sales and adjusted EBITDA margin outlook for 2026, which does not assume any incremental impact of a multi-year hyperscale agreement at this point in time.”

[0001437749-26-013726:8k_2_02:19]
Additional First Quarter 2026 Consolidated Highlights

[0001437749-26-013726:8k_2_02:20]
Gross profit margin was 38.7% as compared to 39.5% in the prior year first quarter. The decrease in gross margin was primarily driven by the higher mix of C&I sales, partially offset by favorable price/cost realization.

[0001437749-26-013726:8k_2_02:21]
Operating expenses increased by $4.6 million, or 2%, as compared to the first quarter of 2025. The increase was primarily driven by higher intangible amortization.

[0001437749-26-013726:8k_2_02:22]
Provision for income taxes for the current year quarter was $23.6 million, or an effective tax rate of 24.4%, as compared to $14.2 million, or a 24.3% effective tax rate, for the prior year.

[0001437749-26-013726:8k_2_02:23]
Cash flow from operations was $119.3 million during the first quarter, as compared to $58.2 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $89.9 million as compared to $27.2 million in the first quarter of 2025. This strong increase in free cash flow during the quarter was primarily driven by higher operating earnings and a lower use of cash for working capital as compared to the prior year.

[0001437749-26-013726:8k_2_02:24]
First Quarter Business Segment Results

[0001437749-26-013726:8k_2_02:25]
See the Company’s 8-K filed today for additional quarterly segment financial information for fiscal 2025 that has been recast to align with the Company’s reorganization as announced at its Investor Day on March 25, 2026.

[0001437749-26-013726:8k_2_02:26]
Residential Segment

[0001437749-26-013726:8k_2_02:27]
Residential segment total sales increased approximately 1% to $552.2 million as compared to $548.7 million in the prior year. This sales increase was primarily driven by higher portable generator shipments, partially offset by a decline in energy storage system sales. Home standby generator sales were approximately flat as higher pricing in the current year was offset by lower volumes due to a strong prior year period that included the benefit from a substantial 2024 hurricane season.

[0001437749-26-013726:8k_2_02:28]
Adjusted EBITDA for the segment was $138.6 million, or 25.1% of residential segment total sales, as compared to $111.6 million, or 20.3% of residential sales, in the prior year. This margin increase was primarily driven by operational efficiencies resulting in lower operating expenses and favorable price realization that more than offset higher input costs.

[0001437749-26-013726:8k_2_02:29]
Commercial & Industrial Segment

[0001437749-26-013726:8k_2_02:30]
Commercial & Industrial segment total sales increased approximately 28% to $510.1 million from $399.0 million in the prior year quarter, including an approximate 10% net favorable impact from the combination of acquisitions, divestitures, and foreign currency. The core total sales growth for the segment was primarily driven by revenue from products sold to global data center customers, increased shipments to our domestic industrial distributor and rental channels, and higher sales of our controls solutions to the global power generation market.

[0001437749-26-013726:8k_2_02:31]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $66.5 million, or 13.0% of C&I total sales, as compared to $45.3 million, or 11.4% of total sales, in the prior year. This margin increase was primarily driven by improved price/cost realization, the accretive impact of the Allmand acquisition, and operating leverage on higher shipment volumes.

[0001437749-26-013726:8k_2_02:32]
2026 Outlook

[0001437749-26-013726:8k_2_02:33]
As a result of our growing backlog with data center customers, the acquisition of Enercon, and strong first quarter outperformance, the Company is increasing its outlook for net sales growth and adjusted EBITDA margin for full year 2026. Total net sales growth is now expected to be in the mid-to-high teens percent range as compared to the prior year, which includes an approximate 2% favorable impact from the net effect of foreign currency, acquisitions, and divestitures. This compares to the previous expectation for total net sales growth in the mid-teens percent range. C&I segment sales are now expected to grow in the mid-to-high 20% range during the year, an increase from the previous guidance of growth in the low-to-mid 20% range. Residential segment sales are still projected to increase in the 10% range from the prior year.

[0001437749-26-013726:8k_2_02:34]
Additionally, the Company still expects net income margin, before deducting for non-controlling interests, to be approximately 8.0 to 9.0% for the full-year 2026. The corresponding adjusted EBITDA margin is now expected to be approximately 18.5 to 19.5%, as compared to the previous guidance of 18.0 to 19.0%. This updated guidance does not include the future favorable impact of any potential tariff recovery.

[0001437749-26-013726:8k_2_02:35]
Conference Call and Webcast

[0001437749-26-013726:8k_2_02:36]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, April 29, 2026 to discuss first quarter 2026 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/734quh73

[0001437749-26-013726:8k_2_02:37]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-26-013726:8k_2_02:38]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-26-013726:8k_2_02:39]
About Generac

[0001437749-26-013726:8k_2_02:40]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company’s broad portfolio of energy technology offerings for homes and businesses enables its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and innovative energy solutions.

[0001437749-26-013726:8k_2_02:41]
Forward-looking Information

[0001437749-26-013726:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-26-013726:8k_2_02:43]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-26-013726:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |

[0001437749-26-013726:8k_2_02:45]
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | our ability to develop and enhance products and gain customer acceptance including our offerings that serve the data center and energy technology markets; |
|  | ● | uncertainty regarding the growth of the data center market; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | risks due to instability caused by geopolitical conflicts; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-26-013726:8k_2_02:46]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-26-013726:8k_2_02:47]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-26-013726:8k_2_02:48]
4

[0001437749-26-013726:8k_2_02:49]
Non-GAAP Financial Metrics

[0001437749-26-013726:8k_2_02:50]
Core Sales

[0001437749-26-013726:8k_2_02:51]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-26-013726:8k_2_02:52]
Adjusted EBITDA

[0001437749-26-013726:8k_2_02:53]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income (loss) before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense (benefit), certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries and certain intellectual property litigation. The adjustments to net income (loss) in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-26-013726:8k_2_02:54]
Adjusted Net Income

[0001437749-26-013726:8k_2_02:55]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income (loss) before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-26-013726:8k_2_02:56]
Free Cash Flow

[0001437749-26-013726:8k_2_02:57]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-26-013726:8k_2_02:58]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-26-013726:8k_2_02:59]
SOURCE: Generac Holdings Inc.

[0001437749-26-013726:8k_2_02:60]
CONTACT:

[0001437749-26-013726:8k_2_02:61]
Kris Rosemann

[0001437749-26-013726:8k_2_02:62]
Director – Corporate Finance & Investor Relations

[0001437749-26-013726:8k_2_02:63]
(262) 506-6064

[0001437749-26-013726:8k_2_02:64]
InvestorRelations@generac.com

[0001437749-26-013726:8k_2_02:65]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-013726:8k_2_02:66]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 265,530 |  |  | $ | 341,413 |  |
| Accounts receivable, less allowance for credit losses of $33,283 and $34,504 as of March 31, 2026 and December 31, 2025, respectively |  |  | 626,584 |  |  |  | 602,739 |  |
| Inventories |  |  | 1,251,793 |  |  |  | 1,248,867 |  |
| Prepaid expenses and other current assets |  |  | 305,061 |  |  |  | 269,459 |  |
| Total current assets |  |  | 2,448,968 |  |  |  | 2,462,478 |  |
| Property and equipment, net |  |  | 819,624 |  |  |  | 813,605 |  |
| Customer lists, net |  |  | 137,082 |  |  |  | 127,517 |  |
| Patents and technology, net |  |  | 330,136 |  |  |  | 338,308 |  |
| Other intangible assets, net |  |  | 7,796 |  |  |  | 10,011 |  |
| Tradenames, net |  |  | 213,664 |  |  |  | 199,430 |  |
| Goodwill |  |  | 1,486,807 |  |  |  | 1,467,094 |  |
| Deferred income taxes |  |  | 38,210 |  |  |  | 41,949 |  |
| Operating lease and other assets |  |  | 110,976 |  |  |  | 113,287 |  |
| Total assets |  | $ | 5,593,263 |  |  | $ | 5,573,679 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 43,950 |  |  | $ | 50,618 |  |
| Accounts payable |  |  | 462,822 |  |  |  | 436,583 |  |
| Accrued wages and employee benefits |  |  | 55,571 |  |  |  | 69,850 |  |
| Accrued product warranty |  |  | 41,622 |  |  |  | 44,716 |  |
| Other accrued liabilities |  |  | 577,427 |  |  |  | 591,387 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 26,390 |  |  |  | 22,192 |  |
| Total current liabilities |  |  | 1,207,782 |  |  |  | 1,215,346 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,253,537 |  |  |  | 1,260,256 |  |
| Deferred income taxes |  |  | 56,786 |  |  |  | 60,913 |  |
| Deferred revenue |  |  | 236,504 |  |  |  | 232,921 |  |
| Operating lease and other long-term liabilities |  |  | 163,354 |  |  |  | 165,197 |  |
| Total liabilities |  |  | 2,917,963 |  |  |  | 2,934,633 |  |
| Redeemable noncontrolling interest |  |  | 602 |  |  |  | 742 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 74,218,726 and 74,050,753 shares issued as of March 31, 2026 and December 31, 2025, respectively |  |  | 742 |  |  |  | 741 |  |
| Additional paid-in capital |  |  | 1,195,494 |  |  |  | 1,187,419 |  |
| Treasury stock, at cost, 15,464,527, and 15,373,990 shares at March 31, 2026 and December 31, 2025, respectively |  |  | (1,378,708 | ) |  |  | (1,358,053 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 3,076,810 |  |  |  | 3,003,557 |  |
| Accumulated other comprehensive (loss) income |  |  | (17,530 | ) |  |  | 874 |  |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,674,692 |  |  |  | 2,632,422 |  |
| Noncontrolling interests |  |  | 6 |  |  |  | 5,882 |  |
| Total stockholders’ equity |  |  | 2,674,698 |  |  |  | 2,638,304 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,593,263 |  |  | $ | 5,573,679 |  |

[0001437749-26-013726:8k_2_02:67]
6

[0001437749-26-013726:8k_2_02:68]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-013726:8k_2_02:69]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net sales |  | $ | 1,059,365 |  |  | $ | 942,121 |  |
| Costs of goods sold |  |  | 649,129 |  |  |  | 570,135 |  |
| Gross profit |  |  | 410,236 |  |  |  | 371,986 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 123,624 |  |  |  | 126,065 |  |
| Research and development |  |  | 62,656 |  |  |  | 62,048 |  |
| General and administrative |  |  | 76,285 |  |  |  | 74,746 |  |
| Amortization of intangibles |  |  | 30,380 |  |  |  | 25,489 |  |
| Total operating expenses |  |  | 292,945 |  |  |  | 288,348 |  |
| Income from operations |  |  | 117,291 |  |  |  | 83,638 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (15,376 | ) |  |  | (17,110 | ) |
| Investment income |  |  | 1,683 |  |  |  | 2,225 |  |
| Change in fair value of investments |  |  | (1,374 | ) |  |  | (9,947 | ) |
| Other, net |  |  | (5,465 | ) |  |  | (292 | ) |
| Total other expense, net |  |  | (20,532 | ) |  |  | (25,124 | ) |
| Income before provision for income taxes |  |  | 96,759 |  |  |  | 58,514 |  |
| Provision for income taxes |  |  | 23,647 |  |  |  | 14,236 |  |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 73,253 |  |  |  | 43,840 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.25 |  |  | $ | 0.74 |  |
| Weighted average common shares outstanding - basic: |  |  | 58,412,205 |  |  |  | 59,062,534 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.24 |  |  | $ | 0.73 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,233,144 |  |  |  | 59,747,589 |  |

[0001437749-26-013726:8k_2_02:70]
7

[0001437749-26-013726:8k_2_02:71]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-26-013726:8k_2_02:72]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 73,112 |  |  | $ | 44,278 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 25,594 |  |  |  | 20,652 |  |
| Amortization of intangible assets |  |  | 30,380 |  |  |  | 25,489 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 535 |  |  |  | 636 |  |
| Change in fair value of investments |  |  | 1,374 |  |  |  | 9,947 |  |
| Deferred income tax expense (benefit) |  |  | 3,745 |  |  |  | (4,182 | ) |
| Share-based compensation expense |  |  | 13,442 |  |  |  | 11,608 |  |
| Loss on disposal of assets |  |  | 218 |  |  |  | 303 |  |
| Loss attributable to business dispositions |  |  | 4,782 |  |  |  | - |  |
| Other noncash charges |  |  | 552 |  |  |  | 626 |  |
| Excess tax benefits from equity awards |  |  | (2,789 | ) |  |  | (164 | ) |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (15,103 | ) |  |  | 48,350 |  |
| Inventories |  |  | 13,930 |  |  |  | (57,203 | ) |
| Other assets |  |  | (44,151 | ) |  |  | 2,145 |  |
| Accounts payable |  |  | 40,085 |  |  |  | (33,007 | ) |
| Accrued wages and employee benefits |  |  | (13,704 | ) |  |  | (31,554 | ) |
| Other accrued liabilities |  |  | (12,717 | ) |  |  | 20,228 |  |
| Net cash provided by operating activities |  |  | 119,285 |  |  |  | 58,152 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | - |  |  |  | 54 |  |
| Purchase of long-term investments |  |  | - |  |  |  | (2,656 | ) |
| Expenditures for property and equipment |  |  | (29,397 | ) |  |  | (30,937 | ) |
| Acquisition of business, net of cash acquired |  |  | (122,828 | ) |  |  | - |  |
| Other investing activities |  |  | (1,525 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (153,750 | ) |  |  | (33,539 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 14,079 |  |  |  | 19,236 |  |
| Proceeds from long-term borrowings |  |  | 243 |  |  |  | 943 |  |
| Repayments of short-term borrowings |  |  | (21,035 | ) |  |  | (19,985 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (6,190 | ) |  |  | (14,450 | ) |
| Stock repurchases |  |  | - |  |  |  | (97,454 | ) |
| Payment of deferred acquisition consideration |  |  | (1,130 | ) |  |  | - |  |
| Taxes paid related to equity awards |  |  | (34,594 | ) |  |  | (8,601 | ) |
| Proceeds from the exercise of stock options |  |  | 7,245 |  |  |  | 592 |  |
| Net cash used in financing activities |  |  | (41,382 | ) |  |  | (119,719 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (36 | ) |  |  | 1,293 |  |
| Net decrease in cash and cash equivalents |  |  | (75,883 | ) |  |  | (93,813 | ) |
| Cash and cash equivalents at beginning of period |  |  | 341,413 |  |  |  | 281,277 |  |
| Cash and cash equivalents at end of period |  | $ | 265,530 |  |  | $ | 187,464 |  |

[0001437749-26-013726:8k_2_02:73]
8

[0001437749-26-013726:8k_2_02:74]
| Generac Holdings Inc. |
| Segment Reporting Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-26-013726:8k_2_02:75]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Residential |  | $ | 549,316 |  |  | $ | 2,867 |  |  | $ | 552,183 |  |  | $ | 543,115 |  |  | $ | 5,548 |  |  | $ | 548,663 |  |
| Commercial & Industrial |  |  | 510,049 |  |  |  | 49 |  |  |  | 510,098 |  |  |  | 399,006 |  |  |  | - |  |  |  | 399,006 |  |
| Corporate and eliminations |  |  | - |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  | - |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Total net sales |  | $ | 1,059,365 |  |  | $ | - |  |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |

[0001437749-26-013726:8k_2_02:76]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Residential |  | $ | 138,585 |  |  | $ | 111,589 |  |
| Commercial & Industrial |  |  | 66,532 |  |  |  | 45,346 |  |
| Corporate and eliminations |  |  | (11,636 | ) |  |  | (7,389 | ) |
| Total adjusted EBITDA (1) |  | $ | 193,481 |  |  | $ | 149,546 |  |

[0001437749-26-013726:8k_2_02:77]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |  |

[0001437749-26-013726:8k_2_02:78]
9

[0001437749-26-013726:8k_2_02:79]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-013726:8k_2_02:80]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |
| Interest expense |  |  | 15,376 |  |  |  | 17,110 |  |
| Depreciation and amortization |  |  | 55,974 |  |  |  | 46,141 |  |
| Provision for income taxes |  |  | 23,647 |  |  |  | 14,236 |  |
| Non-cash write-down and other adjustments (1) |  |  | (1,443 | ) |  |  | (13 | ) |
| Non-cash share-based compensation expense (2) |  |  | 13,442 |  |  |  | 11,608 |  |
| Transaction costs and credit facility fees (3) |  |  | 2,710 |  |  |  | 760 |  |
| Business optimization and other charges (4) |  |  | 1,153 |  |  |  | 1,575 |  |
| Provision for legal, regulatory, and other costs (5) |  |  | 3,206 |  |  |  | 3,751 |  |
| Change in fair value of investments (6) |  |  | 1,374 |  |  |  | 9,947 |  |
| Other (8) |  |  | 4,930 |  |  |  | 153 |  |
| Adjusted EBITDA |  |  | 193,481 |  |  |  | 149,546 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (146 | ) |  |  | 632 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 193,627 |  |  | $ | 148,914 |  |

[0001437749-26-013726:8k_2_02:81]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |
| Amortization of intangible assets |  |  | 30,380 |  |  |  | 25,489 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 535 |  |  |  | 636 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 2,548 |  |  |  | 107 |  |
| Loss attributable to business or asset dispositions (8) |  |  | 4,782 |  |  |  | 390 |  |
| Business optimization and other charges (4) |  |  | 1,153 |  |  |  | 1,575 |  |
| Provision for legal, regulatory, and other costs (5) |  |  | 3,206 |  |  |  | 3,751 |  |
| Change in fair value of investments (6) |  |  | 1,374 |  |  |  | 9,947 |  |
| Tax effect of add backs |  |  | (10,885 | ) |  |  | (10,369 | ) |
| Adjusted net income |  |  | 106,205 |  |  |  | 75,804 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 106,346 |  |  | $ | 75,366 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.80 |  |  | $ | 1.26 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,233,144 |  |  |  | 59,747,589 |  |

[0001437749-26-013726:8k_2_02:82]
10

[0001437749-26-013726:8k_2_02:83]
| (1) Includes (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement. |
| (4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
| (5) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations: |

[0001437749-26-013726:8k_2_02:84]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Legal expenses, judgements and settlements related to certain patent lawsuits |  | $ | 2,447 |  |  | $ | 1,492 |  |
| Legal expenses, judgements and settlements related to certain class action lawsuits |  |  | 1,026 |  |  |  | 1,343 |  |
| Legal expenses related to certain government inquiries and other significant matters |  |  | 862 |  |  |  | 916 |  |
| Release of warranty provision recorded in 2022 to address clean energy warranty-related matters |  |  | (1,129 | ) |  |  | - |  |
| Total provision for legal, regulatory and clean energy product charges |  | $ | 3,206 |  |  | $ | 3,751 |  |

[0001437749-26-013726:8k_2_02:85]
| (6) Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities. |
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) The loss relates primarily to two immaterial business dispositions that closed in the first quarter of 2026. |

[0001437749-26-013726:8k_2_02:86]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Net cash provided by operating activities |  | $ | 119,285 |  |  | $ | 58,152 |  |
| Expenditures for property and equipment |  |  | (29,397 | ) |  |  | (30,937 | ) |
| Free cash flow |  | $ | 89,888 |  |  | $ | 27,215 |  |

[0001437749-26-013726:8k_2_02:87]
11
