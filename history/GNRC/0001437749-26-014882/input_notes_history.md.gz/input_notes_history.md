# GNRC note change history — 0001437749-25-033048 → 0001437749-26-014882


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001437749-26-014882:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  March 31, 2026, and  December 31, 2025, was $162,314 and $149,737, respectively.
  (was, 2025-11-04, similarity 0.988):
[0001437749-25-033048:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  September 30, 2025, and  December 31, 2024, was $165,200 and $165,432, respectively.

- changed (2026-05-05):
[0001437749-26-014882:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred.  The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee decided to pursue PHS’s claims against Generac in arbitration. Generac Power intends to vigorously defend against the claims and contends that PHS cannot recover certain damages on behalf of its customers upon final approval of the settlement in the Multidistrict Litigation described below to the extent the claims relate to the performance of a certain solar system component. The arbitration hearing is expected to occur in  June 2027.
  (was, 2025-11-04, similarity 0.8361):
[0001437749-25-033048:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

- changed (2026-05-05):
[0001437749-26-014882:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis. The parties have obtained preliminary approval for the classwide settlement and will be seeking final approval.  In the third quarter of 2025, Generac Power recorded a reserve for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.
  (was, 2025-11-04, similarity 0.9067):
[0001437749-25-033048:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis.  The parties will seek court approval for the classwide settlement and Generac Power has reserved for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.

- changed (2026-05-05):
[0001437749-26-014882:note_history:4]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025. On  April 30, 2026, the court granted the Company’s motion to dismiss the amended complaint with prejudice, again finding that plaintiffs failed to adequately plead a securities fraud claim, and directed the entry of final judgment in favor of the Company. Plaintiffs  may appeal the dismissal. If an appeal is filed, the Company intends to vigorously defend the judgment.
  (was, 2025-11-04, similarity 0.7773):
[0001437749-25-033048:note_history:4]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025 and the Company has filed a motion to dismiss.

- changed (2026-05-05):
[0001437749-26-014882:note_history:5]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics, various voluntary self-disclosures the Company has made to the EPA since 2024, and other ancillary requests for information.
  (was, 2025-11-04, similarity 0.9622):
[0001437749-25-033048:note_history:5]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020.  On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.

- changed (2026-05-05):
[0001437749-26-014882:note_history:6]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserted claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff sought to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and sought unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). On  February 3, 2026, the court granted the Company’s motion to dismiss the amended complaint and found that plaintiff failed to adequately plead a securities fraud claim. Plaintiff did not appeal the dismissal, so it is final.
  (was, 2025-11-04, similarity 0.6626):
[0001437749-25-033048:note_history:6]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

- added (2026-05-05):
[0001437749-26-014882:note_history:7]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company was named as a nominal defendant) generally alleged, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. Following the dismissal of the Walling Lawsuit, plaintiff voluntarily dismissed the shareholder derivative action.

- added (2026-05-05):
[0001437749-26-014882:note_history:8]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs pursued claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. On  January 26, 2026, the Company, together with other co-defendants, agreed to enter a settlement in principle to resolve all asserted claims, while denying any wrongdoing, to eliminate the uncertainty, burden, and expense of protracted litigation. The Company agreed to pay $104,500 in addition to the Company’s excess insurance for the applicable policy year. As of  March 31, 2026 and  December 31, 2025, the Company has reflected a reserve for $206,500 within other accrued liabilities and an insurance receivable for $102,000 in prepaid expenses and other assets in the condensed consolidated balance sheets. The Company and its insurance carriers satisfied the payment obligation on  April 1, 2026.

- changed (2026-05-05):
[0001437749-26-014882:note_history:9]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The court dismissed (1) all claims against the Company and (2) all non-Florida residents’ claims against Generac Power for lack of personal jurisdiction, and limited the Florida plaintiffs’ claims against Generac Power to a claim for breach of express warranty.  The Company disputes the allegations and intends to vigorously defend against the remaining claims in the Amended Complaint, including that the case should not proceed as a class action.
  (was, 2025-11-04, similarity 0.62):
[0001437749-25-033048:note_history:9]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

- removed (2026-05-05):
[0001437749-25-033048:note_history:10]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

- removed (2026-05-05):
[0001437749-25-033048:note_history:11]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims and Generac filed a counterclaim. On  August 18, 2025, Generac Power prevailed in the defense of Spartronics’ arbitration claims and substantially prevailed on its counterclaim seeking possession of pre-paid raw materials and owned tooling.  Generac Power also received an award of its legal fees in connection with the action.  The award is binding and not subject of an appeal.

- removed (2026-05-05):
[0001437749-25-033048:note_history:12]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

- removed (2026-05-05):
[0001437749-25-033048:note_history:13]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing. Generac Power intends to participate in a mediation in  January 2026 along with other parties and plaintiffs, in advance of a trial that is likely to occur on or after  April 2026.  Plaintiffs have not fully quantified their damages but will be seeking damages in excess of Generac Power’s available insurance. The Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001437749-26-014882:note_history:14]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2025-11-04, similarity 0.9432):
[0001437749-25-033048:note_history:14]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, data & telecom, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- added (2026-05-05):
[0001437749-26-014882:note_history:15]
|  | ● | In January 2026, the Company acquired Allmand, headquartered in Holdrege, Nebraska. Allmand is a leading manufacturer of mobile power equipment for commercial and industrial markets. |

- changed (2026-05-05):
[0001437749-26-014882:note_history:16]
The condensed consolidated balance sheet as of  March 31, 2026, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2026 and 2025, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2026 and 2025, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2026 and 2025 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2025-11-04, similarity 0.8989):
[0001437749-25-033048:note_history:16]
The condensed consolidated balance sheet as of  September 30, 2025, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2026-05-05):
[0001437749-26-014882:note_history:17]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the three months ended  March 31, 2026, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2025-11-04, similarity 0.9137):
[0001437749-25-033048:note_history:17]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2026-05-05):
[0001437749-25-033048:note_history:18]
|  | ● | In November 2024, the Company acquired Wolverine Power Systems (Wolverine), headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC (Ageto). Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System (C&I BESS) product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. (Huntington), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |

- removed (2026-05-05):
[0001437749-25-033048:note_history:19]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

- removed (2026-05-05):
[0001437749-25-033048:note_history:20]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update was effective for fiscal year 2024 and is effective for interim periods in fiscal 2025. The required annual disclosures are reflected in Note 7, "Segment Reporting," to the 2024 Annual Report on Form 10-K and the required quarterly disclosures are reflected in Note 7, "Segment Reporting," of this Quarterly Report on Form 10-Q.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001437749-26-014882:note_history:21]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2026, and  December 31, 2025, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $43,950 and $50,618, respectively. As of  March 31, 2026, the weighted-average interest rate on the short-term borrowings was 6.19%.
  (was, 2025-11-04, similarity 0.8941):
[0001437749-25-033048:note_history:21]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $46,046 and $55,848, respectively. As of  September 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 6.33% and 5.44%, respectively.

- added (2026-05-05):
[0001437749-26-014882:note_history:22]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 700,000 |  |
| Term Loan B Facility |  |  | 492,500 |  |  |  | 493,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,411 | ) |  |  | (5,673 | ) |
| Revolving Facility |  |  | - |  |  |  | - |  |
| Finance lease obligations |  |  | 90,203 |  |  |  | 90,915 |  |
| Other |  |  | 2,635 |  |  |  | 3,456 |  |
| Total |  |  | 1,279,927 |  |  |  | 1,282,448 |  |
| Less: current portion of debt |  |  | 16,303 |  |  |  | 12,729 |  |
| Less: current portion of finance lease obligations |  |  | 10,087 |  |  |  | 9,463 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,253,537 |  |  | $ | 1,260,256 |  |

- changed (2026-05-05):
[0001437749-26-014882:note_history:23]
As of  March 31, 2026, there were $4,712 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the condensed consolidated balance sheets, and $5,411 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the condensed consolidated balance sheets.
  (was, 2025-11-04, similarity 0.9883):
[0001437749-25-033048:note_history:23]
As of  September 30, 2025, there were $5,267 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the condensed consolidated balance sheets, and $5,938 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the condensed consolidated balance sheets.

- changed (2026-05-05):
[0001437749-26-014882:note_history:24]
The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030.  The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on  March 31, 2026, before considering original issue discount and deferred financing costs, were as follows:
  (was, 2025-11-04, similarity 0.9884):
[0001437749-25-033048:note_history:24]
The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030.  The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on  September 30, 2025, before considering original issue discount and deferred financing costs, were as follows:

- added (2026-05-05):
[0001437749-26-014882:note_history:25]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2026 |  | $ | 4,375 |  |  | $ | 3,750 |  |  | $ | - |  |  | $ | 8,125 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 600,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 492,500 |  |  | $ | - |  |  | $ | 1,192,500 |  |

- changed (2026-05-05):
[0001437749-26-014882:note_history:26]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 5.42% combined rate as of  March 31, 2026.
  (was, 2025-11-04, similarity 0.9874):
[0001437749-25-033048:note_history:26]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.03% combined rate as of  September 30, 2025.

- changed (2026-05-05):
[0001437749-26-014882:note_history:27]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  March 31, 2026, the Company’s net secured leverage ratio was 1.31 to 1.00, and the Company was in compliance with all covenants under the facility. There are no financial maintenance covenants on the Term Loan B Facility.
  (was, 2025-11-04, similarity 0.9835):
[0001437749-25-033048:note_history:27]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2025, the Company’s net secured leverage ratio was 1.35 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

- changed (2026-05-05):
[0001437749-26-014882:note_history:28]
The Company's original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.
  (was, 2025-11-04, similarity 0.998):
[0001437749-25-033048:note_history:28]
The Company’s original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

- changed (2026-05-05):
[0001437749-26-014882:note_history:29]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Original Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%. Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements. As of  March 31, 2026, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 4.92%.
  (was, 2025-11-04, similarity 0.907):
[0001437749-25-033048:note_history:29]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%.  The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.  Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements.  As of  September 30, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 5.78%.

- changed (2026-05-05):
[0001437749-26-014882:note_history:30]
In accordance with AS
      C 470-50, the Company capitalized $5,275 of debt issuance costs related to this transaction. Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of $443 and expensed $782 of third-party fees as a loss on refinancing of debt.
  (was, 2025-11-04, similarity 0.9967):
[0001437749-25-033048:note_history:30]
In accordance with ASC
      470-
      50, the Company capitalized
      $5,275 of debt issuance costs related to this transaction.  Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of
      $443 and expensed
      $782 of
      third-party fees as a loss on refinancing of debt.

- changed (2026-05-05):
[0001437749-26-014882:note_history:31]
Both the New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2026, the Company’s total leverage ratio was 1.37 to 1.00, and the Company's interest coverage ratio was 12.98 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of  March 31, 2026.
  (was, 2025-11-04, similarity 0.8593):
[0001437749-25-033048:note_history:31]
Both the Original and New Tranche A Term Loan Facility and the Original and New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2025, the Company’s total leverage ratio was 1.41 to 1.00, and the Company's interest coverage ratio was 12.54 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of  September 30, 2025.

- changed (2026-05-05):
[0001437749-26-014882:note_history:32]
As of  March 31, 2026, there were no amounts outstanding under the New Revolving Facility, leaving $999,250 of unused capacity, net of outstanding letters of credit.
  (was, 2025-11-04, similarity 0.9097):
[0001437749-25-033048:note_history:32]
As of  September 30, 2025, there was $90,000 outstanding under the New Revolving Facility, leaving $909,250 of unused capacity, net of outstanding letters of credit.

- removed (2026-05-05):
[0001437749-25-033048:note_history:33]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 495,000 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,938 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 91,914 |  |  |  | 66,355 |  |
| Other |  |  | 3,134 |  |  |  | 8,972 |  |
| Total |  |  | 1,374,110 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 8,064 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,075 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,356,971 |  |  | $ | 1,210,776 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:34]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2025 |  | $ | - |  |  | $ | 1,250 |  |  | $ | - |  |  | $ | 1,250 |  |
| 2026 |  |  | 4,375 |  |  |  | 5,000 |  |  |  | - |  |  |  | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 690,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 495,000 |  |  | $ | 90,000 |  |  | $ | 1,285,000 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001437749-26-014882:note_history:35]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 700,000 |  |
| Term Loan B Facility |  |  | 492,500 |  |  |  | 493,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,411 | ) |  |  | (5,673 | ) |
| Revolving Facility |  |  | - |  |  |  | - |  |
| Finance lease obligations |  |  | 90,203 |  |  |  | 90,915 |  |
| Other |  |  | 2,635 |  |  |  | 3,456 |  |
| Total |  |  | 1,279,927 |  |  |  | 1,282,448 |  |
| Less: current portion of debt |  |  | 16,303 |  |  |  | 12,729 |  |
| Less: current portion of finance lease obligations |  |  | 10,087 |  |  |  | 9,463 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,253,537 |  |  | $ | 1,260,256 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:36]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 495,000 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,938 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 91,914 |  |  |  | 66,355 |  |
| Other |  |  | 3,134 |  |  |  | 8,972 |  |
| Total |  |  | 1,374,110 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 8,064 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,075 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,356,971 |  |  | $ | 1,210,776 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001437749-26-014882:note_history:37]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2026 |  | $ | 4,375 |  |  | $ | 3,750 |  |  | $ | - |  |  | $ | 8,125 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 600,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 492,500 |  |  | $ | - |  |  | $ | 1,192,500 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:38]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2025 |  | $ | - |  |  | $ | 1,250 |  |  | $ | - |  |  | $ | 1,250 |  |
| 2026 |  |  | 4,375 |  |  |  | 5,000 |  |  |  | - |  |  |  | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 690,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 495,000 |  |  | $ | 90,000 |  |  | $ | 1,285,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001437749-26-014882:note_history:39]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Residential |  | $ | 549,316 |  |  | $ | 2,867 |  |  | $ | 552,183 |  |  | $ | 543,115 |  |  | $ | 5,548 |  |  | $ | 548,663 |  |
| Commercial & Industrial |  |  | 510,049 |  |  |  | 49 |  |  |  | 510,098 |  |  |  | 399,006 |  |  |  | - |  |  |  | 399,006 |  |
| Intercompany eliminations |  |  | - |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  | - |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Total net sales |  | $ | 1,059,365 |  |  | $ | - |  |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:40]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 605,444 |  |  | $ | 21,262 |  |  | $ | 626,706 |  |
| Commercial & industrial products |  |  | 212,875 |  |  |  | 145,398 |  |  |  | 358,273 |  |
| Other |  |  | 115,327 |  |  |  | 14,047 |  |  |  | 129,374 |  |
| Total net sales |  | $ | 933,646 |  |  | $ | 180,707 |  |  | $ | 1,114,353 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:41]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:42]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,632,048 |  |  | $ | 62,998 |  |  | $ | 1,695,046 |  |
| Commercial & industrial products |  |  | 635,356 |  |  |  | 422,493 |  |  |  | 1,057,849 |  |
| Other |  |  | 319,115 |  |  |  | 45,633 |  |  |  | 364,748 |  |
| Total net sales |  | $ | 2,586,519 |  |  | $ | 531,124 |  |  | $ | 3,117,643 |  |

- removed (2026-05-05):
[0001437749-25-033048:note_history:43]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001437749-26-014882:note_history:44]
11.   Contract Liabilities
  (was, 2025-11-04, similarity 0.7317):
[0001437749-25-033048:note_history:44]
10.   Contract Balances

- added (2026-05-05):
[0001437749-26-014882:note_history:45]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods or services; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears after shipment of the product to the customer or performance of the service. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable or as prepaid expenses and other current assets upon revenue recognition, while contracts where customers pay in advance of performance are recognized as deferred revenue and recorded in other accrued liabilities (for the portion expected to be recognized within twelve months) or long-term deferred revenue (for the portion not expected to be recognized within twelve months) in the condensed consolidated balance sheets, until revenue is recognized.

- added (2026-05-05):
[0001437749-26-014882:note_history:46]
The balance of customer deposits and other contract liabilities, excluding the extended warranty deferred revenue balance disclosed in Note 10, was $137,438 and $151,257 as of  March 31, 2026, and  December 31, 2025, respectively. During the three months ended  March 31, 2026, the Company recognized revenue of $46,832 related to amounts included in the  December 31, 2025 contract liability balance. As of  March 31, 2026, the aggregate amount of revenue that the Company expects to recognize on remaining performance obligations (excluding extended warranty) was approximately $272,000, of which approximately 90% is expected to be recognized as revenue over the next two years. We have applied the practical expedient to exclude the value of remaining performance obligations for contracts with an original term of one year or less.

- removed (2026-05-05):
[0001437749-25-033048:note_history:47]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits and other contract liabilities was $58,901 and $26,858 on  September 30, 2025, and  December 31, 2024, respectively. During the nine months ended  September 30, 2025, the Company recognized revenue of $23,020 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2026-05-05):
[0001437749-26-014882:note_history:48]
17. Subsequent Events

- added (2026-05-05):
[0001437749-26-014882:note_history:49]
On  April 1, 2026, the Company acquired Enercon Engineering, Inc. (Enercon) headquartered in East Peoria, Illinois. Enercon designs and manufactures custom power equipment and industrial enclosures for high-reliability applications, strengthening the  Company’s ability to service hyperscale and enterprise data center markets. The preliminary purchase price totaled $122,322, of which $44,785 was paid in restricted shares and the remainder in cash.  Additional contingent consideration  may be earned up to a maximum amount of $112,043, with 35% paid in restricted shares and the remainder in cash, upon the achievement of certain conditions.  The earnout period extends through  April 1, 2027.  Due to the close proximity of the acquisition date and the Company's filing of its interim financial information on Form 10-Q for the three months ended  March 31, 2026, the initial accounting for the business combination is not yet complete and is pending identification and measurement of the assets acquired and liabilities assumed. Accordingly, the information required by ASC 805, Business Combinations, will be disclosed in the Company's subsequent Form 10-Q.
