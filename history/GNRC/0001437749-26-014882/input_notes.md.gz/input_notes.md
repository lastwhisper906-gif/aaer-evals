# GNRC notes — 0001437749-26-014882


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-26-014882:notes:1]
[same as prior period, unchanged from 0001437749-25-033048:notes:1]

[0001437749-26-014882:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-26-014882:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in the Company's Annual Report on Form 10-K for the year ended  December 31, 2025, for a discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-26-014882:notes:4]
|  | ● | In January 2026, the Company acquired Allmand, headquartered in Holdrege, Nebraska. Allmand is a leading manufacturer of mobile power equipment for commercial and industrial markets. |

[0001437749-26-014882:notes:5]
The condensed consolidated balance sheet as of  March 31, 2026, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2026 and 2025, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2026 and 2025, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2026 and 2025 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-26-014882:notes:6]
[same as prior period, unchanged from 0001437749-25-033048:notes:6]

[0001437749-26-014882:notes:7]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended  December 31, 2025.

[0001437749-26-014882:notes:8]
[same as prior period, unchanged from 0001437749-25-033048:notes:8]

[0001437749-26-014882:notes:9]
[same as prior period, unchanged from 0001437749-25-033048:notes:9]

[0001437749-26-014882:notes:10]
In  September 2025, the FASB issued ASU 2025-06 Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40). The update is intended to better align internal use software guidance with modern development methods, which have evolved to commonly include incremental and iterative development approaches. The ASU requires an entity to start capitalizing software costs when management has authorized and committed to funding a software project and when it is probable the project will be completed and used to perform the intended function. The ASU amendments also supersede previous guidance on website development costs. The update is effective for fiscal years beginning after  December 15, 2027 and  may be adopted prospectively, retrospectively or with a modified transition approach. Early adoption is permitted. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-26-014882:notes:11]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors with more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-26-014882:notes:12]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the three months ended  March 31, 2026, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-26-014882:notes:13]
2.   Acquisitions and Dispositions

[0001437749-26-014882:notes:14]
Fiscal 2026 Acquisition

[0001437749-26-014882:notes:15]
On  January 5, 2026, the Company acquired Allmand, a leading manufacturer of mobile power equipment for Commercial & Industrial markets, headquartered in Holdrege, Nebraska for $122,828. The Company recorded its preliminary purchase price allocation based upon the Company’s estimates of the fair value of the acquired assets and assumed liabilities at that time.  As a result, the Company recorded $44,300 of certain intangible assets and $34,439 of goodwill in the Commercial & Industrial segment, as of the acquisition date. Goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Allmand from the date of acquisition through  March 31, 2026.  Pro-forma and other financial information are not presented as the effects of the acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-26-014882:notes:16]
Fiscal 2026 and 2025 Dispositions

[0001437749-26-014882:notes:17]
On  January 2, 2026, the Company completed two immaterial business dispositions within the Commercial & Industrial segment, resulting in a combined loss of $4,782.

[0001437749-26-014882:notes:18]
On  May 31, 2025, the Company completed an immaterial business disposition within the Residential segment (prior to the segment reorganization, the Domestic segment), resulting in a loss of $3,905. Refer to Note 7, "Segment Reporting," for further information regarding the segment reorganization.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-26-014882:notes:19]
3.   Redeemable Noncontrolling Interest

[0001437749-26-014882:notes:20]
The Company entered into a joint venture with E.A. Juffali & Brothers ("Juffali") on  August 7, 2025, based in Bahrain, aiming to expand its footprint in the Middle East region. The joint venture, operating under the name Generac Juffali Generators WLL, will function as a distinct legal entity with ownership interests divided between the Company and Juffali at 51% and 49%, respectively. As the Company holds a controlling financial interest in the joint venture's operating entity, it will consolidate the entity. During the third quarter of 2025, Juffali funded 49% of the total capital contributed to the new legal entity. The issuance date fair value of the 49% noncontrolling interest was $979 and was recorded in the condensed consolidated balance sheets as a redeemable noncontrolling interest. This classification is based on Juffali’s right to require redemption of its interest in Generac Juffali Generators under specific triggering circumstances outlined in the joint venture agreement. The redeemable noncontrolling interest is initially recognized at its issuance date fair value and is adjusted each reporting period to reflect the noncontrolling interests’ share of comprehensive income. If the redeemable noncontrolling interest becomes currently redeemable or is probable of becoming currently redeemable, it is then adjusted to the greater of the redemption value or the carrying value, with any redemption value adjustments being recorded directly to retained earnings in the consolidated balance sheets.

[0001437749-26-014882:notes:21]
The following table presents the changes in the redeemable noncontrolling interest for Generac Jufalli Generators:

[0001437749-26-014882:notes:22]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |
| Balance at beginning of period |  | $ | 742 |  |
| Net loss |  |  | (141 | ) |
| Foreign currency translation |  |  | 1 |  |
| Balance at end of period |  | $ | 602 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-26-014882:notes:23]
[same as prior period, unchanged from 0001437749-25-033048:notes:28]

[0001437749-26-014882:notes:24]
[same as prior period, unchanged from 0001437749-25-033048:notes:29]

[0001437749-26-014882:notes:25]
[same as prior period, unchanged from 0001437749-25-033048:notes:30]

[0001437749-26-014882:notes:26]
[same as prior period, unchanged from 0001437749-25-033048:notes:31]

[0001437749-26-014882:notes:27]
[same as prior period, unchanged from 0001437749-25-033048:notes:32]

[0001437749-26-014882:notes:28]
In  March 2020, the Company entered into three interest rate swap agreements, which were still outstanding as of  March 31, 2026. In  July 2025, in conjunction with the amendments to the Company’s credit agreements discussed further in Note 12, “Credit Agreements”, the Company modified its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive income (loss) in the condensed consolidated balance sheets.

[0001437749-26-014882:notes:29]
The amount of after-tax unrealized losses recognized in accumulated other comprehensive income (loss) for the three months ended  March 31, 2026 and 2025 were $1,515 and $4,313, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-26-014882:notes:30]
[same as prior period, unchanged from 0001437749-25-033048:notes:35]

[0001437749-26-014882:notes:31]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox to purchase 5% of its Class A common stock and acquire stock warrants, the latter of which provide the right to acquire incremental Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024 and the first, second, and fourth quarters of 2025, the Company received additional warrants under the anti-dilution protection rights in connection with additional rounds of funding performed by Wallbox. In accordance with U.S. GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the condensed consolidated statements of comprehensive income.

[0001437749-26-014882:notes:32]
The loss attributable to the stock warrants was $1,635 and $3,356 for the three months ended  March 31, 2026 and 2025, respectively.

[0001437749-26-014882:notes:33]
[same as prior period, unchanged from 0001437749-25-033048:notes:38]

[0001437749-26-014882:notes:34]
[same as prior period, unchanged from 0001437749-25-033048:notes:39]

[0001437749-26-014882:notes:35]
|  |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Interest rate swaps |  | $ | 9,256 |  |  | $ | 11,272 |  |
| Stock warrants |  |  | 445 |  |  |  | 2,080 |  |

[0001437749-26-014882:notes:36]
The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the condensed consolidated balance sheets as of  March 31, 2026 and  December 31, 2025. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  March 31, 2026 and  December 31, 2025 was an asset of $9,559 and $11,604, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-26-014882:notes:37]
[same as prior period, unchanged from 0001437749-25-033048:notes:42]

[0001437749-26-014882:notes:38]
[same as prior period, unchanged from 0001437749-25-033048:notes:43]

[0001437749-26-014882:notes:39]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility (Revolving Facility) borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the New Tranche A Term Loan Facility borrowing, which has a net carrying value of $696,949, was approximately $693,000 (Level 2) as of  March 31, 2026. The fair value of the Term Loan B Facility borrowing, which has a net carrying value of $490,140, was approximately $494,963 (Level 2) as of  March 31, 2026. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-26-014882:notes:40]
[same as prior period, unchanged from 0001437749-25-033048:notes:45]

[0001437749-26-014882:notes:41]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these warrants is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in 2025, 2024, and 2023 expire at the earlier of when the price per share equals or exceeds $120.00 or in 2028, 2028, and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-26-014882:notes:42]
[same as prior period, unchanged from 0001437749-25-033048:notes:47]

[0001437749-26-014882:notes:43]
Equity securities primarily consist of Wallbox Shares. During the third quarter of 2024, the Company invested an incremental $35,000 in additional Wallbox Shares. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $4,724 and $4,457 as of  March 31, 2026, and  December 31, 2025, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the condensed consolidated statements of comprehensive income. The gain (loss) recognized on the Wallbox Shares was $267 and $(6,591) for the three months ended  March 31, 2026 and 2025, respectively.

[0001437749-26-014882:notes:44]
[same as prior period, unchanged from 0001437749-25-033048:notes:49]

[0001437749-26-014882:notes:45]
[same as prior period, unchanged from 0001437749-25-033048:notes:50]

[0001437749-26-014882:notes:46]
The combined fair value of contingent consideration for the Chilicon Power LLC (Chilicon), Ageto, and PR Industrial S.r.l. (Pramac) acquisitions as of  March 31, 2026, and  December 31, 2025, was $29,266 and $32,872, respectively. The contingent consideration period for Pramac ended as of  December 31, 2025. The contingent consideration for Chilicon extends through  December 31, 2028, and is paid annually based on incremental earnings and upon achievement of certain milestones. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration earned as of  August 1, 2025, and the remaining two increments capable of being earned on  August 1, 2026 and  August 1, 2027. The current portion of contingent consideration totals $10,357 and is reported in other accrued liabilities, and the non-current portion totals $18,909 and is reported in operating lease and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-26-014882:notes:47]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-26-014882:notes:48]
| Beginning balance, January 1, 2026 |  | $ | 32,872 |  |
| Payment of contingent consideration (1) |  |  | (3,917 | ) |
| Present value interest accretion |  |  | 310 |  |
| Ending balance, March 31, 2026 |  | $ | 29,266 |  |

[0001437749-26-014882:notes:49]
(1) Represents payment of $3,917 in shares for the Chilicon acquisition. The payment of common stock is accounted for as a non-cash item in the condensed consolidated statement of cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-26-014882:notes:50]
[same as prior period, unchanged from 0001437749-25-033048:notes:55]

[0001437749-26-014882:notes:51]
The following table presents a disclosure of changes in Accumulated Other Comprehensive Income (Loss) during the three months ended  March 31, 2026 and 2025, net of tax:

[0001437749-26-014882:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2026 |  | $ | (7,030 | ) |  |  | $ | 7,904 |  |  |  | $ | 874 |  |
| Other comprehensive loss |  |  | (16,889 | ) | (1) |  |  | (1,515 | ) | (2) |  |  | (18,404 | ) |
| Ending Balance – March 31, 2026 |  | $ | (23,919 | ) |  |  | $ | 6,389 |  |  |  | $ | (17,530 | ) |

[0001437749-26-014882:notes:53]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2025 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |
| Other comprehensive income (loss) |  |  | 29,272 |  | (3) |  |  | (4,313 | ) | (4) |  |  | 24,959 |  |
| Ending Balance – March 31, 2025 |  | $ | (76,894 | ) |  |  | $ | 16,454 |  |  |  | $ | (60,440 | ) |

[0001437749-26-014882:notes:54]
|  | (1) | Represents an unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2026, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized losses of $2,016 on the interest rate swaps, net of tax benefit of $501, for the three months ended March 31, 2026. |
|  | (3) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three months ended March 31, 2025, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized losses of $5,732 on the interest rate swaps, net of tax benefit of $1,419, for the three months ended March 31, 2025. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-26-014882:notes:55]
[same as prior period, unchanged from 0001437749-25-033048:notes:62]

[0001437749-26-014882:notes:56]
On  March 25, 2026, the Company announced its plan to reorganize its two reportable segments, effective  March 31, 2026 (the Reorganization). The Company’s Chief Operating Decision Maker (CODM) is Aaron Jagdfeld, President and Chief Executive Officer (CEO). The Reorganization reflects a change in how the CODM evaluates the Company’s operations and performance to better align reporting with the way the business is managed. Prior to the Reorganization, the Company's reportable segments were Domestic and International. As a result of the Reorganization, the Company's new reportable segments are Residential and Commercial & Industrial (C&I).  While Residential and C&I include similar products, they differ based on power output and end customer.

[0001437749-26-014882:notes:57]
The Residential segment consists of the former Domestic segment, excluding the domestic C&I operations.  Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices and solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. Residential segment revenue consists of product sales to the Company's distribution partners, who in turn sell the product to the end consumer, sometimes including installation and maintenance services. The Residential segment revenue also includes sales of products and services related to aftermarket service parts, the amortization of extended warranty deferred revenue, and remote monitoring subscription revenue. In some cases, residential products are sold directly to the end consumer. The majority of Residential segment revenues are recorded at a point in time when control is transferred to the customer. The remaining revenue, primarily related to extended warranty and other services, is recognized over the period the related services are performed.

[0001437749-26-014882:notes:58]
The C&I segment consists of the operations of the former International segment with the addition of the domestic Commercial & Industrial operations. Commercial & Industrial products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and  related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction (EPC) companies, equipment rental companies, and equipment distributors. C&I segment revenue consists of product sales to the Company's distribution partners, who in turn sell or rent the product to the end customer, sometimes including installation and maintenance services. The C&I segment revenue also includes sales of products and services related to aftermarket service parts and product accessories sold to the Company's distribution partners, grid services subscription revenue, as well as certain installation and maintenance service revenue. In some cases, C&I products are sold directly to the end customer. C&I segment revenues are recorded at either a point in time when control is transferred to the customer, or if the performance obligation is satisfied over time, then revenue is recognized using a method that reflects the performance under the contract.

[0001437749-26-014882:notes:59]
Segment financial information for the prior periods has been recast to conform to the current presentation.

[0001437749-26-014882:notes:60]
The composition of net sales between Residential and Commercial & Industrial reportable segments is as follows:

[0001437749-26-014882:notes:61]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Residential |  | $ | 549,316 |  |  | $ | 2,867 |  |  | $ | 552,183 |  |  | $ | 543,115 |  |  | $ | 5,548 |  |  | $ | 548,663 |  |
| Commercial & Industrial |  |  | 510,049 |  |  |  | 49 |  |  |  | 510,098 |  |  |  | 399,006 |  |  |  | - |  |  |  | 399,006 |  |
| Intercompany eliminations |  |  | - |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  | - |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Total net sales |  | $ | 1,059,365 |  |  | $ | - |  |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |

[0001437749-26-014882:notes:62]
The Company views Adjusted EBITDA as a key measure of the Company's performance. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements. The Company presents Adjusted EBITDA not only due to its importance for purposes of the Company's credit agreements, but also because it assists the Company in comparing performance across reporting periods on a consistent basis as it excludes items the Company's management does not believe are indicative of the Company's core operating performance. The CODM uses Adjusted EBITDA, along with the Company's management:

[0001437749-26-014882:notes:63]
|  | ● | for planning purposes, including the preparation of the Company's annual operating budget and developing and refining internal projections for future periods; |
|  | ● | to allocate resources to enhance the financial performance of the Company's business; |
|  | ● | as a target for the determination of the bonus component of compensation for the Company's senior executives under the Company's management incentive plan, as described further in the Company's proxy statement; |
|  | ● | to evaluate the effectiveness of the Company's business strategies and as a tool in evaluating the Company's performance against the Company's budget for each period; and |
|  | ● | in communications with the Company's Board of Directors and investors concerning the Company's financial performance. |

[0001437749-26-014882:notes:64]
[same as prior period, unchanged from 0001437749-25-033048:notes:74]

[0001437749-26-014882:notes:65]
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
|  |  | Residential |  |  | Commercial & Industrial |  |  | Corporate & Eliminations (*) |  |  | Total |  |  | Residential |  |  | Commercial & Industrial |  |  | Corporate & Eliminations (*) |  |  | Total |  |
| External net sales |  | $ | 549,316 |  |  | $ | 510,049 |  |  | $ | - |  |  | $ | 1,059,365 |  |  | $ | 543,115 |  |  | $ | 399,006 |  |  | $ | - |  |  | $ | 942,121 |  |
| Intersegment sales |  |  | 2,867 |  |  |  | 49 |  |  |  | - |  |  |  | 2,916 |  |  |  | 5,548 |  |  |  | - |  |  |  | - |  |  |  | 5,548 |  |
| Total sales |  |  | 552,183 |  |  |  | 510,098 |  |  |  | - |  |  |  | 1,062,281 |  |  |  | 548,663 |  |  |  | 399,006 |  |  |  | - |  |  |  | 947,669 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  |  |  |  |  |  |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Costs of goods sold |  |  | 280,955 |  |  |  | 371,090 |  |  |  | - |  |  |  | 652,045 |  |  |  | 289,902 |  |  |  | 285,781 |  |  |  | - |  |  |  | 575,683 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  |  |  |  |  |  |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Operating expenses |  |  | 176,617 |  |  |  | 102,481 |  |  |  | 13,847 |  |  |  | 292,945 |  |  |  | 185,228 |  |  |  | 90,373 |  |  |  | 12,747 |  |  |  | 288,348 |  |
| Other segment items (1) |  |  | (43,974 | ) |  |  | (30,005 | ) |  |  | (2,211 | ) |  |  | (76,190 | ) |  |  | (38,056 | ) |  |  | (22,494 | ) |  |  | (5,358 | ) |  |  | (65,908 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 138,585 |  |  | $ | 66,532 |  |  | $ | (11,636 | ) |  | $ | 193,481 |  |  | $ | 111,589 |  |  | $ | 45,346 |  |  | $ | (7,389 | ) |  | $ | 149,546 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (15,376 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (17,110 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (55,974 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (46,141 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,443 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 13 |  |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (13,442 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (11,608 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2,710 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (760 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1,153 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1,575 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3,206 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3,751 | ) |
| Change in fair value of investments (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1,374 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (9,947 | ) |
| Other (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4,930 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (153 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 96,759 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 58,514 |  |

[0001437749-26-014882:notes:66]
|  | (*) | The 'Corporate & Eliminations' column includes general corporate overhead, centrally managed costs not allocated to the reportable segments, and the elimination of intersegment revenues and profits. These costs primarily relate to certain legal, accounting, human resources, technology functions, and other costs related to the Corporate headquarters. |
|  | (1) | Other segment items primarily represent depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; and Provision for legal, regulatory, and other costs. |
|  | (2) | Includes gains (losses) on dispositions of assets other than in the ordinary course of business, gains (losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |
|  | (3) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's credit agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (6) | Represents the following significant litigation, regulatory, and other matters that are not indicative of the Company's ongoing operations: |

[0001437749-26-014882:notes:67]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Legal expenses, judgements and settlements related to certain patent lawsuits |  | $ | 2,447 |  |  | $ | 1,492 |  |
| Legal expenses, judgements and settlements related to certain class action lawsuits |  |  | 1,026 |  |  |  | 1,343 |  |
| Legal expenses related to certain government inquiries and other significant matters |  |  | 862 |  |  |  | 916 |  |
| Release of warranty provision recorded in 2022 to address clean energy warranty-related matters |  |  | (1,129 | ) |  |  | - |  |
| Total provision for legal, regulatory and other matters |  | $ | 3,206 |  |  | $ | 3,751 |  |

[0001437749-26-014882:notes:68]
|  | (7) | Represents non-cash gains (losses) primarily from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (8) | The current year loss relates primarily to two immaterial business dispositions that closed in the first quarter of 2026. |

[0001437749-26-014882:notes:69]
[same as prior period, unchanged from 0001437749-25-033048:notes:81]

[0001437749-26-014882:notes:70]
|  |  | Assets by Reportable Segment |  |
|  |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Residential |  | $ | 3,039,205 |  |  | $ | 3,144,332 |  |
| Commercial & Industrial |  |  | 2,497,864 |  |  |  | 2,367,764 |  |
| Corporate |  |  | 56,194 |  |  |  | 61,583 |  |
| Total |  | $ | 5,593,263 |  |  | $ | 5,573,679 |  |

[0001437749-26-014882:notes:71]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Residential |  | $ | 32,216 |  |  | $ | 28,885 |  |
| Commercial & Industrial |  |  | 23,487 |  |  |  | 16,993 |  |
| Corporate |  |  | 271 |  |  |  | 263 |  |
| Total |  | $ | 55,974 |  |  | $ | 46,141 |  |

[0001437749-26-014882:notes:72]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Residential |  | $ | 12,811 |  |  | $ | 16,127 |  |
| Commercial & Industrial |  |  | 15,458 |  |  |  | 13,088 |  |
| Corporate |  |  | 1,128 |  |  |  | 1,722 |  |
| Total |  | $ | 29,397 |  |  | $ | 30,937 |  |

[0001437749-26-014882:notes:73]
The Company’s sales in the U.S. represented approximately 78% of total sales for both the three months ended  March 31, 2026 and 2025. Approximately 76% and 74% of the Company's identifiable long-lived assets were located in the U.S. as of  March 31, 2026 and  December 31, 2025, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-26-014882:notes:74]
[same as prior period, unchanged from 0001437749-25-033048:notes:88]

[0001437749-26-014882:notes:75]
[same as prior period, unchanged from 0001437749-25-033048:notes:89]

[0001437749-26-014882:notes:76]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Raw material |  | $ | 675,079 |  |  | $ | 705,610 |  |
| Work-in-process |  |  | 12,726 |  |  |  | 12,592 |  |
| Finished goods |  |  | 563,988 |  |  |  | 530,665 |  |
| Total |  | $ | 1,251,793 |  |  | $ | 1,248,867 |  |

[0001437749-26-014882:notes:77]
[same as prior period, unchanged from 0001437749-25-033048:notes:91]

[0001437749-26-014882:notes:78]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Land and improvements |  | $ | 37,041 |  |  | $ | 31,937 |  |
| Buildings and improvements |  |  | 464,038 |  |  |  | 444,171 |  |
| Machinery and equipment |  |  | 390,288 |  |  |  | 374,791 |  |
| Dies and tools |  |  | 66,549 |  |  |  | 63,666 |  |
| Vehicles |  |  | 19,485 |  |  |  | 19,743 |  |
| Office & information technology equipment and internal use software |  |  | 265,658 |  |  |  | 252,425 |  |
| Leasehold improvements |  |  | 10,889 |  |  |  | 10,670 |  |
| Construction in progress |  |  | 62,818 |  |  |  | 86,116 |  |
| Gross property and equipment |  |  | 1,316,766 |  |  |  | 1,283,519 |  |
| Accumulated depreciation |  |  | (497,142 | ) |  |  | (469,914 | ) |
| Total |  | $ | 819,624 |  |  | $ | 813,605 |  |

[0001437749-26-014882:notes:79]
Total property and equipment includes finance leases of $82,513 and $83,963 as of  March 31, 2026, and  December 31, 2025, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.

[0001437749-26-014882:notes:80]
Other accrued liabilities consist of the following:

[0001437749-26-014882:notes:81]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Accrued selling expenses |  | $ | 103,785 |  |  | $ | 118,962 |  |
| Current contract liabilities |  |  | 142,421 |  |  |  | 153,745 |  |
| Accrued legal & professional fees |  |  | 250,142 |  |  |  | 248,445 |  |
| Current operating lease liabilities |  |  | 11,876 |  |  |  | 15,731 |  |
| Accrued other (1) |  |  | 69,203 |  |  |  | 54,504 |  |
| Total |  | $ | 577,427 |  |  | $ | 591,387 |  |

[0001437749-26-014882:notes:82]
(1) Accrued other contains a certain recall reserve for the total amount of $9,228 as of  March 31, 2026, that is recoverable from a certain supplier.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-26-014882:notes:83]
9.   Goodwill

[0001437749-26-014882:notes:84]
As described in Note 7, "Segment Reporting," effective  March 31, 2026, the Company reorganized its reportable segments into Residential and C&I.  As a result, the composition of the reporting units changed. The Company reassigned goodwill to the affected reporting units using a relative fair value allocation approach.

[0001437749-26-014882:notes:85]
The Company concluded that the change in reporting unit composition represented a triggering event and performed an interim quantitative goodwill impairment test for the reporting units affected by the reorganization. The impairment test compared the carrying amount of each affected reporting unit, including goodwill, with its estimated fair value.

[0001437749-26-014882:notes:86]
As a result of this test, the Company recorded $1,523 of goodwill impairment for one reporting unit within the Residential segment.  For the remaining affected reporting units, the Company concluded that estimated fair value exceeded carrying amount and no additional impairment was recognized.

[0001437749-26-014882:notes:87]
The changes in the carrying amount of goodwill by reportable segment are as follows:

[0001437749-26-014882:notes:88]
|  |  | Residential |  |  | Commercial & Industrial |  |  | Total |  |
| Balance as of December 31, 2025 |  | $ | 855,118 |  |  | $ | 611,976 |  |  | $ | 1,467,094 |  |
| Acquisitions and dispositions of businesses, net |  |  | - |  |  |  | 28,263 |  |  |  | 28,263 |  |
| Impairment charge |  |  | (1,523 | ) |  |  | - |  |  |  | (1,523 | ) |
| Foreign currency translation rate changes |  |  | (27 | ) |  |  | (7,000 | ) |  |  | (7,027 | ) |
| Balance as of March 31, 2026 |  | $ | 853,568 |  |  | $ | 633,239 |  |  | $ | 1,486,807 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-26-014882:notes:89]
10.   Product Warranty Obligations

[0001437749-26-014882:notes:90]
[same as prior period, unchanged from 0001437749-25-033048:notes:95]

[0001437749-26-014882:notes:91]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Balance at beginning of period |  | $ | 131,922 |  |  | $ | 110,987 |  |
| Payments |  |  | (23,976 | ) |  |  | (20,887 | ) |
| Provision for warranty issued |  |  | 19,029 |  |  |  | 18,118 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,250 |  |  |  | 2,499 |  |
| Warranty reserve assumed in acquisition |  |  | 129 |  |  |  | - |  |
| Balance at end of period |  | $ | 128,354 |  |  | $ | 110,717 |  |

[0001437749-26-014882:notes:92]
[same as prior period, unchanged from 0001437749-25-033048:notes:97]

[0001437749-26-014882:notes:93]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Balance at beginning of period |  | $ | 219,404 |  |  | $ | 186,922 |  |
| Deferred revenue contracts issued |  |  | 16,822 |  |  |  | 15,818 |  |
| Amortization of deferred revenue contracts |  |  | (9,595 | ) |  |  | (8,337 | ) |
| Balance at end of period |  | $ | 226,631 |  |  | $ | 194,403 |  |

[0001437749-26-014882:notes:94]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  March 31, 2026 is as follows:

[0001437749-26-014882:notes:95]
| Remainder of 2026 |  | $ | 30,404 |  |
| 2027 |  |  | 42,859 |  |
| 2028 |  |  | 40,628 |  |
| 2029 |  |  | 33,826 |  |
| 2030 |  |  | 26,527 |  |
| After 2030 |  |  | 52,387 |  |
| Total |  | $ | 226,631 |  |

[0001437749-26-014882:notes:96]
[same as prior period, unchanged from 0001437749-25-033048:notes:101]

[0001437749-26-014882:notes:97]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 41,622 |  |  | $ | 44,716 |  |
| Long-term portion - other long-term liabilities |  |  | 86,732 |  |  |  | 87,206 |  |
| Total |  | $ | 128,354 |  |  | $ | 131,922 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 41,307 |  |  | $ | 38,958 |  |
| Long-term portion - deferred revenue |  |  | 185,324 |  |  |  | 180,446 |  |
| Total |  | $ | 226,631 |  |  | $ | 219,404 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-26-014882:notes:98]
11.   Contract Liabilities

[0001437749-26-014882:notes:99]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods or services; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears after shipment of the product to the customer or performance of the service. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable or as prepaid expenses and other current assets upon revenue recognition, while contracts where customers pay in advance of performance are recognized as deferred revenue and recorded in other accrued liabilities (for the portion expected to be recognized within twelve months) or long-term deferred revenue (for the portion not expected to be recognized within twelve months) in the condensed consolidated balance sheets, until revenue is recognized.

[0001437749-26-014882:notes:100]
The balance of customer deposits and other contract liabilities, excluding the extended warranty deferred revenue balance disclosed in Note 10, was $137,438 and $151,257 as of  March 31, 2026, and  December 31, 2025, respectively. During the three months ended  March 31, 2026, the Company recognized revenue of $46,832 related to amounts included in the  December 31, 2025 contract liability balance. As of  March 31, 2026, the aggregate amount of revenue that the Company expects to recognize on remaining performance obligations (excluding extended warranty) was approximately $272,000, of which approximately 90% is expected to be recognized as revenue over the next two years. We have applied the practical expedient to exclude the value of remaining performance obligations for contracts with an original term of one year or less.


## us-gaap:DebtDisclosureTextBlock

[0001437749-26-014882:notes:101]
12.   Credit Agreements

[0001437749-26-014882:notes:102]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2026, and  December 31, 2025, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $43,950 and $50,618, respectively. As of  March 31, 2026, the weighted-average interest rate on the short-term borrowings was 6.19%.

[0001437749-26-014882:notes:103]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-26-014882:notes:104]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 700,000 |  |
| Term Loan B Facility |  |  | 492,500 |  |  |  | 493,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,411 | ) |  |  | (5,673 | ) |
| Revolving Facility |  |  | - |  |  |  | - |  |
| Finance lease obligations |  |  | 90,203 |  |  |  | 90,915 |  |
| Other |  |  | 2,635 |  |  |  | 3,456 |  |
| Total |  |  | 1,279,927 |  |  |  | 1,282,448 |  |
| Less: current portion of debt |  |  | 16,303 |  |  |  | 12,729 |  |
| Less: current portion of finance lease obligations |  |  | 10,087 |  |  |  | 9,463 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,253,537 |  |  | $ | 1,260,256 |  |

[0001437749-26-014882:notes:105]
As of  March 31, 2026, there were $4,712 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the condensed consolidated balance sheets, and $5,411 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the condensed consolidated balance sheets.

[0001437749-26-014882:notes:106]
The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030.  The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on  March 31, 2026, before considering original issue discount and deferred financing costs, were as follows:

[0001437749-26-014882:notes:107]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2026 |  | $ | 4,375 |  |  | $ | 3,750 |  |  | $ | - |  |  | $ | 8,125 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 600,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 492,500 |  |  | $ | - |  |  | $ | 1,192,500 |  |

[0001437749-26-014882:notes:108]
The Company’s credit agreements originally provided for a
    $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a
    $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of
    0.75% or adjusted SOFR rate plus an applicable margin of
    1.75%, subject to a SOFR floor of
    0.0%, and was scheduled to mature on
     December 13, 2026.

[0001437749-26-014882:notes:109]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 5.42% combined rate as of  March 31, 2026.

[0001437749-26-014882:notes:110]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  March 31, 2026, the Company’s net secured leverage ratio was 1.31 to 1.00, and the Company was in compliance with all covenants under the facility. There are no financial maintenance covenants on the Term Loan B Facility.

[0001437749-26-014882:notes:111]
The Company's original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-26-014882:notes:112]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Original Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%. Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements. As of  March 31, 2026, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 4.92%.

[0001437749-26-014882:notes:113]
In accordance with AS
      C 470-50, the Company capitalized $5,275 of debt issuance costs related to this transaction. Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of $443 and expensed $782 of third-party fees as a loss on refinancing of debt.

[0001437749-26-014882:notes:114]
Both the New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2026, the Company’s total leverage ratio was 1.37 to 1.00, and the Company's interest coverage ratio was 12.98 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of  March 31, 2026.

[0001437749-26-014882:notes:115]
The New Term Loan B Facility, New Tranche A Term Loan Facility and New Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-26-014882:notes:116]
As of  March 31, 2026, there were no amounts outstanding under the New Revolving Facility, leaving $999,250 of unused capacity, net of outstanding letters of credit.

[0001437749-26-014882:notes:117]
See Item 7A of the Annual Report on Form 10-K for the year ended  December 31, 2025, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:TreasuryStockTextBlock

[0001437749-26-014882:notes:118]
13.   Stock Repurchase Program

[0001437749-26-014882:notes:119]
On  February 12, 2024, the Company's Board of Directors approved a stock repurchase program that allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 9, 2026, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the following 24 months. The new program replaces the prior share repurchase program, which had $199,340 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-26-014882:notes:120]
During the first quarter of 2026, there were no share repurchases under the program. For the three months ended  March 31, 2025, the Company repurchased 716,685 shares of common stock for $97,454. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-26-014882:notes:121]
14. Earnings Per Share

[0001437749-26-014882:notes:122]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested "in the money" restricted stock and the exercise of outstanding "in the money" stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interests,” of the Annual Report on Form 10-K for the year ended  December 31, 2025, for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-26-014882:notes:123]
[same as prior period, unchanged from 0001437749-25-033048:notes:127]

[0001437749-26-014882:notes:124]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Net income attributable to common shareholders |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 58,412,205 |  |  |  | 59,062,534 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 820,939 |  |  |  | 685,055 |  |
| Weighted average shares, diluted |  |  | 59,233,144 |  |  |  | 59,747,589 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.25 |  |  | $ | 0.74 |  |
| Diluted |  | $ | 1.24 |  |  | $ | 0.73 |  |

[0001437749-26-014882:notes:125]
(1) Excludes approximately 178,000 and 402,000 stock options and restricted stock awards for the three months ended  March 31, 2026 and 2025, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-26-014882:notes:126]
15. Income Taxes

[0001437749-26-014882:notes:127]
The effective income tax rates for the three months ended  March 31, 2026 and 2025 were 24.4% and 24.3%, respectively. The slight increase in effective tax rate was due primarily to certain discrete items and their impact on higher pre-tax income in the quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-26-014882:notes:128]
16. Commitments and Contingencies

[0001437749-26-014882:notes:129]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  March 31, 2026, and  December 31, 2025, was $162,314 and $149,737, respectively.

[0001437749-26-014882:notes:130]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred.  The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee decided to pursue PHS’s claims against Generac in arbitration. Generac Power intends to vigorously defend against the claims and contends that PHS cannot recover certain damages on behalf of its customers upon final approval of the settlement in the Multidistrict Litigation described below to the extent the claims relate to the performance of a certain solar system component. The arbitration hearing is expected to occur in  June 2027.

[0001437749-26-014882:notes:131]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis. The parties have obtained preliminary approval for the classwide settlement and will be seeking final approval.  In the third quarter of 2025, Generac Power recorded a reserve for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.

[0001437749-26-014882:notes:132]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025. On  April 30, 2026, the court granted the Company’s motion to dismiss the amended complaint with prejudice, again finding that plaintiffs failed to adequately plead a securities fraud claim, and directed the entry of final judgment in favor of the Company. Plaintiffs  may appeal the dismissal. If an appeal is filed, the Company intends to vigorously defend the judgment.

[0001437749-26-014882:notes:133]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-26-014882:notes:134]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics, various voluntary self-disclosures the Company has made to the EPA since 2024, and other ancillary requests for information.

[0001437749-26-014882:notes:135]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest and continues to accrue for post-judgment interest thereafter. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-26-014882:notes:136]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserted claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff sought to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and sought unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). On  February 3, 2026, the court granted the Company’s motion to dismiss the amended complaint and found that plaintiff failed to adequately plead a securities fraud claim. Plaintiff did not appeal the dismissal, so it is final.

[0001437749-26-014882:notes:137]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company was named as a nominal defendant) generally alleged, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. Following the dismissal of the Walling Lawsuit, plaintiff voluntarily dismissed the shareholder derivative action.

[0001437749-26-014882:notes:138]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs pursued claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. On  January 26, 2026, the Company, together with other co-defendants, agreed to enter a settlement in principle to resolve all asserted claims, while denying any wrongdoing, to eliminate the uncertainty, burden, and expense of protracted litigation. The Company agreed to pay $104,500 in addition to the Company’s excess insurance for the applicable policy year. As of  March 31, 2026 and  December 31, 2025, the Company has reflected a reserve for $206,500 within other accrued liabilities and an insurance receivable for $102,000 in prepaid expenses and other assets in the condensed consolidated balance sheets. The Company and its insurance carriers satisfied the payment obligation on  April 1, 2026.

[0001437749-26-014882:notes:139]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies. Champion in turn filed new patent infringement claims relating to its own carbon monoxide detection and shutoff technology. Generac Power denies the infringement allegations and intends to vigorously defend the matter.

[0001437749-26-014882:notes:140]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The court dismissed (1) all claims against the Company and (2) all non-Florida residents’ claims against Generac Power for lack of personal jurisdiction, and limited the Florida plaintiffs’ claims against Generac Power to a claim for breach of express warranty.  The Company disputes the allegations and intends to vigorously defend against the remaining claims in the Amended Complaint, including that the case should not proceed as a class action.

[0001437749-26-014882:notes:141]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:SubsequentEventsTextBlock

[0001437749-26-014882:notes:142]
17. Subsequent Events

[0001437749-26-014882:notes:143]
On  April 1, 2026, the Company acquired Enercon Engineering, Inc. (Enercon) headquartered in East Peoria, Illinois. Enercon designs and manufactures custom power equipment and industrial enclosures for high-reliability applications, strengthening the  Company’s ability to service hyperscale and enterprise data center markets. The preliminary purchase price totaled $122,322, of which $44,785 was paid in restricted shares and the remainder in cash.  Additional contingent consideration  may be earned up to a maximum amount of $112,043, with 35% paid in restricted shares and the remainder in cash, upon the achievement of certain conditions.  The earnout period extends through  April 1, 2027.  Due to the close proximity of the acquisition date and the Company's filing of its interim financial information on Form 10-Q for the three months ended  March 31, 2026, the initial accounting for the business combination is not yet complete and is pending identification and measurement of the assets acquired and liabilities assumed. Accordingly, the information required by ASC 805, Business Combinations, will be disclosed in the Company's subsequent Form 10-Q.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-26-014882:notes:144]
[same as prior period, unchanged from 0001437749-25-033048:notes:150]

[0001437749-26-014882:notes:145]
On  March 5, 2026, Raj Kanuru, Executive Vice President, General Counsel & Secretary, adopted a Rule 10b5-1 trading plan that is intended to satisfy the affirmative defense in Rule 10b5-1(c) for the (i) sale of up to 2,165 shares of the Company’s common stock, and (ii) exercise and sale of up to 4,514 stock options, until  February 12, 2027.

[0001437749-26-014882:notes:146]
On  March 6, 2026, Norm Taffe, President, Generac Home, adopted a Rule 10b5-1 trading plan that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the (i) sale of up to 3,000 shares of the Company’s common stock, and (ii) exercise and sale of up to 2,500 stock options, until  March 8, 2027.
