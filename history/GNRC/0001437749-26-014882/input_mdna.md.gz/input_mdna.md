# GNRC MD&A — 0001437749-26-014882


## mdna

[0001437749-26-014882:mdna:1]
[same as prior period, unchanged from 0001437749-25-033048:mdna:1]

[0001437749-26-014882:mdna:2]
[same as prior period, unchanged from 0001437749-25-033048:mdna:2]

[0001437749-26-014882:mdna:3]
[same as prior period, unchanged from 0001437749-25-033048:mdna:3]

[0001437749-26-014882:mdna:4]
[same as prior period, unchanged from 0001437749-25-033048:mdna:4]

[0001437749-26-014882:mdna:5]
[same as prior period, unchanged from 0001437749-25-033048:mdna:5]

[0001437749-26-014882:mdna:6]
[same as prior period, unchanged from 0001437749-25-033048:mdna:6]

[0001437749-26-014882:mdna:7]
[same as prior period, unchanged from 0001437749-25-033048:mdna:7]

[0001437749-26-014882:mdna:8]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | our ability to develop and enhance products and gain customer acceptance, including our offerings that serve the data center and energy technology markets; |
|  | ● | uncertainty regarding the growth of the data center market; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | scrutiny regarding our sustainability practices |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | risks due to instability caused by geopolitical conflicts; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-26-014882:mdna:9]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2025 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-26-014882:mdna:10]
[same as prior period, unchanged from 0001437749-25-033048:mdna:13]

[0001437749-26-014882:mdna:11]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. Generac provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. The Company’s broad portfolio of energy technology offerings for homes and businesses enables its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and innovative energy solutions.

[0001437749-26-014882:mdna:12]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading positions in the North American market for power equipment with an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial, and industrial standby generators, as well as portable and mobile generators used in a variety of applications. The recent introduction of our large-megawatt diesel generator line-up has substantially increased our served addressable market, allowing us to participate in the supply-constrained data center market which is expected to grow significantly over the coming years due to the mass adoption of artificial intelligence. Over the last few years, we have also been focused on building out ecosystems of energy technology products, solutions, and services for homes and businesses, allowing us to fully integrate our product portfolios together into common platforms and user interfaces and enabling end users to better manage their energy resilience and costs. We have also been leveraging our leading position in the growing market for natural gas fueled generators, which we believe represents a cleaner fuel compared to diesel, to develop solutions for applications beyond standby power, allowing us to participate in multipurpose microgrid projects for C&I customers. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will develop, and our energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid.

[0001437749-26-014882:mdna:13]
Given our competitive strengths in our traditional power generation markets, we believe we are well-positioned to execute on the growing opportunity for backup power for homes and businesses, where increased penetration is being driven by multiple mega-trends that are resulting in poorer power quality for end users. In addition, our focus on more resilient, efficient and innovative energy solutions has increased our served addressable market, and as a result, we believe we can provide products that can help offset rising energy costs as the traditional utility grid suffers from significant supply/demand imbalances over time.

[0001437749-26-014882:mdna:14]
[same as prior period, unchanged from 0001437749-25-033048:mdna:17]

[0001437749-26-014882:mdna:15]
Our “Powering a Smarter World” strategic plan serves as the framework for the significant investments that we have made, and will continue to make, to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is derived from certain key mega-trends that we believe will drive various strategic growth themes for our business. Those mega-trends and growth themes are as follows:

[0001437749-26-014882:mdna:16]
[same as prior period, unchanged from 0001437749-25-033048:mdna:19]

[0001437749-26-014882:mdna:17]
| ● | Lower power quality continuing to drive demand for backup power solutions: |
|  | ○ | More frequent severe and volatile weather impacting an aging grid, causing increased power outage activity. |
|  | ○ | Increasing deployment of intermittent generation sources coupled with accelerating electricity demand trends driving supply/demand imbalances for utilities and grid operators. |
| ● | Higher power prices driving the need for energy management solutions: |
|  | ○ | Electrification trends causing power demand to exceed supply, driving up power prices. |
|  | ○ | Investment required to upgrade grid infrastructure and transition to renewable power sources, pushing prices higher. |
| ● | Artificial intelligence adoption accelerating, creating a large market opportunity for backup power: |
|  | ○ | Significant power requirements for the buildout of data centers to enable AI adoption could drive further grid instability and higher power prices. |
|  | ○ | Massive capital investment into hyperscale and edge data centers has created a very large market for back-up power that is supply-constrained, providing a significant growth opportunity for our newly introduced large-megawatt C&I products. |
| ● | Growing demand for cleaner burning fuels: |
|  | ○ | Natural gas and other alternative fuels are vital to the energy transition. |
|  | ○ | Demand for natural gas-fueled backup generators growing as homes and businesses desire cleaner-burning fuel sources of generation. |
| ● | Required investment in global infrastructure, driving demand for our products: |
|  | ○ | Upgrading of aging and underinvested legacy infrastructure systems, such as energy production, telecommunications, transportation, and data centers. |
|  | ○ | Expanding investment for increasingly critical technology infrastructure as we transition to a more "connected" society. |

[0001437749-26-014882:mdna:18]
[same as prior period, unchanged from 0001437749-25-033048:mdna:21]

[0001437749-26-014882:mdna:19]
Power quality issues continue to increase. Power disruptions are an important driver of consumer awareness for backup power and have historically influenced demand for generators both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period. Energy storage systems offer similar resiliency advantages to consumers (at least for short duration power outages and for limited circuits) and demand for these products can benefit from these same awareness drivers. The optional standby market for C&I power generation is also driven by power quality issues and the related need for backup power.

[0001437749-26-014882:mdna:20]
The impact of climate change has received increased global focus in recent years, and an aging and under-invested electrical grid infrastructure remains highly vulnerable to potentially more severe and volatile weather. Additionally, growth in renewable power sources (such as solar and wind) is resulting in increased intermittency of supply as traditional thermal generation assets are retired, further impairing the reliable supply of electricity. At the same time, power demand is expected to meaningfully accelerate due to (i) the rapid adoption of artificial intelligence and related data center energy requirements, (ii) the re-industrialization of North America, and (iii) the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. These developments are causing a growing supply/demand imbalance for grid operators across the world, which has led to high-profile examples of rolling blackouts and calls for utility customers to reduce consumption to maintain grid integrity. In fact, the North American Electric Reliability Corporation has labeled significant portions of the United States and Canada as being at high or elevated risk of resource adequacy shortfalls in the 2025-2029 period due in part to these supply/demand dynamics. We believe utility supply shortfalls and related warnings may continue in the future, resulting in further power quality issues for the world’s electrical grid. Finally, certain utilities are adopting preventative power shutoff policies to reduce the risk of wildfires caused by their electrical distribution equipment, predominately in the western part of the United States. Taken together, we expect these factors to continue driving increased awareness of the need for backup power for homes and businesses which will continue to create demand for Generac’s products across the portfolio.

[0001437749-26-014882:mdna:21]
Home standby penetration opportunity is significant. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. With only approximately 6.75% penetration of the addressable market of homes in the United States (which we define as single-family detached, owner-occupied households with a home value of over $175,000, as defined by the U.S. Census Bureau's 2023 American Housing Survey for the United States), we believe there are significant opportunities to further penetrate the residential standby generator market both domestically and internationally. In addition to the mega-trends supporting growth of the category, we believe by expanding and developing our distribution network, continuing to invest in new product lines and technologies, and optimizing our marketing efforts, we can continue to build awareness and increase penetration for our home standby generators.

[0001437749-26-014882:mdna:22]
Substantial capital investments in new data centers and accelerating adoption of artificial intelligence. As a result of the development of artificial intelligence and the expected benefits of this technology, there is significant capital investment being made to build out data center infrastructure, which is expected to further accelerate adoption of artificial intelligence capabilities. Backup power solutions are a necessary part of this substantial investment in data centers. Given the significant power requirements and the mission-critical nature of these data centers, demand for large backup power generators is expected to grow at a dramatic rate for the foreseeable future. Due to all of these factors, the market for large-megawatt backup generators has become significantly supply-constrained. This presents a very large incremental opportunity for our recently introduced large-megawatt diesel generator offering. As we continue to ramp our capacity and capabilities for large megawatt generators, we believe that we are well positioned to take share in this market over time given (i) our long-standing historical focus on backup power generation, (ii) our global presence in markets around the world, (iii) our ability to provide customized product solutions via our extensive sales, engineering, and project management resources, and (iv) our robust aftermarket support through a combination of direct service teams and our global service network provided by our industrial distributor partners. Given the scale and mission-critical nature of these applications, this level of support is necessary to capture market share and serve these customers. Additionally, we believe these large data center power loads will contribute to the growing supply/demand imbalance across the broader electrical grid, resulting in continued power quality issues and increased demand for backup power solutions for all homes and businesses. Finally, we believe the significant growth in data center power consumption will cause higher power prices, driving growth in the market for solar, storage, and intelligent energy management solutions.

[0001437749-26-014882:mdna:23]
Increasingly critical nature and growing power consumption of digital infrastructure. As the number of “connected” devices continues to rapidly increase and wireless networks are considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore, necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States. As more mission-critical data is transmitted over wireless networks, we believe the penetration rate of backup generators on cell towers must increase considerably to maintain a higher level of reliability across the network. We have relationships with key Tier 1 carriers and tower companies globally, in addition to having distribution partners to provide local service support to the global market. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-26-014882:mdna:24]
Natural gas generators, a continuing growth opportunity. We believe natural gas will continue to be an important and cleaner transition fuel of the future, compared to diesel, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of many C&I end markets, as the benefits of natural gas power generation are very compelling relative to traditional diesel fueled generators for certain end users. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids, and overall use as a Distributed Energy Resource (DER) in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having the capability to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is another way that we are increasing the addressable market for natural gas generators. As a leader in natural gas power generation, we believe we are well positioned to capitalize on this strategic growth theme.

[0001437749-26-014882:mdna:25]
Solar, storage, and energy management markets will continue to develop despite phasing out of government subsidies and incentives. We believe the electric utility landscape will undergo significant changes in the decade ahead due to accelerating demand growth, grid instability and power quality issues, environmental concerns, permitting challenges, and the continuing performance and cost improvements in renewable energy and energy storage technologies. Importantly, we expect that a confluence of factors will continue to drive power prices meaningfully higher in the future. As a result, on-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity as utility customers seek alternative solutions to combat rising power prices. In addition, battery storage can also provide customers with another source of power resiliency for shorter duration outages.

[0001437749-26-014882:mdna:26]
Solar and storage markets have historically been supported by subsidies and investment tax credits for consumers and businesses to help advance the adoption of clean energy technologies. Further, production tax credits are being offered to businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. On July 4, 2025, the United States signed into law the One Big Beautiful Bill Act (OBBBA). The OBBBA accelerates the phase-out of tax incentives for the solar market and includes certain domestic supply chain requirements to qualify for these incentives. While this phase-out of tax incentives will negatively impact the solar and storage markets in the near term, we believe the overall mega-trends that drive the solar, storage, and energy management markets will continue and provide sufficient incentive for long-term, value-creating investments for market participants in this space. Given the significant long-term market opportunity, we believe it is important to build out our capabilities in energy technology and continue to develop our residential ecosystem of products and solutions. In addition, we plan to leverage our strong competencies in the residential standby generator market to increase our market position in the residential solar, storage, and energy management markets.

[0001437749-26-014882:mdna:27]
[same as prior period, unchanged from 0001437749-25-033048:mdna:28]

[0001437749-26-014882:mdna:28]
Impact of residential investment cycle. The market for our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators, solar and energy storage systems, and energy management devices. Trends in interest rates and the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. The existence of renewable energy mandates, investment tax credits, and other subsidies can also have an impact on the demand for solar and energy storage systems. The “One Big Beautiful Bill Act” (OBBBA) that was enacted in the United States in July 2025 accelerated the phase out of certain investment tax credits, resulting in a negative impact to the solar & storage market thereafter.

[0001437749-26-014882:mdna:29]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. The capital investment cycle may differ for the various C&I end markets that we serve, including data centers, light commercial, retail, office, telecommunications, rental, industrial, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions around the world, fluctuations in interest rates & foreign currencies, trade policies, and geopolitical matters and conflicts in the various countries where we serve, as well as credit availability in those regions.

[0001437749-26-014882:mdna:30]
[same as prior period, unchanged from 0001437749-25-033048:mdna:31]

[0001437749-26-014882:mdna:31]
[same as prior period, unchanged from 0001437749-25-033048:mdna:32]

[0001437749-26-014882:mdna:32]
Effect of commodity, currency, component price fluctuations, and resource availability. Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells that can fluctuate in terms of pricing and availability. Our international operations, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-26-014882:mdna:33]
Commodity, currency, and component price levels are increasingly subject to geopolitical uncertainty, including ongoing regional conflicts, shifts in U.S. and international trade policies, and the potential for new or increased tariffs. These factors, along with increased demand from data centers, have contributed to heightened volatility in commodity prices, particularly for raw materials such as steel, copper, and aluminum. Additionally, geopolitical instability can contribute to significant fluctuations in foreign currency exchange rates which can impact our reported financial performance from our foreign operations and supply chain.

[0001437749-26-014882:mdna:34]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-26-014882:mdna:35]
Tariffs and international trade relations. Given our global supply chain and international operations, our business is impacted by tariffs and other changes in U.S. trade policy and international trade relations. For example, starting in the first quarter of 2025, the United States government enacted additional tariffs on goods imported into the U.S. from numerous countries, and certain countries announced tariffs on U.S. goods. Some of these tariffs have been subsequently modified or delayed, and the U.S. government has also stated it is willing to negotiate with respect to the tariffs it has enacted.

[0001437749-26-014882:mdna:36]
We have implemented price increases across many of our product offerings and are executing a number of supply chain initiatives to attempt to mitigate the impact of these tariffs on our profitability. Despite our efforts, these tariff actions and resulting price increases have created inflationary pressures for consumers, negatively impacting demand and margins for certain of our products. As U.S. trade policy continues to evolve, we will continue to evaluate the impact of future tariffs and take actions to mitigate and/or minimize their effects.

[0001437749-26-014882:mdna:37]
On February 20, 2026, the U.S. Supreme Court issued a decision invalidating tariffs imposed under the International Emergency Economic Powers Act (“IEEPA”). This ruling may allow for the recovery of IEEPA tariff amounts previously paid. The ruling leaves uncertainties regarding the timing and administration of any potential IEEPA tariff refunds by the U.S. government, and may be subject to further legal and regulatory developments.

[0001437749-26-014882:mdna:38]
The extent and duration of the tariffs and the resulting impact on general economic conditions and on our business, including potential IEEPA tariff refunds, continues to be uncertain. If refunds are received in future periods, they could have a favorable impact on cash flows and results of operations in the period of receipt or realization. However, we cannot reasonably estimate the amount or timing of these refunds, and therefore have not reflected a related receivable as of March 31, 2026.

[0001437749-26-014882:mdna:39]
Seasonality. Although there is demand for our products throughout the year, in each of the past five years, approximately 20% to 25% of our net sales occurred in the first quarter, 23% to 28% in the second quarter, 24% to 27% in the third quarter, and 23% to 29% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. The second half of 2025 represented a very low level of baseline power outage activity, impacting demand for our residential products and resulting in quarterly net sales being more evenly distributed compared to our historical averages.

[0001437749-26-014882:mdna:40]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2025.

[0001437749-26-014882:mdna:41]
[same as prior period, unchanged from 0001437749-25-033048:mdna:37]

[0001437749-26-014882:mdna:42]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for further information. The year-over-year decrease in interest expense in the current period was primarily driven by lower borrowings and lower interest rates compared to the prior year period.

[0001437749-26-014882:mdna:43]
On July 1, 2025, we amended our Term Loan A Facility and Revolving Credit Facility, extending the maturity of both to July 1, 2030, revising the Term Loan A Facility outstanding principal balance to $700,000, reducing the Revolving Credit Facility borrowing capacity to $1,000,000, and redefining the Term Benchmark to replace the Adjusted Term SOFR Rate with the Term SOFR Rate, resulting in an interest rate reduction of 0.10%.

[0001437749-26-014882:mdna:44]
[same as prior period, unchanged from 0001437749-25-033048:mdna:39]

[0001437749-26-014882:mdna:45]
The effective income tax rates for the three months ended March 31, 2026 and 2025 were 24.4% and 24.3%, respectively. The slight increase in effective tax rate was due primarily to certain discrete items and their impact on higher pre-tax income in the quarter.

[0001437749-26-014882:mdna:46]
On July 4, 2025, the United States signed the “One Big Beautiful Bill Act” (OBBBA) into law. This legislation makes permanent several key provisions of the Tax Cuts and Jobs Act, including 100% bonus depreciation and the immediate expensing of domestic research and development costs. Under ASC 740, “Income Taxes,” the effects of changes in tax laws are reflected in the Company’s financial statements in the quarter in which the legislation was passed. We continue to expect cash tax savings from the bonus depreciation and domestic research and development expensing.   These changes did not have a material impact on our effective income tax rate for the first quarter or the estimated annual effective tax rate for 2026 as the changes relate to temporary differences in basis.

[0001437749-26-014882:mdna:47]
In January 2026, the Organization for Economic Cooperation and Development (OECD) released a new package of administrative guidance that effectively deems the United States tax system as compliant with Pillar Two, which is expected to eliminate additional top-up taxes across our global operations. This updated guidance package does not exempt us from Qualified Domestic Minimum Top-Up Taxes in foreign jurisdictions. As a result, we expect our cash taxes paid to remain subject to local minimum tax regimes where applicable. There was no impact to our financial results during the quarter, and we do not expect the rules to have a material impact on our effective tax rate for the year. We continue to monitor OECD and foreign jurisdictions developments and will update our future tax provisions accordingly.

[0001437749-26-014882:mdna:48]
[same as prior period, unchanged from 0001437749-25-033048:mdna:43]

[0001437749-26-014882:mdna:49]
Three months ended March 31, 2026, compared to the three months ended March 31, 2025

[0001437749-26-014882:mdna:50]
[same as prior period, unchanged from 0001437749-25-033048:mdna:45]

[0001437749-26-014882:mdna:51]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2026 |  |  | 2025 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | 117,244 |  |  |  | 12.4 | % |
| Costs of goods sold |  |  | 649,129 |  |  |  | 570,135 |  |  |  | 78,994 |  |  |  | 13.9 | % |
| Gross profit |  |  | 410,236 |  |  |  | 371,986 |  |  |  | 38,250 |  |  |  | 10.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 123,624 |  |  |  | 126,065 |  |  |  | (2,441 | ) |  |  | -1.9 | % |
| Research and development |  |  | 62,656 |  |  |  | 62,048 |  |  |  | 608 |  |  |  | 1.0 | % |
| General and administrative |  |  | 76,285 |  |  |  | 74,746 |  |  |  | 1,539 |  |  |  | 2.1 | % |
| Amortization of intangible assets |  |  | 30,380 |  |  |  | 25,489 |  |  |  | 4,891 |  |  |  | 19.2 | % |
| Total operating expenses |  |  | 292,945 |  |  |  | 288,348 |  |  |  | 4,597 |  |  |  | 1.6 | % |
| Income from operations |  |  | 117,291 |  |  |  | 83,638 |  |  |  | 33,653 |  |  |  | 40.2 | % |
| Total other expense, net |  |  | (20,532 | ) |  |  | (25,124 | ) |  |  | 4,592 |  |  |  | 18.3 | % |
| Income before provision for income taxes |  |  | 96,759 |  |  |  | 58,514 |  |  |  | 38,245 |  |  |  | 65.4 | % |
| Provision for income taxes |  |  | 23,647 |  |  |  | 14,236 |  |  |  | 9,411 |  |  |  | 66.1 | % |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |  |  | 28,834 |  |  |  | 65.1 | % |
| Net (loss) income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |  |  | (579 | ) |  |  | -132.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |  | $ | 29,413 |  |  |  | 67.1 | % |

[0001437749-26-014882:mdna:52]
Segment Results of Operations

[0001437749-26-014882:mdna:53]
On March 25, 2026, we announced our plan to reorganize our two reportable segments to better align the organization with our enterprise strategy, effective March 31, 2026 (the Reorganization).  Prior to the Reorganization, our reportable segments were Domestic and International.  As a result of the Reorganization, our new reportable segments are Residential and C&I. The Residential segment consists of the former Domestic segment, excluding the domestic C&I operations.  The C&I segment consists of the operations of the former International segment with the addition of the domestic C&I operations.

[0001437749-26-014882:mdna:54]
Segment financial information for the prior periods has been recast to conform to the current presentation.

[0001437749-26-014882:mdna:55]
[same as prior period, unchanged from 0001437749-25-033048:mdna:47]

[0001437749-26-014882:mdna:56]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2026 |  |  | 2025 |  |  | $ Change |  |  | % Change |  |
| Residential |  | $ | 549,316 |  |  | $ | 543,115 |  |  | $ | 6,201 |  |  |  | 1.1 | % |
| Commercial & Industrial |  |  | 510,049 |  |  |  | 399,006 |  |  |  | 111,043 |  |  |  | 27.8 | % |
| Total net sales |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | 117,244 |  |  |  | 12.4 | % |

[0001437749-26-014882:mdna:57]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Residential |  | $ | 549,316 |  |  | $ | 2,867 |  |  | $ | 552,183 |  |  | $ | 543,115 |  |  | $ | 5,548 |  |  | $ | 548,663 |  |
| Commercial & Industrial |  |  | 510,049 |  |  |  | 49 |  |  |  | 510,098 |  |  |  | 399,006 |  |  |  | - |  |  |  | 399,006 |  |
| Intercompany eliminations |  |  | - |  |  |  | (2,916 | ) |  |  | (2,916 | ) |  |  | - |  |  |  | (5,548 | ) |  |  | (5,548 | ) |
| Total net sales |  | $ | 1,059,365 |  |  | $ | - |  |  | $ | 1,059,365 |  |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |

[0001437749-26-014882:mdna:58]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2026 |  |  | 2025 |  |  | $ Change |  |  | % Change |  |
| Residential |  | $ | 138,585 |  |  | $ | 111,589 |  |  | $ | 26,996 |  |  |  | 24.2 | % |
| Commercial & Industrial |  |  | 66,532 |  |  |  | 45,346 |  |  |  | 21,186 |  |  |  | 46.7 | % |
| Corporate and eliminations |  |  | (11,636 | ) |  |  | (7,389 | ) |  |  | (4,247 | ) |  |  | NM |  |
| Total Adjusted EBITDA |  | $ | 193,481 |  |  | $ | 149,546 |  |  | $ | 43,935 |  |  |  | 29.4 | % |

[0001437749-26-014882:mdna:59]
Net sales.   Residential segment total sales increased approximately 1% to $552 million as compared to $549 million in the prior year. This sales increase was primarily driven by higher portable generator shipments, partially offset by a decline in energy storage system sales. Home standby generator sales were approximately flat as higher pricing in the current year was offset by lower volumes due to a strong prior year period that included the benefit from a substantial 2024 hurricane season.

[0001437749-26-014882:mdna:60]
Commercial & Industrial segment total sales increased approximately 28% to $510 million from $399 million in the prior year quarter, including an approximate 10% net favorable impact from the combination of acquisitions, divestitures, and foreign currency. The core total sales growth for the segment was primarily driven by revenue from products sold to global data center customers, increased shipments to our domestic industrial distributor and rental channels, and higher sales of our controls solutions to the global power generation market.

[0001437749-26-014882:mdna:61]
In addition, net contribution from non-annualized acquisitions & divestitures for the first quarter of 2026 was $18.0 million, primarily in the Commercial & Industrial segment.

[0001437749-26-014882:mdna:62]
Gross profit.   Gross profit margin was 38.7% as compared to 39.5% in the prior-year first quarter. The decrease in gross margin was primarily driven by unfavorable sales mix. In addition, higher input costs, including the impact of tariffs and commodities, were more than offset by increased price realization.

[0001437749-26-014882:mdna:63]
Operating Expenses.   Operating expenses increased $4.6 million, or 2%, compared to the first quarter of 2025. The increase was primarily driven by higher intangible amortization.

[0001437749-26-014882:mdna:64]
Other Expense.   The reduction in other expense, net was driven primarily by a decrease in the loss on the change in fair value of our investment in warrants and equity securities of Wallbox N.V. This was partially offset by the net impact of two immaterial business dispositions that closed in the current year quarter.

[0001437749-26-014882:mdna:65]
Provision for income taxes.   Provision for income taxes for the current year quarter was $23.6 million, or an effective tax rate of 24.4%, as compared to $14.2 million, or a 24.3% effective tax rate, for the prior quarter. The slight increase in effective tax rate was primarily due to certain discrete items and their impact on higher pre-tax income relative to the prior year quarter.

[0001437749-26-014882:mdna:66]
Net income attributable to Generac Holdings Inc.   Net income attributable to the Company during the first quarter was $73 million, or $1.24 per share, as compared to $44 million, or $0.73 per share, for the same period of 2025.

[0001437749-26-014882:mdna:67]
Adjusted EBITDA.   Adjusted EBITDA for the Residential segment was $138.6 million, or 25.1% of residential segment total sales, as compared to $111.6 million, or 20.3% of residential sales, in the prior year. This margin increase was primarily driven by operational efficiencies resulting in lower operating expenses and favorable price realization that more than offset higher input costs.

[0001437749-26-014882:mdna:68]
Adjusted EBITDA for the Commercial & Industrial segment, before deducting for noncontrolling interests, was $66.5 million, or 13.0% of C&I total sales, as compared to $45.3 million, or 11.4% of total sales, in the prior year. This margin increase was primarily driven by improved price/cost realization, the accretive impact of the Allmand acquisition,  and operating leverage on higher shipment volumes.

[0001437749-26-014882:mdna:69]
Adjusted Net Income.   Adjusted net income attributable to the Company, as defined in the accompanying non-GAAP measures reconciliation schedules, was $106 million in the current year first quarter as compared to $75 million in the prior-year. This increase was primarily driven by higher net income in the current period as outlined above.

[0001437749-26-014882:mdna:70]
[same as prior period, unchanged from 0001437749-25-033048:mdna:64]

[0001437749-26-014882:mdna:71]
[same as prior period, unchanged from 0001437749-25-033048:mdna:87]

[0001437749-26-014882:mdna:72]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-26-014882:mdna:73]
On July 1, 2025, we amended our Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700 million (New Tranche A Term Loan Facility), reducing the Original Revolving Facility borrowing capacity to $1 billion (New Revolving Facility) (collectively the New Credit Agreements) and redefining the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreements), resulting in an interest rate reduction of 0.10%. The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on October 1, 2026. The New Tranche A Term Loan Facility and the New Revolving Facility bear interest at a rate based on SOFR plus an applicable margin between 1.25% and 1.75%, both based on our total leverage ratio and subject to a SOFR floor of 0.0%. As of March 31, 2026, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 4.92%.

[0001437749-26-014882:mdna:74]
[same as prior period, unchanged from 0001437749-25-033048:mdna:90]

[0001437749-26-014882:mdna:75]
As of March 31, 2026, there was $492.5 million outstanding under the Term Loan B Facility, $700 million outstanding under the New Tranche A Term Loan Facility, and no borrowings on the New Revolving Facility, leaving $999.3 million of unused capacity, net of outstanding letters of credit.

[0001437749-26-014882:mdna:76]
The Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of March 31, 2026, the interest rate for the Term Loan B Facility was 5.42%. The Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the Term Loan B Facility credit agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of March 31, 2026, our net secured leverage ratio was 1.31 to 1.00, and we were in compliance with all covenants of the facility. There are no financial maintenance covenants on the Term Loan B Facility. The New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of March 31, 2026, our total leverage ratio was 1.37 to 1.00, and our interest coverage ratio was 12.98 to 1.00. We were also in compliance with all other covenants of the New Credit Agreements as of March 31, 2026.

[0001437749-26-014882:mdna:77]
On February 12, 2024, our Board of Directors approved a stock repurchase program that allowed for the repurchase of up to $500.0 million of our common stock over a twenty-four-month period. Additionally, on February 9, 2026, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaces the prior share repurchase program, which had approximately $199.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. As of March 31, 2026, the remaining unused buyback authorization under the current program was $500 million.

[0001437749-26-014882:mdna:78]
There were no share repurchases under the program during the first quarter of 2026. During the first quarter of 2025, w
   e repurchased 716,685 shares of common stock for $97.5 million. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-26-014882:mdna:79]
See Note 12, “Credit Agreements,” and Note 13, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-26-014882:mdna:80]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 11% and 15% of net sales for the three months ended March 31, 2026 and 2025, respectively. The amount financed by dealers which remained outstanding under this arrangement was $162.3 million and $149.7 million as of March 31, 2026, and December 31, 2025, respectively.

[0001437749-26-014882:mdna:81]
[same as prior period, unchanged from 0001437749-25-033048:mdna:97]

[0001437749-26-014882:mdna:82]
As of March 31, 2026, we had total liquidity of $1,264.8 million which consists of $265.5 million of cash and cash equivalents and $999.3 million of availability under our New Revolving Facility.

[0001437749-26-014882:mdna:83]
We believe our cash and cash equivalents, cash flow from operations, and availability under our New Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other initiatives that could potentially drive incremental shareholder value.

[0001437749-26-014882:mdna:84]
[same as prior period, unchanged from 0001437749-25-033048:mdna:100]

[0001437749-26-014882:mdna:85]
Three months ended March 31, 2026, compared to the three months ended March 31, 2025

[0001437749-26-014882:mdna:86]
[same as prior period, unchanged from 0001437749-25-033048:mdna:102]

[0001437749-26-014882:mdna:87]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2026 |  |  | 2025 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 119,285 |  |  | $ | 58,152 |  |  | $ | 61,133 |  |  |  | 105.1 | % |
| Net cash used in investing activities |  |  | (153,750 | ) |  |  | (33,539 | ) |  |  | (120,211 | ) |  |  | -358.4 | % |
| Net cash used in financing activities |  |  | (41,382 | ) |  |  | (119,719 | ) |  |  | 78,337 |  |  |  | 65.4 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | (36 | ) |  |  | 1,293 |  |  |  | (1,329 | ) |  |  | -102.8 | % |
| Net decrease in cash and cash equivalents |  | $ | (75,883 | ) |  | $ | (93,813 | ) |  | $ | 17,930 |  |  |  | 19.1 | % |

[0001437749-26-014882:mdna:88]
The increase in operating cash flows for the three months ended March 31, 2026 was primarily driven by higher operating earnings and a lower use of cash for working capital as compared to the prior year.

[0001437749-26-014882:mdna:89]
The $153.8 million net cash used in investing activities for the three months ended March 31, 2026 primarily represents cash payments of $29.4 million related to the purchase of property and equipment, $122.8 million for the acquisition of Allmand, and $1.5 million related to other investing activities.

[0001437749-26-014882:mdna:90]
The $33.5 million net cash used in investing activities for the three months ended March 31, 2025 primarily represents cash payments of $30.9 million related to the purchase of property and equipment, and $2.7 million for the purchase of long-term investments.

[0001437749-26-014882:mdna:91]
The $41.4 million net cash used in financing activities for the three months ended March 31, 2026 primarily represents proceeds of $14.1 million from short-term borrowings, $0.2 million from long-term borrowings, and $7.2 million from the exercise of stock options. These cash proceeds were more than offset by $27.2 million of debt repayments ($21.0 million of short-term borrowings and $6.2 million of long-term borrowings and finance lease obligations), $34.6 million for taxes paid related to equity awards, and $1.1 million for payments of deferred acquisition consideration.

[0001437749-26-014882:mdna:92]
The $119.7 million net cash used in financing activities for the three months ended March 31, 2025 primarily represents proceeds of $19.2 million from short-term borrowings, $0.9 million from long-term borrowings, and $0.6 million from the exercise of stock options. These cash proceeds were more than offset by $34.4 million of debt repayments ($20.0 million of short-term borrowings and $14.4 million of long-term borrowings and finance lease obligations), $97.5 million of share repurchases, and $8.6 million for taxes paid related to equity awards.

[0001437749-26-014882:mdna:93]
[same as prior period, unchanged from 0001437749-25-033048:mdna:109]

[0001437749-26-014882:mdna:94]
There have been no material changes to our contractual obligations between the February 18, 2026, filing of our Annual Report on Form 10-K for the year ended December 31, 2025, and March 31, 2026, except for the changes in outstanding borrowings and interest rates as discussed in Note 12, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-26-014882:mdna:95]
[same as prior period, unchanged from 0001437749-25-033048:mdna:111]

[0001437749-26-014882:mdna:96]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2025, in preparing the financial statements in accordance with GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes.

[0001437749-26-014882:mdna:97]
Other than the changes described within Note 9, "Goodwill," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q, there have been no material changes in our critical accounting policies since the February 18, 2026, filing of our Annual Report on Form 10-K for the year ended December 31, 2025.

[0001437749-26-014882:mdna:98]
[same as prior period, unchanged from 0001437749-25-033048:mdna:114]

[0001437749-26-014882:mdna:99]
[same as prior period, unchanged from 0001437749-25-033048:mdna:115]

[0001437749-26-014882:mdna:100]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are not part of the ordinary routine litigation or regulatory matters incidental to the Company's business, including but not limited to class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our New and Prior Credit Agreements.

[0001437749-26-014882:mdna:101]
[same as prior period, unchanged from 0001437749-25-033048:mdna:117]

[0001437749-26-014882:mdna:102]
[same as prior period, unchanged from 0001437749-25-033048:mdna:118]

[0001437749-26-014882:mdna:103]
[same as prior period, unchanged from 0001437749-25-033048:mdna:119]

[0001437749-26-014882:mdna:104]
|  | • | as a target for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our proxy statement; |

[0001437749-26-014882:mdna:105]
[same as prior period, unchanged from 0001437749-25-033048:mdna:121]

[0001437749-26-014882:mdna:106]
[same as prior period, unchanged from 0001437749-25-033048:mdna:122]

[0001437749-26-014882:mdna:107]
[same as prior period, unchanged from 0001437749-25-033048:mdna:123]

[0001437749-26-014882:mdna:108]
[same as prior period, unchanged from 0001437749-25-033048:mdna:124]

[0001437749-26-014882:mdna:109]
[same as prior period, unchanged from 0001437749-25-033048:mdna:125]

[0001437749-26-014882:mdna:110]
[same as prior period, unchanged from 0001437749-25-033048:mdna:126]

[0001437749-26-014882:mdna:111]
[same as prior period, unchanged from 0001437749-25-033048:mdna:127]

[0001437749-26-014882:mdna:112]
[same as prior period, unchanged from 0001437749-25-033048:mdna:128]

[0001437749-26-014882:mdna:113]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; |

[0001437749-26-014882:mdna:114]
|  | • | are non-cash in nature, such as share-based compensation; or |
|  | • | the provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, including but not limited to large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. |

[0001437749-26-014882:mdna:115]
[same as prior period, unchanged from 0001437749-25-033048:mdna:131]

[0001437749-26-014882:mdna:116]
[same as prior period, unchanged from 0001437749-25-033048:mdna:132]

[0001437749-26-014882:mdna:117]
[same as prior period, unchanged from 0001437749-25-033048:mdna:133]

[0001437749-26-014882:mdna:118]
[same as prior period, unchanged from 0001437749-25-033048:mdna:134]

[0001437749-26-014882:mdna:119]
[same as prior period, unchanged from 0001437749-25-033048:mdna:135]

[0001437749-26-014882:mdna:120]
[same as prior period, unchanged from 0001437749-25-033048:mdna:136]

[0001437749-26-014882:mdna:121]
[same as prior period, unchanged from 0001437749-25-033048:mdna:137]

[0001437749-26-014882:mdna:122]
[same as prior period, unchanged from 0001437749-25-033048:mdna:138]

[0001437749-26-014882:mdna:123]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our New and Prior Credit Agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-26-014882:mdna:124]
[same as prior period, unchanged from 0001437749-25-033048:mdna:140]

[0001437749-26-014882:mdna:125]
[same as prior period, unchanged from 0001437749-25-033048:mdna:141]

[0001437749-26-014882:mdna:126]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2026 |  |  | 2025 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |
| Interest expense |  |  | 15,376 |  |  |  | 17,110 |  |
| Depreciation and amortization |  |  | 55,974 |  |  |  | 46,141 |  |
| Provision for income taxes |  |  | 23,647 |  |  |  | 14,236 |  |
| Non-cash write-down and other adjustments (a) |  |  | (1,443 | ) |  |  | (13 | ) |
| Non-cash share-based compensation expense (b) |  |  | 13,442 |  |  |  | 11,608 |  |
| Transaction costs and credit facility fees (c) |  |  | 2,710 |  |  |  | 760 |  |
| Business optimization and other charges (d) |  |  | 1,153 |  |  |  | 1,575 |  |
| Provision for legal, regulatory, and other costs (e) |  |  | 3,206 |  |  |  | 3,751 |  |
| Change in fair value of investments (f) |  |  | 1,374 |  |  |  | 9,947 |  |
| Other (g) |  |  | 4,930 |  |  |  | 153 |  |
| Adjusted EBITDA |  |  | 193,481 |  |  |  | 149,546 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (146 | ) |  |  | 632 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 193,627 |  |  | $ | 148,914 |  |

[0001437749-26-014882:mdna:127]
[same as prior period, unchanged from 0001437749-25-033048:mdna:143]

[0001437749-26-014882:mdna:128]
• The gains/losses on disposals of assets and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains/losses that are not from our core operations;

[0001437749-26-014882:mdna:129]
• The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and

[0001437749-26-014882:mdna:130]
•The purchase accounting adjustments represent non-cash items to reflect fair value of certain assets at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price.

[0001437749-26-014882:mdna:131]
[same as prior period, unchanged from 0001437749-25-033048:mdna:146]

[0001437749-26-014882:mdna:132]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Prior and New Credit Agreement.

[0001437749-26-014882:mdna:133]
[same as prior period, unchanged from 0001437749-25-033048:mdna:148]

[0001437749-26-014882:mdna:134]
(e)  Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-26-014882:mdna:135]
|  |  | Three Months Ended March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Legal expenses, judgements and settlements related to certain patent lawsuits |  | $ | 2,447 |  |  | $ | 1,492 |  |
| Legal expenses, judgements and settlements related to certain class action lawsuits |  |  | 1,026 |  |  |  | 1,343 |  |
| Legal expenses related to certain government inquiries and other significant matters |  |  | 862 |  |  |  | 916 |  |
| Release of warranty provision recorded in 2022 to address clean energy warranty-related matters |  |  | (1,129 | ) |  |  | - |  |
| Total provision for legal, regulatory and other matters |  | $ | 3,206 |  |  | $ | 3,751 |  |

[0001437749-26-014882:mdna:136]
[same as prior period, unchanged from 0001437749-25-033048:mdna:151]

[0001437749-26-014882:mdna:137]
(g)  The current year loss relates primarily to two immaterial business dispositions that closed in the first quarter of 2026.

[0001437749-26-014882:mdna:138]
[same as prior period, unchanged from 0001437749-25-033048:mdna:154]

[0001437749-26-014882:mdna:139]
[same as prior period, unchanged from 0001437749-25-033048:mdna:155]

[0001437749-26-014882:mdna:140]
[same as prior period, unchanged from 0001437749-25-033048:mdna:156]

[0001437749-26-014882:mdna:141]
[same as prior period, unchanged from 0001437749-25-033048:mdna:157]

[0001437749-26-014882:mdna:142]
[same as prior period, unchanged from 0001437749-25-033048:mdna:158]

[0001437749-26-014882:mdna:143]
[same as prior period, unchanged from 0001437749-25-033048:mdna:159]

[0001437749-26-014882:mdna:144]
[same as prior period, unchanged from 0001437749-25-033048:mdna:160]

[0001437749-26-014882:mdna:145]
[same as prior period, unchanged from 0001437749-25-033048:mdna:161]

[0001437749-26-014882:mdna:146]
[same as prior period, unchanged from 0001437749-25-033048:mdna:162]

[0001437749-26-014882:mdna:147]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2026 |  |  | 2025 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 73,253 |  |  | $ | 43,840 |  |
| Net income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Net income |  |  | 73,112 |  |  |  | 44,278 |  |
| Amortization of intangible assets |  |  | 30,380 |  |  |  | 25,489 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 535 |  |  |  | 636 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 2,548 |  |  |  | 107 |  |
| Loss attributable to business or asset dispositions (c) |  |  | 4,782 |  |  |  | 390 |  |
| Business optimization and other charges (b) |  |  | 1,153 |  |  |  | 1,575 |  |
| Provision for legal, regulatory, and other costs (b) |  |  | 3,206 |  |  |  | 3,751 |  |
| Change in fair value of investments (b) |  |  | 1,374 |  |  |  | 9,947 |  |
| Tax effect of add backs |  |  | (10,885 | ) |  |  | (10,369 | ) |
| Adjusted net income |  |  | 106,205 |  |  |  | 75,804 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (141 | ) |  |  | 438 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 106,346 |  |  | $ | 75,366 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.80 |  |  | $ | 1.26 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,233,144 |  |  |  | 59,747,589 |  |

[0001437749-26-014882:mdna:148]
[same as prior period, unchanged from 0001437749-25-033048:mdna:164]

[0001437749-26-014882:mdna:149]
[same as prior period, unchanged from 0001437749-25-033048:mdna:165]

[0001437749-26-014882:mdna:150]
(c)  The current year loss relates primarily to two immaterial business dispositions that closed in the first quarter of 2026.

[0001437749-26-014882:mdna:151]
[same as prior period, unchanged from 0001437749-25-033048:mdna:167]

[0001437749-26-014882:mdna:152]
[same as prior period, unchanged from 0001437749-25-033048:mdna:168]
