# GNRC 8-K — 0001437749-17-013526 filed 2017-08-02

## item codes, every 8-K on or before 2017-08-04

- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2017-08-04

- none on or before 2017-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-013526:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-013526:8k_2_02:2]
ex99-1.htm

[0001437749-17-013526:8k_2_02:3]
Exhibit 99.1

[0001437749-17-013526:8k_2_02:4]
Generac Reports Second Quarter 2017 Results

[0001437749-17-013526:8k_2_02:5]
Strong shipments of home standby generators and domestic mobile products lead to overall solid organic sales growth over the prior year

[0001437749-17-013526:8k_2_02:6]
WAUKESHA, WISCONSIN, (August 2, 2017) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its second quarter ended June 30, 2017.

[0001437749-17-013526:8k_2_02:7]
Second Quarter 2017 Highlights

[0001437749-17-013526:8k_2_02:8]
| ● | Net sales increased 7.6% to $395.4 million during the second quarter of 2017 as compared to $367.4 million in the prior-year second quarter, including $9.5 million of contribution from the Motortech acquisition. |

[0001437749-17-013526:8k_2_02:9]
| ● | Net income attributable to the Company during the second quarter of 2017 was $25.7 million, or $0.41 per share, as compared to $20.9 million, or $0.31 per share, for the same period of 2016. The prior-year net income includes $3.4 million of pre-tax expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. |

[0001437749-17-013526:8k_2_02:10]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $43.3 million, or $0.69 per share, as compared to $42.7 million, or $0.64 per share, in the second quarter of 2016. |

[0001437749-17-013526:8k_2_02:11]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $68.7 million as compared to $62.3 million in the second quarter last year. |

[0001437749-17-013526:8k_2_02:12]
| ● | Cash flow from operations was $60.2 million as compared to $59.1 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $53.7 million as compared to $52.2 million in the second quarter of 2016. |

[0001437749-17-013526:8k_2_02:13]
| ● | The Company repurchased 845,000 shares of its common stock during the second quarter for $30.0 million under its current share repurchase program. |

[0001437749-17-013526:8k_2_02:14]
| ● | On May 11, 2017, the Company amended its Term Loan credit facility which, among other items, modified the pricing by favorably reducing the applicable margin rate to a fixed rate of 2.25%, resulting in a 50 basis point reduction in the overall interest rate from the level previously in effect, or approximately $4.5 million of annualized interest savings. |

[0001437749-17-013526:8k_2_02:15]
“We are pleased with our second quarter results with strong organic sales growth compared to the prior year leading to an improvement in overall operating earnings and cash flow,” said Aaron Jagdfeld, President and Chief Executive Officer. “Shipments of home standby generators in particular were very strong in the quarter as higher power outage activity and targeted marketing in the first half drove increased activations as every region in the US experienced solid double digit growth year over year. Demand for our mobile products domestically also continued to be much stronger as compared to the prior-year, as our rental equipment customers further replaced and upgraded their fleets during the quarter.”

[0001437749-17-013526:8k_2_02:16]
Additional Second Quarter 2017 Consolidated Highlights

[0001437749-17-013526:8k_2_02:17]
Residential product sales increased 9.0% to $198.1 million as compared to $181.7 million in the prior year. Commercial & Industrial (C&I) product sales improved 8.9% to $170.8 million as compared to $156.7 million in the prior year.

[0001437749-17-013526:8k_2_02:18]
Gross profit margin was 34.0% compared to 33.8% in the prior-year second quarter. The prior year included $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these expenses, gross margin in the prior year was 34.7%. The pro-forma decline in gross margin as compared to the prior year was due to a number of factors including higher commodity prices seen in prior quarters and, to a lesser extent, certain plant consolidation costs.

[0001437749-17-013526:8k_2_02:19]
Operating expenses increased $2.1 million, or 2.6%, as compared to the second quarter of 2016. The increase was primarily driven by the addition of recurring operating expenses associated with the Motortech acquisition.

[0001437749-17-013526:8k_2_02:20]
Cash flow from operations was $60.2 million as compared to $59.1 million in the prior year, and free cash flow was $53.7 million as compared to $52.2 million in the same period last year. The increases in cash flow were primarily driven by higher operating earnings in the current-year quarter, partially offset by a smaller benefit from working capital reduction during the current year.

[0001437749-17-013526:8k_2_02:21]
Business Segment Results

[0001437749-17-013526:8k_2_02:22]
Domestic Segment

[0001437749-17-013526:8k_2_02:23]
Domestic segment sales increased 6.7% to $305.9 million as compared to $286.7 million in the prior-year quarter. The current-year second quarter experienced strong growth in shipments of home standby generators and mobile products. This strength was partially offset by a decline in residential portable sales due to excess levels of field inventory during the current-year quarter along with new product placement with certain retail customers in the prior-year quarter.

[0001437749-17-013526:8k_2_02:24]
Adjusted EBITDA for the segment was $64.2 million, or 21.0% of net sales, as compared to $57.4 million in the prior year, or 20.0% of net sales. Adjusted EBITDA margin in the current year was positively impacted by improved overall leverage of fixed operating expenses on the organic increase in sales, partially offset by unfavorable impact from higher commodity prices seen in prior quarters.

[0001437749-17-013526:8k_2_02:25]
International Segment

[0001437749-17-013526:8k_2_02:26]
International segment sales, primarily consisting of C&I products, increased 10.9% to $89.5 million as compared to $80.7 million in the prior-year quarter. The increase was primarily due to the contribution from the recent acquisition of Motortech, which closed on January 1, 2017.

[0001437749-17-013526:8k_2_02:27]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, was $6.0 million, or 6.7% of net sales, as compared to $6.6 million, or 8.2% of net sales, in the prior year. The decline in adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable foreign currency impacts and sales mix, along with higher commodity prices and increased overall operating expenses including the expansion of branch operations. These impacts were partially offset by the addition of the Motortech acquisition.

[0001437749-17-013526:8k_2_02:28]
2017 Outlook Update

[0001437749-17-013526:8k_2_02:29]
The Company is increasing its prior guidance for revenue growth for full-year 2017, which is primarily due to an improved outlook for domestic mobile products, as well as higher international segment sales from a stronger Euro relative to the U.S. dollar. Full year net sales are now expected to increase between 6 to 8% as compared to the prior year, with core organic growth of between 2 to 3%. As a result of an unfavorable shift in sales mix and foreign currency impacts, the Company is revising its prior guidance for net income and adjusted EBITDA margins for the full year 2017. Net income margins, before deducting for non-controlling interests, are now expected to be between 7.0 to 7.5%, while adjusted EBITDA margins, also before deducting for non-controlling interests, are now expected to be approximately 18.5% for the full year 2017.

[0001437749-17-013526:8k_2_02:30]
The top-line guidance assumes no material changes in the current macroeconomic environment and also assumes a power outage severity level for the remainder of the year similar to that experienced during 2016 excluding the impact of Hurricane Matthew. Operating and free cash flow generation is expected to seasonally increase during the second half, with the conversion of adjusted net income expected to be over 90% for the full year.

[0001437749-17-013526:8k_2_02:31]
Conference Call and Webcast

[0001437749-17-013526:8k_2_02:32]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, August 2, 2017 to discuss highlights of the second quarter of 2017 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 56163658.

[0001437749-17-013526:8k_2_02:33]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-17-013526:8k_2_02:34]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 56163658. The telephonic replay will be available for 7 days.

[0001437749-17-013526:8k_2_02:35]
About Generac

[0001437749-17-013526:8k_2_02:36]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-013526:8k_2_02:37]
Forward-looking Information

[0001437749-17-013526:8k_2_02:38]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-17-013526:8k_2_02:39]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-17-013526:8k_2_02:40]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-17-013526:8k_2_02:41]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-17-013526:8k_2_02:42]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-17-013526:8k_2_02:43]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-17-013526:8k_2_02:44]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-17-013526:8k_2_02:45]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-17-013526:8k_2_02:46]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-17-013526:8k_2_02:47]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-17-013526:8k_2_02:48]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-17-013526:8k_2_02:49]
|  | ● | loss of key management and employees; |

[0001437749-17-013526:8k_2_02:50]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-17-013526:8k_2_02:51]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-17-013526:8k_2_02:52]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2016 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-17-013526:8k_2_02:53]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-17-013526:8k_2_02:54]
Reconciliations to GAAP Financial Metrics

[0001437749-17-013526:8k_2_02:55]
Adjusted EBITDA

[0001437749-17-013526:8k_2_02:56]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-17-013526:8k_2_02:57]
Adjusted Net Income

[0001437749-17-013526:8k_2_02:58]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-17-013526:8k_2_02:59]
Free Cash Flow

[0001437749-17-013526:8k_2_02:60]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-17-013526:8k_2_02:61]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-17-013526:8k_2_02:62]
SOURCE: Generac Holdings Inc.

[0001437749-17-013526:8k_2_02:63]
CONTACT:

[0001437749-17-013526:8k_2_02:64]
Michael W. Harris

[0001437749-17-013526:8k_2_02:65]
Vice President – Finance

[0001437749-17-013526:8k_2_02:66]
(262) 544-4811 x2675

[0001437749-17-013526:8k_2_02:67]
Michael.Harris@Generac.com

[0001437749-17-013526:8k_2_02:68]
4

[0001437749-17-013526:8k_2_02:69]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-17-013526:8k_2_02:70]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 727,190 |  |  | $ | 653,911 |  |
| Costs of goods sold |  |  | 260,916 |  |  |  | 243,229 |  |  |  | 482,244 |  |  |  | 431,704 |  |
| Gross profit |  |  | 134,460 |  |  |  | 124,147 |  |  |  | 244,946 |  |  |  | 222,207 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 43,116 |  |  |  | 42,366 |  |  |  | 83,300 |  |  |  | 79,635 |  |
| Research and development |  |  | 10,567 |  |  |  | 9,889 |  |  |  | 20,868 |  |  |  | 18,086 |  |
| General and administrative |  |  | 21,361 |  |  |  | 19,593 |  |  |  | 42,334 |  |  |  | 37,426 |  |
| Amortization of intangibles |  |  | 7,129 |  |  |  | 8,217 |  |  |  | 14,312 |  |  |  | 16,014 |  |
| Total operating expenses |  |  | 82,173 |  |  |  | 80,065 |  |  |  | 160,814 |  |  |  | 151,161 |  |
| Income from operations |  |  | 52,287 |  |  |  | 44,082 |  |  |  | 84,132 |  |  |  | 71,046 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,893 | ) |  |  | (11,380 | ) |  |  | (21,681 | ) |  |  | (22,415 | ) |
| Investment income |  |  | 38 |  |  |  | 4 |  |  |  | 43 |  |  |  | 36 |  |
| Costs related to acquisition |  |  | (136 | ) |  |  | – |  |  |  | (321 | ) |  |  | (417 | ) |
| Other, net |  |  | (1,437 | ) |  |  | 158 |  |  |  | (1,214 | ) |  |  | 545 |  |
| Total other expense, net |  |  | (12,428 | ) |  |  | (11,218 | ) |  |  | (23,173 | ) |  |  | (22,251 | ) |
| Income before provision for income taxes |  |  | 39,859 |  |  |  | 32,864 |  |  |  | 60,959 |  |  |  | 48,795 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 22,365 |  |  |  | 17,640 |  |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 38,594 |  |  |  | 31,155 |  |
| Net income attributable to noncontrolling interests |  |  | 85 |  |  |  | 55 |  |  |  | 92 |  |  |  | 59 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.42 |  |  | $ | 0.32 |  |  | $ | 0.63 |  |  | $ | 0.47 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,146,393 |  |  |  | 65,870,714 |  |  |  | 62,260,170 |  |  |  | 65,955,455 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.41 |  |  | $ | 0.31 |  |  | $ | 0.63 |  |  | $ | 0.47 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,635,437 |  |  |  | 66,388,581 |  |  |  | 62,849,877 |  |  |  | 66,465,770 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 32,577 |  |  | $ | 7,622 |  |  | $ | 48,964 |  |  | $ | 19,076 |  |

[0001437749-17-013526:8k_2_02:71]
5

[0001437749-17-013526:8k_2_02:72]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-013526:8k_2_02:73]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 67,071 |  |  | $ | 67,272 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 243,285 |  |  |  | 241,857 |  |
| Inventories |  |  | 378,110 |  |  |  | 349,731 |  |
| Prepaid expenses and other assets |  |  | 9,314 |  |  |  | 24,649 |  |
| Total current assets |  |  | 697,780 |  |  |  | 683,509 |  |
| Property and equipment, net |  |  | 217,056 |  |  |  | 212,793 |  |
| Customer lists, net |  |  | 44,659 |  |  |  | 45,312 |  |
| Patents, net |  |  | 44,409 |  |  |  | 48,061 |  |
| Other intangible assets, net |  |  | 2,699 |  |  |  | 2,925 |  |
| Tradenames, net |  |  | 156,650 |  |  |  | 158,874 |  |
| Goodwill |  |  | 716,820 |  |  |  | 704,640 |  |
| Deferred income taxes |  |  | 4,261 |  |  |  | 3,337 |  |
| Other assets |  |  | 3,196 |  |  |  | 2,233 |  |
| Total assets |  | $ | 1,887,530 |  |  | $ | 1,861,684 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 22,155 |  |  | $ | 31,198 |  |
| Accounts payable |  |  | 163,359 |  |  |  | 181,519 |  |
| Accrued wages and employee benefits |  |  | 23,765 |  |  |  | 21,189 |  |
| Other accrued liabilities |  |  | 93,343 |  |  |  | 93,068 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 7,700 |  |  |  | 14,965 |  |
| Total current liabilities |  |  | 310,322 |  |  |  | 341,939 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,007,235 |  |  |  | 1,006,758 |  |
| Deferred income taxes |  |  | 37,575 |  |  |  | 17,278 |  |
| Other long-term liabilities |  |  | 66,633 |  |  |  | 61,459 |  |
| Total liabilities |  |  | 1,421,765 |  |  |  | 1,427,434 |  |
| Redeemable noncontrolling interests |  |  | 37,796 |  |  |  | 33,138 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,594,648 and 70,261,481 shares issued at June 30, 2017 and December 31, 2016, respectively |  |  | 705 |  |  |  | 702 |  |
| Additional paid-in capital |  |  | 454,763 |  |  |  | 449,049 |  |
| Treasury stock, at cost |  |  | (293,684 | ) |  |  | (262,402 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 495,463 |  |  |  | 456,052 |  |
| Accumulated other comprehensive loss |  |  | (27,209 | ) |  |  | (40,163 | ) |
| Stockholders' equity attributable to Generac Holdings, Inc. |  |  | 427,922 |  |  |  | 401,122 |  |
| Noncontrolling interests |  |  | 47 |  |  |  | (10 | ) |
| Total stockholders’ equity |  |  | 427,969 |  |  |  | 401,112 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,887,530 |  |  | $ | 1,861,684 |  |

[0001437749-17-013526:8k_2_02:74]
6

[0001437749-17-013526:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-17-013526:8k_2_02:76]
|  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 38,594 |  |  | $ | 31,155 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 11,271 |  |  |  | 10,429 |  |
| Amortization of intangible assets |  |  | 14,312 |  |  |  | 16,014 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,308 |  |  |  | 2,122 |  |
| Deferred income taxes |  |  | 17,164 |  |  |  | 9,072 |  |
| Share-based compensation expense |  |  | 5,818 |  |  |  | 5,386 |  |
| Other |  |  | 377 |  |  |  | 46 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 5,362 |  |  |  | (9,389 | ) |
| Inventories |  |  | (13,981 | ) |  |  | (1,046 | ) |
| Other assets |  |  | 1,069 |  |  |  | 2,297 |  |
| Accounts payable |  |  | (26,560 | ) |  |  | 17,537 |  |
| Accrued wages and employee benefits |  |  | 1,902 |  |  |  | 6,166 |  |
| Other accrued liabilities |  |  | (559 | ) |  |  | (1,825 | ) |
| Excess tax benefits from equity awards |  |  | (403 | ) |  |  | (6,729 | ) |
| Net cash provided by operating activities |  |  | 55,674 |  |  |  | 81,235 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 45 |  |  |  | 47 |  |
| Expenditures for property and equipment |  |  | (10,030 | ) |  |  | (14,004 | ) |
| Acquisition of business, net of cash acquired |  |  | 1,160 |  |  |  | (60,886 | ) |
| Net cash used in investing activities |  |  | (8,825 | ) |  |  | (74,843 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 62,435 |  |  |  | 10,278 |  |
| Proceeds from long-term borrowings |  |  | 3,069 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (72,971 | ) |  |  | (6,327 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (9,806 | ) |  |  | (10,652 | ) |
| Stock repurchases |  |  | (30,012 | ) |  |  | (34,576 | ) |
| Payment of debt issuance costs |  |  | (1,517 | ) |  |  | – |  |
| Cash dividends paid |  |  | – |  |  |  | (76 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (1,958 | ) |  |  | (12,099 | ) |
| Proceeds from exercise of stock options |  |  | 1,254 |  |  |  | – |  |
| Excess tax benefits from equity awards |  |  | – |  |  |  | 6,729 |  |
| Net cash used in financing activities |  |  | (49,506 | ) |  |  | (46,723 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,456 |  |  |  | 115 |  |
| Net decrease in cash and cash equivalents |  |  | (201 | ) |  |  | (40,216 | ) |
| Cash and cash equivalents at beginning of period |  |  | 67,272 |  |  |  | 115,857 |  |
| Cash and cash equivalents at end of period |  | $ | 67,071 |  |  | $ | 75,641 |  |

[0001437749-17-013526:8k_2_02:77]
7

[0001437749-17-013526:8k_2_02:78]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-17-013526:8k_2_02:79]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 305,907 |  |  | $ | 286,720 |  |  | $ | 554,404 |  |  | $ | 534,736 |  |
| International |  |  | 89,469 |  |  |  | 80,656 |  |  |  | 172,786 |  |  |  | 119,175 |  |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 727,190 |  |  | $ | 653,911 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 198,117 |  |  | $ | 181,735 |  |  | $ | 352,973 |  |  | $ | 340,716 |  |
| Commercial & industrial products |  |  | 170,755 |  |  |  | 156,730 |  |  |  | 322,198 |  |  |  | 259,720 |  |
| Other |  |  | 26,504 |  |  |  | 28,911 |  |  |  | 52,019 |  |  |  | 53,475 |  |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 727,190 |  |  | $ | 653,911 |  |

[0001437749-17-013526:8k_2_02:80]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 64,157 |  |  | $ | 57,352 |  |  | $ | 107,003 |  |  | $ | 104,212 |  |
| International |  |  | 6,034 |  |  |  | 6,574 |  |  |  | 10,846 |  |  |  | 9,523 |  |
| Total adjusted EBITDA (1) |  | $ | 70,191 |  |  | $ | 63,926 |  |  | $ | 117,849 |  |  | $ | 113,735 |  |

[0001437749-17-013526:8k_2_02:81]
| (1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-17-013526:8k_2_02:82]
8

[0001437749-17-013526:8k_2_02:83]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |

[0001437749-17-013526:8k_2_02:84]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Net loss attributable to noncontrolling interests (1) |  |  | 85 |  |  |  | 55 |  |  |  | 92 |  |  |  | 59 |  |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 38,594 |  |  |  | 31,155 |  |
| Interest expense |  |  | 10,893 |  |  |  | 11,380 |  |  |  | 21,681 |  |  |  | 22,415 |  |
| Depreciation and amortization |  |  | 12,986 |  |  |  | 13,650 |  |  |  | 25,583 |  |  |  | 26,443 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 22,365 |  |  |  | 17,640 |  |
| Non-cash write-down and other adjustments (2) |  |  | 1,710 |  |  |  | 2,909 |  |  |  | 1,876 |  |  |  | 2,782 |  |
| Non-cash share-based compensation expense (3) |  |  | 3,186 |  |  |  | 2,901 |  |  |  | 5,818 |  |  |  | 5,386 |  |
| Transaction costs and credit facility fees (4) |  |  | 420 |  |  |  | 237 |  |  |  | 736 |  |  |  | 760 |  |
| Business optimization expenses (5) |  |  | 1,346 |  |  |  | – |  |  |  | 1,446 |  |  |  | 7,106 |  |
| Other |  |  | (209 | ) |  |  | (15 | ) |  |  | (250 | ) |  |  | 48 |  |
| Adjusted EBITDA |  |  | 70,191 |  |  |  | 63,926 |  |  |  | 117,849 |  |  |  | 113,735 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,455 |  |  |  | 1,623 |  |  |  | 2,411 |  |  |  | 2,307 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 68,736 |  |  | $ | 62,303 |  |  | $ | 115,438 |  |  | $ | 111,428 |  |

[0001437749-17-013526:8k_2_02:85]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.1 million and $2.2 million for the three and six months ended June 30, 2017, respectively, and $4.3 million and $5.5 million for the three and six months ended June 30, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) For the three and six months ended June 30, 2017, represents severance and other non-recurring plant consolidation costs. For the six months ended June 30, 2016, represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. |

[0001437749-17-013526:8k_2_02:86]
9

[0001437749-17-013526:8k_2_02:87]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Net loss attributable to noncontrolling interests (1) |  |  | 85 |  |  |  | 55 |  |  |  | 92 |  |  |  | 59 |  |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 38,594 |  |  |  | 31,155 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 22,365 |  |  |  | 17,640 |  |
| Income before provision for income taxes |  |  | 39,859 |  |  |  | 32,864 |  |  |  | 60,959 |  |  |  | 48,795 |  |
| Amortization of intangible assets |  |  | 7,129 |  |  |  | 8,217 |  |  |  | 14,312 |  |  |  | 16,014 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 818 |  |  |  | 1,066 |  |  |  | 1,308 |  |  |  | 2,122 |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 429 |  |  |  | 3,443 |  |  |  | 1,014 |  |  |  | 4,690 |  |
| Business optimization expenses (5) |  |  | 1,346 |  |  |  | – |  |  |  | 1,446 |  |  |  | 7,106 |  |
| Adjusted net income before provision for income taxes |  |  | 49,581 |  |  |  | 45,590 |  |  |  | 79,039 |  |  |  | 78,727 |  |
| Cash income tax expense (7) |  |  | (5,642 | ) |  |  | (1,450 | ) |  |  | (8,729 | ) |  |  | (3,270 | ) |
| Adjusted net income |  |  | 43,939 |  |  |  | 44,140 |  |  |  | 70,310 |  |  |  | 75,457 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 633 |  |  |  | 1,451 |  |  |  | 1,215 |  |  |  | 1,881 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 43,306 |  |  | $ | 42,689 |  |  | $ | 69,095 |  |  | $ | 73,576 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.69 |  |  | $ | 0.64 |  |  | $ | 1.10 |  |  | $ | 1.11 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,635,437 |  |  |  | 66,388,581 |  |  |  | 62,849,877 |  |  |  | 66,465,770 |  |

[0001437749-17-013526:8k_2_02:88]
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (7) Amount for the three and six months ended June 30, 2017 is based on an anticipated cash income tax rate of approximately 14% for the full year ended 2017. Amount for the three and six months ended June 30, 2016 is based on an anticipated cash income tax rate of approximately 5% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-17-013526:8k_2_02:89]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities |  | $ | 60,220 |  |  | $ | 59,084 |  |  | $ | 55,674 |  |  | $ | 81,235 |  |
| Expenditures for property and equipment |  |  | (6,482 | ) |  |  | (6,911 | ) |  |  | (10,030 | ) |  |  | (14,004 | ) |
| Free cash flow |  | $ | 53,738 |  |  | $ | 52,173 |  |  | $ | 45,644 |  |  | $ | 67,231 |  |

[0001437749-17-013526:8k_2_02:90]
10
