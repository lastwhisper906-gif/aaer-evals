# GNRC note change history — 0001437749-17-008152 → 0001437749-17-013821


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-04):
[0001437749-17-013821:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,900
 and 
$33,900,
 respectively.
  (was, 2017-05-05, similarity 0.9173):
[0001437749-17-008152:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:2]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:3]
2017
 and 
 December

- removed (2017-08-04):
[0001437749-17-008152:note_history:4]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:5]
2016
 was approximately 
$33,800
 and 
$33,900,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-04):
[0001437749-17-013821:note_history:6]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
  (was, 2017-05-05, similarity 0.7974):
[0001437749-17-008152:note_history:6]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December

- added (2017-08-04):
[0001437749-17-013821:note_history:7]
and Item 
8
 (Note 
1
 “Description of Business”) 
of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:

- changed (2017-08-04):
[0001437749-17-013821:note_history:8]
The condensed conso
lidated balance sheet as of 
 June 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2017-05-05, similarity 0.7602):
[0001437749-17-008152:note_history:8]
2017
 and 
2016
 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2017-08-04):
[0001437749-17-013821:note_history:9]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016.
  (was, 2017-05-05, similarity 0.9948):
[0001437749-17-008152:note_history:9]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December

- changed (2017-08-04):
[0001437749-17-013821:note_history:10]
In 
 May 2014, 
the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,
  (was, 2017-05-05, similarity 0.9648):
[0001437749-17-008152:note_history:10]
2014,
 the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

- changed (2017-08-04):
[0001437749-17-013821:note_history:11]
606
): D
  (was, 2017-05-05, similarity 0.9091):
[0001437749-17-008152:note_history:11]
606):
 D

- changed (2017-08-04):
[0001437749-17-013821:note_history:12]
Revenue from Contracts with Customers (Topic 
606
): Principal versus Agent Considerations
, ASU 
2016
-
10,
  (was, 2017-05-05, similarity 0.9949):
[0001437749-17-008152:note_history:12]
Revenue from Contracts with Customers (Topic 
606):
 Principal versus Agent Considerations
, ASU 
2016
-
10,

- changed (2017-08-04):
[0001437749-17-013821:note_history:13]
Revenue from Contracts with Customers (Topic 
606
): Identifying Performance Obligations and Licensin
  (was, 2017-05-05, similarity 0.9949):
[0001437749-17-008152:note_history:13]
Revenue from Contracts with Customers (Topic 
606):
 Identifying Performance Obligations and Licensin

- changed (2017-08-04):
[0001437749-17-013821:note_history:14]
Revenue from Contracts with Customers (Topic 
606
):
  (was, 2017-05-05, similarity 0.9897):
[0001437749-17-008152:note_history:14]
Revenue from Contracts with Customers (Topic 
606):

- added (2017-08-04):
[0001437749-17-013821:note_history:15]
Narrow-

- changed (2017-08-04):
[0001437749-17-013821:note_history:16]
Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,
  (was, 2017-05-05, similarity 0.944):
[0001437749-17-008152:note_history:16]
Narrow-Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

- changed (2017-08-04):
[0001437749-17-013821:note_history:17]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may 
have on its financial statements, it believes that the adoption will 
not
 have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company is currently planning to adopt the standard using the full retrospective method.
  (was, 2017-05-05, similarity 0.9139):
[0001437749-17-008152:note_history:17]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may
 have on its financial statements, it believes that the adoption will not have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company has not yet determined its method of adoption.

- changed (2017-08-04):
[0001437749-17-013821:note_history:18]
In 
 August 2016, 
the FASB issued ASU 
2016
-
15,
  (was, 2017-05-05, similarity 0.8438):
[0001437749-17-008152:note_history:18]
2016,
 the FASB issued ASU 
2016
-
15,

- changed (2017-08-04):
[0001437749-17-013821:note_history:19]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does 
not
 believe that the adoption of this guidance will have a significant impact on the presentation of the statement of cash flows.
  (was, 2017-05-05, similarity 0.9846):
[0001437749-17-008152:note_history:19]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does not believe that this guidance will have a significant impact on the presentation of the statement of cash flows.

- changed (2017-08-04):
[0001437749-17-013821:note_history:20]
In 
 January 2017, 
the FASB issued ASU 
2017
-
04,
  (was, 2017-05-05, similarity 0.8308):
[0001437749-17-008152:note_history:20]
2017,
 the FASB issued ASU 
2017
-
04,

- changed (2017-08-04):
[0001437749-17-013821:note_history:21]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should 
not
 exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January 1, 2017. 
The Company has early adopted this standard, which did 
not
 have a significant impact on its consolidated financial statements.
  (was, 2017-05-05, similarity 0.9118):
[0001437749-17-008152:note_history:21]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January

- removed (2017-08-04):
[0001437749-17-008152:note_history:22]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:23]
2016).
 A summary of these acquisitions include the following:

- removed (2017-08-04):
[0001437749-17-008152:note_history:24]
|  | ● | In October 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:25]
|  | ● | In December 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:26]
|  | ● | In August 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:27]
|  | ● | In November 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:28]
|  | ● | In September 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:29]
|  | ● | In October 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:30]
|  | ● | In August 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

- removed (2017-08-04):
[0001437749-17-008152:note_history:31]
The condensed conso
lidated balance sheet as of 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:32]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:33]
2017,
 the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:34]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:35]
2017
 and 
2016,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:36]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:37]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:38]
2016.

- removed (2017-08-04):
[0001437749-17-008152:note_history:39]
In 
 May

- removed (2017-08-04):
[0001437749-17-008152:note_history:40]
In 
 August

- removed (2017-08-04):
[0001437749-17-008152:note_history:41]
In 
 January

- removed (2017-08-04):
[0001437749-17-008152:note_history:42]
1,

- removed (2017-08-04):
[0001437749-17-008152:note_history:43]
2017.
 The Company has early adopted this standard, however it does not believe that this guidance will have a significant impact on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-04):
[0001437749-17-013821:note_history:44]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 22,155 |  |  |  | 31,198 |  |
| Total |  | $ | 22,155 |  |  | $ | 31,198 |  |
  (was, 2017-05-05, similarity 0.9129):
[0001437749-17-008152:note_history:44]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 28,078 |  |  |  | 31,198 |  |
| Total |  | $ | 28,078 |  |  | $ | 31,198 |  |

- changed (2017-08-04):
[0001437749-17-013821:note_history:45]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,800 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,845 |  |  |  | 4,647 |  |
| Other |  |  | 7,890 |  |  |  | 14,753 |  |
| Total |  |  | 1,014,935 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 7,038 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 662 |  |  |  | 566 |  |
| Total |  | $ | 1,007,235 |  |  | $ | 1,006,758 |  |
  (was, 2017-05-05, similarity 0.9694):
[0001437749-17-008152:note_history:45]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,187 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,724 |  |  |  | 4,647 |  |
| Other |  |  | 14,876 |  |  |  | 14,753 |  |
| Total |  |  | 1,022,413 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 13,870 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 645 |  |  |  | 566 |  |
| Total |  | $ | 1,007,898 |  |  | $ | 1,006,758 |  |

- changed (2017-08-04):
[0001437749-17-013821:note_history:46]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.
  (was, 2017-05-05, similarity 0.8587):
[0001437749-17-008152:note_history:46]
2023.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period. The Company’s net debt leverage ratio as of 
 March

- added (2017-08-04):
[0001437749-17-013821:note_history:47]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing certain applicable margin rates; base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. 
The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. 
In connection with this amendment and in accordance with ASC 
470
-
50,

- added (2017-08-04):
[0001437749-17-013821:note_history:48]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 June 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

- changed (2017-08-04):
[0001437749-17-013821:note_history:49]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.
  (was, 2017-05-05, similarity 0.8958):
[0001437749-17-008152:note_history:49]
2020.
 Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

- changed (2017-08-04):
[0001437749-17-013821:note_history:50]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 June 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$145,876
 of availability, net of outstanding letters of credit.
  (was, 2017-05-05, similarity 0.6798):
[0001437749-17-008152:note_history:50]
2015,
 the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 March

- changed (2017-08-04):
[0001437749-17-013821:note_history:51]
As 
of 
 June 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$22,155
 and 
$31,198,
 respectively.
  (was, 2017-05-05, similarity 0.9026):
[0001437749-17-008152:note_history:51]
2016,
 short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$28,078
 and 
$31,198,
 respectively.

- removed (2017-08-04):
[0001437749-17-008152:note_history:52]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November

- removed (2017-08-04):
[0001437749-17-008152:note_history:53]
2016,
 the Company amended its Term Loan to extend the maturity date from 
 May

- removed (2017-08-04):
[0001437749-17-008152:note_history:54]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:55]
2020
 to 
 May

- removed (2017-08-04):
[0001437749-17-008152:note_history:56]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:57]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:58]
2017
 was above 
3.00
 to 
1.00.
 As of 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:59]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:60]
2017,
 the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- removed (2017-08-04):
[0001437749-17-008152:note_history:61]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May

- removed (2017-08-04):
[0001437749-17-008152:note_history:62]
29,

- removed (2017-08-04):
[0001437749-17-008152:note_history:63]
May

- removed (2017-08-04):
[0001437749-17-008152:note_history:64]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:65]
2017,
 there was 
$100,000
 outstanding under the ABL Facility, leaving 
$138,097
 of availability, net of outstanding letters of credit.

- removed (2017-08-04):
[0001437749-17-008152:note_history:66]
As 
of 
 March

- removed (2017-08-04):
[0001437749-17-008152:note_history:67]
31,

- removed (2017-08-04):
[0001437749-17-008152:note_history:68]
2017
 and 
 December

- removed (2017-08-04):
[0001437749-17-008152:note_history:69]
31,


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-04):
[0001437749-17-013821:note_history:70]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,800 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,845 |  |  |  | 4,647 |  |
| Other |  |  | 7,890 |  |  |  | 14,753 |  |
| Total |  |  | 1,014,935 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 7,038 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 662 |  |  |  | 566 |  |
| Total |  | $ | 1,007,235 |  |  | $ | 1,006,758 |  |
  (was, 2017-05-05, similarity 0.9694):
[0001437749-17-008152:note_history:70]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,187 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,724 |  |  |  | 4,647 |  |
| Other |  |  | 14,876 |  |  |  | 14,753 |  |
| Total |  |  | 1,022,413 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 13,870 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 645 |  |  |  | 566 |  |
| Total |  | $ | 1,007,898 |  |  | $ | 1,006,758 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-04):
[0001437749-17-013821:note_history:71]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 22,155 |  |  |  | 31,198 |  |
| Total |  | $ | 22,155 |  |  | $ | 31,198 |  |
  (was, 2017-05-05, similarity 0.9129):
[0001437749-17-008152:note_history:71]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 28,078 |  |  |  | 31,198 |  |
| Total |  | $ | 28,078 |  |  | $ | 31,198 |  |
