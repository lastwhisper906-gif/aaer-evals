# GNRC MD&A — 0001437749-17-013821


## mdna

[0001437749-17-013821:mdna:1]
[same as prior period, unchanged from 0001437749-17-008152:mdna:1]

[0001437749-17-013821:mdna:2]
[same as prior period, unchanged from 0001437749-17-008152:mdna:2]

[0001437749-17-013821:mdna:3]
[same as prior period, unchanged from 0001437749-17-008152:mdna:3]

[0001437749-17-013821:mdna:4]
[same as prior period, unchanged from 0001437749-17-008152:mdna:4]

[0001437749-17-013821:mdna:5]
[same as prior period, unchanged from 0001437749-17-008152:mdna:5]

[0001437749-17-013821:mdna:6]
[same as prior period, unchanged from 0001437749-17-008152:mdna:6]

[0001437749-17-013821:mdna:7]
[same as prior period, unchanged from 0001437749-17-008152:mdna:7]

[0001437749-17-013821:mdna:8]
[same as prior period, unchanged from 0001437749-17-008152:mdna:8]

[0001437749-17-013821:mdna:9]
[same as prior period, unchanged from 0001437749-17-008152:mdna:9]

[0001437749-17-013821:mdna:10]
[same as prior period, unchanged from 0001437749-17-008152:mdna:10]

[0001437749-17-013821:mdna:11]
[same as prior period, unchanged from 0001437749-17-008152:mdna:11]

[0001437749-17-013821:mdna:12]
[same as prior period, unchanged from 0001437749-17-008152:mdna:12]

[0001437749-17-013821:mdna:13]
[same as prior period, unchanged from 0001437749-17-008152:mdna:13]

[0001437749-17-013821:mdna:14]
[same as prior period, unchanged from 0001437749-17-008152:mdna:14]

[0001437749-17-013821:mdna:15]
[same as prior period, unchanged from 0001437749-17-008152:mdna:15]

[0001437749-17-013821:mdna:16]
[same as prior period, unchanged from 0001437749-17-008152:mdna:16]

[0001437749-17-013821:mdna:17]
[same as prior period, unchanged from 0001437749-17-008152:mdna:17]

[0001437749-17-013821:mdna:18]
[same as prior period, unchanged from 0001437749-17-008152:mdna:18]

[0001437749-17-013821:mdna:19]
[same as prior period, unchanged from 0001437749-17-008152:mdna:19]

[0001437749-17-013821:mdna:20]
[same as prior period, unchanged from 0001437749-17-008152:mdna:20]

[0001437749-17-013821:mdna:21]
[same as prior period, unchanged from 0001437749-17-008152:mdna:21]

[0001437749-17-013821:mdna:22]
[same as prior period, unchanged from 0001437749-17-008152:mdna:22]

[0001437749-17-013821:mdna:23]
Over the past several years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q, and in Item 8 (Note 1 “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-013821:mdna:24]
[same as prior period, unchanged from 0001437749-17-008152:mdna:24]

[0001437749-17-013821:mdna:25]
[same as prior period, unchanged from 0001437749-17-008152:mdna:25]

[0001437749-17-013821:mdna:26]
[same as prior period, unchanged from 0001437749-17-008152:mdna:26]

[0001437749-17-013821:mdna:27]
[same as prior period, unchanged from 0001437749-17-008152:mdna:27]

[0001437749-17-013821:mdna:28]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-17-013821:mdna:29]
[same as prior period, unchanged from 0001437749-17-008152:mdna:29]

[0001437749-17-013821:mdna:30]
[same as prior period, unchanged from 0001437749-17-008152:mdna:30]

[0001437749-17-013821:mdna:31]
[same as prior period, unchanged from 0001437749-17-008152:mdna:31]

[0001437749-17-013821:mdna:32]
[same as prior period, unchanged from 0001437749-17-008152:mdna:32]

[0001437749-17-013821:mdna:33]
[same as prior period, unchanged from 0001437749-17-008152:mdna:33]

[0001437749-17-013821:mdna:34]
[same as prior period, unchanged from 0001437749-17-008152:mdna:34]

[0001437749-17-013821:mdna:35]
[same as prior period, unchanged from 0001437749-17-008152:mdna:35]

[0001437749-17-013821:mdna:36]
[same as prior period, unchanged from 0001437749-17-008152:mdna:36]

[0001437749-17-013821:mdna:37]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense decreased during the six months ended June 30, 2017 compared to the six months ended June 30, 2016, primarily due to the $25 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other foreign subsidiaries, partially offset by an increase in the LIBOR rate. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-17-013821:mdna:38]
[same as prior period, unchanged from 0001437749-17-008152:mdna:38]

[0001437749-17-013821:mdna:39]
[same as prior period, unchanged from 0001437749-17-008152:mdna:39]

[0001437749-17-013821:mdna:40]
Three months ended June 30, 2017 compared to the three months ended June 30, 2016

[0001437749-17-013821:mdna:41]
[same as prior period, unchanged from 0001437749-17-008152:mdna:41]

[0001437749-17-013821:mdna:42]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 28,000 |  |  |  | 7.6 | % |
| Cost of goods sold |  |  | 260,916 |  |  |  | 243,229 |  |  |  | 17,687 |  |  |  | 7.3 | % |
| Gross profit |  |  | 134,460 |  |  |  | 124,147 |  |  |  | 10,313 |  |  |  | 8.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 43,116 |  |  |  | 42,366 |  |  |  | 750 |  |  |  | 1.8 | % |
| Research and development |  |  | 10,567 |  |  |  | 9,889 |  |  |  | 678 |  |  |  | 6.9 | % |
| General and administrative |  |  | 21,361 |  |  |  | 19,593 |  |  |  | 1,768 |  |  |  | 9.0 | % |
| Amortization of intangible assets |  |  | 7,129 |  |  |  | 8,217 |  |  |  | (1,088 | ) |  |  | -13.2 | % |
| Total operating expenses |  |  | 82,173 |  |  |  | 80,065 |  |  |  | 2,108 |  |  |  | 2.6 | % |
| Income from operations |  |  | 52,287 |  |  |  | 44,082 |  |  |  | 8,205 |  |  |  | 18.6 | % |
| Total other expense, net |  |  | (12,428 | ) |  |  | (11,218 | ) |  |  | (1,210 | ) |  |  | 10.8 | % |
| Income before provision for income taxes |  |  | 39,859 |  |  |  | 32,864 |  |  |  | 6,995 |  |  |  | 21.3 | % |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 2,193 |  |  |  | 18.4 | % |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 4,802 |  |  |  | 22.9 | % |
| Net income attributable to noncontrolling interests |  |  | 85 |  |  |  | 55 |  |  |  | 30 |  |  |  | 54.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 4,772 |  |  |  | 22.8 | % |

[0001437749-17-013821:mdna:43]
[same as prior period, unchanged from 0001437749-17-008152:mdna:43]

[0001437749-17-013821:mdna:44]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 305,907 |  |  | $ | 286,720 |  |  | $ | 19,187 |  |  |  | 6.7 | % |
| International |  |  | 89,469 |  |  |  | 80,656 |  |  |  | 8,813 |  |  |  | 10.9 | % |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 28,000 |  |  |  | 7.6 | % |

[0001437749-17-013821:mdna:45]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 64,157 |  |  | $ | 57,352 |  |  | $ | 6,805 |  |  |  | 11.9 | % |
| International |  |  | 6,034 |  |  |  | 6,574 |  |  |  | (540 | ) |  |  | -8.2 | % |
| Total Adjusted EBITDA |  | $ | 70,191 |  |  | $ | 63,926 |  |  | $ | 6,265 |  |  |  | 9.8 | % |

[0001437749-17-013821:mdna:46]
[same as prior period, unchanged from 0001437749-17-008152:mdna:46]

[0001437749-17-013821:mdna:47]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 198,117 |  |  | $ | 181,735 |  |  | $ | 16,382 |  |  |  | 9.0 | % |
| Commercial & industrial products |  |  | 170,755 |  |  |  | 156,730 |  |  |  | 14,025 |  |  |  | 8.9 | % |
| Other |  |  | 26,504 |  |  |  | 28,911 |  |  |  | (2,407 | ) |  |  | -8.3 | % |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 28,000 |  |  |  | 7.6 | % |

[0001437749-17-013821:mdna:48]
Net sales.    The increase in Domestic sales for the three months ended June 30, 2017 was primarily due to strong growth in shipments of home standby generators and mobile products, which was partially offset by a decline in residential portable sales due to excess levels of field inventory during the current-year quarter along with new product placement with certain retail customers in the prior-year quarter.

[0001437749-17-013821:mdna:49]
The increase in International sales for the three months ended June 30, 2017 was primarily due to the contribution from the recent acquisition of Motortech.

[0001437749-17-013821:mdna:50]
The total net sales contribution from non-annualized recent acquisitions to the three months ended June 30, 2017 was $9.5 million.

[0001437749-17-013821:mdna:51]
Gross profit.    Gross profit margin for the second quarter of 2017 was 34.0% compared to 33.8% in the prior-year second quarter. The prior-year included $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these expenses, gross margin in the prior year was 34.7%. The pro-forma decline in gross margin as compared to the prior year was due to a number of factors including higher commodity prices seen in prior quarters and, to a lesser extent, certain plant consolidation costs.

[0001437749-17-013821:mdna:52]
Operating expenses.    The increase in operating expenses was primarily driven by the addition of recurring operating expenses associated with the Motortech acquisition.

[0001437749-17-013821:mdna:53]
Other expense.    The increase in other expense was primarily due to an increase in foreign currency transactional losses partially offset by a decrease in interest expense due to the $25 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other foreign subsidiaries.

[0001437749-17-013821:mdna:54]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2017 and 2016 were 35.4% and 36.4%, respectively. The decrease in the effective income tax rate year-over-year is partially attributable to an increase in the Company’s federal domestic production activity deduction due to higher pre-tax income during the first half of 2017 compared to the first half of 2016.

[0001437749-17-013821:mdna:55]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above.

[0001437749-17-013821:mdna:56]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the three months ended June 30, 2017 were 21.0% of net sales compared to 20.0% in the prior-year second quarter. Adjusted EBITDA margin in the current year was positively impacted by improved overall leverage of fixed operating expenses on the organic increase in sales, partially offset by the unfavorable impact from higher commodity prices seen in prior quarters.

[0001437749-17-013821:mdna:57]
Adjusted EBITDA margins for the International segment, before deducting for noncontrolling interests, for the three months ended June 30, 2017 were 6.7% of net sales compared to 8.2% in the prior-year second quarter. The decline was primarily due to unfavorable foreign currency impacts and sales mix, along with higher commodity prices and increased overall operating expenses including the expansion of branch operations. These impacts were partially offset by the addition of the Motortech acquisition.

[0001437749-17-013821:mdna:58]
Adjusted Net Income.    Adjusted Net Income of $43.3 million for the three months ended June 30, 2017 increased 1.4% from $42.7 million for the three months ended June 30, 2016, due to the factors outlined above together with an increase in cash income tax expense.

[0001437749-17-013821:mdna:59]
[same as prior period, unchanged from 0001437749-17-008152:mdna:59]

[0001437749-17-013821:mdna:60]
Six months ended June 30, 2017 compared to the six months ended June 30, 2016

[0001437749-17-013821:mdna:61]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-17-013821:mdna:62]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 727,190 |  |  | $ | 653,911 |  |  | $ | 73,279 |  |  |  | 11.2 | % |
| Cost of goods sold |  |  | 482,244 |  |  |  | 431,704 |  |  |  | 50,540 |  |  |  | 11.7 | % |
| Gross profit |  |  | 244,946 |  |  |  | 222,207 |  |  |  | 22,739 |  |  |  | 10.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 83,300 |  |  |  | 79,635 |  |  |  | 3,665 |  |  |  | 4.6 | % |
| Research and development |  |  | 20,868 |  |  |  | 18,086 |  |  |  | 2,782 |  |  |  | 15.4 | % |
| General and administrative |  |  | 42,334 |  |  |  | 37,426 |  |  |  | 4,908 |  |  |  | 13.1 | % |
| Amortization of intangible assets |  |  | 14,312 |  |  |  | 16,014 |  |  |  | (1,702 | ) |  |  | -10.6 | % |
| Total operating expenses |  |  | 160,814 |  |  |  | 151,161 |  |  |  | 9,653 |  |  |  | 6.4 | % |
| Income from operations |  |  | 84,132 |  |  |  | 71,046 |  |  |  | 13,086 |  |  |  | 18.4 | % |
| Total other expense, net |  |  | (23,173 | ) |  |  | (22,251 | ) |  |  | (922 | ) |  |  | 4.1 | % |
| Income before provision for income taxes |  |  | 60,959 |  |  |  | 48,795 |  |  |  | 12,164 |  |  |  | 24.9 | % |
| Provision for income taxes |  |  | 22,365 |  |  |  | 17,640 |  |  |  | 4,725 |  |  |  | 26.8 | % |
| Net income |  |  | 38,594 |  |  |  | 31,155 |  |  |  | 7,439 |  |  |  | 23.9 | % |
| Net income attributable to noncontrolling interests |  |  | 92 |  |  |  | 59 |  |  |  | 33 |  |  |  | 55.9 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 38,502 |  |  | $ | 31,096 |  |  | $ | 7,406 |  |  |  | 23.8 | % |

[0001437749-17-013821:mdna:63]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-17-013821:mdna:64]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 554,404 |  |  | $ | 534,736 |  |  | $ | 19,668 |  |  |  | 3.7 | % |
| International |  |  | 172,786 |  |  |  | 119,175 |  |  |  | 53,611 |  |  |  | 45.0 | % |
| Total net sales |  | $ | 727,190 |  |  | $ | 653,911 |  |  | $ | 73,279 |  |  |  | 11.2 | % |

[0001437749-17-013821:mdna:65]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 107,003 |  |  | $ | 104,212 |  |  | $ | 2,791 |  |  |  | 2.7 | % |
| International |  |  | 10,846 |  |  |  | 9,523 |  |  |  | 1,323 |  |  |  | 13.9 | % |
| Total Adjusted EBITDA |  | $ | 117,849 |  |  | $ | 113,735 |  |  | $ | 4,114 |  |  |  | 3.6 | % |

[0001437749-17-013821:mdna:66]
The following table sets forth our product class information for the periods indicated:

[0001437749-17-013821:mdna:67]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 352,973 |  |  | $ | 340,716 |  |  | $ | 12,257 |  |  |  | 3.6 | % |
| Commercial & industrial products |  |  | 322,198 |  |  |  | 259,720 |  |  |  | 62,478 |  |  |  | 24.1 | % |
| Other |  |  | 52,019 |  |  |  | 53,475 |  |  |  | (1,456 | ) |  |  | -2.7 | % |
| Total net sales |  | $ | 727,190 |  |  | $ | 653,911 |  |  | $ | 73,279 |  |  |  | 11.2 | % |

[0001437749-17-013821:mdna:68]
Net sales.    The increase in Domestic sales for the six months ended June 30, 2017 was primarily due to strong growth in shipments of mobile products and home standby generators, as well as increased shipments of C&I stationary and specialty outdoor power equipment products. This strength was largely offset by a decline in residential portable sales due to excess levels of field inventory during the current year along with new product placement with certain retail customers in the prior year.

[0001437749-17-013821:mdna:69]
The increase in International sales for the six months ended June 30, 2017 was primarily due to the contribution from the recent acquisitions of Pramac and Motortech. The growth was also due to increased organic shipments of stationary products, most notably within the European and Latin American regions.

[0001437749-17-013821:mdna:70]
The total net sales contribution from non-annualized recent acquisitions to the six months ended June 30, 2017 was $50.0 million.

[0001437749-17-013821:mdna:71]
Gross profit.    Gross profit margin for the first half of 2017 was 33.7% compared to 34.0% in the prior-year first half. The prior year included $2.7 million of business optimization and restructuring costs classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry, as well as $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these charges, gross margin in the prior-year was 34.9%. The pro-forma decline in gross margin as compared to the prior year was due to the mix impact from the Pramac and Motortech acquisitions, higher commodity prices seen in prior quarters and certain plant consolidation costs. These impacts were partially offset by net favorable pricing impacts.

[0001437749-17-013821:mdna:72]
Operating expenses.    Operating expenses increased $9.7 million, or 6.4%, as compared to the first half of 2016. The prior-year included $4.4 million of business optimization and restructuring costs classified within operating expenses to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $14.1 million, or 9.6%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with the recent acquisitions of Pramac and Motortech.

[0001437749-17-013821:mdna:73]
Other expense.    The increase in other expense was primarily due to an increase in foreign currency transactional losses partially offset by a decrease in interest expense due to the $25 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other foreign subsidiaries.

[0001437749-17-013821:mdna:74]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2017 and 2016 were 36.7% and 36.2%, respectively. The increase in the effective income tax rate in 2017 was primarily due to non-recurring discrete tax items.

[0001437749-17-013821:mdna:75]
Net income attributable to Generac Holdings Inc.    The prior-year net income attributable to Generac Holdings Inc. includes $7.1 million of pre-tax business optimization and restructuring costs to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, net income attributable to the Company was flat, based on the factors outlined above.

[0001437749-17-013821:mdna:76]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the six months ended June 30, 2017 were 19.3% of net sales compared to 19.5% for the six months ended June 30, 2016. Adjusted EBITDA margins decreased due to overall unfavorable product mix and the unfavorable impact from higher commodity prices seen in prior quarters, mostly offset by improved overall leverage of fixed operating expenses on the organic increase in sales and net favorable pricing impacts.

[0001437749-17-013821:mdna:77]
Adjusted EBITDA margins for the International segment, before deducting for noncontrolling interests, for the six months ended June 30, 2017 were 6.3% of net sales compared to 8.0% for the six months ended June 30, 2016. The decline was primarily due to the Pramac acquisition, unfavorable foreign currency impacts and sales mix, higher commodity prices and increased overall operating expenses including the expansion of branch operations. These impacts were partially offset by the addition of the Motortech acquisition.

[0001437749-17-013821:mdna:78]
Adjusted Net Income.    Adjusted Net Income of $69.1 million for the six months ended June 30, 2017 decreased 6.1% from $73.6 million for the six months ended June 30, 2016, due to the factors outlined above and an increase in cash income tax expense.

[0001437749-17-013821:mdna:79]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-17-013821:mdna:80]
[same as prior period, unchanged from 0001437749-17-008152:mdna:60]

[0001437749-17-013821:mdna:81]
[same as prior period, unchanged from 0001437749-17-008152:mdna:61]

[0001437749-17-013821:mdna:82]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. Following the amendment in May 2017, the Term Loan bears interest at rates based upon either a base rate plus a fixed applicable margin of 1.25% or adjusted LIBOR rate plus a fixed applicable margin of 2.25%, subject to a LIBOR floor of 0.75%. As of June 30, 2017, we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-013821:mdna:83]
Our credit agreements also provide for the $250.0 million ABL Facility. The maturity date of the ABL Facility is May 29, 2020. In May 2015, we borrowed $100.0 million under the ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of June 30, 2017, there was $100.0 million outstanding under the ABL Facility, and we were in compliance with all of its covenants.

[0001437749-17-013821:mdna:84]
At June 30, 2017, we had cash and cash equivalents on hand of $67.1 million and $145.9 million of availability under our ABL Facility, net of outstanding letters of credit.

[0001437749-17-013821:mdna:85]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. For the three months ended June 30, 2017, the Company repurchased 844,500 shares of its common stock for $30.0 million. Since the inception of both programs, we have repurchased 8,116,706 shares of our common stock for $$279.9 million, all funded with cash on hand.

[0001437749-17-013821:mdna:86]
[same as prior period, unchanged from 0001437749-17-008152:mdna:66]

[0001437749-17-013821:mdna:87]
[same as prior period, unchanged from 0001437749-17-008152:mdna:67]

[0001437749-17-013821:mdna:88]
We believe that our cash flow from operations and availability under our ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-17-013821:mdna:89]
[same as prior period, unchanged from 0001437749-17-008152:mdna:69]

[0001437749-17-013821:mdna:90]
Six months ended June 30, 2017 compared to the six months ended June 30, 2016

[0001437749-17-013821:mdna:91]
[same as prior period, unchanged from 0001437749-17-008152:mdna:71]

[0001437749-17-013821:mdna:92]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 55,674 |  |  | $ | 81,235 |  |  | $ | (25,561 | ) |  |  | -31.5 | % |
| Net cash used in investing activities |  |  | (8,825 | ) |  |  | (74,843 | ) |  |  | 66,018 |  |  |  | -88.2 | % |
| Net cash used in financing activities |  |  | (49,506 | ) |  |  | (46,723 | ) |  |  | (2,783 | ) |  |  | 6.0 | % |

[0001437749-17-013821:mdna:93]
The decrease in net cash from operating activities was primarily driven by a working capital investment during the current year as compared to a benefit from the working capital reduction in the prior year as we replenished inventory levels in the first quarter of 2017 following Hurricane Matthew. This decrease is partially offset by an increase in operating income.

[0001437749-17-013821:mdna:94]
Net cash used in investing activities for the six months ended June 30, 2017 primarily represents cash payments for the purchase of property and equipment. Net cash used in investing activities for the six months ended June 30, 2016 primarily represents cash payments of $60.9 million related to the acquisition of Pramac and $14.0 million for the purchase of property and equipment. The Motortech acquisition was completed in the first quarter of 2017, but was funded in the fourth quarter of 2016.

[0001437749-17-013821:mdna:95]
Net cash used in financing activities for the six months ended June 30, 2017 primarily represents $82.8 million of debt repayments ($73.0 million of short-term borrowings and $9.8 million of long-term borrowings) and $30.0 million of payments for the repurchase of the Company’s common stock. These payments were partially offset by $65.5 million cash proceeds from borrowings ($62.4 million short-term and $3.1 million long-term).

[0001437749-17-013821:mdna:96]
Net cash used in financing activities for the six months ended June 30, 2016 primarily represents $34.6 million of payments for the repurchase of the Company’s common stock, $17.0 million of debt repayments ($10.7 million of long-term borrowings and $6.3 million of short-term borrowings) and $12.1 million related to the net share settlement of equity awards. These payments were partially offset by $10.3 million cash proceeds from short-term borrowings and a $6.7 million cash inflow related to excess tax benefits of equity awards.

[0001437749-17-013821:mdna:97]
[same as prior period, unchanged from 0001437749-17-008152:mdna:77]

[0001437749-17-013821:mdna:98]
In May 2017, the Company amended its Term Loan, which reduces future interest payments on the Term Loan. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements for further information. Other than the Term Loan amendment, there have been no material changes to our contractual obligations since the February 24, 2017 filing of our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-013821:mdna:99]
[same as prior period, unchanged from 0001437749-17-008152:mdna:79]

[0001437749-17-013821:mdna:100]
[same as prior period, unchanged from 0001437749-17-008152:mdna:80]

[0001437749-17-013821:mdna:101]
[same as prior period, unchanged from 0001437749-17-008152:mdna:81]

[0001437749-17-013821:mdna:102]
[same as prior period, unchanged from 0001437749-17-008152:mdna:82]

[0001437749-17-013821:mdna:103]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2016, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of product warranty and other contingencies; income taxes and share based compensation.

[0001437749-17-013821:mdna:104]
[same as prior period, unchanged from 0001437749-17-008152:mdna:84]

[0001437749-17-013821:mdna:105]
[same as prior period, unchanged from 0001437749-17-008152:mdna:85]

[0001437749-17-013821:mdna:106]
[same as prior period, unchanged from 0001437749-17-008152:mdna:86]

[0001437749-17-013821:mdna:107]
[same as prior period, unchanged from 0001437749-17-008152:mdna:87]

[0001437749-17-013821:mdna:108]
[same as prior period, unchanged from 0001437749-17-008152:mdna:88]

[0001437749-17-013821:mdna:109]
[same as prior period, unchanged from 0001437749-17-008152:mdna:89]

[0001437749-17-013821:mdna:110]
[same as prior period, unchanged from 0001437749-17-008152:mdna:90]

[0001437749-17-013821:mdna:111]
[same as prior period, unchanged from 0001437749-17-008152:mdna:91]

[0001437749-17-013821:mdna:112]
[same as prior period, unchanged from 0001437749-17-008152:mdna:92]

[0001437749-17-013821:mdna:113]
[same as prior period, unchanged from 0001437749-17-008152:mdna:93]

[0001437749-17-013821:mdna:114]
[same as prior period, unchanged from 0001437749-17-008152:mdna:94]

[0001437749-17-013821:mdna:115]
[same as prior period, unchanged from 0001437749-17-008152:mdna:95]

[0001437749-17-013821:mdna:116]
[same as prior period, unchanged from 0001437749-17-008152:mdna:96]

[0001437749-17-013821:mdna:117]
[same as prior period, unchanged from 0001437749-17-008152:mdna:97]

[0001437749-17-013821:mdna:118]
[same as prior period, unchanged from 0001437749-17-008152:mdna:98]

[0001437749-17-013821:mdna:119]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-17-013821:mdna:120]
[same as prior period, unchanged from 0001437749-17-008152:mdna:100]

[0001437749-17-013821:mdna:121]
[same as prior period, unchanged from 0001437749-17-008152:mdna:101]

[0001437749-17-013821:mdna:122]
[same as prior period, unchanged from 0001437749-17-008152:mdna:102]

[0001437749-17-013821:mdna:123]
[same as prior period, unchanged from 0001437749-17-008152:mdna:103]

[0001437749-17-013821:mdna:124]
[same as prior period, unchanged from 0001437749-17-008152:mdna:104]

[0001437749-17-013821:mdna:125]
[same as prior period, unchanged from 0001437749-17-008152:mdna:105]

[0001437749-17-013821:mdna:126]
[same as prior period, unchanged from 0001437749-17-008152:mdna:106]

[0001437749-17-013821:mdna:127]
[same as prior period, unchanged from 0001437749-17-008152:mdna:107]

[0001437749-17-013821:mdna:128]
[same as prior period, unchanged from 0001437749-17-008152:mdna:108]

[0001437749-17-013821:mdna:129]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-17-013821:mdna:130]
[same as prior period, unchanged from 0001437749-17-008152:mdna:110]

[0001437749-17-013821:mdna:131]
23

[0001437749-17-013821:mdna:132]
[same as prior period, unchanged from 0001437749-17-008152:mdna:112]

[0001437749-17-013821:mdna:133]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Net income attributable to noncontrolling interests (a) |  |  | 85 |  |  |  | 55 |  |  |  | 92 |  |  |  | 59 |  |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 38,594 |  |  |  | 31,155 |  |
| Interest expense |  |  | 10,893 |  |  |  | 11,380 |  |  |  | 21,681 |  |  |  | 22,415 |  |
| Depreciation and amortization |  |  | 12,986 |  |  |  | 13,650 |  |  |  | 25,583 |  |  |  | 26,443 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 22,365 |  |  |  | 17,640 |  |
| Non-cash write-down and other adjustments (b) |  |  | 1,710 |  |  |  | 2,909 |  |  |  | 1,876 |  |  |  | 2,782 |  |
| Non-cash share-based compensation expense (c) |  |  | 3,186 |  |  |  | 2,901 |  |  |  | 5,818 |  |  |  | 5,386 |  |
| Transaction costs and credit facility fees (d) |  |  | 420 |  |  |  | 237 |  |  |  | 736 |  |  |  | 760 |  |
| Business optimization expenses (e) |  |  | 1,346 |  |  |  | - |  |  |  | 1,446 |  |  |  | 7,106 |  |
| Other |  |  | (209 | ) |  |  | (15 | ) |  |  | (250 | ) |  |  | 48 |  |
| Adjusted EBITDA |  |  | 70,191 |  |  |  | 63,926 |  |  |  | 117,849 |  |  |  | 113,735 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,455 |  |  |  | 1,623 |  |  |  | 2,411 |  |  |  | 2,307 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 68,736 |  |  | $ | 62,303 |  |  | $ | 115,438 |  |  | $ | 111,428 |  |

[0001437749-17-013821:mdna:134]
(a)   Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.1 million and $2.2 million for the three and six months ended June 30, 2017, respectively, and $4.3 million and $5.5 million for the three and six months ended June 30, 2016, respectively.

[0001437749-17-013821:mdna:135]
(b)   Represents the following non-cash charges: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, transactional foreign currency gains/losses and certain purchase accounting related adjustments. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-17-013821:mdna:136]
[same as prior period, unchanged from 0001437749-17-008152:mdna:116]

[0001437749-17-013821:mdna:137]
[same as prior period, unchanged from 0001437749-17-008152:mdna:117]

[0001437749-17-013821:mdna:138]
[same as prior period, unchanged from 0001437749-17-008152:mdna:118]

[0001437749-17-013821:mdna:139]
[same as prior period, unchanged from 0001437749-17-008152:mdna:119]

[0001437749-17-013821:mdna:140]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-17-013821:mdna:141]
(e) For the three and six months ended June 30, 2017, represents severance and other non-recurring plant consolidation costs. For the six months ended June 30, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-17-013821:mdna:142]
[same as prior period, unchanged from 0001437749-17-008152:mdna:122]

[0001437749-17-013821:mdna:143]
[same as prior period, unchanged from 0001437749-17-008152:mdna:123]

[0001437749-17-013821:mdna:144]
[same as prior period, unchanged from 0001437749-17-008152:mdna:124]

[0001437749-17-013821:mdna:145]
[same as prior period, unchanged from 0001437749-17-008152:mdna:125]

[0001437749-17-013821:mdna:146]
[same as prior period, unchanged from 0001437749-17-008152:mdna:126]

[0001437749-17-013821:mdna:147]
[same as prior period, unchanged from 0001437749-17-008152:mdna:127]

[0001437749-17-013821:mdna:148]
[same as prior period, unchanged from 0001437749-17-008152:mdna:128]

[0001437749-17-013821:mdna:149]
[same as prior period, unchanged from 0001437749-17-008152:mdna:129]

[0001437749-17-013821:mdna:150]
[same as prior period, unchanged from 0001437749-17-008152:mdna:130]

[0001437749-17-013821:mdna:151]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Net income attributable to noncontrolling interests |  |  | 85 |  |  |  | 55 |  |  |  | 92 |  |  |  | 59 |  |
| Net income |  |  | 25,745 |  |  |  | 20,943 |  |  |  | 38,594 |  |  |  | 31,155 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | 11,921 |  |  |  | 22,365 |  |  |  | 17,640 |  |
| Income before provision for income taxes |  |  | 39,859 |  |  |  | 32,864 |  |  |  | 60,959 |  |  |  | 48,795 |  |
| Amortization of intangible assets |  |  | 7,129 |  |  |  | 8,217 |  |  |  | 14,312 |  |  |  | 16,014 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 818 |  |  |  | 1,066 |  |  |  | 1,308 |  |  |  | 2,122 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 429 |  |  |  | 3,443 |  |  |  | 1,014 |  |  |  | 4,690 |  |
| Business optimization expenses |  |  | 1,346 |  |  |  | - |  |  |  | 1,446 |  |  |  | 7,106 |  |
| Adjusted net income before provision for income taxes |  |  | 49,581 |  |  |  | 45,590 |  |  |  | 79,039 |  |  |  | 78,727 |  |
| Cash income tax expense (b) |  |  | (5,642 | ) |  |  | (1,450 | ) |  |  | (8,729 | ) |  |  | (3,270 | ) |
| Adjusted net income |  |  | 43,939 |  |  |  | 44,140 |  |  |  | 70,310 |  |  |  | 75,457 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 633 |  |  |  | 1,451 |  |  |  | 1,215 |  |  |  | 1,881 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 43,306 |  |  | $ | 42,689 |  |  | $ | 69,095 |  |  | $ | 73,576 |  |
| Adjusted net income per common share attributable to Generac Holdings, Inc. - diluted: |  | $ | 0.69 |  |  | $ | 0.64 |  |  | $ | 1.10 |  |  | $ | 1.11 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,635,437 |  |  |  | 66,388,581 |  |  |  | 62,849,877 |  |  |  | 66,465,770 |  |

[0001437749-17-013821:mdna:152]
[same as prior period, unchanged from 0001437749-17-008152:mdna:132]

[0001437749-17-013821:mdna:153]
(b) Amount for the three and six months ended June 30, 2017 is based on an anticipated cash income tax rate of approximately 14% for the full year ended 2017. Amount for the three and six months ended June 30, 2016 is based on an anticipated cash income tax rate of approximately 5% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-17-013821:mdna:154]
[same as prior period, unchanged from 0001437749-17-008152:mdna:134]

[0001437749-17-013821:mdna:155]
[same as prior period, unchanged from 0001437749-17-008152:mdna:135]
