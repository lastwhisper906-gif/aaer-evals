# GNRC notes — 0001437749-17-013821


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-17-013821:notes:1]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,582 |  |  | $ | 20,763 |  |
| Long-term portion - other long-term liabilities |  |  | 12,231 |  |  |  | 10,932 |  |
| Total |  | $ | 32,813 |  |  | $ | 31,695 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 7,635 |  |  | $ | 6,728 |  |
| Long-term portion - other long-term liabilities |  |  | 29,082 |  |  |  | 24,352 |  |
| Total |  | $ | 36,717 |  |  | $ | 31,080 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-17-013821:notes:2]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Commodity contracts |  | $ | 432 |  |  | $ | 623 |  |
| Foreign currency contracts |  |  | 267 |  |  |  | (150 | ) |
| Interest rate swaps |  |  | (493 | ) |  |  | (1,739 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-17-013821:notes:3]
2.

[0001437749-17-013821:notes:4]
Pramac

[0001437749-17-013821:notes:5]
Acquisition

[0001437749-17-013821:notes:6]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in Pramac for a purchase price, net of cash 
acquired, of 
$60,250.
 Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 
150
 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-17-013821:notes:7]
[same as prior period, unchanged from 0001437749-17-008152:notes:8]

[0001437749-17-013821:notes:8]
two
 years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it 
 may 
redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with 
no
 partial transfers of interest permitted.

[0001437749-17-013821:notes:9]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests
’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
11,
 “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-17-013821:notes:10]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 33,566 |  |  | $ | 35,047 |  |  | $ | 33,138 |  |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 34,253 |  |
| Net income |  |  | 92 |  |  |  | 151 |  |  |  | 210 |  |  |  | 167 |  |
| Foreign currency translation |  |  | 4,433 |  |  |  | 487 |  |  |  | 5,357 |  |  |  | 1,265 |  |
| Redemption value adjustment |  |  | (295 | ) |  |  | - |  |  |  | (909 | ) |  |  | - |  |
| Balance at end of period |  | $ | 37,796 |  |  | $ | 35,685 |  |  | $ | 37,796 |  |  | $ | 35,685 |  |

[0001437749-17-013821:notes:11]
The Company 
finalized the Pramac purchase price allocation during the 
first
 quarter of 
2017,
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The final purchase price allocation as of the balance sheet date was as follows:

[0001437749-17-013821:notes:12]
[same as prior period, unchanged from 0001437749-17-008152:notes:13]

[0001437749-17-013821:notes:13]
The goodwill ascribed to this acquisition is 
not
 deductible for tax purposes.
 The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through 
 June 30, 2017.

[0001437749-17-013821:notes:14]
The following unaudited pro forma information of t
he Company gives effect to this acquisition as though the transaction had occurred on 
 January 1, 2016. 
Consolidated net sales on a pro forma basis for the 
three
 and 
six
 month periods ended 
 June 30, 2016 
were 
$367,376
 and 
$683,258,
 respectively. The pro forma impact of this acquisition on net income and earnings per share for both the 
three
 and 
six
 month periods ended 
 June 30, 2016 
is 
not
 significant due to amortization related to acquired intangible assets and the fair value step-up of inventory in purchase accounting. This unaudited pro forma information is presented for informational purposes only and is 
not
 necessarily indicative of the results of operations that actually would have been achieved had the acquisition been consummated on 
 January 1, 2016.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-17-013821:notes:15]
[same as prior period, unchanged from 0001437749-17-008152:notes:23]

[0001437749-17-013821:notes:16]
[same as prior period, unchanged from 0001437749-17-008152:notes:24]

[0001437749-17-013821:notes:17]
[same as prior period, unchanged from 0001437749-17-008152:notes:25]

[0001437749-17-013821:notes:18]
[same as prior period, unchanged from 0001437749-17-008152:notes:26]

[0001437749-17-013821:notes:19]
[same as prior period, unchanged from 0001437749-17-008152:notes:27]

[0001437749-17-013821:notes:20]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1

[0001437749-17-013821:notes:21]
and Item 
8
 (Note 
1
 “Description of Business”) 
of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:

[0001437749-17-013821:notes:22]
[same as prior period, unchanged from 0001437749-17-008152:notes:37]

[0001437749-17-013821:notes:23]
[same as prior period, unchanged from 0001437749-17-008152:notes:38]

[0001437749-17-013821:notes:24]
[same as prior period, unchanged from 0001437749-17-008152:notes:39]

[0001437749-17-013821:notes:25]
The condensed conso
lidated balance sheet as of 
 June 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-17-013821:notes:26]
[same as prior period, unchanged from 0001437749-17-008152:notes:44]

[0001437749-17-013821:notes:27]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016.

[0001437749-17-013821:notes:28]
[same as prior period, unchanged from 0001437749-17-008152:notes:46]

[0001437749-17-013821:notes:29]
In 
 May 2014, 
the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

[0001437749-17-013821:notes:30]
[same as prior period, unchanged from 0001437749-17-008152:notes:49]

[0001437749-17-013821:notes:31]
[same as prior period, unchanged from 0001437749-17-008152:notes:50]

[0001437749-17-013821:notes:32]
606
): D

[0001437749-17-013821:notes:33]
[same as prior period, unchanged from 0001437749-17-008152:notes:52]

[0001437749-17-013821:notes:34]
Revenue from Contracts with Customers (Topic 
606
): Principal versus Agent Considerations
, ASU 
2016
-
10,

[0001437749-17-013821:notes:35]
Revenue from Contracts with Customers (Topic 
606
): Identifying Performance Obligations and Licensin

[0001437749-17-013821:notes:36]
[same as prior period, unchanged from 0001437749-17-008152:notes:55]

[0001437749-17-013821:notes:37]
Revenue from Contracts with Customers (Topic 
606
):

[0001437749-17-013821:notes:38]
Narrow-

[0001437749-17-013821:notes:39]
Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

[0001437749-17-013821:notes:40]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may 
have on its financial statements, it believes that the adoption will 
not
 have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company is currently planning to adopt the standard using the full retrospective method.

[0001437749-17-013821:notes:41]
[same as prior period, unchanged from 0001437749-17-008152:notes:59]

[0001437749-17-013821:notes:42]
[same as prior period, unchanged from 0001437749-17-008152:notes:60]

[0001437749-17-013821:notes:43]
[same as prior period, unchanged from 0001437749-17-008152:notes:61]

[0001437749-17-013821:notes:44]
In 
 August 2016, 
the FASB issued ASU 
2016
-
15,

[0001437749-17-013821:notes:45]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does 
not
 believe that the adoption of this guidance will have a significant impact on the presentation of the statement of cash flows.

[0001437749-17-013821:notes:46]
In 
 January 2017, 
the FASB issued ASU 
2017
-
04,

[0001437749-17-013821:notes:47]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should 
not
 exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January 1, 2017. 
The Company has early adopted this standard, which did 
not
 have a significant impact on its consolidated financial statements.

[0001437749-17-013821:notes:48]
[same as prior period, unchanged from 0001437749-17-008152:notes:69]

[0001437749-17-013821:notes:49]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid for withheld shares had 
no
 impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.

[0001437749-17-013821:notes:50]
There are several other new accounting pronouncements issued by the FASB. 
Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-17-013821:notes:51]
1

[0001437749-17-013821:notes:52]
3

[0001437749-17-013821:notes:53]
. Commitments and Contingencies

[0001437749-17-013821:notes:54]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,900
 and 
$33,900,
 respectively.

[0001437749-17-013821:notes:55]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-17-013821:notes:56]
[same as prior period, unchanged from 0001437749-17-008152:notes:79]

[0001437749-17-013821:notes:57]
[same as prior period, unchanged from 0001437749-17-008152:notes:80]

[0001437749-17-013821:notes:58]
The following presents a tabular disclosure of changes in 
AOCL during the 
three
 and 
six
 months ended 
 June 30, 2017 
and 
2016,
 net of tax:

[0001437749-17-013821:notes:59]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2017 |  | $ | (24,447 | ) |  | $ | (11,040 | ) |  | $ | (636 | ) |  | $ | (36,123 | ) |
| Other comprehensive income before reclassifications |  |  | 8,590 |  |  |  | - |  |  |  | 324 | (1) |  |  | 8,914 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 8,590 |  |  |  | - |  |  |  | 324 |  |  |  | 8,914 |  |
| Ending Balance – June 30, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  | $ | (27,209 | ) |

[0001437749-17-013821:notes:60]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2016 |  | $ | (7,102 | ) |  | $ | (11,362 | ) |  | $ | (2,765 | ) |  | $ | (21,229 | ) |
| Other comprehensive loss before reclassifications |  |  | (13,132 | ) |  |  | - |  |  |  | (134 | ) (2) |  |  | (13,266 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (13,132 | ) |  |  | - |  |  |  | (134 | ) |  |  | (13,266 | ) |
| Ending Balance – June 30, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  | $ | (34,495 | ) |

[0001437749-17-013821:notes:61]
|  |  | Foreign Currency Translation Adjustment |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 12,190 |  |  |  | - |  |  |  | 764 | (3) |  |  | 12,954 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 12,190 |  |  |  | - |  |  |  | 764 |  |  |  | 12,954 |  |
| Ending Balance – June 30, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  | $ | (27,209 | ) |

[0001437749-17-013821:notes:62]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive loss before reclassifications |  |  | (10,732 | ) |  |  | - |  |  |  | (1,288) (4) |  |  | (12,020 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (10,732 | ) |  |  | - |  |  |  | (1,288 | ) |  |  | (12,020 | ) |
| Ending Balance – June 30, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  | $ | (34,495 | ) |

[0001437749-17-013821:notes:63]
|  | (1) | Represents unrealized gains of $531, net of tax effect of $(207) for the three months ended June 30, 2017. |

[0001437749-17-013821:notes:64]
|  | (2) | Represents unrealized losses of $(219), net of tax benefit of $85 for the three months ended June 30, 2016. |

[0001437749-17-013821:notes:65]
|  | (3) | Represents unrealized gains of $1,254, net of tax effect of $(490) for the six months ended June 30, 2017. |

[0001437749-17-013821:notes:66]
|  | (4) | Represents unrealized losses of $(2,115), net of tax benefit of $827 for the six months ended June 30, 2016. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-013821:notes:67]
9

[0001437749-17-013821:notes:68]
. Credit Agreements

[0001437749-17-013821:notes:69]
Short-term borrowings included in the 
condensed consolidated balance sheets consist of the following:

[0001437749-17-013821:notes:70]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 22,155 |  |  |  | 31,198 |  |
| Total |  | $ | 22,155 |  |  | $ | 31,198 |  |

[0001437749-17-013821:notes:71]
Long-term borrowings in the 
condensed consolidated balance sheets include the following:

[0001437749-17-013821:notes:72]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,800 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,845 |  |  |  | 4,647 |  |
| Other |  |  | 7,890 |  |  |  | 14,753 |  |
| Total |  |  | 1,014,935 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 7,038 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 662 |  |  |  | 566 |  |
| Total |  | $ | 1,007,235 |  |  | $ | 1,006,758 |  |

[0001437749-17-013821:notes:73]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-17-013821:notes:74]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing certain applicable margin rates; base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. 
The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. 
In connection with this amendment and in accordance with ASC 
470
-
50,

[0001437749-17-013821:notes:75]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 June 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-17-013821:notes:76]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-17-013821:notes:77]
In

[0001437749-17-013821:notes:78]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 June 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$145,876
 of availability, net of outstanding letters of credit.

[0001437749-17-013821:notes:79]
As 
of 
 June 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$22,155
 and 
$31,198,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-17-013821:notes:80]
[same as prior period, unchanged from 0001437749-17-008152:notes:109]

[0001437749-17-013821:notes:81]
[same as prior period, unchanged from 0001437749-17-008152:notes:110]

[0001437749-17-013821:notes:82]
Derivatives and Hedging
, which requires derivative instruments be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does 
not
 hold or issue derivative financial instruments for trading purposes.

[0001437749-17-013821:notes:83]
[same as prior period, unchanged from 0001437749-17-008152:notes:112]

[0001437749-17-013821:notes:84]
The Company 
is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. At 
 June 30, 2017,

[0001437749-17-013821:notes:85]
December 31, 2016 
and 
 June 30, 2016, 
the Company had 
one
 commodity contract outstanding, covering the purchases of copper.

[0001437749-17-013821:notes:86]
Because these contracts do 
not
 qualify for hedge 
accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains recognized for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$2
 and 
$185,
 respectively. Net pre-tax gains recognized for the 
three
 and 
six
 months ended 
 June 30, 2016 
were 
$82
 and 
$76,
 respectively.

[0001437749-17-013821:notes:87]
[same as prior period, unchanged from 0001437749-17-008152:notes:121]

[0001437749-17-013821:notes:88]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies
 other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 June 30, 2017,

[0001437749-17-013821:notes:89]
December 31, 2016 
and 
 June 30, 2016, 
the Company had eighteen, 
thirty-eight
 and 
twelve
 foreign currency contracts outstanding, respectively.

[0001437749-17-013821:notes:90]
Because these contracts do 
not
 qualify for 
hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains recognized for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$380
 and 
$179,
 respectively. Net pre-tax gains (losses) recognized for the 
three
 and 
six
 months ended 
 June 30, 2016 
were 
$1
 and $(
178
), respectively.

[0001437749-17-013821:notes:91]
[same as prior period, unchanged from 0001437749-17-008152:notes:127]

[0001437749-17-013821:notes:92]
October 2013, 
the Company entered into 
two
 interest rate swap agreements, and in 
 May 2014, 
the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.
 For additional details on these interest rate swaps, refer to Item 
7A
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016.

[0001437749-17-013821:notes:93]
In 
 June 2017, 
the Company entered into

[0001437749-17-013821:notes:94]
ten
 additional interest rate swap agreements. These interest rate swap agreements also qualify as cash flow hedges. The following table presents the details of the additional interest rate swaps:

[0001437749-17-013821:notes:95]
| Hedged Item |  | Contract Date |  | Effective Date |  | Notional Amount |  |  | Fixed LIBOR Rate |  |  | Expiration Date |
| Interest Rate |  | June 19, 2017 |  | July 2, 2018 |  | $ | 125,000 |  |  |  | 1.6543% |  |  | July 1, 2019 |
| Interest Rate |  | June 19, 2017 |  | July 1, 2019 |  |  | 125,000 |  |  |  | 1.9053% |  |  | July 1, 2020 |
| Interest Rate |  | June 19, 2017 |  | July 1, 2020 |  |  | 125,000 |  |  |  | 2.1328% |  |  | July 1, 2021 |
| Interest Rate |  | June 19, 2017 |  | July 1, 2021 |  |  | 125,000 |  |  |  | 2.3453% |  |  | July 1, 2022 |
| Interest Rate |  | June 19, 2017 |  | July 1, 2022 |  |  | 125,000 |  |  |  | 2.4828% |  |  | May 31, 2023 |
| Interest Rate |  | June 30, 2017 |  | July 2, 2018 |  |  | 125,000 |  |  |  | 1.7090% |  |  | July 1, 2019 |
| Interest Rate |  | June 30, 2017 |  | July 1, 2019 |  |  | 125,000 |  |  |  | 1.9750% |  |  | July 1, 2020 |
| Interest Rate |  | June 30, 2017 |  | July 1, 2020 |  |  | 125,000 |  |  |  | 2.2170% |  |  | July 1, 2021 |
| Interest Rate |  | June 30, 2017 |  | July 1, 2021 |  |  | 125,000 |  |  |  | 2.4360% |  |  | July 1, 2022 |
| Interest Rate |  | June 30, 2017 |  | July 1, 2022 |  |  | 125,000 |  |  |  | 2.5910% |  |  | May 31, 2023 |

[0001437749-17-013821:notes:96]
[same as prior period, unchanged from 0001437749-17-008152:notes:131]

[0001437749-17-013821:notes:97]
[same as prior period, unchanged from 0001437749-17-008152:notes:132]

[0001437749-17-013821:notes:98]
The fair 
value of the commodity and foreign currency contracts are included in other assets, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of 
 June 30, 2017. 
The fair value of the commodity contract is included in other assets, the fair value of the foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of 
 December 31, 2016. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 June 30, 2017 
and 
 December 31, 2016 
is an asset of 
$206
 and a liability of 
$1,295,
 respectively, which represents the amount the Company would either receive or need to pay upon exit of the agreements on those dates.

[0001437749-17-013821:notes:99]
The 
amount of gains recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$324
 and 
$764,
 respectively. The amount of losses for the 
three
 and 
six
 months ended 
 June 30, 2016 
were 
$134
 and 
$1,288,
 respectively.

[0001437749-17-013821:notes:100]
T
he amount of pre-tax gains recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts 
not
 designated as hedging instruments for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$382
 and 
$364,
 respectively. The amount of pre-tax gains (losses) for the 
three
 and 
six
 months ended 
 June 30, 2016 
were 
$83
 and $(
102
), respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-013821:notes:101]
11

[0001437749-17-013821:notes:102]
[same as prior period, unchanged from 0001437749-17-008152:notes:140]

[0001437749-17-013821:notes:103]
[same as prior period, unchanged from 0001437749-17-008152:notes:141]

[0001437749-17-013821:notes:104]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | 20,888 |  |  | $ | 38,502 |  |  | $ | 31,096 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 295 |  |  |  | - |  |  |  | 909 |  |  |  | - |  |
| Net income attributable to common shareholders |  | $ | 25,955 |  |  | $ | 20,888 |  |  | $ | 39,411 |  |  | $ | 31,096 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,146,393 |  |  |  | 65,870,714 |  |  |  | 62,260,170 |  |  |  | 65,955,455 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 489,044 |  |  |  | 517,867 |  |  |  | 589,707 |  |  |  | 510,315 |  |
| Diluted shares |  |  | 62,635,437 |  |  |  | 66,388,581 |  |  |  | 62,849,877 |  |  |  | 66,465,770 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | 0.32 |  |  | $ | 0.63 |  |  | $ | 0.47 |  |
| Diluted |  | $ | 0.41 |  |  | $ | 0.31 |  |  | $ | 0.63 |  |  | $ | 0.47 |  |

[0001437749-17-013821:notes:105]
(
1
) Excludes 
approximately 
279,200
 stock options and 
7,000
 shares of restricted stock for the 
three
 month period ended 
 June 30, 2017, 
and 
193,200
 stock options for the 
six
 month period ended 
 June 30, 2017, 
as the impact of such awards was anti-dilutive. Excludes approximately 
189,500
 stock options and 
3,000
 shares of restricted stock for the 
three
 month period ended 
 June 30, 2016, 
and 
215,800
 stock options and 
3,400
 shares of restricted stock for the 
six
 month period ended 
 June 30, 2016, 
as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-013821:notes:106]
[same as prior period, unchanged from 0001437749-17-008152:notes:146]

[0001437749-17-013821:notes:107]
[same as prior period, unchanged from 0001437749-17-008152:notes:147]

[0001437749-17-013821:notes:108]
[same as prior period, unchanged from 0001437749-17-008152:notes:148]

[0001437749-17-013821:notes:109]
Fair Value Measurement
, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 
820
-
10
 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a 
three
-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 
1
) observable inputs such as quoted prices in active markets; (Level 
2
) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 
3
) unobservable inputs in which there is little or 
no
 market data, which require the reporting entity to develop its own assumptions.

[0001437749-17-013821:notes:110]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts 
receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$903,294,
 was approximately 
$902,730
 (Level 
2
) at 
 June 30, 2017, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-17-013821:notes:111]
[same as prior period, unchanged from 0001437749-17-008152:notes:152]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-013821:notes:112]
12

[0001437749-17-013821:notes:113]
[same as prior period, unchanged from 0001437749-17-008152:notes:154]

[0001437749-17-013821:notes:114]
[same as prior period, unchanged from 0001437749-17-008152:notes:155]

[0001437749-17-013821:notes:115]
six
 months ended 
 June 30, 2017 
and 
2016
 were 
36.7%
 and 
36.2%,
 respectively. The increase in the effective income tax rate in 
2017
 was primarily due to non-recurring discrete tax items.

[0001437749-17-013821:notes:116]
The Company files U.S. federal, U.S. state, and foreign jurisdiction tax returns that are subject to examination up to the expiration of the statute of limitations. We believe the tax positions taken on our returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded.

[0001437749-17-013821:notes:117]
The Company is currently under examination in multiple jurisdictions and is working to address all 
matters. While the Company does 
not
 believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination 
 may 
result in differences from what was recorded. Such differences 
 may 
affect the provision for income taxes in the period in which the determination is made, and could impact the company’s financial results.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-17-013821:notes:118]
[same as prior period, unchanged from 0001437749-17-008152:notes:158]

[0001437749-17-013821:notes:119]
[same as prior period, unchanged from 0001437749-17-008152:notes:159]

[0001437749-17-013821:notes:120]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable.
 Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the lives of the contracts.

[0001437749-17-013821:notes:121]
[same as prior period, unchanged from 0001437749-17-008152:notes:161]

[0001437749-17-013821:notes:122]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 32,008 |  |  | $ | 31,904 |  |  | $ | 31,695 |  |  | $ | 30,197 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 43 |  |  |  | 840 |  |
| Payments |  |  | (4,285 | ) |  |  | (4,900 | ) |  |  | (8,845 | ) |  |  | (8,552 | ) |
| Provision for warranty issued |  |  | 4,086 |  |  |  | 4,220 |  |  |  | 8,246 |  |  |  | 7,702 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,004 |  |  |  | (489 | ) |  |  | 1,674 |  |  |  | 548 |  |
| Balance at end of period |  | $ | 32,813 |  |  | $ | 30,735 |  |  | $ | 32,813 |  |  | $ | 30,735 |  |

[0001437749-17-013821:notes:123]
[same as prior period, unchanged from 0001437749-17-008152:notes:163]

[0001437749-17-013821:notes:124]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 31,451 |  |  | $ | 28,830 |  |  | $ | 31,080 |  |  | $ | 28,961 |  |
| Deferred revenue contracts issued |  |  | 6,898 |  |  |  | 1,619 |  |  |  | 8,867 |  |  |  | 2,763 |  |
| Amortization of deferred revenue contracts |  |  | (1,632 | ) |  |  | (1,367 | ) |  |  | (3,230 | ) |  |  | (2,642 | ) |
| Balance at end of period |  | $ | 36,717 |  |  | $ | 29,082 |  |  | $ | 36,717 |  |  | $ | 29,082 |  |

[0001437749-17-013821:notes:125]
[same as prior period, unchanged from 0001437749-17-008152:notes:165]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-17-013821:notes:126]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Land and improvements |  | $ | 12,696 |  |  | $ | 12,079 |  |
| Buildings and improvements |  |  | 127,167 |  |  |  | 122,747 |  |
| Machinery and equipment |  |  | 87,647 |  |  |  | 81,687 |  |
| Dies and tools |  |  | 24,222 |  |  |  | 23,269 |  |
| Vehicles |  |  | 1,702 |  |  |  | 1,474 |  |
| Office equipment and systems |  |  | 69,166 |  |  |  | 66,929 |  |
| Leasehold improvements |  |  | 2,397 |  |  |  | 2,319 |  |
| Construction in progress |  |  | 7,060 |  |  |  | 8,654 |  |
| Gross property and equipment |  |  | 332,057 |  |  |  | 319,158 |  |
| Accumulated depreciation |  |  | (115,001 | ) |  |  | (106,365 | ) |
| Total |  | $ | 217,056 |  |  | $ | 212,793 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-17-013821:notes:127]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Product Classes |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Residential products |  | $ | 198,117 |  |  | $ | 181,735 |  |  | $ | 352,973 |  |  | $ | 340,716 |  |
| Commercial & industrial products |  |  | 170,755 |  |  |  | 156,730 |  |  |  | 322,198 |  |  |  | 259,720 |  |
| Other |  |  | 26,504 |  |  |  | 28,911 |  |  |  | 52,019 |  |  |  | 53,475 |  |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 727,190 |  |  | $ | 653,911 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-17-013821:notes:128]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Raw material |  | $ | 225,472 |  |  | $ | 218,911 |  |
| Work-in-process |  |  | 4,448 |  |  |  | 2,950 |  |
| Finished goods |  |  | 148,190 |  |  |  | 127,870 |  |
| Total |  | $ | 378,110 |  |  | $ | 349,731 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-013821:notes:129]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 305,907 |  |  | $ | 286,720 |  |  | $ | 554,404 |  |  | $ | 534,736 |  |
| International |  |  | 89,469 |  |  |  | 80,656 |  |  |  | 172,786 |  |  |  | 119,175 |  |
| Total net sales |  | $ | 395,376 |  |  | $ | 367,376 |  |  | $ | 727,190 |  |  | $ | 653,911 |  |

[0001437749-17-013821:notes:130]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 64,157 |  |  | $ | 57,352 |  |  | $ | 107,003 |  |  | $ | 104,212 |  |
| International |  |  | 6,034 |  |  |  | 6,574 |  |  |  | 10,846 |  |  |  | 9,523 |  |
| Total adjusted EBITDA |  | $ | 70,191 |  |  | $ | 63,926 |  |  | $ | 117,849 |  |  | $ | 113,735 |  |
| Interest expense |  |  | (10,893 | ) |  |  | (11,380 | ) |  |  | (21,681 | ) |  |  | (22,415 | ) |
| Depreciation and amortization |  |  | (12,986 | ) |  |  | (13,650 | ) |  |  | (25,583 | ) |  |  | (26,443 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,710 | ) |  |  | (2,909 | ) |  |  | (1,876 | ) |  |  | (2,782 | ) |
| Non-cash share-based compensation expense (2) |  |  | (3,186 | ) |  |  | (2,901 | ) |  |  | (5,818 | ) |  |  | (5,386 | ) |
| Transaction costs and credit facility fees (3) |  |  | (420 | ) |  |  | (237 | ) |  |  | (736 | ) |  |  | (760 | ) |
| Business optimization expenses (4) |  |  | (1,346 | ) |  |  | - |  |  |  | (1,446 | ) |  |  | (7,106 | ) |
| Other |  |  | 209 |  |  |  | 15 |  |  |  | 250 |  |  |  | (48 | ) |
| Income before provision for income taxes |  | $ | 39,859 |  |  | $ | 32,864 |  |  | $ | 60,959 |  |  | $ | 48,795 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-013821:notes:131]
[same as prior period, unchanged from 0001437749-17-008152:notes:171]

[0001437749-17-013821:notes:132]
[same as prior period, unchanged from 0001437749-17-008152:notes:172]

[0001437749-17-013821:notes:133]
T
he Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac and Motortech acquisitions, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. All segment information has been retrospectively adjusted for all periods presented to reflect the current reportable segment structure.

[0001437749-17-013821:notes:134]
[same as prior period, unchanged from 0001437749-17-008152:notes:174]

[0001437749-17-013821:notes:135]
Management 
evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-17-013821:notes:136]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. |

[0001437749-17-013821:notes:137]
[same as prior period, unchanged from 0001437749-17-008152:notes:177]

[0001437749-17-013821:notes:138]
[same as prior period, unchanged from 0001437749-17-008152:notes:178]

[0001437749-17-013821:notes:139]
[same as prior period, unchanged from 0001437749-17-008152:notes:179]

[0001437749-17-013821:notes:140]
T
he Company’s sales in the United States represented approximately 
73%
 and 
74%
 of total sales for the 
three
 months ended 
 June 30, 2017 
and 
2016,
 respectively, and represented approximately 
72%
 and 
78%
 of total sales for the 
six
 months ended 
 June 30, 2017 
and 
2016,
 respectively. Approximately 
85%
 and 
87%
 of the Company’s identifiable long-lived assets are located in the United States at 
 June 30, 2017 
and 
 December 31, 2016, 
respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-17-013821:notes:141]
[same as prior period, unchanged from 0001437749-17-008152:notes:183]

[0001437749-17-013821:notes:142]
[same as prior period, unchanged from 0001437749-17-008152:notes:184]

[0001437749-17-013821:notes:143]
[same as prior period, unchanged from 0001437749-17-008152:notes:185]

[0001437749-17-013821:notes:144]
[same as prior period, unchanged from 0001437749-17-008152:notes:186]


## us-gaap:TreasuryStockTextBlock

[0001437749-17-013821:notes:145]
0.
 Stock Repurchase Program

[0001437749-17-013821:notes:146]
I
n 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.

[0001437749-17-013821:notes:147]
In 
 October 2016, 
the Company
’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the program, the Company 
 may 
repurchase 
$250,000
 of its common stock over the following 
24
 months. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
three
 months ended 
 June 30, 2017, 
the Company repurchased 
844,500
 shares of its common stock for 
$30,012.
 Since the inception of both programs, the Company has repurchased 
8,116,706
 shares of its common stock for 
$279,891,
 all funded with cash on hand.
