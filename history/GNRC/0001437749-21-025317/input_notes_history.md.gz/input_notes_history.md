# GNRC note change history — 0001437749-21-018371 → 0001437749-21-025317


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001437749-21-025317:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2021 and  December 31, 2020 was approximately $97,000 and $55,600, respectively.
  (was, 2021-08-03, similarity 0.9889):
[0001437749-21-018371:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2021 and  December 31, 2020 was approximately $93,700 and $55,600, respectively.

- added (2021-11-04):
[0001437749-21-025317:note_history:2]
From time to time, we are involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      September 30, 2021, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.

- added (2021-11-04):
[0001437749-21-025317:note_history:3]
Federal Securities Law Class Actions

- added (2021-11-04):
[0001437749-21-025317:note_history:4]
On
      August 20, 2021 and
      August 31, 2021, the Company and certain of its officers were named as defendants in
     two putative federal securities law class actions filed in the U.S. District Court for the Central District of California (the "Federal Securities Law Class Actions"). These actions were filed, respectively, under the captions
     Khami v. Generac Holdings Inc., et al., Case
     No.
     2:21-cv-
     06777, and
     Procter v. Generac Holdings Inc., et al., Case
     No.
     2:21-cv-
     07009. On
      October 19, 2021, the Company filed in each case a motion to transfer venue to the U.S. District Court for the Eastern District of Wisconsin. The plaintiffs in both cases allege that the Company and its officers made false or misleading statements regarding the Company's exposure to liability associated with a recall of portable generators issued by the Company in conjunction with the U.S. Consumer Product Safety Commission, and bring claims for unspecified damages under Sections
     10(b) and
     20(a) of the Securities Exchange Act of
     1934, as amended, and SEC Rule
     10b-
     5. The Company is vigorously defending both of the Federal Securities Law Class Actions, and does
     not believe they will have a material adverse effect on our results of operations or financial condition.

- removed (2021-11-04):
[0001437749-21-018371:note_history:5]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001437749-21-025317:note_history:6]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer, manufacturer and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2021-11-04):
[0001437749-21-025317:note_history:7]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
  (was, 2021-08-03, similarity 0.7247):
[0001437749-21-018371:note_history:7]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions, focused on the global power generation and transfer switch space. |

- changed (2021-11-04):
[0001437749-21-025317:note_history:8]
The condensed consolidated balance sheet as of  September 30, 2021, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2021 and 2020, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2021-08-03, similarity 0.9033):
[0001437749-21-018371:note_history:8]
The condensed consolidated balance sheet as of  June 30, 2021, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2021 and 2020, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2021-11-04):
[0001437749-21-018371:note_history:9]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001437749-21-025317:note_history:10]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 61,470 |  |  |  | 39,282 |  |
| Total |  | $ | 61,470 |  |  | $ | 39,282 |  |
  (was, 2021-08-03, similarity 0.912):
[0001437749-21-018371:note_history:10]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Asset Backed Loan ("ABL") Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,760 |  |  |  | 39,282 |  |
| Total |  | $ | 23,760 |  |  | $ | 39,282 |  |

- changed (2021-11-04):
[0001437749-21-025317:note_history:11]
As of  September 30, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.
  (was, 2021-08-03, similarity 0.9617):
[0001437749-21-018371:note_history:11]
As of  June 30, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

- added (2021-11-04):
[0001437749-21-025317:note_history:12]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,863 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 27,953 |  |  |  | 27,371 |  |
| Other |  |  | 4,281 |  |  |  | 3,990 |  |
| Total |  |  | 848,371 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,967 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,978 |  |  |  | 2,311 |  |
| Total |  | $ | 843,426 |  |  | $ | 841,764 |  |

- changed (2021-11-04):
[0001437749-21-025317:note_history:13]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2021, the Company’s net secured leverage ratio was 0.77 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2021-08-03, similarity 0.981):
[0001437749-21-018371:note_history:13]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2021, the Company’s net secured leverage ratio was 0.79 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2021-11-04):
[0001437749-21-025317:note_history:14]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. As of  September 30, 2021, there was $50,000 outstanding under the ABL Facility, leaving $449,302 of availability, net of outstanding letters of credit.
  (was, 2021-08-03, similarity 0.6759):
[0001437749-21-018371:note_history:14]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of  June 30, 2021, there was $50,000 outstanding under the ABL Facility, leaving $439,529 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- removed (2021-11-04):
[0001437749-21-018371:note_history:15]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,509 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 28,389 |  |  |  | 27,371 |  |
| Other |  |  | 2,960 |  |  |  | 3,990 |  |
| Total |  |  | 846,840 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,783 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,450 |  |  |  | 2,311 |  |
| Total |  | $ | 842,607 |  |  | $ | 841,764 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001437749-21-025317:note_history:16]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,863 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 27,953 |  |  |  | 27,371 |  |
| Other |  |  | 4,281 |  |  |  | 3,990 |  |
| Total |  |  | 848,371 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,967 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,978 |  |  |  | 2,311 |  |
| Total |  | $ | 843,426 |  |  | $ | 841,764 |  |

- removed (2021-11-04):
[0001437749-21-018371:note_history:17]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,509 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 28,389 |  |  |  | 27,371 |  |
| Other |  |  | 2,960 |  |  |  | 3,990 |  |
| Total |  |  | 846,840 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,783 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,450 |  |  |  | 2,311 |  |
| Total |  | $ | 842,607 |  |  | $ | 841,764 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001437749-21-025317:note_history:18]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 61,470 |  |  |  | 39,282 |  |
| Total |  | $ | 61,470 |  |  | $ | 39,282 |  |
  (was, 2021-08-03, similarity 0.912):
[0001437749-21-018371:note_history:18]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Asset Backed Loan ("ABL") Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,760 |  |  |  | 39,282 |  |
| Total |  | $ | 23,760 |  |  | $ | 39,282 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001437749-21-025317:note_history:19]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 585,150 |  |  | $ | 23,666 |  |  | $ | 608,816 |  |
| Commercial & industrial products |  |  | 140,824 |  |  |  | 117,485 |  |  |  | 258,309 |  |
| Other |  |  | 64,790 |  |  |  | 10,783 |  |  |  | 75,573 |  |
| Total net sales |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | 942,698 |  |
  (was, 2021-08-03, similarity 0.8928):
[0001437749-21-018371:note_history:19]
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |

- changed (2021-11-04):
[0001437749-21-025317:note_history:20]
|  |  | Three Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 441,532 |  |  | $ | 17,345 |  |  | $ | 458,877 |  |
| Commercial & industrial products |  |  | 108,774 |  |  |  | 67,426 |  |  |  | 176,200 |  |
| Other |  |  | 56,569 |  |  |  | 9,709 |  |  |  | 66,278 |  |
| Total net sales |  | $ | 606,875 |  |  | $ | 94,480 |  |  | $ | 701,355 |  |
  (was, 2021-08-03, similarity 0.9803):
[0001437749-21-018371:note_history:20]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

- added (2021-11-04):
[0001437749-21-025317:note_history:21]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,690,707 |  |  | $ | 60,250 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 402,357 |  |  |  | 312,637 |  |  |  | 714,994 |  |
| Other |  |  | 174,584 |  |  |  | 29,578 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | 2,670,113 |  |

- added (2021-11-04):
[0001437749-21-025317:note_history:22]
|  |  | Nine Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,013,219 |  |  | $ | 44,629 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 294,940 |  |  |  | 208,216 |  |  |  | 503,156 |  |
| Other |  |  | 135,521 |  |  |  | 27,593 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 1,443,680 |  |  | $ | 280,438 |  |  | $ | 1,724,118 |  |

- removed (2021-11-04):
[0001437749-21-018371:note_history:23]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

- removed (2021-11-04):
[0001437749-21-018371:note_history:24]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001437749-21-025317:note_history:25]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $32,076 and $25,710 at  September 30, 2021 and  December 31, 2020, respectively. During the nine months ended  September 30, 2021, the Company recognized revenue of $24,096 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2021-08-03, similarity 0.9473):
[0001437749-21-018371:note_history:25]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $31,316 and $25,710 at  June 30, 2021 and  December 31, 2020, respectively. During the six months ended  June 30, 2021, the Company recognized revenue of $20,977 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001437749-21-025317:note_history:26]
Agreement to acquire ecobee Inc.

- added (2021-11-04):
[0001437749-21-025317:note_history:27]
On  November 1, 2021, the Company entered into a definitive agreement to acquire ecobee Inc. (ecobee). Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. Pursuant to the agreement, the Company will acquire all of the outstanding ownership interests of ecobee from the ecobee securityholders. As consideration, the Company will pay or cause to be paid consideration valued at up to $770,000, comprising (i) $200,000 in cash, subject to customary adjustments, to be paid at closing, (ii) $450,000 of GNRC common stock to be issued at closing, and (iii) contingent consideration paid in the form of GNRC common stock with an aggregate value of up to $120,000 based on the achievement of certain performance targets by ecobee as of  June 30, 2022 and  June 30, 2023. The contingent consideration will be fixed and accelerated upon certain corporate transactions, including a change of control of the Company. The Company expects the acquisition to close in the fourth quarter of 2021, subject to customary closing conditions, including clearance under the Hart-Scott-Rodino Antitrust Improvement Act.

- added (2021-11-04):
[0001437749-21-025317:note_history:28]
Acquisition of Tank Utility, Inc.

- added (2021-11-04):
[0001437749-21-025317:note_history:29]
On  October 1, 2021, the Company acquired Tank Utility, Inc., a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.

- removed (2021-11-04):
[0001437749-21-018371:note_history:30]
On  July 2, 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon’s power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction.
