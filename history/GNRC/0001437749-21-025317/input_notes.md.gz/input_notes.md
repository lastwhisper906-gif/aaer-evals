# GNRC notes — 0001437749-21-025317


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-21-025317:notes:1]
[same as prior period, unchanged from 0001437749-21-018371:notes:1]

[0001437749-21-025317:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer, manufacturer and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-025317:notes:3]
[same as prior period, unchanged from 0001437749-21-018371:notes:3]

[0001437749-21-025317:notes:4]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |

[0001437749-21-025317:notes:5]
[same as prior period, unchanged from 0001437749-21-018371:notes:5]

[0001437749-21-025317:notes:6]
The condensed consolidated balance sheet as of  September 30, 2021, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2021 and 2020, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-21-025317:notes:7]
[same as prior period, unchanged from 0001437749-21-018371:notes:7]

[0001437749-21-025317:notes:8]
[same as prior period, unchanged from 0001437749-21-018371:notes:8]

[0001437749-21-025317:notes:9]
[same as prior period, unchanged from 0001437749-21-018371:notes:9]

[0001437749-21-025317:notes:10]
[same as prior period, unchanged from 0001437749-21-018371:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-025317:notes:11]
[same as prior period, unchanged from 0001437749-21-018371:notes:11]

[0001437749-21-025317:notes:12]
Fiscal 2021 Acquisitions

[0001437749-21-025317:notes:13]
Acquisition of Deep Sea

[0001437749-21-025317:notes:14]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-025317:notes:15]
The Company recorded its preliminary purchase price allocation during the second quarter of 2021, and was updated in the third quarter of 2021, based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $434,724 of intangible assets, including $263,287 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Deep Sea from the date of acquisition through  September 30, 2021. Pro forma financial information is not presented as the effects of this acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-21-025317:notes:16]
Acquisition of Off Grid Energy

[0001437749-21-025317:notes:17]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $76,553, net of cash acquired and inclusive of estimated contingent consideration of $44,042 that is to be paid in cash upon achievement of certain performance targets at the end of the earnout period. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-21-025317:notes:18]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $71,935 of intangible assets, including $48,263 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  September 30, 2021. Pro forma financial information is not presented as the effects of this acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-21-025317:notes:19]
[same as prior period, unchanged from 0001437749-21-018371:notes:19]

[0001437749-21-025317:notes:20]
On  July 2, 2021, the Company acquired Chilicon, a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Chilicon is based in Los Angeles, California.

[0001437749-21-025317:notes:21]
On  September 1, 2021, the Company acquired Apricity Code, an advanced engineering and product design company located in Bend, Oregon.

[0001437749-21-025317:notes:22]
The combined fair value of the consideration transferred for these acquisitions consisted of the following:

[0001437749-21-025317:notes:23]
| Cash at closing |  | $ | 18,823 |  |
| Deferred cash payment |  |  | 6,000 |  |
| Common stock issued at closing |  |  | 12,000 |  |
| Contingent consideration (1) |  |  | 23,971 |  |
| Total purchase price |  | $ | 60,794 |  |

[0001437749-21-025317:notes:24]
|  | (1) | To be paid in the form of common stock issued upon achievement of certain performance targets at the end of the earnout period. |

[0001437749-21-025317:notes:25]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $69,776 of intangible assets, including $30,976 of goodwill recorded in the Domestic segment, as of the acquisition date for these acquisitions. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The goodwill ascribed to the Apricity acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  September 30, 2021. Pro forma financial information is not presented for these acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-025317:notes:26]
Fiscal 2020 Acquisitions

[0001437749-21-025317:notes:27]
[same as prior period, unchanged from 0001437749-21-018371:notes:16]

[0001437749-21-025317:notes:28]
[same as prior period, unchanged from 0001437749-21-018371:notes:17]

[0001437749-21-025317:notes:29]
The Company finalized its purchase price allocation during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $46,338 of intangible assets, including $27,038 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Enbala from the date of acquisition through  September 30, 2021. Pro forma financial information is not presented as the effects of this acquisition or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-21-025317:notes:30]
On  July 1, 2020, the Company acquired Energy Systems, its industrial distributor in northern California.

[0001437749-21-025317:notes:31]
On  September 1, 2020, the Company acquired Mean Green, a designer and manufacturer of commercial grade, battery-powered turf care products.

[0001437749-21-025317:notes:32]
The combined purchase price for these two acquisitions was $22,958 and was funded solely through cash on hand. The Company finalized its purchase price allocation for these two acquisitions during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  September 30, 2021. Pro forma financial information is not presented for these acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-025317:notes:33]
[same as prior period, unchanged from 0001437749-21-018371:notes:23]

[0001437749-21-025317:notes:34]
[same as prior period, unchanged from 0001437749-21-018371:notes:24]

[0001437749-21-025317:notes:35]
|  |  | 2021 Acquisitions |  |  |  |  |
|  |  | Deep Sea |  |  | All Other |  |  | 2020 Acquisitions |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 13,478 |  |  | $ | 5,094 |  |
| Inventories |  |  | 9,970 |  |  |  | 4,522 |  |  |  | 3,575 |  |
| Prepaid expenses and other assets |  |  | 826 |  |  |  | 1,146 |  |  |  | 858 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 413 |  |  |  | 635 |  |
| Intangible assets |  |  | 171,437 |  |  |  | 62,472 |  |  |  | 26,235 |  |
| Goodwill |  |  | 263,287 |  |  |  | 79,239 |  |  |  | 40,395 |  |
| Other assets |  |  | 3,414 |  |  |  | 4,750 |  |  |  | 1,122 |  |
| Total assets acquired |  |  | 467,346 |  |  |  | 166,020 |  |  |  | 77,914 |  |
| Accounts payable |  |  | 8,254 |  |  |  | 4,066 |  |  |  | 4,088 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 788 |  |  |  | 700 |  |
| Other accrued liabilities |  |  | 3,641 |  |  |  | 1,903 |  |  |  | 2,151 |  |
| Short-term borrowings |  |  | - |  |  |  | 833 |  |  |  | - |  |
| Current portion of long-term debt |  |  | - |  |  |  | 233 |  |  |  | - |  |
| Deferred income taxes |  |  | 32,545 |  |  |  | 13,981 |  |  |  | 3,827 |  |
| Long-term debt |  |  | - |  |  |  | 1,672 |  |  |  | - |  |
| Other long-term liabilities |  |  | 100 |  |  |  | 5,197 |  |  |  | 2,208 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 137,347 |  |  | $ | 64,940 |  |

[0001437749-21-025317:notes:36]
The allocations of the purchase price to identifiable assets for the 2021 acquisitions are based on the preliminary valuations performed to determine the fair value of the net assets as of their respective acquisition dates. The measurement period for the valuation of net assets acquired ends as soon as information on the facts and circumstances that existed as of the acquisition dates becomes available, but not to exceed 12 months following the acquisition date. Adjustments in purchase price allocations  may require a change in the amounts allocated to net assets acquired during the periods in which the adjustments are determined.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-21-025317:notes:37]
[same as prior period, unchanged from 0001437749-21-018371:notes:27]

[0001437749-21-025317:notes:38]
[same as prior period, unchanged from 0001437749-21-018371:notes:28]

[0001437749-21-025317:notes:39]
[same as prior period, unchanged from 0001437749-21-018371:notes:29]

[0001437749-21-025317:notes:40]
[same as prior period, unchanged from 0001437749-21-018371:notes:30]

[0001437749-21-025317:notes:41]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 37,245 |  |  | $ | 61,019 |  |  | $ | 66,207 |  |  | $ | 61,227 |  |
| Net income |  |  | 1,007 |  |  |  | 80 |  |  |  | 2,700 |  |  |  | (2,601 | ) |
| Foreign currency translation |  |  | (1,105 | ) |  |  | 3,257 |  |  |  | (2,726 | ) |  |  | 2,638 |  |
| Purchase of additional ownership interest |  |  | - |  |  |  | - |  |  |  | (27,164 | ) |  |  | - |  |
| Redemption value adjustment |  |  | 7,557 |  |  |  | (811 | ) |  |  | 5,687 |  |  |  | 2,281 |  |
| Balance at end of period |  | $ | 44,704 |  |  | $ | 63,545 |  |  | $ | 44,704 |  |  | $ | 63,545 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-21-025317:notes:42]
[same as prior period, unchanged from 0001437749-21-018371:notes:32]

[0001437749-21-025317:notes:43]
[same as prior period, unchanged from 0001437749-21-018371:notes:33]

[0001437749-21-025317:notes:44]
[same as prior period, unchanged from 0001437749-21-018371:notes:34]

[0001437749-21-025317:notes:45]
[same as prior period, unchanged from 0001437749-21-018371:notes:35]

[0001437749-21-025317:notes:46]
In 2017, the Company entered into twenty interest rate swap agreements, twelve of which were still outstanding as of  September 30, 2021. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to fifteen as of  September 30, 2021. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains, net of tax, recognized for the three and nine months ended  September 30, 2021 were $2,941 and $15,184, respectively. The amount of gains and losses, net of tax, recognized for the three and nine months ended  September 30, 2020 were $1,003 and $(18,406), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-21-025317:notes:47]
[same as prior period, unchanged from 0001437749-21-018371:notes:37]

[0001437749-21-025317:notes:48]
[same as prior period, unchanged from 0001437749-21-018371:notes:38]

[0001437749-21-025317:notes:49]
|  |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Commodity contracts |  | $ | 32 |  |  | $ | 1,386 |  |
| Foreign currency contracts |  |  | 23 |  |  |  | (154 | ) |
| Interest rate swaps |  |  | (9,224 | ) |  |  | (29,536 | ) |

[0001437749-21-025317:notes:50]
The fair values of the commodity contracts and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other assets, other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  September 30, 2021. The fair value of the commodity contracts is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities, respectively, in the condensed consolidated balance sheets as of  December 31, 2020. Excluding the impact of credit risk, the fair value of the derivative contracts as of  September 30, 2021 and  December 31, 2020 is a liability of $9,383 and $28,667, respectively, which represents the amount the Company would pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-025317:notes:51]
[same as prior period, unchanged from 0001437749-21-018371:notes:41]

[0001437749-21-025317:notes:52]
[same as prior period, unchanged from 0001437749-21-018371:notes:42]

[0001437749-21-025317:notes:53]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $767,547, was approximately $782,925 (Level 2) at  September 30, 2021, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-21-025317:notes:54]
[same as prior period, unchanged from 0001437749-21-018371:notes:44]

[0001437749-21-025317:notes:55]
Contingent Consideration

[0001437749-21-025317:notes:56]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's condensed consolidated statements of comprehensive income. This fair value measurement of contingent consideration is categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs not observable in the market.

[0001437749-21-025317:notes:57]
The fair value of contingent consideration as of  September 30, 2021 and  December 31, 2020 was $70,206 and $5,888, respectively, which was recorded in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-21-025317:notes:58]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-21-025317:notes:59]
| Beginning balance, January 1, 2021 |  | $ | 5,888 |  |
| Purchase price contingent consideration (1) |  |  | 68,013 |  |
| Changes in fair value |  |  | 55 |  |
| Payments |  |  | (3,750 | ) |
| Ending balance, September 30, 2021 |  | $ | 70,206 |  |

[0001437749-21-025317:notes:60]
|  | (1) | The increase in the contingent consideration liability is due to the contingent consideration associated with the acquisitions of Chilicon and Off Grid Energy. Refer to Note 2 for further information. |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-21-025317:notes:61]
[same as prior period, unchanged from 0001437749-21-018371:notes:45]

[0001437749-21-025317:notes:62]
The following presents a tabular disclosure of changes in AOCL during the three and nine months ended  September 30, 2021 and 2020, net of tax:

[0001437749-21-025317:notes:63]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2021 |  | $ | (27,246 | ) |  |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (20,899 | ) | (1) |  |  | 2,941 |  | (2) |  |  | (17,958 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (20,899 | ) |  |  |  | 2,941 |  |  |  |  | (17,958 | ) |
| Ending Balance – September 30, 2021 |  | $ | (48,145 | ) |  |  | $ | (7,396 | ) |  |  | $ | (55,541 | ) |

[0001437749-21-025317:notes:64]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2020 |  | $ | (44,822 | ) |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 9,484 |  |  |  | 1,003 |  | (3) |  |  | 10,487 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 9,484 |  |  |  | 1,003 |  |  |  |  | 10,487 |  |
| Ending Balance – September 30, 2020 |  | $ | (35,338 | ) |  | $ | (26,701 | ) |  |  | $ | (62,039 | ) |

[0001437749-21-025317:notes:65]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive loss before reclassifications |  |  | (36,471 | ) | (4) |  |  | 15,184 |  | (5) |  |  | (21,287 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (36,471 | ) |  |  |  | 15,184 |  |  |  |  | (21,287 | ) |
| Ending Balance – September 30, 2021 |  | $ | (48,145 | ) |  |  | $ | (7,396 | ) |  |  | $ | (55,541 | ) |

[0001437749-21-025317:notes:66]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (18,716 | ) | (6) |  |  | (18,406 | ) | (7) |  |  | (37,122 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (18,716 | ) |  |  |  | (18,406 | ) |  |  |  | (37,122 | ) |
| Ending Balance – September 30, 2020 |  | $ | (35,338 | ) |  |  | $ | (26,701 | ) |  |  | $ | (62,039 | ) |

[0001437749-21-025317:notes:67]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2021, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $3,934 on the interest rate swaps, net of tax effect of $(993) for the three months ended September 30, 2021. |

[0001437749-21-025317:notes:68]
|  | (3) | Represents unrealized gains of $1,342 on the interest rate swaps, net of tax effect of $(339) for the three months ended September 30, 2020. |
|  | (4) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2021, particularly the Euro and British Pound. |
|  | (5) | Represents unrealized gains of $20,312 on the interest rate swaps, net of tax effect of $(5,128) for the nine months ended September 30, 2021. |
|  | (6) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |
|  | (7) | Represents unrealized losses of $(24,623) on the interest rate swaps, net of tax effect of $6,217 for the nine months ended September 30, 2020. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-025317:notes:69]
[same as prior period, unchanged from 0001437749-21-018371:notes:53]

[0001437749-21-025317:notes:70]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, Deep Sea, and Off Grid Energy acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design, manufacture, and provide a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-21-025317:notes:71]
[same as prior period, unchanged from 0001437749-21-018371:notes:55]

[0001437749-21-025317:notes:72]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 585,150 |  |  | $ | 23,666 |  |  | $ | 608,816 |  |
| Commercial & industrial products |  |  | 140,824 |  |  |  | 117,485 |  |  |  | 258,309 |  |
| Other |  |  | 64,790 |  |  |  | 10,783 |  |  |  | 75,573 |  |
| Total net sales |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | 942,698 |  |

[0001437749-21-025317:notes:73]
|  |  | Three Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 441,532 |  |  | $ | 17,345 |  |  | $ | 458,877 |  |
| Commercial & industrial products |  |  | 108,774 |  |  |  | 67,426 |  |  |  | 176,200 |  |
| Other |  |  | 56,569 |  |  |  | 9,709 |  |  |  | 66,278 |  |
| Total net sales |  | $ | 606,875 |  |  | $ | 94,480 |  |  | $ | 701,355 |  |

[0001437749-21-025317:notes:74]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,690,707 |  |  | $ | 60,250 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 402,357 |  |  |  | 312,637 |  |  |  | 714,994 |  |
| Other |  |  | 174,584 |  |  |  | 29,578 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | 2,670,113 |  |

[0001437749-21-025317:notes:75]
|  |  | Nine Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,013,219 |  |  | $ | 44,629 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 294,940 |  |  |  | 208,216 |  |  |  | 503,156 |  |
| Other |  |  | 135,521 |  |  |  | 27,593 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 1,443,680 |  |  | $ | 280,438 |  |  | $ | 1,724,118 |  |

[0001437749-21-025317:notes:76]
[same as prior period, unchanged from 0001437749-21-018371:notes:60]

[0001437749-21-025317:notes:77]
C&I products consist of larger output stationary generators and controls used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage, mobile heaters, mobile pumps, and controllers. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-21-025317:notes:78]
[same as prior period, unchanged from 0001437749-21-018371:notes:62]

[0001437749-21-025317:notes:79]
[same as prior period, unchanged from 0001437749-21-018371:notes:63]

[0001437749-21-025317:notes:80]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 187,726 |  |  | $ | 171,359 |  |  | $ | 598,730 |  |  | $ | 374,065 |  |
| International |  |  | 21,475 |  |  |  | 7,419 |  |  |  | 42,344 |  |  |  | 13,877 |  |
| Total adjusted EBITDA |  | $ | 209,201 |  |  | $ | 178,778 |  |  | $ | 641,074 |  |  | $ | 387,942 |  |
| Interest expense |  |  | (7,980 | ) |  |  | (8,096 | ) |  |  | (23,424 | ) |  |  | (25,081 | ) |
| Depreciation and amortization |  |  | (23,216 | ) |  |  | (17,168 | ) |  |  | (62,682 | ) |  |  | (50,087 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (3,333 | ) |  |  | (477 | ) |  |  | (638 | ) |  |  | (1,868 | ) |
| Non-cash share-based compensation expense (2) |  |  | (5,783 | ) |  |  | (4,353 | ) |  |  | (18,204 | ) |  |  | (14,327 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | (831 | ) |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | (3,385 | ) |  |  | (568 | ) |  |  | (9,471 | ) |  |  | (1,160 | ) |
| Business optimization and other charges (5) |  |  | - |  |  |  | (531 | ) |  |  | (159 | ) |  |  | (12,503 | ) |
| Other |  |  | (140 | ) |  |  | (300 | ) |  |  | (717 | ) |  |  | (711 | ) |
| Income before provision for income taxes |  | $ | 165,364 |  |  | $ | 147,285 |  |  | $ | 524,948 |  |  | $ | 282,205 |  |

[0001437749-21-025317:notes:81]
|  | (1) | Includes gains/losses on disposals of assets and investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting adjustments. |

[0001437749-21-025317:notes:82]
[same as prior period, unchanged from 0001437749-21-018371:notes:66]

[0001437749-21-025317:notes:83]
[same as prior period, unchanged from 0001437749-21-018371:notes:67]

[0001437749-21-025317:notes:84]
|  | (5) | For the three and nine months ended September 30, 2021, represents severance and other charges related to the consolidation of certain of our facilities. For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. |

[0001437749-21-025317:notes:85]
The Company’s sales in the U.S. represented approximately 82% and 84% of total sales for the three months ended  September 30, 2021 and 2020, respectively. The Company's sales in the U.S. represented approximately 82% of the total sales for the nine months ended  September 30, 2021 and 2020. Approximately 64% and 81% of the Company’s identifiable long-lived assets were located in the U.S. at  September 30, 2021 and  December 31, 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-21-025317:notes:86]
[same as prior period, unchanged from 0001437749-21-018371:notes:70]

[0001437749-21-025317:notes:87]
[same as prior period, unchanged from 0001437749-21-018371:notes:71]

[0001437749-21-025317:notes:88]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Raw material |  | $ | 623,592 |  |  | $ | 375,516 |  |
| Work-in-process |  |  | 8,808 |  |  |  | 6,833 |  |
| Finished goods |  |  | 302,548 |  |  |  | 220,968 |  |
| Total |  | $ | 934,948 |  |  | $ | 603,317 |  |

[0001437749-21-025317:notes:89]
[same as prior period, unchanged from 0001437749-21-018371:notes:73]

[0001437749-21-025317:notes:90]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Land and improvements |  | $ | 22,907 |  |  | $ | 18,363 |  |
| Buildings and improvements |  |  | 230,731 |  |  |  | 198,908 |  |
| Machinery and equipment |  |  | 176,585 |  |  |  | 153,696 |  |
| Dies and tools |  |  | 29,014 |  |  |  | 24,190 |  |
| Vehicles |  |  | 6,977 |  |  |  | 6,037 |  |
| Office equipment and systems |  |  | 121,914 |  |  |  | 107,923 |  |
| Leasehold improvements |  |  | 4,231 |  |  |  | 5,276 |  |
| Construction in progress |  |  | 44,603 |  |  |  | 30,227 |  |
| Gross property and equipment |  |  | 636,962 |  |  |  | 544,620 |  |
| Accumulated depreciation |  |  | (224,256 | ) |  |  | (200,684 | ) |
| Total |  | $ | 412,706 |  |  | $ | 343,936 |  |

[0001437749-21-025317:notes:91]
Total property and equipment included finance leases of $27,243 and $27,269 at  September 30, 2021 and  December 31, 2020, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-21-025317:notes:92]
[same as prior period, unchanged from 0001437749-21-018371:notes:76]

[0001437749-21-025317:notes:93]
[same as prior period, unchanged from 0001437749-21-018371:notes:77]

[0001437749-21-025317:notes:94]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 74,758 |  |  | $ | 50,324 |  |  | $ | 59,218 |  |  | $ | 49,316 |  |
| Product warranty reserve assumed in acquisition |  |  | 1,085 |  |  |  | 124 |  |  |  | 1,085 |  |  |  | 124 |  |
| Payments |  |  | (10,475 | ) |  |  | (8,667 | ) |  |  | (29,536 | ) |  |  | (24,136 | ) |
| Provision for warranty issued |  |  | 16,527 |  |  |  | 10,949 |  |  |  | 48,521 |  |  |  | 27,691 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,089 |  |  |  | (575 | ) |  |  | 3,696 |  |  |  | (840 | ) |
| Balance at end of period |  | $ | 82,984 |  |  | $ | 52,155 |  |  | $ | 82,984 |  |  | $ | 52,155 |  |

[0001437749-21-025317:notes:95]
[same as prior period, unchanged from 0001437749-21-018371:notes:79]

[0001437749-21-025317:notes:96]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 100,484 |  |  | $ | 83,153 |  |  | $ | 89,788 |  |  | $ | 78,738 |  |
| Deferred revenue contracts issued |  |  | 11,105 |  |  |  | 6,802 |  |  |  | 31,304 |  |  |  | 18,966 |  |
| Amortization of deferred revenue contracts |  |  | (5,014 | ) |  |  | (4,241 | ) |  |  | (14,517 | ) |  |  | (11,990 | ) |
| Balance at end of period |  | $ | 106,575 |  |  | $ | 85,714 |  |  | $ | 106,575 |  |  | $ | 85,714 |  |

[0001437749-21-025317:notes:97]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  September 30, 2021 is as follows:

[0001437749-21-025317:notes:98]
| Remainder of 2021 |  | $ | 5,140 |  |
| 2022 |  |  | 20,809 |  |
| 2023 |  |  | 21,053 |  |
| 2024 |  |  | 17,432 |  |
| 2025 |  |  | 13,661 |  |
| After 2025 |  |  | 28,480 |  |
| Total |  | $ | 106,575 |  |

[0001437749-21-025317:notes:99]
[same as prior period, unchanged from 0001437749-21-018371:notes:83]

[0001437749-21-025317:notes:100]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Product warranty liability: |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 51,555 |  |  | $ | 37,417 |  |
| Long-term portion - other long-term liabilities |  |  | 31,429 |  |  |  | 21,801 |  |
| Total |  | $ | 82,984 |  |  | $ | 59,218 |  |
| Deferred revenue related to extended warranties: |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,090 |  |  | $ | 18,857 |  |
| Long-term portion - other long-term liabilities |  |  | 86,485 |  |  |  | 70,931 |  |
| Total |  | $ | 106,575 |  |  | $ | 89,788 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-025317:notes:101]
[same as prior period, unchanged from 0001437749-21-018371:notes:85]

[0001437749-21-025317:notes:102]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $32,076 and $25,710 at  September 30, 2021 and  December 31, 2020, respectively. During the nine months ended  September 30, 2021, the Company recognized revenue of $24,096 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-025317:notes:103]
11.   Credit Agreements

[0001437749-21-025317:notes:104]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-025317:notes:105]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 61,470 |  |  |  | 39,282 |  |
| Total |  | $ | 61,470 |  |  | $ | 39,282 |  |

[0001437749-21-025317:notes:106]
As of  September 30, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-21-025317:notes:107]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-025317:notes:108]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,863 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 27,953 |  |  |  | 27,371 |  |
| Other |  |  | 4,281 |  |  |  | 3,990 |  |
| Total |  |  | 848,371 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,967 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,978 |  |  |  | 2,311 |  |
| Total |  | $ | 843,426 |  |  | $ | 841,764 |  |

[0001437749-21-025317:notes:109]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

[0001437749-21-025317:notes:110]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2021, the Company’s net secured leverage ratio was 0.77 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-025317:notes:111]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility. Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-21-025317:notes:112]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Term Loan agreement to reflect the same amendments made to the ABL Facility.

[0001437749-21-025317:notes:113]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. As of  September 30, 2021, there was $50,000 outstanding under the ABL Facility, leaving $449,302 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-21-025317:notes:114]
[same as prior period, unchanged from 0001437749-21-018371:notes:98]

[0001437749-21-025317:notes:115]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program, which expired in  October 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three and nine months ended  September 30, 2021 and 2020. Since the inception of all programs starting in  August 2015, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-025317:notes:116]
[same as prior period, unchanged from 0001437749-21-018371:notes:100]

[0001437749-21-025317:notes:117]
[same as prior period, unchanged from 0001437749-21-018371:notes:101]

[0001437749-21-025317:notes:118]
[same as prior period, unchanged from 0001437749-21-018371:notes:102]

[0001437749-21-025317:notes:119]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (7,557 | ) |  |  | 811 |  |  |  | (5,687 | ) |  |  | (2,281 | ) |
| Net income attributable to common shareholders |  | $ | 124,013 |  |  | $ | 115,781 |  |  | $ | 401,912 |  |  | $ | 223,294 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,690,437 |  |  |  | 62,353,473 |  |  |  | 62,583,957 |  |  |  | 62,244,872 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,517,680 |  |  |  | 1,407,907 |  |  |  | 1,562,325 |  |  |  | 1,301,260 |  |
| Diluted shares |  |  | 64,208,116 |  |  |  | 63,761,380 |  |  |  | 64,146,281 |  |  |  | 63,546,132 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.98 |  |  | $ | 1.86 |  |  | $ | 6.42 |  |  | $ | 3.59 |  |
| Diluted |  | $ | 1.93 |  |  | $ | 1.82 |  |  | $ | 6.27 |  |  | $ | 3.51 |  |

[0001437749-21-025317:notes:120]
(1) There were no awards with an anti-dilutive impact for the three and nine months ended  September 30, 2021 and 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-025317:notes:121]
[same as prior period, unchanged from 0001437749-21-018371:notes:105]

[0001437749-21-025317:notes:122]
The effective income tax rates for the nine months ended  September 30, 2021 and 2020 were 21.8% and 21.3%, respectively. The increase in the effective tax rate was primarily due to the earnings mix in the taxing jurisdictions the company operates in.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-025317:notes:123]
15. Commitments and Contingencies

[0001437749-21-025317:notes:124]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2021 and  December 31, 2020 was approximately $97,000 and $55,600, respectively.

[0001437749-21-025317:notes:125]
From time to time, we are involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      September 30, 2021, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.

[0001437749-21-025317:notes:126]
Federal Securities Law Class Actions

[0001437749-21-025317:notes:127]
On
      August 20, 2021 and
      August 31, 2021, the Company and certain of its officers were named as defendants in
     two putative federal securities law class actions filed in the U.S. District Court for the Central District of California (the "Federal Securities Law Class Actions"). These actions were filed, respectively, under the captions
     Khami v. Generac Holdings Inc., et al., Case
     No.
     2:21-cv-
     06777, and
     Procter v. Generac Holdings Inc., et al., Case
     No.
     2:21-cv-
     07009. On
      October 19, 2021, the Company filed in each case a motion to transfer venue to the U.S. District Court for the Eastern District of Wisconsin. The plaintiffs in both cases allege that the Company and its officers made false or misleading statements regarding the Company's exposure to liability associated with a recall of portable generators issued by the Company in conjunction with the U.S. Consumer Product Safety Commission, and bring claims for unspecified damages under Sections
     10(b) and
     20(a) of the Securities Exchange Act of
     1934, as amended, and SEC Rule
     10b-
     5. The Company is vigorously defending both of the Federal Securities Law Class Actions, and does
     not believe they will have a material adverse effect on our results of operations or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-025317:notes:128]
16. Subsequent Event

[0001437749-21-025317:notes:129]
Agreement to acquire ecobee Inc.

[0001437749-21-025317:notes:130]
On  November 1, 2021, the Company entered into a definitive agreement to acquire ecobee Inc. (ecobee). Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. Pursuant to the agreement, the Company will acquire all of the outstanding ownership interests of ecobee from the ecobee securityholders. As consideration, the Company will pay or cause to be paid consideration valued at up to $770,000, comprising (i) $200,000 in cash, subject to customary adjustments, to be paid at closing, (ii) $450,000 of GNRC common stock to be issued at closing, and (iii) contingent consideration paid in the form of GNRC common stock with an aggregate value of up to $120,000 based on the achievement of certain performance targets by ecobee as of  June 30, 2022 and  June 30, 2023. The contingent consideration will be fixed and accelerated upon certain corporate transactions, including a change of control of the Company. The Company expects the acquisition to close in the fourth quarter of 2021, subject to customary closing conditions, including clearance under the Hart-Scott-Rodino Antitrust Improvement Act.

[0001437749-21-025317:notes:131]
Acquisition of Tank Utility, Inc.

[0001437749-21-025317:notes:132]
On  October 1, 2021, the Company acquired Tank Utility, Inc., a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.
