# GNRC 8-K — 0001437749-21-024804 filed 2021-11-02

## item codes, every 8-K on or before 2021-11-04

- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2021-11-04

- none on or before 2021-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-21-024804:8k_2_02:1]
EX-99.1
2
ex_300475.htm
EXHIBIT 99.1

[0001437749-21-024804:8k_2_02:2]
ex_300475.htm

[0001437749-21-024804:8k_2_02:3]
Exhibit 99.1

[0001437749-21-024804:8k_2_02:4]
Generac Reports Third Quarter 2021 Results

[0001437749-21-024804:8k_2_02:5]
Continued exceptional demand drives record quarterly revenue results and increasing backlog, providing further support for expected significant revenue growth in 2022

[0001437749-21-024804:8k_2_02:6]
WAUKESHA, WISCONSIN (November 2, 2021) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2021 and provided an update on its outlook for the full year 2021.

[0001437749-21-024804:8k_2_02:7]
Third Quarter 2021 Highlights

[0001437749-21-024804:8k_2_02:8]
| ● | Net sales increased 34% to a record $943 million during the third quarter of 2021 as compared to $701 million in the prior-year third quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 30%. |

[0001437749-21-024804:8k_2_02:9]
|  | - | Residential product sales grew 33% to $609 million as compared to $459 million last year. |

[0001437749-21-024804:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 47% to $258 million as compared to $176 million in the prior year. |

[0001437749-21-024804:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $132 million, or $1.93 per share, as compared to $115 million, or $1.82 per share, for the same period of 2020. |

[0001437749-21-024804:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $151 million, or $2.35 per share, as compared to $133 million, or $2.08 per share, in the third quarter of 2020. |

[0001437749-21-024804:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $209 million, or 22.2% of net sales, as compared to $179 million, or 25.5% of net sales, in the prior year. |

[0001437749-21-024804:8k_2_02:14]
| ● | On July 2nd, the Company closed on the acquisition of Chilicon Power, a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market, based in California. |

[0001437749-21-024804:8k_2_02:15]
| ● | On September 1st, the Company closed on the acquisition of Apricity Code Corporation, headquartered in Bend, Oregon, an advanced engineering and product design company focused on developing energy technology solutions. |

[0001437749-21-024804:8k_2_02:16]
| ● | On September 1st, the Company closed on the acquisition of Off Grid Energy, a designer and manufacturer of industrial-grade energy storage systems, headquartered in Rugby, United Kingdom. |

[0001437749-21-024804:8k_2_02:17]
| ● | On October 1st, the Company closed on the acquisition of Tank Utility, a provider of IoT propane tank monitoring solutions that enable the optimization of propane fuel logistics, headquartered in Boston, Massachusetts. |

[0001437749-21-024804:8k_2_02:18]
| ● | On November 1st, the Company announced the signing of a purchase agreement to acquire ecobee, a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind, headquartered in Toronto, Canada. |

[0001437749-21-024804:8k_2_02:19]
“We continued to experience exceptional demand during the third quarter leading to all-time record revenue and further increases in our backlog,” said Aaron Jagdfeld, President and Chief Executive Officer. “We again hit record production levels in spite of the challenging supply chain environment that deteriorated during the third quarter. We have tremendous momentum in our business as we head into 2022 with the continuation of robust home standby demand, an expanding Energy Technology solutions portfolio, and strong global demand for our C&I products. This visibility provides support for another year of expected significant revenue growth with improving margins as we realize the full impact of pricing and cost-reduction actions. To support this growth over the long term, we are planning to make further capacity investments by expanding distribution capabilities in our new South Carolina facility and investing in additional manufacturing automation equipment for home standby generators and other products.”

[0001437749-21-024804:8k_2_02:20]
Jagdfeld continued, “In addition, we recently announced several strategic acquisitions that will accelerate our new ‘Powering a Smarter World’ strategy as we continue our evolution into an energy technology solutions company. We’re particularly excited about yesterday’s announcement to acquire ecobee as this transaction will allow us to create a clean, efficient, and reliable home energy ecosystem that will not only help homeowners reduce their energy consumption, but also help grid operators meet the challenges of an electrical grid under enormous stress.”

[0001437749-21-024804:8k_2_02:21]
Additional Third Quarter 2021 Consolidated Highlights

[0001437749-21-024804:8k_2_02:22]
Gross profit margin was 35.6% as compared to 39.4% in the prior-year third quarter. The current quarter’s margin was pressured by higher input costs due to rising commodity prices, labor, logistics and plant start-up costs, which was partially offset by the early impacts of recent pricing actions.

[0001437749-21-024804:8k_2_02:23]
Operating expenses increased $41.9 million, or 34.8%, as compared to the third quarter of 2020. The increase was primarily driven by additional variable expenses from the significant increase in sales volumes, higher employee and marketing costs, and the impact of acquisitions.

[0001437749-21-024804:8k_2_02:24]
Provision for income taxes for the current year quarter was $32.6 million, or an effective tax rate of 19.7%, as compared to $32.1 million, or a 21.8% effective tax rate, for the prior year. The decline in effective tax rate was primarily due to a higher stock compensation deduction during the current year.

[0001437749-21-024804:8k_2_02:25]
Cash flow from operations was $74 million during the third quarter, as compared to $155 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $42 million as compared to $148 million for 2020. The decline in free cash flow was due to higher working capital investment and capital expenditures in the current year quarter, partially offset by an increase in operating earnings.

[0001437749-21-024804:8k_2_02:26]
Business Segment Results

[0001437749-21-024804:8k_2_02:27]
Domestic Segment

[0001437749-21-024804:8k_2_02:28]
Domestic segment sales increased 30% to $790.8 million as compared to $606.9 million in the prior year quarter, with the impact of acquisitions contributing approximately 1% of the revenue growth for the quarter. The core sales growth was driven by strength across both residential and C&I products highlighted by very strong growth with home standby generators, PWRcell® energy storage systems, telecom national account customers and C&I mobile products.

[0001437749-21-024804:8k_2_02:29]
Adjusted EBITDA for the segment was $187.7 million, or 23.7% of net sales, as compared to $171.4 million in the prior year, or 28.2% of net sales. This margin performance was impacted by higher input costs, partially offset by the early impacts of improved pricing during the quarter.

[0001437749-21-024804:8k_2_02:30]
International Segment

[0001437749-21-024804:8k_2_02:31]
International segment sales increased 61% to $151.9 million as compared to $94.5 million in the prior year quarter, with the impact of acquisitions and foreign currency contributing approximately 29% of the revenue growth for the quarter. The core sales growth for the segment was driven by strength across all regions, primarily Europe and Latin America, that continued to experience a sharp increase in demand off the prior-year COVID lows and have recovered well above 2019 levels.

[0001437749-21-024804:8k_2_02:32]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $21.5 million, or 14.1% of net sales, as compared to $7.4 million, or 7.9% of net sales, in the prior year. The increase in margin was primarily due to the positive impact of recent acquisitions and improved operating leverage on higher sales volumes.

[0001437749-21-024804:8k_2_02:33]
Updated 2021 Outlook

[0001437749-21-024804:8k_2_02:34]
The Company is maintaining its full-year 2021 net sales growth guidance range of approximately 47 to 50% compared to the prior year, which includes approximately 5% of favorable impact from acquisitions and foreign currency.

[0001437749-21-024804:8k_2_02:35]
While the Company continues to experience an exceptional demand environment, additional supply chain constraints, escalating logistics challenges, and rising input costs are increasingly impacting the business leading to further margin pressures. As a result of these factors and the impact of recent acquisitions, net income margin, before deducting for non-controlling interests, is now expected to be approximately 15.0% for the full-year 2021 as compared to the prior expectation of between 15.5 to 16.0%. The corresponding adjusted EBITDA margin is now expected to be approximately 23.5%, as compared to the previous guidance range of approximately 24.5 to 25.0%.

[0001437749-21-024804:8k_2_02:36]
Conference Call and Webcast

[0001437749-21-024804:8k_2_02:37]
Generac management will hold a conference call at 10:00 a.m. EDT on Tuesday, November 2, 2021 to discuss third quarter 2021 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 2488472.

[0001437749-21-024804:8k_2_02:38]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-21-024804:8k_2_02:39]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 2488472. The telephonic replay will be available for 7 days.

[0001437749-21-024804:8k_2_02:40]
About Generac

[0001437749-21-024804:8k_2_02:41]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-21-024804:8k_2_02:42]
Forward-looking Information

[0001437749-21-024804:8k_2_02:43]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-21-024804:8k_2_02:44]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-21-024804:8k_2_02:45]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |
|  | ● | the ability to satisfy the closing conditions for the acquisition of ecobee on the timeline expected or at all; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-21-024804:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and may or will continue to adversely affect our operations, supply chain, and distribution for certain of our products and services; |
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |
|  | ● | our dependence on our distribution network; |
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |
|  | ● | loss of our key management and employees; |
|  | ● | increase in product and other liability claims or recalls; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; and |
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand. |

[0001437749-21-024804:8k_2_02:47]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2020 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-21-024804:8k_2_02:48]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-21-024804:8k_2_02:49]
Non-GAAP Financial Metrics

[0001437749-21-024804:8k_2_02:50]
Core Sales

[0001437749-21-024804:8k_2_02:51]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-21-024804:8k_2_02:52]
Adjusted EBITDA

[0001437749-21-024804:8k_2_02:53]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-21-024804:8k_2_02:54]
Adjusted Net Income

[0001437749-21-024804:8k_2_02:55]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-21-024804:8k_2_02:56]
Free Cash Flow

[0001437749-21-024804:8k_2_02:57]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-21-024804:8k_2_02:58]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-21-024804:8k_2_02:59]
SOURCE: Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:60]
CONTACT:

[0001437749-21-024804:8k_2_02:61]
Michael W. Harris

[0001437749-21-024804:8k_2_02:62]
Vice President – Corporate Development & Investor Relations

[0001437749-21-024804:8k_2_02:63]
(262) 506-6064

[0001437749-21-024804:8k_2_02:64]
InvestorRelations@generac.com

[0001437749-21-024804:8k_2_02:65]
Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:66]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-21-024804:8k_2_02:67]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-024804:8k_2_02:68]
(Unaudited)

[0001437749-21-024804:8k_2_02:69]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |
| Costs of goods sold |  |  | 606,704 |  |  |  | 425,206 |  |  |  | 1,672,570 |  |  |  | 1,066,666 |  |
| Gross profit |  |  | 335,994 |  |  |  | 276,149 |  |  |  | 997,543 |  |  |  | 657,452 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 82,242 |  |  |  | 60,901 |  |  |  | 229,443 |  |  |  | 178,566 |  |
| Research and development |  |  | 27,165 |  |  |  | 20,658 |  |  |  | 74,897 |  |  |  | 58,762 |  |
| General and administrative |  |  | 40,802 |  |  |  | 31,061 |  |  |  | 115,311 |  |  |  | 88,732 |  |
| Amortization of intangibles |  |  | 12,206 |  |  |  | 7,892 |  |  |  | 32,237 |  |  |  | 23,340 |  |
| Total operating expenses |  |  | 162,415 |  |  |  | 120,512 |  |  |  | 451,888 |  |  |  | 349,400 |  |
| Income from operations |  |  | 173,579 |  |  |  | 155,637 |  |  |  | 545,655 |  |  |  | 308,052 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (7,980 | ) |  |  | (8,096 | ) |  |  | (23,424 | ) |  |  | (25,081 | ) |
| Investment income |  |  | 165 |  |  |  | 301 |  |  |  | 1,012 |  |  |  | 1,921 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (831 | ) |  |  | – |  |
| Other, net |  |  | (400 | ) |  |  | (557 | ) |  |  | 2,536 |  |  |  | (2,687 | ) |
| Total other expense, net |  |  | (8,215 | ) |  |  | (8,352 | ) |  |  | (20,707 | ) |  |  | (25,847 | ) |
| Income before provision for income taxes |  |  | 165,364 |  |  |  | 147,285 |  |  |  | 524,948 |  |  |  | 282,205 |  |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 114,341 |  |  |  | 59,967 |  |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 410,607 |  |  |  | 222,238 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 3,008 |  |  |  | (3,337 | ) |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.98 |  |  | $ | 1.86 |  |  | $ | 6.42 |  |  | $ | 3.59 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,690,437 |  |  |  | 62,353,473 |  |  |  | 62,583,957 |  |  |  | 62,244,872 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.93 |  |  | $ | 1.82 |  |  | $ | 6.27 |  |  | $ | 3.51 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,208,116 |  |  |  | 63,761,380 |  |  |  | 64,146,281 |  |  |  | 63,546,132 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 113,727 |  |  | $ | 123,887 |  |  | $ | 386,789 |  |  | $ | 187,548 |  |

[0001437749-21-024804:8k_2_02:70]
6

[0001437749-21-024804:8k_2_02:71]
Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:72]
Condensed Consolidated Balance Sheets

[0001437749-21-024804:8k_2_02:73]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-024804:8k_2_02:74]
(Unaudited)

[0001437749-21-024804:8k_2_02:75]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 423,726 |  |  | $ | 655,128 |  |
| Accounts receivable, less allowance for credit losses |  |  | 510,670 |  |  |  | 374,906 |  |
| Inventories |  |  | 934,948 |  |  |  | 603,317 |  |
| Prepaid expenses and other assets |  |  | 54,228 |  |  |  | 36,382 |  |
| Total current assets |  |  | 1,923,572 |  |  |  | 1,669,733 |  |
| Property and equipment, net |  |  | 412,706 |  |  |  | 343,936 |  |
| Customer lists, net |  |  | 154,152 |  |  |  | 49,205 |  |
| Patents and technology, net |  |  | 141,952 |  |  |  | 86,727 |  |
| Other intangible assets, net |  |  | 14,703 |  |  |  | 9,932 |  |
| Tradenames, net |  |  | 172,398 |  |  |  | 146,159 |  |
| Goodwill |  |  | 1,174,315 |  |  |  | 855,228 |  |
| Deferred income taxes |  |  | 3,813 |  |  |  | 1,497 |  |
| Operating lease and other assets |  |  | 102,819 |  |  |  | 73,006 |  |
| Total assets |  | $ | 4,100,430 |  |  | $ | 3,235,423 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 61,470 |  |  | $ | 39,282 |  |
| Accounts payable |  |  | 611,181 |  |  |  | 330,247 |  |
| Accrued wages and employee benefits |  |  | 69,882 |  |  |  | 63,036 |  |
| Other accrued liabilities |  |  | 270,536 |  |  |  | 204,812 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 4,945 |  |  |  | 4,147 |  |
| Total current liabilities |  |  | 1,018,014 |  |  |  | 641,524 |  |
| Long-term borrowings and finance lease obligations |  |  | 843,426 |  |  |  | 841,764 |  |
| Deferred income taxes |  |  | 175,665 |  |  |  | 115,769 |  |
| Operating lease and other long-term liabilities |  |  | 236,344 |  |  |  | 179,955 |  |
| Total liabilities |  |  | 2,273,449 |  |  |  | 1,779,012 |  |
| Redeemable noncontrolling interest |  |  | 44,704 |  |  |  | 66,207 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,335,705 and 72,024,329 shares issued at September 30, 2021 and December 31, 2020, respectively |  |  | 724 |  |  |  | 721 |  |
| Additional paid-in capital |  |  | 563,162 |  |  |  | 525,541 |  |
| Treasury stock, at cost |  |  | (358,634 | ) |  |  | (332,164 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,834,477 |  |  |  | 1,432,565 |  |
| Accumulated other comprehensive loss |  |  | (55,541 | ) |  |  | (34,254 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,782,072 |  |  |  | 1,390,293 |  |
| Noncontrolling interests |  |  | 205 |  |  |  | (89 | ) |
| Total stockholders’ equity |  |  | 1,782,277 |  |  |  | 1,390,204 |  |
| Total liabilities and stockholders’ equity |  | $ | 4,100,430 |  |  | $ | 3,235,423 |  |

[0001437749-21-024804:8k_2_02:76]
Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:77]
Condensed Consolidated Statements of Cash Flows

[0001437749-21-024804:8k_2_02:78]
(U.S. Dollars in Thousands)

[0001437749-21-024804:8k_2_02:79]
(Unaudited)

[0001437749-21-024804:8k_2_02:80]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 410,607 |  |  | $ | 222,238 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 30,445 |  |  |  | 26,747 |  |
| Amortization of intangible assets |  |  | 32,237 |  |  |  | 23,340 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,941 |  |  |  | 1,940 |  |
| Loss on extinguishment of debt |  |  | 831 |  |  |  | – |  |
| Deferred income taxes |  |  | 8,210 |  |  |  | 15,433 |  |
| Share-based compensation expense |  |  | 18,204 |  |  |  | 14,327 |  |
| Loss (gain) on disposal of assets |  |  | (4,018 | ) |  |  | – |  |
| Other, net |  |  | (12 | ) |  |  | 6,414 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (116,768 | ) |  |  | (85,474 | ) |
| Inventories |  |  | (322,954 | ) |  |  | (14,604 | ) |
| Other assets |  |  | (6,874 | ) |  |  | 2,543 |  |
| Accounts payable |  |  | 269,951 |  |  |  | 11,624 |  |
| Accrued wages and employee benefits |  |  | 4,497 |  |  |  | 11,793 |  |
| Other accrued liabilities |  |  | 49,987 |  |  |  | 38,211 |  |
| Excess tax benefits from equity awards |  |  | (26,880 | ) |  |  | (6,222 | ) |
| Net cash provided by operating activities |  |  | 349,404 |  |  |  | 268,310 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 182 |  |  |  | 26 |  |
| Proceeds from sale of investment |  |  | 4,968 |  |  |  | – |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,240 |  |  |  | 1,998 |  |
| Contribution to equity method investment |  |  | (781 | ) |  |  | – |  |
| Expenditures for property and equipment |  |  | (87,456 | ) |  |  | (33,940 | ) |
| Acquisition of business, net of cash acquired |  |  | (465,926 | ) |  |  | (22,815 | ) |
| Net cash used in investing activities |  |  | (546,773 | ) |  |  | (54,731 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 127,816 |  |  |  | 198,087 |  |
| Proceeds from long-term borrowings |  |  | 50,000 |  |  |  | 297 |  |
| Repayments of short-term borrowings |  |  | (105,206 | ) |  |  | (210,854 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (54,889 | ) |  |  | (3,584 | ) |
| Payment of contingent acquisition consideration |  |  | (3,750 | ) |  |  | (4,000 | ) |
| Payment of debt issuance costs |  |  | (1,185 | ) |  |  | – |  |
| Purchase of additional ownership interest |  |  | (27,164 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (49,569 | ) |  |  | (13,533 | ) |
| Proceeds from the exercise of stock options |  |  | 30,502 |  |  |  | 11,991 |  |
| Net cash used in financing activities |  |  | (33,445 | ) |  |  | (21,596 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (588 | ) |  |  | (922 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (231,402 | ) |  |  | 191,061 |  |
| Cash and cash equivalents at beginning of period |  |  | 655,128 |  |  |  | 322,883 |  |
| Cash and cash equivalents at end of period |  | $ | 423,726 |  |  | $ | 513,944 |  |

[0001437749-21-024804:8k_2_02:81]
8

[0001437749-21-024804:8k_2_02:82]
Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:83]
Segment Reporting and Product Class Information

[0001437749-21-024804:8k_2_02:84]
(U.S. Dollars in Thousands)

[0001437749-21-024804:8k_2_02:85]
(Unaudited)

[0001437749-21-024804:8k_2_02:86]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 790,764 |  |  | $ | 606,875 |  |  | $ | 2,267,648 |  |  | $ | 1,443,680 |  |
| International |  |  | 151,934 |  |  |  | 94,480 |  |  |  | 402,465 |  |  |  | 280,438 |  |
| Total net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 608,816 |  |  | $ | 458,877 |  |  | $ | 1,750,956 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 258,309 |  |  |  | 176,200 |  |  |  | 714,995 |  |  |  | 503,156 |  |
| Other |  |  | 75,573 |  |  |  | 66,278 |  |  |  | 204,162 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |

[0001437749-21-024804:8k_2_02:87]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 187,726 |  |  | $ | 171,359 |  |  | $ | 598,730 |  |  | $ | 374,065 |  |
| International |  |  | 21,475 |  |  |  | 7,419 |  |  |  | 42,344 |  |  |  | 13,877 |  |
| Total adjusted EBITDA (1) |  | $ | 209,201 |  |  | $ | 178,778 |  |  | $ | 641,074 |  |  | $ | 387,942 |  |

[0001437749-21-024804:8k_2_02:88]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-21-024804:8k_2_02:89]
Generac Holdings Inc.

[0001437749-21-024804:8k_2_02:90]
Reconciliation Schedules

[0001437749-21-024804:8k_2_02:91]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-024804:8k_2_02:92]
(Unaudited)

[0001437749-21-024804:8k_2_02:93]
Net income to Adjusted EBITDA reconciliation

[0001437749-21-024804:8k_2_02:94]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 3,008 |  |  |  | (3,337 | ) |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 410,607 |  |  |  | 222,238 |  |
| Interest expense |  |  | 7,980 |  |  |  | 8,096 |  |  |  | 23,424 |  |  |  | 25,081 |  |
| Depreciation and amortization |  |  | 23,216 |  |  |  | 17,168 |  |  |  | 62,682 |  |  |  | 50,087 |  |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 114,341 |  |  |  | 59,967 |  |
| Non-cash write-down and other adjustments (1) |  |  | 3,333 |  |  |  | 477 |  |  |  | 638 |  |  |  | 1,868 |  |
| Non-cash share-based compensation expense (2) |  |  | 5,783 |  |  |  | 4,353 |  |  |  | 18,204 |  |  |  | 14,327 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 3,385 |  |  |  | 568 |  |  |  | 9,471 |  |  |  | 1,160 |  |
| Business optimization and other charges (5) |  |  | - |  |  |  | 531 |  |  |  | 159 |  |  |  | 12,503 |  |
| Other |  |  | 140 |  |  |  | 300 |  |  |  | 717 |  |  |  | 711 |  |
| Adjusted EBITDA |  |  | 209,201 |  |  |  | 178,778 |  |  |  | 641,074 |  |  |  | 387,942 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,247 |  |  |  | 920 |  |  |  | 6,454 |  |  |  | 950 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 206,954 |  |  | $ | 177,858 |  |  | $ | 634,620 |  |  | $ | 386,992 |  |

[0001437749-21-024804:8k_2_02:95]
(1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-21-024804:8k_2_02:96]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-21-024804:8k_2_02:97]
(3) Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary debt prepayment.

[0001437749-21-024804:8k_2_02:98]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-21-024804:8k_2_02:99]
(5) For the three and nine months ended September 30, 2021, represents severance and other charges related to the consolidation of certain of our facilities. For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices.

[0001437749-21-024804:8k_2_02:100]
Net income to Adjusted net income reconciliation

[0001437749-21-024804:8k_2_02:101]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 3,008 |  |  |  | (3,337 | ) |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 410,607 |  |  |  | 222,238 |  |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 114,341 |  |  |  | 59,967 |  |
| Income before provision for income taxes |  |  | 165,364 |  |  |  | 147,285 |  |  |  | 524,948 |  |  |  | 282,205 |  |
| Amortization of intangible assets |  |  | 12,206 |  |  |  | 7,892 |  |  |  | 32,237 |  |  |  | 23,340 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 646 |  |  |  | 654 |  |  |  | 1,941 |  |  |  | 1,940 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | – |  |  |  | 831 |  |  |  | – |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 5,487 |  |  |  | 381 |  |  |  | 11,130 |  |  |  | 612 |  |
| (Gain)/loss attributable to business or asset dispositions (7) |  |  | - |  |  |  | – |  |  |  | (3,991 | ) |  |  | – |  |
| Business optimization and other charges (5) |  |  | - |  |  |  | 531 |  |  |  | 159 |  |  |  | 12,503 |  |
| Adjusted net income before provision for income taxes |  |  | 183,703 |  |  |  | 156,743 |  |  |  | 567,255 |  |  |  | 320,600 |  |
| Cash income tax expense (8) |  |  | (31,290 | ) |  |  | (23,620 | ) |  |  | (106,564 | ) |  |  | (44,842 | ) |
| Adjusted net income |  |  | 152,413 |  |  |  | 133,123 |  |  |  | 460,691 |  |  |  | 275,758 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,272 |  |  |  | 198 |  |  |  | 3,616 |  |  |  | (725 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 151,141 |  |  | $ | 132,925 |  |  | $ | 457,075 |  |  | $ | 276,483 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.35 |  |  | $ | 2.08 |  |  | $ | 7.13 |  |  | $ | 4.35 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,208,116 |  |  |  | 63,761,380 |  |  |  | 64,146,281 |  |  |  | 63,546,132 |  |

[0001437749-21-024804:8k_2_02:102]
(6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-21-024804:8k_2_02:103]
(7) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-21-024804:8k_2_02:104]
(8) Amount for the three and nine months ended September 30, 2021 is based on an anticipated cash income tax rate of approximately 20.0% to 20.5% for the full year ending 2021. Amount for the three and nine months ended September 30, 2020 is based on an anticipated cash income tax rate at the time of approximately 16% for the full year ended 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-21-024804:8k_2_02:105]
Free Cash Flow Reconciliation

[0001437749-21-024804:8k_2_02:106]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net cash provided by operating activities |  | $ | 74,411 |  |  | $ | 155,196 |  |  | $ | 349,404 |  |  | $ | 268,310 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 877 |  |  |  | 674 |  |  |  | 2,240 |  |  |  | 1,998 |  |
| Expenditures for property and equipment |  |  | (33,234 | ) |  |  | (7,608 | ) |  |  | (87,456 | ) |  |  | (33,940 | ) |
| Free cash flow |  | $ | 42,054 |  |  | $ | 148,262 |  |  | $ | 264,188 |  |  | $ | 236,368 |  |

[0001437749-21-024804:8k_2_02:107]
11
