# GNRC MD&A — 0001437749-21-025317


## mdna

[0001437749-21-025317:mdna:1]
[same as prior period, unchanged from 0001437749-21-018371:mdna:1]

[0001437749-21-025317:mdna:2]
[same as prior period, unchanged from 0001437749-21-018371:mdna:2]

[0001437749-21-025317:mdna:3]
[same as prior period, unchanged from 0001437749-21-018371:mdna:3]

[0001437749-21-025317:mdna:4]
[same as prior period, unchanged from 0001437749-21-018371:mdna:4]

[0001437749-21-025317:mdna:5]
[same as prior period, unchanged from 0001437749-21-018371:mdna:5]

[0001437749-21-025317:mdna:6]
[same as prior period, unchanged from 0001437749-21-018371:mdna:6]

[0001437749-21-025317:mdna:7]
[same as prior period, unchanged from 0001437749-21-018371:mdna:7]

[0001437749-21-025317:mdna:8]
[same as prior period, unchanged from 0001437749-21-018371:mdna:8]

[0001437749-21-025317:mdna:9]
[same as prior period, unchanged from 0001437749-21-018371:mdna:9]

[0001437749-21-025317:mdna:10]
[same as prior period, unchanged from 0001437749-21-018371:mdna:10]

[0001437749-21-025317:mdna:11]
|  | ● | the ability to satisfy the closing conditions for the acquisition of ecobee on the timeline expected or at all; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-21-025317:mdna:12]
[same as prior period, unchanged from 0001437749-21-018371:mdna:12]

[0001437749-21-025317:mdna:13]
[same as prior period, unchanged from 0001437749-21-018371:mdna:13]

[0001437749-21-025317:mdna:14]
[same as prior period, unchanged from 0001437749-21-018371:mdna:14]

[0001437749-21-025317:mdna:15]
[same as prior period, unchanged from 0001437749-21-018371:mdna:15]

[0001437749-21-025317:mdna:16]
[same as prior period, unchanged from 0001437749-21-018371:mdna:16]

[0001437749-21-025317:mdna:17]
[same as prior period, unchanged from 0001437749-21-018371:mdna:17]

[0001437749-21-025317:mdna:18]
[same as prior period, unchanged from 0001437749-21-018371:mdna:18]

[0001437749-21-025317:mdna:19]
[same as prior period, unchanged from 0001437749-21-018371:mdna:19]

[0001437749-21-025317:mdna:20]
[same as prior period, unchanged from 0001437749-21-018371:mdna:20]

[0001437749-21-025317:mdna:21]
[same as prior period, unchanged from 0001437749-21-018371:mdna:21]

[0001437749-21-025317:mdna:22]
We are a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets.

[0001437749-21-025317:mdna:23]
Power generation and storage is a key focus of the Company, which differentiates us from many of our competitors who also have broad operations outside of the power equipment market. As the only significant market participant with a primary focus on these products, we maintain one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost effective natural gas-fueled generators to expand into applications beyond standby power, allowing us to participate in distributed generation projects. The Company in recent years has been evolving its business model to also focus on clean energy products, solutions, and services. In 2019, we began providing energy storage systems as a clean energy solution for residential use that capture and store electricity from solar panels or other power sources and help reduce home energy costs while also protecting homes from shorter-duration power outages. During 2020, we entered the market for grid services by offering distributed energy optimization and control software that helps support the operational stability of the world's power grids. We have also been focused on connecting the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product life cycle. The strategic focus on grid edge devices will broaden our monitoring capabilities and also enable the increasing utilization of this equipment as distributed energy resources as the nascent market for grid services expands over the next several years. Overall, as the traditional centralized utility model evolves over time, we believe that a cleaner, more decentralized grid infrastructure will build-out, and Generac's energy technology solutions are strategically positioned to participate in this future "Grid 2.0".

[0001437749-21-025317:mdna:24]
[same as prior period, unchanged from 0001437749-21-018371:mdna:24]

[0001437749-21-025317:mdna:25]
[same as prior period, unchanged from 0001437749-21-018371:mdna:25]

[0001437749-21-025317:mdna:26]
[same as prior period, unchanged from 0001437749-21-018371:mdna:26]

[0001437749-21-025317:mdna:27]
[same as prior period, unchanged from 0001437749-21-018371:mdna:27]

[0001437749-21-025317:mdna:28]
Our performance is affected by the demand for reliable power generation equipment, energy storage systems, grid service solutions, and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-21-025317:mdna:29]
[same as prior period, unchanged from 0001437749-21-018371:mdna:29]

[0001437749-21-025317:mdna:30]
[same as prior period, unchanged from 0001437749-21-018371:mdna:30]

[0001437749-21-025317:mdna:31]
[same as prior period, unchanged from 0001437749-21-018371:mdna:31]

[0001437749-21-025317:mdna:32]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, there have been a number of major outage events that occurred over the past decade that drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both the year they occurred along with the following subsequent year. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur every day across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-21-025317:mdna:33]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the acquisitions of Pika Energy and Neurio Technologies, along with the subsequent introduction of Generac branded products - marketed under the names PWRcellTM and PWRviewTM. We believe the electric utility landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage and store this power–potentially developing into a significant market opportunity as attachment rates for energy storage systems on solar installations have increased significantly over the last couple of years. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets, which enabled us to quickly ramp shipments for these clean energy solutions during 2020, and which we believe will position Generac as a key participant going forward. Although different from the emergency backup power space, we believe this market will develop similarly as the home standby generator market has over the past two decades given both products can provide power resiliency to homeowners. We expect to further advance our growing capabilities for clean energy including product development, sourcing, distribution, and marketing, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential energy storage, monitoring, and management markets.

[0001437749-21-025317:mdna:34]
[same as prior period, unchanged from 0001437749-21-018371:mdna:34]

[0001437749-21-025317:mdna:35]
[same as prior period, unchanged from 0001437749-21-018371:mdna:35]

[0001437749-21-025317:mdna:36]
[same as prior period, unchanged from 0001437749-21-018371:mdna:36]

[0001437749-21-025317:mdna:37]
[same as prior period, unchanged from 0001437749-21-018371:mdna:37]

[0001437749-21-025317:mdna:38]
[same as prior period, unchanged from 0001437749-21-018371:mdna:38]

[0001437749-21-025317:mdna:39]
[same as prior period, unchanged from 0001437749-21-018371:mdna:39]

[0001437749-21-025317:mdna:40]
[same as prior period, unchanged from 0001437749-21-018371:mdna:40]

[0001437749-21-025317:mdna:41]
[same as prior period, unchanged from 0001437749-21-018371:mdna:41]

[0001437749-21-025317:mdna:42]
[same as prior period, unchanged from 0001437749-21-018371:mdna:42]

[0001437749-21-025317:mdna:43]
[same as prior period, unchanged from 0001437749-21-018371:mdna:43]

[0001437749-21-025317:mdna:44]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions over the years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, specifically in 2021, there continue to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs and delays for certain of our products.

[0001437749-21-025317:mdna:45]
[same as prior period, unchanged from 0001437749-21-018371:mdna:45]

[0001437749-21-025317:mdna:46]
[same as prior period, unchanged from 0001437749-21-018371:mdna:46]

[0001437749-21-025317:mdna:47]
[same as prior period, unchanged from 0001437749-21-018371:mdna:47]

[0001437749-21-025317:mdna:48]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. Additionally, as part of our ABL Facility amendment in May 2021, language was added to the ABL Facility agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. During the nine months ended September 30, 2021, interest expense decreased compared to the nine months ended September 30, 2020, primarily due to lower LIBOR rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-21-025317:mdna:49]
[same as prior period, unchanged from 0001437749-21-018371:mdna:49]

[0001437749-21-025317:mdna:50]
[same as prior period, unchanged from 0001437749-21-018371:mdna:50]

[0001437749-21-025317:mdna:51]
[same as prior period, unchanged from 0001437749-21-018371:mdna:51]

[0001437749-21-025317:mdna:52]
[same as prior period, unchanged from 0001437749-21-018371:mdna:52]

[0001437749-21-025317:mdna:53]
Agreement to acquire ecobee Inc.

[0001437749-21-025317:mdna:54]
On November 1, 2021, we entered into a definitive agreement to acquire ecobee Inc. (ecobee). Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. Pursuant to the agreement, we will acquire all of the outstanding ownership interests of ecobee from the ecobee securityholders. As consideration, we will pay or cause to be paid consideration valued at up to $770 million, comprising (i) $200 million in cash, subject to customary adjustments, to be paid at closing, (ii) $450 million of our common stock to be issued at closing, and (iii) contingent consideration paid in the form of our common stock with an aggregate value of up to $120 million based on the achievement of certain performance targets by ecobee as of June 30, 2022 and June 30, 2023. The contingent consideration will be fixed and accelerated upon certain corporate transactions, including a change of control of the Company. We expect the acquisition to close in the fourth quarter of 2021, subject to customary closing conditions, including clearance under the Hart-Scott-Rodino Antitrust Improvement Act.

[0001437749-21-025317:mdna:55]
[same as prior period, unchanged from 0001437749-21-018371:mdna:54]

[0001437749-21-025317:mdna:56]
Three months ended September 30, 2021 compared to the three months ended September 30, 2020

[0001437749-21-025317:mdna:57]
[same as prior period, unchanged from 0001437749-21-018371:mdna:56]

[0001437749-21-025317:mdna:58]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 241,343 |  |  |  | 34.4 | % |
| Costs of goods sold |  |  | 606,704 |  |  |  | 425,206 |  |  |  | 181,498 |  |  |  | 42.7 | % |
| Gross profit |  |  | 335,994 |  |  |  | 276,149 |  |  |  | 59,845 |  |  |  | 21.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 82,242 |  |  |  | 60,901 |  |  |  | 21,341 |  |  |  | 35.0 | % |
| Research and development |  |  | 27,165 |  |  |  | 20,658 |  |  |  | 6,507 |  |  |  | 31.5 | % |
| General and administrative |  |  | 40,802 |  |  |  | 31,061 |  |  |  | 9,741 |  |  |  | 31.4 | % |
| Amortization of intangible assets |  |  | 12,206 |  |  |  | 7,892 |  |  |  | 4,314 |  |  |  | 54.7 | % |
| Total operating expenses |  |  | 162,415 |  |  |  | 120,512 |  |  |  | 41,903 |  |  |  | 34.8 | % |
| Income from operations |  |  | 173,579 |  |  |  | 155,637 |  |  |  | 17,942 |  |  |  | 11.5 | % |
| Total other income (expense), net |  |  | (8,215 | ) |  |  | (8,352 | ) |  |  | 137 |  |  |  | -1.6 | % |
| Income before provision for income taxes |  |  | 165,364 |  |  |  | 147,285 |  |  |  | 18,079 |  |  |  | 12.3 | % |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 561 |  |  |  | 1.8 | % |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 17,518 |  |  |  | 15.2 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 918 |  |  |  | 346.4 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 16,600 |  |  |  | 14.4 | % |

[0001437749-21-025317:mdna:59]
[same as prior period, unchanged from 0001437749-21-018371:mdna:58]

[0001437749-21-025317:mdna:60]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 790,764 |  |  | $ | 606,875 |  |  | $ | 183,889 |  |  |  | 30.3 | % |
| International |  |  | 151,934 |  |  |  | 94,480 |  |  |  | 57,454 |  |  |  | 60.8 | % |
| Total net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 241,343 |  |  |  | 34.4 | % |

[0001437749-21-025317:mdna:61]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 187,726 |  |  | $ | 171,359 |  |  | $ | 16,367 |  |  |  | 9.6 | % |
| International |  |  | 21,475 |  |  |  | 7,419 |  |  |  | 14,056 |  |  |  | 189.5 | % |
| Total Adjusted EBITDA |  | $ | 209,201 |  |  | $ | 178,778 |  |  | $ | 30,423 |  |  |  | 17.0 | % |

[0001437749-21-025317:mdna:62]
[same as prior period, unchanged from 0001437749-21-018371:mdna:61]

[0001437749-21-025317:mdna:63]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 608,816 |  |  | $ | 458,877 |  |  | $ | 149,939 |  |  |  | 32.7 | % |
| Commercial & industrial products |  |  | 258,309 |  |  |  | 176,200 |  |  |  | 82,109 |  |  |  | 46.6 | % |
| Other |  |  | 75,573 |  |  |  | 66,278 |  |  |  | 9,295 |  |  |  | 14.0 | % |
| Total net sales |  | $ | 942,698 |  |  | $ | 701,355 |  |  | $ | 241,343 |  |  |  | 34.4 | % |

[0001437749-21-025317:mdna:64]
Net sales.    Domestic segment sales increased 30.3% to $790.8 million as compared to $606.9 million in the prior year quarter, with the impact of acquisitions contributing approximately 1% of the revenue growth for the quarter. The current year quarter core sales growth was driven by strength across both residential and C&I products highlighted by very strong growth with home standby generators, PWRcellTM energy storage systems, telecom national account customers and C&I mobile products.

[0001437749-21-025317:mdna:65]
International segment sales increased 60.8% to $151.9 million as compared to $94.5 million in the prior year quarter, with the impact of acquisitions and foreign currency contributing $27.3 million of the revenue growth for the quarter. The core sales growth for the segment was primarily driven by strength across all regions, primarily Europe and Latin America, that continue to experience a sharp increase in demand off the prior year COVID-19 lows and have recovered well above 2019 levels.

[0001437749-21-025317:mdna:66]
The net sales contribution from all non-annualized recent acquisitions for the three months ended September 30, 2021 was $30.5 million.

[0001437749-21-025317:mdna:67]
Gross profit.    Gross profit margin for the third quarter of 2021 was 35.6% compared to 39.4% in the prior year third quarter. The gross profit margin decrease was primarily driven by higher input costs due to rising commodity prices, labor, logistics and plant start-up costs, which were partially offset by the early impacts of recent pricing actions.

[0001437749-21-025317:mdna:68]
Operating expenses.   Operating expenses increased $41.9 million, or 34.8%, as compared to the prior year third quarter. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee and marketing costs, and the impact of acquisitions relative to acquisition related transaction expenses, recurring operating expenses and amortization expense.

[0001437749-21-025317:mdna:69]
Other expense.    The decrease in Other expense, net was driven by a reduction in interest expense due to lower LIBOR rates.

[0001437749-21-025317:mdna:70]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2021 and 2020 were 19.7% and 21.8%, respectively. The decrease in the effective tax rate was primarily due to a discrete tax item resulting from a higher stock compensation deduction during the current year quarter.

[0001437749-21-025317:mdna:71]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $131.6 million as compared to $115.0 million in the prior year third quarter. The increase was primarily driven by increased operating earnings as noted above.

[0001437749-21-025317:mdna:72]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the third quarter of 2021 was $187.7 million, or 23.7% of net sales, as compared to $171.4 million, or 28.2% of net sales, in the prior year quarter. The margin decrease was driven by higher input costs in the current year quarter, which were partially offset by the early impacts of improved pricing during the quarter.

[0001437749-21-025317:mdna:73]
Adjusted EBITDA for the International segment in the third quarter of 2021, before deducting for non-controlling interests, was $21.5 million, or 14.1% of net sales, as compared to $7.4 million, or 7.9% of net sales, in the prior year quarter. The improvement in margin was primarily due to the positive impact of recent acquisitions and improved operating leverage on the higher sales volumes.

[0001437749-21-025317:mdna:74]
Adjusted Net Income.    Adjusted Net Income of $151.1 million for the three months ended September 30, 2021 increased 13.7% from $132.9 million for the three months ended September 30, 2020, due to the factors outlined above together with an increase in the cash income tax rate from approximately 16.0% in the prior year to approximately 20.0% to 20.5% in the current year.

[0001437749-21-025317:mdna:75]
[same as prior period, unchanged from 0001437749-21-018371:mdna:74]

[0001437749-21-025317:mdna:76]
Nine months ended September 30, 2021 compared to the nine months ended September 30, 2020

[0001437749-21-025317:mdna:77]
[same as prior period, unchanged from 0001437749-21-018371:mdna:76]

[0001437749-21-025317:mdna:78]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |  | $ | 945,995 |  |  |  | 54.9 | % |
| Costs of goods sold |  |  | 1,672,570 |  |  |  | 1,066,666 |  |  |  | 605,904 |  |  |  | 56.8 | % |
| Gross profit |  |  | 997,543 |  |  |  | 657,452 |  |  |  | 340,091 |  |  |  | 51.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 229,443 |  |  |  | 178,566 |  |  |  | 50,877 |  |  |  | 28.5 | % |
| Research and development |  |  | 74,897 |  |  |  | 58,762 |  |  |  | 16,135 |  |  |  | 27.5 | % |
| General and administrative |  |  | 115,311 |  |  |  | 88,732 |  |  |  | 26,579 |  |  |  | 30.0 | % |
| Amortization of intangible assets |  |  | 32,237 |  |  |  | 23,340 |  |  |  | 8,897 |  |  |  | 38.1 | % |
| Total operating expenses |  |  | 451,888 |  |  |  | 349,400 |  |  |  | 102,488 |  |  |  | 29.3 | % |
| Income from operations |  |  | 545,655 |  |  |  | 308,052 |  |  |  | 237,603 |  |  |  | 77.1 | % |
| Total other expense, net |  |  | (20,707 | ) |  |  | (25,847 | ) |  |  | 5,140 |  |  |  | -19.9 | % |
| Income before provision for income taxes |  |  | 524,948 |  |  |  | 282,205 |  |  |  | 242,743 |  |  |  | 86.0 | % |
| Provision for income taxes |  |  | 114,341 |  |  |  | 59,967 |  |  |  | 54,374 |  |  |  | 90.7 | % |
| Net income |  |  | 410,607 |  |  |  | 222,238 |  |  |  | 188,369 |  |  |  | 84.8 | % |
| Net loss attributable to noncontrolling interests |  |  | 3,008 |  |  |  | (3,337 | ) |  |  | 6,345 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 407,599 |  |  | $ | 225,575 |  |  | $ | 182,024 |  |  |  | 80.7 | % |

[0001437749-21-025317:mdna:79]
[same as prior period, unchanged from 0001437749-21-018371:mdna:78]

[0001437749-21-025317:mdna:80]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,267,648 |  |  | $ | 1,443,680 |  |  | $ | 823,968 |  |  |  | 57.1 | % |
| International |  |  | 402,465 |  |  |  | 280,438 |  |  |  | 122,027 |  |  |  | 43.5 | % |
| Total net sales |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |  | $ | 945,995 |  |  |  | 54.9 | % |

[0001437749-21-025317:mdna:81]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 598,730 |  |  | $ | 374,065 |  |  | $ | 224,665 |  |  |  | 60.1 | % |
| International |  |  | 42,344 |  |  |  | 13,877 |  |  |  | 28,467 |  |  |  | 205.1 | % |
| Total Adjusted EBITDA |  | $ | 641,074 |  |  | $ | 387,942 |  |  | $ | 253,132 |  |  |  | 65.2 | % |

[0001437749-21-025317:mdna:82]
[same as prior period, unchanged from 0001437749-21-018371:mdna:81]

[0001437749-21-025317:mdna:83]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,750,957 |  |  | $ | 1,057,848 |  |  | $ | 693,109 |  |  |  | 65.5 | % |
| Commercial & industrial products |  |  | 714,994 |  |  |  | 503,156 |  |  |  | 211,838 |  |  |  | 42.1 | % |
| Other |  |  | 204,162 |  |  |  | 163,114 |  |  |  | 41,048 |  |  |  | 25.2 | % |
| Total net sales |  | $ | 2,670,113 |  |  | $ | 1,724,118 |  |  | $ | 945,995 |  |  |  | 54.9 | % |

[0001437749-21-025317:mdna:84]
Net sales.    Domestic segment sales increased 57.1% to $2,267.6 million as compared to $1,443.7 million in the prior year. The increase was primarily driven by strong growth in shipments of residential products highlighted by home standby and portable generators. In addition, PWRcellTM energy storage systems experienced very robust growth as the Company continues to expand in the clean energy market, and shipments of chore products also improved at a strong rate as compared to the prior year. This was supplemented by a return to growth for C&I products which was led by a substantial increase in shipments for telecom national account customers and C&I mobile products compared to the prior year.

[0001437749-21-025317:mdna:85]
International segment sales increased 43.5% to $402.5 million as compared to $280.4 million in the prior year. The growth for the segment was due to an increase in market activity primarily in the European and Latin American regions that are seeing a sharp increase in demand as end markets recover from the impact of the COVID-19 pandemic. In addition, the impact of acquisitions and foreign currency added $43.8 million of revenue growth.

[0001437749-21-025317:mdna:86]
The net sales contribution from all non-annualized recent acquisitions for the nine months ended September 30, 2021 was $53.2 million.

[0001437749-21-025317:mdna:87]
Gross profit.    Gross profit margin for the nine months ended September 30, 2021 was 37.4% compared to 38.1% in the prior year. The gross profit margin decrease was primarily driven by higher input costs due to rising commodity prices, labor, logistics and plant start-up costs, which were partially offset by the early impacts of recent pricing actions and favorable sales mix from higher shipments of residential products.

[0001437749-21-025317:mdna:88]
Operating expenses.   Operating expenses increased $102.5 million, or 29.3%, as compared to the prior year. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee costs and incentive compensation, and the impact of acquisitions relative to acquisition related transaction expenses, recurring operating expenses and amortization expense.

[0001437749-21-025317:mdna:89]
Other expense.    The decrease in Other expense, net was driven by a reduction in interest expense due to lower LIBOR rates, as well as a $3.9 million gain recorded on the sale of a long-term investment in the first quarter of 2021, which was partially offset by an $.8 million non-cash write-off of original issue discount and deferred financing costs due to a $50 million voluntary prepayment of our Term Loan.

[0001437749-21-025317:mdna:90]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2021 and 2020 were 21.8% and 21.3%, respectively. The increase in the effective tax rate was primarily due to the earnings mix in the taxing jurisdictions the company operates in.

[0001437749-21-025317:mdna:91]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $407.6 million as compared to $225.6 million in the prior year period. The increase was primarily driven by increased sales volumes, operating earnings, and other items noted above.

[0001437749-21-025317:mdna:92]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $598.7 million, or 26.4% of net sales, as compared to $374.1 million, or 25.9% of net sales, in the prior year period. This margin increase was driven by favorable sales mix, improved pricing and higher operating leverage from the substantial revenue growth for the segment during the current year, which were partially offset by higher input costs due to rising commodity prices, labor, logistics and plant start-up costs.

[0001437749-21-025317:mdna:93]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $42.3 million, or 10.5% of net sales, as compared to $13.9 million, or 4.9% of net sales, in the prior year period. The improvement in margin was primarily due to the combination of favorable sales mix, improved operating leverage on the higher sales volumes, lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020, and the impact of recent acquisitions.

[0001437749-21-025317:mdna:94]
Adjusted Net Income.    Adjusted Net Income of $457.1 million for the nine months ended September 30, 2021 increased 65.3% from $276.5 million for the nine months ended September 30, 2020, due to the factors outlined above together with an increase in the cash income tax rate from approximately 16.0% in the prior year to approximately 20.0% to 20.5% in the current year.

[0001437749-21-025317:mdna:95]
[same as prior period, unchanged from 0001437749-21-018371:mdna:94]

[0001437749-21-025317:mdna:96]
[same as prior period, unchanged from 0001437749-21-018371:mdna:95]

[0001437749-21-025317:mdna:97]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, income taxes, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-21-025317:mdna:98]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. As of September 30, 2021, there was $780 million outstanding under the Term Loan. Following several amendments, the Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of September 30, 2021, our secured leverage ratio was 0.77 to 1.00 times, and we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-025317:mdna:99]
Our credit agreements also provide for a $500.0 million ABL Facility. The ABL Facility matures May 27, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. As of September 30, 2021, there was $50 million outstanding under the ABL Facility, leaving $449.3 million of availability, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of September 30, 2021.

[0001437749-21-025317:mdna:100]
As of September 30, 2021, we had $873.0 million of liquidity comprised of $423.7 million of cash and equivalents and $449.3 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan and ABL Facility until 2026. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-21-025317:mdna:101]
In September 2018, our Board of Directors approved a $250.0 million stock repurchase program, which expired in October 2020. In September 2020, our Board of Directors approved another stock repurchase program, which commenced on October 27, 2020, and allows for the repurchase of up to $250.0 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the nine months ended September 30, 2021 and 2020, no share repurchases were made under these plans. Since the inception of all stock repurchase programs starting in August 2015, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-21-025317:mdna:102]
[same as prior period, unchanged from 0001437749-21-018371:mdna:101]

[0001437749-21-025317:mdna:103]
[same as prior period, unchanged from 0001437749-21-018371:mdna:102]

[0001437749-21-025317:mdna:104]
[same as prior period, unchanged from 0001437749-21-018371:mdna:103]

[0001437749-21-025317:mdna:105]
[same as prior period, unchanged from 0001437749-21-018371:mdna:104]

[0001437749-21-025317:mdna:106]
Nine months ended September 30, 2021 compared to the nine months ended September 30, 2020

[0001437749-21-025317:mdna:107]
[same as prior period, unchanged from 0001437749-21-018371:mdna:106]

[0001437749-21-025317:mdna:108]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 349,404 |  |  | $ | 268,310 |  |  | $ | 81,094 |  |  |  | 30.2 | % |
| Net cash used in investing activities |  |  | (546,773 | ) |  |  | (54,731 | ) |  |  | (492,042 | ) |  |  | -899.0 | % |
| Net cash used in financing activities |  |  | (33,445 | ) |  |  | (21,596 | ) |  |  | (11,849 | ) |  |  | -54.9 | % |

[0001437749-21-025317:mdna:109]
The increase in net cash provided by operating activities was primarily due to higher sales volumes and resulting higher operating earnings in the current year, partially offset by increased working capital investment and higher income taxes paid in the current year.

[0001437749-21-025317:mdna:110]
Net cash used in investing activities for the nine months ended September 30, 2021 primarily represents cash payments of $465.9 million related to the acquisition of businesses and $87.5 million related to the purchase of property and equipment, which were partially offset by cash proceeds on sale of an investment of $5.0 million. Net cash used in investing activities for the nine months ended September 30, 2020 primarily represents cash payments of $33.9 million related to the purchase of property and equipment and $22.8 million related to the acquisition of businesses.

[0001437749-21-025317:mdna:111]
Net cash used in financing activities for the nine months ended September 30, 2021 primarily represents $160.1 million of debt repayments ($105.2 million of short-term borrowings and $54.9 million of long-term borrowings and finance lease obligations), $50.0 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of Pramac, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $127.8 million from short-term borrowings, $50.0 million from long-term borrowings and $30.5 million from the exercise of stock options.

[0001437749-21-025317:mdna:112]
Net cash used in financing activities for the nine months ended September 30, 2020 primarily represents $214.4 million of debt repayments ($210.8 million of short-term borrowings and $3.6 million of long-term borrowings and finance lease obligations), $13.5 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $198.1 million from short-term borrowings and $12.0 million from the exercise of stock options.

[0001437749-21-025317:mdna:113]
[same as prior period, unchanged from 0001437749-21-018371:mdna:112]

[0001437749-21-025317:mdna:114]
[same as prior period, unchanged from 0001437749-21-018371:mdna:113]

[0001437749-21-025317:mdna:115]
[same as prior period, unchanged from 0001437749-21-018371:mdna:114]

[0001437749-21-025317:mdna:116]
There have been no material changes to off-balance sheet arrangements since the February 23, 2021 filing of our Annual Report on Form 10-K for the year ended December 31, 2020. See Note 15, "Commitments and Contingencies," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our off-balance sheet arrangements.

[0001437749-21-025317:mdna:117]
[same as prior period, unchanged from 0001437749-21-018371:mdna:116]

[0001437749-21-025317:mdna:118]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2020, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-21-025317:mdna:119]
[same as prior period, unchanged from 0001437749-21-018371:mdna:118]

[0001437749-21-025317:mdna:120]
[same as prior period, unchanged from 0001437749-21-018371:mdna:119]

[0001437749-21-025317:mdna:121]
[same as prior period, unchanged from 0001437749-21-018371:mdna:120]

[0001437749-21-025317:mdna:122]
[same as prior period, unchanged from 0001437749-21-018371:mdna:121]

[0001437749-21-025317:mdna:123]
[same as prior period, unchanged from 0001437749-21-018371:mdna:122]

[0001437749-21-025317:mdna:124]
[same as prior period, unchanged from 0001437749-21-018371:mdna:123]

[0001437749-21-025317:mdna:125]
[same as prior period, unchanged from 0001437749-21-018371:mdna:124]

[0001437749-21-025317:mdna:126]
[same as prior period, unchanged from 0001437749-21-018371:mdna:125]

[0001437749-21-025317:mdna:127]
[same as prior period, unchanged from 0001437749-21-018371:mdna:126]

[0001437749-21-025317:mdna:128]
[same as prior period, unchanged from 0001437749-21-018371:mdna:127]

[0001437749-21-025317:mdna:129]
[same as prior period, unchanged from 0001437749-21-018371:mdna:128]

[0001437749-21-025317:mdna:130]
[same as prior period, unchanged from 0001437749-21-018371:mdna:129]

[0001437749-21-025317:mdna:131]
[same as prior period, unchanged from 0001437749-21-018371:mdna:130]

[0001437749-21-025317:mdna:132]
[same as prior period, unchanged from 0001437749-21-018371:mdna:131]

[0001437749-21-025317:mdna:133]
[same as prior period, unchanged from 0001437749-21-018371:mdna:132]

[0001437749-21-025317:mdna:134]
[same as prior period, unchanged from 0001437749-21-018371:mdna:133]

[0001437749-21-025317:mdna:135]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-21-025317:mdna:136]
[same as prior period, unchanged from 0001437749-21-018371:mdna:135]

[0001437749-21-025317:mdna:137]
[same as prior period, unchanged from 0001437749-21-018371:mdna:136]

[0001437749-21-025317:mdna:138]
[same as prior period, unchanged from 0001437749-21-018371:mdna:137]

[0001437749-21-025317:mdna:139]
[same as prior period, unchanged from 0001437749-21-018371:mdna:138]

[0001437749-21-025317:mdna:140]
[same as prior period, unchanged from 0001437749-21-018371:mdna:139]

[0001437749-21-025317:mdna:141]
[same as prior period, unchanged from 0001437749-21-018371:mdna:140]

[0001437749-21-025317:mdna:142]
[same as prior period, unchanged from 0001437749-21-018371:mdna:141]

[0001437749-21-025317:mdna:143]
[same as prior period, unchanged from 0001437749-21-018371:mdna:142]

[0001437749-21-025317:mdna:144]
[same as prior period, unchanged from 0001437749-21-018371:mdna:143]

[0001437749-21-025317:mdna:145]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-21-025317:mdna:146]
[same as prior period, unchanged from 0001437749-21-018371:mdna:145]

[0001437749-21-025317:mdna:147]
[same as prior period, unchanged from 0001437749-21-018371:mdna:146]

[0001437749-21-025317:mdna:148]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 3,008 |  |  |  | (3,337 | ) |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 410,607 |  |  |  | 222,238 |  |
| Interest expense |  |  | 7,980 |  |  |  | 8,096 |  |  |  | 23,424 |  |  |  | 25,081 |  |
| Depreciation and amortization |  |  | 23,216 |  |  |  | 17,168 |  |  |  | 62,682 |  |  |  | 50,087 |  |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 114,341 |  |  |  | 59,967 |  |
| Non-cash write-down and other adjustments (a) |  |  | 3,333 |  |  |  | 477 |  |  |  | 638 |  |  |  | 1,868 |  |
| Non-cash share-based compensation expense (b) |  |  | 5,783 |  |  |  | 4,353 |  |  |  | 18,204 |  |  |  | 14,327 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 3,385 |  |  |  | 568 |  |  |  | 9,471 |  |  |  | 1,160 |  |
| Business optimization and other charges (e) |  |  | - |  |  |  | 531 |  |  |  | 159 |  |  |  | 12,503 |  |
| Other |  |  | 140 |  |  |  | 300 |  |  |  | 717 |  |  |  | 711 |  |
| Adjusted EBITDA |  |  | 209,201 |  |  |  | 178,778 |  |  |  | 641,074 |  |  |  | 387,942 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,247 |  |  |  | 920 |  |  |  | 6,454 |  |  |  | 950 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 206,954 |  |  | $ | 177,858 |  |  | $ | 634,620 |  |  | $ | 386,992 |  |

[0001437749-21-025317:mdna:149]
(a)   Represents the following non-cash charges, gains, and other adjustments: gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. We believe that adjusting net income for these non-cash charges and gains is useful for the following reasons:

[0001437749-21-025317:mdna:150]
[same as prior period, unchanged from 0001437749-21-018371:mdna:149]

[0001437749-21-025317:mdna:151]
[same as prior period, unchanged from 0001437749-21-018371:mdna:150]

[0001437749-21-025317:mdna:152]
[same as prior period, unchanged from 0001437749-21-018371:mdna:151]

[0001437749-21-025317:mdna:153]
[same as prior period, unchanged from 0001437749-21-018371:mdna:152]

[0001437749-21-025317:mdna:154]
(d)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-21-025317:mdna:155]
(e)  For the three and nine months ended September 30, 2021, represents severance and other charges related to the consolidation of certain of our facilities. For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices.

[0001437749-21-025317:mdna:156]
[same as prior period, unchanged from 0001437749-21-018371:mdna:155]

[0001437749-21-025317:mdna:157]
[same as prior period, unchanged from 0001437749-21-018371:mdna:156]

[0001437749-21-025317:mdna:158]
[same as prior period, unchanged from 0001437749-21-018371:mdna:157]

[0001437749-21-025317:mdna:159]
[same as prior period, unchanged from 0001437749-21-018371:mdna:158]

[0001437749-21-025317:mdna:160]
[same as prior period, unchanged from 0001437749-21-018371:mdna:159]

[0001437749-21-025317:mdna:161]
[same as prior period, unchanged from 0001437749-21-018371:mdna:160]

[0001437749-21-025317:mdna:162]
[same as prior period, unchanged from 0001437749-21-018371:mdna:161]

[0001437749-21-025317:mdna:163]
[same as prior period, unchanged from 0001437749-21-018371:mdna:162]

[0001437749-21-025317:mdna:164]
[same as prior period, unchanged from 0001437749-21-018371:mdna:163]

[0001437749-21-025317:mdna:165]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 131,570 |  |  | $ | 114,970 |  |  | $ | 407,599 |  |  | $ | 225,575 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,183 |  |  |  | 265 |  |  |  | 3,008 |  |  |  | (3,337 | ) |
| Net income |  |  | 132,753 |  |  |  | 115,235 |  |  |  | 410,607 |  |  |  | 222,238 |  |
| Provision for income taxes |  |  | 32,611 |  |  |  | 32,050 |  |  |  | 114,341 |  |  |  | 59,967 |  |
| Income before provision for income taxes |  |  | 165,364 |  |  |  | 147,285 |  |  |  | 524,948 |  |  |  | 282,205 |  |
| Amortization of intangible assets |  |  | 12,206 |  |  |  | 7,892 |  |  |  | 32,237 |  |  |  | 23,340 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 646 |  |  |  | 654 |  |  |  | 1,941 |  |  |  | 1,940 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 5,487 |  |  |  | 381 |  |  |  | 11,130 |  |  |  | 612 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | - |  |  |  | - |  |  |  | (3,991 | ) |  |  | - |  |
| Business optimization and other charges |  |  | - |  |  |  | 531 |  |  |  | 159 |  |  |  | 12,503 |  |
| Adjusted net income before provision for income taxes |  |  | 183,703 |  |  |  | 156,743 |  |  |  | 567,255 |  |  |  | 320,600 |  |
| Cash income tax expense (c) |  |  | (31,290 | ) |  |  | (23,620 | ) |  |  | (106,564 | ) |  |  | (44,842 | ) |
| Adjusted net income |  |  | 152,413 |  |  |  | 133,123 |  |  |  | 460,691 |  |  |  | 275,758 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,272 |  |  |  | 198 |  |  |  | 3,616 |  |  |  | (725 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 151,141 |  |  | $ | 132,925 |  |  | $ | 457,075 |  |  | $ | 276,483 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.35 |  |  | $ | 2.08 |  |  | $ | 7.13 |  |  | $ | 4.35 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,208,116 |  |  |  | 63,761,380 |  |  |  | 64,146,281 |  |  |  | 63,546,132 |  |

[0001437749-21-025317:mdna:166]
[same as prior period, unchanged from 0001437749-21-018371:mdna:165]

[0001437749-21-025317:mdna:167]
[same as prior period, unchanged from 0001437749-21-018371:mdna:166]

[0001437749-21-025317:mdna:168]
(c) Amount for the three and nine months ended September 30, 2021 is based on an anticipated cash income tax rate of approximately 20.0% to 20.5% for the full year ending December 31, 2021. Amount for the three and nine months ended September 30, 2020 is based on an anticipated cash income tax rate at the time of approximately 16% for the full year ended December 31, 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-21-025317:mdna:169]
[same as prior period, unchanged from 0001437749-21-018371:mdna:168]

[0001437749-21-025317:mdna:170]
[same as prior period, unchanged from 0001437749-21-018371:mdna:169]
