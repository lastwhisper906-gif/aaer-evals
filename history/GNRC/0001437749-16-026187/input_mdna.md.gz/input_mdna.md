# GNRC MD&A — 0001437749-16-026187


## mdna

[0001437749-16-026187:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-16-026187:mdna:2]
Overview

[0001437749-16-026187:mdna:3]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas, and construction markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we are a market leader in the power equipment market in North America and have an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-16-026187:mdna:4]
Over the past several years, we have executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-16-026187:mdna:5]
Business Drivers and Operational Factors

[0001437749-16-026187:mdna:6]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-16-026187:mdna:7]
Business Drivers and Trends

[0001437749-16-026187:mdna:8]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-16-026187:mdna:9]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2013 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. In addition, the importance of backup power for telecommunications infrastructure is increasing due to the growing importance for uninterrupted voice and data services. Also, in recent years, a more stringent regulatory environment around the flaring of natural gas at oil & gas drilling and production sites has been a catalyst for increased demand for natural gas fueled generators, including mobile solutions. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-16-026187:mdna:10]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the multiple major outage events that occurred during the second half of both 2011 and 2012 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to substantial organic revenue growth in 2012 with strong growth continuing during 2013. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-16-026187:mdna:11]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-16-026187:mdna:12]
Impact of business capital investment cycle.  The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions and credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-16-026187:mdna:13]
Factors Affecting Results of Operations

[0001437749-16-026187:mdna:14]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing and cost control. Certain operational and other factors that affect our business include the following:

[0001437749-16-026187:mdna:15]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum and other components we use in our products, together with foreign currency fluctuations, can have a material impact on our results of operations. We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-16-026187:mdna:16]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 23% to 27% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 28% in the fourth quarter, with different seasonality depending on the presence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period, and for the subsequent quarters following the time period, varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-16-026187:mdna:17]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit agreement pricing grids, and repayments or borrowings of indebtedness. Cash interest expense decreased during 2015 compared to 2014, primarily due to voluntary prepayments of Term Loan principal and the lower interest rate on our Amended ABL Facility borrowings. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-16-026187:mdna:18]
Factors influencing provision for income taxes and cash income taxes paid. We had approximately $715 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2015 related to our acquisition by CCMP in 2006 that we expect to generate aggregate cash tax savings of approximately $279 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $42.0 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2015. We expect these assets to generate aggregate cash tax savings of $16.4 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-16-026187:mdna:19]
Components of Net Sales and Expenses

[0001437749-16-026187:mdna:20]
Net Sales

[0001437749-16-026187:mdna:21]
Substantially all of our net sales are generated through the sale of our power generator equipment and other engine powered products to the residential, light commercial, industrial, oil & gas, and construction markets. We also sell engines to certain customers and service parts to our dealer network. Net sales, which include shipping and handling charges billed to customers, are generally recognized upon shipment of products to our customers. Related freight costs are included in cost of sales.

[0001437749-16-026187:mdna:22]
During 2015, our net sales were affected primarily by the U.S. market as sales outside of the United States represented approximately 15% of total net sales.

[0001437749-16-026187:mdna:23]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 7% of our sales, and our top ten customers representing less than 25% of our total sales for the year ended December 31, 2015.

[0001437749-16-026187:mdna:24]
Costs of Goods Sold

[0001437749-16-026187:mdna:25]
The principal elements of costs of goods sold in our manufacturing operations are component parts, raw materials, factory overhead and labor. Component parts and raw materials comprised approximately 84% of costs of goods sold for the year ended December 31, 2015. The principal component parts are engines and alternators. We design and manufacture air-cooled engines for certain of our generators up to 22kW. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the OEM of those engines. We design many of the alternators for our units and either manufacture or source alternators for certain of our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-16-026187:mdna:26]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. However, there is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-16-026187:mdna:27]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-16-026187:mdna:28]
Operating Expenses

[0001437749-16-026187:mdna:29]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs and taxes, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-16-026187:mdna:30]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, and opportunities to create market awareness for home standby generators in areas impacted by heightened power outage activity.

[0001437749-16-026187:mdna:31]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. We currently operate engineering facilities at eight locations globally and employ over 250 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-16-026187:mdna:32]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-16-026187:mdna:33]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and other intangibles assets.

[0001437749-16-026187:mdna:34]
Other Income (Expense)

[0001437749-16-026187:mdna:35]
Other income (expense) includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and expenses related to interest rate swap agreements. Other income (expense) also includes other financial items such as losses on extinguishment of debt, gains (losses) on change in contractual interest rate, interest income earned on our cash and cash equivalents, and costs related to acquisitions.

[0001437749-16-026187:mdna:36]
Costs related to acquisitions.   In 2015, the other expenses include transaction-related expenses related to the acquisitions of CHP and Pramac. In 2014, the other expenses include transaction-related expenses related to the acquisitions of Powermate and MAC. In 2013, other expenses include transaction-related expenses related to the acquisitions of Tower Light and Baldor. See Note 3, “Acquisitions” and Note 20, “Subsequent Events” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information on the Company’s recent acquisitions and the announced acquisition of Pramac.

[0001437749-16-026187:mdna:37]
Results of Operations

[0001437749-16-026187:mdna:38]
Year ended December 31, 2015 compared to year ended December 31, 2014

[0001437749-16-026187:mdna:39]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-16-026187:mdna:40]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |
| Costs of goods sold |  |  | 857,349 |  |  |  | 944,700 |  |
| Gross profit |  |  | 459,950 |  |  |  | 516,219 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 130,242 |  |  |  | 120,408 |  |
| Research and development |  |  | 32,922 |  |  |  | 31,494 |  |
| General and administrative |  |  | 52,947 |  |  |  | 54,795 |  |
| Amortization of intangibles |  |  | 23,591 |  |  |  | 21,024 |  |
| Tradename and goodwill impairment |  |  | 40,687 |  |  |  | - |  |
| Gain on remeasurement of contingent consideration |  |  | - |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 280,389 |  |  |  | 222,844 |  |
| Income from operations |  |  | 179,561 |  |  |  | 293,375 |  |
| Total other expense, net |  |  | 56,578 |  |  |  | 35,013 |  |
| Income before provision for income taxes |  |  | 122,983 |  |  |  | 258,362 |  |
| Provision for income taxes |  |  | 45,236 |  |  |  | 83,749 |  |
| Net income |  | $ | 77,747 |  |  | $ | 174,613 |  |

[0001437749-16-026187:mdna:41]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |
| Residential products |  | $ | 673,764 |  |  | $ | 722,206 |  |
| Commercial & Industrial products |  |  | 548,440 |  |  |  | 652,216 |  |
| Other |  |  | 95,095 |  |  |  | 86,497 |  |
| Net sales |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |

[0001437749-16-026187:mdna:42]
Net sales. Net sales decreased $143.6 million, or 9.8%, to $1,317.3 million for the year ended December 31, 2015 from $1,460.9 million for the year ended December 31, 2014. The contribution from non-annualized recent acquisitions to the year ended December 31, 2015 was $62.8 million. Residential product sales decreased 6.7% to $673.8 million in 2015 from $722.2 million for the comparable period in 2014, primarily due to lower demand of home standby generators as a result of the significant decline in the power outage severity environment during 2015, partially offset by the contribution from recent acquisitions. C&I product sales decreased 15.9% to $548.4 million in 2015 from $652.2 million for the comparable period in 2014, primarily due to a significant reduction in shipments into oil & gas and general rental markets and, to a lesser extent, reduced shipments to telecom national account customers and the negative impact of foreign currency, partially offset by the contribution from recent acquisitions.

[0001437749-16-026187:mdna:43]
Gross profit. Gross profit decreased $56.2 million, or 10.9%, to $460.0 million for the year ended December 31, 2015 from $516.2 million for the year ended December 31, 2014. Gross profit margin for the year ended December 31, 2015 decreased to 34.9% from 35.3% for the year ended December 31, 2014. The decline in gross margin was primarily due to unfavorable absorption of manufacturing overhead-related costs, partially offset by the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar.

[0001437749-16-026187:mdna:44]
Operating expenses. Operating expenses increased $57.6 million to $280.4 million for the year ended December 31, 2015 from $222.8 million for the year ended December 31, 2014. The current year operating expenses include a non-cash $36.1 million impairment charge relating to tradenames as a result of a new brand strategy to transition and consolidate various brands to the Generac® tradename, and a non-cash $4.6 million impairment charge relating to the write-down of the goodwill of the Ottomotores reporting unit. Additionally, the prior year operating expenses include a $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from an acquisition. Excluding the impact of these items, operating expenses increased $12.0 million primarily due to the addition of recurring operating expenses associated with recent acquisitions, increased marketing and advertising expenses, and a $2.6 million increase in the amortization of intangible assets. This was partially offset by reductions in variable operating expenses on lower sales volumes

[0001437749-16-026187:mdna:45]
Other expense. Other expense increased $21.6 million, or 61.6%, to $56.6 million for the year ended December 31, 2015 from $35.0 million for the year ended December 31, 2014. The increase was primarily due to a prior year $16.0 million non-cash gain relating to a 25 basis point reduction in borrowing costs as a result of our net debt leverage ratio falling below 3.0 times at March 31, 2014, and a current year $2.4 million non-cash loss relating to a 25 basis point increase in borrowing costs as a result of our net debt leverage ratio moving back above 3.0 times at June 30, 2015. Additionally, $150.0 million of voluntary prepayments of Term Loan debt were made in the current year, resulting in a non-cash $4.8 million loss on extinguishment of debt compared to voluntary prepayments of Term Loan debt of $87.0 million in the prior year, which resulted in a non-cash $2.1 million loss on extinguishment of debt. The debt repayments resulted in a year-over-year decrease in interest expense of $4.4 million.

[0001437749-16-026187:mdna:46]
Income tax expense. Income tax expense decreased $38.5 million to $45.2 million for the year ended December 31, 2015 from $83.7 million for the year ended December 31, 2014. The effective tax rate for 2015 was 36.8% as compared to 32.4% for 2014. The increase in income tax rate was primarily attributable to a decrease in the Company’s federal domestic production activity deduction due to lower pre-tax income.

[0001437749-16-026187:mdna:47]
Net income. As a result of the factors identified above, we generated net income of $77.7 million for the year ended December 31, 2015 compared to $174.6 million for the year ended December 31, 2014.

[0001437749-16-026187:mdna:48]
Adjusted EBITDA. Adjusted EBITDA, as defined and reconciled in Item 6, “Selected Financial Data,” decreased to $270.8 million in 2015 as compared to $337.3 million in 2014, due to the factors discussed above.

[0001437749-16-026187:mdna:49]
Adjusted net income. Adjusted Net Income, as defined and reconciled in Item 6, “Selected Financial Data,” decreased to $198.4 million in 2015 compared to $234.2 million in 2014, due to the factors discussed above partially offset by a decrease in cash income tax expense.

[0001437749-16-026187:mdna:50]
Year ended December 31, 2014 compared to year ended December 31, 2013

[0001437749-16-026187:mdna:51]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-16-026187:mdna:52]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 1,460,919 |  |  | $ | 1,485,765 |  |
| Costs of goods sold |  |  | 944,700 |  |  |  | 916,205 |  |
| Gross profit |  |  | 516,219 |  |  |  | 569,560 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 120,408 |  |  |  | 107,515 |  |
| Research and development |  |  | 31,494 |  |  |  | 29,271 |  |
| General and administrative |  |  | 54,795 |  |  |  | 55,490 |  |
| Amortization of intangibles |  |  | 21,024 |  |  |  | 25,819 |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  |  | - |  |
| Total operating expenses |  |  | 222,844 |  |  |  | 218,095 |  |
| Income from operations |  |  | 293,375 |  |  |  | 351,465 |  |
| Total other expense, net |  |  | 35,013 |  |  |  | 72,749 |  |
| Income before provision for income taxes |  |  | 258,362 |  |  |  | 278,716 |  |
| Provision for income taxes |  |  | 83,749 |  |  |  | 104,177 |  |
| Net income |  | $ | 174,613 |  |  | $ | 174,539 |  |

[0001437749-16-026187:mdna:53]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2014 |  |  | 2013 |  |
| Residential products |  | $ | 722,206 |  |  | $ | 843,727 |  |
| Commercial & Industrial products |  |  | 652,216 |  |  |  | 569,890 |  |
| Other |  |  | 86,497 |  |  |  | 72,148 |  |
| Net sales |  | $ | 1,460,919 |  |  | $ | 1,485,765 |  |

[0001437749-16-026187:mdna:54]
Net sales. Net sales decreased $24.9 million, or 1.7%, to $1,460.9 million for the year ended December 31, 2014 from $1,485.8 million for the year ended December 31, 2013. The contribution from non-annualized recent acquisitions to the year ended December 31, 2014 was $108.0 million. Residential product sales decreased 14.4% to $722.2 million from $843.7 million for the comparable period in 2013. Residential product sales declined on a year-over-year basis as 2013 benefited from approximately $140 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy in October 2012, which did not repeat in 2014. Excluding this benefit in 2013, residential products increased approximately 3%. C&I product sales increased 14.4% to $652.2 million from $569.9 million for the comparable period in 2013, primarily due to the contributions from recent acquisitions along with strength in the oil & gas markets, partially offset by reduced capital spending from certain telecom customers and overall softness within Latin America.

[0001437749-16-026187:mdna:55]
Gross profit. Gross profit decreased $53.4 million, or 9.4%, to $516.2 million for the year ended December 31, 2014 from $569.6 million for the year ended December 31, 2013. Gross profit margin for the year ended December 31, 2014 decreased to 35.3% from 38.3% for the year ended December 31, 2013. The decline in gross margin was driven by the combination of a higher mix of C&I product shipments, including the impact of recent acquisitions, an increase in promotional activities, and an overall increase in product costs, including a temporary increase in certain costs associated with the slowdown of activity in west coast ports as well as short-term increases in other overhead-related costs.

[0001437749-16-026187:mdna:56]
Operating expenses. Operating expenses increased $4.7 million to $222.8 million for the year ended December 31, 2014 from $218.1 million for the year ended December 31, 2013. Operating expenses increased primarily due to the impact of recent acquisitions, a more favorable adjustment to warranty reserves in 2013 as compared to 2014, and increased marketing and advertising expenses. These increases were partially offset by a $4.9 million gain recorded in the second quarter of 2014 relating to a remeasurement of a contingent earn-out obligation from a recent acquisition and a $4.8 million year-over-year decline in amortization of intangible assets.

[0001437749-16-026187:mdna:57]
Other expense. Other expense decreased $37.7 million, or 51.9%, to $35.0 million for the year ended December 31, 2014 from $72.7 million for the year ended December 31, 2013. Beginning in the second quarter of 2014, there was a 25 basis point reduction in borrowing costs as a result of the Company’s net debt leverage ratio falling below 3.0 times, resulting in a $16.0 million non-cash gain. In conjunction with the May 2013 refinancing and other debt prepayments made in 2013, a $15.3 million loss on extinguishment of debt was recorded. During 2014, $87.0 million of voluntary prepayments of Term Loan debt were made, resulting in a non-cash $2.1 million loss on extinguishment of debt. Additionally, there was a $7.2 million year-over-year decrease in interest expense due to the refinancing of our debt in May 2013.

[0001437749-16-026187:mdna:58]
Income tax expense. Income tax expense decreased $20.5 million to $83.7 million for the year ended December 31, 2014 from $104.2 million for the year ended December 31, 2013. The effective tax rate for 2014 was 32.4% as compared to 37.4% for 2013. The decrease in income tax rate was primarily attributable to tax planning related to the federal and state research credits, and utilization of the federal domestic production activity deduction due to sufficient taxable income.

[0001437749-16-026187:mdna:59]
Net income. As a result of the factors identified above, we generated net income of $174.6 million for the year ended December 31, 2014 compared to $174.5 million for the year ended December 31, 2013.

[0001437749-16-026187:mdna:60]
Adjusted EBITDA. Adjusted EBITDA, as defined and reconciled in Item 6, “Selected Financial Data,” decreased to $337.3 million in 2014 as compared to $402.6 million in 2013, due to the factors discussed above.

[0001437749-16-026187:mdna:61]
Adjusted net income. Adjusted Net Income, as defined and reconciled in Item 6, “Selected Financial Data,” decreased to $234.2 million in 2014 compared to $301.7 million in 2013, due to the factors discussed above in addition to an $8.5 million increase in cash income tax expense.

[0001437749-16-026187:mdna:62]
Liquidity and Financial Position

[0001437749-16-026187:mdna:63]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our Amended ABL Facility.

[0001437749-16-026187:mdna:64]
The Company’s credit agreements provide for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of December 31, 2015 was above 3.00 to 1.00. As of December 31, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-026187:mdna:65]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of December 31, 2015, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all of its covenants.

[0001437749-16-026187:mdna:66]
At December 31, 2015, we had cash and cash equivalents of $115.9 million and $148.5 million of availability under our revolving ABL credit facility, net of outstanding letters of credit.

[0001437749-16-026187:mdna:67]
On August 5, 2015, the Company’s Board of Directors approved a $200.0 million stock repurchase program. Under the program, the Company may repurchase up to $200.0 million of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its direction and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand or available borrowings. The stock repurchase program may be suspended or discontinued at any time without prior notice. For the year ended December 31, 2015, the Company repurchased 3,303,500 shares of its common stock for $99.9 million, funded with cash on hand.

[0001437749-16-026187:mdna:68]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information.

[0001437749-16-026187:mdna:69]
Long-term Liquidity

[0001437749-16-026187:mdna:70]
We believe that our cash flow from operations and availability under our Amended ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-16-026187:mdna:71]
Cash Flow

[0001437749-16-026187:mdna:72]
Year ended December 31, 2015 compared to year ended December 31, 2014

[0001437749-16-026187:mdna:73]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-16-026187:mdna:74]
|  |  | Year Ended December 31, |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 188,619 |  |  | $ | 252,986 |  |  | $ | (64,367 | ) |  |  | -25.4 | % |
| Net cash used in investing activities |  |  | (104,328 | ) |  |  | (95,491 | ) |  |  | (8,837 | ) |  |  | -9.3 | % |
| Net cash used in financing activities |  |  | (154,483 | ) |  |  | (116,023 | ) |  |  | (38,460 | ) |  |  | -33.1 | % |

[0001437749-16-026187:mdna:75]
Net cash provided by operating activities was $188.6 million for 2015 compared to $253.0 million in 2014. This decrease of $64.4 million, or 25.4%, is primarily attributable to lower operating earnings during the current year along with higher working capital investment primarily due to an increase in accounts payable, partially offset by lower cash tax payments versus the prior year.

[0001437749-16-026187:mdna:76]
Net cash used for investing activities for the year ended December 31, 2015 was $104.3 million, which was primarily related to cash payments of $73.8 million for the acquisition of businesses and $30.7 million for the purchase of property and equipment. Net cash used for investing activities for the year ended December 31, 2014 was $95.5 million, which was primarily related to cash payments of $61.2 million related to the acquisition of businesses and $34.7 million for the purchase of property and equipment.

[0001437749-16-026187:mdna:77]
Net cash used for financing activities was $154.5 million for the year ended December 31, 2015, primarily consisting of $174.0 million of debt repayments ($150.8 million repayment of long-term borrowings and $23.2 million repayment of short-term borrowings), partially offset by $126.4 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the Amended ABL facility and $26.4 million from short-term borrowings). In addition, the Company paid $99.9 million for the repurchase of its common stock and $13.0 million for the net share settlement of equity awards, which was partially offset by $9.6 million of cash tax benefits of equity awards.

[0001437749-16-026187:mdna:78]
Net cash used for financing activities was $116.0 million for the year ended December 31, 2014, including $120.4 million of debt repayments ($94.0 million repayment of long-term borrowings and $26.4 million repayment of short-term borrowings), partially offset by $6.6 million of cash proceeds from short-term borrowings. In addition, the Company paid $12.2 million of taxes for the net share settlement of equity awards, which was partially offset by $11.0 million of cash tax benefits of equity awards.

[0001437749-16-026187:mdna:79]
Year ended December 31, 2014 compared to year ended December 31, 2013

[0001437749-16-026187:mdna:80]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-16-026187:mdna:81]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 252,986 |  |  | $ | 259,944 |  |  | $ | (6,958 | ) |  |  | -2.7 | % |
| Net cash used in investing activities |  |  | (95,491 | ) |  |  | (144,549 | ) |  |  | 49,058 |  |  |  | -33.9 | % |
| Net cash used in financing activities |  |  | (116,023 | ) |  |  | (73,399 | ) |  |  | (42,624 | ) |  |  | 58.1 | % |

[0001437749-16-026187:mdna:82]
Net cash provided by operating activities was $253.0 million for 2014 compared to $259.9 million in 2013. This decrease of $6.9 million, or 2.7%, is primarily attributable to lower operating income mostly offset by a reduction in working capital investment, which was primarily due to a significant use of cash in 2013 to replenish finished good inventory levels that had been depleted by demand driven from major power outages in 2012.

[0001437749-16-026187:mdna:83]
Net cash used for investing activities for the year ended December 31, 2014 was $95.5 million. This included cash payments of $61.2 million for the acquisition of businesses and $34.7 million for the purchase of property and equipment. Net cash used for investing activities for the year ended December 31, 2013 was $144.6 million. This included cash payments of $116.1 million for the acquisition of businesses and $30.8 million for the purchase of property and equipment, partially offset by cash proceeds of $2.3 million from the sale of a business.

[0001437749-16-026187:mdna:84]
Net cash used for financing activities was $116.0 million for the year ended December 31, 2014, including $120.4 million of debt repayments ($94.0 million repayment of long-term borrowings and $26.4 million repayment of short-term borrowings), partially offset by $6.6 million of cash proceeds from short-term borrowings. In addition, the Company paid $12.2 million of taxes for the net share settlement of equity awards, which was partially offset by $11.0 million of cash tax benefits of equity awards.

[0001437749-16-026187:mdna:85]
Net cash used for financing activities was $73.4 million for the year ended December 31, 2013, primarily representing the net cash impact of debt prepayments and the dividend recapitalization transaction in 2013, including cash proceeds from long-term borrowings of $1.2 billion offset by $901.2 million of long-term borrowing repayments. The Company paid $22.4 million for transaction fees incurred in connection with the May 2013 refinancing transaction. Following the refinancing, the Company paid a special cash dividend of $5.00 per share ($340.8 million) on the Company’s common stock (incremental to the $2.6 million cash dividends paid during 2013, related to the 2012 dividend, due to the vesting of restricted stock awards). In addition, the Company paid $15.0 million in taxes related to the net share settlement of equity awards which was partially offset by approximately $11.6 million of excess tax benefits of equity awards. Finally, the Company repaid $19.0 million of short-term borrowings, which were partially offset by $16.0 million of cash proceeds from short-term borrowings.

[0001437749-16-026187:mdna:86]
Senior Secured Credit Facilities

[0001437749-16-026187:mdna:87]
Refer to Note 10, “Credit Agreements,” to consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-16-026187:mdna:88]
Covenant Compliance

[0001437749-16-026187:mdna:89]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends (but which permitted the payment of the 2013 special cash dividend described in Note 17, “Special Cash Dividend,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K). Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-16-026187:mdna:90]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-16-026187:mdna:91]
The Amended ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-16-026187:mdna:92]
Contractual Obligations

[0001437749-16-026187:mdna:93]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2015:

[0001437749-16-026187:mdna:94]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including curent portion (1) |  | $ | 1,066,000 |  |  | $ | 500 |  |  | $ | 11,500 |  |  | $ | 1,054,000 |  |  | $ | - |  |
| Capital lease obligations, including current portion |  |  | 1,694 |  |  |  | 157 |  |  |  | 342 |  |  |  | 366 |  |  |  | 829 |  |
| Interest on long-term debt |  |  | 151,210 |  |  |  | 36,253 |  |  |  | 67,318 |  |  |  | 47,639 |  |  |  | - |  |
| Operating leases |  |  | 19,117 |  |  |  | 3,561 |  |  |  | 6,105 |  |  |  | 3,962 |  |  |  | 5,489 |  |
| Total contractual cash obligations (2) |  | $ | 1,238,021 |  |  | $ | 40,471 |  |  | $ | 85,265 |  |  | $ | 1,105,967 |  |  | $ | 6,318 |  |

[0001437749-16-026187:mdna:95]
(1) The Term Loan provides for a $1.2 billion term loan B credit facility and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020.

[0001437749-16-026187:mdna:96]
(2) Pension obligations are excluded from this table as we are unable to estimate the timing of payment due to the inherent assumptions underlying the obligation. However, the Company estimates we will contribute $0.7 million to our pension plans in 2016.

[0001437749-16-026187:mdna:97]
Capital Expenditures

[0001437749-16-026187:mdna:98]
Our operations require capital expenditures for technology, tooling, equipment, capacity expansion, systems and upgrades. Capital expenditures were $30.7 million and $34.7 million for the years ended December 31, 2015 and 2014, respectively, and were funded through cash from operations.

[0001437749-16-026187:mdna:99]
Off-Balance Sheet Arrangements

[0001437749-16-026187:mdna:100]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer and our dealers are given a longer period of time to pay the finance provider. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-16-026187:mdna:101]
Total inventory financed under this arrangement accounted for approximately 9% and 8% of net sales for the years ended December 31, 2015 and 2014, respectively. The amount financed by dealers which remained outstanding was $32.4 million and $26.1 million as of December 31, 2015 and 2014, respectively.

[0001437749-16-026187:mdna:102]
Critical Accounting Policies

[0001437749-16-026187:mdna:103]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, that its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; income taxes and share based compensation.

[0001437749-16-026187:mdna:104]
Goodwill and Other Intangible Assets

[0001437749-16-026187:mdna:105]
See Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets.

[0001437749-16-026187:mdna:106]
The Company performed the required annual impairment tests for goodwill as of October 31, 2015, and determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge of $4.6 million in the fourth quarter of 2015. The fair value was determined using a discounted cash flow analysis, which utilizes key estimates and assumptions as discussed below. There were no other reporting units with a carrying value at-risk of exceeding fair value as of the October 31, 2015 impairment test date.

[0001437749-16-026187:mdna:107]
Additionally, in the fourth quarter of 2015, the Company’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired through acquisitions over the past several years to the Generac® tradename. This brand strategy change resulted in a reclassification to a two year remaining useful life for the impacted tradenames, causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a $36.1 million non-cash impairment charge was recorded in the fourth quarter of 2015 to write-down the impacted tradenames to net realizable value.

[0001437749-16-026187:mdna:108]
Other than the impairment charges discussed above, the Company found no other impairment when performing the required annual impairment tests for goodwill and other indefinite-lived intangible assets for fiscal years 2015, 2014 and 2013. See Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the impairment charges recorded in the fourth quarter of 2015.

[0001437749-16-026187:mdna:109]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-16-026187:mdna:110]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-16-026187:mdna:111]
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-16-026187:mdna:112]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-16-026187:mdna:113]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-16-026187:mdna:114]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-16-026187:mdna:115]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-16-026187:mdna:116]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-16-026187:mdna:117]
|  | ● | disruptions to the Company’s business; |

[0001437749-16-026187:mdna:118]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-16-026187:mdna:119]
|  | ● | unexpected or planned changes in the use of assets or entity structure; and |

[0001437749-16-026187:mdna:120]
|  | ● | business divestitures. |

[0001437749-16-026187:mdna:121]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-16-026187:mdna:122]
Business Combinations and Purchase Accounting

[0001437749-16-026187:mdna:123]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, and the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, earnings margins, and forecasted cash flows based on the discount rate and terminal growth rate. See Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-16-026187:mdna:124]
Defined Benefit Pension Obligations

[0001437749-16-026187:mdna:125]
The Company’s pension benefit obligation and related pension expense or income are calculated in accordance with ASC 715-30, Defined Benefit Plans—Pension, and are impacted by certain actuarial assumptions, including the discount rate and the expected rate of return on plan assets. Such rates are evaluated on an annual basis considering factors including market interest rates and historical asset performance. Actuarial valuations for fiscal year 2015 used a discount rate of 4.36% for the salaried pension plan and 4.39% for the hourly pension plan. Our discount rate was selected using a methodology that matches plan cash flows with a selection of “Aa” or higher rated bonds, resulting in a discount rate that better matches a bond yield curve with comparable cash flows. In estimating the expected return on plan assets, we study historical markets and preserve the long-term historical relationships between equities and fixed-income securities. We evaluate current market factors such as inflation and interest rates before we determine long-term capital market assumptions and review peer data and historical returns to check for reasonableness and appropriateness. Changes in the discount rate and return on assets can have a significant effect on the funded status of our pension plans, stockholders' equity and related expense. We cannot predict these changes in discount rates or investment returns and, therefore, cannot reasonably estimate whether the impact in subsequent years will be significant..

[0001437749-16-026187:mdna:126]
The funded status of our pension plans is the difference between the projected benefit obligation and the fair value of its plan assets. The projected benefit obligation is the actuarial present value of all benefits expected to be earned by the employees' service. No compensation increase is assumed in the calculation of the projected benefit obligation, as the plans were frozen effective December 31, 2008. Further information regarding the funded status of our pension plans can be found in Note 14, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-16-026187:mdna:127]
Our funding policy for our pension plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations. Given this policy, we expect to make $0.7 million in contributions to our pension plans in 2016.

[0001437749-16-026187:mdna:128]
Allowance for Doubtful Accounts, Excess & Obsolete Inventory Reserves, Product Warranty Reserves and Other Contingencies

[0001437749-16-026187:mdna:129]
The reserves, if any, for customer rebates, product warranty, product liability, litigation, excess and obsolete inventory, and doubtful accounts are fact-specific and take into account such factors as specific customer situations, historical experience, and current and expected economic conditions. Further information on these reserves are reflected under Notes 2, 7, 9, 16 and 19 to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-16-026187:mdna:130]
Income Taxes

[0001437749-16-026187:mdna:131]
We account for income taxes in accordance with ASC 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-16-026187:mdna:132]
Our balance sheet includes significant deferred tax assets as a result of goodwill and intangible asset book versus tax differences. In assessing the realizability of these deferred tax assets, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-16-026187:mdna:133]
Generac Brazil, acquired in the Ottomotores acquisition in December 2012, is in a three-year cumulative net loss position due to the start-up nature of the business, and therefore we have not considered expected future taxable income in analyzing the realizability of its deferred tax assets as of December 31, 2015. As a result, a full valuation allowance was recorded against the deferred tax assets of Generac Brazil.

[0001437749-16-026187:mdna:134]
In performing the assessment of the realization of our deferred tax assets as of December 31, 2015, excluding Generac Brazil, we have determined that it is more likely than not that our deferred tax assets will be realized, and therefore no valuation allowance is required.

[0001437749-16-026187:mdna:135]
See Note 13, “Income Taxes” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes.

[0001437749-16-026187:mdna:136]
Share Based Compensation

[0001437749-16-026187:mdna:137]
Under the fair value recognition provisions of ASC 718, Compensation – Stock Compensation, share based compensation cost is measured at the grant date based on the fair value of the award and is recognized as expense over the requisite service period. Determining the fair value of share based awards at the grant date requires judgment, including estimating expected dividends and market volatility of our stock. In addition, judgment is also required in estimating the amount of share based awards that are expected to be forfeited. If actual results differ significantly from these estimates, share based compensation expense and our results of operations could be impacted. See Note 15, “Share Plans” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s share based compensation.

[0001437749-16-026187:mdna:138]
New Accounting Standards

[0001437749-16-026187:mdna:139]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, see Note 2, “Significant Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.
