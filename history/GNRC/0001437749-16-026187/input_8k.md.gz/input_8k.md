# GNRC 8-K — 0001437749-16-025339 filed 2016-02-16

## item codes, every 8-K on or before 2016-02-26

- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2016-02-26

- none on or before 2016-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-025339:8k_2_02:1]
EX-99.1
3
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-025339:8k_2_02:2]
ex99-1.htm

[0001437749-16-025339:8k_2_02:3]
Exhibit 99.1

[0001437749-16-025339:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2015 Results

[0001437749-16-025339:8k_2_02:5]
Free cash flow a quarterly record of $101 million

[0001437749-16-025339:8k_2_02:6]
WAUKESHA, WISCONSIN, (February 16, 2016) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its fourth quarter and full-year ended December 31, 2015. Additionally, the Company initiated its outlook for 2016.

[0001437749-16-025339:8k_2_02:7]
Fourth Quarter 2015 Highlights

[0001437749-16-025339:8k_2_02:8]
| ● | Net sales were $357.8 million during the fourth quarter of 2015 as compared to $404.0 million in the prior-year fourth quarter, including a $14.9 million contribution from a recent acquisition. |

[0001437749-16-025339:8k_2_02:9]
|  | - | Residential product sales increased 1.8% to $198.5 million as compared to $194.9 million in the prior-year quarter, which was primarily due to the contribution from a recent acquisition, mostly offset by a decline in shipments of home standby generators as a result of lower power outage activity. |

[0001437749-16-025339:8k_2_02:10]
|  | - | Commercial & Industrial (C&I) product sales were $131.9 million as compared to $185.0 million in the prior-year quarter, which was primarily due to a significant decline in shipments of mobile products into oil & gas and general rental markets driven by the substantial decline in energy prices. |

[0001437749-16-025339:8k_2_02:11]
| ● | Gross profit margin during the fourth quarter improved 230 basis points over the prior-year quarter to 36.6% compared to 34.3%. |

[0001437749-16-025339:8k_2_02:12]
| ● | Net income during the fourth quarter of 2015 was $9.2 million, or $0.14 per share, as compared to net income of $49.4 million, or $0.70 per share, for the same period of 2014. The current-year net income includes the impact of $40.7 million of pre-tax, non-cash charges for the impairment of certain intangible assets with nearly the entire amount relating to tradenames as a result of a new brand strategy to transition and consolidate various brands to the Generac® tradename. |

[0001437749-16-025339:8k_2_02:13]
| ● | Adjusted net income, as defined in the accompanying reconciliation schedules, was $65.3 million, or $0.97 per share, as compared to $68.4 million, or $0.98 per share, in the fourth quarter of 2014. |

[0001437749-16-025339:8k_2_02:14]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $80.1 million as compared to $92.2 million in the fourth quarter last year. |

[0001437749-16-025339:8k_2_02:15]
| ● | Cash flow from operations was $111.8 million as compared to $110.5 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was a quarterly record of $101.2 million as compared to $98.5 million in the fourth quarter of 2014. |

[0001437749-16-025339:8k_2_02:16]
| ● | The Company repurchased 1.15 million shares of its common stock during the fourth quarter for $35.6 million under its previously announced $200 million share repurchase program. |

[0001437749-16-025339:8k_2_02:17]
| ● | As announced yesterday, the Company entered into an agreement to acquire a majority ownership interest of PR Industrial S.r.l and its subsidiaries (collectively Pramac), headquartered in Siena, Italy. With over 600 employees, four manufacturing plants and 14 commercial branches located around the world, Pramac is a leading global manufacturer of stationary, mobile and portable generators sold in over 150 countries through a broad distribution network. The acquisition is anticipated to close before the end of the first quarter of 2016. |

[0001437749-16-025339:8k_2_02:18]
Full-Year 2015 Highlights

[0001437749-16-025339:8k_2_02:19]
| ● | Net sales were $1.317 billion during 2015 as compared to $1.461 billion during 2014. |

[0001437749-16-025339:8k_2_02:20]
|  | - | Residential product sales were $673.8 million as compared to $722.2 million in the prior year. The decline from the prior year was primarily due to lower demand of home standby generators as a result of the significant decline in the power outage severity environment during 2015, partially offset by the contribution from recent acquisitions. |

[0001437749-16-025339:8k_2_02:21]
|  | - | Commercial & Industrial product sales were $548.4 million as compared to $652.2 million in the prior year. The decline was primarily due to a significant reduction in shipments into oil & gas and general rental markets and, to a lesser extent, reduced shipments to telecom national account customers and the negative impact of foreign currency, partially offset by the contribution from recent acquisitions. |

[0001437749-16-025339:8k_2_02:22]
| ● | Net income during 2015 was $77.7 million, or $1.12 per share, as compared to $174.6 million, or $2.49 per share for 2014. Current-year net income includes the impact of $40.7 million of pre-tax, non-cash charges for the impairment of certain intangible assets as previously discussed. Net income for both years also includes the impact of changes in the contractual interest rate relating to the Company’s term loan credit agreement, resulting in a $16.0 million gain during 2014 and $2.4 million loss during 2015. |
| ● | Adjusted net income was $198.4 million, or $2.87 per share, as compared to $234.2 million, or $3.34 per share, in 2014. |

[0001437749-16-025339:8k_2_02:23]
| ● | Adjusted EBITDA for 2015 was $270.8 million as compared to $337.3 million last year. |

[0001437749-16-025339:8k_2_02:24]
| ● | Cash flow from operations was $188.6 million as compared to $253.0 million in the prior year. Free cash flow was $158.0 million as compared to $218.3 million in 2014. |

[0001437749-16-025339:8k_2_02:25]
| ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries, a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. |

[0001437749-16-025339:8k_2_02:26]
| ● | Uses of cash during 2015 included $30.7 million for capital expenditures, $73.8 million related to acquisitions, $50.0 million for the pre-payment of term loan debt, and approximately $100 million for stock repurchases. |

[0001437749-16-025339:8k_2_02:27]
“Despite the ongoing low power outage environment, shipments of residential products improved organically on a sequential basis during the fourth quarter and exceeded our expectations,” said Aaron Jagdfeld, President and Chief Executive Officer. “This strength helped to largely offset additional weakness with shipments of mobile products caused by the ongoing decline in energy prices. We achieved our second half 2015 goals for inventory reductions and margin improvements, which led to a record level of free cash flow during the fourth quarter. On the acquisition front, the Pramac acquisition announced yesterday accelerates our strategy of expanding geographically and elevates us to a major player in the global power generation market.”

[0001437749-16-025339:8k_2_02:28]
Additional Fourth Quarter 2015 Highlights

[0001437749-16-025339:8k_2_02:29]
Residential product sales for the fourth quarter increased to $198.5 million as compared to $194.9 million for the fourth quarter of 2014. The increase was due to a combination of the contribution from a recent acquisition and, to a lesser extent, an increase in shipments of portable generators due to expanded placement of new products. These increases were partially offset by a decline in shipments of home standby generators primarily driven by very low levels of power outage severity during the current year.

[0001437749-16-025339:8k_2_02:30]
C&I product sales were $131.9 million as compared to $185.0 million for the comparable period in 2014. The decline was primarily due to a significant decline in shipments of mobile products into oil & gas and general rental markets as a result of lower capital spending caused by the substantial decline in energy prices. To a lesser extent, shipments of C&I products during the current year were also impacted by declines in Latin America along with the negative impact of foreign currency.

[0001437749-16-025339:8k_2_02:31]
Gross profit margin was 36.6% compared to 34.3% in the prior-year fourth quarter. The increase was primarily driven by favorable product mix including the impact from a recent acquisition, along with the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current-year quarter.

[0001437749-16-025339:8k_2_02:32]
Net income during the fourth quarter of 2015 includes the impact of $40.7 million of pre-tax, non-cash charges for the impairment of intangibles with nearly the entire amount relating to certain tradenames as a result of a new strategy to transition and consolidate various brands acquired through acquisitions over the past several years to the Generac® tradename.

[0001437749-16-025339:8k_2_02:33]
2

[0001437749-16-025339:8k_2_02:34]
Operating expenses increased $44.5 million as compared to the fourth quarter of 2014, which includes the impact of the aforementioned $40.7 million of intangible impairment charges. Excluding the impact of these charges, operating expenses for the quarter increased $3.8 million, or 6.5%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with a recent acquisition, partially offset by reductions in certain organic selling, general and administrative expenses.

[0001437749-16-025339:8k_2_02:35]
Free cash flow was $101.2 million as compared to $98.5 million in the same period last year, as the decline in operating earnings in the current year was more than offset by a larger benefit from a reduction in working capital investment, and to a lesser extent, a decline in cash income taxes and capital spending levels.

[0001437749-16-025339:8k_2_02:36]
The Company repurchased 1.15 million shares of its common stock during the fourth quarter of 2015 for $35.6 million under its share repurchase program which was announced in August 2015. The program authorizes the Company to repurchase up to $200 million of its common stock over a 24 month period, and to date, a total of 3.3 million shares of common stock have been repurchased for approximately $100 million.

[0001437749-16-025339:8k_2_02:37]
2016 Outlook

[0001437749-16-025339:8k_2_02:38]
The Company is initiating guidance for 2016 with net sales expected to increase between 10 to 12% as compared to the prior year, which assumes the contribution from the Pramac acquisition that is anticipated to close before the end of the first quarter of 2016.  Total organic sales on a constant currency basis are anticipated to be down between 5 to 7%, with nearly all of the decline expected to be from ongoing weakness in mobile product shipments into the oil & gas and general rental markets. This top-line guidance assumes no material changes in the current macroeconomic environment and also assumes no improvement in power outage severity relative to the very low levels experienced during 2015.  Adjusted EBITDA margins are expected to be approximately 20.0% for the full-year 2016, and free cash flow generation is expected to be strong, with the conversion of adjusted net income anticipated to be over 90%.

[0001437749-16-025339:8k_2_02:39]
“While several of our major end markets experienced significant down-cycles during 2015, we still made important progress on a variety of strategic initiatives throughout the year,” continued Mr. Jagdfeld. “These included driving awareness for our products, developing and expanding our distribution, further investing in innovative new products, and implementing manufacturing improvements. In addition, we continued to execute on our capital allocation priorities including paying down debt, making another strategic acquisition and returning capital to shareholders. Despite a weaker demand environment that persists entering 2016, we remain optimistic regarding the overall long-term growth prospects for our business. With the Pramac acquisition, we enter the current year as a more globally diversified company with a strong liquidity position that gives us the flexibility to drive our Powering Ahead strategic plan forward.”

[0001437749-16-025339:8k_2_02:40]
Conference Call and Webcast

[0001437749-16-025339:8k_2_02:41]
Generac management will hold a conference call at 9:00 a.m. EST on Tuesday, February 16, 2016 to discuss highlights of the fourth quarter and full-year 2015 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 39115113.

[0001437749-16-025339:8k_2_02:42]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-16-025339:8k_2_02:43]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 39115113. The telephonic replay will be available for 30 days.

[0001437749-16-025339:8k_2_02:44]
About Generac

[0001437749-16-025339:8k_2_02:45]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-025339:8k_2_02:46]
Forward-looking Information

[0001437749-16-025339:8k_2_02:47]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-16-025339:8k_2_02:48]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-16-025339:8k_2_02:49]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-16-025339:8k_2_02:50]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-16-025339:8k_2_02:51]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-16-025339:8k_2_02:52]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-16-025339:8k_2_02:53]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-16-025339:8k_2_02:54]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-16-025339:8k_2_02:55]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-16-025339:8k_2_02:56]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-16-025339:8k_2_02:57]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-16-025339:8k_2_02:58]
|  | ● | loss of key management and employees; |

[0001437749-16-025339:8k_2_02:59]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-16-025339:8k_2_02:60]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-025339:8k_2_02:61]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2014 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-025339:8k_2_02:62]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-16-025339:8k_2_02:63]
Reconciliations to GAAP Financial Metrics

[0001437749-16-025339:8k_2_02:64]
Adjusted EBITDA

[0001437749-16-025339:8k_2_02:65]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-025339:8k_2_02:66]
Adjusted Net Income

[0001437749-16-025339:8k_2_02:67]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses and certain other non-cash gains and losses.

[0001437749-16-025339:8k_2_02:68]
Free Cash Flow

[0001437749-16-025339:8k_2_02:69]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-16-025339:8k_2_02:70]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-16-025339:8k_2_02:71]
SOURCE: Generac Holdings Inc.

[0001437749-16-025339:8k_2_02:72]
CONTACT:

[0001437749-16-025339:8k_2_02:73]
Michael W. Harris

[0001437749-16-025339:8k_2_02:74]
Vice President – Finance 
(262) 544-4811 x2675

[0001437749-16-025339:8k_2_02:75]
Michael.Harris@Generac.com

[0001437749-16-025339:8k_2_02:76]
Generac Holdings Inc.

[0001437749-16-025339:8k_2_02:77]
Consolidated Statements of Comprehensive Income

[0001437749-16-025339:8k_2_02:78]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-025339:8k_2_02:79]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Audited) |  |
| Net sales |  | $ | 357,830 |  |  | $ | 403,997 |  |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |
| Costs of goods sold |  |  | 226,706 |  |  |  | 265,587 |  |  |  | 857,349 |  |  |  | 944,700 |  |
| Gross profit |  |  | 131,124 |  |  |  | 138,410 |  |  |  | 459,950 |  |  |  | 516,219 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 36,925 |  |  |  | 30,363 |  |  |  | 130,242 |  |  |  | 120,408 |  |
| Research and development |  |  | 8,015 |  |  |  | 7,914 |  |  |  | 32,922 |  |  |  | 31,494 |  |
| General and administrative |  |  | 12,050 |  |  |  | 15,715 |  |  |  | 52,947 |  |  |  | 54,795 |  |
| Amortization of intangibles |  |  | 6,131 |  |  |  | 5,303 |  |  |  | 23,591 |  |  |  | 21,024 |  |
| Tradename and goodwill impairment |  |  | 40,687 |  |  | – |  |  |  | 40,687 |  |  | – |  |
| Gain on remeasurement of contingent consideration |  | – |  |  | – |  |  | – |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 103,808 |  |  |  | 59,295 |  |  |  | 280,389 |  |  |  | 222,844 |  |
| Income from operations |  |  | 27,316 |  |  |  | 79,115 |  |  |  | 179,561 |  |  |  | 293,375 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,602 | ) |  |  | (11,804 | ) |  |  | (42,843 | ) |  |  | (47,215 | ) |
| Investment income |  |  | 12 |  |  |  | 11 |  |  |  | 123 |  |  |  | 130 |  |
| Loss on extinguishment of debt |  | – |  |  |  | (248 | ) |  |  | (4,795 | ) |  |  | (2,084 | ) |
| Gain (loss) on change in contractual interest rate |  | – |  |  | – |  |  |  | (2,381 | ) |  |  | 16,014 |  |
| Costs related to acquisition |  |  | (1,042 | ) |  | – |  |  |  | (1,195 | ) |  |  | (396 | ) |
| Other, net |  |  | (130 | ) |  |  | (220 | ) |  |  | (5,487 | ) |  |  | (1,462 | ) |
| Total other expense, net |  |  | (11,762 | ) |  |  | (12,261 | ) |  |  | (56,578 | ) |  |  | (35,013 | ) |
| Income before provision for income taxes |  |  | 15,554 |  |  |  | 66,854 |  |  |  | 122,983 |  |  |  | 258,362 |  |
| Provision for income taxes |  |  | 6,372 |  |  |  | 17,464 |  |  |  | 45,236 |  |  |  | 83,749 |  |
| Net income |  | $ | 9,182 |  |  | $ | 49,390 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Net income per common share - basic: |  | $ | 0.14 |  |  | $ | 0.72 |  |  | $ | 1.14 |  |  | $ | 2.55 |  |
| Weighted average common shares outstanding - basic: |  |  | 66,482,219 |  |  |  | 68,598,310 |  |  |  | 68,096,051 |  |  |  | 68,538,248 |  |
| Net income per common share - diluted: |  | $ | 0.14 |  |  | $ | 0.70 |  |  | $ | 1.12 |  |  | $ | 2.49 |  |
| Weighted average common shares outstanding - diluted: |  |  | 67,472,321 |  |  |  | 70,170,300 |  |  |  | 69,200,297 |  |  |  | 70,171,044 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | (1,069 | ) |  | $ | (1,052 | ) |  | $ | (7,624 | ) |  | $ | (3,082 | ) |
| Net unrealized gain (loss) on derivatives |  |  | 1,106 |  |  |  | (701 | ) |  |  | (965 | ) |  |  | (1,420 | ) |
| Pension liability adjustment |  |  | 1,881 |  |  |  | (8,850 | ) |  |  | 1,881 |  |  |  | (8,850 | ) |
| Other comprehensive income (loss) |  |  | 1,918 |  |  |  | (10,603 | ) |  |  | (6,708 | ) |  |  | (13,352 | ) |
| Comprehensive income |  | $ | 11,100 |  |  | $ | 38,787 |  |  | $ | 71,039 |  |  | $ | 161,261 |  |

[0001437749-16-025339:8k_2_02:80]
6

[0001437749-16-025339:8k_2_02:81]
Generac Holdings Inc.

[0001437749-16-025339:8k_2_02:82]
Consolidated Balance Sheets

[0001437749-16-025339:8k_2_02:83]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-025339:8k_2_02:84]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 115,857 |  |  | $ | 189,761 |  |
| Accounts receivable, less allowance for doubtful accounts of $2,494 at December 31, 2015 and $2,275 at December 31, 2014 |  |  | 182,185 |  |  |  | 189,107 |  |
| Inventories |  |  | 325,375 |  |  |  | 319,385 |  |
| Deferred income taxes |  |  | 29,355 |  |  |  | 22,841 |  |
| Prepaid expenses and other assets |  |  | 8,600 |  |  |  | 9,384 |  |
| Total current assets |  |  | 661,372 |  |  |  | 730,478 |  |
| Property and equipment, net |  |  | 184,213 |  |  |  | 168,821 |  |
| Customer lists, net |  |  | 39,313 |  |  |  | 41,002 |  |
| Patents, net |  |  | 53,772 |  |  |  | 56,894 |  |
| Other intangible assets, net |  |  | 2,768 |  |  |  | 4,298 |  |
| Tradenames, net |  |  | 161,057 |  |  |  | 182,684 |  |
| Goodwill |  |  | 669,719 |  |  |  | 635,565 |  |
| Deferred financing costs, net |  |  | 12,965 |  |  |  | 16,243 |  |
| Deferred income taxes |  |  | 6,673 |  |  |  | 46,509 |  |
| Other assets |  |  | 964 |  |  |  | 48 |  |
| Total assets |  | $ | 1,792,816 |  |  | $ | 1,882,542 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 8,594 |  |  | $ | 5,359 |  |
| Accounts payable |  |  | 108,332 |  |  |  | 132,248 |  |
| Accrued wages and employee benefits |  |  | 13,101 |  |  |  | 17,544 |  |
| Other accrued liabilities |  |  | 82,540 |  |  |  | 84,814 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 657 |  |  |  | 557 |  |
| Total current liabilities |  |  | 213,224 |  |  |  | 240,522 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,050,097 |  |  |  | 1,082,101 |  |
| Deferred income taxes |  |  | 6,166 |  |  |  | 13,449 |  |
| Other long-term liabilities |  |  | 57,458 |  |  |  | 56,671 |  |
| Total liabilities |  |  | 1,326,945 |  |  |  | 1,392,743 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,582,669 and 69,122,271 shares issued at December 31, 2015 and 2014, respectively |  |  | 696 |  |  |  | 691 |  |
| Additional paid-in capital |  |  | 443,109 |  |  |  | 434,906 |  |
| Treasury stock, at cost, 3,567,575 and 198,312 shares at December 31, 2015 and 2014, respectively |  |  | (111,516 | ) |  |  | (8,341 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 358,173 |  |  |  | 280,426 |  |
| Accumulated other comprehensive loss |  |  | (22,475 | ) |  |  | (15,767 | ) |
| Total stockholders’ equity |  |  | 465,871 |  |  |  | 489,799 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,792,816 |  |  | $ | 1,882,542 |  |

[0001437749-16-025339:8k_2_02:85]
Generac Holdings Inc.

[0001437749-16-025339:8k_2_02:86]
Consolidated Statements of Cash Flows

[0001437749-16-025339:8k_2_02:87]
(Dollars in Thousands)

[0001437749-16-025339:8k_2_02:88]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 16,742 |  |  |  | 13,706 |  |
| Amortization of intangible assets |  |  | 23,591 |  |  |  | 21,024 |  |
| Amortization of original issue discount |  |  | 3,050 |  |  |  | 3,599 |  |
| Amortization of deferred financing costs |  |  | 2,379 |  |  |  | 3,016 |  |
| Tradename and goodwill impairment |  |  | 40,687 |  |  | – |  |
| Loss on extinguishment of debt |  |  | 4,795 |  |  |  | 2,084 |  |
| (Gain) loss on change in contractual interest rate |  |  | 2,381 |  |  |  | (16,014 | ) |
| Gain on remeasurement of contingent consideration |  | – |  |  |  | (4,877 | ) |
| Provision for losses on accounts receivable |  |  | 481 |  |  |  | 672 |  |
| Deferred income taxes |  |  | 26,955 |  |  |  | 37,878 |  |
| Loss on disposal of property and equipment |  |  | 59 |  |  |  | 576 |  |
| Share-based compensation expense |  |  | 8,241 |  |  |  | 12,612 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 9,610 |  |  |  | (2,988 | ) |
| Inventories |  |  | 9,084 |  |  |  | 3,508 |  |
| Other assets |  |  | 5,063 |  |  |  | 2,456 |  |
| Accounts payable |  |  | (27,771 | ) |  |  | 15,269 |  |
| Accrued wages and employee benefits |  |  | (5,361 | ) |  |  | (9,405 | ) |
| Other accrued liabilities |  |  | 445 |  |  |  | 6,229 |  |
| Excess tax benefits from equity awards |  |  | (9,559 | ) |  |  | (10,972 | ) |
| Net cash provided by operating activities |  |  | 188,619 |  |  |  | 252,986 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 105 |  |  |  | 394 |  |
| Expenditures for property and equipment |  |  | (30,651 | ) |  |  | (34,689 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (73,782 | ) |  |  | (61,196 | ) |
| Net cash used in investing activities |  |  | (104,328 | ) |  |  | (95,491 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 26,384 |  |  |  | 6,550 |  |
| Proceeds from long-term borrowings |  |  | 100,000 |  |  | – |  |
| Repayments of short-term borrowings |  |  | (23,149 | ) |  |  | (26,444 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (150,826 | ) |  |  | (94,035 | ) |
| Stock repurchases |  |  | (99,942 | ) |  | – |  |
| Payment of debt issuance costs |  |  | (2,117 | ) |  |  | (4 | ) |
| Cash dividends paid |  |  | (1,436 | ) |  |  | (902 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,956 | ) |  |  | (12,160 | ) |
| Excess tax benefits from equity awards |  |  | 9,559 |  |  |  | 10,972 |  |
| Net cash used in financing activities |  |  | (154,483 | ) |  |  | (116,023 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (3,712 | ) |  |  | (1,858 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (73,904 | ) |  |  | 39,614 |  |
| Cash and cash equivalents at beginning of period |  |  | 189,761 |  |  |  | 150,147 |  |
| Cash and cash equivalents at end of period |  | $ | 115,857 |  |  | $ | 189,761 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 39,524 |  |  | $ | 42,592 |  |
| Income taxes |  |  | 6,087 |  |  |  | 34,283 |  |

[0001437749-16-025339:8k_2_02:89]
8

[0001437749-16-025339:8k_2_02:90]
Generac Holdings, Inc.

[0001437749-16-025339:8k_2_02:91]
Reconciliation Schedules

[0001437749-16-025339:8k_2_02:92]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-025339:8k_2_02:93]
| Net income to Adjusted EBITDA reconciliation |  |  |

[0001437749-16-025339:8k_2_02:94]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income |  | $ | 9,182 |  |  | $ | 49,390 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Interest expense |  |  | 10,602 |  |  |  | 11,804 |  |  |  | 42,843 |  |  |  | 47,215 |  |
| Depreciation and amortization |  |  | 10,573 |  |  |  | 8,985 |  |  |  | 40,333 |  |  |  | 34,730 |  |
| Income taxes provision |  |  | 6,372 |  |  |  | 17,464 |  |  |  | 45,236 |  |  |  | 83,749 |  |
| Non-cash write-down and other adjustments (1) |  |  | (199 | ) |  |  | 800 |  |  |  | 3,892 |  |  |  | (3,853 | ) |
| Non-cash share-based compensation expense (2) |  |  | 1,352 |  |  |  | 3,209 |  |  |  | 8,241 |  |  |  | 12,612 |  |
| Tradename and goodwill impairment (3) |  |  | 40,687 |  |  | – |  |  |  | 40,687 |  |  | – |  |
| Loss on extinguishment of debt (4) |  | – |  |  |  | 248 |  |  |  | 4,795 |  |  |  | 2,084 |  |
| (Gain) loss on change in contractual interest rate (5) |  | – |  |  | – |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and credit facility fees (6) |  |  | 1,250 |  |  |  | 261 |  |  |  | 2,249 |  |  |  | 1,851 |  |
| Business optimization expenses (7) |  |  | 204 |  |  | – |  |  |  | 1,947 |  |  | – |  |
| Other |  |  | 61 |  |  |  | 32 |  |  |  | 465 |  |  |  | 296 |  |
| Adjusted EBITDA |  | $ | 80,084 |  |  | $ | 92,193 |  |  | $ | 270,816 |  |  | $ | 337,283 |  |

[0001437749-16-025339:8k_2_02:95]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. Additionally, the year ended December 31, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the impairment of certain tradenames due to a new brand strategy to transition and consolidate various brands to the Generac® tradename ($36.1 million) and the impairment of goodwill related to a prior acquisition ($4.6 million). |
| (4) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (5) The amount for the year ended December 31, 2015 represents a non-cash loss relating to a 25 basis point increase in borrowing costs, effective third quarter 2015, as a result of the credit agreement leverage ratio rising above 3.0 times. The amount for the year ended December 31, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (7) Represents severance and other non-recurring restructuring charges. |

[0001437749-16-025339:8k_2_02:96]
| Net income to Adjusted net income reconciliation |

[0001437749-16-025339:8k_2_02:97]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income |  | $ | 9,182 |  |  | $ | 49,390 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Provision for income taxes |  |  | 6,372 |  |  |  | 17,464 |  |  |  | 45,236 |  |  |  | 83,749 |  |
| Income before provision for income taxes |  |  | 15,554 |  |  |  | 66,854 |  |  |  | 122,983 |  |  |  | 258,362 |  |
| Amortization of intangible assets |  |  | 6,131 |  |  |  | 5,303 |  |  |  | 23,591 |  |  |  | 21,024 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,061 |  |  |  | 1,770 |  |  |  | 5,429 |  |  |  | 6,615 |  |
| Tradename and goodwill impairment (8) |  |  | 40,687 |  |  | – |  |  |  | 40,687 |  |  | – |  |
| Loss on extinguishment of debt (9) |  | – |  |  |  | 248 |  |  |  | 4,795 |  |  |  | 2,084 |  |
| (Gain) loss on change in contractual interest rate (10) |  | – |  |  | – |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and other purchase accounting adjustments (11) |  |  | 1,228 |  |  |  | 511 |  |  |  | 2,710 |  |  |  | (3,623 | ) |
| Business optimization expenses (12) |  |  | 204 |  |  | – |  |  |  | 1,947 |  |  | – |  |
| Adjusted net income before provision for income taxes |  |  | 64,865 |  |  |  | 74,686 |  |  |  | 204,523 |  |  |  | 268,448 |  |
| Cash income tax expense (13) |  |  | 448 |  |  |  | (6,253 | ) |  |  | (6,087 | ) |  |  | (34,283 | ) |
| Adjusted net income |  | $ | 65,313 |  |  | $ | 68,433 |  |  | $ | 198,436 |  |  | $ | 234,165 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.97 |  |  | $ | 0.98 |  |  | $ | 2.87 |  |  | $ | 3.34 |  |
| Weighted average common shares outstanding - diluted: |  |  | 67,472,321 |  |  |  | 70,170,300 |  |  |  | 69,200,297 |  |  |  | 70,171,044 |  |

[0001437749-16-025339:8k_2_02:98]
| (8) Represents the impairment of certain tradenames due to a new brand strategy to transition and consolidate various brands to the Generac® tradename ($36.1 million) and the impairment of goodwill related to a prior acquisition ($4.6 million). |
| (9) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (10) The amount for the year ended December 31, 2015 represents a non-cash loss relating to a 25 basis point increase in borrowing costs, effective third quarter 2015, as a result of the credit agreement leverage ratio rising above 3.0 times. The amount for the year ended December 31, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (11) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. The year ended December 31, 2014 also includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). |
| (12) Represents severance and other non-recurring restructuring charges. |
| (13) Amounts for the years ended December 31, 2015 and 2014 are based on actual cash income taxes paid during the full year ended 2015 and 2014, respectively, which equates to a cash income tax rate of 4.9% and 13.3%, respectively, for each year. |

[0001437749-16-025339:8k_2_02:99]
| Free Cash Flow Reconciliation |

[0001437749-16-025339:8k_2_02:100]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 111,760 |  |  | $ | 110,475 |  |  | $ | 188,619 |  |  | $ | 252,986 |  |
| Expenditures for property and equipment |  |  | (10,543 | ) |  |  | (11,967 | ) |  |  | (30,651 | ) |  |  | (34,689 | ) |
| Free cash flow |  | $ | 101,217 |  |  | $ | 98,508 |  |  | $ | 157,968 |  |  | $ | 218,297 |  |

[0001437749-16-025339:8k_2_02:101]
10

## item 5.02 — body, verbatim

[0001437749-16-025339:8k_body:1]
Item 5.02. Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001437749-16-025339:8k_body:2]
On February 10, 2016, Timothy J. Walsh advised the Board of Directors of Generac Holdings, Inc. (the “Company”) that he would not stand for reelection at the 2016 Annual Meeting of Shareholders. Mr. Walsh’s decision was not the result of any disagreement with the Company on any matters. In connection with that decision, Mr. Walsh also stepped down as Chairman of the Board effective February 10, 2016. As a result, the Board of Directors has elected Aaron Jagdfeld, the Company’s President and Chief Executive Officer, to serve as Executive Chairman of the Board, also effective February 10, 2016.
