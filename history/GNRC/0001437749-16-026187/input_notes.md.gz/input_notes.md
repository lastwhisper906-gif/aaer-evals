# GNRC notes — 0001437749-16-026187


## gnrc:NetCurrentAndNoncurrentComponentsOfDeferredTaxesTableTextBlock

[0001437749-16-026187:notes:1]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net current deferred tax assets |  | $ | 29,355 |  |  | $ | 22,841 |  |
| Net long-term deferred tax assets |  |  | 8,196 |  |  |  | 47,894 |  |
| Net long-term deferred tax liabilitites |  |  | (6,166 | ) |  |  | (13,449 | ) |
| Valuation allowance |  |  | (1,523 | ) |  |  | (1,385 | ) |
| Net deferred tax assets |  | $ | 29,862 |  |  | $ | 55,901 |  |


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-16-026187:notes:2]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,726 |  |  | $ | 24,143 |  |
| Long-term portion - other long-term liabilities |  |  | 8,471 |  |  |  | 6,766 |  |
| Total |  | $ | 30,197 |  |  | $ | 30,909 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 6,026 |  |  | $ | 4,519 |  |
| Long-term portion - other long-term liabilities |  |  | 22,935 |  |  |  | 22,674 |  |
| Total |  | $ | 28,961 |  |  | $ | 27,193 |  |


## gnrc:PropertyPlantAndEquipmentEstimatedUsefulLivesTableTextBlock

[0001437749-16-026187:notes:3]
| Land improvements | 10 | – | 15 |  |
| Buildings and improvements | 10 | – | 40 |  |
| Machinery and equipment | 5 | – | 20 |  |
| Dies and tools | 3 | – | 10 |  |
| Vehicles | 3 | – | 5 |  |
| Office equipment and systems | 3 | – | 15 |  |
| Leasehold improvements | 7 | – | 20 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-16-026187:notes:4]
|  |  | December 31,2015 |  |  | December 31,2014 |  |
| Commodity contracts |  | $ | (400 | ) |  | $ | (515 | ) |
| Foreign currency contracts |  |  | (171 | ) |  |  | (149 | ) |
| Interest rate swaps |  |  | (2,618 | ) |  |  | (1,045 | ) |


## gnrc:ScheduleOfFairValueOfPlanAssetsTableTextBlock

[0001437749-16-026187:notes:5]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 40,310 |  |  | $ | 40,310 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 3,675 |  |  |  | – |  |  |  | – |  |  |  | 3,675 |  |
| Total |  | $ | 43,985 |  |  | $ | 40,310 |  |  | $ | – |  |  | $ | 3,675 |  |

[0001437749-16-026187:notes:6]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 42,267 |  |  | $ | 42,267 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 3,185 |  |  |  | – |  |  |  | – |  |  |  | 3,185 |  |
| Total |  | $ | 45,452 |  |  | $ | 42,267 |  |  | $ | – |  |  | $ | 3,185 |  |


## gnrc:ScheduleOfIntangibleAssetsTableTextBlock

[0001437749-16-026187:notes:7]
|  |  | Weighted Average |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
|  |  | Amortization Years |  |  | Cost |  |  | Accumulated Amortization |  |  | Amortized Cost |  |  | Cost |  |  | Accumulated Amortization |  |  | Amortized Cost |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 7 |  |  | $ | 43,252 |  |  | $ | (10,516 | ) |  | $ | 32,736 |  |  | $ | 8,775 |  |  | $ | (8,775 | ) |  | $ | - |  |
| Customer lists |  |  | 9 |  |  |  | 314,600 |  |  |  | (275,287 | ) |  |  | 39,313 |  |  |  | 304,180 |  |  |  | (263,178 | ) |  |  | 41,002 |  |
| Patents |  |  | 14 |  |  |  | 126,491 |  |  |  | (72,719 | ) |  |  | 53,772 |  |  |  | 121,341 |  |  |  | (64,447 | ) |  |  | 56,894 |  |
| Unpatented technology |  |  | 15 |  |  |  | 13,169 |  |  |  | (11,628 | ) |  |  | 1,541 |  |  |  | 13,169 |  |  |  | (10,435 | ) |  |  | 2,734 |  |
| Software |  |  | 9 |  |  |  | 1,046 |  |  |  | (1,042 | ) |  |  | 4 |  |  |  | 1,046 |  |  |  | (1,037 | ) |  |  | 9 |  |
| Non-compete/other |  |  | 9 |  |  |  | 1,731 |  |  |  | (508 | ) |  |  | 1,223 |  |  |  | 1,961 |  |  |  | (406 | ) |  |  | 1,555 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 500,289 |  |  | $ | (371,700 | ) |  | $ | 128,589 |  |  | $ | 450,472 |  |  | $ | (348,278 | ) |  | $ | 102,194 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 182,684 |  |  |  | - |  |  |  | 182,684 |  |
| Total intangible assets |  |  |  |  |  | $ | 628,610 |  |  | $ | (371,700 | ) |  | $ | 256,910 |  |  | $ | 633,156 |  |  | $ | (348,278 | ) |  | $ | 284,878 |  |


## gnrc:SpecialCashDividendsTextBlock

[0001437749-16-026187:notes:8]
17.   Special Cash Dividend

[0001437749-16-026187:notes:9]
On June 21, 2013, the Company used a portion of the proceeds from the May 31, 2013 debt refinancing (see Note 10, “Credit Agreements” to the consolidated financial statements) to pay a special cash dividend of $5.00 per share on its common stock, resulting in payments totaling $340,772 to stockholders on that date. Related dividends declared but unpaid as of December 31, 2015 are $76, which relate to dividends earned on unvested restricted stock awards, and are included in other accrued liabilities in the consolidated balance sheet. Payment of these dividends will be made when the underlying restricted stock awards vest. The balance of retained earnings as of the 2013 dividend declaration date was $4,934. As such, the dividends were first charged to retained earnings and dividends in excess of retained earnings were recorded as a reduction to additional paid-in capital.

[0001437749-16-026187:notes:10]
In connection with the special dividend, and pursuant to the terms of the Company’s stock option plan, certain adjustments were made to stock options outstanding under the plan in order to avoid dilution of the intended benefits which would otherwise result as a consequence of the special dividend. As such, the strike price for all outstanding stock options at that time of the dividend was modified by the $5.00 special dividend amount. There was no change to compensation expense as a result of this adjustment.


## gnrc:ValuationAndQualifyingAccountsTableTextBlock

[0001437749-16-026187:notes:11]
|  |  | Balance at Beginning of Year |  |  | Reserves Assumed in Acquisition |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Balance at End of Year |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,275 |  |  | $ | 63 |  |  | $ | 481 |  |  | $ | (325 | ) |  | $ | 2,494 |  |
| Reserves for inventory |  |  | 9,387 |  |  |  | 614 |  |  |  | 3,739 |  |  |  | (3,158 | ) |  |  | 10,582 |  |
| Valuation of deferred tax assets |  |  | 1,385 |  |  |  | - |  |  |  | 138 |  |  |  | – |  |  |  | 1,523 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,658 |  |  | $ | 209 |  |  | $ | 672 |  |  | $ | (1,264 | ) |  | $ | 2,275 |  |
| Reserves for inventory |  |  | 6,558 |  |  |  | 2,282 |  |  |  | 2,797 |  |  |  | (2,250 | ) |  |  | 9,387 |  |
| Valuation of deferred tax assets |  |  | 1,021 |  |  |  | - |  |  |  | 364 |  |  |  | – |  |  |  | 1,385 |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,166 |  |  | $ | 496 |  |  | $ | 1,037 |  |  | $ | (41 | ) |  | $ | 2,658 |  |
| Reserves for inventory |  |  | 6,999 |  |  |  | 1,131 |  |  |  | 72 |  |  |  | (1,644 | ) |  |  | 6,558 |  |
| Valuation of deferred tax assets |  |  | 806 |  |  |  | (120 | ) |  |  | 335 |  |  |  | – |  |  |  | 1,021 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-16-026187:notes:12]
Advertising and Co-Op Advertising

[0001437749-16-026187:notes:13]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Total expenditures for advertising were $39,258, $32,352, and $19,910 for the years ended December 31, 2015, 2014, and 2013, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-16-026187:notes:14]
3

[0001437749-16-026187:notes:15]
.

[0001437749-16-026187:notes:16]
Acquisitions

[0001437749-16-026187:notes:17]
Acquisition of CHP

[0001437749-16-026187:notes:18]
On August 1, 2015, a subsidiary of the Company acquired CHP for a purchase price, net of cash acquired, of $74,570. Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition purchase price was funded solely through cash on hand.

[0001437749-16-026187:notes:19]
The Company recorded a preliminary purchase price allocation during the third quarter of 2015 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $81,726 of intangible assets, including approximately $30,076 of goodwill, as of the acquisition date. The purchase price allocation was updated in the fourth quarter of 2015, resulting in a $6,552 decrease to total intangible assets, including an increase of $6,208 in goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. In addition, the Company assumed $12,000 of debt along with this acquisition. The accompanying consolidated financial statements include the results of CHP from August 1, 2015 through December 31, 2015.

[0001437749-16-026187:notes:20]
Acquisition of MAC

[0001437749-16-026187:notes:21]
On October 1, 2014, a subsidiary of the Company acquired MAC for a purchase price, net of cash acquired, of $55,035. Headquartered in Bismarck, North Dakota, MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition was funded solely through cash on hand.

[0001437749-16-026187:notes:22]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2014 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $49,378 of intangible assets, including approximately $25,898 of goodwill, as of the acquisition date. The purchase price allocation was finalized during the third quarter of 2015, resulting in a $4,229 decrease to total intangible assets, including an increase of $2,481 to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of MAC from October 1, 2014 through December 31, 2015.

[0001437749-16-026187:notes:23]
Acquisition of Tower Light

[0001437749-16-026187:notes:24]
On August 1, 2013, a subsidiary of the Company acquired all of the shares of Tower Light for a purchase price, net of cash acquired and inclusive of estimated earn-out payments, of $85,812. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East, Africa and Asia Pacific. Tower Light has built a leading market position in the equipment rental markets by leveraging its broad product offering and strong global distribution network in over 50 countries worldwide.

[0001437749-16-026187:notes:25]
The net cash paid at closing was $80,239 and included a cash deposit of $6,645 into an escrow account to fund future earn-out payments required by the purchase agreement. The earn-out payment of $7,641 was finalized during the second quarter of 2014, resulting in a gain of $4,877, which was recorded in the consolidated statement of comprehensive income for the year ended December 31, 2014. The acquisition was funded solely by existing cash.

[0001437749-16-026187:notes:26]
The Company recorded a preliminary purchase price allocation during the third quarter of 2013 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $67,900 of intangible assets, including approximately $38,400 of goodwill. The purchase price allocation was finalized during the fourth quarter of 2013, resulting in an increase of $9,328 to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Tower Light from August 1, 2013 through December 31, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-16-026187:notes:27]
| 1. | Description of Business |

[0001437749-16-026187:notes:28]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-026187:notes:29]
The Company has executed a number of acquisitions that support our strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of our Powering Ahead strategic plan). A summary of these acquisitions include the following:

[0001437749-16-026187:notes:30]
|  | ● | On October 3, 2011, the Company acquired substantially all the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-16-026187:notes:31]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-16-026187:notes:32]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East, Africa and Asia Pacific. |

[0001437749-16-026187:notes:33]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

[0001437749-16-026187:notes:34]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

[0001437749-16-026187:notes:35]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-16-026187:notes:36]
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-16-026187:notes:37]
Cash

[0001437749-16-026187:notes:38]
and Cash

[0001437749-16-026187:notes:39]
Equivalents

[0001437749-16-026187:notes:40]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-16-026187:notes:41]
16.   Commitments and Contingencies

[0001437749-16-026187:notes:42]
The Company leases certain manufacturing facilities, computer equipment, automobiles and warehouse space under operating leases. The approximate aggregate minimum rental commitments at December 31, 2015, are as follows:

[0001437749-16-026187:notes:43]
| Year |  | Amount |  |
| 2016 |  | $ | 3,561 |  |
| 2017 |  |  | 3,072 |  |
| 2018 |  |  | 3,033 |  |
| 2019 |  |  | 2,153 |  |
| 2020 |  |  | 1,809 |  |
| After 2020 |  |  | 5,489 |  |
| Total |  | $ | 19,117 |  |

[0001437749-16-026187:notes:44]
Total rent expense for the years ended December 31, 2015, 2014 and 2013, was approximately $4,796, $4,102, and $2,457, respectively.

[0001437749-16-026187:notes:45]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at December 31, 2015 and 2014 was approximately $32,400 and $26,100, respectively.

[0001437749-16-026187:notes:46]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-026187:notes:47]
5.     Accumulated Other Comprehensive Loss

[0001437749-16-026187:notes:48]
The following presents a tabular disclosure of changes in AOCL during the years ended December 31, 2015 and 2014, net of tax:

[0001437749-16-026187:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (7,624 | ) |  |  | 1,105 | (1) |  |  | (965 | )(2) |  |  | (7,484 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 776 | (3) |  |  | - |  |  |  | 776 |  |
| Net current-period other comprehensive income (loss) |  |  | (7,624 | ) |  |  | 1,881 |  |  |  | (965 | ) |  |  | (6,708 | ) |
| Ending Balance – December 31, 2015 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |

[0001437749-16-026187:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (3,082 | ) |  |  | (8,922 | )(4) |  |  | (1,420 | )(5) |  |  | (13,424 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 72 | (6) |  |  | - |  |  |  | 72 |  |
| Net current-period other comprehensive loss |  |  | (3,082 | ) |  |  | (8,850 | ) |  |  | (1,420 | ) |  |  | (13,352 | ) |
| Ending Balance – December 31, 2014 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |

[0001437749-16-026187:notes:51]
|  | (1) | Represents unrecognized actuarial gains of $1,829, net of tax effect of $(724), included in the computation of net periodic pension cost for the year ended December 31, 2015. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-16-026187:notes:52]
|  | (2) | Represents unrealized losses of $(1,574), net of tax benefit of $609 for the year ended December 31, 2015. |

[0001437749-16-026187:notes:53]
|  | (3) | Represents actuarial losses of $1,228, net of tax effect of $(452), amortized to net periodic pension cost for the year ended December 31, 2015. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-16-026187:notes:54]
|  | (4) | Represents unrecognized actuarial losses of $(14,614), net of tax benefit of $5,692, included in the computation of net periodic pension cost for the year ended December 31, 2014. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-16-026187:notes:55]
|  | (5) | Represents unrealized losses of $(2,279), net of tax benefit of $859 for the year ended December 31, 2014. |

[0001437749-16-026187:notes:56]
|  | (6) | Represents actuarial losses of $106, net of tax effect of $(34), amortized to net periodic pension cost for the year ended December 31, 2014. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |


## us-gaap:ConsolidationPolicyTextBlock

[0001437749-16-026187:notes:57]
Principles of Consolidation

[0001437749-16-026187:notes:58]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-026187:notes:59]
10.   Credit Agreements

[0001437749-16-026187:notes:60]
Short-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-16-026187:notes:61]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 8,594 |  |  |  | 5,359 |  |
| Total |  | $ | 8,594 |  |  | $ | 5,359 |  |

[0001437749-16-026187:notes:62]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-16-026187:notes:63]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (16,940 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,694 |  |  |  | 2,059 |  |
| Other |  |  | 12,000 |  |  |  | 460 |  |
| Total |  |  | 1,050,754 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 500 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 157 |  |  |  | 168 |  |
| Total |  | $ | 1,050,097 |  |  | $ | 1,082,101 |  |

[0001437749-16-026187:notes:64]
Maturities of long-term borrowings outstanding at December 31, 2015, are as follows:

[0001437749-16-026187:notes:65]
| Year |  |  |  |  |
| 2016 |  | $ | 657 |  |
| 2017 |  |  | 11,666 |  |
| 2018 |  |  | 172 |  |
| 2019 |  |  | 177 |  |
| After 2019 |  |  | 1,055,022 |  |
| Total |  | $ | 1,067,694 |  |

[0001437749-16-026187:notes:66]
On May 31, 2013, the Company amended and restated its then existing term loan credit agreement (Previous Term Loan) by entering into a new term loan credit agreement (Term Loan) with certain commercial banks and other lenders. The Term Loan provides for a $1,200,000 term loan B credit facility and includes a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. Proceeds from the Term Loan were used to repay amounts outstanding under the Company’s Previous Term Loan and to fund a special cash dividend of $5.00 per share on the Company’s common stock (See Note 17, “Special Cash Dividend” to the consolidated financial statements for additional details). Remaining funds from the Term Loan were used for general corporate purposes and to pay related financing fees and expenses. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50% to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

[0001437749-16-026187:notes:67]
Because the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs in the second quarter of 2014. As a result, the Company recorded a catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan, as the Company projected the net debt leverage ratio to remain below 3.00 to 1.00. The gain was recorded as original issue discount on long-term borrowings in the consolidated balance sheets.

[0001437749-16-026187:notes:68]
Because the Company’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is forecasted to be above 3.00 to 1.00. The loss was recorded against original issue discount on long-term borrowings in the consolidated balance sheets. The Company’s net debt leverage ratio as of December 31, 2015 was above 3.00 to 1.00.

[0001437749-16-026187:notes:69]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of December 31, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-026187:notes:70]
Concurrent with the closing of the Term Loan on May 31, 2013, the Company amended its then existing ABL credit agreement. The amendment provides for a one year extension of the maturity date on the $150,000 senior secured ABL revolving credit facility (ABL Facility). The extended maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-16-026187:notes:71]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $540 of new debt issuance costs in 2015.

[0001437749-16-026187:notes:72]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of December 31, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

[0001437749-16-026187:notes:73]
On February 11 and May 2, 2013, the Company made voluntary prepayments of the Previous Term Loan of $80,000 and $30,000, respectively, with available cash on hand that was applied to future principal amortizations on the Previous Term Loan. As a result of the prepayments, the Company wrote off $2,763 of original issue discount and capitalized debt issuance costs during the year ended December 31, 2013 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-16-026187:notes:74]
In connection with the May 31, 2013 refinancing, the Company capitalized $21,824 of new debt issuance costs, recorded $13,797 of fees paid to creditors as original issue discount, expensed $7,100 of transaction fees and wrote-off $5,473 of unamortized debt issuance costs and original issue discount relating to the Previous Term Loan and ABL credit agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the consolidated statement of comprehensive income for the year ended December 31, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its loans under the catch-up approach of the effective interest method.

[0001437749-16-026187:notes:75]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs during the year ended December 31, 2014 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-16-026187:notes:76]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs during the year ended December 31, 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-16-026187:notes:77]
As of December 31, 2015 and December 31, 2014, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $8,594 and $5,359, respectively.


## us-gaap:DebtPolicyTextBlock

[0001437749-16-026187:notes:78]
Debt Issuance Costs

[0001437749-16-026187:notes:79]
Direct and incremental costs incurred in connection with the issuance of long-term debt are capitalized as deferred financing costs and amortized to interest expense over the terms of the related credit agreements. Debt discounts incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. Approximately $5,429, $6,615, and $4,772 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2015, 2014 and 2013, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization expense for the next five years is as follows: 2016 - $5,355; 2017 - $6,783; 2018 - $7,048; 2019 - $7,323; 2020 - $3,134.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-16-026187:notes:80]
4.     Derivative Instruments and Hedging Activities

[0001437749-16-026187:notes:81]
Commodities

[0001437749-16-026187:notes:82]
The Company is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than eighteen months. At December 31, 2015 and 2014, the Company had one and three commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-16-026187:notes:83]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net losses recognized were $1,909, $629 and $605 for the years ended December 31, 2015, 2014, and 2013, respectively.

[0001437749-16-026187:notes:84]
Foreign Currencies

[0001437749-16-026187:notes:85]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of December 31, 2015 and 2014, the Company had six foreign currency contracts outstanding.

[0001437749-16-026187:notes:86]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net losses recognized for the years ended December 31, 2015, 2014 and 2013 were $624, $149 and $56, respectively.

[0001437749-16-026187:notes:87]
Interest Rate Swaps

[0001437749-16-026187:notes:88]
As of May 30, 2012, the Company had four interest rate swap agreements outstanding. Due to the incorporation of a new interest rate floor provision in the then new credit agreement, which constituted a change in critical terms, the Company concluded that as of May 30, 2012, the then outstanding swaps would no longer be highly effective in achieving offsetting changes in cash flows during the periods the hedges were designated. As a result, the Company was required to de-designate the four outstanding hedges as of May 30, 2012. Beginning May 31, 2012, the effective portion of the swaps prior to the change (i.e. amounts previously recorded in Accumulated Other Comprehensive Loss (AOCL)) were amortized into interest expense over the period of the originally designated hedged transactions which had various termination dates through October 2013. The amount reclassified from AOCL to interest expense on the consolidated statement of comprehensive income for the year ended December 31, 2013 was a loss of $2,381. Future changes in fair value of these swaps were immediately recognized in the consolidated statements of comprehensive income as interest expense, which was a gain of $2,973 for the year ended December 31, 2013.

[0001437749-16-026187:notes:89]
On October 23, 2013, the Company entered into two interest rate swap agreements, and on May 19, 2014, the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of AOCL. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-16-026187:notes:90]
Fair Value

[0001437749-16-026187:notes:91]
The following table presents the fair value of the Company’s derivatives:

[0001437749-16-026187:notes:92]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other long-term liabilities in the consolidated balance sheets as of December 31, 2015 and 2014. Excluding the impact of credit risk, the fair value of the derivative contracts as of December 31, 2015 and 2014 is a liability of $3,248 and $1,727, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-16-026187:notes:93]
The amount of gains (losses) recognized in AOCL in the consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the years ended December 31, 2015, 2014 and 2013 were $(965), $(1,420) and $774, respectively. The amount of losses recognized in cost of goods sold in the consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the years ended December 31, 2015, 2014 and 2013 were $2,533, $778 and $661, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001437749-16-026187:notes:94]
Derivative Instruments and Hedging Activities

[0001437749-16-026187:notes:95]
The Company records all derivatives in accordance with ASC 815, 
Derivatives and Hedging
, which requires derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-16-026187:notes:96]
1

[0001437749-16-026187:notes:97]
5

[0001437749-16-026187:notes:98]
.   Share Plans

[0001437749-16-026187:notes:99]
The Company adopted an equity incentive plan (Plan) on February 10, 2010 in connection with its initial public offering. The Plan, as amended, allows for granting of up to 9.1 million stock-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other stock-based awards, and performance-based compensation awards. Total share-based compensation expense related to the Plan was $8,241, $12,612 and $12,368 for the years ended December 31, 2015, 2014 and 2013, respectively, net of estimated forfeitures, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-16-026187:notes:100]
Stock Options

[0001437749-16-026187:notes:101]
- Stock options granted in 2015 have an exercise price between $28.36 per share and $49.70 per share; stock options granted in 2014 have an exercise price between $42.20 per share and $59.01 per share, and the stock options granted in 2013 have an exercise price between $29.81 per share and $48.36 per share.

[0001437749-16-026187:notes:102]
On June 21, 2013, the Company paid a special cash dividend of $5.00 per share on its common stock. In connection with this special dividend, and pursuant to the terms of the Company’s Plan, certain adjustments were made to stock options outstanding in order to avoid dilution of the intended benefits which would otherwise result as a consequence of the special dividend. As such, the strike price for all outstanding stock options as of the special dividend date, were adjusted by the $5.00 special dividend amount. There was no change to compensation expense as a result of this adjustment. Stock options issued in 2012 - 2015 vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant. Stock options issued in 2011 and 2010 vest in equal installments over five years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-16-026187:notes:103]
Stock option exercises are net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 272,296, 235,644 and 323,427 in 2015, 2014 and 2013, respectively, and were based on the value of the stock on the exercise dates as determined based upon an average of the Company’s high and low stock sales price on the exercise dates. Total payments for the employees’ tax obligations to the taxing authorities were $9,768, $10,411 and $8,449 in 2015, 2014 and 2013, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-16-026187:notes:104]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs.

[0001437749-16-026187:notes:105]
Expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history. The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2015, 2014 and 2013 are as follows:

[0001437749-16-026187:notes:106]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Weighted average grant date fair value |  | $ | 19.07 |  |  | $ | 26.35 |  |  | $ | 16.30 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 41 | % |  |  | 45 | % |  |  | 47 | % |
| Risk free interest rate |  |  | 1.72 | % |  |  | 1.90 | % |  |  | 1.21 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-16-026187:notes:107]
The Company periodically evaluates its forfeiture rates and updates the rates it uses in the determination of its stock-based compensation expense. The impact of the change to the forfeiture rates on non-cash compensation expense was immaterial for the years ended December 31, 2015, 2014 and 2013.

[0001437749-16-026187:notes:108]
A summary of the Company’s stock option activity and related information for the years ended December 31, 2015, 2014 and 2013 is as follows:

[0001437749-16-026187:notes:109]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2012 |  |  | 3,440,042 |  |  | $ | 8.44 |  |  |  | 9.5 |  |  | $ | 87,001 |  |
| Granted |  |  | 253,857 |  |  |  | 35.04 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (703,326 | ) |  |  | 6.05 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (1,625 | ) |  |  | 20.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (51,647 | ) |  |  | 17.02 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2013 |  |  | 2,937,301 |  |  |  | 5.74 |  |  |  | 9.5 |  |  | $ | 148,369 |  |
| Granted |  |  | 187,189 |  |  |  | 57.21 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (549,282 | ) |  |  | 3.44 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (259 | ) |  |  | 15.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (32,810 | ) |  |  | 12.68 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2014 |  |  | 2,542,139 |  |  |  | 9.94 |  |  |  | 8.5 |  |  | $ | 96,518 |  |
| Granted |  |  | 287,165 |  |  |  | 45.18 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (604,088 | ) |  |  | 3.79 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (6,409 | ) |  |  | 50.11 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (90,793 | ) |  |  | 37.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2015 |  |  | 2,128,014 |  |  |  | 15.15 |  |  |  | 7.7 |  |  | $ | 40,271 |  |
| Exercisable as of December 31, 2015 |  |  | 1,574,790 |  |  |  | 6.08 |  |  |  | 7.5 |  |  | $ | 39,072 |  |

[0001437749-16-026187:notes:110]
As of December 31, 2015, there was $7,342 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.5 years. Total share-based compensation cost related to the stock options for 2015, 2014 and 2013 was $4,198, $8,509 and $9,034, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-16-026187:notes:111]
Restricted Stock

[0001437749-16-026187:notes:112]
– Restricted stock awards issued in 2012 and after, vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, which were awarded in 2014 and 2015. The number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of revenue growth and EBITDA margin, from which grantees may earn from 0% to 200% of their target performance share award. The performance period for the 2014 awards covers the years 2014 through 2016, and the performance period for the 2015 awards covers the years 2015 through 2017. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-16-026187:notes:113]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes, and then pays those taxes on behalf of the employee. In effect, the Company repurchases these shares and classifies as treasury stock, and pays the cash to the taxing authorities on behalf of the employees to satisfy the tax withholding requirements. Total shares withheld were 65,763, 34,854 and 163,458 in 2015, 2014 and 2013, respectively, and were based on the value of the stock on the vesting dates as determined based upon an average of the Company’s high and low stock sales price on the vesting dates. Total payments for the employees’ tax obligations to the taxing authorities were $3,233, $1,770 and $6,571 in 2015, 2014 and 2013, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-16-026187:notes:114]
A summary of the Company's restricted stock activity for the years ended December 31, 2015, 2014 and 2013 is as follows:

[0001437749-16-026187:notes:115]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2012 |  |  | 665,071 |  |  | $ | 17.75 |  |
| Granted |  |  | 112,494 |  |  |  | 37.82 |  |
| Vested |  |  | (450,537 | ) |  |  | 14.21 |  |
| Forfeited |  |  | (22,622 | ) |  |  | 25.36 |  |
| Non-vested as of December 31, 2013 |  |  | 304,406 |  |  |  | 29.68 |  |
| Granted |  |  | 115,473 |  |  |  | 54.35 |  |
| Vested |  |  | (105,123 | ) |  |  | 28.31 |  |
| Forfeited |  |  | (47,472 | ) |  |  | 42.31 |  |
| Non-vested as of December 31, 2014 |  |  | 267,284 |  |  |  | 38.72 |  |
| Granted |  |  | 193,117 |  |  |  | 41.31 |  |
| Vested |  |  | (183,362 | ) |  |  | 32.56 |  |
| Forfeited |  |  | (33,999 | ) |  |  | 47.77 |  |
| Non-vested as of December 31, 2015 |  |  | 243,040 |  |  |  | 44.16 |  |

[0001437749-16-026187:notes:116]
As of December 31, 2015, there was $6,723 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.0 years.

[0001437749-16-026187:notes:117]
Total share-based compensation cost related to the restricted stock for 2015, 2014 and 2013 was $4,043, $4,103 and $3,074, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-16-026187:notes:118]
During 2015, 2014 and 2013, 16,260, 8,869 and 7,291 shares, respectively, of fully vested stock were granted to certain members of the Company’s board of directors as a component of their compensation for their service on the board. Total compensation cost for these share grants in 2015, 2014 and 2013 was $615, $509 and $260, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-026187:notes:119]
12

[0001437749-16-026187:notes:120]
.   Earnings Per Share

[0001437749-16-026187:notes:121]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, dilutive earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-16-026187:notes:122]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net income (numerator) |  | $ | 77,747 |  |  | $ | 174,613 |  |  | $ | 174,539 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,096,051 |  |  |  | 68,538,248 |  |  |  | 68,081,632 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,104,246 |  |  |  | 1,632,796 |  |  |  | 1,585,897 |  |
| Diluted |  |  | 69,200,297 |  |  |  | 70,171,044 |  |  |  | 69,667,529 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.14 |  |  | $ | 2.55 |  |  | $ | 2.56 |  |
| Diluted |  | $ | 1.12 |  |  | $ | 2.49 |  |  | $ | 2.51 |  |

[0001437749-16-026187:notes:123]
(1) Excludes approximately 161,400, 81,600 and 10,300 stock options for the years ended December 31, 2015, 2014 and 2013, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 1,000 shares of restricted stock for the year ended December 31, 2015, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001437749-16-026187:notes:124]
|  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 3,185 |  |  | $ | – |  |
| Purchases |  |  | 408 |  |  |  | 3,100 |  |
| Realized gains |  |  | 82 |  |  |  | 85 |  |
| Balance at end of period |  | $ | 3,675 |  |  | $ | 3,185 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-16-026187:notes:125]
Foreign Currency Translation and Transactions

[0001437749-16-026187:notes:126]
Balance sheet amounts for non-U.S. Dollar functional currency businesses are translated into dollars at the rates of exchange in effect at fiscal year-end. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-16-026187:notes:127]
8.     Goodwill and Intangible Assets

[0001437749-16-026187:notes:128]
The changes in the carrying amount of goodwill for the years ended December 31, 2015 and 2014 are as follows:

[0001437749-16-026187:notes:129]
|  |  | Year Ended December 31, 2015 |  |  | Year Ended December 31, 2014 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Balance at beginning of year |  | $ | 1,138,758 |  |  | $ | (503,193 | ) |  | $ | 635,565 |  |  | $ | 1,111,480 |  |  | $ | (503,193 | ) |  | $ | 608,287 |  |
| Acquisitions of businesses, net |  |  | 38,765 |  |  |  | - |  |  | $ | 38,765 |  |  |  | 27,278 |  |  |  | - |  |  | $ | 27,278 |  |
| Impairment |  |  | - |  |  |  | (4,611 | ) |  |  | (4,611 | ) |  |  | - |  |  |  | - |  |  |  | - |  |
| Balance at end of year |  | $ | 1,177,523 |  |  | $ | (507,804 | ) |  | $ | 669,719 |  |  | $ | 1,138,758 |  |  | $ | (503,193 | ) |  | $ | 635,565 |  |

[0001437749-16-026187:notes:130]
See Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions and Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 2015 goodwill impairment charge.

[0001437749-16-026187:notes:131]
The following table summarizes intangible assets by major category as of December 31, 2015 and 2014:

[0001437749-16-026187:notes:132]
See Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 2015 brand strategy change and resulting tradename impairment charge.

[0001437749-16-026187:notes:133]
Amortization of intangible assets was $23,591, $21,024 and $25,819 in 2015, 2014 and 2013, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2016 - $29,184; 2017 - $25,832; 2018 - $15,535; 2019 - $13,835; 2020 - $13,762.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001437749-16-026187:notes:134]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-16-026187:notes:135]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value may not be recoverable. The Company has the option to assess goodwill for impairment by first performing a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then further goodwill impairment testing is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform a two-step goodwill impairment test. In the first step, the fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired and no further analysis is necessary. If the fair value of the reporting unit is less than its book value, there is an indication of potential impairment and a second step is performed. When required, the second step of testing involves calculating the implied fair value of goodwill for the reporting unit. The implied fair value of goodwill is determined in the same manner as goodwill recognized in a business combination, which is the excess of the fair value of the reporting unit determined in step one over the fair value of its net assets and identifiable intangible assets as if the reporting unit had been acquired. If the carrying value of the reporting unit's goodwill exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. For reporting units with a negative book value (i.e., excess of liabilities over assets), qualitative factors are evaluated to determine whether it is necessary to perform the second step of the goodwill impairment test.

[0001437749-16-026187:notes:136]
The Company performed the required annual impairment tests for goodwill as of October 31, 2015, and determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge in the fourth quarter of 2015 of $4,611 to write-down the balance of the Ottomotores goodwill. The decrease in fair value of the Ottomotores reporting unit was due to several factors in the second half of 2015: the continued challenges of the Latin American economies, devaluation of the Peso against the US Dollar, the slow development of Mexican energy reform as a result of decreasing oil prices; combining to cause 2015 results to fall short of prior expectations and future forecasts to decrease. The fair value was determined using a discounted cash flow analysis, which utilized key financial assumptions including the sales growth factors discussed above, a 3% terminal growth rate and a 15.7% discount rate. There were no other reporting units with a carrying value at-risk of exceeding fair value as of the October 31, 2015 impairment test date.

[0001437749-16-026187:notes:137]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company. The Company conducts its annual impairment test for indefinite-lived intangible assets as of October 31 of each year.

[0001437749-16-026187:notes:138]
In the fourth quarter of 2015, the Company’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired in acquisitions over the past several years to the Generac® tradename. This brand strategy change resulted in a reclassification to a two year remaining useful life for the impacted tradenames causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a $36,076 non-cash impairment charge was recorded to write-down the impacted tradenames to net realizable value.

[0001437749-16-026187:notes:139]
Other than the impairment charges discussed above, the Company found no other impairment when performing the required annual impairment tests for goodwill and other indefinite-lived intangible assets for fiscal years 2015, 2014 and 2013. There can be no assurance that future impairment tests will not result in a charge to earnings.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001437749-16-026187:notes:140]
Impairment of

[0001437749-16-026187:notes:141]
Long-Lived Assets

[0001437749-16-026187:notes:142]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-026187:notes:143]
13.   Income Taxes

[0001437749-16-026187:notes:144]
The Company’s provision for income taxes consists of the following:

[0001437749-16-026187:notes:145]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 13,614 |  |  | $ | 38,161 |  |  | $ | 48,287 |  |
| State |  |  | 1,966 |  |  |  | 1,645 |  |  |  | 5,648 |  |
| Foreign |  |  | 3,588 |  |  |  | 5,701 |  |  |  | 2,214 |  |
|  |  |  | 19,168 |  |  |  | 45,507 |  |  |  | 56,149 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 31,869 |  |  | $ | 42,474 |  |  | $ | 42,003 |  |
| State |  |  | 1,387 |  |  |  | (3,134 | ) |  |  | 5,523 |  |
| Foreign |  |  | (7,326 | ) |  |  | (1,462 | ) |  |  | 167 |  |
|  |  |  | 25,930 |  |  |  | 37,878 |  |  |  | 47,693 |  |
| Change in valuation allowance |  |  | 138 |  |  |  | 364 |  |  |  | 335 |  |
| Provision for income taxes |  | $ | 45,236 |  |  | $ | 83,749 |  |  | $ | 104,177 |  |

[0001437749-16-026187:notes:146]
During 2015, the Internal Revenue Service completed field work on income tax audits for the 2012 and 2013 tax years. A final audit report was issued and resulted in no change to the Company’s provision for income taxes. As of December 31, 2015, due to the carryforward of net operating losses, and research and development credits, the Company is open to U.S. federal and state income tax examinations for the tax years 2006 through 2014. In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 2010 through 2015.

[0001437749-16-026187:notes:147]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-16-026187:notes:148]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  | $ | - |  |  | $ | 23,624 |  |
| Accrued expenses |  |  | 18,982 |  |  |  | 18,191 |  |
| Deferred revenue |  |  | 9,389 |  |  |  | 7,945 |  |
| Inventories |  |  | 9,772 |  |  |  | 9,177 |  |
| Pension obligations |  |  | 7,684 |  |  |  | 8,738 |  |
| Stock-based compensation |  |  | 7,974 |  |  |  | 8,628 |  |
| Operating loss and credit carryforwards |  |  | 15,677 |  |  |  | 10,047 |  |
| Other |  |  | 2,842 |  |  |  | 1,428 |  |
| Valuation allowance |  |  | (1,523 | ) |  |  | (1,385 | ) |
| Total deferred tax assets |  |  | 70,797 |  |  |  | 86,393 |  |
| Deferred tax liabilitites: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 12,455 |  |  |  | - |  |
| Depreciation |  |  | 19,507 |  |  |  | 18,535 |  |
| Debt refinancing costs |  |  | 7,732 |  |  |  | 10,925 |  |
| Prepaid expenses |  |  | 1,241 |  |  |  | 1,032 |  |
| Total deferred tax liabilities |  |  | 40,935 |  |  |  | 30,492 |  |
| Net deferred tax assets |  | $ | 29,862 |  |  | $ | 55,901 |  |

[0001437749-16-026187:notes:149]
The net current and noncurrent components of deferred taxes included in the consolidated balance sheets are as follows:

[0001437749-16-026187:notes:150]
Generac Brazil, acquired as part of the Ottomotores acquisition, has generated net operating losses for multiple years as part of the start-up of the business. The realizability of the deferred tax assets associated with these net operating losses is uncertain so a valuation allowance was recorded in the opening balance sheet as of December 8, 2012 and continued through December 31, 2015.

[0001437749-16-026187:notes:151]
At December 31, 2015, the Company had state research and development credit, and state manufacturing credit carryforwards of approximately $16,275 and $3,132, respectively, which expire between 2017 and 2030.

[0001437749-16-026187:notes:152]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-16-026187:notes:153]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 6,394 |  |  | $ | - |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 845 |  |  |  | 6,394 |  |
| Unrecognized tax benefit, end of period |  | $ | 7,239 |  |  | $ | 6,394 |  |

[0001437749-16-026187:notes:154]
The entire unrecognized tax benefit as of December 31, 2015 and 2014, if recognized, would impact the effective tax rate.

[0001437749-16-026187:notes:155]
Interest and penalties are recorded as a component of income tax expense. As of December 31, 2015 and 2014, total interest of approximately $174 and $86, respectively, and penalties of approximately $363 and $263, respectively, associated with net unrecognized tax benefits are included in the Company’s consolidated balance sheets. There were no interest or penalties related to income taxes that had been accrued or recognized as of and for the year ended December 31, 2013.

[0001437749-16-026187:notes:156]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending December 31, 2016.

[0001437749-16-026187:notes:157]
The Company considers the earnings of certain non-U.S. subsidiaries to be indefinitely invested outside the United States on the basis of estimates that future domestic cash generation will be sufficient to meet future domestic cash needs and the Company’s specific plans for reinvestment of those subsidiary earnings. The Company has not provided for additional U.S. income taxes on approximately $11,430 of undistributed earnings of consolidated non-U.S. subsidiaries. It is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on such earnings.

[0001437749-16-026187:notes:158]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended December 31, 2015, 2014 and 2013 are as follows:

[0001437749-16-026187:notes:159]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| U.S. stautory rate |  |  | 35.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 4.1 |  |  |  | 3.1 |  |  |  | 3.7 |  |
| Valuation allowance |  |  | 0.6 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Research and development credits |  |  | (2.3 | ) |  |  | (5.0 | ) |  |  | (0.6 | ) |
| Other |  |  | (0.6 | ) |  |  | (0.9 | ) |  |  | (0.9 | ) |
| Effective tax rate |  |  | 36.8 | % |  |  | 32.4 | % |  |  | 37.4 | % |


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-16-026187:notes:160]
Income Taxes

[0001437749-16-026187:notes:161]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.


## us-gaap:InventoryPolicyTextBlock

[0001437749-16-026187:notes:162]
Inventories

[0001437749-16-026187:notes:163]
Inventories are stated at the lower of cost or market, with cost determined generally using the first-in, first-out method.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-16-026187:notes:164]
New Accounting Pronouncements

[0001437749-16-026187:notes:165]
In May 2014, the FASB issued ASU 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-16-026187:notes:166]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

[0001437749-16-026187:notes:167]
In September 2015, the FASB issued ASU 2015-16, 
Business Combinations: Simplifying

[0001437749-16-026187:notes:168]
the Accounting for Measurement

[0001437749-16-026187:notes:169]
Period Adjustments
. This guidance eliminates the requirement for an acquirer to recognize measurement period adjustments retrospectively; rather an acquirer will recognize a measurement period adjustment during the period in which it determines the amount of the adjustment. The guidance should be applied on a prospective basis, and is effective for the Company in 2016, with early adoption permitted. The Company has early adopted this guidance in the current year; however, there is no impact on the Company’s results of operations for year ended December 31, 2015 as there were no material measurement period adjustments.

[0001437749-16-026187:notes:170]
In November 2015, the FASB issued ASU 2015-17, 
I

[0001437749-16-026187:notes:171]
ncome Taxes: Balance Sheet Classification of Deferred Taxes
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated balance sheets. The guidance may be applied on either a prospective or a retrospective basis, and is effective for the Company in 2017. The Company expects that this guidance will only affect classification and presentation of deferred tax liabilities and assets on its balance sheets and will have no impact on its results of operations.

[0001437749-16-026187:notes:172]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-16-026187:notes:173]
14.   Benefit Plans

[0001437749-16-026187:notes:174]
Medical and Dental Plan

[0001437749-16-026187:notes:175]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. Certain plans are partially or fully self-funded plans under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $14,352, $11,701, and $9,500 for the years ended December 31, 2015, 2014, and 2013, respectively. During 2015, the Company paid premiums of $3,400 for other standard medical benefits covering certain full-time employees.

[0001437749-16-026187:notes:176]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-16-026187:notes:177]
Savings Plan

[0001437749-16-026187:notes:178]
The Company maintains defined-contribution 401(k) savings plans for eligible domestic employees. Under the plans, employees may defer receipt of a portion of their eligible compensation. The Company amended the 401(k) savings plans effective January 1, 2009, to add Company matching and non-elective contributions. The Company may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees. The Company may also contribute a non-elective contribution for eligible employees employed on December 31, 2008. Both Company matching contributions and non-elective contributions are subject to vesting. Forfeitures may be applied against plan expenses and company contributions. The Company recognized $3,000, $3,400 and $3,300 of expense related to this plan in 2015, 2014 and 2013, respectively.

[0001437749-16-026187:notes:179]
Pension Plans

[0001437749-16-026187:notes:180]
The Company has frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The benefits under the salaried plan are based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan are based on a unit amount at the date of termination multiplied by the participant’s years of credited service. The Company’s funding policy for the Pension Plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations.

[0001437749-16-026187:notes:181]
The Company uses a December 31 measurement date for the Pension Plans. The table that includes the accumulated benefit obligation and reconciliation of the changes in projected benefit obligation, changes in plan assets and the funded status of the Pension Plans is as follows:

[0001437749-16-026187:notes:182]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Accumulated benefit obligation at end of period |  | $ | 63,894 |  |  | $ | 68,376 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 68,376 |  |  | $ | 52,825 |  |
| Interest cost |  |  | 2,681 |  |  |  | 2,591 |  |
| Net actuarial loss (gain) |  |  | (5,254 | ) |  |  | 14,791 |  |
| Benefits paid |  |  | (1,909 | ) |  |  | (1,831 | ) |
| Projected benefit obligation at end of period |  | $ | 63,894 |  |  | $ | 68,376 |  |
| Change in plan assets |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 45,452 |  |  | $ | 42,440 |  |
| Actual return (loss) on plan assets |  |  | (384 | ) |  |  | 3,110 |  |
| Company contributions |  |  | 826 |  |  |  | 1,733 |  |
| Benefits paid |  |  | (1,909 | ) |  |  | (1,831 | ) |
| Fair value of plan assets at end of period |  | $ | 43,985 |  |  | $ | 45,452 |  |
| Funded status: accrued pension liability included in other long-term liabilities |  | $ | (19,909 | ) |  | $ | (22,924 | ) |
| Amounts recognized in accumulated other comprehensive loss |  |  |  |  |  |  |  |  |
| Net actuarial loss |  | $ | (11,362 | ) |  | $ | (13,243 | ) |

[0001437749-16-026187:notes:183]
The actuarial loss for the Pension Plans that was amortized from AOCL into net periodic (benefit) cost during 2015 is $1,228. The amount in AOCL as of December 31, 2015 that is expected to be recognized as a component of net periodic pension expense during the next fiscal year is $941.

[0001437749-16-026187:notes:184]
The components of net periodic pension (benefit) cost are as follows:

[0001437749-16-026187:notes:185]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Components of net periodic pension (benefit) cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 2,681 |  |  | $ | 2,591 |  |  | $ | 2,423 |  |
| Expected return on plan assets |  |  | (3,041 | ) |  |  | (2,933 | ) |  |  | (2,520 | ) |
| Amortization of net loss |  |  | 1,228 |  |  |  | 106 |  |  |  | 1,108 |  |
| Net periodic pension (benefit) cost |  | $ | 868 |  |  | $ | (236 | ) |  | $ | 1,011 |  |

[0001437749-16-026187:notes:186]
Weighted-average assumptions used to determine the benefit obligations are as follows:

[0001437749-16-026187:notes:187]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Discount rate – salaried pension plan |  |  | 4.36 | % |  |  | 3.97 | % |
| Discount rate – hourly pension plan |  |  | 4.39 | % |  |  | 3.99 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |

[0001437749-16-026187:notes:188]
|  | (1) | No compensation increase was assumed as the plans were frozen effective December 31, 2008. |

[0001437749-16-026187:notes:189]
Weighted-average assumptions used to determine net periodic pension (benefit) cost are as follows:

[0001437749-16-026187:notes:190]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Discount rate |  |  | 3.99 | % |  |  | 5.01 | % |  |  | 4.14 | % |
| Expected long-term rate of return on plan assets |  |  | 6.75 | % |  |  | 6.88 | % |  |  | 6.95 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |

[0001437749-16-026187:notes:191]
To determine the long-term rate of return assumption for plan assets, the Company studies historical markets and preserves the long-term historical relationships between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluates current market factors such as inflation and interest rates before it determines long-term capital market assumptions and reviews peer data and historical returns to check for reasonableness and appropriateness.

[0001437749-16-026187:notes:192]
The Pension Plan’s weighted-average asset allocation at December 31, 2015 and 2014, by asset category, is as follows:

[0001437749-16-026187:notes:193]
|  |  |  |  |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Asset Category |  | Target |  |  | Dollars |  |  | % |  |  | Dollars |  |  | % |  |
| Fixed Income |  |  | 20% |  |  | $ | 8,571 |  |  |  | 19 | % |  | $ | 7,400 |  |  |  | 16 | % |
| Domestic equity |  |  | 49% |  |  |  | 20,479 |  |  |  | 47 | % |  |  | 24,373 |  |  |  | 54 | % |
| International equity |  |  | 21% |  |  |  | 9,687 |  |  |  | 22 | % |  |  | 8,869 |  |  |  | 19 | % |
| Real estate |  |  | 10% |  |  |  | 5,248 |  |  |  | 12 | % |  |  | 4,810 |  |  |  | 11 | % |
| Total |  |  | 100% |  |  | $ | 43,985 |  |  |  | 100 | % |  | $ | 45,452 |  |  |  | 100 | % |

[0001437749-16-026187:notes:194]
The fair values of the Pension Plans’ assets at December 31, 2015 are as follows:

[0001437749-16-026187:notes:195]
The fair values of the Pension Plan's assets at December 31, 2014 are as follows:

[0001437749-16-026187:notes:196]
A reconciliation of beginning and ending balances for Level 3 assets for the years ended December 31, 2015 and 2014 is as follows:

[0001437749-16-026187:notes:197]
Mutual Funds

[0001437749-16-026187:notes:198]
– This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plan’s mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 1 of the fair value hierarchy.

[0001437749-16-026187:notes:199]
Other Investments

[0001437749-16-026187:notes:200]
– This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment, and therefore is classified within Level 3 of the fair value hierarchy.

[0001437749-16-026187:notes:201]
The Company’s target allocation for equity securities and real estate is generally between 65% - 85%, with the remainder allocated primarily to fixed income (bonds). The Company regularly reviews its actual asset allocation and periodically rebalances its investments to the targeted allocation when considered appropriate.

[0001437749-16-026187:notes:202]
The Company expects to make estimated contributions of $741 to the Pension Plans in 2016.

[0001437749-16-026187:notes:203]
The following benefit payments are expected to be paid from the Pension Plans:

[0001437749-16-026187:notes:204]
| Year |  |  |  |  |  |
| 2016 |  |  |  |  | $ | 2,052 |  |
| 2017 |  |  |  |  |  | 2,231 |  |
| 2018 |  |  |  |  |  | 2,340 |  |
| 2019 |  |  |  |  |  | 2,424 |  |
| 2020 |  |  |  |  |  | 2,552 |  |
| 2021 | – | 2025 |  |  |  | 15,238 |  |

[0001437749-16-026187:notes:205]
Certain of the Company’s foreign subsidiaries participate in local defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in accrued wages and employee benefits in the Company’s consolidated balance sheets and are not material.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-16-026187:notes:206]
9.     Product Warranty Obligations

[0001437749-16-026187:notes:207]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts.

[0001437749-16-026187:notes:208]
The following is a tabular reconciliation of the product warranty liability, excluding the deferred revenue related to our extended warranty coverage:

[0001437749-16-026187:notes:209]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of year |  | $ | 30,909 |  |  | $ | 33,734 |  |  | $ | 36,111 |  |
| Product warranty reserve assumed in acquisition |  |  | 351 |  |  |  | 360 |  |  |  | 600 |  |
| Payments |  |  | (21,686 | ) |  |  | (20,975 | ) |  |  | (19,084 | ) |
| Provision for warranties issued |  |  | 20,823 |  |  |  | 22,890 |  |  |  | 33,707 |  |
| Changes in estimates for pre-existing warranties |  |  | (200 | ) |  |  | (5,100 | ) |  |  | (17,600 | ) |
| Balance at end of year |  | $ | 30,197 |  |  | $ | 30,909 |  |  | $ | 33,734 |  |

[0001437749-16-026187:notes:210]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-16-026187:notes:211]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of year |  | $ | 27,193 |  |  | $ | 23,092 |  |  | $ | 13,474 |  |
| Deferred revenue contracts assumed in acquisition |  |  | 291 |  |  |  | - |  |  |  | - |  |
| Deferred revenue contracts sold |  |  | 5,978 |  |  |  | 7,343 |  |  |  | 11,998 |  |
| Amortization of deferred revenue contracts |  |  | (4,501 | ) |  |  | (3,242 | ) |  |  | (2,380 | ) |
| Balance at end of year |  | $ | 28,961 |  |  | $ | 27,193 |  |  | $ | 23,092 |  |

[0001437749-16-026187:notes:212]
Product warranty obligations and warranty related deferred revenues are included in the balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-16-026187:notes:213]
Property and Equipment

[0001437749-16-026187:notes:214]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-16-026187:notes:215]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Land and improvements |  | $ | 8,553 |  |  | $ | 7,803 |  |
| Buildings and improvements |  |  | 104,774 |  |  |  | 102,254 |  |
| Machinery and equipment |  |  | 72,280 |  |  |  | 65,240 |  |
| Dies and tools |  |  | 20,066 |  |  |  | 16,897 |  |
| Vehicles |  |  | 1,244 |  |  |  | 1,383 |  |
| Office equipment and systems |  |  | 29,395 |  |  |  | 21,990 |  |
| Leasehold improvements |  |  | 3,338 |  |  |  | 2,535 |  |
| Construction in progress |  |  | 30,482 |  |  |  | 20,120 |  |
| Gross property and equipment |  |  | 270,132 |  |  |  | 238,222 |  |
| Accumulated depreciation |  |  | (85,919 | ) |  |  | (69,401 | ) |
| Total |  | $ | 184,213 |  |  | $ | 168,821 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-16-026187:notes:216]
18.   Quarterly Financial Information (Unaudited)

[0001437749-16-026187:notes:217]
|  |  | Quarters Ended 2015 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 311,818 |  |  | $ | 288,360 |  |  | $ | 359,291 |  |  | $ | 357,830 |  |
| Gross profit |  |  | 102,603 |  |  |  | 95,897 |  |  |  | 130,326 |  |  |  | 131,124 |  |
| Operating income |  |  | 44,911 |  |  |  | 39,467 |  |  |  | 67,867 |  |  |  | 27,316 |  |
| Net income |  |  | 19,685 |  |  |  | 14,844 |  |  |  | 34,036 |  |  |  | 9,182 |  |
| Net income per common share, basic: |  | $ | 0.29 |  |  | $ | 0.22 |  |  | $ | 0.50 |  |  | $ | 0.14 |  |
| Net income per common share, diluted: |  | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.49 |  |  | $ | 0.14 |  |

[0001437749-16-026187:notes:218]
|  |  | Quarters Ended 2014 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 342,008 |  |  | $ | 362,609 |  |  | $ | 352,305 |  |  | $ | 403,997 |  |
| Gross profit |  |  | 119,514 |  |  |  | 128,012 |  |  |  | 130,283 |  |  |  | 138,410 |  |
| Operating income |  |  | 65,306 |  |  |  | 78,160 |  |  |  | 70,794 |  |  |  | 79,115 |  |
| Net income |  |  | 34,701 |  |  |  | 54,025 |  |  |  | 36,497 |  |  |  | 49,390 |  |
| Net income per common share, basic: |  | $ | 0.51 |  |  | $ | 0.79 |  |  | $ | 0.53 |  |  | $ | 0.72 |  |
| Net income per common share, diluted: |  | $ | 0.50 |  |  | $ | 0.77 |  |  | $ | 0.52 |  |  | $ | 0.70 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-16-026187:notes:219]
Accounts Receivable

[0001437749-16-026187:notes:220]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-16-026187:notes:221]
Revenue Recognition

[0001437749-16-026187:notes:222]
Sales, net of estimated returns and allowances, are recognized upon shipment of product to the customer, which is generally when title passes, the Company has no further obligations, and the customer is required to pay subject to agreed upon payment terms. The Company, at the request of certain customers, will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customers take possession of the product. In these cases, the funds collected on product warehoused for these customers are recorded as a customer advance until the customer takes possession of the product and the Company’s obligation to deliver the goods is completed. Customer advances are included in accrued liabilities in the consolidated balance sheets.

[0001437749-16-026187:notes:223]
The Company provides for certain estimated sales programs, discounts and incentive expenses which are recognized as a reduction of sales.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-16-026187:notes:224]
|  |  | Year Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Residential products |  | $ | 673,764 |  |  | $ | 722,206 |  |  | $ | 843,727 |  |
| Commercial & industrial products |  |  | 548,440 |  |  |  | 652,216 |  |  |  | 569,890 |  |
| Other |  |  | 95,095 |  |  |  | 86,497 |  |  |  | 72,148 |  |
| Total |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |  | $ | 1,485,765 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-16-026187:notes:225]
|  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Raw material |  | $ | 188,354 |  |  | $ | 184,407 |  |
| Work-in-process |  |  | 2,856 |  |  |  | 8,798 |  |
| Finished goods |  |  | 144,747 |  |  |  | 135,567 |  |
| Reserves for excess and obsolete |  |  | (10,582 | ) |  |  | (9,387 | ) |
| Total |  | $ | 325,375 |  |  | $ | 319,385 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-16-026187:notes:226]
19.   Valuation and Qualifying Accounts

[0001437749-16-026187:notes:227]
For the years ended December 31, 2015, 2014 and 2013:

[0001437749-16-026187:notes:228]
|  | (1) | Deductions from the allowance for doubtful accounts equal accounts receivable written off, less recoveries, against the allowance. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-026187:notes:229]
6.     Segment Reporting

[0001437749-16-026187:notes:230]
The Company has multiple operating segments, which it aggregates into a single reportable segment, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. The single reportable segment is the design and manufacture of a wide range of engine power products. The Company’s sales in the United States represent approximately 85%, 84%, and 88% of total sales for the years ended December 31, 2015, 2014 and 2013, respectively. Approximately 93% and 91% of the Company’s identifiable long-lived assets are located in the United States as of December 31, 2015 and 2014, respectively.

[0001437749-16-026187:notes:231]
The Company's product offerings consist primarily of power products with a range of power output geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, commercial & industrial, and other products is as follows:


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-16-026187:notes:232]
Shipping and Handling Costs

[0001437749-16-026187:notes:233]
Shipping and handling costs billed to customers are included in net sales, and the related costs are included in cost of goods sold in the consolidated statements of comprehensive income.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-16-026187:notes:234]
2.

[0001437749-16-026187:notes:235]
Significant Accounting Policies

[0001437749-16-026187:notes:236]
Concentration of Credit Risk

[0001437749-16-026187:notes:237]
The Company maintains the majority of its domestic cash in one commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-16-026187:notes:238]
One customer accounted for approximately 11% and 9% of accounts receivable at December 31, 2015 and 2014, respectively. No one customer accounted for greater than 7%, 8% and 6%, of net sales during the years ended December 31, 2015, 2014, or 2013, respectively.

[0001437749-16-026187:notes:239]
Research and Development

[0001437749-16-026187:notes:240]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $32,922, $31,494, and $29,271 for the years ended December 31, 2015, 2014 and 2013, respectively.

[0001437749-16-026187:notes:241]
Fair Value of Financial Instruments

[0001437749-16-026187:notes:242]
The Financial Accounting Standards Board (FASB) Accounting Standards Update (ASC) 820-10, 
Fair Value Measurement

[0001437749-16-026187:notes:243]
,
 defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-16-026187:notes:244]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $937,060 was approximately $918,319 (Level 2) at December 31, 2015, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-16-026187:notes:245]
For the fair value of the assets and liabilities measured on a recurring basis, see the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-16-026187:notes:246]
Use of Estimates

[0001437749-16-026187:notes:247]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-16-026187:notes:248]
Stock-Based Compensation

[0001437749-16-026187:notes:249]
Stock-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant.


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-026187:notes:250]
20.   Subsequent Events

[0001437749-16-026187:notes:251]
On February 13, 2016, the Company entered into an agreement to acquire a majority ownership interest of PR Industrial S.r.l and its subsidiaries (collectively Pramac), headquartered in Siena, Italy. With over 600 employees, four manufacturing plants and fourteen commercial branches located around the world, Pramac is a leading global manufacturer of stationary, mobile and portable generators sold in over 150 countries through a broad distribution network. The acquisition is anticipated to close prior to the end of the first quarter of 2016.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-16-026187:notes:252]
7.     Balance Sheet Details

[0001437749-16-026187:notes:253]
Inventories consist of the following:

[0001437749-16-026187:notes:254]
As of December 31, 2015

[0001437749-16-026187:notes:255]
and 2014

[0001437749-16-026187:notes:256]
, inventories totaling $11,253

[0001437749-16-026187:notes:257]
and $12,497

[0001437749-16-026187:notes:258]
, respectively, were on consignment at customer locations.

[0001437749-16-026187:notes:259]
Property and equipment consists of the following:


## us-gaap:TreasuryStockTextBlock

[0001437749-16-026187:notes:260]
11

[0001437749-16-026187:notes:261]
Stock Repurchase Program

[0001437749-16-026187:notes:262]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the program, the Company may repurchase up to $200,000 of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-16-026187:notes:263]
For the year ended December 31, 2015, the Company repurchased 3,303,500 shares of its common stock for $99,942, funded with cash on hand.
