# GNRC MD&A — 0001437749-18-003334


## mdna

[0001437749-18-003334:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-18-003334:mdna:2]
Overview

[0001437749-18-003334:mdna:3]
We are a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-18-003334:mdna:4]
Recent Developments

[0001437749-18-003334:mdna:5]
On February 13, 2018, we signed a purchase agreement to acquire Selmec Equipos Industriales, S.A. de C.V. (Selmec), which is headquartered in Mexico City, Mexico. Selmec, which has approximately 300 employees, is a designer and manufacturer of industrial generators ranging from 10 kW to 2,750 kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services.

[0001437749-18-003334:mdna:6]
Business Drivers and Operational Factors

[0001437749-18-003334:mdna:7]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-18-003334:mdna:8]
Business Drivers and Trends

[0001437749-18-003334:mdna:9]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-18-003334:mdna:10]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-18-003334:mdna:11]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in 2017. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-18-003334:mdna:12]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-18-003334:mdna:13]
Impact of business capital investment cycles.   The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment. We believe the passage of the Tax Act in late 2017 could have a favorable impact on future demand within many of the end markets that we serve, as the improved cash flow, liquidity and business sentiment may lead to further investments in equipment, facilities and infrastructure in the United States.

[0001437749-18-003334:mdna:14]
24

[0001437749-18-003334:mdna:15]
Factors Affecting Results of Operations

[0001437749-18-003334:mdna:16]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-18-003334:mdna:17]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These acquisitions, along with our existing international presence, exposes us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-18-003334:mdna:18]
We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-18-003334:mdna:19]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 20% to 27% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-18-003334:mdna:20]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, and repayments or borrowings of indebtedness. Cash interest expense decreased during 2017 compared to 2016, primarily due to the $25 million voluntary prepayment of Term Loan debt in November 2016, the May and December 2017 Term Loan refinancings, the repayment of $100 million of ABL Facility borrowings, and decreased borrowings at other subsidiaries; partially offset by an increase in the LIBOR rate. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-18-003334:mdna:21]
Factors influencing provision for income taxes and cash income taxes paid.   On December 22, 2017, the U.S. government enacted the Tax Act, which significantly changes how the U.S. taxes corporations. The Tax Act requires complex computations to be performed that were not previously required in U.S. tax law, significant judgments to be made in interpretation of the provisions of the Tax Act and significant estimates in calculations, and the preparation and analysis of information not previously relevant or regularly produced. The U.S. Treasury Department, the IRS, and other standard-setting bodies could interpret or issue guidance on how provisions of the Tax Act will be applied or otherwise administered that is different from our interpretation.

[0001437749-18-003334:mdna:22]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. While the Company continues to assess the full impact of the Tax Act, the preliminary analysis suggests a meaningful benefit from the legislation. Specifically for 2018, the combined federal and state effective tax rate is expected to decline to between 25 to 26%, resulting in lower cash income taxes. As we complete our analysis of the Tax Act, collect and prepare necessary data, and interpret any additional guidance, we may make adjustments to provisional amounts that we have recorded that may materially impact our provision for income taxes in the period in which the adjustments are made. Refer to Note 13, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Tax Act and its impact.

[0001437749-18-003334:mdna:23]
Further, we had approximately $470 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2017 related to our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $122 million through 2021, assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $61 million due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $32 million through 2020 and $26 million in 2021, assuming profitability and a 26% combined federal and state tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $34 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2017. We expect these assets to generate aggregate cash tax savings of $9.0 million through 2026 assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $4.5 million due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.0 million through 2025 and $0.7 million in 2026, assuming profitability and a 26% combined federal and state tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-18-003334:mdna:24]
Acquisitions.   Over the years, we have executed a number of acquisitions that supported our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-18-003334:mdna:25]
Components of Net Sales and Expenses

[0001437749-18-003334:mdna:26]
Net Sales

[0001437749-18-003334:mdna:27]
Substantially all of our net sales are generated through the sale of our power generation equipment and other engine powered products to the residential, light commercial and industrial markets. We also sell service parts to our dealer network. Net sales, which include shipping and handling charges billed to customers, are generally recognized upon shipment of products to our customers. Related freight costs are included in cost of sales.

[0001437749-18-003334:mdna:28]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 6% of our sales, and our top ten customers representing less than 22% of our total sales for the year ended December 31, 2017.

[0001437749-18-003334:mdna:29]
Costs of Goods Sold

[0001437749-18-003334:mdna:30]
The principal elements of costs of goods sold in our manufacturing operations are component parts, raw materials, factory overhead and labor. Component parts and raw materials comprised approximately 77% of costs of goods sold for the year ended December 31, 2017. The principal component parts are engines and alternators. We design and manufacture air-cooled engines for certain of our generators up to 22kW, along with certain liquid-cooled engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the OEM of those engines. We design many of the alternators for our units and either manufacture or source alternators for certain of our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-18-003334:mdna:31]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-18-003334:mdna:32]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-18-003334:mdna:33]
Operating Expenses

[0001437749-18-003334:mdna:34]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs and taxes, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-18-003334:mdna:35]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising, promotional expenses and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, and opportunities to create market awareness for home standby generators in areas impacted by heightened power outage activity.

[0001437749-18-003334:mdna:36]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. We operate engineering facilities at many locations globally and employ over 350 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-18-003334:mdna:37]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-18-003334:mdna:38]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and other intangibles assets.

[0001437749-18-003334:mdna:39]
Other (Expense) Income

[0001437749-18-003334:mdna:40]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and expenses related to interest rate swap agreements. Other (expense) income also includes other financial items such as losses on extinguishment of debt, gains (losses) on change in contractual interest rate, interest income earned on our cash and cash equivalents, and costs related to acquisitions.

[0001437749-18-003334:mdna:41]
Results of Operations

[0001437749-18-003334:mdna:42]
Year ended December 31, 2017 compared to year ended December 31, 2016

[0001437749-18-003334:mdna:43]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-18-003334:mdna:44]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |  |  | 227,992 |  |  |  | 15.8 | % |
| Cost of goods sold |  |  | 1,090,328 |  |  |  | 930,347 |  |  |  | 159,981 |  |  |  | 17.2 | % |
| Gross profit |  |  | 582,117 |  |  |  | 514,106 |  |  |  | 68,011 |  |  |  | 13.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 171,755 |  |  |  | 164,607 |  |  |  | 7,148 |  |  |  | 4.3 | % |
| Research and development |  |  | 42,925 |  |  |  | 37,229 |  |  |  | 5,696 |  |  |  | 15.3 | % |
| General and administrative |  |  | 87,512 |  |  |  | 74,700 |  |  |  | 12,812 |  |  |  | 17.2 | % |
| Amortization of intangible assets |  |  | 28,861 |  |  |  | 32,953 |  |  |  | (4,092 | ) |  |  | -12.4 | % |
| Total operating expenses |  |  | 331,053 |  |  |  | 309,489 |  |  |  | 21,564 |  |  |  | 7.0 | % |
| Income from operations |  |  | 251,064 |  |  |  | 204,617 |  |  |  | 46,447 |  |  |  | 22.7 | % |
| Total other expense, net |  |  | (46,376 | ) |  |  | (48,235 | ) |  |  | 1,859 |  |  |  | -3.9 | % |
| Income before provision for income taxes |  |  | 204,688 |  |  |  | 156,382 |  |  |  | 48,306 |  |  |  | 30.9 | % |
| Provision for income taxes |  |  | 43,553 |  |  |  | 57,570 |  |  |  | (14,017 | ) |  |  | -24.3 | % |
| Net income |  |  | 161,135 |  |  |  | 98,812 |  |  |  | 62,323 |  |  |  | 63.1 | % |
| Net income attributable to noncontrolling interests |  |  | 1,749 |  |  |  | 24 |  |  |  | 1,725 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,386 |  |  | $ | 98,788 |  |  |  | 60,598 |  |  |  | 61.3 | % |

[0001437749-18-003334:mdna:45]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-18-003334:mdna:46]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,296,578 |  |  | $ | 1,173,559 |  |  |  | 123,019 |  |  |  | 10.5 | % |
| International |  |  | 375,867 |  |  |  | 270,894 |  |  |  | 104,973 |  |  |  | 38.8 | % |
| Total net sales |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |  |  | 227,992 |  |  |  | 15.8 | % |

[0001437749-18-003334:mdna:47]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 290,720 |  |  | $ | 261,428 |  |  |  | 29,292 |  |  |  | 11.2 | % |
| International |  |  | 27,010 |  |  |  | 16,959 |  |  |  | 10,051 |  |  |  | 59.3 | % |
| Total Adjusted EBITDA |  | $ | 317,730 |  |  | $ | 278,387 |  |  |  | 39,343 |  |  |  | 14.1 | % |

[0001437749-18-003334:mdna:48]
The following table sets forth our product class information for the periods indicated:

[0001437749-18-003334:mdna:49]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 870,410 |  |  | $ | 772,436 |  |  |  | 97,974 |  |  |  | 12.7 | % |
| Commercial & industrial products |  |  | 685,052 |  |  |  | 557,532 |  |  |  | 127,520 |  |  |  | 22.9 | % |
| Other |  |  | 116,983 |  |  |  | 114,485 |  |  |  | 2,498 |  |  |  | 2.2 | % |
| Total net sales |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |  |  | 227,992 |  |  |  | 15.8 | % |

[0001437749-18-003334:mdna:50]
Net sales.    The increase in Domestic sales for the year ended December 31, 2017 was primarily due to strong growth in shipments of home standby and portable generators driven by increased power outage activity, along with strong growth for mobile products due to recovery in the general rental and oil & gas markets, given the continued replacement cycle by our rental customers.

[0001437749-18-003334:mdna:51]
The increase in International sales for the year ended December 31, 2017 was due to the contribution from the recent acquisitions of Pramac and Motortech. The growth was also due to increased organic shipments of both C&I and residential products within the European and Latin America regions.

[0001437749-18-003334:mdna:52]
The total contribution from non-annualized recent acquisitions for the year ended December 31, 2017 was $69.7 million.

[0001437749-18-003334:mdna:53]
Gross profit.    Gross profit margin for the year ended December 31, 2017 was 34.8% compared to 35.6% for the year ended December 31, 2016. The prior year included $2.7 million of business optimization and restructuring costs classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry, as well as $4.2 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. The current year included $2.0 million of business optimization and non-recurring plant consolidation costs. Excluding the impact of these charges, pro-forma gross margins were 34.9% and 36.1% in 2017 and 2016, respectively. The pro-forma decrease in gross margins was primarily due to unfavorable sales mix attributable to higher organic sales within the International segment and of mobile products relative to prior year, which carry lower gross margins relative to the consolidated average. Additionally, the mix impact from the Pramac and Motortech acquisitions, and higher commodity prices negatively impacted gross margin. These impacts were partially offset by improved leverage of fixed manufacturing costs on the higher organic sales volumes and net favorable pricing impacts.

[0001437749-18-003334:mdna:54]
Operating expenses.    Operating expenses increased $21.6 million, or 7.0%, as compared to the year ended December 31, 2016. The prior year included $4.4 million of business optimization and restructuring costs classified within operating expenses to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $26.0 million, or 8.5%, as compared to the prior year. The increase was primarily due to the addition of recurring operating expenses associated with the Pramac and Motortech acquisitions, and an increase in personnel costs including higher incentive compensation accrued during the current year; partially offset by a decline in amortization of intangibles.

[0001437749-18-003334:mdna:55]
Other expense.     The decrease in other expense was primarily due to a prior year $3.0 million non-cash loss on change in contractual interest rate not repeating and a prior year $0.6 million loss on extinguishment of debt resulting from a $25.0 million voluntary prepayment of Term Loan debt. Additionally, interest expense decreased in the current year due to that $25.0 million Term Loan prepayment in November 2016, Term Loan repricings in May and December 2017, and decreased borrowings at other subsidiaries. These impacts were partially offset by an increase in LIBOR rates and foreign currency transactional losses.

[0001437749-18-003334:mdna:56]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2017 and 2016 were 21.3% and 36.8%, respectively. The decrease in the effective income tax rate is primarily due to the provisional favorable effect of the Tax Act, including a one-time, non-cash benefit of $28.4 million recorded in the fourth quarter of 2017, as well as excess tax benefits from share-based compensation. Refer to Note 13, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Tax Act and its impact.

[0001437749-18-003334:mdna:57]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-18-003334:mdna:58]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2017 were 22.4% of net sales as compared to 22.3% of net sales for the year ended December 31, 2016. This increase was primarily due to improved overall leverage of fixed operating expenses on the organic increase in sales, and the net favorable impact of pricing. These impacts were partially offset by higher commodity prices and an increase in personnel costs including higher incentive compensation accrued during the current year.

[0001437749-18-003334:mdna:59]
Adjusted EBITDA margins for the International segment for the year ended December 31, 2017 were 7.2% of net sales as compared to 6.3% of net sales for the year ended December 31, 2016. The increase was primarily due improved overall leverage of fixed manufacturing and operating expenses on the organic increase in sales, the addition of the Motortech acquisition and cost reduction actions. These impacts were partially offset by higher commodity prices and increased operating expenses associated with the expansion of certain branch operations.

[0001437749-18-003334:mdna:60]
Adjusted net income.    Adjusted Net Income of $212.9 million for the year ended December 31, 2017 increased 7.4% from $198.3 million for the year ended December 31, 2016, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-18-003334:mdna:61]
Year ended December 31, 2016 compared to year ended December 31, 2015

[0001437749-18-003334:mdna:62]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-18-003334:mdna:63]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |
| Cost of goods sold |  |  | 930,347 |  |  |  | 857,349 |  |  |  | 72,998 |  |  |  | 8.5 | % |
| Gross profit |  |  | 514,106 |  |  |  | 459,950 |  |  |  | 54,156 |  |  |  | 11.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 164,607 |  |  |  | 130,242 |  |  |  | 34,365 |  |  |  | 26.4 | % |
| Research and development |  |  | 37,229 |  |  |  | 32,922 |  |  |  | 4,307 |  |  |  | 13.1 | % |
| General and administrative |  |  | 74,700 |  |  |  | 52,947 |  |  |  | 21,753 |  |  |  | 41.1 | % |
| Amortization of intangible assets |  |  | 32,953 |  |  |  | 23,591 |  |  |  | 9,362 |  |  |  | 39.7 | % |
| Tradename and goodwill impairment |  |  | - |  |  |  | 40,687 |  |  |  | (40,687 | ) |  |  | -100.0 | % |
| Total operating expenses |  |  | 309,489 |  |  |  | 280,389 |  |  |  | 29,100 |  |  |  | 10.4 | % |
| Income from operations |  |  | 204,617 |  |  |  | 179,561 |  |  |  | 25,056 |  |  |  | 14.0 | % |
| Total other expense, net |  |  | (48,235 | ) |  |  | (56,578 | ) |  |  | 8,343 |  |  |  | -14.7 | % |
| Income before provision for income taxes |  |  | 156,382 |  |  |  | 122,983 |  |  |  | 33,399 |  |  |  | 27.2 | % |
| Provision for income taxes |  |  | 57,570 |  |  |  | 45,236 |  |  |  | 12,334 |  |  |  | 27.3 | % |
| Net income |  |  | 98,812 |  |  |  | 77,747 |  |  |  | 21,065 |  |  |  | 27.1 | % |
| Net income attributable to noncontrolling interests |  |  | 24 |  |  |  | - |  |  |  | 24 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 98,788 |  |  | $ | 77,747 |  |  |  | 21,041 |  |  |  | 27.1 | % |

[0001437749-18-003334:mdna:64]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-18-003334:mdna:65]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,173,559 |  |  | $ | 1,204,589 |  |  |  | (31,030 | ) |  |  | -2.6 | % |
| International |  |  | 270,894 |  |  |  | 112,710 |  |  |  | 158,184 |  |  |  | 140.3 | % |
| Total net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |

[0001437749-18-003334:mdna:66]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 261,428 |  |  | $ | 254,882 |  |  |  | 6,546 |  |  |  | 2.6 | % |
| International |  |  | 16,959 |  |  |  | 15,934 |  |  |  | 1,025 |  |  |  | 6.4 | % |
| Total Adjusted EBITDA |  | $ | 278,387 |  |  | $ | 270,816 |  |  |  | 7,571 |  |  |  | 2.8 | % |

[0001437749-18-003334:mdna:67]
The following table sets forth our product class information for the periods indicated:

[0001437749-18-003334:mdna:68]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 772,436 |  |  | $ | 673,764 |  |  |  | 98,672 |  |  |  | 14.6 | % |
| Commercial & industrial products |  |  | 557,532 |  |  |  | 548,440 |  |  |  | 9,092 |  |  |  | 1.7 | % |
| Other |  |  | 114,485 |  |  |  | 95,095 |  |  |  | 19,390 |  |  |  | 20.4 | % |
| Total net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |

[0001437749-18-003334:mdna:69]
Net sales.   The decrease in Domestic sales for the year ended December 31, 2016 was primarily due to significant declines in shipments of mobile products into oil & gas and general rental markets. Partially offsetting this was the contribution from the CHP acquisition, along with increased shipments of portable and home standby generators.

[0001437749-18-003334:mdna:70]
The increase in International sales for the year ended December 31, 2016 was due to the contribution from the Pramac acquisition. Partially offsetting this impact were declines in organic shipments of mobile products into the European region.

[0001437749-18-003334:mdna:71]
The total contribution from non-annualized recent acquisitions for the year ended December 31, 2016 was $236.6 million.

[0001437749-18-003334:mdna:72]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the year ended December 31, 2016 includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost-reduction actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write-downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. The increase in net income attributable to Generac Holdings Inc. was primarily due to a 2015 $40.7 million pre-tax, non-cash charge for the impairment of certain intangible assets, partially offset by the business optimization charge discussed above and the other factors outlined in this section.

[0001437749-18-003334:mdna:73]
Gross profit.    Gross profit margin for the year ended December 31, 2016 was 35.6% compared to 34.9% for the year ended December 31, 2015, which includes the impact of the aforementioned $2.7 million of business optimization charges classified within cost of goods sold, as well as $4.2 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these adjustments, pro-forma gross profit margin was 36.1%, an improvement of 120 basis points over the year ended December 31, 2015. The pro-forma increase was primarily due to the favorable impacts from lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar, along with an overall favorable organic product mix. In addition, gross margin in 2015 was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current year. These factors were partially offset by the mix impact from the Pramac acquisition.

[0001437749-18-003334:mdna:74]
Operating expenses.    Excluding the impact of the aforementioned $4.4 million of business optimization charges and 2015 $40.7 million of intangible impairment charges classified within operating expenses, operating expenses increased $65.4 million, or 27.3%, to $305.1 million for the year ended December 31, 2016 from $239.7 million for the year ended December 31, 2015. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions and increased amortization expense.

[0001437749-18-003334:mdna:75]
Other expense.   Other expense in 2015 included a non-cash $4.8 million loss on extinguishment of debt resulting from $150.0 million of voluntary prepayments of Term Loan debt, and a $2.4 million non-cash loss resulting from an increase in our Term Loan interest rate spread of 25 basis points. In 2016, other expense included a $3.0 million non-cash loss resulting from a continuation of the 25 basis point spread increase, and a $0.6 million loss on extinguishment of debt resulting from a $25.0 million voluntary prepayment of Term Loan debt.

[0001437749-18-003334:mdna:76]
Provision for ncome taxes.    The effective income tax rates for the years ended December 31, 2016 and 2015 were both 36.8%.

[0001437749-18-003334:mdna:77]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2016 were 22.3% of net sales as compared to 21.2% of net sales for the year ended December 31, 2015. This increase was primarily due to overall favorable product mix; lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar; and the benefit of cost-reduction actions within domestic mobile products, partially offset by increased promotional activities.

[0001437749-18-003334:mdna:78]
Adjusted EBITDA margins for the International segment for the year ended December 31, 2016 were 6.3% of net sales as compared to 14.1% of net sales for the year ended December 31, 2015. This decrease was primarily due to a large decline in mobile products margins given the reduced operating leverage on lower organic sales volume, unfavorable sales mix, foreign currency impacts with the weakness in the British Pound, and, to a lesser extent, the Pramac acquisition sales mix.

[0001437749-18-003334:mdna:79]
Adjusted net income.    Adjusted Net Income of $198.3 million for the year ended December 31, 2016 decreased 0.1% from $198.4 million for the year ended December 31, 2015. The increased earnings outlined above were offset by an increase in cash income tax expense and adjusted net income attributable to noncontrolling interests.

[0001437749-18-003334:mdna:80]
Liquidity and Financial Position

[0001437749-18-003334:mdna:81]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our Amended ABL Facility.

[0001437749-18-003334:mdna:82]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The Term Loan currently bears interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, subject to a LIBOR floor of 0.75%. As of December 31, 2017, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-18-003334:mdna:83]
Our credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. As of December 31, 2017, there was $249.7 million of availability under the Amended ABL Facility, net of outstanding letters of credit. The Company is in compliance with all covenants of the Amended ABL Facility.

[0001437749-18-003334:mdna:84]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the year ended December 31, 2017, we repurchased 844,500 shares of our common stock for $30.0 million; during the year ended December 31, 2016, we repurchased 3,968,706 shares of our common stock for $149.9 million; and during the year ended December 31, 2015, we repurchased 3,303,500 shares of our common stock for $99.9 million, all funded with cash on hand.

[0001437749-18-003334:mdna:85]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information.

[0001437749-18-003334:mdna:86]
Long-term Liquidity

[0001437749-18-003334:mdna:87]
We believe that our cash flow from operations and availability under our Amended ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-18-003334:mdna:88]
Cash Flow

[0001437749-18-003334:mdna:89]
Year ended December 31, 2017 compared to year ended December 31, 2016

[0001437749-18-003334:mdna:90]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-18-003334:mdna:91]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 261,116 |  |  | $ | 253,409 |  |  | $ | 7,707 |  |  |  | 3.0 | % |
| Net cash used in investing activities |  |  | (31,922 | ) |  |  | (105,822 | ) |  |  | 73,900 |  |  |  | -69.8 | % |
| Net cash used in financing activities |  |  | (160,143 | ) |  |  | (195,705 | ) |  |  | 35,562 |  |  |  | -18.2 | % |

[0001437749-18-003334:mdna:92]
The 3.0% increase in net cash provided by operating activities was primarily driven by an overall increase in operating earnings, partially offset by a lesser benefit from working capital reductions during the current year, which was primarily due to replenishing inventory levels in the first quarter of 2017 following Hurricane Matthew, and ramping up production in the second half of 2017 in response to Hurricanes Harvey, Irma and Maria.

[0001437749-18-003334:mdna:93]
Net cash used in investing activities for the year ended December 31, 2017 primarily consisted of cash payments for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2016 primarily represents cash payments of $76.7 million related to the acquisition of businesses and $30.5 million for the purchase of property and equipment.

[0001437749-18-003334:mdna:94]
Net cash used in financing activities for the year ended December 31, 2017 primarily consisted of $232.4 million of debt repayments ($117.5 million of long-term borrowings and $114.9 million of short-term borrowings), $30.0 million for the repurchase of the Company’s common stock, $5.9 million of taxes paid related to equity awards and $3.9 million of payments for debt issuance costs. These payments were partially offset by $105.1 million cash proceeds from borrowings ($102.0 million for short-term borrowings and $3.1 million for long-term borrowings) and $7.0 million of proceeds from the exercise of stock options.

[0001437749-18-003334:mdna:95]
Net cash used in financing activities for the year ended December 31, 2016 primarily consisted of $149.9 million for the repurchase of the Company’s common stock, $65.4 million of debt repayments ($37.6 million of long-term borrowings and $27.8 million of short-term borrowings) and $12.4 million of taxes paid related to equity awards. These payments were partially offset by $28.7 million cash proceeds from short-term borrowings and $7.9 million of excess tax benefits from equity awards.

[0001437749-18-003334:mdna:96]
Year ended December 31, 2016 compared to year ended December 31, 2015

[0001437749-18-003334:mdna:97]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-18-003334:mdna:98]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 253,409 |  |  | $ | 188,619 |  |  | $ | 64,790 |  |  |  | 34.3 | % |
| Net cash used in investing activities |  |  | (105,822 | ) |  |  | (104,328 | ) |  |  | (1,494 | ) |  |  | 1.4 | % |
| Net cash used in financing activities |  |  | (195,705 | ) |  |  | (154,483 | ) |  |  | (41,222 | ) |  |  | 26.7 | % |

[0001437749-18-003334:mdna:99]
The 34.3% increase in net cash provided by operating activities was primarily driven by a reduction in working capital investment during 2016 as compared to the larger investment that was incurred in 2015, and an overall increase in operating earnings.

[0001437749-18-003334:mdna:100]
Net cash used in investing activities for the year ended December 31, 2016 primarily consisted of cash payments of $76.7 million related to the acquisitions of businesses and $30.5 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2015 primarily represents cash payments of $74.6 million related to the acquisition of CHP and $30.7 million for the purchase of property and equipment.

[0001437749-18-003334:mdna:101]
Net cash used in financing activities for the year ended December 31, 2016 primarily consisted of $149.9 million for the repurchase of the Company’s common stock, $65.4 million of debt repayments ($37.6 million of long-term borrowings and $27.8 million of short-term borrowings) and $12.4 million of taxes paid related to equity awards. These payments were partially offset by $28.7 million cash proceeds from short-term borrowings and $7.9 million of excess tax benefits from equity awards.

[0001437749-18-003334:mdna:102]
Net cash used in financing activities for the year ended December 31, 2015 primarily consisted of $174.0 million of debt repayments ($150.8 million of long-term borrowings and $23.2 million of short-term borrowings), partially offset by $126.4 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the Amended ABL facility and $26.4 million from short-term borrowings). In addition, the Company paid $99.9 million for the repurchase of its common stock and $13.0 million of taxes related to equity awards, which was partially offset by $9.6 million of excess tax benefits from equity awards.

[0001437749-18-003334:mdna:103]
Senior Secured Credit Facilities

[0001437749-18-003334:mdna:104]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-18-003334:mdna:105]
Covenant Compliance

[0001437749-18-003334:mdna:106]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-18-003334:mdna:107]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-18-003334:mdna:108]
The Amended ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-18-003334:mdna:109]
Contractual Obligations

[0001437749-18-003334:mdna:110]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2017, using the interest rates in effect as of that date:

[0001437749-18-003334:mdna:111]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including curent portion (1) |  | $ | 930,367 |  |  | $ | 936 |  |  | $ | 431 |  |  | $ | - |  |  | $ | 929,000 |  |
| Capital lease obligations, including current portion |  |  | 4,690 |  |  |  | 636 |  |  |  | 1,246 |  |  |  | 1,755 |  |  |  | 1,053 |  |
| Interest on long-term debt |  |  | 186,357 |  |  |  | 34,455 |  |  |  | 68,925 |  |  |  | 68,750 |  |  |  | 14,227 |  |
| Operating leases |  |  | 43,924 |  |  |  | 9,497 |  |  |  | 15,282 |  |  |  | 13,280 |  |  |  | 5,865 |  |
| Total contractual cash obligations (2) |  | $ | 1,165,338 |  |  | $ | 45,524 |  |  | $ | 85,884 |  |  | $ | 83,785 |  |  | $ | 950,145 |  |

[0001437749-18-003334:mdna:112]
(1) The Term Loan originally provided for a $1.2 billion term loan B credit facility and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The Amended ABL Facility provides for a $250.0 million senior secured ABL revolving credit facility, which matures on May 29, 2020. There was no outstanding balance on the Amended ABL Facility as of December 31, 2017.

[0001437749-18-003334:mdna:113]
(2) Pension obligations are excluded from this table as we are unable to estimate the timing of payment due to the inherent assumptions underlying the obligation. However, at a minimum, the Company estimates we will contribute $0.3 million to our pension plans in 2018.

[0001437749-18-003334:mdna:114]
Capital Expenditures

[0001437749-18-003334:mdna:115]
Our operations require capital expenditures for technology, tooling, equipment, capacity expansion, systems and upgrades. Capital expenditures were $33.3 million, $30.5 million and $30.7 million for the years ended December 31, 2017, 2016 and 2015, respectively, and were funded through cash from operations.

[0001437749-18-003334:mdna:116]
Off-Balance Sheet Arrangements

[0001437749-18-003334:mdna:117]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer and our dealers are given a longer period of time to pay the finance provider. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-18-003334:mdna:118]
Total inventory financed under this arrangement accounted for approximately 9% and 8% of net sales for the years ended December 31, 2017 and 2016, respectively. The amount financed by dealers which remained outstanding was $36.5 million and $33.9 million as of December 31, 2017 and 2016, respectively.

[0001437749-18-003334:mdna:119]
Critical Accounting Policies

[0001437749-18-003334:mdna:120]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, that its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-18-003334:mdna:121]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-18-003334:mdna:122]
Refer to Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets.

[0001437749-18-003334:mdna:123]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2017, 2016 and 2015, and found no impairment following the 2017 and 2016 tests. There were no reporting units with a carrying value at-risk of exceeding fair value as of the October 31, 2017 impairment test date.

[0001437749-18-003334:mdna:124]
After performing the impairment tests for fiscal year 2015, the Company determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge of $4.6 million in the fourth quarter of 2015. The fair value was determined using a discounted cash flow analysis, which utilizes key estimates and assumptions as discussed below. Additionally, in the fourth quarter of 2015, the Company’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired through acquisitions to the Generac® tradename. This brand strategy change resulted in a reclassification to a two year remaining useful life for the impacted tradenames, causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a $36.1 million non-cash impairment charge was recorded in the fourth quarter of 2015 to write-down the impacted tradenames to net realizable value. See Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the impairment charges recorded in 2015.

[0001437749-18-003334:mdna:125]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-18-003334:mdna:126]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-18-003334:mdna:127]
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-18-003334:mdna:128]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-18-003334:mdna:129]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-18-003334:mdna:130]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-18-003334:mdna:131]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-18-003334:mdna:132]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-18-003334:mdna:133]
|  | ● | disruptions to the Company’s business; |

[0001437749-18-003334:mdna:134]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-18-003334:mdna:135]
|  | ● | unexpected or planned changes in the use of assets or entity structure; and |

[0001437749-18-003334:mdna:136]
|  | ● | business divestitures. |

[0001437749-18-003334:mdna:137]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-18-003334:mdna:138]
Business Combinations and Purchase Accounting

[0001437749-18-003334:mdna:139]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, earnings margins, and forecasted cash flows based on the discount rate and terminal growth rate. Refer to Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-18-003334:mdna:140]
Defined Benefit Pension Obligations

[0001437749-18-003334:mdna:141]
The Company’s pension benefit obligation and related pension expense or income are calculated in accordance with Financial Accounting Standards Board (FASB) Accounting Standards Codification (ASC) 715-30, Defined Benefit Plans—Pension, and are impacted by certain actuarial assumptions, including the discount rate and the expected rate of return on plan assets. Such rates are evaluated on an annual basis considering factors including market interest rates and historical asset performance. Actuarial valuations for fiscal year 2017 used a discount rate of 3.60% for the salaried pension plan and 3.62% for the hourly pension plan. Our discount rate was selected using a methodology that matches plan cash flows with a selection of “Aa” or higher rated bonds, resulting in a discount rate that better matches a bond yield curve with comparable cash flows. In estimating the expected return on plan assets, we study historical markets and preserve the long-term historical relationships between equities and fixed-income securities. We evaluate current market factors such as inflation and interest rates before we determine long-term capital market assumptions and review peer data and historical returns to check for reasonableness and appropriateness. Changes in the discount rate and return on assets can have a significant effect on the funded status of our pension plans, stockholders' equity and related expense. We cannot predict these changes in discount rates or investment returns and, therefore, cannot reasonably estimate whether the impact in subsequent years will be significant.

[0001437749-18-003334:mdna:142]
The funded status of our pension plans is the difference between the projected benefit obligation and the fair value of its plan assets. The projected benefit obligation is the actuarial present value of all benefits expected to be earned by the employees' service. No compensation increase is assumed in the calculation of the projected benefit obligation, as the plans were frozen effective December 31, 2008. Further information regarding the funded status of our pension plans can be found in Note 14, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-18-003334:mdna:143]
Our funding policy for our pension plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations. Given this policy, we expect to make $0.3 million in contributions to our pension plans in 2018, at a minimum.

[0001437749-18-003334:mdna:144]
Income Taxes

[0001437749-18-003334:mdna:145]
We account for income taxes in accordance with ASC 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-18-003334:mdna:146]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-18-003334:mdna:147]
Refer to Note 13, “Income Taxes” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and the impact of the Tax Act.

[0001437749-18-003334:mdna:148]
New Accounting Standards

[0001437749-18-003334:mdna:149]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Significant Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.
