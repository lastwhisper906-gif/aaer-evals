# GNRC 8-K — 0001437749-18-002286 filed 2018-02-13

## item codes, every 8-K on or before 2018-02-26

- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2018-02-26

- none on or before 2018-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-002286:8k_2_02:1]
EX-99.1
2
ex_105021.htm
EXHIBIT 99.1

[0001437749-18-002286:8k_2_02:2]
ex_105021.htm

[0001437749-18-002286:8k_2_02:3]
Exhibit 99.1

[0001437749-18-002286:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2017 Results

[0001437749-18-002286:8k_2_02:5]
Strong organic sales growth compared to prior year leads to record shipments and cash flow

[0001437749-18-002286:8k_2_02:6]
WAUKESHA, WISCONSIN, (February 13, 2018) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its fourth quarter and full-year ended December 31, 2017. Additionally, the Company initiated its outlook for 2018.

[0001437749-18-002286:8k_2_02:7]
Fourth Quarter 2017 Highlights

[0001437749-18-002286:8k_2_02:8]
| ● | Net sales increased 16.9% to $488.0 million during the fourth quarter of 2017 as compared to $417.4 million in the prior-year fourth quarter, including $9.6 million of contribution from the Motortech acquisition. |

[0001437749-18-002286:8k_2_02:9]
| ● | Net income attributable to the Company during the fourth quarter was $81.2 million, or $1.30 per share, as compared to $41.5 million, or $0.64 per share, for the same period of 2016. The current year net income includes the impact of a $28.4 million non-cash gain, or $0.45 per share, largely from the revaluation of the Company’s net deferred tax liabilities associated with the enactment of the Tax Cuts and Jobs Act of 2017 (“Tax Reform Act”). |

[0001437749-18-002286:8k_2_02:10]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $85.9 million, or $1.37 per share, as compared to $71.4 million, or $1.12 per share, in the fourth quarter of 2016. The current-year adjusted net income includes the favorable impact from the acceleration of certain tax deductions, mostly in response to the Tax Reform Act, that resulted in a $0.15 benefit on a per share basis. |

[0001437749-18-002286:8k_2_02:11]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $108.6 million as compared to $91.0 million in the fourth quarter last year. |

[0001437749-18-002286:8k_2_02:12]
| ● | Cash flow from operations was a quarterly record of $138.4 million as compared to $123.9 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was also a quarterly record of $121.8 million as compared to $114.3 million in the fourth quarter of 2016. |

[0001437749-18-002286:8k_2_02:13]
| ● | The Company amended its Term Loan credit facility which reduced the applicable margin interest rate by 25 basis points from the level previously in effect, and eliminated the annual excess cash flow payment requirement if the consolidated net debt to adjusted EBITDA leverage ratio (“net leverage ratio”) is maintained below 3.75 times. The net leverage ratio, as defined in the accompanying reconciliation schedules, declined to 2.5 times as of December 31, 2017 compared to 3.6 times as of December 31, 2016. |

[0001437749-18-002286:8k_2_02:14]
Full-Year 2017 Highlights

[0001437749-18-002286:8k_2_02:15]
| ● | Net sales increased 15.8% to $1.672 billion during 2017 as compared to $1.444 billion during 2016, including $69.7 million of contribution from acquisitions, resulting in total organic sales growth for the year of 11.0%. Domestic segment sales increased 10.5% to $1.297 billion as compared to $1.174 billion in the prior year. International segment sales increased 38.8% to $375.9 million as compared to $270.9 million in the prior year. |

[0001437749-18-002286:8k_2_02:16]
| ● | Net income attributable to the Company during 2017 was $159.4 million, or $2.56 per share, as compared to $98.8 million, or $1.50 per share for 2016. Net income for 2017 includes the impact of the $28.4 million non-cash gain as a result of the Tax Reform Act. The prior-year net income includes the impact of $7.1 million of non-recurring, pre-tax charges relating to the downturn for capital spending within the oil & gas industry. |

[0001437749-18-002286:8k_2_02:17]
| ● | Adjusted net income attributable to the Company was $212.9 million, or $3.40 per share, as compared to $198.3 million, or $3.03 per share, in 2016. |
| ● | Adjusted EBITDA attributable to the Company for 2017 was $311.7 million as compared to $274.6 million last year. |

[0001437749-18-002286:8k_2_02:18]
| ● | Cash flow from operations was $261.1 million as compared to $253.4 million in the prior year. Free cash flow was $227.9 million as compared to $222.9 million in 2016. |

[0001437749-18-002286:8k_2_02:19]
“Our fourth quarter results put an exclamation point on a great 2017 as strong organic sales growth led to record quarterly sales and cash flow,” said Aaron Jagdfeld, President and Chief Executive Officer. “Shipments of home standby generators during the quarter were near record levels as higher power outage activity drove significant awareness for the product category during the second half of the year. The increased interest in home standby generators translated to elevated levels of sales leads during the quarter and helped to push our residential dealer count to an all-time high. Shipments of commercial and industrial products were also strong during the quarter driven mainly by our rental customers continued spending on new fleet equipment such as light towers and mobile generators. In addition to our fantastic Domestic segment results for the quarter, our continued focus to create a more global company resulted in our best ever level of shipments outside the U.S. and Canada as our International segment experienced very strong organic sales growth and a substantial increase in margins.”

[0001437749-18-002286:8k_2_02:20]
Additional Fourth Quarter 2017 Consolidated Highlights

[0001437749-18-002286:8k_2_02:21]
Residential product sales increased 11.2% to $265.5 million as compared to $238.9 million in the prior year. Commercial & Industrial (C&I) product sales increased 27.1% to $188.3 million as compared to $148.1 million in the prior year.

[0001437749-18-002286:8k_2_02:22]
Gross profit margin was largely flat at 36.8% compared to 36.9% in the prior-year fourth quarter, which was due to a variety of factors. Favorable pricing impacts along with improved leverage of fixed manufacturing costs were offset by unfavorable sales mix attributable to significantly higher International segment and mobile products sales compared to prior year along with higher commodity prices.

[0001437749-18-002286:8k_2_02:23]
Operating expenses increased $8.7 million, or 11.4%, as compared to the fourth quarter of 2016. The increase was primarily driven by the Motortech acquisition, higher variable costs on the strong growth in organic sales, and an increase in employee costs including higher incentive compensation, partially offset by lower promotional costs benefitting from the higher power outage environment.

[0001437749-18-002286:8k_2_02:24]
Cash flow from operations was $138.4 million as compared to $123.9 million in the prior-year fourth quarter, and free cash flow was $121.8 million as compared to $114.3 million in the same quarter last year. The improvements in cash flow were driven by a variety of factors including the increase in operating earnings as compared to the prior year and a larger benefit from working capital reduction during the current year, partially offset by higher cash income taxes and capital expenditures.

[0001437749-18-002286:8k_2_02:25]
On December 8, 2017, the Company amended its Term Loan credit facility which, among other items, modified the pricing by reducing the applicable margin rate to a fixed rate of 2.00%, resulting in a 25 basis point reduction in overall interest rate from the level previously in effect, or approximately $2.3 million of annualized interest savings. In addition, certain terms were amended to increase the Company’s flexibility regarding repayment obligations, including the elimination of the annual excess cash flow payment requirement if the consolidated net leverage ratio is maintained below 3.75 times.

[0001437749-18-002286:8k_2_02:26]
Business Segment Results

[0001437749-18-002286:8k_2_02:27]
Domestic Segment

[0001437749-18-002286:8k_2_02:28]
Domestic segment sales increased 11.2% to $377.9 million as compared to $339.7 million in the prior-year quarter. The current-year fourth quarter experienced strong growth in shipments of home standby generators driven by increased outage activity, along with the continuation of significant growth for mobile products. Also contributing to the year-over-year sales growth were increases in service parts.

[0001437749-18-002286:8k_2_02:29]
Adjusted EBITDA for the segment was $100.6 million, or 26.6% of net sales, as compared to $87.9 million in the prior year, or 25.9% of net sales. Adjusted EBITDA margin in the current year benefitted from a favorable pricing environment including lower promotional costs, and improved overall leverage of fixed operating costs on the higher organic sales volumes. These impacts were partially offset by higher commodity prices and an increase in employee costs including higher incentive compensation.

[0001437749-18-002286:8k_2_02:30]
International Segment

[0001437749-18-002286:8k_2_02:31]
International segment sales increased 41.8% to $110.2 million as compared to $77.7 million in the prior-year quarter, including $9.6 million of contribution from the Motortech acquisition. The significant organic growth compared to the prior year was due to increased shipments of both C&I and residential products primarily within the European region, together with large project activity and the favorable impact of the stronger Euro.

[0001437749-18-002286:8k_2_02:32]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, improved to $10.5 million, or 9.6% of net sales, as compared to $3.9 million, or 5.0% of net sales, in the prior year. The significant improvement in adjusted EBITDA margin as compared to the prior year was primarily due to improved leverage of fixed operating costs on the significant increase in organic sales, as well as favorable sales mix from higher-margin large project activity. These favorable impacts were partially offset by higher commodity prices and increased operating expenses associated with the expansion of certain branch operations.

[0001437749-18-002286:8k_2_02:33]
2018 Outlook

[0001437749-18-002286:8k_2_02:34]
The Company is initiating guidance for 2018 with net sales expected to increase between 3 to 5% as compared to the prior year, which includes a favorable foreign currency impact of between 1 to 2%. Excluding the benefit of elevated portable generator shipments during 2017 related to major outage events from the active hurricane season, net sales are expected to increase between 7 to 9% as compared to the prior year. This top-line guidance assumes no major outage events and a baseline power outage severity level similar to the longer-term average. Should the baseline power outage environment in 2018 be higher, or if there is “major” outage activity during the year, it is likely the Company could exceed these expectations.

[0001437749-18-002286:8k_2_02:35]
Net income margins, before deducting for non-controlling interests, are expected to be between 9.5 to 10.0% for the full-year 2018, with adjusted EBITDA margins, also before deducting for non-controlling interests, expected to be between 19.0 to 19.5% for the year.

[0001437749-18-002286:8k_2_02:36]
Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income to free cash flow expected to be over 90%.

[0001437749-18-002286:8k_2_02:37]
Tax Reform

[0001437749-18-002286:8k_2_02:38]
As a result of the Tax Reform Act, the Company recognized a one-time, non-cash gain of $28.4 million in the fourth quarter primarily from the impact of the revaluation of net deferred tax liabilities. Excluding this gain, the effective tax rate during the fourth quarter and full-year 2017 were 34.9% and 35.2%, respectively. While the Company continues to assess the full impact of tax reform, the preliminary analysis suggests a meaningful benefit from the legislation. Specifically for 2018, the effective tax rate is expected to decline to between 25 to 26%, resulting in a corresponding benefit to cash flow of between $10 to $12 million based on the outlook being provided.

[0001437749-18-002286:8k_2_02:39]
Conference Call and Webcast

[0001437749-18-002286:8k_2_02:40]
Generac management will hold a conference call at 9:00 a.m. EST on Tuesday, February 13, 2018 to discuss highlights of the fourth quarter of 2017 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 1776607.

[0001437749-18-002286:8k_2_02:41]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-18-002286:8k_2_02:42]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 1776607. The telephonic replay will be available for 7 days.

[0001437749-18-002286:8k_2_02:43]
About Generac

[0001437749-18-002286:8k_2_02:44]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-002286:8k_2_02:45]
Forward-looking Information

[0001437749-18-002286:8k_2_02:46]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-18-002286:8k_2_02:47]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-18-002286:8k_2_02:48]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-18-002286:8k_2_02:49]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-18-002286:8k_2_02:50]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities and product mix; |

[0001437749-18-002286:8k_2_02:51]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-18-002286:8k_2_02:52]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-18-002286:8k_2_02:53]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-18-002286:8k_2_02:54]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-18-002286:8k_2_02:55]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-18-002286:8k_2_02:56]
|  | ● | loss of key management and employees; |

[0001437749-18-002286:8k_2_02:57]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-18-002286:8k_2_02:58]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-18-002286:8k_2_02:59]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2016 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-18-002286:8k_2_02:60]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-18-002286:8k_2_02:61]
Reconciliations to GAAP Financial Metrics

[0001437749-18-002286:8k_2_02:62]
Adjusted EBITDA

[0001437749-18-002286:8k_2_02:63]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-18-002286:8k_2_02:64]
Adjusted Net Income

[0001437749-18-002286:8k_2_02:65]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-18-002286:8k_2_02:66]
Free Cash Flow

[0001437749-18-002286:8k_2_02:67]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-18-002286:8k_2_02:68]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-18-002286:8k_2_02:69]
SOURCE: Generac Holdings Inc.

[0001437749-18-002286:8k_2_02:70]
CONTACT:

[0001437749-18-002286:8k_2_02:71]
Michael W. Harris

[0001437749-18-002286:8k_2_02:72]
Vice President – Finance

[0001437749-18-002286:8k_2_02:73]
(262) 544-4811 x2675

[0001437749-18-002286:8k_2_02:74]
Michael.Harris@Generac.com

[0001437749-18-002286:8k_2_02:75]
| Generac Holdings Inc. |
| Consolidated Statements of Comprehensive Income |
| (Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-18-002286:8k_2_02:76]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Audited) |  |
| Net sales |  | $ | 488,002 |  |  | $ | 417,421 |  |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |
| Costs of goods sold |  |  | 308,300 |  |  |  | 263,294 |  |  |  | 1,090,328 |  |  |  | 930,347 |  |
| Gross profit |  |  | 179,702 |  |  |  | 154,127 |  |  |  | 582,117 |  |  |  | 514,106 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 44,053 |  |  |  | 40,543 |  |  |  | 171,755 |  |  |  | 164,607 |  |
| Research and development |  |  | 11,193 |  |  |  | 9,717 |  |  |  | 42,925 |  |  |  | 37,229 |  |
| General and administrative |  |  | 23,076 |  |  |  | 19,208 |  |  |  | 87,512 |  |  |  | 74,700 |  |
| Amortization of intangibles |  |  | 7,307 |  |  |  | 7,428 |  |  |  | 28,861 |  |  |  | 32,953 |  |
| Total operating expenses |  |  | 85,629 |  |  |  | 76,896 |  |  |  | 331,053 |  |  |  | 309,489 |  |
| Income from operations |  |  | 94,073 |  |  |  | 77,231 |  |  |  | 251,064 |  |  |  | 204,617 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,314 | ) |  |  | (10,854 | ) |  |  | (42,667 | ) |  |  | (44,568 | ) |
| Investment income |  |  | 241 |  |  |  | 8 |  |  |  | 298 |  |  |  | 44 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (574 | ) |  |  | – |  |  |  | (574 | ) |
| Loss on change in contractual interest rate |  |  | – |  |  |  | – |  |  |  | – |  |  |  | (2,957 | ) |
| Costs related to acquisition |  |  | (405 | ) |  |  | (88 | ) |  |  | (777 | ) |  |  | (1,082 | ) |
| Other, net |  |  | (497 | ) |  |  | 338 |  |  |  | (3,230 | ) |  |  | 902 |  |
| Total other expense, net |  |  | (10,975 | ) |  |  | (11,170 | ) |  |  | (46,376 | ) |  |  | (48,235 | ) |
| Income before provision for income taxes |  |  | 83,098 |  |  |  | 66,061 |  |  |  | 204,688 |  |  |  | 156,382 |  |
| Provision for income taxes |  |  | 607 |  |  |  | 24,416 |  |  |  | 43,553 |  |  |  | 57,570 |  |
| Net income |  |  | 82,491 |  |  |  | 41,645 |  |  |  | 161,135 |  |  |  | 98,812 |  |
| Net income attributable to noncontrolling interests |  |  | 1,316 |  |  |  | 136 |  |  |  | 1,749 |  |  |  | 24 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 81,175 |  |  | $ | 41,509 |  |  | $ | 159,386 |  |  | $ | 98,788 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.31 |  |  | $ | 0.64 |  |  | $ | 2.58 |  |  | $ | 1.51 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,883,857 |  |  |  | 63,021,966 |  |  |  | 62,040,704 |  |  |  | 64,905,793 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.30 |  |  | $ | 0.64 |  |  | $ | 2.56 |  |  | $ | 1.50 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,500,072 |  |  |  | 63,533,112 |  |  |  | 62,642,872 |  |  |  | 65,382,774 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | (825 | ) |  | $ | (7,498 | ) |  | $ | 15,191 |  |  | $ | (18,545 | ) |
| Net unrealized gain on derivatives |  |  | 2,367 |  |  |  | 1,044 |  |  |  | 3,712 |  |  |  | 535 |  |
| Pension liability adjustment |  |  | 62 |  |  |  | 322 |  |  |  | 62 |  |  |  | 322 |  |
| Other comprehensive income (loss) |  |  | 1,604 |  |  |  | (6,132 | ) |  |  | 18,965 |  |  |  | (17,688 | ) |
| Total comprehensive income |  |  | 84,095 |  |  |  | 35,513 |  |  |  | 180,100 |  |  |  | 81,124 |  |
| Comprehensive income (loss) attributable to noncontrolling interests |  |  | 1,721 |  |  |  | (1,727 | ) |  |  | 5,549 |  |  |  | (973 | ) |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 82,374 |  |  | $ | 37,240 |  |  | $ | 174,551 |  |  | $ | 82,097 |  |

[0001437749-18-002286:8k_2_02:77]
6

[0001437749-18-002286:8k_2_02:78]
| Generac Holdings Inc. |
| Consolidated Balance Sheets |
| (Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-18-002286:8k_2_02:79]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 138,472 |  |  | $ | 67,272 |  |
| Accounts receivable, less allowance for doubtful accounts of $4,805 and $5,642 at December 31, 2017 and 2016, respectively |  |  | 280,002 |  |  |  | 241,857 |  |
| Inventories |  |  | 380,341 |  |  |  | 349,731 |  |
| Prepaid expenses and other assets |  |  | 19,741 |  |  |  | 24,649 |  |
| Total current assets |  |  | 818,556 |  |  |  | 683,509 |  |
| Property and equipment, net |  |  | 230,380 |  |  |  | 212,793 |  |
| Customer lists, net |  |  | 41,064 |  |  |  | 45,312 |  |
| Patents, net |  |  | 39,617 |  |  |  | 48,061 |  |
| Other intangible assets, net |  |  | 2,401 |  |  |  | 2,925 |  |
| Tradenames, net |  |  | 152,683 |  |  |  | 158,874 |  |
| Goodwill |  |  | 721,523 |  |  |  | 704,640 |  |
| Deferred income taxes |  |  | 3,238 |  |  |  | 3,337 |  |
| Other assets |  |  | 10,502 |  |  |  | 2,233 |  |
| Total assets |  | $ | 2,019,964 |  |  | $ | 1,861,684 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 20,602 |  |  | $ | 31,198 |  |
| Accounts payable |  |  | 233,639 |  |  |  | 181,519 |  |
| Accrued wages and employee benefits |  |  | 27,992 |  |  |  | 21,189 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 93,068 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 1,572 |  |  |  | 14,965 |  |
| Total current liabilities |  |  | 388,872 |  |  |  | 341,939 |  |
| Long-term borrowings and capital lease obligations |  |  | 906,548 |  |  |  | 1,006,758 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | 17,278 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 61,459 |  |
| Total liabilities |  |  | 1,416,204 |  |  |  | 1,427,434 |  |
| Redeemable noncontrolling interest |  |  | 43,929 |  |  |  | 33,138 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,820,173 and 70,261,481 shares issued at December 31, 2017 and 2016, respectively |  |  | 708 |  |  |  | 702 |  |
| Additional paid-in capital |  |  | 459,816 |  |  |  | 449,049 |  |
| Treasury stock, at cost, 8,448,874 and 7,564,874 shares at December 31, 2017 and 2016, respectively |  |  | (294,005 | ) |  |  | (262,402 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 616,347 |  |  |  | 456,052 |  |
| Accumulated other comprehensive loss |  |  | (21,198 | ) |  |  | (40,163 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 559,552 |  |  |  | 401,122 |  |
| Noncontrolling interests |  |  | 279 |  |  |  | (10 | ) |
| Total stockholders’ equity |  |  | 559,831 |  |  |  | 401,112 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,019,964 |  |  | $ | 1,861,684 |  |

[0001437749-18-002286:8k_2_02:80]
7

[0001437749-18-002286:8k_2_02:81]
| Generac Holdings Inc. |
| Consolidated Statements of Cash Flows |
| (Dollars in Thousands) |

[0001437749-18-002286:8k_2_02:82]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 161,135 |  |  | $ | 98,812 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 23,127 |  |  |  | 21,465 |  |
| Amortization of intangible assets |  |  | 28,861 |  |  |  | 32,953 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,516 |  |  |  | 3,940 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 574 |  |
| Loss on change in contractual interest rate |  |  | – |  |  |  | 2,957 |  |
| Deferred income taxes |  |  | 21,439 |  |  |  | 39,347 |  |
| Share-based compensation expense |  |  | 10,205 |  |  |  | 9,493 |  |
| Other |  |  | 410 |  |  |  | 127 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (29,771 | ) |  |  | (9,082 | ) |
| Inventories |  |  | (16,278 | ) |  |  | 15,514 |  |
| Other assets |  |  | (14,783 | ) |  |  | 406 |  |
| Accounts payable |  |  | 42,788 |  |  |  | 32,908 |  |
| Accrued wages and employee benefits |  |  | 6,105 |  |  |  | 5,196 |  |
| Other accrued liabilities |  |  | 27,514 |  |  |  | 6,719 |  |
| Excess tax benefits from equity awards |  |  | (3,152 | ) |  |  | (7,920 | ) |
| Net cash provided by operating activities |  |  | 261,116 |  |  |  | 253,409 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 82 |  |  |  | 1,360 |  |
| Expenditures for property and equipment |  |  | (33,261 | ) |  |  | (30,467 | ) |
| Acquisition of business, net of cash acquired |  |  | 1,257 |  |  |  | (61,386 | ) |
| Deposit paid related to acquisition |  |  | – |  |  |  | (15,329 | ) |
| Net cash used in investing activities |  |  | (31,922 | ) |  |  | (105,822 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 101,991 |  |  |  | 28,712 |  |
| Proceeds from long-term borrowings |  |  | 3,069 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (114,874 | ) |  |  | (27,755 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (117,475 | ) |  |  | (37,627 | ) |
| Stock repurchases |  |  | (30,012 | ) |  |  | (149,937 | ) |
| Payment of debt issuance costs |  |  | (3,901 | ) |  |  | (4,557 | ) |
| Cash dividends paid |  |  | – |  |  |  | (76 | ) |
| Taxes paid related to equity awards |  |  | (5,892 | ) |  |  | (14,008 | ) |
| Proceeds from the exercise of stock options |  |  | 6,951 |  |  |  | 1,623 |  |
| Excess tax benefits from equity awards |  |  | – |  |  |  | 7,920 |  |
| Net cash used in financing activities |  |  | (160,143 | ) |  |  | (195,705 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,149 |  |  |  | (467 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 71,200 |  |  |  | (48,585 | ) |
| Cash and cash equivalents at beginning of period |  |  | 67,272 |  |  |  | 115,857 |  |
| Cash and cash equivalents at end of period |  | $ | 138,472 |  |  | $ | 67,272 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 41,105 |  |  | $ | 42,456 |  |
| Income taxes |  |  | 23,836 |  |  |  | 8,889 |  |

[0001437749-18-002286:8k_2_02:83]
8

[0001437749-18-002286:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-002286:8k_2_02:85]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 377,851 |  |  | $ | 339,728 |  |  | $ | 1,296,578 |  |  | $ | 1,173,559 |  |
| International |  |  | 110,151 |  |  |  | 77,693 |  |  |  | 375,867 |  |  |  | 270,894 |  |
| Total net sales |  | $ | 488,002 |  |  | $ | 417,421 |  |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 265,516 |  |  | $ | 238,864 |  |  | $ | 870,410 |  |  | $ | 772,436 |  |
| Commercial & industrial products |  |  | 188,316 |  |  |  | 148,136 |  |  |  | 685,052 |  |  |  | 557,532 |  |
| Other |  |  | 34,170 |  |  |  | 30,421 |  |  |  | 116,983 |  |  |  | 114,485 |  |
| Total net sales |  | $ | 488,002 |  |  | $ | 417,421 |  |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |

[0001437749-18-002286:8k_2_02:86]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 100,589 |  |  | $ | 87,907 |  |  | $ | 290,720 |  |  | $ | 261,428 |  |
| International |  |  | 10,539 |  |  |  | 3,909 |  |  |  | 27,010 |  |  |  | 16,959 |  |
| Total adjusted EBITDA (1) |  | $ | 111,128 |  |  | $ | 91,816 |  |  | $ | 317,730 |  |  | $ | 278,387 |  |

[0001437749-18-002286:8k_2_02:87]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-18-002286:8k_2_02:88]
9

[0001437749-18-002286:8k_2_02:89]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (Dollars in Thousands, Except Share and Per Share Data) |
| Net income to Adjusted EBITDA reconciliation |

[0001437749-18-002286:8k_2_02:90]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 81,175 |  |  | $ | 41,509 |  |  | $ | 159,386 |  |  | $ | 98,788 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 1,316 |  |  |  | 136 |  |  |  | 1,749 |  |  |  | 24 |  |
| Net income |  |  | 82,491 |  |  |  | 41,645 |  |  |  | 161,135 |  |  |  | 98,812 |  |
| Interest expense |  |  | 10,314 |  |  |  | 10,854 |  |  |  | 42,667 |  |  |  | 44,568 |  |
| Depreciation and amortization |  |  | 13,297 |  |  |  | 13,075 |  |  |  | 51,988 |  |  |  | 54,418 |  |
| Provision for income taxes |  |  | 607 |  |  |  | 24,416 |  |  |  | 43,553 |  |  |  | 57,570 |  |
| Non-cash write-down and other adjustments (2) |  |  | 291 |  |  |  | (1,332 | ) |  |  | 2,923 |  |  |  | 357 |  |
| Non-cash share-based compensation expense (3) |  |  | 1,803 |  |  |  | 1,688 |  |  |  | 10,205 |  |  |  | 9,493 |  |
| Loss on extinguishment of debt (4) |  |  | – |  |  |  | 574 |  |  |  | - |  |  |  | 574 |  |
| Loss on change in contractual interest rate (5) |  |  | – |  |  |  | – |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and credit facility fees (6) |  |  | 1,175 |  |  |  | 943 |  |  |  | 2,145 |  |  |  | 2,442 |  |
| Business optimization expenses (7) |  |  | 979 |  |  |  | 152 |  |  |  | 2,912 |  |  |  | 7,316 |  |
| Other |  |  | 171 |  |  |  | (199 | ) |  |  | 202 |  |  |  | (120 | ) |
| Adjusted EBITDA |  |  | 111,128 |  |  |  | 91,816 |  |  |  | 317,730 |  |  |  | 278,387 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,486 |  |  |  | 769 |  |  |  | 6,075 |  |  |  | 3,784 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 108,642 |  |  | $ | 91,047 |  |  | $ | 311,655 |  |  | $ | 274,603 |  |

[0001437749-18-002286:8k_2_02:91]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.2 million and $4.7 million for the three months and year ended December 31, 2017, respectively, and $1.1 million and $8.0 million for the three months and year ended December 31, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (5) For the year ended December 31, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time. |
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (7) For the three months and year ended December 31, 2017, represents severance and other non-recurring plant consolidation costs. For the year ended December 31, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. |

[0001437749-18-002286:8k_2_02:92]
10

[0001437749-18-002286:8k_2_02:93]
| Net income to Adjusted net income reconciliation |

[0001437749-18-002286:8k_2_02:94]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 81,175 |  |  | $ | 41,509 |  |  | $ | 159,386 |  |  | $ | 98,788 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 1,316 |  |  |  | 136 |  |  |  | 1,749 |  |  |  | 24 |  |
| Net income |  |  | 82,491 |  |  |  | 41,645 |  |  |  | 161,135 |  |  |  | 98,812 |  |
| Provision for income taxes |  |  | 607 |  |  |  | 24,416 |  |  |  | 43,553 |  |  |  | 57,570 |  |
| Income before provision for income taxes |  |  | 83,098 |  |  |  | 66,061 |  |  |  | 204,688 |  |  |  | 156,382 |  |
| Amortization of intangible assets |  |  | 7,307 |  |  |  | 7,428 |  |  |  | 28,861 |  |  |  | 32,953 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,116 |  |  |  | 711 |  |  |  | 3,516 |  |  |  | 3,940 |  |
| Loss on extinguishment of debt (5) |  |  | – |  |  |  | 574 |  |  |  | - |  |  |  | 574 |  |
| Loss on change in contractual interest rate (6) |  |  | – |  |  |  | – |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 727 |  |  |  | 494 |  |  |  | 1,706 |  |  |  | 5,653 |  |
| Business optimization expenses (7) |  |  | 979 |  |  |  | 152 |  |  |  | 2,912 |  |  |  | 7,316 |  |
| Adjusted net income before provision for income taxes |  |  | 93,227 |  |  |  | 75,420 |  |  |  | 241,683 |  |  |  | 209,775 |  |
| Cash income tax expense (9) |  |  | (6,017 | ) |  |  | (3,704 | ) |  |  | (25,624 | ) |  |  | (9,299 | ) |
| Adjusted net income |  |  | 87,210 |  |  |  | 71,716 |  |  |  | 216,059 |  |  |  | 200,476 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,289 |  |  |  | 280 |  |  |  | 3,201 |  |  |  | 2,219 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 85,921 |  |  | $ | 71,436 |  |  | $ | 212,858 |  |  | $ | 198,257 |  |
| Adjusted net income attributable to Generac Holdings Inc. per |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| common share - diluted: |  | $ | 1.37 |  |  | $ | 1.12 |  |  | $ | 3.40 |  |  | $ | 3.03 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,500,072 |  |  |  | 63,533,112 |  |  |  | 62,642,872 |  |  |  | 65,382,774 |  |

[0001437749-18-002286:8k_2_02:95]
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (9) Amount for the three months and year ended December 31, 2017 is based on an anticipated cash income tax rate of 12.5% for the full year ended 2017. Amount for the three months and year ended December 31, 2016 is based on an anticipated cash income tax rate of 5.9% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-18-002286:8k_2_02:96]
11

[0001437749-18-002286:8k_2_02:97]
| Free Cash Flow Reconciliation |

[0001437749-18-002286:8k_2_02:98]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 138,397 |  |  | $ | 123,896 |  |  | $ | 261,116 |  |  | $ | 253,409 |  |
| Expenditures for property and equipment |  |  | (16,603 | ) |  |  | (9,620 | ) |  |  | (33,261 | ) |  |  | (30,467 | ) |
| Free cash flow |  | $ | 121,794 |  |  | $ | 114,276 |  |  | $ | 227,855 |  |  | $ | 222,942 |  |

[0001437749-18-002286:8k_2_02:99]
| Net Debt to Adjusted EBITDA Leverage Ratio |

[0001437749-18-002286:8k_2_02:100]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Short-term borrowings |  | $ | 20,602 |  |  | $ | 31,198 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 1,572 |  |  |  | 14,965 |  |
| Long-term borrowings and capital lease obligations |  |  | 906,548 |  |  |  | 1,006,758 |  |
| Less: Cash |  |  | (138,472 | ) |  |  | (67,272 | ) |
| Net debt |  |  | 790,250 |  |  |  | 985,649 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  |  | 311,655 |  |  |  | 274,603 |  |
| Net debt to adjusted EBITDA leverage ratio |  |  | 2.5 |  |  |  | 3.6 |  |

[0001437749-18-002286:8k_2_02:101]
12
