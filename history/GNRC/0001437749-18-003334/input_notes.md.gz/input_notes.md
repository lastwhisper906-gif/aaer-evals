# GNRC notes — 0001437749-18-003334


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-18-003334:notes:1]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,576 |  |  | $ | 20,763 |  |
| Long-term portion - other long-term liabilities |  |  | 14,846 |  |  |  | 10,932 |  |
| Total |  | $ | 35,422 |  |  | $ | 31,695 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 10,002 |  |  | $ | 6,728 |  |
| Long-term portion - other long-term liabilities |  |  | 40,939 |  |  |  | 24,352 |  |
| Total |  | $ | 50,941 |  |  | $ | 31,080 |  |


## gnrc:PropertyPlantAndEquipmentEstimatedUsefulLivesTableTextBlock

[0001437749-18-003334:notes:2]
| Land improvements | 8 | – | 20 |
| Buildings and improvements | 10 | – | 40 |
| Machinery and equipment | 3 | – | 15 |
| Dies and tools | 3 | – | 10 |
| Vehicles | 3 | – | 6 |
| Office equipment and systems | 3 | – | 15 |
| Leasehold improvements | 2 | – | 20 |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-18-003334:notes:3]
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Commodity contracts |  | $ | 107 |  |  | $ | 623 |  |
| Foreign currency contracts |  |  | 167 |  |  |  | (150 | ) |
| Interest rate swaps |  |  | 4,356 |  |  |  | (1,739 | ) |


## gnrc:ScheduleOfFairValueOfPlanAssetsTableTextBlock

[0001437749-18-003334:notes:4]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 48,314 |  |  | $ | 48,314 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 9,700 |  |  |  | – |  |  |  | – |  |  |  | 9,700 |  |
| Total |  | $ | 58,014 |  |  | $ | 48,314 |  |  | $ | – |  |  | $ | 9,700 |  |

[0001437749-18-003334:notes:5]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 37,860 |  |  | $ | 37,860 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 8,628 |  |  |  | – |  |  |  | – |  |  |  | 8,628 |  |
| Total |  | $ | 46,488 |  |  | $ | 37,860 |  |  | $ | – |  |  | $ | 8,628 |  |


## gnrc:ScheduleOfIntangibleAssetsTableTextBlock

[0001437749-18-003334:notes:6]
|  |  | Weighted Average |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 9 |  |  | $ | 52,784 |  |  | $ | (28,422 | ) |  | $ | 24,362 |  |  | $ | 50,742 |  |  | $ | (20,189 | ) |  | $ | 30,553 |  |
| Customer lists |  |  | 10 |  |  |  | 340,138 |  |  |  | (299,074 | ) |  |  | 41,064 |  |  |  | 333,935 |  |  |  | (288,623 | ) |  |  | 45,312 |  |
| Patents |  |  | 14 |  |  |  | 131,137 |  |  |  | (91,520 | ) |  |  | 39,617 |  |  |  | 130,099 |  |  |  | (82,038 | ) |  |  | 48,061 |  |
| Unpatented technology |  |  | 15 |  |  |  | 13,169 |  |  |  | (11,915 | ) |  |  | 1,254 |  |  |  | 13,169 |  |  |  | (11,771 | ) |  |  | 1,398 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 8 |  |  |  | 2,684 |  |  |  | (1,537 | ) |  |  | 1,147 |  |  |  | 2,513 |  |  |  | (986 | ) |  |  | 1,527 |  |
| Total finite-lived intangible assets |  |  | $ | 540,958 |  |  | $ | (433,514 | ) |  | $ | 107,444 |  |  | $ | 531,504 |  |  | $ | (404,653 | ) |  | $ | 126,851 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 669,279 |  |  | $ | (433,514 | ) |  | $ | 235,765 |  |  | $ | 659,825 |  |  | $ | (404,653 | ) |  | $ | 255,172 |  |


## gnrc:ValuationAndQualifyingAccountsTableTextBlock

[0001437749-18-003334:notes:7]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 5,642 |  |  | $ | 346 |  |  | $ | (1,842 | ) |  | $ | 659 |  |  | $ | 4,805 |  |
| Reserves for inventory |  |  | 13,031 |  |  |  | 6,164 |  |  |  | (4,036 | ) |  |  | 828 |  |  |  | 15,987 |  |
| Valuation of deferred tax assets |  |  | 4,362 |  |  |  | 2,455 |  |  |  | - |  |  |  | - |  |  |  | 6,817 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,494 |  |  | $ | 1,654 |  |  | $ | (1,110 | ) |  | $ | 2,604 |  |  | $ | 5,642 |  |
| Reserves for inventory |  |  | 10,582 |  |  |  | 5,359 |  |  |  | (5,357 | ) |  |  | 2,447 |  |  |  | 13,031 |  |
| Valuation of deferred tax assets |  |  | 1,523 |  |  |  | 638 |  |  |  | - |  |  |  | 2,201 |  |  |  | 4,362 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,275 |  |  | $ | 481 |  |  | $ | (325 | ) |  | $ | 63 |  |  | $ | 2,494 |  |
| Reserves for inventory |  |  | 9,387 |  |  |  | 3,739 |  |  |  | (3,158 | ) |  |  | 614 |  |  |  | 10,582 |  |
| Valuation of deferred tax assets |  |  | 1,385 |  |  |  | 138 |  |  |  | - |  |  |  | - |  |  |  | 1,523 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-18-003334:notes:8]
Advertising and Co-Op Advertising

[0001437749-18-003334:notes:9]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Total 
expenditures for advertising were 
$45,926,

[0001437749-18-003334:notes:10]
$45,488,
 and 
$39,258
 for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:11]
2016,
 and 
2015,
 respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-18-003334:notes:12]
| 3. | Acquisitions |

[0001437749-18-003334:notes:13]
Acquisition of Pramac

[0001437749-18-003334:notes:14]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in Pramac for a purchase price, net of cash acquired, of 
$60,

[0001437749-18-003334:notes:15]
250.
 Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 
150
 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-18-003334:notes:16]
The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as t
he noncontrolling interest holder has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell their interests to the Company any time within 
five
 years from the date of acquisition. The put option price is either (i) a fixed amount if voluntarily exercised within the 
first

[0001437749-18-003334:notes:17]
two
 years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it 
 may 
redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with 
no
 partial transfers of interest permitted.

[0001437749-18-003334:notes:18]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests
’ share of comprehensive net income (loss), or the estimated redemption value, with any adjustment to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
12,
 “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-18-003334:notes:19]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 33,138 |  |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | 1,540 | (1) |  |  | 34,253 |  |
| Net income |  |  | 1,631 |  |  |  | 100 |  |
| Foreign currency translation |  |  | 8,529 |  |  |  | (2,124 | ) |
| Redemption value adjustment |  |  | (909 | ) |  |  | 909 |  |
| Balance at end of period |  | $ | 43,929 |  |  | $ | 33,138 |  |

[0001437749-18-003334:notes:20]
|  | (1) | Represents the additional noncontrolling interest of Pramac resulting from a common control transaction between the Generac Mobile Products S.r.l. and Pramac UK Limited legal entities. |

[0001437749-18-003334:notes:21]
The Company
 finalized the Pramac purchase price allocation during the 
first
 quarter of 
2017,
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The final purchase price allocation as of the balance sheet date was as follows:

[0001437749-18-003334:notes:22]
|  |  | March 1, 2016 |  |
| Accounts receivable |  | $ | 50,716 |  |
| Inventories |  |  | 39,889 |  |
| Property and equipment |  |  | 19,138 |  |
| Intangible assets |  |  | 34,471 |  |
| Goodwill |  |  | 46,775 |  |
| Other assets |  |  | 7,698 |  |
| Total assets acquired |  |  | 198,687 |  |
| Short-term borrowings |  |  | 21,741 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 23,521 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,250 |  |

[0001437749-18-003334:notes:23]
The goodwill ascribed to this acquisition is 
not
 deductible for tax purp
oses. The accompanying consolidated financial statements include the results of Pramac from the date of acquisition through 
 December 31, 2017.

[0001437749-18-003334:notes:24]
Acquisition of CHP

[0001437749-18-003334:notes:25]
On 
 August 1, 2015,

[0001437749-18-003334:notes:26]
the Company acquired CHP for a purchase price, net of cash acquired, of 
$74,570.
 Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition purchase price was funded solely through cash on hand.

[0001437749-18-003334:notes:27]
The Company 
finalized the CHP purchase price allocation during the 
fourth
 quarter of 
2015
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$75,174
 of intangible assets, including approximately 
$36,284
 of goodwill, as of the acquisition date. The goodwill ascribed to this acquisition is 
not
 deductible for tax purposes. In addition, the Company assumed 
$12,000
 of debt along with this acquisition. The accompanying consolidated financial statements include the results of CHP from the date of acquisition through 
 December 31, 2017.

[0001437749-18-003334:notes:28]
Pro Forma Information

[0001437749-18-003334:notes:29]
The following unaudited pro forma information of the Company gives effect to these acquisitions as though the transactions
 had occurred on 
 January 1, 2015. 
Consolidated net sales on a pro forma basis for the years ended 
 December 31, 2016 
and 
2015
 were 
$1,473,799
 and 
$1,566,459,
 respectively. The pro forma impact of these acquisitions on net income and earnings per share for both the years ended 
 December 31, 2016 
and 
2015
 is 
not
 significant due to amortization related to acquired intangible assets and the fair value step-up of inventory in purchase accounting. This unaudited pro forma information is presented for informational purposes only and is 
not
 necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on 
 January 1, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-18-003334:notes:30]
| 1. | Description of Business |

[0001437749-18-003334:notes:31]
Founded in 
1959,

[0001437749-18-003334:notes:32]
Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-003334:notes:33]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (refer to Item 
1
 in this Annual Report on Form 
10
-K for discussion of our Powering Ahead strategic plan). A summary of recent acquisitions include the following:

[0001437749-18-003334:notes:34]
|  | ● | In August 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout the world. |

[0001437749-18-003334:notes:35]
|  | ● | In November 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expanded the Company’s commercial and industrial product lines. |

[0001437749-18-003334:notes:36]
|  | ● | In September 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expanded Generac’s residential product portfolio in the portable generator category. |

[0001437749-18-003334:notes:37]
|  | ● | In October 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expanded the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-18-003334:notes:38]
|  | ● | In August 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provided an expanded product lineup and additional scale to the Company’s residential engine powered products. |

[0001437749-18-003334:notes:39]
|  | ● | In March 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-18-003334:notes:40]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. While the Motortech acquisition was completed in January 2017, it was funded in the fourth quarter of 2016. |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-18-003334:notes:41]
Cash

[0001437749-18-003334:notes:42]
and Cash

[0001437749-18-003334:notes:43]
Equivalents

[0001437749-18-003334:notes:44]
The Company considers all highly liquid investments purchased with an original maturity of 
three
 months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-18-003334:notes:45]
| 16. | Commitments and Contingencies |

[0001437749-18-003334:notes:46]
The Company leases certain 
manufacturing and office facilities, machinery and computer equipment, automobiles and warehouse space under operating leases. The approximate aggregate minimum rental commitments at 
 December 31, 2017, 
are as follows:

[0001437749-18-003334:notes:47]
| 2018 |  | $ | 9,497 |  |
| 2019 |  |  | 7,786 |  |
| 2020 |  |  | 7,496 |  |
| 2021 |  |  | 6,647 |  |
| 2022 |  |  | 6,633 |  |
| After 2022 |  |  | 5,865 |  |
| Total |  | $ | 43,924 |  |

[0001437749-18-003334:notes:48]
Total rent expense for t
he years ended 
 December 31, 2017,

[0001437749-18-003334:notes:49]
2016
 and 
2015,
 was approximately 
$10,845,

[0001437749-18-003334:notes:50]
$9,146,
 and 
$4,796,
 respectively.

[0001437749-18-003334:notes:51]
The Company has an arrangement with a finance company to provide f
loor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 December 31, 2017 
and 
2016
 was approximately 
$36,500
 and 
$33,900,
 respectively.

[0001437749-18-003334:notes:52]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-18-003334:notes:53]
| 5. | Accumulated Other Comprehensive Loss |

[0001437749-18-003334:notes:54]
The following presents a tabular disclosure of changes in 
AOCL during the years ended 
 December 31, 2017 
and 
2016,
 net of tax:

[0001437749-18-003334:notes:55]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 15,191 |  |  |  | (591 | ) | (1) |  |  | 3,712 | (2) |  |  | 18,312 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 653 |  | (3) |  |  | - |  |  |  | 653 |  |
| Net current-period other comprehensive income |  |  | 15,191 |  |  |  | 62 |  |  |  |  | 3,712 |  |  |  | 18,965 |  |
| Ending Balance – December 31, 2017 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  |  | $ | 2,636 |  |  | $ | (21,198 | ) |

[0001437749-18-003334:notes:56]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (18,545 | ) |  |  | (273 | ) | (4) |  |  | 535 | (5) |  |  | (18,283 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 595 |  | (6) |  |  | - |  |  |  | 595 |  |
| Net current-period other comprehensive income (loss) |  |  | (18,545 | ) |  |  | 322 |  |  |  |  | 535 |  |  |  | (17,688 | ) |
| Ending Balance – December 31, 2016 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  |  | $ | (1,076 | ) |  | $ | (40,163 | ) |

[0001437749-18-003334:notes:57]
|  | (1) | Represents unrecognized actuarial losses of $(800), net of tax benefit of $209, included in the computation of net periodic pension cost for the year ended December 31, 2017. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-18-003334:notes:58]
|  | (2) | Represents unrealized gains of $6,096, net of tax effect of $(2,384) for the year ended December 31, 2017. |

[0001437749-18-003334:notes:59]
|  | (3) | Represents actuarial losses of $883, net of tax effect of $(230), amortized to net periodic pension cost for the year ended December 31, 2017. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-18-003334:notes:60]
|  | (4) | Represents unrecognized actuarial losses of $(412), net of tax benefit of $139, included in the computation of net periodic pension cost for the year ended December 31, 2016. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-18-003334:notes:61]
|  | (5) | Represents unrealized gains of $876, net of tax effect of $(341) for the year ended December 31, 2016. |

[0001437749-18-003334:notes:62]
|  | (6) | Represents actuarial losses of $941, net of tax effect of $(346), amortized to net periodic pension cost for the year ended December 31, 2016. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |


## us-gaap:ConsolidationPolicyTextBlock

[0001437749-18-003334:notes:63]
Principles of Consolidation

[0001437749-18-003334:notes:64]
The consolidated financial statements include the accounts of the Company and its subsidiaries
 that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-003334:notes:65]
| 10. | Credit Agreements |

[0001437749-18-003334:notes:66]
Short-term
 borrowings are included in the consolidated balance sheets as follows:

[0001437749-18-003334:notes:67]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 20,602 |  |  |  | 31,198 |  |
| Total |  | $ | 20,602 |  |  | $ | 31,198 |  |

[0001437749-18-003334:notes:68]
Long-term borrowi
ngs are included in the consolidated balance sheets as follows:

[0001437749-18-003334:notes:69]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,937 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | - |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,690 |  |  |  | 4,647 |  |
| Other |  |  | 1,367 |  |  |  | 14,753 |  |
| Total |  |  | 908,120 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 936 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 636 |  |  |  | 566 |  |
| Total |  | $ | 906,548 |  |  | $ | 1,006,758 |  |

[0001437749-18-003334:notes:70]
Maturities of long-term borrowings (before considering original issue discount and deferred financing costs) outstanding at 
 December 31,

[0001437749-18-003334:notes:71]
2017,
 are as follows:

[0001437749-18-003334:notes:72]
| 2018 |  | $ | 1,572 |  |
| 2019 |  |  | 1,078 |  |
| 2020 |  |  | 599 |  |
| 2021 |  |  | 614 |  |
| After 2021 |  |  | 931,194 |  |
| Total |  | $ | 935,057 |  |

[0001437749-18-003334:notes:73]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-18-003334:notes:74]
Because the Company
’s net debt leverage ratio was above 
3.00
 to 
1.00
 on 
 July 1, 2015, 
it realized a 
25
 basis point increase in borrowing costs in the 
third
 quarter of 
2015.
 As a result, the Company recorded a cumulative catch-up loss of 
$2,381
 in the 
third
 quarter of 
2015,
 which represented the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time. The loss was recorded against original issue discount and deferred financing costs on long-term borrowings in the consolidated balance sheets and as a loss on change in contractual interest rate in the consolidated statement of comprehensive income.

[0001437749-18-003334:notes:75]
As the Company
’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July 1, 2016, 
the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represented the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time. The loss was recorded against original issue discount and deferred financing costs on long-term borrowings in the consolidated balance sheets and as a loss on change in contractual interest rate in the consolidated statement of comprehensive income.

[0001437749-18-003334:notes:76]
I
n 
 May 2015, 
the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 
470
-
50,

[0001437749-18-003334:notes:77]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,528
 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed 
$49
 of transaction fees in the 
second
 quarter of 
2015.

[0001437749-18-003334:notes:78]
In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023.

[0001437749-18-003334:notes:79]
In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$4,242
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings and expensed 
$315
 of transaction fees in the 
fourth
 quarter of 
2016.

[0001437749-18-003334:notes:80]
In 
 May 2017, 
the Company amended its Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees 
paid to creditors as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.

[0001437749-18-003334:notes:81]
In 
 December 2017, 
the Company amended its Term Loan, 
which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and will eliminate future requirements if the Company’s secured leverage ratio is maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings and expensed 
$38
 of transaction fees in the 
fourth
 quarter of 
2017.

[0001437749-18-003334:notes:82]
As of 
 December 31, 2017, 
the Company's secured leverage ratio was 
2.50
 to 
1.00
 times, and the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-18-003334:notes:83]
T
he Company’s credit agreements also originally provided for a 
$150,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was 
 May 31, 2018. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.00%
 or adjusted LIBOR rate plus an applicable margin of 
2.00%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-18-003334:notes:84]
I
n 
 May 2015, 
the Company amended its ABL Facility (Amended ABL Facility). The amendment (i) increased the ABL Facility from 
$150,000
 to 
$250,000
, (ii) extended the maturity date from 
 May 31, 2018 
to 
 May 29, 2020, (
iii) increased the uncommitted incremental facility from 
$50,000
 to 
$100,000,
 (iv) reduced the interest rate spread by 
50
 basis points and (v) reduced the unused line fee by 
12.5
 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$540
 of new debt issuance costs in 
2015.

[0001437749-18-003334:notes:85]
I
n 
 May 2015, 
the Company borrowed 
$100,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. In the 
fourth
 quarter of 
2017,
 the Company repaid the entire outstanding Amended ABL Facility balance. As of 
 December 31, 2017, 
the Company had 
$249,650
 of availability under the Amended ABL Facility, net of outstanding letters of credit.

[0001437749-18-003334:notes:86]
I
n 
 March 
and 
 May 2015, 
the Company made voluntary prepayments of the Term Loan of 
$50,000
 and 
$100,000,
 respectively, which were applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off 
$4,795
 of original issue discount and capitalized debt issuance costs during the year ended 
 December 31, 2015 
as a loss on extinguishment of debt in the consolidated statement of comprehensive income. Similarly, i
n 
 November 2016, 
the Company made a voluntary prepayment of 
$25,000,
 which resulted in a

[0001437749-18-003334:notes:87]
$574
 write-off of original issue discount and capitalized debt issuance costs during the year ended 
 December 31, 2016 
as a loss on extinguishment of debt.

[0001437749-18-003334:notes:88]
As of 
 December 31,

[0001437749-18-003334:notes:89]
201

[0001437749-18-003334:notes:90]
7
 and 
 December 31, 2016, 
short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$20,602
 and 
$31,198,
 respectively.


## us-gaap:DebtPolicyTextBlock

[0001437749-18-003334:notes:91]
Debt Issuance Costs

[0001437749-18-003334:notes:92]
Debt discounts and d
irect costs incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $
3,516,

[0001437749-18-003334:notes:93]
$3,939,
 and 
$5,429
 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 
2017,

[0001437749-18-003334:notes:94]
2016
 and 
2015,
 respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next 
five
 years is as follows: 
2018
 - 
$4,798;

[0001437749-18-003334:notes:95]
2019
 - 
$4,982;

[0001437749-18-003334:notes:96]
2020
 - 
$4,936;

[0001437749-18-003334:notes:97]
2021
 - 
$4,931;

[0001437749-18-003334:notes:98]
2022
 - 
$5,099.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-18-003334:notes:99]
| 4. | Derivative Instruments and Hedging Activities |

[0001437749-18-003334:notes:100]
Commodities

[0001437749-18-003334:notes:101]
The 
Company is exposed to price fluctuations in commodities it uses as raw materials; primarily steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. At both 
 December 31, 2017 
and 
2016,
 the Company had

[0001437749-18-003334:notes:102]
one

[0001437749-18-003334:notes:103]
commodity contract outstanding, covering the purchases of copper.

[0001437749-18-003334:notes:104]
Because these contracts do 
not
 qualify for hedge accounting, 
the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized were 
$377,

[0001437749-18-003334:notes:105]
$739
 and $(
1,909
) for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:106]
Foreign Currencies

[0001437749-18-003334:notes:107]
The Company is exposed to foreign currency exchange risk as a result of transactions
 denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 December 31, 2017 
and 
2016,
 the Company had 
twenty-eight
 and 
thirty-eight
 foreign currency contracts outstanding, respectively.

[0001437749-18-003334:notes:108]
Because these contracts do 
not
 qualify for hedge accounting, 
the related gains and losses are recorded in other, net in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:109]
2016
 and 
2015
 were 
$697,
 $(
385
) and $(
624
), respectively.

[0001437749-18-003334:notes:110]
Interest Rate Swaps

[0001437749-18-003334:notes:111]
I
n 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements; in 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement; and in 
2017,
 the Company entered into 
twenty
 additional interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking these hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL)

[0001437749-18-003334:notes:112]
in the consolidated balance sheets. 
The amount of gains (losses) recognized for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:113]
2016
 and 
2015
 were 
$3,712,

[0001437749-18-003334:notes:114]
$535
 and $(
965
), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-18-003334:notes:115]
Fair Value

[0001437749-18-003334:notes:116]
The following table presents the fair value of the Company
’s derivatives:

[0001437749-18-003334:notes:117]
The fair value of the co
mmodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair value of the interest rate swaps are included in other assets in the consolidated balance sheet as of 
 December 31, 2017. 
The fair value of the commodity contract is included in other assets, the fair value of the foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the consolidated balance sheet as of 
 December 31, 2016. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 December 31, 2017 
and 
2016
 is an asset of 
$4,703
 and a liability of 
$1,295,
 respectively, which represents the amount the Company would receive or need to pay to exit the agreements on those dates.


## us-gaap:DerivativesPolicyTextBlock

[0001437749-18-003334:notes:118]
Derivative Instruments and Hedging Activities

[0001437749-18-003334:notes:119]
The Company records
 all derivatives in accordance with ASC 
815,

[0001437749-18-003334:notes:120]
Derivatives and Hedging
, which requires derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does 
not
 hold or issue derivative financial instruments for trading purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-18-003334:notes:121]
| 15. | Share Plans |

[0001437749-18-003334:notes:122]
The Company adopted an equity incentive plan
 (Plan) on 
 February 10, 2010 
in connection with its initial public offering. The Plan, as amended, allows for granting of up to 
9.1
 million share-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the Plan, net of estimated forfeitures, was 
$10,205,

[0001437749-18-003334:notes:123]
$9,493
 and 
$8,241
 for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:124]
2016
 and 
2015,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-18-003334:notes:125]
Stock Options

[0001437749-18-003334:notes:126]
- Stock options granted in 
2017
 have an exercise price between 
$40.12
 per share and 
$48.98
 per share; stock options granted in 
2016
 have an exercise price between 
$33.23
 per share and 
$35.37
 per share, and the stock options granted in 
2015
 have an exercise price between 
$28.36
 per share and 
$49.70
 per share. Stock options vest in equal installments over 
four
 years, subject to the grantee’s continued employment or service and expire 
ten
 years after the date of grant.

[0001437749-18-003334:notes:127]
S
tock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 
9,033,

[0001437749-18-003334:notes:128]
473,743
 and 
272,296
 in 
2017,

[0001437749-18-003334:notes:129]
2016
 and 
2015,
 respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-18-003334:notes:130]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees
’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total proceeds from the cashless for cash exercise of stock options were 
$6,951
 and 
$1,623
 in 
2017
 and 
2016,
 respectively, and are reflected as a financing activity in the consolidated statement of cash flows.

[0001437749-18-003334:notes:131]
Total payments made by the Company for the employees
’ tax obligations to the taxing authorities were 
$4,301,

[0001437749-18-003334:notes:132]
$13,056
 and 
$9,768
 in 
2017,

[0001437749-18-003334:notes:133]
2016
 and 
2015,
 respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-18-003334:notes:134]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. 
Expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury 
zero
-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history. The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 
2017,

[0001437749-18-003334:notes:135]
2016
 and 
2015
 are as follows:

[0001437749-18-003334:notes:136]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Weighted average grant date fair value |  | $ | 16.84 |  |  | $ | 13.77 |  |  | $ | 19.07 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 40 | % |  |  | 41 | % |  |  | 41 | % |
| Risk free interest rate |  |  | 1.92 | % |  |  | 1.31 | % |  |  | 1.72 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-18-003334:notes:137]
The Company periodically evaluates its forfeiture rates and updates the rates it uses in the determination of its share-based compensation expense. 
The impact of the change to the forfeiture rates on shares-based compensation expense was 
not
 material for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:138]
2016
 and 
2015.

[0001437749-18-003334:notes:139]
A summary of the Company
’s stock option activity and related information for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:140]
2016
 and 
2015
 is as follows:

[0001437749-18-003334:notes:141]
|  |  | Number of Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2014 |  |  | 2,542,139 |  |  | $ | 9.94 |  |  |  | 8.5 |  |  | $ | 96,518 |  |
| Granted |  |  | 287,165 |  |  |  | 45.18 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (604,088 | ) |  |  | 3.79 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (6,409 | ) |  |  | 50.11 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (90,793 | ) |  |  | 37.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2015 |  |  | 2,128,014 |  |  |  | 15.15 |  |  |  | 7.7 |  |  | $ | 40,271 |  |
| Granted |  |  | 398,313 |  |  |  | 33.24 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (995,469 | ) |  |  | 2.89 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (47,894 | ) |  |  | 37.41 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2016 |  |  | 1,482,964 |  |  |  | 27.49 |  |  |  | 7.5 |  |  | $ | 23,840 |  |
| Granted |  |  | 346,421 |  |  |  | 40.13 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (287,375 | ) |  |  | 10.58 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (69,880 | ) |  |  | 41.12 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2017 |  |  | 1,472,130 |  |  |  | 33.11 |  |  |  | 7.3 |  |  | $ | 25,281 |  |
| Exercisable as of December 31, 2017 |  |  | 720,730 |  |  |  | 26.76 |  |  |  | 6.1 |  |  | $ | 17,239 |  |

[0001437749-18-003334:notes:142]
7,
 there was 
$8,552
 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 
2.5
 years. Total share-based compensation cost related to the stock options for 
2017,

[0001437749-18-003334:notes:143]
2016
 and 
2015
 was 
$4,503,

[0001437749-18-003334:notes:144]
$4,366
 and 
$4,198,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-18-003334:notes:145]
Restricted Stock

[0001437749-18-003334:notes:146]
– Restricted stock awards vest in equal installments over 
three
 years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, which were awarded in the years 
2014
 through 
2017.
 The number of performance shares that can be earned are contingent upon Company performance measures over a 
three
-year period. Performance measures are based on a weighting of revenue growth and EBITDA margin, from which grantees 
 may 
earn from 
0%
 to 
200%
 of their target performance share award. The performance period for the 
2015
 awards covers the years 
2015
 through 
2017,
 the performance period for the 
2016
 awards covers the years 
2016
 through 
2018,
 and the performance period for the 
2017
 awards covers the years 
2017
 through 
2019.
 The Company estimates the number of performance shares that will vest based on projected financial performance. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-18-003334:notes:147]
Restricted stock vesting is net-share settled such that
, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies as treasury stock. Total shares withheld were 
39,500,

[0001437749-18-003334:notes:148]
28,593
 and 
65,763
 in 
2017,

[0001437749-18-003334:notes:149]
2016
 and 
2015,
 respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company for the employees’ tax obligations to the taxing authorities were 
$1,591,

[0001437749-18-003334:notes:150]
$952
 and 
$3,233
 in 
2017,

[0001437749-18-003334:notes:151]
A summary of the Company's restricted 
stock activity for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:152]
|  |  | Shares |  |  | Weighted- Average Grant- Date Fair Value |  |
| Non-vested as of December 31, 2014 |  |  | 267,284 |  |  | $ | 38.72 |  |
| Granted |  |  | 193,117 |  |  |  | 41.31 |  |
| Vested |  |  | (183,362 | ) |  |  | 32.56 |  |
| Forfeited |  |  | (33,999 | ) |  |  | 47.77 |  |
| Non-vested as of December 31, 2015 |  |  | 243,040 |  |  |  | 44.16 |  |
| Granted |  |  | 232,295 |  |  |  | 33.56 |  |
| Vested |  |  | (95,858 | ) |  |  | 41.93 |  |
| Forfeited |  |  | (18,074 | ) |  |  | 38.30 |  |
| Non-vested as of December 31, 2016 |  |  | 361,403 |  |  |  | 38.18 |  |
| Granted |  |  | 211,769 |  |  |  | 39.91 |  |
| Vested |  |  | (133,796 | ) |  |  | 40.60 |  |
| Forfeited |  |  | (47,100 | ) |  |  | 42.48 |  |
| Non-vested as of December 31, 2017 |  |  | 392,276 |  |  |  | 37.77 |  |

[0001437749-18-003334:notes:153]
As of

[0001437749-18-003334:notes:154]
December 31, 2017, 
there was 
$7,702
 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 
1.7
 years.

[0001437749-18-003334:notes:155]
Total share-based compensation cost related to the restricted stock for 
2017,

[0001437749-18-003334:notes:156]
2016
 and 
2015
 was 
$5,702,

[0001437749-18-003334:notes:157]
$5,127
 and 
$4,043,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-18-003334:notes:158]
During 
201

[0001437749-18-003334:notes:159]
7,

[0001437749-18-003334:notes:160]
2016
 and 
2015,

[0001437749-18-003334:notes:161]
34,095,

[0001437749-18-003334:notes:162]
19,326
 and 
16,260
 shares, respectively, of stock were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, of which 
22,762,

[0001437749-18-003334:notes:163]
19,326
 and 
16,260
 shares, respectively, were fully vested. Total share-based compensation cost for these share grants in 
2017,

[0001437749-18-003334:notes:164]
2016
 and 
2015
 was 
$1,133,

[0001437749-18-003334:notes:165]
$670
 and 
$615,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-003334:notes:166]
| 12. | Earnings Per Share |

[0001437749-18-003334:notes:167]
Basic earnings per share is calculated by dividing net income
 attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-18-003334:notes:168]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,386 |  |  | $ | 98,788 |  |  | $ | 77,747 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 909 |  |  |  | (909 | ) |  |  | - |  |
| Net income attributable to common shareholders |  | $ | 160,295 |  |  | $ | 97,879 |  |  | $ | 77,747 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,040,704 |  |  |  | 64,905,793 |  |  |  | 68,096,051 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 602,168 |  |  |  | 476,981 |  |  |  | 1,104,246 |  |
| Diluted shares |  |  | 62,642,872 |  |  |  | 65,382,774 |  |  |  | 69,200,297 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.58 |  |  | $ | 1.51 |  |  | $ | 1.14 |  |
| Diluted |  | $ | 2.56 |  |  | $ | 1.50 |  |  | $ | 1.12 |  |

[0001437749-18-003334:notes:169]
|  | (1) | Excludes approximately 147,400, 15,800 and 161,400 stock options for the years ended December 31, 2017, 2016 and 2015, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 1,000 shares of restricted stock for the year ended December 31, 2015, as the impact of such awards was anti-dilutive. |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001437749-18-003334:notes:170]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 8,628 |  |  | $ | 3,675 |  |
| Purchases |  |  | - |  |  |  | 4,400 |  |
| Realized gains |  |  | 1,072 |  |  |  | 553 |  |
| Balance at end of period |  | $ | 9,700 |  |  | $ | 8,628 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-18-003334:notes:171]
Foreign Currency Translation and Transactions

[0001437749-18-003334:notes:172]
Balance sheet amounts for non-U.S. Dollar functional currency businesses
 are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-18-003334:notes:173]
| 8. | Goodwill and Intangible Assets |

[0001437749-18-003334:notes:174]
The changes in the carrying amount of goodwill 
by reportable segment for the years ended 
 December 31, 2017 
and 
2016
 are as follows:

[0001437749-18-003334:notes:175]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2015 |  | $ | 621,451 |  |  | $ | 48,268 |  |  | $ | 669,719 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 46,202 |  |  |  | 46,202 |  |
| Foreign currency translation |  |  | - |  |  |  | (11,281 | ) |  |  | (11,281 | ) |
| Balance at December 31, 2016 |  |  | 621,451 |  |  |  | 83,189 |  |  |  | 704,640 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 5,271 |  |  |  | 5,271 |  |
| Foreign currency translation |  |  | - |  |  |  | 11,612 |  |  |  | 11,612 |  |
| Balance at December 31, 2017 |  | $ | 621,451 |  |  | $ | 100,072 |  |  | $ | 721,523 |  |

[0001437749-18-003334:notes:176]
The detail
s of the gross goodwill applicable to each reportable segment at 
 December 31, 2017 
and 
2016
 are as follows:

[0001437749-18-003334:notes:177]
|  |  | Year Ended December 31, 2017 |  |  | Year Ended December 31, 2016 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |
| International |  |  | 104,683 |  |  |  | (4,611 | ) |  |  | 100,072 |  |  |  | 87,800 |  |  |  | (4,611 | ) |  |  | 83,189 |  |
| Total |  | $ | 1,229,327 |  |  | $ | (507,804 | ) |  | $ | 721,523 |  |  | $ | 1,212,444 |  |  | $ | (507,804 | ) |  | $ | 704,640 |  |

[0001437749-18-003334:notes:178]
Refer to 
Note 
3,
 “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions and Note 
2,
 “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 
2015
 goodwill impairment charge.

[0001437749-18-003334:notes:179]
The following table summarizes intangible assets by major category as of Decembe
r 
31,

[0001437749-18-003334:notes:180]
2017
 and 
2016:

[0001437749-18-003334:notes:181]
Refer to 
Note 
2,
 “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 
2015
 brand strategy change and resulting tradename impairment charge, which was netted against the gross intangible asset balance at 
 December 31, 2017 
and 
2016.

[0001437749-18-003334:notes:182]
Amortization of intangible 
assets was 
$28,861,

[0001437749-18-003334:notes:183]
$32,953
 and 
$23,591
 in 
2017,

[0001437749-18-003334:notes:184]
2016
 and 
2015,
 respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next 
five
 years will be as follows: 
2018
 - 
$20,566;

[0001437749-18-003334:notes:185]
2019
 - 
$18,828;

[0001437749-18-003334:notes:186]
2020
 - 
$18,737;

[0001437749-18-003334:notes:187]
2021
 - 
$16,927;

[0001437749-18-003334:notes:188]
2022
 - 
$9,671.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001437749-18-003334:notes:189]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-18-003334:notes:190]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is 
not
 amortized, but is reviewed for impairment on an annual basis and between annual tests 
if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of 
 October 31 
or more frequently when an event occurs or circumstances change that indicates the carrying value 
 may

[0001437749-18-003334:notes:191]
not
 be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is 
not
 more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is 
not
 required to be performed. If the Company determines that it is more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is 
not
 impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-18-003334:notes:192]
Other indefinite-lived intangible assets consist of certain tradenames. 
The Company tests the carrying value of these tradenames annually as of 
 October 31 
or more frequently when an event occurs or circumstances change that indicates the carrying value 
 may

[0001437749-18-003334:notes:193]
not
 be recoverable by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company 
not
 owned the tradename and instead licensed the tradename from another company.

[0001437749-18-003334:notes:194]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 
201

[0001437749-18-003334:notes:195]
2016
 and 
2015,
 and found

[0001437749-18-003334:notes:196]
no

[0001437749-18-003334:notes:197]
impairment following the 
2017
 and 
2016
 tests. There were 
no
 reporting units with a carrying value at-risk of exceeding fair value as of the 
 October 31, 2017 
impairment test date.

[0001437749-18-003334:notes:198]
After performing the impairment tests for fiscal year 
2015,
 t
he Company determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge in the 
fourth
 quarter of 
2015
 of 
$4,611
 to write-down the balance of the Ottomotores goodwill. The decrease in fair value of the Ottomotores reporting unit was due to several factors in the 
second
 half of 
2015:
 the continued challenges of the Latin American economies, devaluation of the Peso against the U.S. Dollar, the slow development of Mexican energy reform as a result of decreasing oil prices; combining to cause 
2015
 results to fall short of prior expectations and future forecasts to decrease. The fair value was determined using a discounted cash flow analysis, which utilized key financial assumptions including the sales growth factors discussed above, a 
3%
 terminal growth rate and a 
15.7%
 discount rate.

[0001437749-18-003334:notes:199]
In the 
fourth
 quarter of 
2015,
 the Company
’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired in acquisitions to the Generac® tradename. This brand strategy change resulted in a reclassification to a 
two
 year remaining useful life for the impacted tradenames, causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a 
$36,076
 non-cash impairment charge was recorded to write-down the impacted tradenames to net realizable value.

[0001437749-18-003334:notes:200]
Other than the impairment charges discussed above, the Company found 
no
 other impairment when performing the required annual
 impairment tests for goodwill and other indefinite-lived intangible assets for fiscal year 
2015.
 There can be 
no
 assurance that future impairment tests will 
not
 result in a charge to earnings.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001437749-18-003334:notes:201]
Impairment of

[0001437749-18-003334:notes:202]
Long-Lived Assets

[0001437749-18-003334:notes:203]
The Company periodically evaluates the carrying value of long-lived asset
s (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount 
 may

[0001437749-18-003334:notes:204]
not
 be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-003334:notes:205]
| 13. | Income Taxes |

[0001437749-18-003334:notes:206]
The Company
’s provision for income taxes consists of the following:

[0001437749-18-003334:notes:207]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 15,753 |  |  | $ | 11,717 |  |  | $ | 13,614 |  |
| State |  |  | 1,775 |  |  |  | 2,047 |  |  |  | 1,966 |  |
| Foreign |  |  | 4,585 |  |  |  | 4,460 |  |  |  | 3,588 |  |
|  |  |  | 22,113 |  |  |  | 18,224 |  |  |  | 19,168 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 17,737 |  |  |  | 41,264 |  |  |  | 31,869 |  |
| State |  |  | 4,026 |  |  |  | 3,029 |  |  |  | 1,387 |  |
| Foreign |  |  | (2,777 | ) |  |  | (5,585 | ) |  |  | (7,326 | ) |
|  |  |  | 18,986 |  |  |  | 38,708 |  |  |  | 25,930 |  |
| Change in valuation allowance |  |  | 2,454 |  |  |  | 638 |  |  |  | 138 |  |
| Provision for income taxes |  | $ | 43,553 |  |  | $ | 57,570 |  |  | $ | 45,236 |  |

[0001437749-18-003334:notes:208]
The Company files U.S federal, U.S. state and foreign jurisdiction tax returns that are subject to examination up to the expiration of the statute of limitations. We believe the tax positions taken on our returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded.
 As of 
 December 31, 2017 
the Company is 
no
 longer subject to income tax examinations for United States federal income taxes for the tax years prior to 
2

[0001437749-18-003334:notes:209]
014.
 Due to the carryforward of net operating losses, and research and development credits, the Company's Wisconsin state income tax returns for tax years 
2007
 through 
2016
 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 
2012
 through 
2016.

[0001437749-18-003334:notes:210]
The Company is currently under examination in multiple jurisdictions and is working to address all matters. While the Compa
ny does 
not
 believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination 
 may 
result in differences from what was recorded. Such differences 
 may 
affect the provision for income taxes in the period in which the determination is made, and could impact the Company’s financial results.

[0001437749-18-003334:notes:211]
On 
 December 22, 2017, 
the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code, including, but 
not
 limited to, reducing the U.S. federal corporate tax rate from 
35%
 to 
21%
, requiring companies to pay a 
one
-time transition tax on certain unrepatriated earnings of foreign subsidiaries, eliminating certain deductions, introducing new tax regimes, changing how foreign earnings are subject to U.S. tax, and enhancing and extending through 
2026
 the option to claim accelerated depreciation deductions on qualified property.

[0001437749-18-003334:notes:212]
The SEC staff issued SAB 
118,
 which provides guidance on accounting for the tax effects of the Tax Act. SAB 
118
 provides a measurement period that should 
not
 extend beyond 
one
 year from the Tax Act enactment date for companies to complete the accounting under ASC 
740.
 In accordance with SAB 
118,
 a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 
740
 is complete. To the extent that a company
’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 
740
 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001437749-18-003334:notes:213]
The Company's accounting for the following elements of the Tax Act is incomplete. However, reasonable estimates of certain effects were able to be made and, therefore, provisional adjustments were recorded as follows:

[0001437749-18-003334:notes:214]
Reduction of US federal corporate tax rate:

[0001437749-18-003334:notes:215]
The Tax Act reduces the federal corporate tax rate to 
21%
, effective 
 January 1, 2018. 
For certain of the Company's deferred tax liabilities (DTLs), a provisional decrease of 
$28,434
 was recorded to reflect our DTLs at thelower corporate tax rate, with a corresponding net adjustment to deferred income tax benefit of 
$28,434
 for the year ended 
 December 31, 2017. 
While a reasonable estimate of the impact of the reduction in the corporate tax rate was made, it 
 may 
be affected by other analyses related to the Tax Act, including, but 
not
 limited to, the calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences.

[0001437749-18-003334:notes:216]
Deemed Repatriation Transition Tax:

[0001437749-18-003334:notes:217]
The Deemed Repatriation Transition Tax (Transition Tax) is a tax on previously untaxed accumulated and current earnings and profits (E&P) of certain of the Company
’s foreign subsidiaries. To determine the amount of the Transition Tax, the amount of post-
1986
 E&P of relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings must be determined, in addition to other factors. The Company made a reasonable estimate of the Transition Tax and has concluded the amount was 
not
 material.

[0001437749-18-003334:notes:218]
Cost recovery:

[0001437749-18-003334:notes:219]
While the Company has 
not
 yet completed all of the computations necessary or completed an inventory of our 
2017
 expenditures that qualify for immediate expensing, a provisional benefit of 
$700
 was recorded based on our current intent to fully expense all qualifying expenditures. This resulted in a decrease of approximately 
$1,750
 to current income tax payable and a corresponding increase in DTLs of approximately 
$1,050
 (after considering the effects of the reduction in income tax rates).

[0001437749-18-003334:notes:220]
As the Company completes its analysis of the Tax Act; collects and prepares necessary data; and interprets any additional guidance issued by the U.S. Treasury Department, the IRS, and other standard-setting bodies; adjustments to the provisional amounts 
 may 
be recorded.

[0001437749-18-003334:notes:221]
Global intangible low taxed income (GILTI):

[0001437749-18-003334:notes:222]
Because of the complexity of the new GILTI tax rules, the Company is continuing to evaluate this provision of the Tax Act and the application of ASC 
740.
 Under U.S. GAAP, the Company is allowed to make an accounting policy choice of either (
1
) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (
2
) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). The selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing the Company's global income to determine whether it is expected to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be. Because whether the Company expects to have future U.S. inclusions in taxable income related to GILTI depends 
not
 only on the current structure and estimated future results of global operations but also on the intent and ability to modify the structure and/or the business; the Company is not yet able to reasonably estimate the effect of this provision of the Tax Act. Therefore, 
no
 adjustments related to potential GILTI tax have been made in the financial statements and 
no
 policy decision regarding whether to record deferred taxes on GILTI has been made.

[0001437749-18-003334:notes:223]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-18-003334:notes:224]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 15,138 |  |  | $ | 22,758 |  |
| Deferred revenue |  |  | 8,060 |  |  |  | 10,645 |  |
| Inventories |  |  | 7,933 |  |  |  | 10,159 |  |
| Pension obligations |  |  | 3,795 |  |  |  | 7,512 |  |
| Stock-based compensation |  |  | 5,522 |  |  |  | 7,291 |  |
| Operating loss and credit carryforwards |  |  | 23,771 |  |  |  | 20,927 |  |
| Other |  |  | 1,064 |  |  |  | 2,822 |  |
| Valuation allowance |  |  | (6,817 | ) |  |  | (4,362 | ) |
| Total deferred tax assets |  |  | 58,466 |  |  |  | 77,752 |  |
| Deferred tax liabilitites: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 70,556 |  |  |  | 58,133 |  |
| Depreciation |  |  | 22,563 |  |  |  | 25,194 |  |
| Debt refinancing costs |  |  | 5,189 |  |  |  | 7,193 |  |
| Prepaid expenses |  |  | 709 |  |  |  | 1,173 |  |
| Total deferred tax liabilities |  |  | 99,017 |  |  |  | 91,693 |  |
| Net deferred tax liabilities |  | $ | (40,551 | ) |  | $ | (13,941 | ) |

[0001437749-18-003334:notes:225]
7
 and 
2016,
 deferred tax assets of 
$3,238
 and 
$3,337,
 and deferred tax liabilities of 
$43,789
 and 
$17,278,
 respectively, were reflected on the consolidated balance sheets.

[0001437749-18-003334:notes:226]
One of the Company's subsidiaries, Generac Brazil, 
has generated net operating losses for multiple years. The realizability of the deferred tax assets associated with these net operating losses is uncertain, therefore a valuation allowance has been recorded since Generac Brazil's acquisition on 
 December 8, 2012 
and continued through 
 December 31, 2017.

[0001437749-18-003334:notes:227]
In addition, the Company recorded a valuation allowance in the opening balance sheet and as of 
 December 31,

[0001437749-18-003334:notes:228]
2017
 and 
2016
 related to the Pramac acquisition. The valuation allowance represents a reserve for deferred tax assets, including loss carryforwards, of certain Pramac subsidiaries, for which utilization is uncertain.

[0001437749-18-003334:notes:229]
At 
 December 31,

[0001437749-18-003334:notes:230]
7,
 the Company had state research and development tax credit carryforwards, and state manufacturing tax credit carryforwards of approximately 
$13,089
 and 
$4,618,
 respectively, which expire between 
2018
 and 
2032.
 A valuation allowance of 
$1,171
 has been established against deferred tax assets for these carryforwards.

[0001437749-18-003334:notes:231]
Changes in the Company
’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-18-003334:notes:232]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 7,943 |  |  | $ | 7,239 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 251 |  |  |  | 704 |  |
| Statute of limitation expirations |  |  | (1,072 | ) |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 7,122 |  |  | $ | 7,943 |  |

[0001437749-18-003334:notes:233]
The unrecognized tax
 benefit as of 
 December

[0001437749-18-003334:notes:234]
31,

[0001437749-18-003334:notes:235]
2017
 and 
2016,
 if recognized, would impact the effective tax rate.

[0001437749-18-003334:notes:236]
As of 
 December

[0001437749-18-003334:notes:237]
2017,

[0001437749-18-003334:notes:238]
2016
 and 
2015,
 total accrued interest of approximately 
$131,

[0001437749-18-003334:notes:239]
$272
 and 
$174,
 respectively, and accrued penalties of approximately 
$220,

[0001437749-18-003334:notes:240]
$425
 and 
$363,
 respectively, associated with net unrecognized tax benefits are included in the Company’s consolidated balance sheets. 
Interest and penalties are recorded as a component of income tax expense.

[0001437749-18-003334:notes:241]
T
he Company does 
not
 expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending 
 December

[0001437749-18-003334:notes:242]
2018.

[0001437749-18-003334:notes:243]
The Tax Act includes a mandatory 
one
-time tax on accumulated earnings of foreign subsidiaries, and as a result, all previously
 unremitted earnings for which 
no
 U.S. deferred tax liability had been accrued have now been subject to U.S. tax. Notwithstanding the U.S. taxation of these amounts, the Company intends to continue to invest these earnings, as well as the capital in these subsidiaries, indefinitely outside of the U.S. and do 
not
 expect to incur any significant, additional taxes related to such amounts.

[0001437749-18-003334:notes:244]
A reconciliation
 of the statutory tax rates and the effective tax rates for the years ended 
 December 31, 2017

[0001437749-18-003334:notes:245]
, 
2016
 and 
2015
 are as follows:

[0001437749-18-003334:notes:246]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| U.S. statutory rate |  |  | 35.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 4.1 |  |  |  | 4.1 |  |  |  | 4.1 |  |
| Research and development credits |  |  | (1.4 | ) |  |  | (1.0 | ) |  |  | (2.3 | ) |
| Share-based compensation (1) |  |  | (1.4 | ) |  |  | - |  |  |  | - |  |
| Tax Act impact |  |  | (13.9 | ) |  |  | - |  |  |  | - |  |
| Other |  |  | (1.1 | ) |  |  | (1.3 | ) |  |  | - |  |
| Effective tax rate |  |  | 21.3 | % |  |  | 36.8 | % |  |  | 36.8 | % |

[0001437749-18-003334:notes:247]
|  | (1) | With the adoption of ASU 2016-09 in the first quarter of 2017, excess tax benefits from equity awards are reflected within the provision for income taxes rather than within the consolidated balance sheet. For further information on the Company’s adoption of ASU 2016-09, refer to Note 2, “Significant Accounting Policies – New Accounting Pronouncements” to the consolidated financial statements. |


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-18-003334:notes:248]
Income Taxes

[0001437749-18-003334:notes:249]
The Company is
 a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than 
not
 that some portion or all of the deferred tax assets will 
not
 be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.


## us-gaap:InventoryPolicyTextBlock

[0001437749-18-003334:notes:250]
Inventories

[0001437749-18-003334:notes:251]
Inventories are stated at the lower of cost or 
market, with cost determined generally using the 
first
-in, 
first
-out method.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-18-003334:notes:252]
New Accounting Pronouncements

[0001437749-18-003334:notes:253]
In 
 May 2014, 
the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

[0001437749-18-003334:notes:254]
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a 
five
-step process that entities should follow in order to achieve that core principal. ASU 
2014
-
09,
 as amended by ASU 
2015
-
14,

[0001437749-18-003334:notes:255]
Revenue from Contracts with Customers (Topic

[0001437749-18-003334:notes:256]
606
): D

[0001437749-18-003334:notes:257]
eferral of the Effective Date
, ASU 
2016
-
08,

[0001437749-18-003334:notes:258]
Revenue from Contracts with Customers (Topic 
606
): Principal versus Agent Considerations
, ASU 
2016
-
10,

[0001437749-18-003334:notes:259]
Revenue from Contracts with Customers (Topic 
606
): Identifying Performance Obligations and Licensin

[0001437749-18-003334:notes:260]
g, 
ASU 
2016
-
12,

[0001437749-18-003334:notes:261]
Revenue from Contracts with Customers (Topic 
606
):

[0001437749-18-003334:notes:262]
Narrow-

[0001437749-18-003334:notes:263]
Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

[0001437749-18-003334:notes:264]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, becomes effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company has completed its assessment of the impacts the standard will have on its financial statements, and determined that the adoption does 
not
 have a material impact. In all material respects, the Company has identified a similar amount of performance obligations under the new guidance as compared with deliverables previously identified. As a result, the timing of revenue recognition will generally remain the same. The Company adopted the standard 
 January 1, 2018 
and will use the full retrospective method.

[0001437749-18-003334:notes:265]
In 
 February 2016, 
the FASB issued ASU 
2016
-
02,

[0001437749-18-003334:notes:266]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-003334:notes:267]
In 
 August 2016, 
the FASB issued ASU 
2016
-
15,

[0001437749-18-003334:notes:268]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does 
not
 believe that the adoption of this guidance will have a significant impact on the presentation of the statement of cash flows.

[0001437749-18-003334:notes:269]
In 
 January 2017, 
the FASB issued ASU 
2017
-
04,

[0001437749-18-003334:notes:270]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance was issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should 
not
 exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 The Company has early adopted this standard, which did 
not
 have a significant impact on its consolidated financial statements.

[0001437749-18-003334:notes:271]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-18-003334:notes:272]
Derivatives and Hedging

[0001437749-18-003334:notes:273]
–

[0001437749-18-003334:notes:274]
Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. For existing hedges, this guidance should be applied using a cumulative effect adjustment, while the presentation and disclosure guidance should be adopted on a prospective basis. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-003334:notes:275]
In the 
first
 quarter of 
2017,
 the Company adopted ASU 
2016
-
09,

[0001437749-18-003334:notes:276]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the consolidated statement of comprehensive income rather than within additional paid-in capital on the consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid in exchange for withheld shares had 
no
 impact to any period presented on the consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.

[0001437749-18-003334:notes:277]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these accounting pronouncements has had or will have a material impact on the Company
’s consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-18-003334:notes:278]
| 14. | Benefit Plans |

[0001437749-18-003334:notes:279]
Medical and Dental Plan

[0001437749-18-003334:notes:280]
The Company maintains medical and dental benefit plans covering 
its full-time domestic employees and their dependents. Certain plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were 
$14,992,

[0001437749-18-003334:notes:281]
$15,019,
 and 
$14,352
 for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:282]
The Company
’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations

[0001437749-18-003334:notes:283]
. The expenses related to these plans are 
not
 material to the Company’s consolidated financial statements.

[0001437749-18-003334:notes:284]
S
avings Plan

[0001437749-18-003334:notes:285]
The Company maintains
 a defined-contribution 
401
(k) savings plan for eligible domestic employees. Under the plan, employees 
 may 
defer receipt of a portion of their eligible compensation. The Company amended the 
401
(k) savings plans effective 
 January 1, 2009, 
to add Company matching and non-elective contributions. The Company 
 may 
contribute a matching contribution of 
50%
 of the 
first

[0001437749-18-003334:notes:286]
6%
 of eligible compensation of employees. The Company 
 may 
also contribute a non-elective contribution for eligible employees employed on 
 December 31, 2008. 
Both Company matching contributions and non-elective contributions are subject to vesting. Forfeitures 
 may 
be applied against plan expenses and company contributions. The Company recognized 
$3,600,

[0001437749-18-003334:notes:287]
$3,400
 and 
$3,000
 of expense related to these plans in 
2017,

[0001437749-18-003334:notes:288]
2016
 and 
2015,
 respectively.

[0001437749-18-003334:notes:289]
Pension Plans

[0001437749-18-003334:notes:290]
The Company has
 frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. 
The Pension Plans were frozen effective 
 December 31, 2008.

[0001437749-18-003334:notes:291]
The benefits under the salaried plan are based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan are based on a unit amount at the date of termination multiplied by the participant’s years of credited service. The Company’s funding policy for the Pension Plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations.

[0001437749-18-003334:notes:292]
The Company uses a 
 December 31 
measurement date for the Pension Plans. 
The accumulated benefit obligation, reconciliation of the changes in projected benefit obligation, changes in plan assets and the funded status of the Pension Plans are as follows:

[0001437749-18-003334:notes:293]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Accumulated benefit obligation at end of period |  | $ | 72,631 |  |  | $ | 65,956 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 65,956 |  |  | $ | 63,894 |  |
| Interest cost |  |  | 2,688 |  |  |  | 2,747 |  |
| Net actuarial loss |  |  | 6,170 |  |  |  | 1,363 |  |
| Benefits paid |  |  | (2,183 | ) |  |  | (2,048 | ) |
| Projected benefit obligation at end of period |  | $ | 72,631 |  |  | $ | 65,956 |  |
| Change in plan assets |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 46,488 |  |  | $ | 43,985 |  |
| Actual return on plan assets |  |  | 8,382 |  |  |  | 3,820 |  |
| Company contributions |  |  | 5,327 |  |  |  | 731 |  |
| Benefits paid |  |  | (2,183 | ) |  |  | (2,048 | ) |
| Fair value of plan assets at end of period |  | $ | 58,014 |  |  | $ | 46,488 |  |
| Funded status: accrued pension liability included in other long-term liabilities |  | $ | (14,617 | ) |  | $ | (19,468 | ) |
| Amounts recognized in accumulated other comprehensive loss |  |  |  |  |  |  |  |  |
| Net actuarial loss, net of tax |  | $ | (10,978 | ) |  | $ | (11,040 | ) |

[0001437749-18-003334:notes:294]
The 
actuarial loss for the Pension Plans that was amortized from AOCL into net periodic (benefit) cost during 
2017
 is 
$883.
 The amount in AOCL as of 
 December 31, 2017 
that is expected to be recognized as a component of net periodic pension expense during the next fiscal year is 
$802.

[0001437749-18-003334:notes:295]
The 
components of net periodic pension cost are as follows:

[0001437749-18-003334:notes:296]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Interest cost |  | $ | 2,688 |  |  | $ | 2,747 |  |  | $ | 2,681 |  |
| Expected return on plan assets |  |  | (3,011 | ) |  |  | (2,868 | ) |  |  | (3,041 | ) |
| Amortization of net loss |  |  | 883 |  |  |  | 941 |  |  |  | 1,228 |  |
| Net periodic pension cost |  | $ | 560 |  |  | $ | 820 |  |  | $ | 868 |  |

[0001437749-18-003334:notes:297]
Weighted-average assumptions used to determine 
the benefit obligations are as follows:

[0001437749-18-003334:notes:298]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Discount rate – salaried pension plan |  |  | 3.60 | % |  |  | 4.14 | % |
| Discount rate – hourly pension plan |  |  | 3.62 | % |  |  | 4.16 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |

[0001437749-18-003334:notes:299]
|  | (1) | No compensation increase was assumed as the plans were frozen effective December 31, 2008. |

[0001437749-18-003334:notes:300]
Weighted-average assumptions used to
 determine net periodic pension cost are as follows:

[0001437749-18-003334:notes:301]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Discount rate |  |  | 4.14 | % |  |  | 4.39 | % |  |  | 3.99 | % |
| Expected long-term rate of return on plan assets |  |  | 6.58 | % |  |  | 6.62 | % |  |  | 6.75 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |

[0001437749-18-003334:notes:302]
To determine the long-term rate of return assumption for the plans' assets, the Company studies historical markets and preserves the long-term historical relationships between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluates current market factors such as inflation and interest rates before it determines long-term capital market assumptions and reviews peer data and historical returns to check for reasonableness and 
appropriateness.

[0001437749-18-003334:notes:303]
The Pension Plans
’ weighted-average asset allocation at 
 December 31, 2017 
and 
2016,
 by asset category, is as follows:

[0001437749-18-003334:notes:304]
|  |  | Target Allocation |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Asset Category |  | Minimum |  |  | Maximum |  |  | Dollars |  |  | % |  |  | Dollars |  |  | % |  |
| Fixed Income |  | 15.0 | % |  | 25.0 | % |  | $ | 10,637 |  |  |  | 18 | % |  | $ | 7,812 |  |  |  | 17 | % |
| Domestic equity |  | 36.5 | % |  | 61.5 | % |  |  | 25,151 |  |  |  | 43 | % |  |  | 19,615 |  |  |  | 42 | % |
| International equity |  | 17.0 | % |  | 25.0 | % |  |  | 16,093 |  |  |  | 28 | % |  |  | 13,466 |  |  |  | 29 | % |
| Real estate |  | 7.0 | % |  | 15.0 | % |  |  | 6,133 |  |  |  | 11 | % |  |  | 5,595 |  |  |  | 12 | % |
| Total |  |  |  |  |  |  |  | $ | 58,014 |  |  |  | 100 | % |  | $ | 46,488 |  |  |  | 100 | % |

[0001437749-18-003334:notes:305]
The fair values of the Pension Plans
’ assets at 
 December 31, 2017 
are as follows:

[0001437749-18-003334:notes:306]
The fair values of the Pension Pl
ans' assets at 
 December 31, 2016 
are as follows:

[0001437749-18-003334:notes:307]
A reconciliation of beg
inning and ending balances for Level 
3
 assets for the years ended 
 December 31, 2017 
and 
2016
 is as follows:

[0001437749-18-003334:notes:308]
Mutual Funds

[0001437749-18-003334:notes:309]
– This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plans' mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 
1
 of the fair value hierarchy.

[0001437749-18-003334:notes:310]
Other Investments

[0001437749-18-003334:notes:311]
– This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment, and therefore is classified within Level 
3
 of the fair value hierarchy.

[0001437749-18-003334:notes:312]
The Company
’s target allocation for equity securities and real estate is generally between 
65%
 - 
85%,
 with the remainder allocated primarily to fixed income (bonds). The Company regularly reviews its actual asset allocation and periodically rebalances its investments to the targeted allocation when considered appropriate.

[0001437749-18-003334:notes:313]
At a minimum, the Company expects to make 
estimated contributions of 
$319
 to the Pension Plans in 
2018.

[0001437749-18-003334:notes:314]
The following benefit payments are expected to be paid from the Pension Plans:

[0001437749-18-003334:notes:315]
| 2018 |  |  | $ | 2,445 |  |
| 2019 |  |  |  | 2,502 |  |
| 2020 |  |  |  | 2,622 |  |
| 2021 |  |  |  | 2,760 |  |
| 2022 |  |  |  | 2,932 |  |
| 2023 – 2027 |  |  |  | 16,989 |  |

[0001437749-18-003334:notes:316]
Certain of the Company
’s foreign subsidiaries participate in local statutory defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in accrued wages and employee benefits in the Company’s consolidated balance sheets and are 
not
 material.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-18-003334:notes:317]
| 9. | Product Warranty Obligations |

[0001437749-18-003334:notes:318]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. 
Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts following the standard warranty period.

[0001437749-18-003334:notes:319]
The following is a tabular reconciliation of the product warranty liability, 
excluding the deferred revenue related to our extended warranty coverage:

[0001437749-18-003334:notes:320]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 31,695 |  |  | $ | 30,197 |  |  | $ | 30,909 |  |
| Product warranty reserve assumed in acquisition |  |  | 43 |  |  |  | 840 |  |  |  | 351 |  |
| Payments |  |  | (18,861 | ) |  |  | (18,691 | ) |  |  | (21,686 | ) |
| Provision for warranty issued |  |  | 21,347 |  |  |  | 19,148 |  |  |  | 20,823 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,198 |  |  |  | 201 |  |  |  | (200 | ) |
| Balance at end of period |  | $ | 35,422 |  |  | $ | 31,695 |  |  | $ | 30,197 |  |

[0001437749-18-003334:notes:321]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage
:

[0001437749-18-003334:notes:322]
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 31,080 |  |  | $ | 28,961 |  |  | $ | 27,193 |  |
| Deferred revenue contracts assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 291 |  |
| Deferred revenue contracts issued (1) |  |  | 27,107 |  |  |  | 7,733 |  |  |  | 5,978 |  |
| Amortization of deferred revenue contracts |  |  | (7,246 | ) |  |  | (5,614 | ) |  |  | (4,501 | ) |
| Balance at end of period |  | $ | 50,941 |  |  | $ | 31,080 |  |  | $ | 28,961 |  |

[0001437749-18-003334:notes:323]
|  | (1) | The increase in deferred revenue contracts issued during 2017 was largely due to the launch of a post-sale extended warranty program. |

[0001437749-18-003334:notes:324]
Product warranty obligations and extended warranty
 related deferred revenues are included in the balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-18-003334:notes:325]
Property and Equipment

[0001437749-18-003334:notes:326]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements.

[0001437749-18-003334:notes:327]
Total depreciation expense 
was 
$23,127,

[0001437749-18-003334:notes:328]
$21,465,
 and 
$16,742
 for the years ended 
 December 31, 2017,


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-18-003334:notes:329]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Land and improvements |  | $ | 13,118 |  |  | $ | 12,079 |  |
| Buildings and improvements |  |  | 132,072 |  |  |  | 122,747 |  |
| Machinery and equipment |  |  | 90,487 |  |  |  | 81,687 |  |
| Dies and tools |  |  | 24,504 |  |  |  | 23,269 |  |
| Vehicles |  |  | 1,878 |  |  |  | 1,474 |  |
| Office equipment and systems |  |  | 73,254 |  |  |  | 66,929 |  |
| Leasehold improvements |  |  | 2,436 |  |  |  | 2,319 |  |
| Construction in progress |  |  | 18,799 |  |  |  | 8,654 |  |
| Gross property and equipment |  |  | 356,548 |  |  |  | 319,158 |  |
| Accumulated depreciation |  |  | (126,168 | ) |  |  | (106,365 | ) |
| Total |  | $ | 230,380 |  |  | $ | 212,793 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-18-003334:notes:330]
| 17. | Quarterly Financial Information (Unaudited) |

[0001437749-18-003334:notes:331]
|  |  | Quarters Ended 2017 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 331,814 |  |  | $ | 395,376 |  |  | $ | 457,253 |  |  | $ | 488,002 |  |
| Gross profit |  |  | 110,486 |  |  |  | 134,460 |  |  |  | 157,469 |  |  |  | 179,702 |  |
| Operating income |  |  | 31,845 |  |  |  | 52,287 |  |  |  | 72,859 |  |  |  | 94,073 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 12,842 |  |  |  | 25,660 |  |  |  | 39,709 |  |  |  | 81,175 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.22 |  |  | $ | 0.42 |  |  | $ | 0.64 |  |  | $ | 1.31 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.21 |  |  | $ | 0.41 |  |  | $ | 0.64 |  |  | $ | 1.30 |  |

[0001437749-18-003334:notes:332]
|  |  | Quarters Ended 2016 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 286,535 |  |  | $ | 367,376 |  |  | $ | 373,121 |  |  | $ | 417,421 |  |
| Gross profit |  |  | 98,060 |  |  |  | 124,147 |  |  |  | 137,772 |  |  |  | 154,127 |  |
| Operating income |  |  | 26,964 |  |  |  | 44,082 |  |  |  | 56,340 |  |  |  | 77,231 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 10,208 |  |  |  | 20,888 |  |  |  | 26,183 |  |  |  | 41,509 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.15 |  |  | $ | 0.32 |  |  | $ | 0.41 |  |  | $ | 0.64 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.15 |  |  | $ | 0.31 |  |  | $ | 0.40 |  |  | $ | 0.64 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-18-003334:notes:333]
Accounts Receivable

[0001437749-18-003334:notes:334]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-18-003334:notes:335]
Revenue Recognition

[0001437749-18-003334:notes:336]
Sales, net of estimated returns and allowances, are recognized upon shipment of product to the customer, which is generally when title passes, the Company has 
no
 further obligations, and the customer is required to pay subject to agreed upon payment terms. The Company, at the request of certain customers, will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customers take possession of the product. In these cases, the funds collected on product warehoused for these customers are recorded as a customer advance until the customer takes possession of the product and the Company’s obligation to deliver the goods is completed. Customer advances are included in accrued liabilities in the consolidated balance sheets.

[0001437749-18-003334:notes:337]
The Company provides for certain estimated sales 
programs, discounts and incentive expenses which are recognized as a reduction of sales.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-18-003334:notes:338]
|  |  | Net Sales |  |
|  |  | Year Ended December 31, |  |
| Product Classes |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Residential products |  | $ | 870,410 |  |  | $ | 772,436 |  |  | $ | 673,764 |  |
| Commercial & industrial products |  |  | 685,052 |  |  |  | 557,532 |  |  |  | 548,440 |  |
| Other |  |  | 116,983 |  |  |  | 114,485 |  |  |  | 95,095 |  |
| Total |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-18-003334:notes:339]
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Raw material |  | $ | 242,239 |  |  | $ | 218,911 |  |
| Work-in-process |  |  | 2,544 |  |  |  | 2,950 |  |
| Finished goods |  |  | 135,558 |  |  |  | 127,870 |  |
| Total |  | $ | 380,341 |  |  | $ | 349,731 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-003334:notes:340]
|  |  | Net Sales |  |
|  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 1,296,578 |  |  | $ | 1,173,559 |  |  | $ | 1,204,589 |  |
| International |  |  | 375,867 |  |  |  | 270,894 |  |  |  | 112,710 |  |
| Total |  | $ | 1,672,445 |  |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |

[0001437749-18-003334:notes:341]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 290,720 |  |  | $ | 261,428 |  |  | $ | 254,882 |  |
| International |  |  | 27,010 |  |  |  | 16,959 |  |  |  | 15,934 |  |
| Total adjusted EBITDA |  | $ | 317,730 |  |  | $ | 278,387 |  |  | $ | 270,816 |  |
| Interest expense |  |  | (42,667 | ) |  |  | (44,568 | ) |  |  | (42,843 | ) |
| Depreciation and amortization |  |  | (51,988 | ) |  |  | (54,418 | ) |  |  | (40,333 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (2,923 | ) |  |  | (357 | ) |  |  | (3,892 | ) |
| Non-cash share-based compensation expense (2) |  |  | (10,205 | ) |  |  | (9,493 | ) |  |  | (8,241 | ) |
| Tradename and goodwill impairment (3) |  |  | - |  |  |  | - |  |  |  | (40,687 | ) |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | (574 | ) |  |  | (4,795 | ) |
| Gain (loss) on change in contractual interest rate (5) |  |  | - |  |  |  | (2,957 | ) |  |  | (2,381 | ) |
| Transaction costs and credit facility fees (6) |  |  | (2,145 | ) |  |  | (2,442 | ) |  |  | (2,249 | ) |
| Business optimization expenses (7) |  |  | (2,912 | ) |  |  | (7,316 | ) |  |  | (1,947 | ) |
| Other |  |  | (202 | ) |  |  | 120 |  |  |  | (465 | ) |
| Income before provision for income taxes |  | $ | 204,688 |  |  | $ | 156,382 |  |  | $ | 122,983 |  |

[0001437749-18-003334:notes:342]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 1,606,606 |  |  | $ | 1,521,665 |  |  | $ | 1,605,043 |  |
| International |  |  | 413,358 |  |  |  | 340,019 |  |  |  | 173,592 |  |
| Total |  | $ | 2,019,964 |  |  | $ | 1,861,684 |  |  | $ | 1,778,635 |  |

[0001437749-18-003334:notes:343]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 37,962 |  |  | $ | 42,346 |  |  | $ | 35,327 |  |
| International |  |  | 14,026 |  |  |  | 12,072 |  |  |  | 5,006 |  |
| Total |  | $ | 51,988 |  |  | $ | 54,418 |  |  | $ | 40,333 |  |

[0001437749-18-003334:notes:344]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 29,258 |  |  | $ | 26,936 |  |  | $ | 29,368 |  |
| International |  |  | 4,003 |  |  |  | 3,531 |  |  |  | 1,283 |  |
| Total |  | $ | 33,261 |  |  | $ | 30,467 |  |  | $ | 30,651 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-18-003334:notes:345]
| 18. | Valuation and Qualifying Accounts |

[0001437749-18-003334:notes:346]
For t
he years ended 
 December 31, 2017,

[0001437749-18-003334:notes:347]
2016
 and 
2015:

[0001437749-18-003334:notes:348]
|  | (1) | Deductions from the allowance for doubtful accounts equal accounts receivable written off, less recoveries, against the allowance. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-003334:notes:349]
| 6. | Segment Reporting |

[0001437749-18-003334:notes:350]
The Company has

[0001437749-18-003334:notes:351]
two
 reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac and Motortech acquisitions, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. All segment information has been retrospectively applied to all periods presented to reflect the current reportable segment structure.

[0001437749-18-003334:notes:352]
The Company's product offerings consist primarily of power
 generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer. The breakout of net sales by product class between residential, commercial & industrial, and other products is as follows:

[0001437749-18-003334:notes:353]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA
 before noncontrolling interests, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-18-003334:notes:354]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. |

[0001437749-18-003334:notes:355]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-18-003334:notes:356]
|  | (3) | Represents the 2015 impairment of certain tradenames due to a change in brand strategy to transition and consolidate various brands to the Generac® tradename ($36,076) and the impairment of goodwill related to the Ottomotores reporting unit ($4,611). |

[0001437749-18-003334:notes:357]
|  | (4) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |

[0001437749-18-003334:notes:358]
|  | (5) | For the year ended December 31, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time. For the year ended December 31, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 times and expected to remain above 3.0 times based on projections at that time. Following the May 2017 Term Loan amendment, which removed the pricing grid based on leverage ratio achieved, gains or losses on changes in contractual interest rate will no longer be recorded in the statements of comprehensive income. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the gains and losses on changes in the contractual interest rate. |

[0001437749-18-003334:notes:359]
|  | (6) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-18-003334:notes:360]
|  | (7) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-18-003334:notes:361]
The following tables summarize additional financial information by reportable segment:

[0001437749-18-003334:notes:362]
The Company
’s sales in the United States represent approximately 
74%,

[0001437749-18-003334:notes:363]
77%,
 and 
85%
 of total sales for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:364]
2016
 and 
2015,
 respectively. Approximately 
85%
 and 
87%
 of the Company’s identifiable long-lived assets are located in the United States as of 
 December 31, 2017 
and 
2016,
 respectively.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-18-003334:notes:365]
Shipping and Handling Costs

[0001437749-18-003334:notes:366]
Shipping and handling costs billed to customers are included in net sales, and the related costs are included in cost of goods sold in the consolidated statements of comprehensive income.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-18-003334:notes:367]
| 2. | Significant Accounting Policies |

[0001437749-18-003334:notes:368]
Concentration of Credit Risk

[0001437749-18-003334:notes:369]
The Company maintains the majority of its 
domestic cash in 
one
 commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-18-003334:notes:370]
One

[0001437749-18-003334:notes:371]
customer accounted for 
approximately 
7%
 and 
9%
 of accounts receivable at 
 December 31, 2017 
and 
2016,
 respectively.

[0001437749-18-003334:notes:372]
No

[0001437749-18-003334:notes:373]
one
 customer accounted for greater than 
6%,

[0001437749-18-003334:notes:374]
7%
 and 
7%,
 of net sales during the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:375]
2016,
 or 
2015,
 respectively.

[0001437749-18-003334:notes:376]
Research and Development

[0001437749-18-003334:notes:377]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development 
were 
$42,925,

[0001437749-18-003334:notes:378]
$37,229,
 and 
$32,922
 for the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:379]
Fair Value of Financial Instruments

[0001437749-18-003334:notes:380]
ASC 
820
-
10

[0001437749-18-003334:notes:381]
, 
Fair Value Measurement

[0001437749-18-003334:notes:382]
,
 defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 
820
-
10
 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a 
three
-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 
1
) observable inputs such as quoted prices in active markets; (Level 
2
) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 
3
) unobservable inputs in which there is little or 
no
 market data, which require the reporting entity to develop its own assumptions.

[0001437749-18-003334:notes:383]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts 
payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$902,959,
 was approximately 
$903,500
 (Level 
2
) at 
 December 31, 2017, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-18-003334:notes:384]
For the fair value of the assets and liabilities measured on a recurring basis, 
refer to the fair value table in Note 
4,
 “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 
820
-
10.

[0001437749-18-003334:notes:385]
Use of Estimates

[0001437749-18-003334:notes:386]
The preparation of the consolidated financial statements in conformity with 
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-18-003334:notes:387]
Share-Based Compensation

[0001437749-18-003334:notes:388]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant.


## us-gaap:SubsequentEventsTextBlock

[0001437749-18-003334:notes:389]
| 19. | Subsequent Events |

[0001437749-18-003334:notes:390]
On 
 February

[0001437749-18-003334:notes:391]
13,

[0001437749-18-003334:notes:392]
2018,
 the Company signed a purchase agreement to acquire Selmec Equipos Industriales, S.A. de C.V. (Selmec), which is headquartered in Mexico City, Mexico. Selmec, which has approximately 
300
 employees, is a designer and manufacturer of industrial generators ranging from 
10
 kW to 
2,750
 kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-18-003334:notes:393]
| 7. | Balance Sheet Details |

[0001437749-18-003334:notes:394]
Inventories consist of the following:

[0001437749-18-003334:notes:395]
December 31, 2017

[0001437749-18-003334:notes:396]
and 
2016

[0001437749-18-003334:notes:397]
, inventories totaling 
$6,245

[0001437749-18-003334:notes:398]
and 
$10,598

[0001437749-18-003334:notes:399]
, respectively, were on consignment at customer locations.

[0001437749-18-003334:notes:400]
Property and equipment consists of the following:


## us-gaap:TreasuryStockTextBlock

[0001437749-18-003334:notes:401]
| 11. | Stock Repurchase Program |

[0001437749-18-003334:notes:402]
I
n 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the 
second
 program, the Company 
 may 
repurchase up to 
$250,000
 of its common stock over the 
24
 months following the date of approval. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the years ended 
 December 31, 2017,

[0001437749-18-003334:notes:403]
2016
 and 
2015,
 the Company repurchased 
844,500,

[0001437749-18-003334:notes:404]
3,968,706
 and 
3,303,500
 shares of its common stock, respectively, for 
$30,012,

[0001437749-18-003334:notes:405]
$149,937
 and 
$99,942,
 respectively, all funded with cash on hand.
