# GNRC notes — 0001437749-19-008988


## gnrc:LeaseTermAndDiscountRateTableTextBlock

[0001437749-19-008988:notes:1]
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating Leases |  |  | 6.97 |  |
| Finance Leases |  |  | 14.67 |  |
| Weighted average discount rate |  |  |  |  |
| Operating Leases |  |  | 5.59 | % |
| Finance Leases |  |  | 7.87 | % |


## gnrc:OperatingAndFinanceLeaseLiabilityMaturityTableTextBlock

[0001437749-19-008988:notes:2]
|  |  | As of March 31, 2019 |  |
|  |  | Finance Leases |  |  | Operating Leases |  |
| Remainder of 2019 |  | $ | 2,394 |  |  | $ | 7,862 |  |
| 2020 |  |  | 3,217 |  |  |  | 8,769 |  |
| 2021 |  |  | 2,844 |  |  |  | 6,860 |  |
| 2022 |  |  | 2,697 |  |  |  | 5,410 |  |
| 2023 |  |  | 2,609 |  |  |  | 4,695 |  |
| After 2023 |  |  | 32,030 |  |  |  | 18,666 |  |
| Total minimum lease payments |  |  | 45,791 |  |  |  | 52,262 |  |
| Interest |  |  | (20,077 | ) |  |  | (11,606 | ) |
| Present value of minimum lease payments |  | $ | 25,714 |  |  | $ | 40,656 |  |


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-19-008988:notes:3]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 25,559 |  |  | $ | 25,396 |  |
| Long-term portion - other long-term liabilities |  |  | 18,003 |  |  |  | 16,389 |  |
| Total |  | $ | 43,562 |  |  | $ | 41,785 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 13,930 |  |  | $ | 13,646 |  |
| Long-term portion - other long-term liabilities |  |  | 56,914 |  |  |  | 54,694 |  |
| Total |  | $ | 70,844 |  |  | $ | 68,340 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-19-008988:notes:4]
3.
 Redeemable Noncontrolling Interest

[0001437749-19-008988:notes:5]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In 
 February 2019, 
the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by 
five
 years, allowing the Company to exercise its call option rights in partial increments at certain times during the 
five
 year period, and providing that the noncontrolling interest holder 
no
 longer holds the right to put its shares to the Company until 
 April 1, 2021.

[0001437749-19-008988:notes:6]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
14,
 “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-19-008988:notes:7]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 61,004 |  |  | $ | 43,929 |  |
| Net income |  |  | 265 |  |  |  | (26 | ) |
| Foreign currency translation |  |  | (1,480 | ) |  |  | 2,836 |  |
| Redemption value adjustment |  |  | (2,432 | ) |  |  | 7,665 |  |
| Balance at end of period |  | $ | 57,357 |  |  | $ | 54,404 |  |


## gnrc:ScheduleOfComponentsOfLeaseAssetsAndLiabilitiesTableTextBlock

[0001437749-19-008988:notes:8]
|  |  | March 31, 2019 |  |
| Operating Leases |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 39,672 |  |
| Operating lease liabilities - current (2) |  | $ | 7,581 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 33,075 |  |
| Total operating lease liabilities |  | $ | 40,656 |  |
| Finance Leases |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 28,514 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (2,306 | ) |
| Finance lease ROU assets, net (4) |  | $ | 26,208 |  |
| Finance lease liabilities - current (5) |  | $ | 1,315 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 24,399 |  |
| Total finance lease liabilities |  | $ | 25,714 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-19-008988:notes:9]
|  |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Commodity contracts |  | $ | 0 |  |  | $ | (160 | ) |
| Foreign currency contracts |  |  | (221 | ) |  |  | (117 | ) |
| Interest rate swaps |  |  | 1,383 |  |  |  | 8,307 |  |


## gnrc:ScheduleOfFutureMinimumRentalPaymentsForFinanceAndOperatingLeasesTableTextBlock

[0001437749-19-008988:notes:10]
|  |  | As of December 31, 2018 |  |
|  |  | Capital Leases |  |  | Operating Leases |  |
| 2019 |  | $ | 2,166 |  |  | $ | 8,914 |  |
| 2020 |  |  | 2,477 |  |  |  | 7,575 |  |
| 2021 |  |  | 2,053 |  |  |  | 6,379 |  |
| 2022 |  |  | 1,995 |  |  |  | 4,955 |  |
| 2023 |  |  | 1,889 |  |  |  | 4,482 |  |
| After 2023 |  |  | 18,108 |  |  |  | 18,614 |  |
| Total minimum lease payments |  |  | 28,688 |  |  | $ | 50,919 |  |
| Interest |  |  | (8,517 | ) |  |  |  |  |
| Present value of minimum lease payments |  | $ | 20,171 |  |  |  |  |  |


## gnrc:ScheduleOfLeasesCashFlowInformationTableTextBlock

[0001437749-19-008988:notes:11]
|  |  | Three Months Ended March 31, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,618 |  |
| Operating cash flows from finance leases |  |  | 456 |  |
| Financing cash flows from finance leases |  |  | 529 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |
| Operating leases |  |  | 397 |  |
| Finance leases |  |  | 6,976 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-19-008988:notes:12]
2

[0001437749-19-008988:notes:13]
. Acquisitions

[0001437749-19-008988:notes:14]
Acquisition of

[0001437749-19-008988:notes:15]
Neurio

[0001437749-19-008988:notes:16]
On 
 March 12, 2019, 
the Company acquired Neurio for a purchase price of 
$60,364,
 net of cash acquired and inclusive of estimated deferred payments of 
$9,270.
 To date, the acquisition purchase price was funded solely through cash on hand.

[0001437749-19-008988:notes:17]
The Company recorded a preliminary purchase price allocation during the 
first
 quarter of 
2019
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$59,962
 of goodwill in the domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition through 
 March 31, 2019.

[0001437749-19-008988:notes:18]
Acquisition of Selmec

[0001437749-19-008988:notes:19]
On 
 June 1, 2018, 
the Company acquired Selmec for a purchase price of 
$79,972,
 net of cash acquired and inclusive of estimated earnout payments of 
$14,902.
 To date, the acquisition purchase price was funded solely through cash on hand.

[0001437749-19-008988:notes:20]
The Company recorded a preliminary purchase price allocation through 
Q1

[0001437749-19-008988:notes:21]
2019
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$79,986
 of intangible assets, including approximately 
$46,356
 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is 
not
 deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Selmec from the date of acquisition through 
 March 31, 2019.

[0001437749-19-008988:notes:22]
Overall, the net sales contribution from all non-annualized acquisitions to the 
three
 months ended 
 March 31, 2019 
was 
$14,861.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-19-008988:notes:23]
[same as prior period, unchanged from 0001437749-18-019673:notes:17]

[0001437749-19-008988:notes:24]
[same as prior period, unchanged from 0001437749-18-019673:notes:18]

[0001437749-19-008988:notes:25]
[same as prior period, unchanged from 0001437749-18-019673:notes:19]

[0001437749-19-008988:notes:26]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

[0001437749-19-008988:notes:27]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018). 
A summary of acquisitions affecting the reporting periods presented include:

[0001437749-19-008988:notes:28]
[same as prior period, unchanged from 0001437749-18-019673:notes:22]

[0001437749-19-008988:notes:29]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. Captiva has seven sales locations throughout India and has over 100 employees. |

[0001437749-19-008988:notes:30]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

[0001437749-19-008988:notes:31]
[same as prior period, unchanged from 0001437749-18-019673:notes:24]

[0001437749-19-008988:notes:32]
The condensed consolidated balance sheet as of 
 March 31, 2019, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 the condensed consolidated statements of stockholders’ equity for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2019 
and 
2018
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-19-008988:notes:33]
[same as prior period, unchanged from 0001437749-18-019673:notes:26]

[0001437749-19-008988:notes:34]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018.

[0001437749-19-008988:notes:35]
[same as prior period, unchanged from 0001437749-18-019673:notes:28]

[0001437749-19-008988:notes:36]
[same as prior period, unchanged from 0001437749-18-019673:notes:29]

[0001437749-19-008988:notes:37]
In 
 August 2018, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2018
-
15,

[0001437749-19-008988:notes:38]
Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-19-008988:notes:39]
[same as prior period, unchanged from 0001437749-18-019673:notes:37]

[0001437749-19-008988:notes:40]
Recently Adopted Accounting Standards

[0001437749-19-008988:notes:41]
On 
 January 1, 2019, 
the Company adopted ASU 
2016
-
02,

[0001437749-19-008988:notes:42]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning 
no
 prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balances sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did 
not
 have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 
9,
 “Leases,” for further information regarding the Company’s leases.

[0001437749-19-008988:notes:43]
On 
 January 1, 2019, 
the Company adopted ASU 
2018
-
02,

[0001437749-19-008988:notes:44]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income
. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 
2017
 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to 
not
 reclassify the stranded income tax effects from AOCI to retained earnings.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-008988:notes:45]
1

[0001437749-19-008988:notes:46]
6

[0001437749-19-008988:notes:47]
. Commitments and

[0001437749-19-008988:notes:48]
Contingencies

[0001437749-19-008988:notes:49]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2019 
and 
 December 31, 2018 
was approximately 
$48,600
 and 
$47,200,
 respectively.

[0001437749-19-008988:notes:50]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-19-008988:notes:51]
6.
 Accumulated Other Comprehensive

[0001437749-19-008988:notes:52]
[same as prior period, unchanged from 0001437749-18-019673:notes:62]

[0001437749-19-008988:notes:53]
The following presents a tabular disclosure of changes in AOCL during the 
three
 months ended 
 March 31, 2019 
and 
2018,
 net of tax:

[0001437749-19-008988:notes:54]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  | $ | (23,813 | ) |
| Other comprehensive loss before reclassifications |  |  | (933 | ) |  |  | - |  |  |  | (5,124 | ) |  |  | (6,057 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (933 | ) |  |  | - |  |  |  | (5,124 | ) |  |  | (6,057 | ) |
| Ending Balance – March 31, 2019 |  | $ | (19,765 | ) |  | $ | (10,541 | ) |  | $ | 436 |  |  | $ | (29,870 | ) |

[0001437749-19-008988:notes:55]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income before reclassifications |  |  | 6,179 |  |  |  | - |  |  |  | 6,647 |  |  |  | 12,826 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 6,179 |  |  |  | - |  |  |  | 6,647 |  |  |  | 12,826 |  |
| Ending Balance – March 31, 2018 |  | $ | (6,677 | ) |  | $ | (10,978 | ) |  | $ | 9,283 |  |  | $ | (8,372 | ) |

[0001437749-19-008988:notes:56]
|  | (1) | Represents unrealized losses of $(6,924), net of tax effect of $1,800 for the three months ended March 31, 2019. |

[0001437749-19-008988:notes:57]
|  | (2) | Represents unrealized gains of $8,982, net of tax effect of $(2,335) for the three months ended March 31, 2018. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-19-008988:notes:58]
12

[0001437749-19-008988:notes:59]
. Credit Agreements

[0001437749-19-008988:notes:60]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-008988:notes:61]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 15,051 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,190 |  |  |  | 27,124 |  |
| Total |  | $ | 45,241 |  |  | $ | 45,583 |  |

[0001437749-19-008988:notes:62]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-008988:notes:63]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (21,263 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,714 |  |  |  | 20,171 |  |
| Other |  |  | 1,235 |  |  |  | 1,642 |  |
| Total |  |  | 884,686 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 888 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,315 |  |  |  | 902 |  |
| Total |  | $ | 882,483 |  |  | $ | 876,396 |  |

[0001437749-19-008988:notes:64]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 The Term Loan agreement has been amended a number of times since inception.

[0001437749-19-008988:notes:65]
In 
 June 2018, 
the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.

[0001437749-19-008988:notes:66]
As of 
 March 31, 2019, 
the Company’s net secured leverage ratio was 
1.69
 to 
1.00
 times, and the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-19-008988:notes:67]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.00%
 or adjusted LIBOR rate plus an applicable margin of 
2.00%,
 in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-19-008988:notes:68]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date to 
 June 12, 2023. 
In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.

[0001437749-19-008988:notes:69]
As of 
 March 31, 2019, 
there was 
$15,051
 outstanding under the ABL Facility, leaving 
$284,599
 of availability, net of outstanding letters of credit.

[0001437749-19-008988:notes:70]
As of 
 March 31, 2019 
and 
 December 31, 2018, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled 
$45,241
 and 
$45,583,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-008988:notes:71]
4

[0001437749-19-008988:notes:72]
[same as prior period, unchanged from 0001437749-18-019673:notes:86]

[0001437749-19-008988:notes:73]
[same as prior period, unchanged from 0001437749-18-019673:notes:87]

[0001437749-19-008988:notes:74]
[same as prior period, unchanged from 0001437749-18-019673:notes:88]

[0001437749-19-008988:notes:75]
Derivatives and Hedging
, which requires derivative instruments be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does 
not
 hold or issue derivative financial instruments for trading purposes.

[0001437749-19-008988:notes:76]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in the Company’s condensed consolidated statements of comprehensive income. These gains and losses are 
not
 material to the Company’s condensed consolidated financial statements.

[0001437749-19-008988:notes:77]
[same as prior period, unchanged from 0001437749-18-019673:notes:98]

[0001437749-19-008988:notes:78]
In 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements. In 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement. In 
2017,
 the Company entered into 
twenty
 interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains (losses), net of tax, recognized for the 
three
 months ended 
 March 31, 2019 
and 
2018
 were $(
5,124
) and 
$6,647,
 respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-19-008988:notes:79]
[same as prior period, unchanged from 0001437749-18-019673:notes:100]

[0001437749-19-008988:notes:80]
[same as prior period, unchanged from 0001437749-18-019673:notes:101]

[0001437749-19-008988:notes:81]
The fair value of the foreign currency contracts is included in other accrued liabilities and the fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheets as of 
 March 31, 2019. 
The fair values of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the consolidated balance sheet as of 
 December 31, 2018. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 March 31, 2019 
and 
 December 31, 2018 
is an asset of 
$1,186
 and 
$8,220,
 respectively, which represents the amount the Company would receive upon exit of the agreements on those dates.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-19-008988:notes:82]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 205,181 |  |  | $ | 12,649 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 122,446 |  |  |  | 86,678 |  |  |  | 209,124 |  |
| Other |  |  | 31,621 |  |  |  | 11,778 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 359,248 |  |  | $ | 111,105 |  |  | $ | 470,353 |  |

[0001437749-19-008988:notes:83]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 176,685 |  |  | $ | 13,789 |  |  | $ | 190,474 |  |
| Commercial & industrial products |  |  | 97,771 |  |  |  | 77,354 |  |  |  | 175,125 |  |
| Other |  |  | 28,220 |  |  |  | 6,272 |  |  |  | 34,492 |  |
| Total net sales |  | $ | 302,676 |  |  | $ | 97,415 |  |  | $ | 400,091 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-008988:notes:84]
[same as prior period, unchanged from 0001437749-18-019673:notes:108]

[0001437749-19-008988:notes:85]
[same as prior period, unchanged from 0001437749-18-019673:notes:109]

[0001437749-19-008988:notes:86]
Basic earnings per share is calculated by dividing net income attributable to the common stockholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 
3,
 “Redeemable Noncontrolling Interest” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-19-008988:notes:87]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-19-008988:notes:88]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 2,432 |  |  |  | (7,665 | ) |
| Net income attributable to common shareholders |  | $ | 47,293 |  |  | $ | 25,980 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,762,260 |  |  |  | 61,943,495 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 461,378 |  |  |  | 531,441 |  |
| Diluted shares |  |  | 62,223,638 |  |  |  | 62,474,936 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.77 |  |  | $ | 0.42 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.42 |  |

[0001437749-19-008988:notes:89]
(
1
) Excludes approximately 
71,800
 and 
93,600
 stock options for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 respectively, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-19-008988:notes:90]
5

[0001437749-19-008988:notes:91]
[same as prior period, unchanged from 0001437749-18-019673:notes:114]

[0001437749-19-008988:notes:92]
[same as prior period, unchanged from 0001437749-18-019673:notes:115]

[0001437749-19-008988:notes:93]
[same as prior period, unchanged from 0001437749-18-019673:notes:116]

[0001437749-19-008988:notes:94]
[same as prior period, unchanged from 0001437749-18-019673:notes:117]

[0001437749-19-008988:notes:95]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$858,957,
 was approximately 
$857,861
 (Level 
2
) at 
 March 31, 2019, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-19-008988:notes:96]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 
4,
 “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 
820
-
10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-008988:notes:97]
[same as prior period, unchanged from 0001437749-18-019673:notes:120]

[0001437749-19-008988:notes:98]
The effective income tax rates for the 
three
 months ended 
 March 31, 2019 
and 
2018
 were 
24.7%
 and 
25.3%,
 respectively. The decrease in the effective income tax rate in 
2019
 was primarily due to the mixture of taxable income in the jurisdictions where we pay tax and state tax credits.


## us-gaap:LeaseCostTableTextBlock

[0001437749-19-008988:notes:99]
|  |  | Three Months Ended March 31, 2019 |  |
| Operating lease cost |  | $ | 2,599 |  |
| Finance lease cost: |  |  |  |  |
| Amortization of ROU assets |  |  | 418 |  |
| Interest on lease liabilities |  |  | 581 |  |
| Total lease cost |  | $ | 3,598 |  |


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001437749-19-008988:notes:100]
9.
 Leases

[0001437749-19-008988:notes:101]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a ROU asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do 
not
 provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term 
 may 
include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the condensed consolidated financial statements.

[0001437749-19-008988:notes:102]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did 
not
 elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-19-008988:notes:103]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 
20
 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 
10
 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arms’ length transactions.

[0001437749-19-008988:notes:104]
The Company is a lessor of 
one
 building that it leases to a 
third
 party. The lease income related to this arrangement is 
not
 material to the condensed consolidated financial statements.

[0001437749-19-008988:notes:105]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the condensed consolidated statement of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the condensed consolidated statement of comprehensive income.

[0001437749-19-008988:notes:106]
The components of total lease cost consist of the following:

[0001437749-19-008988:notes:107]
Prior to the adoption of ASC 
842,
 lease expense consisted of payments on operating leases.

[0001437749-19-008988:notes:108]
As of 
 January 1, 2019, 
the date of the adoption of ASC 
2016
-
02,
 the Company recognized ROU assets and lease liabilities related to operating leases of 
$42,024
 and 
$42,056,
 respectively, and there was 
no
 cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases was as follows:

[0001437749-19-008988:notes:109]
|  | (1) | Recorded in the operating lease and other assets line |

[0001437749-19-008988:notes:110]
|  | (2) | Recorded in the other accrued liabilities line |

[0001437749-19-008988:notes:111]
|  | (3) | Recorded in the operating lease and other long-term liabilities line |

[0001437749-19-008988:notes:112]
|  | (4) | Recorded in the property & equipment, net line |

[0001437749-19-008988:notes:113]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line |

[0001437749-19-008988:notes:114]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line |

[0001437749-19-008988:notes:115]
Supplemental cash flow information related to the Company’s leases was as follows:

[0001437749-19-008988:notes:116]
Weighted average remaining lease term and discount rate information related to the Company’s leases was as follows:

[0001437749-19-008988:notes:117]
The maturities of the Company’s lease liabilities are as follows:


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-19-008988:notes:118]
[same as prior period, unchanged from 0001437749-18-019673:notes:123]

[0001437749-19-008988:notes:119]
[same as prior period, unchanged from 0001437749-18-019673:notes:124]

[0001437749-19-008988:notes:120]
[same as prior period, unchanged from 0001437749-18-019673:notes:125]

[0001437749-19-008988:notes:121]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-19-008988:notes:122]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 41,785 |  |  | $ | 35,422 |  |
| Product warranty reserve assumed in acquisition |  |  | 212 |  |  |  | - |  |
| Payments |  |  | (5,634 | ) |  |  | (4,985 | ) |
| Provision for warranty issued |  |  | 6,960 |  |  |  | 5,203 |  |
| Changes in estimates for pre-existing warranties |  |  | 239 |  |  |  | 679 |  |
| Balance at end of period |  | $ | 43,562 |  |  | $ | 36,319 |  |

[0001437749-19-008988:notes:123]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of 
five
 to 
ten
 years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the condensed consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-19-008988:notes:124]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 68,340 |  |  | $ | 57,854 |  |
| Deferred revenue contracts issued |  |  | 5,800 |  |  |  | 4,716 |  |
| Amortization of deferred revenue contracts |  |  | (3,296 | ) |  |  | (2,457 | ) |
| Balance at end of period |  | $ | 70,844 |  |  | $ | 60,113 |  |

[0001437749-19-008988:notes:125]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at 
 March 31, 2019 
is as follows:

[0001437749-19-008988:notes:126]
| Remainder of 2019 |  | $ | 10,433 |  |
| 2020 |  |  | 14,333 |  |
| 2021 |  |  | 13,157 |  |
| 2022 |  |  | 11,071 |  |
| 2023 |  |  | 8,173 |  |
| After 2023 |  |  | 13,677 |  |
| Total |  | $ | 70,844 |  |

[0001437749-19-008988:notes:127]
[same as prior period, unchanged from 0001437749-18-019673:notes:132]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-19-008988:notes:128]
|  |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Land and improvements |  | $ | 16,777 |  |  | $ | 15,975 |  |
| Buildings and improvements |  |  | 169,869 |  |  |  | 163,161 |  |
| Machinery and equipment |  |  | 106,101 |  |  |  | 103,726 |  |
| Dies and tools |  |  | 29,158 |  |  |  | 28,198 |  |
| Vehicles |  |  | 2,863 |  |  |  | 2,070 |  |
| Office equipment and systems |  |  | 84,065 |  |  |  | 82,638 |  |
| Leasehold improvements |  |  | 2,833 |  |  |  | 2,137 |  |
| Construction in progress |  |  | 27,268 |  |  |  | 26,543 |  |
| Gross property and equipment |  |  | 438,934 |  |  |  | 424,448 |  |
| Accumulated depreciation |  |  | (149,496 | ) |  |  | (145,519 | ) |
| Total |  | $ | 289,438 |  |  | $ | 278,929 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-19-008988:notes:129]
11.
 Contract Balances

[0001437749-19-008988:notes:130]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was 
$10,836
 and 
$14,174
 at 
 March 31, 2019 
and 
 December 31, 2018, 
respectively. During the 
three
 months ended 
 March 31, 2019, 
the Company recognized revenue of 
$5,691
 related to amounts included in the 
 December 31, 2018 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-19-008988:notes:131]
|  |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Raw material |  | $ | 334,949 |  |  | $ | 348,980 |  |
| Work-in-process |  |  | 9,020 |  |  |  | 6,971 |  |
| Finished goods |  |  | 244,411 |  |  |  | 188,799 |  |
| Total |  | $ | 588,380 |  |  | $ | 544,750 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-19-008988:notes:132]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 80,975 |  |  | $ | 65,475 |  |
| International |  |  | 6,153 |  |  |  | 6,306 |  |
| Total adjusted EBITDA |  | $ | 87,128 |  |  | $ | 71,781 |  |
| Interest expense |  |  | (10,272 | ) |  |  | (10,113 | ) |
| Depreciation and amortization |  |  | (12,607 | ) |  |  | (11,683 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 1,400 |  |  |  | (1,306 | ) |
| Non-cash share-based compensation expense (2) |  |  | (3,594 | ) |  |  | (3,106 | ) |
| Transaction costs and credit facility fees (3) |  |  | (1,286 | ) |  |  | (262 | ) |
| Business optimization expenses (4) |  |  | (169 | ) |  |  | (138 | ) |
| Other |  |  | 154 |  |  |  | 13 |  |
| Income before provision for income taxes |  | $ | 60,754 |  |  | $ | 45,186 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-008988:notes:133]
7

[0001437749-19-008988:notes:134]
[same as prior period, unchanged from 0001437749-18-019673:notes:145]

[0001437749-19-008988:notes:135]
The Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other power products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-19-008988:notes:136]
The Company's product offerings consist primarily of power generation equipment and other power products geared for varying end customer uses. Residential products and commercial & industrial (C&I) products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-19-008988:notes:137]
[same as prior period, unchanged from 0001437749-18-019673:notes:148]

[0001437749-19-008988:notes:138]
C&I products consist of larger output stationary generators used in various C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 
10kW
 up to 
3,250kW
 for single engine sets. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-19-008988:notes:139]
Other products consist primarily of aftermarket service parts and product accessories sold to our dealers, and the amortization of extended warranty deferred revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue is recognized over the life of the contract.

[0001437749-19-008988:notes:140]
In accordance with ASU 
2014
-
09,

[0001437749-19-008988:notes:141]
Revenue from Contracts with Customers
, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were 
not
 material. To report extended warranty in accordance with ASU 
2014
-
09,
 the net sales and gross profit amounts for the 
first
 quarter of 
2018
 have been revised by 
$2,457
 and 
$1,938,
 respectively, from the amounts previously reported in the Company’s 
first
 quarter 
2018
 Form 
10
-Q, with an equal offset to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was 
no
 impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets, the condensed consolidated statement of stockholders’ equity, or the condensed consolidated statements of cash flows.

[0001437749-19-008988:notes:142]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition contained in the Company’s credit agreements.

[0001437749-19-008988:notes:143]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. |

[0001437749-19-008988:notes:144]
[same as prior period, unchanged from 0001437749-18-019673:notes:153]

[0001437749-19-008988:notes:145]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-19-008988:notes:146]
|  | (4) | Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-19-008988:notes:147]
The Company’s sales in the United States represented approximately 
72%
 and 
71%
 of total sales for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 respectively. Approximately

[0001437749-19-008988:notes:148]
80%

[0001437749-19-008988:notes:149]
of the Company’s identifiable long-lived assets were located in the United States at 
 March 31, 2019 
and 
 December 31, 2018.


## us-gaap:SubsequentEventsTextBlock

[0001437749-19-008988:notes:150]
17.
 Subsequent Event

[0001437749-19-008988:notes:151]
On 
 April 26, 2019, 
the Company acquired Pika Energy, Inc. (Pika), a designer and manufacturer of energy storage technologies that capture and store solar or grid power for homeowners and business owners. Pika was founded in 
2010
 and is located in Westbrook, Maine.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-19-008988:notes:152]
8

[0001437749-19-008988:notes:153]
[same as prior period, unchanged from 0001437749-18-019673:notes:161]

[0001437749-19-008988:notes:154]
[same as prior period, unchanged from 0001437749-18-019673:notes:162]

[0001437749-19-008988:notes:155]
[same as prior period, unchanged from 0001437749-18-019673:notes:163]

[0001437749-19-008988:notes:156]
[same as prior period, unchanged from 0001437749-18-019673:notes:164]

[0001437749-19-008988:notes:157]
Total property and equipment included capital leases of 
$20,158
 at 
 December 31, 2018, 
primarily made up of buildings and improvements. Amortization of capital leases is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of capital leases is accounted for as a non-cash item in the condensed consolidated statement of cash flows. Refer to Note 
9,
 “Leases,” for further information regarding the Company’s accounting for leases under ASC 
842
 in 
2019.


## us-gaap:TreasuryStockTextBlock

[0001437749-19-008988:notes:158]
13

[0001437749-19-008988:notes:159]
[same as prior period, unchanged from 0001437749-18-019673:notes:166]

[0001437749-19-008988:notes:160]
[same as prior period, unchanged from 0001437749-18-019673:notes:167]

[0001437749-19-008988:notes:161]
In 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved a 
$250,000
 stock repurchase program, which expired in the 
fourth
 quarter of 
2018.
 In 
 September 2018, 
the Company’s Board of Directors approved another stock repurchase program, which commenced in 
 October 2018, 
and under which the Company 
 may 
repurchase an additional 
$250,000
 of its common stock over the following 
24
 months. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
three
 months ended 
 March 31, 2018, 
the Company repurchased 
560,000
 shares of its common stock for 
$25,656,
 funded with cash on hand. There were 
no
 share repurchases during the 
three
 months ended 
 March 31, 2019. 
Since the inception of the above noted programs, the Company has repurchased 
8,676,706
 shares of its common stock for 
$305,547,
 all funded with cash on hand.
