# GNRC note change history — 0001437749-18-019673 → 0001437749-19-008988


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001437749-19-008988:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2019 
and 
 December 31, 2018 
was approximately 
$48,600
 and 
$47,200,
 respectively.
  (was, 2018-11-06, similarity 0.988):
[0001437749-18-019673:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2018 
and 
 December 31, 2017 
was approximately 
$40,600
 and 
$36,500,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001437749-19-008988:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.
  (was, 2018-11-06, similarity 0.9802):
[0001437749-18-019673:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

- changed (2019-05-07):
[0001437749-19-008988:note_history:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018). 
A summary of acquisitions affecting the reporting periods presented include:
  (was, 2018-11-06, similarity 0.9887):
[0001437749-18-019673:note_history:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of its Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:

- added (2019-05-07):
[0001437749-19-008988:note_history:4]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. Captiva has seven sales locations throughout India and has over 100 employees. |

- added (2019-05-07):
[0001437749-19-008988:note_history:5]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

- changed (2019-05-07):
[0001437749-19-008988:note_history:6]
The condensed consolidated balance sheet as of 
 March 31, 2019, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 the condensed consolidated statements of stockholders’ equity for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2019 
and 
2018
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2018-11-06, similarity 0.8287):
[0001437749-18-019673:note_history:6]
The condensed consolidated balance sheets as of 
 September 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- changed (2019-05-07):
[0001437749-19-008988:note_history:7]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018.
  (was, 2018-11-06, similarity 0.9871):
[0001437749-18-019673:note_history:7]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.

- added (2019-05-07):
[0001437749-19-008988:note_history:8]
In 
 August 2018, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2018
-
15,

- changed (2019-05-07):
[0001437749-19-008988:note_history:9]
Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.
  (was, 2018-11-06, similarity 0.9563):
[0001437749-18-019673:note_history:9]
Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2019-05-07):
[0001437749-19-008988:note_history:10]
Recently Adopted Accounting Standards
  (was, 2018-11-06, similarity 0.7018):
[0001437749-18-019673:note_history:10]
Accounting Standards

- added (2019-05-07):
[0001437749-19-008988:note_history:11]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning 
no
 prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balances sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did 
not
 have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 
9,
 “Leases,” for further information regarding the Company’s leases.

- added (2019-05-07):
[0001437749-19-008988:note_history:12]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income
. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 
2017
 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to 
not
 reclassify the stranded income tax effects from AOCI to retained earnings.

- removed (2019-05-07):
[0001437749-18-019673:note_history:13]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers around the world. |

- removed (2019-05-07):
[0001437749-18-019673:note_history:14]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,
 Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company has developed a comprehensive project plan and established a cross-functional implementation team to evaluate the impact of the standard. The project plan includes evaluating the Company’s lease portfolio, analyzing the standard’s impact on the Company’s various types of lease contracts and identifying the reporting requirements of the standard. While the Company does 
not
 anticipate the impact to the statement of comprehensive income to be material, it is still calculating the impact the lease asset and lease liability will have on the balance sheet.

- removed (2019-05-07):
[0001437749-18-019673:note_history:15]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

- removed (2019-05-07):
[0001437749-18-019673:note_history:16]
Derivatives

- removed (2019-05-07):
[0001437749-18-019673:note_history:17]
and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- removed (2019-05-07):
[0001437749-18-019673:note_history:18]
In 
 August 2018, 
the FASB issued ASU 
2018
-
15,

- removed (2019-05-07):
[0001437749-18-019673:note_history:19]
Intangibles – Goodwill and Other – Internal-Use Software:

- removed (2019-05-07):
[0001437749-18-019673:note_history:20]
Recently Adopted

- removed (2019-05-07):
[0001437749-18-019673:note_history:21]
Improving the Presentation of Net Periodic Pension Cost and Net

- removed (2019-05-07):
[0001437749-18-019673:note_history:22]
Periodic

- removed (2019-05-07):
[0001437749-18-019673:note_history:23]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The adoption of this new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

- removed (2019-05-07):
[0001437749-18-019673:note_history:24]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. The changes in presentation of the proceeds from beneficial interests in securitization transactions were applied retrospectively to all periods presented.

- removed (2019-05-07):
[0001437749-18-019673:note_history:25]
On 
 January 1, 2018, 
the Company adopted ASU 
2014
-
09,

- removed (2019-05-07):
[0001437749-18-019673:note_history:26]
Revenue from Contracts with Customers
, and all related amendments (the “new revenue recognition standard”) using the full retrospective method, which requires application to all periods presented.

- removed (2019-05-07):
[0001437749-18-019673:note_history:27]
The impact of adopting the above standards on the Company’s previously reported condensed consolidated financial statements is as follows:

- removed (2019-05-07):
[0001437749-18-019673:note_history:28]
| Condensed Consolidated Balance Sheets |  | September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 320,626 |  |  | $ | (4,207 | ) |  | $ | 316,419 |  |
| Inventories |  |  | 349,023 |  |  |  | 7,359 |  |  |  | 356,382 |  |
| Other accrued liabilities |  |  | 109,362 |  |  |  | 5,584 |  |  |  | 114,946 |  |
| Deferred income taxes |  |  | 49,528 |  |  |  | (3,367 | ) |  |  | 46,161 |  |
| Other long-term liabilities |  |  | 69,556 |  |  |  | 6,178 |  |  |  | 75,734 |  |
| Retained earnings |  | $ | 535,172 |  |  | $ | (5,243 | ) |  | $ | 529,929 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:29]
|  |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:30]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 457,253 |  |  | $ | (1,414 | ) |  | $ | 455,839 |  |
| Cost of goods sold |  |  | 299,784 |  |  |  | (176 | ) |  |  | 299,608 |  |
| Selling and service expenses |  |  | 44,402 |  |  |  | (939 | ) |  |  | 43,463 |  |
| Research and development expenses |  |  | 10,864 |  |  |  | (14 | ) |  |  | 10,850 |  |
| General and administrative expenses |  |  | 22,102 |  |  |  | 26 |  |  |  | 22,128 |  |
| Other, net |  |  | 1,570 |  |  |  | 140 |  |  |  | 1,710 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | (177 | ) |  |  | 20,404 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | (274 | ) |  | $ | 39,435 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.64 |  |  | $ | - |  |  | $ | 0.64 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 43,213 |  |  | $ | (274 | ) |  | $ | 42,939 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:31]
|  |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 1,184,443 |  |  | $ | (3,244 | ) |  | $ | 1,181,199 |  |
| Cost of goods sold |  |  | 782,028 |  |  |  | 1,219 |  |  |  | 783,247 |  |
| Selling and service expenses |  |  | 127,702 |  |  |  | (2,762 | ) |  |  | 124,940 |  |
| Research and development expenses |  |  | 31,732 |  |  |  | (42 | ) |  |  | 31,690 |  |
| General and administrative expenses |  |  | 64,436 |  |  |  | 72 |  |  |  | 64,508 |  |
| Other, net |  |  | 3,105 |  |  |  | 420 |  |  |  | 3,525 |  |
| Provision for income taxes |  |  | 42,946 |  |  |  | (841 | ) |  |  | 42,105 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 78,211 |  |  | $ | (1,310 | ) |  | $ | 76,901 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.27 |  |  | $ | (0.02 | ) |  | $ | 1.25 |  |
| Diluted |  | $ | 1.26 |  |  | $ | (0.02 | ) |  | $ | 1.24 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 92,177 |  |  | $ | (1,310 | ) |  | $ | 90,867 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:32]
| Condensed Consolidated Statement of Cash Flows |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 78,644 |  |  | $ | (1,310 | ) |  | $ | 77,334 |  |
| Deferred income taxes |  |  | 28,703 |  |  |  | (3,367 | ) |  |  | 25,336 |  |
| Accounts receivable |  |  | (70,108 | ) |  |  | 2,105 |  |  |  | (68,003 | ) |
| Inventories |  |  | 16,738 |  |  |  | (7,359 | ) |  |  | 9,379 |  |
| Other accrued liabilities |  |  | 17,319 |  |  |  | 7,829 |  |  |  | 25,148 |  |
| Net cash provided by operating activities |  | $ | 122,719 |  |  | $ | (2,102 | ) |  | $ | 120,617 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 2,102 |  |  | $ | 2,102 |  |
| Net cash used in investing activities |  | $ | (15,324 | ) |  | $ | 2,102 |  |  | $ | (13,222 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001437749-19-008988:note_history:33]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 15,051 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,190 |  |  |  | 27,124 |  |
| Total |  | $ | 45,241 |  |  | $ | 45,583 |  |
  (was, 2018-11-06, similarity 0.9661):
[0001437749-18-019673:note_history:33]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | 11,000 |  |  | $ | - |  |
| Other lines of credit |  |  | 24,758 |  |  |  | 20,602 |  |
| Total |  | $ | 35,758 |  |  | $ | 20,602 |  |

- added (2019-05-07):
[0001437749-19-008988:note_history:34]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (21,263 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,714 |  |  |  | 20,171 |  |
| Other |  |  | 1,235 |  |  |  | 1,642 |  |
| Total |  |  | 884,686 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 888 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,315 |  |  |  | 902 |  |
| Total |  | $ | 882,483 |  |  | $ | 876,396 |  |

- changed (2019-05-07):
[0001437749-19-008988:note_history:35]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 The Term Loan agreement has been amended a number of times since inception.
  (was, 2018-11-06, similarity 0.6743):
[0001437749-18-019673:note_history:35]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans was reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, fell below 
3.00
 to 
1.00
 for that measurement period.

- changed (2019-05-07):
[0001437749-19-008988:note_history:36]
In 
 June 2018, 
the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
  (was, 2018-11-06, similarity 0.6667):
[0001437749-18-019673:note_history:36]
In 
 June 2018, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$829
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2018.

- changed (2019-05-07):
[0001437749-19-008988:note_history:37]
As of 
 March 31, 2019, 
the Company’s net secured leverage ratio was 
1.69
 to 
1.00
 times, and the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.
  (was, 2018-11-06, similarity 0.6553):
[0001437749-18-019673:note_history:37]
As of 
 September 30, 2018, 
the Company’s secured leverage ratio was 
1.82
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

- added (2019-05-07):
[0001437749-19-008988:note_history:38]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.00%
 or adjusted LIBOR rate plus an applicable margin of 
2.00%,
 in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

- changed (2019-05-07):
[0001437749-19-008988:note_history:39]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date to 
 June 12, 2023. 
In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
  (was, 2018-11-06, similarity 0.6316):
[0001437749-18-019673:note_history:39]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$755
 of new debt issuance costs as deferred financing costs on long-term borrowings in 
2018
 and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

- added (2019-05-07):
[0001437749-19-008988:note_history:40]
As of 
 March 31, 2019, 
there was 
$15,051
 outstanding under the ABL Facility, leaving 
$284,599
 of availability, net of outstanding letters of credit.

- changed (2019-05-07):
[0001437749-19-008988:note_history:41]
As of 
 March 31, 2019 
and 
 December 31, 2018, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled 
$45,241
 and 
$45,583,
 respectively.
  (was, 2018-11-06, similarity 0.9469):
[0001437749-18-019673:note_history:41]
As of 
 September 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the Amended ABL Facility, which totaled 
$35,758
 and 
$20,602,
 respectively.

- removed (2019-05-07):
[0001437749-18-019673:note_history:42]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,635 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,091 |  |  |  | 4,690 |  |
| Other |  |  | 2,055 |  |  |  | 1,367 |  |
| Total |  |  | 911,511 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 51,266 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 620 |  |  |  | 636 |  |
| Total |  | $ | 859,625 |  |  | $ | 906,548 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:43]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023

- removed (2019-05-07):
[0001437749-18-019673:note_history:44]
In 
 May 2017, 
the Company amended the Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing, however, is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2017.

- removed (2019-05-07):
[0001437749-18-019673:note_history:45]
In 
 December 2017, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminated future related payment requirements if the Company’s secured leverage ratio was maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in the 
fourth
 quarter of 
2017.

- removed (2019-05-07):
[0001437749-18-019673:note_history:46]
The Company’s credit agreements also originally provided for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility), with a maturity date of 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings originally bore interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

- removed (2019-05-07):
[0001437749-18-019673:note_history:47]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- removed (2019-05-07):
[0001437749-18-019673:note_history:48]
As of 
 September 30, 2018, 
there was 
$61,000
 outstanding under the Amended ABL Facility, leaving 
$207,498
 of availability, net of outstanding letters of credit. In 
 October 2018, 
the Company repaid the 
$50,000
 outstanding Amended ABL Facility balance classified as current portion of long-term borrowings as of 
 September 30, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-05-07):
[0001437749-19-008988:note_history:49]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (21,263 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,714 |  |  |  | 20,171 |  |
| Other |  |  | 1,235 |  |  |  | 1,642 |  |
| Total |  |  | 884,686 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 888 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,315 |  |  |  | 902 |  |
| Total |  | $ | 882,483 |  |  | $ | 876,396 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:50]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,635 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,091 |  |  |  | 4,690 |  |
| Other |  |  | 2,055 |  |  |  | 1,367 |  |
| Total |  |  | 911,511 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 51,266 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 620 |  |  |  | 636 |  |
| Total |  | $ | 859,625 |  |  | $ | 906,548 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001437749-19-008988:note_history:51]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 15,051 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,190 |  |  |  | 27,124 |  |
| Total |  | $ | 45,241 |  |  | $ | 45,583 |  |
  (was, 2018-11-06, similarity 0.9661):
[0001437749-18-019673:note_history:51]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | 11,000 |  |  | $ | - |  |
| Other lines of credit |  |  | 24,758 |  |  |  | 20,602 |  |
| Total |  | $ | 35,758 |  |  | $ | 20,602 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-07):
[0001437749-19-008988:note_history:52]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 205,181 |  |  | $ | 12,649 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 122,446 |  |  |  | 86,678 |  |  |  | 209,124 |  |
| Other |  |  | 31,621 |  |  |  | 11,778 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 359,248 |  |  | $ | 111,105 |  |  | $ | 470,353 |  |

- added (2019-05-07):
[0001437749-19-008988:note_history:53]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 176,685 |  |  | $ | 13,789 |  |  | $ | 190,474 |  |
| Commercial & industrial products |  |  | 97,771 |  |  |  | 77,354 |  |  |  | 175,125 |  |
| Other |  |  | 28,220 |  |  |  | 6,272 |  |  |  | 34,492 |  |
| Total net sales |  | $ | 302,676 |  |  | $ | 97,415 |  |  | $ | 400,091 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:54]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 30,920 |  |  |  | 10,311 |  |  |  | 41,231 |  |
| Total net sales |  | $ | 453,259 |  |  | $ | 106,256 |  |  | $ | 559,515 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:55]
|  |  | Three Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 236,821 |  |  | $ | 14,382 |  |  | $ | 251,203 |  |
| Commercial & industrial products |  |  | 101,122 |  |  |  | 72,720 |  |  |  | 173,842 |  |
| Other |  |  | 24,966 |  |  |  | 5,828 |  |  |  | 30,794 |  |
| Total net sales |  | $ | 362,909 |  |  | $ | 92,930 |  |  | $ | 455,839 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:56]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 83,078 |  |  |  | 23,111 |  |  |  | 106,189 |  |
| Total net sales |  | $ | 1,134,525 |  |  | $ | 317,573 |  |  | $ | 1,452,098 |  |

- removed (2019-05-07):
[0001437749-18-019673:note_history:57]
|  |  | Nine Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 563,636 |  |  | $ | 40,252 |  |  | $ | 603,888 |  |
| Commercial & industrial products |  |  | 284,796 |  |  |  | 209,702 |  |  |  | 494,498 |  |
| Other |  |  | 67,051 |  |  |  | 15,762 |  |  |  | 82,813 |  |
| Total net sales |  | $ | 915,483 |  |  | $ | 265,716 |  |  | $ | 1,181,199 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-07):
[0001437749-19-008988:note_history:58]
11.
 Contract Balances

- added (2019-05-07):
[0001437749-19-008988:note_history:59]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was 
$10,836
 and 
$14,174
 at 
 March 31, 2019 
and 
 December 31, 2018, 
respectively. During the 
three
 months ended 
 March 31, 2019, 
the Company recognized revenue of 
$5,691
 related to amounts included in the 
 December 31, 2018 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

- removed (2019-05-07):
[0001437749-18-019673:note_history:60]
2.
 Revenue Recognition

- removed (2019-05-07):
[0001437749-18-019673:note_history:61]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company’s contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

- removed (2019-05-07):
[0001437749-18-019673:note_history:62]
At the request of certain customers, the Company will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customer takes possession of the product.

- removed (2019-05-07):
[0001437749-18-019673:note_history:63]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$18,543
 and 
$7,034
 at 
 September 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
nine
 month period ended 
 September 30, 2018, 
the Company recognized revenue of 
$6,824
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

- removed (2019-05-07):
[0001437749-18-019673:note_history:64]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.

- removed (2019-05-07):
[0001437749-18-019673:note_history:65]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
-party marketing agreement, it is required to pay fees to the 
third
-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheets. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.

- removed (2019-05-07):
[0001437749-18-019673:note_history:66]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue in 
2018.

- removed (2019-05-07):
[0001437749-18-019673:note_history:67]
Refer to Note 
8,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-05-07):
[0001437749-19-008988:note_history:68]
17.
 Subsequent Event

- added (2019-05-07):
[0001437749-19-008988:note_history:69]
On 
 April 26, 2019, 
the Company acquired Pika Energy, Inc. (Pika), a designer and manufacturer of energy storage technologies that capture and store solar or grid power for homeowners and business owners. Pika was founded in 
2010
 and is located in Westbrook, Maine.
