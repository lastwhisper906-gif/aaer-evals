# GNRC MD&A — 0001437749-19-008988


## mdna

[0001437749-19-008988:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001437749-19-008988:mdna:2]
[same as prior period, unchanged from 0001437749-18-019673:mdna:2]

[0001437749-19-008988:mdna:3]
[same as prior period, unchanged from 0001437749-18-019673:mdna:3]

[0001437749-19-008988:mdna:4]
[same as prior period, unchanged from 0001437749-18-019673:mdna:4]

[0001437749-19-008988:mdna:5]
[same as prior period, unchanged from 0001437749-18-019673:mdna:5]

[0001437749-19-008988:mdna:6]
[same as prior period, unchanged from 0001437749-18-019673:mdna:6]

[0001437749-19-008988:mdna:7]
[same as prior period, unchanged from 0001437749-18-019673:mdna:7]

[0001437749-19-008988:mdna:8]
[same as prior period, unchanged from 0001437749-18-019673:mdna:8]

[0001437749-19-008988:mdna:9]
[same as prior period, unchanged from 0001437749-18-019673:mdna:9]

[0001437749-19-008988:mdna:10]
[same as prior period, unchanged from 0001437749-18-019673:mdna:10]

[0001437749-19-008988:mdna:11]
[same as prior period, unchanged from 0001437749-18-019673:mdna:11]

[0001437749-19-008988:mdna:12]
[same as prior period, unchanged from 0001437749-18-019673:mdna:12]

[0001437749-19-008988:mdna:13]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-19-008988:mdna:14]
[same as prior period, unchanged from 0001437749-18-019673:mdna:14]

[0001437749-19-008988:mdna:15]
[same as prior period, unchanged from 0001437749-18-019673:mdna:15]

[0001437749-19-008988:mdna:16]
[same as prior period, unchanged from 0001437749-18-019673:mdna:16]

[0001437749-19-008988:mdna:17]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-19-008988:mdna:18]
|  | ● | failures or security breaches of our networks or information technology systems; and |

[0001437749-19-008988:mdna:19]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-19-008988:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2018. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-19-008988:mdna:21]
[same as prior period, unchanged from 0001437749-18-019673:mdna:20]

[0001437749-19-008988:mdna:22]
We are a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other power products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-19-008988:mdna:23]
[same as prior period, unchanged from 0001437749-18-019673:mdna:23]

[0001437749-19-008988:mdna:24]
[same as prior period, unchanged from 0001437749-18-019673:mdna:24]

[0001437749-19-008988:mdna:25]
[same as prior period, unchanged from 0001437749-18-019673:mdna:25]

[0001437749-19-008988:mdna:26]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-19-008988:mdna:27]
Increasing penetration opportunity. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2017 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result, these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas-fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-19-008988:mdna:28]
Effect of large scale and baseline power disruptions. Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both 2017 and 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-19-008988:mdna:29]
[same as prior period, unchanged from 0001437749-18-019673:mdna:29]

[0001437749-19-008988:mdna:30]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment. We believe the passage of the Tax Act in 2017 will continue to have a favorable impact on future demand within many of the end markets that we serve, as the improved cash flow, liquidity and business sentiment may lead to further investments in equipment, facilities and infrastructure in the United States.

[0001437749-19-008988:mdna:31]
[same as prior period, unchanged from 0001437749-18-019673:mdna:31]

[0001437749-19-008988:mdna:32]
[same as prior period, unchanged from 0001437749-18-019673:mdna:32]

[0001437749-19-008988:mdna:33]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Also, acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can have a material impact on our results of operations.

[0001437749-19-008988:mdna:34]
[same as prior period, unchanged from 0001437749-18-019673:mdna:34]

[0001437749-19-008988:mdna:35]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 20% to 24% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 28% in the third quarter and 27% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-19-008988:mdna:36]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Interest expense increased slightly during the three months ended March 31, 2019 compared to the three months ended March 31, 2018, primarily due to an increase in the market LIBOR rate. The higher LIBOR rate was partially offset by lower interest rate spreads resulting from Term Loan and ABL Facility amendments in June 2018 and new interest rate swaps beginning in July 2018. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-19-008988:mdna:37]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $347 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2018 related to our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $90 million through 2021, assuming continued profitability of our U.S. business and a combined federal and state tax rate of 26%. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $32 million through 2020 and $26 million in 2021. Based on current business plans, we believe that our cash tax obligations through 2021 will be significantly reduced by these tax attributes, after which our cash tax obligation will increase. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s condensed consolidated financial statements.

[0001437749-19-008988:mdna:38]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q, and in Item 8 (Note 1 “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2018.

[0001437749-19-008988:mdna:39]
Recent Updates

[0001437749-19-008988:mdna:40]
The Company recently completed two acquisitions – Neurio Technology, Inc. (“Neurio,” acquired on March 12, 2019) and Pika Energy, Inc. (“Pika,” acquired on April 26, 2019). Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. Pika is a manufacturer of energy storage technologies that capture and store solar or grid power for homeowners or business owners. Together, these acquisitions provide the Company with the technology to enter the rapidly developing market for energy management and storage. By combining Generac’s strong distribution, brand, and market creation capabilities with Neurio’s valuable energy monitoring technologies and Pika’s expertise in energy storage, we believe we are well positioned to offer a new, differentiated line of products and solutions to help homeowners and business owners reduce their overall energy costs.

[0001437749-19-008988:mdna:41]
Further information on these  recent acquisitions can be found in Notes 1, “Description of Business and Basis of Presentation,” 2, “Acquisitions”, and 17, “Subsequent Event,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q.

[0001437749-19-008988:mdna:42]
[same as prior period, unchanged from 0001437749-18-019673:mdna:40]

[0001437749-19-008988:mdna:43]
Three months ended March 31, 2019 compared to the three months ended March 31, 2018

[0001437749-19-008988:mdna:44]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-19-008988:mdna:45]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |  | $ | 70,262 |  |  |  | 17.6 | % |
| Cost of goods sold |  |  | 308,178 |  |  |  | 258,164 |  |  |  | 50,014 |  |  |  | 19.4 | % |
| Gross profit |  |  | 162,175 |  |  |  | 141,927 |  |  |  | 20,248 |  |  |  | 14.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 47,289 |  |  |  | 44,620 |  |  |  | 2,669 |  |  |  | 6.0 | % |
| Research and development |  |  | 13,609 |  |  |  | 11,853 |  |  |  | 1,756 |  |  |  | 14.8 | % |
| General and administrative |  |  | 24,762 |  |  |  | 23,475 |  |  |  | 1,287 |  |  |  | 5.5 | % |
| Amortization of intangible assets |  |  | 5,342 |  |  |  | 5,632 |  |  |  | (290 | ) |  |  | -5.1 | % |
| Total operating expenses |  |  | 91,002 |  |  |  | 85,580 |  |  |  | 5,422 |  |  |  | 6.3 | % |
| Income from operations |  |  | 71,173 |  |  |  | 56,347 |  |  |  | 14,826 |  |  |  | 26.3 | % |
| Total other income (expense), net |  |  | (10,419 | ) |  |  | (11,161 | ) |  |  | 742 |  |  |  | -6.6 | % |
| Income before provision for income taxes |  |  | 60,754 |  |  |  | 45,186 |  |  |  | 15,568 |  |  |  | 34.5 | % |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |  |  | 3,569 |  |  |  | 31.3 | % |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |  |  | 11,999 |  |  |  | 35.5 | % |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |  |  | 783 |  |  |  | 626.4 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |  |  | 11,216 |  |  |  | 33.3 | % |

[0001437749-19-008988:mdna:46]
[same as prior period, unchanged from 0001437749-18-019673:mdna:44]

[0001437749-19-008988:mdna:47]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 359,248 |  |  | $ | 302,676 |  |  |  | 56,572 |  |  |  | 18.7 | % |
| International |  |  | 111,105 |  |  |  | 97,415 |  |  |  | 13,690 |  |  |  | 14.1 | % |
| Total net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |  |  | 70,262 |  |  |  | 17.6 | % |

[0001437749-19-008988:mdna:48]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 80,975 |  |  | $ | 65,475 |  |  |  | 15,500 |  |  |  | 23.7 | % |
| International |  |  | 6,153 |  |  |  | 6,306 |  |  |  | (153 | ) |  |  | -2.4 | % |
| Total Adjusted EBITDA |  | $ | 87,128 |  |  | $ | 71,781 |  |  |  | 15,347 |  |  |  | 21.4 | % |

[0001437749-19-008988:mdna:49]
[same as prior period, unchanged from 0001437749-18-019673:mdna:48]

[0001437749-19-008988:mdna:50]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 217,830 |  |  | $ | 190,474 |  |  |  | 27,356 |  |  |  | 14.4 | % |
| Commercial & industrial products |  |  | 209,124 |  |  |  | 175,125 |  |  |  | 33,999 |  |  |  | 19.4 | % |
| Other |  |  | 43,399 |  |  |  | 34,492 |  |  |  | 8,907 |  |  |  | 25.8 | % |
| Total net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |  |  | 70,262 |  |  |  | 17.6 | % |

[0001437749-19-008988:mdna:51]
Net sales.    The increase in Domestic sales for the three months ended March 31, 2019 was due to growth in shipments of home standby generators given continued strong end market conditions as a result of increased power outage severity in recent years. In addition, shipments of C&I stationary generators also increased during the quarter, particularly for telecom and healthcare applications. These increases were partially offset by lower shipments of portable generators, as the prior year benefitted from elevated power outage activity in the Northeast. The net sales contribution from non-annualized recent acquisitions to the three months ended March 31, 2019 was $0.6 million.

[0001437749-19-008988:mdna:52]
The increase in International sales for the three months ended March 31, 2019 was primarily due to continued market share gains and further execution of synergies, particularly in Europe, Middle East, China and Brazil. This increase in sales was partially offset by an unfavorable foreign currency impact.

[0001437749-19-008988:mdna:53]
Overall, the net sales contribution from all non-annualized recent acquisitions to the three months ended March 31, 2019 was $14.3 million.

[0001437749-19-008988:mdna:54]
[same as prior period, unchanged from 0001437749-18-019673:mdna:47]

[0001437749-19-008988:mdna:55]
Gross profit.    Gross profit margin for the first quarter of 2019 was 34.5% compared to 35.5% in the prior-year first quarter. The decrease in gross profit margin was the result of a favorable sales mix shift towards higher margin home standby generator sales and price increases implemented since prior year, more than offset by the impact of recent acquisitions and the realization of higher input costs, including increased regulatory tariffs, logistics costs, labor rates, and commodities.

[0001437749-19-008988:mdna:56]
Operating expenses.   The increase in Operating expenses was primarily driven by incremental variable operating expense on the strong sales growth, an increase in employee headcount related to strategic initiatives, and additional recurring operating expenses from recent acquisitions.  These increases were partially offset by lower International operating expenses which were impacted by the weaker Euro.

[0001437749-19-008988:mdna:57]
Other expense.    The decrease in Other expense, net was primarily due to an increase in investment income.

[0001437749-19-008988:mdna:58]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2019 and 2018 were 24.7% and 25.3%, respectively. The decrease in the effective income tax rate in 2019 was primarily due to the mixture of taxable income in the jurisdictions where we pay tax and state tax credits.

[0001437749-19-008988:mdna:59]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate recorded during the current year quarter.

[0001437749-19-008988:mdna:60]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $81.0 million, or 22.5% of net sales, as compared to $65.5 million in the prior year, or 21.6% of net sales. Adjusted EBITDA margin in the current year benefitted from favorable sales mix, pricing initiatives, and fixed operating cost leverage on the higher sales volumes. These favorable impacts were partially offset by higher input costs, unfavorable commodity fluctuations, and increased employee costs.

[0001437749-19-008988:mdna:61]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $6.2 million, or 5.5% of net sales, as compared to $6.3 million in the prior year, or 6.5% of net sales. The decrease in Adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable regional and customer sales mix and higher input costs.

[0001437749-19-008988:mdna:62]
Adjusted Net Income.    Adjusted Net Income of $56.5 million for the three months ended March 31, 2019 increased 22.6% from $46.1 million for the three months ended March 31, 2018, due to the factors outlined above partially offset by an increase in cash income tax expense.

[0001437749-19-008988:mdna:63]
[same as prior period, unchanged from 0001437749-18-019673:mdna:60]

[0001437749-19-008988:mdna:64]
[same as prior period, unchanged from 0001437749-18-019673:mdna:80]

[0001437749-19-008988:mdna:65]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-19-008988:mdna:66]
Our credit agreements originally provided for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2019, the Company’s secured leverage ratio was 1.69 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-008988:mdna:67]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023. As of March 31, 2019, there were $15.1 million of borrowings outstanding and $284.6 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of March 31, 2019.

[0001437749-19-008988:mdna:68]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. For the three months ended March 31, 2018, the Company repurchased 560,000 shares of its common stock for $25.7 million. There were no share repurchases during the three months ended March 31, 2019. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand.

[0001437749-19-008988:mdna:69]
See Note 12, “Credit Agreements” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-19-008988:mdna:70]
[same as prior period, unchanged from 0001437749-18-019673:mdna:87]

[0001437749-19-008988:mdna:71]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-19-008988:mdna:72]
[same as prior period, unchanged from 0001437749-18-019673:mdna:89]

[0001437749-19-008988:mdna:73]
Three months ended March 31, 2019 compared to the three months ended March 31, 2018

[0001437749-19-008988:mdna:74]
[same as prior period, unchanged from 0001437749-18-019673:mdna:91]

[0001437749-19-008988:mdna:75]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 14,571 |  |  | $ | 28,968 |  |  | $ | (14,397 | ) |  |  | -49.7 | % |
| Net cash used in investing activities |  |  | (76,685 | ) |  |  | (5,997 | ) |  |  | (70,688 | ) |  |  | 1178.7 | % |
| Net cash used in financing activities |  |  | (1,622 | ) |  |  | (16,200 | ) |  |  | 14,578 |  |  |  | -90.0 | % |

[0001437749-19-008988:mdna:76]
The decrease in net cash provided by operating activities was driven by a variety of factors including higher working capital usage as well as higher incentive compensation payments in the current year partially offset by an increase in operating earnings as compared to prior year.

[0001437749-19-008988:mdna:77]
Net cash used in investing activities for the three months ended March 31, 2019 primarily represents cash payments of $61.5 million related to the acquisition of businesses and $15.9 million related to the purchase of property and equipment. Net cash used in investing activities for the three months ended March 31, 2018 primarily represents cash payments for the purchase of property and equipment.

[0001437749-19-008988:mdna:78]
Net cash used in financing activities for the three months ended March 31, 2019 primarily represents $14.2 million of debt repayments ($13.3 million of short-term borrowings and $0.9 million of long-term borrowings and capital lease obligations), partially offset by $13.5 million of cash proceeds from short-term borrowings.

[0001437749-19-008988:mdna:79]
Net cash used in financing activities for the three months ended March 31, 2018 primarily represents $14.3 million of cash proceeds from short-term borrowings, partially offset by $4.3 million of debt repayments ($3.9 million of short-term borrowings and $0.4 million of long-term borrowings and capital lease obligations), as well as $25.7 million cash used for stock repurchases under previously announced stock repurchase programs.

[0001437749-19-008988:mdna:80]
[same as prior period, unchanged from 0001437749-18-019673:mdna:97]

[0001437749-19-008988:mdna:81]
There have been no material changes to our contractual obligations since the February 26, 2019 filing of our Annual Report on Form 10-K for the year ended December 31, 2018.

[0001437749-19-008988:mdna:82]
[same as prior period, unchanged from 0001437749-18-019673:mdna:99]

[0001437749-19-008988:mdna:83]
There have been no material changes to off-balance sheet arrangements since the February 26, 2019 filing of our Annual Report on Form 10-K for the year ended December 31, 2018.

[0001437749-19-008988:mdna:84]
[same as prior period, unchanged from 0001437749-18-019673:mdna:101]

[0001437749-19-008988:mdna:85]
There have been no material changes in our critical accounting policies since the February 26, 2019 filing of our Annual Report on Form 10-K for the year ended December 31, 2018.

[0001437749-19-008988:mdna:86]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2018, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-19-008988:mdna:87]
[same as prior period, unchanged from 0001437749-18-019673:mdna:104]

[0001437749-19-008988:mdna:88]
[same as prior period, unchanged from 0001437749-18-019673:mdna:105]

[0001437749-19-008988:mdna:89]
[same as prior period, unchanged from 0001437749-18-019673:mdna:106]

[0001437749-19-008988:mdna:90]
[same as prior period, unchanged from 0001437749-18-019673:mdna:107]

[0001437749-19-008988:mdna:91]
[same as prior period, unchanged from 0001437749-18-019673:mdna:108]

[0001437749-19-008988:mdna:92]
[same as prior period, unchanged from 0001437749-18-019673:mdna:109]

[0001437749-19-008988:mdna:93]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2019 Proxy Statement; |

[0001437749-19-008988:mdna:94]
[same as prior period, unchanged from 0001437749-18-019673:mdna:111]

[0001437749-19-008988:mdna:95]
[same as prior period, unchanged from 0001437749-18-019673:mdna:112]

[0001437749-19-008988:mdna:96]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. GAAP and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-19-008988:mdna:97]
[same as prior period, unchanged from 0001437749-18-019673:mdna:114]

[0001437749-19-008988:mdna:98]
[same as prior period, unchanged from 0001437749-18-019673:mdna:115]

[0001437749-19-008988:mdna:99]
[same as prior period, unchanged from 0001437749-18-019673:mdna:116]

[0001437749-19-008988:mdna:100]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-19-008988:mdna:101]
[same as prior period, unchanged from 0001437749-18-019673:mdna:118]

[0001437749-19-008988:mdna:102]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-19-008988:mdna:103]
[same as prior period, unchanged from 0001437749-18-019673:mdna:120]

[0001437749-19-008988:mdna:104]
We explain in more detail in footnotes (a) through (d) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-19-008988:mdna:105]
[same as prior period, unchanged from 0001437749-18-019673:mdna:122]

[0001437749-19-008988:mdna:106]
[same as prior period, unchanged from 0001437749-18-019673:mdna:123]

[0001437749-19-008988:mdna:107]
[same as prior period, unchanged from 0001437749-18-019673:mdna:124]

[0001437749-19-008988:mdna:108]
[same as prior period, unchanged from 0001437749-18-019673:mdna:125]

[0001437749-19-008988:mdna:109]
[same as prior period, unchanged from 0001437749-18-019673:mdna:126]

[0001437749-19-008988:mdna:110]
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-19-008988:mdna:111]
[same as prior period, unchanged from 0001437749-18-019673:mdna:128]

[0001437749-19-008988:mdna:112]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-19-008988:mdna:113]
[same as prior period, unchanged from 0001437749-18-019673:mdna:130]

[0001437749-19-008988:mdna:114]
[same as prior period, unchanged from 0001437749-18-019673:mdna:132]

[0001437749-19-008988:mdna:115]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |
| Interest expense |  |  | 10,272 |  |  |  | 10,113 |  |
| Depreciation and amortization |  |  | 12,607 |  |  |  | 11,683 |  |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |
| Non-cash write-down and other adjustments (a) |  |  | (1,400 | ) |  |  | 1,306 |  |
| Non-cash share-based compensation expense (b) |  |  | 3,594 |  |  |  | 3,106 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,286 |  |  |  | 262 |  |
| Business optimization expenses (d) |  |  | 169 |  |  |  | 138 |  |
| Other |  |  | (154 | ) |  |  | (13 | ) |
| Adjusted EBITDA |  |  | 87,128 |  |  |  | 71,781 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,050 |  |  |  | 1,549 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 85,078 |  |  | $ | 70,232 |  |

[0001437749-19-008988:mdna:116]
[same as prior period, unchanged from 0001437749-18-019673:mdna:134]

[0001437749-19-008988:mdna:117]
[same as prior period, unchanged from 0001437749-18-019673:mdna:135]

[0001437749-19-008988:mdna:118]
[same as prior period, unchanged from 0001437749-18-019673:mdna:136]

[0001437749-19-008988:mdna:119]
24

[0001437749-19-008988:mdna:120]
[same as prior period, unchanged from 0001437749-18-019673:mdna:137]

[0001437749-19-008988:mdna:121]
[same as prior period, unchanged from 0001437749-18-019673:mdna:138]

[0001437749-19-008988:mdna:122]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-19-008988:mdna:123]
(d)  Represents severance and other non-recurring plant consolidation costs. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-19-008988:mdna:124]
[same as prior period, unchanged from 0001437749-18-019673:mdna:142]

[0001437749-19-008988:mdna:125]
[same as prior period, unchanged from 0001437749-18-019673:mdna:143]

[0001437749-19-008988:mdna:126]
[same as prior period, unchanged from 0001437749-18-019673:mdna:144]

[0001437749-19-008988:mdna:127]
[same as prior period, unchanged from 0001437749-18-019673:mdna:145]

[0001437749-19-008988:mdna:128]
[same as prior period, unchanged from 0001437749-18-019673:mdna:146]

[0001437749-19-008988:mdna:129]
[same as prior period, unchanged from 0001437749-18-019673:mdna:147]

[0001437749-19-008988:mdna:130]
[same as prior period, unchanged from 0001437749-18-019673:mdna:148]

[0001437749-19-008988:mdna:131]
[same as prior period, unchanged from 0001437749-18-019673:mdna:149]

[0001437749-19-008988:mdna:132]
[same as prior period, unchanged from 0001437749-18-019673:mdna:150]

[0001437749-19-008988:mdna:133]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |
| Income before provision for income taxes |  |  | 60,754 |  |  |  | 45,186 |  |
| Amortization of intangible assets |  |  | 5,342 |  |  |  | 5,632 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,177 |  |  |  | 1,177 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 1,035 |  |  |  | 20 |  |
| Business optimization expenses |  |  | 169 |  |  |  | 138 |  |
| Adjusted net income before provision for income taxes |  |  | 68,477 |  |  |  | 52,153 |  |
| Cash income tax expense (b) |  |  | (10,510 | ) |  |  | (5,410 | ) |
| Adjusted net income |  |  | 57,967 |  |  |  | 46,743 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,474 |  |  |  | 661 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 56,493 |  |  | $ | 46,082 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.91 |  |  | $ | 0.74 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,223,638 |  |  |  | 62,474,936 |  |

[0001437749-19-008988:mdna:134]
(a)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-19-008988:mdna:135]
(b)  Amount for the three months ended March 31, 2019 is based on an anticipated cash income tax rate at that time of approximately 17% for the full year ended 2019. Amount for the three months ended March 31, 2018 is based on an anticipated cash income tax rate of approximately 13% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-19-008988:mdna:136]
[same as prior period, unchanged from 0001437749-18-019673:mdna:154]

[0001437749-19-008988:mdna:137]
Refer to Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements for further information on the new accounting standards applicable to the Company.
