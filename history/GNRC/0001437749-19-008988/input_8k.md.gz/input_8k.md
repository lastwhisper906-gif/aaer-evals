# GNRC 8-K — 0001437749-19-008474 filed 2019-05-02

## item codes, every 8-K on or before 2019-05-07

- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2019-05-07

- none on or before 2019-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-19-008474:8k_2_02:1]
EX-99.1
2
ex_142580.htm
EXHIBIT 99.1

[0001437749-19-008474:8k_2_02:2]
ex_142580.htm

[0001437749-19-008474:8k_2_02:3]
Exhibit 99.1

[0001437749-19-008474:8k_2_02:4]
Generac Reports First Quarter 2019 Results

[0001437749-19-008474:8k_2_02:5]
Strong end market fundamentals drive increased 2019 outlook;

[0001437749-19-008474:8k_2_02:6]
Recent acquisitions accelerate entry into rapidly developing energy management and storage market

[0001437749-19-008474:8k_2_02:7]
WAUKESHA, WISCONSIN (May 2, 2019) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other power products, today reported financial results for its first quarter ended March 31, 2019.

[0001437749-19-008474:8k_2_02:8]
First Quarter 2019 Highlights

[0001437749-19-008474:8k_2_02:9]
| ● | Net sales increased 17.6% to $470.4 million during the first quarter of 2019 as compared to $400.1 million in the prior-year first quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was approximately 15%. |

[0001437749-19-008474:8k_2_02:10]
|  | - | Residential product sales increased 14.4% to $217.8 million as compared to $190.5 million last year. |

[0001437749-19-008474:8k_2_02:11]
|  | - | Commercial & Industrial (“C&I”) product sales increased 19.4% to $209.1 million as compared to $175.1 million in the prior year, with core sales growth of approximately 17%. |

[0001437749-19-008474:8k_2_02:12]
| ● | Net income attributable to the Company during the first quarter was $44.9 million, or $0.76 per share, as compared to $33.6 million, or $0.42 per share, for the same period of 2018. |

[0001437749-19-008474:8k_2_02:13]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $56.5 million, or $0.91 per share, as compared to $46.1 million, or $0.74 per share, in the first quarter of 2018. |

[0001437749-19-008474:8k_2_02:14]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $87.1 million, or 18.5% of net sales, as compared to $71.8 million, or 17.9% of net sales, in the prior year. |

[0001437749-19-008474:8k_2_02:15]
| ● | Cash flow from operations was $14.6 million as compared to $29.0 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $(0.6) million as compared to $23.3 million in the first quarter of 2018. Higher operating earnings in the current year quarter were more than offset by increased incentive compensation payments related to fiscal 2018 performance and higher levels of capital expenditures. |

[0001437749-19-008474:8k_2_02:16]
| ● | As previously announced on March 13, 2019, the Company closed on the acquisition of Neurio Technology. Founded in 2005 and headquartered in Vancouver, British Columbia, Neurio is a leading energy data company focused on monitoring technology and sophisticated analytics to optimize energy use within a home or business. Neurio’s hardware and software solutions equip users with the intelligence to manage and control electrical loads, solar systems and batteries to optimize energy consumption and increase savings. |

[0001437749-19-008474:8k_2_02:17]
| ● | Also, as previously announced on April 29, 2019, the Company closed on the acquisition of Pika Energy. Founded in 2010 and located near Portland, Maine, Pika Energy develops and manufactures advanced power electronics, software and controls for smart energy storage and management. Pika’s innovative home energy storage solutions make them one of the leaders in the rapidly growing market for energy storage technology. |

[0001437749-19-008474:8k_2_02:18]
“Our outstanding first quarter results reflect continued end market strength as we entered 2019,” said Aaron Jagdfeld, President and Chief Executive Officer. “Both residential and C&I generator activity remained strong during the quarter with spending on backup power for telecom applications in particular coming in ahead of expectations as wireless carriers continue to invest in hardening their networks.”

[0001437749-19-008474:8k_2_02:19]
Jagdfeld continued, “In addition to our impressive start to the year, with our recent acquisitions of Neurio and Pika, we have accelerated our entry into the global market for energy management and storage, which we believe to be a multi-billion dollar opportunity as this market matures. By combining Generac’s strong distribution, brand, and market creation capabilities with Neurio’s valuable energy monitoring technologies and Pika’s expertise in energy storage, we believe we are well positioned to offer a new, differentiated line of products and solutions to help homeowners and business owners reduce their overall energy costs.”

[0001437749-19-008474:8k_2_02:20]
1

[0001437749-19-008474:8k_2_02:21]
Additional First Quarter 2019 Consolidated Highlights

[0001437749-19-008474:8k_2_02:22]
Gross profit margin was 34.5% compared to 35.5% in the prior-year first quarter. Favorable sales mix and pricing actions were more than offset by realization of higher input costs, including regulatory tariffs, logistics and labor costs, as well as unfavorable commodity fluctuations.

[0001437749-19-008474:8k_2_02:23]
Operating expenses increased $5.4 million, or 6.3%, as compared to the first quarter of 2018. The increase was primarily driven by higher variable costs given the strong core sales volumes, an increase in employee headcount related to strategic initiatives, and recurring operating expenses from recent acquisitions.

[0001437749-19-008474:8k_2_02:24]
Provision for income taxes for the current year quarter was $15.0 million, or an effective tax rate of 24.7%, as compared to $11.4 million, or a 25.3% effective tax rate, for the prior year.

[0001437749-19-008474:8k_2_02:25]
On January 1, 2019, the Company adopted Accounting Standards Update 2016-02, Leases. As a result of this new lease accounting standard, the Company was required to recognize approximately $40 million of right-of-use assets and lease liabilities related to operating leases on the condensed consolidated balance sheet.

[0001437749-19-008474:8k_2_02:26]
Business Segment Results

[0001437749-19-008474:8k_2_02:27]
Domestic Segment

[0001437749-19-008474:8k_2_02:28]
Domestic segment sales increased 18.7% to $359.2 million as compared to $302.7 million in the prior-year quarter. The current-year quarter experienced robust growth in shipments of home standby generators given continued strong end market conditions as a result of increased power outage severity in recent years. In addition, C&I stationary generator shipments were also strong during the quarter, particularly for telecom and healthcare applications. The overall Domestic segment growth was partially offset by lower shipments of portable generators as the prior year quarter benefitted from elevated outage activity in the Northeast.

[0001437749-19-008474:8k_2_02:29]
Adjusted EBITDA for the segment was $81.0 million, or 22.5% of net sales, as compared to $65.5 million in the prior year, or 21.6% of net sales. Favorable sales mix, pricing initiatives and fixed operating cost leverage were partially offset by the aforementioned higher input costs, as well as increased employee costs.

[0001437749-19-008474:8k_2_02:30]
International Segment

[0001437749-19-008474:8k_2_02:31]
International segment sales increased 14.1% to $111.1 million as compared to $97.4 million in the prior-year quarter. Core sales growth, which excludes the impact of the Selmec and Captiva acquisitions, as well as the unfavorable impact of currency, was approximately 6%. This core sales increase was primarily driven by continued market share gains and further execution of synergies, particularly in Europe, Middle East, China, and Brazil.

[0001437749-19-008474:8k_2_02:32]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $6.2 million, or 5.5% of net sales, as compared to $6.3 million, or 6.5% of net sales, in the prior year. Although unfavorable regional sales mix and higher input costs drove this modest year over year decline, margins for the segment have improved by 130 basis points over the last twelve months.

[0001437749-19-008474:8k_2_02:33]
Updated 2019 Outlook

[0001437749-19-008474:8k_2_02:34]
The Company is increasing its prior guidance for revenue growth for full-year 2019, reflecting the stronger demand for Residential and C&I products, as well as the addition of the Neurio and Pika acquisitions. Depending on the severity of power outages during the year, full-year net sales are expected to grow by approximately 5 to 9%, which is an increase from the 3 to 7% growth previously expected. Core sales growth for the full year is expected to be approximately 3 to 7%, which is an increase from the 2 to 6% core growth previously expected. Seasonally, first half net sales are now expected to grow 12 to 13% on an as-reported basis, with growth in the second half expected to be approximately flat to up mid-single-digits, depending on the severity of power outages.

[0001437749-19-008474:8k_2_02:35]
Net income margins, before deducting for noncontrolling interests, are now expected to be between 10.5 to 11.5% for the full-year 2019. Adjusted EBITDA margins, also before deducting for noncontrolling interests, are now expected to be between 19.5 to 20.5% for the year, depending on the severity of power outages during the year. This modest decline in margin outlook is primarily driven by the Neurio and Pika acquisitions, which include strategic investments in product development and infrastructure to build out and penetrate the new market opportunities around energy management and storage.

[0001437749-19-008474:8k_2_02:36]
Operating and free cash flow generation is still expected to be strong, with the conversion of adjusted net income to free cash flow expected to be over 90%.

[0001437749-19-008474:8k_2_02:37]
Conference Call and Webcast

[0001437749-19-008474:8k_2_02:38]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, May 2, 2019 to discuss first quarter 2019 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 7667828.

[0001437749-19-008474:8k_2_02:39]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-19-008474:8k_2_02:40]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 7667828. The telephonic replay will be available for 7 days.

[0001437749-19-008474:8k_2_02:41]
About Generac

[0001437749-19-008474:8k_2_02:42]
Founded in 1959, Generac is a leading designer and manufacturer of a wide range of power generation equipment and other power products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-008474:8k_2_02:43]
Forward-looking Information

[0001437749-19-008474:8k_2_02:44]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-19-008474:8k_2_02:45]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-19-008474:8k_2_02:46]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-19-008474:8k_2_02:47]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing our products; |

[0001437749-19-008474:8k_2_02:48]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-19-008474:8k_2_02:49]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-19-008474:8k_2_02:50]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-19-008474:8k_2_02:51]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-19-008474:8k_2_02:52]
|  | ● | our dependence on our distribution network; |

[0001437749-19-008474:8k_2_02:53]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-19-008474:8k_2_02:54]
|  | ● | loss of our key management and employees; |

[0001437749-19-008474:8k_2_02:55]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-19-008474:8k_2_02:56]
|  | ● | failures or security breaches of our networks or information technology systems; and |

[0001437749-19-008474:8k_2_02:57]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-19-008474:8k_2_02:58]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2018 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-19-008474:8k_2_02:59]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-19-008474:8k_2_02:60]
Non-GAAP Financial Metrics

[0001437749-19-008474:8k_2_02:61]
Core Sales

[0001437749-19-008474:8k_2_02:62]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-19-008474:8k_2_02:63]
Adjusted EBITDA

[0001437749-19-008474:8k_2_02:64]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-19-008474:8k_2_02:65]
Adjusted Net Income

[0001437749-19-008474:8k_2_02:66]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-19-008474:8k_2_02:67]
Free Cash Flow

[0001437749-19-008474:8k_2_02:68]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-19-008474:8k_2_02:69]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-19-008474:8k_2_02:70]
SOURCE: Generac Holdings Inc.

[0001437749-19-008474:8k_2_02:71]
CONTACT:

[0001437749-19-008474:8k_2_02:72]
York Ragen

[0001437749-19-008474:8k_2_02:73]
Chief Financial Officer

[0001437749-19-008474:8k_2_02:74]
(262) 506-6064

[0001437749-19-008474:8k_2_02:75]
InvestorRelations@generac.com

[0001437749-19-008474:8k_2_02:76]
Generac Holdings Inc.

[0001437749-19-008474:8k_2_02:77]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-19-008474:8k_2_02:78]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-19-008474:8k_2_02:79]
(Unaudited)

[0001437749-19-008474:8k_2_02:80]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |
| Costs of goods sold |  |  | 308,178 |  |  |  | 258,164 |  |
| Gross profit |  |  | 162,175 |  |  |  | 141,927 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 47,289 |  |  |  | 44,620 |  |
| Research and development |  |  | 13,609 |  |  |  | 11,853 |  |
| General and administrative |  |  | 24,762 |  |  |  | 23,475 |  |
| Amortization of intangibles |  |  | 5,342 |  |  |  | 5,632 |  |
| Total operating expenses |  |  | 91,002 |  |  |  | 85,580 |  |
| Income from operations |  |  | 71,173 |  |  |  | 56,347 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,272 | ) |  |  | (10,113 | ) |
| Investment income |  |  | 914 |  |  |  | 346 |  |
| Other, net |  |  | (1,061 | ) |  |  | (1,394 | ) |
| Total other expense, net |  |  | (10,419 | ) |  |  | (11,161 | ) |
| Income before provision for income taxes |  |  | 60,754 |  |  |  | 45,186 |  |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.77 |  |  | $ | 0.42 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,762,260 |  |  |  | 61,943,495 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.76 |  |  | $ | 0.42 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,223,638 |  |  |  | 62,474,936 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 39,527 |  |  | $ | 44,703 |  |

[0001437749-19-008474:8k_2_02:81]
6

[0001437749-19-008474:8k_2_02:82]
Generac Holdings Inc.

[0001437749-19-008474:8k_2_02:83]
Condensed Consolidated Balance Sheets

[0001437749-19-008474:8k_2_02:84]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-19-008474:8k_2_02:85]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Assets |  | (Unaudited) |  |  | (Audited) |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 161,266 |  |  | $ | 224,482 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 284,612 |  |  |  | 326,133 |  |
| Inventories |  |  | 588,380 |  |  |  | 544,750 |  |
| Prepaid expenses and other assets |  |  | 28,537 |  |  |  | 25,404 |  |
| Total current assets |  |  | 1,062,795 |  |  |  | 1,120,769 |  |
| Property and equipment, net |  |  | 289,438 |  |  |  | 278,929 |  |
| Customer lists, net |  |  | 59,450 |  |  |  | 61,194 |  |
| Patents, net |  |  | 27,557 |  |  |  | 29,970 |  |
| Other intangible assets, net |  |  | 2,930 |  |  |  | 3,043 |  |
| Tradenames, net |  |  | 151,174 |  |  |  | 152,283 |  |
| Goodwill |  |  | 828,403 |  |  |  | 764,655 |  |
| Deferred income taxes |  |  | 4,385 |  |  |  | 163 |  |
| Operating lease and other assets |  |  | 47,590 |  |  |  | 15,308 |  |
| Total assets |  | $ | 2,473,722 |  |  | $ | 2,426,314 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 45,241 |  |  | $ | 45,583 |  |
| Accounts payable |  |  | 290,871 |  |  |  | 328,091 |  |
| Accrued wages and employee benefits |  |  | 26,659 |  |  |  | 40,819 |  |
| Other accrued liabilities |  |  | 151,005 |  |  |  | 144,236 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 2,203 |  |  |  | 1,977 |  |
| Total current liabilities |  |  | 515,979 |  |  |  | 560,706 |  |
| Long-term borrowings and finance lease obligations |  |  | 882,483 |  |  |  | 876,396 |  |
| Deferred income taxes |  |  | 78,877 |  |  |  | 71,300 |  |
| Operating lease and other long-term liabilities |  |  | 129,071 |  |  |  | 95,647 |  |
| Total liabilities |  |  | 1,606,410 |  |  |  | 1,604,049 |  |
| Redeemable noncontrolling interest |  |  | 57,357 |  |  |  | 61,004 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,395,561 and 71,186,418 shares issued at March 31, 2019 and December 31, 2018, respectively |  |  | 714 |  |  |  | 712 |  |
| Additional paid-in capital |  |  | 481,391 |  |  |  | 476,116 |  |
| Treasury stock, at cost |  |  | (324,115 | ) |  |  | (321,473 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 878,416 |  |  |  | 831,123 |  |
| Accumulated other comprehensive loss |  |  | (29,870 | ) |  |  | (23,813 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 804,420 |  |  |  | 760,549 |  |
| Noncontrolling interests |  |  | 5,535 |  |  |  | 712 |  |
| Total stockholders’ equity |  |  | 809,955 |  |  |  | 761,261 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,473,722 |  |  | $ | 2,426,314 |  |

[0001437749-19-008474:8k_2_02:86]
Generac Holdings Inc.

[0001437749-19-008474:8k_2_02:87]
Condensed Consolidated Statements of Cash Flows

[0001437749-19-008474:8k_2_02:88]
(U.S. Dollars in Thousands)

[0001437749-19-008474:8k_2_02:89]
(Unaudited)

[0001437749-19-008474:8k_2_02:90]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 45,769 |  |  | $ | 33,770 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 7,265 |  |  |  | 6,051 |  |
| Amortization of intangible assets |  |  | 5,342 |  |  |  | 5,632 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,177 |  |  |  | 1,177 |  |
| Deferred income taxes |  |  | 5,151 |  |  |  | 4,283 |  |
| Share-based compensation expense |  |  | 3,594 |  |  |  | 3,106 |  |
| Other |  |  | 66 |  |  |  | 102 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 46,970 |  |  |  | 18,744 |  |
| Inventories |  |  | (41,644 | ) |  |  | (48,798 | ) |
| Other assets |  |  | (1,293 | ) |  |  | 2,658 |  |
| Accounts payable |  |  | (37,176 | ) |  |  | (9,439 | ) |
| Accrued wages and employee benefits |  |  | (14,148 | ) |  |  | 813 |  |
| Other accrued liabilities |  |  | (5,762 | ) |  |  | 11,065 |  |
| Excess tax benefits from equity awards |  |  | (740 | ) |  |  | (196 | ) |
| Net cash provided by operating activities |  |  | 14,571 |  |  |  | 28,968 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 23 |  |  |  | 1 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 743 |  |  |  | 867 |  |
| Expenditures for property and equipment |  |  | (15,902 | ) |  |  | (6,496 | ) |
| Acquisition of business, net of cash acquired |  |  | (61,549 | ) |  |  | (369 | ) |
| Net cash used in investing activities |  |  | (76,685 | ) |  |  | (5,997 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 13,531 |  |  |  | 14,315 |  |
| Repayments of short-term borrowings |  |  | (13,282 | ) |  |  | (3,911 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (908 | ) |  |  | (408 | ) |
| Stock repurchases |  |  | – |  |  |  | (25,656 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | – |  |  |  | (314 | ) |
| Taxes paid related to equity awards |  |  | (3,156 | ) |  |  | (1,626 | ) |
| Proceeds from the exercise of stock options |  |  | 2,193 |  |  |  | 1,400 |  |
| Net cash used in financing activities |  |  | (1,622 | ) |  |  | (16,200 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 520 |  |  |  | 919 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (63,216 | ) |  |  | 7,690 |  |
| Cash and cash equivalents at beginning of period |  |  | 224,482 |  |  |  | 138,472 |  |
| Cash and cash equivalents at end of period |  | $ | 161,266 |  |  | $ | 146,162 |  |

[0001437749-19-008474:8k_2_02:91]
8

[0001437749-19-008474:8k_2_02:92]
Generac Holdings Inc.

[0001437749-19-008474:8k_2_02:93]
Segment Reporting and Product Class Information

[0001437749-19-008474:8k_2_02:94]
(U.S. Dollars in Thousands)

[0001437749-19-008474:8k_2_02:95]
(Unaudited)

[0001437749-19-008474:8k_2_02:96]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Reportable Segments |  |  |  |  |  |  |  |  |
| Domestic (1) |  | $ | 359,248 |  |  | $ | 302,676 |  |
| International |  |  | 111,105 |  |  |  | 97,415 |  |
| Total net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 217,830 |  |  | $ | 190,474 |  |
| Commercial & industrial products |  |  | 209,124 |  |  |  | 175,125 |  |
| Other (1) |  |  | 43,399 |  |  |  | 34,492 |  |
| Total net sales |  | $ | 470,353 |  |  | $ | 400,091 |  |

[0001437749-19-008474:8k_2_02:97]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 80,975 |  |  | $ | 65,475 |  |
| International |  |  | 6,153 |  |  |  | 6,306 |  |
| Total adjusted EBITDA (2) |  | $ | 87,128 |  |  | $ | 71,781 |  |

[0001437749-19-008474:8k_2_02:98]
(1) In accordance with ASU 2014-09, Revenue from Contracts with Customers, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were not material. To report extended warranty in accordance with ASU 2014-09, the net sales and gross profit amounts for the first quarter of 2018 have been revised by $2,457 and $1,938, respectively, from the amounts previously reported in the Company’s first quarter 2018 Form 10-Q, with an equal offset to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was no impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets or the condensed consolidated statements of cash flows.

[0001437749-19-008474:8k_2_02:99]
(2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-19-008474:8k_2_02:100]
Generac Holdings, Inc.

[0001437749-19-008474:8k_2_02:101]
Reconciliation Schedules

[0001437749-19-008474:8k_2_02:102]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-19-008474:8k_2_02:103]
(Unaudited)

[0001437749-19-008474:8k_2_02:104]
Net income to Adjusted EBITDA reconciliation

[0001437749-19-008474:8k_2_02:105]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |
| Interest expense |  |  | 10,272 |  |  |  | 10,113 |  |
| Depreciation and amortization |  |  | 12,607 |  |  |  | 11,683 |  |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |
| Non-cash write-down and other adjustments (1) |  |  | (1,400 | ) |  |  | 1,306 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,594 |  |  |  | 3,106 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,286 |  |  |  | 262 |  |
| Business optimization expenses (4) |  |  | 169 |  |  |  | 138 |  |
| Other |  |  | (154 | ) |  |  | (13 | ) |
| Adjusted EBITDA |  |  | 87,128 |  |  |  | 71,781 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,050 |  |  |  | 1,549 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 85,078 |  |  | $ | 70,232 |  |

[0001437749-19-008474:8k_2_02:106]
(1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-19-008474:8k_2_02:107]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-19-008474:8k_2_02:108]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-19-008474:8k_2_02:109]
(4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities.

[0001437749-19-008474:8k_2_02:110]
Net income to Adjusted net income reconciliation

[0001437749-19-008474:8k_2_02:111]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Net income attributable to noncontrolling interests |  |  | 908 |  |  |  | 125 |  |
| Net income |  |  | 45,769 |  |  |  | 33,770 |  |
| Provision for income taxes |  |  | 14,985 |  |  |  | 11,416 |  |
| Income before provision for income taxes |  |  | 60,754 |  |  |  | 45,186 |  |
| Amortization of intangible assets |  |  | 5,342 |  |  |  | 5,632 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,177 |  |  |  | 1,177 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 1,035 |  |  |  | 20 |  |
| Business optimization expenses (4) |  |  | 169 |  |  |  | 138 |  |
| Adjusted net income before provision for income taxes |  |  | 68,477 |  |  |  | 52,153 |  |
| Cash income tax expense (6) |  |  | (10,510 | ) |  |  | (5,410 | ) |
| Adjusted net income |  |  | 57,967 |  |  |  | 46,743 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,474 |  |  |  | 661 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 56,493 |  |  | $ | 46,082 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.91 |  |  | $ | 0.74 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,223,638 |  |  |  | 62,474,936 |  |

[0001437749-19-008474:8k_2_02:112]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-19-008474:8k_2_02:113]
(6) Amount for the three months ended March 31, 2019 is based on an anticipated cash income tax rate of 17% for the full year ended 2019. Amount for the three months ended March 31, 2018 is based on an anticipated cash income tax rate of 13% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-19-008474:8k_2_02:114]
Free Cash Flow Reconciliation

[0001437749-19-008474:8k_2_02:115]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net cash provided by operating activities |  | $ | 14,571 |  |  | $ | 28,968 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 743 |  |  |  | 867 |  |
| Expenditures for property and equipment |  |  | (15,902 | ) |  |  | (6,496 | ) |
| Free cash flow |  | $ | (588 | ) |  | $ | 23,339 |  |

[0001437749-19-008474:8k_2_02:116]
GAAP Earnings Per Share

[0001437749-19-008474:8k_2_02:117]
|  |  | Three Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,861 |  |  | $ | 33,645 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 2,432 |  |  |  | (7,665 | ) |
| Net income attributable to common shareholders |  | $ | 47,293 |  |  | $ | 25,980 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,762,260 |  |  |  | 61,943,495 |  |
| Dilutive effect of stock compensation awards |  |  | 461,378 |  |  |  | 531,441 |  |
| Diluted shares |  |  | 62,223,638 |  |  |  | 62,474,936 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.77 |  |  | $ | 0.42 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.42 |  |

[0001437749-19-008474:8k_2_02:118]
11
