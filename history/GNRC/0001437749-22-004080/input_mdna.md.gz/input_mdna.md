# GNRC MD&A — 0001437749-22-004080


## mdna

[0001437749-22-004080:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-22-004080:mdna:2]
Overview

[0001437749-22-004080:mdna:3]
Generac is a leading energy technology solutions company that provides backup and prime power systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, energy management devices and controls, advanced power grid software platforms & services and engine- & battery-powered tools and equipment.  The Company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-22-004080:mdna:4]
Further information regarding our business is provided in “Part I, Item 1. Business” of this Annual Report.

[0001437749-22-004080:mdna:5]
Business Drivers and Operational Factors

[0001437749-22-004080:mdna:6]
“Part I, Item 1. Business” of this Annual Report contains information regarding business drivers, including key mega-trends and strategic growth themes under the subheading “Mega-Trends, Strategic Growth Themes, and Additional Business Drivers.”

[0001437749-22-004080:mdna:7]
Factors Affecting Results of Operations

[0001437749-22-004080:mdna:8]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-22-004080:mdna:9]
Impact of the COVID-19 pandemic.     As the COVID-19 pandemic continues to evolve, we continue to work to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have been operational during the pandemic. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-22-004080:mdna:10]
The COVID-19 pandemic has influenced various trends we are currently experiencing involving supply chain and operations constraints. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience labor shortages and increased employee absences at our production facilities. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. Additionally, the COVID-19 pandemic has disrupted the global supply chain and logistics network, and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies.  We have experienced inbound and outbound logistics delays and increased costs, resulting in longer lead times and higher prices to our customers.

[0001437749-22-004080:mdna:11]
We continue to experience a broad-based increase in demand for residential products, specifically home standby generators, created by a significant increase in the awareness, importance and need for backup power security as people are working, learning, shopping, entertaining, and spending more time at home. Additionally, as economic activity continues to recover across the globe, we are experiencing a return to growth for our domestic and international C&I products.

[0001437749-22-004080:mdna:12]
The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to continue to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers. Refer to the COVID-19 related risk factor disclosed in "Item 1A. Risk Factors" of this Annual Report on Form 10-K.

[0001437749-22-004080:mdna:13]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronics components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, specifically in 2021, there continue to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs and delays for certain of our products that are reducing our margins. In 2021, we have implemented multiple price increases throughout the year to help mitigate the impact of rising costs. However, the full impact of these price increases will not be realized until 2022 as the higher pricing works through backlog.

[0001437749-22-004080:mdna:14]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-22-004080:mdna:15]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 22% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 25% to 28% in the third quarter and 27% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-22-004080:mdna:16]
Elevated power outage activity and the emergence of the "Home as a Sanctuary" trend driven by the COVID-19 pandemic led to a significant increase in demand for home standby generators.  This increased demand has resulted in extended lead times for these products as of December 31, 2021, and as a result, our net sales during 2022 are expected to experience an increasing trend on a quarterly basis as we increase our production capacity for home standby generators throughout the year.

[0001437749-22-004080:mdna:17]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment, in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. Additionally, as part of our ABL Facility amendment in May 2021, language was added to the ABL Facility agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. Interest expense slightly decreased during 2021 compared to 2020, primarily due to lower LIBOR rates partially offset by increased borrowings on our ABL Facility. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-22-004080:mdna:18]
Factors influencing provision for income taxes and cash income taxes paid.    On December 22, 2017, the U.S. government enacted the Tax Cuts and Jobs Act, which significantly changed how the U.S. taxes corporations. Since enactment, the U.S. Treasury Department (Treasury) issued several new regulations and other guidance which we have incorporated into our final tax calculations.

[0001437749-22-004080:mdna:19]
As of December 31, 2021, the tax-deductible goodwill and intangible assets amortization from our acquisition by CCMP Capital Advisors, LLC in 2006 were fully amortized. As a result, beginning in 2022, this tax amortization will no longer exist, resulting in a higher cash tax obligation on a go-forward basis.

[0001437749-22-004080:mdna:20]
Components of Net Sales and Expenses

[0001437749-22-004080:mdna:21]
Net Sales

[0001437749-22-004080:mdna:22]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, remote monitoring, grid optimization, installation and maintenance services. These services accounted for less than two percent of our net sales for the year ended December 31, 2021. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-22-004080:mdna:23]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 6% of our sales, and our top ten customers representing less than 23% of our net sales for the year ended December 31, 2021.

[0001437749-22-004080:mdna:24]
Costs of Goods Sold

[0001437749-22-004080:mdna:25]
The principal elements of costs of goods sold are component parts, raw materials, freight, factory overhead and labor. Component parts and raw materials comprised approximately 74% of costs of goods sold for the year ended December 31, 2021. The principal component parts are engines, alternators, batteries, electronic controls, and steel enclosures. We design and manufacture air-cooled engines for certain of our generators up to 26kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-22-004080:mdna:26]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-22-004080:mdna:27]
In 2021, we have seen a significant increase in commodity costs. We have implemented multiple price increases throughout 2021 to help mitigate the impact of these rising commodity costs. However, the full impact of these price increases will not be realized until 2022 as the higher pricing works through backlog.

[0001437749-22-004080:mdna:28]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-22-004080:mdna:29]
Operating Expenses

[0001437749-22-004080:mdna:30]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, warranty, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs, payroll taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses as well as acquisition related costs.

[0001437749-22-004080:mdna:31]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard assurance warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Standard warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include media advertising, promotional expenses, co-op advertising costs, direct mail costs, printed material costs, product display costs, market research expenses, and trade show expenses. Marketing expenses are generally related to the launch of new product offerings, opportunities to create market awareness for our products, and general brand awareness marketing efforts.

[0001437749-22-004080:mdna:32]
Research and development.    Our research and development expenses include mechanical engineering, electronics engineering, and software development costs and they support numerous projects covering all of our product lines. They also support our connectivity, grid services, remote monitoring, and energy management initiatives. We operate engineering facilities with extensive capabilities at many locations globally and employ over 1,000 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-22-004080:mdna:33]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-22-004080:mdna:34]
Acquisition related costs.    Acquisition related costs are external costs incurred to effect a business combination including legal fees, professional and advisory services, stamp tax, and insurance premiums.

[0001437749-22-004080:mdna:35]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-22-004080:mdna:36]
Other (Expense) Income

[0001437749-22-004080:mdna:37]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and cash flows related to interest rate swap agreements. Other (expense) income also includes other financial items such as losses on extinguishment of debt, loss on pension settlement, investment income earned on our cash and cash equivalents, and gains/losses on the sale of certain investments.

[0001437749-22-004080:mdna:38]
Results of Operations

[0001437749-22-004080:mdna:39]
A detailed discussion of the year-over-year changes from the Company's fiscal 2019 to fiscal 2020 can be found in the Management's Discussion and Analysis section of the Company's fiscal 2020 Annual Report on Form 10-K filed February 23, 2021.

[0001437749-22-004080:mdna:40]
Year ended December 31, 2021 compared to year ended December 31, 2020

[0001437749-22-004080:mdna:41]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-22-004080:mdna:42]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |  | $ | 1,251,984 |  |  |  | 50.4 | % |
| Cost of goods sold |  |  | 2,377,102 |  |  |  | 1,527,546 |  |  |  | 849,556 |  |  |  | 55.6 | % |
| Gross profit |  |  | 1,360,082 |  |  |  | 957,654 |  |  |  | 402,428 |  |  |  | 42.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 319,020 |  |  |  | 246,373 |  |  |  | 72,647 |  |  |  | 29.5 | % |
| Research and development |  |  | 104,303 |  |  |  | 80,251 |  |  |  | 24,052 |  |  |  | 30.0 | % |
| General and administrative |  |  | 144,272 |  |  |  | 118,233 |  |  |  | 26,039 |  |  |  | 22.0 | % |
| Acquisition related costs |  |  | 21,465 |  |  |  | 1,411 |  |  |  | 20,054 |  |  |  | 1421.3 | % |
| Amortization of intangible assets |  |  | 49,886 |  |  |  | 32,280 |  |  |  | 17,606 |  |  |  | 54.5 | % |
| Total operating expenses |  |  | 638,946 |  |  |  | 478,548 |  |  |  | 160,398 |  |  |  | 33.5 | % |
| Income from operations |  |  | 721,136 |  |  |  | 479,106 |  |  |  | 242,030 |  |  |  | 50.5 | % |
| Total other expense, net |  |  | (29,610 | ) |  |  | (32,915 | ) |  |  | 3,305 |  |  |  | -10.0 | % |
| Income before provision for income taxes |  |  | 691,526 |  |  |  | 446,191 |  |  |  | 245,335 |  |  |  | 55.0 | % |
| Provision for income taxes |  |  | 134,957 |  |  |  | 98,973 |  |  |  | 35,984 |  |  |  | 36.4 | % |
| Net income |  |  | 556,569 |  |  |  | 347,218 |  |  |  | 209,351 |  |  |  | 60.3 | % |
| Net income attributable to noncontrolling interests |  |  | 6,075 |  |  |  | (3,358 | ) |  |  | 9,433 |  |  |  | -280.9 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 550,494 |  |  | $ | 350,576 |  |  | $ | 199,918 |  |  |  | 57.0 | % |

[0001437749-22-004080:mdna:43]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-22-004080:mdna:44]
|  |  | Net Sales by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,164,050 |  |  | $ | 2,088,808 |  |  | $ | 1,075,242 |  |  |  | 51.5 | % |
| International |  |  | 573,134 |  |  |  | 396,392 |  |  |  | 176,742 |  |  |  | 44.6 | % |
| Total net sales |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |  | $ | 1,251,984 |  |  |  | 50.4 | % |

[0001437749-22-004080:mdna:45]
|  |  | Adjusted EBITDA by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 795,417 |  |  | $ | 563,394 |  |  | $ | 232,023 |  |  |  | 41.2 | % |
| International |  |  | 66,008 |  |  |  | 20,379 |  |  |  | 45,629 |  |  |  | 223.9 | % |
| Total Adjusted EBITDA |  | $ | 861,425 |  |  | $ | 583,773 |  |  | $ | 277,652 |  |  |  | 47.6 | % |

[0001437749-22-004080:mdna:46]
The following table sets forth our net sales by product class for the periods indicated:

[0001437749-22-004080:mdna:47]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,456,765 |  |  | $ | 1,556,501 |  |  | $ | 900,264 |  |  |  | 57.8 | % |
| Commercial & industrial products |  |  | 998,998 |  |  |  | 701,751 |  |  |  | 297,247 |  |  |  | 42.4 | % |
| Other |  |  | 281,421 |  |  |  | 226,948 |  |  |  | 54,473 |  |  |  | 24.0 | % |
| Total net sales |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |  | $ | 1,251,984 |  |  |  | 50.4 | % |

[0001437749-22-004080:mdna:48]
Net sales.    The increase in Domestic segment sales for the year ended December 31, 2021 was primarily driven by strong growth in shipments of residential products highlighted by home standby generators. In addition, PWRcellTM energy storage systems experienced very robust growth as the Company continues to expand in the clean energy market. This was supplemented by a return to growth for C&I products which was led by a substantial increase in shipments for telecom national account customers and C&I mobile products compared to the prior year.

[0001437749-22-004080:mdna:49]
The increase in International segment sales for the year ended December 31, 2021 was due to a broad-based increase in market activity primarily in the European and Latin American regions that are seeing a sharp increase in demand as end markets recover from the impact of the COVID-19 pandemic. In addition, the impact of acquisitions and foreign currency added $68.5 million of revenue growth.

[0001437749-22-004080:mdna:50]
Total contribution from non-annualized acquisitions for the year ended December 31, 2021 was $94.9 million.

[0001437749-22-004080:mdna:51]
Gross profit.    Gross profit margin for the year ended December 31, 2021 was 36.4% compared to 38.5% for the year ended December 31, 2020. The gross profit margin decrease was primarily driven by higher input costs due to rising commodity prices, labor, logistics and plant start-up costs, which were partially offset by the early benefits of pricing actions implemented throughout the year and favorable sales mix from higher shipments of home standby generators.

[0001437749-22-004080:mdna:52]
Operating expenses.    Operating expenses increased $160.4 million, or 33.5%, as compared to the prior year. The increase was primarily driven by additional variable expenses from the significant increase in sales volumes, higher employee and marketing costs, and the impact of acquisitions and related transaction costs.

[0001437749-22-004080:mdna:53]
Other expense.    The decrease in Other expense, net was driven by a $4.4 million gain recorded on the sale of certain long-term investments.

[0001437749-22-004080:mdna:54]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2021 and 2020 were 19.5% and 22.2%, respectively. The decrease in the effective tax rate was primarily due to larger deductions related to net stock compensation and net deductible acquisition transaction expenses partially offset by a discrete tax item created by a legislative tax rate change in a foreign jurisdiction which revalued certain deferred tax liabilities.

[0001437749-22-004080:mdna:55]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $550.5 million as compared to $350.6 million in the prior year period. The increase was primarily driven by increased sales volumes and other items noted above.

[0001437749-22-004080:mdna:56]
Adjusted EBITDA.    Adjusted EBITDA is defined and reconciled to net income in, "Non-GAAP Measures - Adjusted EBITDA" included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2021 were 25.1% of net sales as compared to 27.0% of net sales for the year ended December 31, 2020. The Adjusted EBITDA margin decrease was driven by higher input costs due to rising commodity prices, labor, logistics, and plant start-up costs in the current year, which were partially offset by favorable sales mix, the early benefits of pricing actions, and improved operating leverage from the substantial revenue growth for the segment.

[0001437749-22-004080:mdna:57]
Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2021 were 11.5% of net sales as compared to 5.1% of net sales for the year ended December 31, 2020. The margin improvement was primarily due to the positive impact of recent acquisitions, favorable sales mix, improved operating leverage, and pricing actions.

[0001437749-22-004080:mdna:58]
Adjusted net income.    Adjusted Net Income is defined and reconciled to net income in, "Non-GAAP Measures - Adjusted Net Income" included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income of $618.9 million for the year ended December 31, 2021 increased 50.2% from $412.2 million for the year ended December 31, 2020, due to the factors outlined above and higher cash income tax expense in the current year period.

[0001437749-22-004080:mdna:59]
Liquidity and Financial Position

[0001437749-22-004080:mdna:60]
Our primary cash requirements include payment for our raw materials and components, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-22-004080:mdna:61]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. As of December 31, 2021, there was $780 million outstanding under the Term Loan. The Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of December 31, 2021, our secured leverage ratio was 0.88 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-22-004080:mdna:62]
Our credit agreements also provide for a $500.0 million ABL Facility, which matures on May 27, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. As of December 31, 2021, there was $100 million outstanding under the ABL Facility, leaving $399.5 million of availability, net of outstanding letters of credit. We were in compliance with all covenants of the ABL Facility as of December 31, 2021.

[0001437749-22-004080:mdna:63]
As of December 31, 2021, we had $546.8 million of available liquidity comprised of $147.3 million of cash and cash equivalents and $399.5 million available under our ABL Facility. We have no maturities on our Term Loan and ABL Facility until 2026. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-22-004080:mdna:64]
In September 2018, our Board of Directors approved a $250.0 million stock repurchase program, which expired in October 2020. In September 2020, the Board of Directors approved another $250 million stock repurchase program, which commenced on October 27, 2020. During the year ended December 31, 2021, the Company repurchased 350,000 shares of its common stock for $126.0 million, all funded with cash on hand. Since the inception of all stock repurchase programs (starting in August 2015), the Company has repurchased 9,026,706 shares of its common stock for $431.5 million (at an average cost per share of $47.81), all funded with cash on hand.

[0001437749-22-004080:mdna:65]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-22-004080:mdna:66]
Total dealer purchases financed under this arrangement accounted for approximately 12% of net sales for the years ended December 31, 2021 and 2020. The amount financed by dealers which remained outstanding was $115.9 million and $55.6 million as of December 31, 2021 and 2020, respectively.

[0001437749-22-004080:mdna:67]
Long-term Liquidity

[0001437749-22-004080:mdna:68]
We believe that our cash and cash equivalents, cash flow from operations, and availability under our ABL Facility and other short-term lines of credit will provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay principal on our outstanding debt, as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-22-004080:mdna:69]
Cash Flow

[0001437749-22-004080:mdna:70]
Year ended December 31, 2021 compared to year ended December 31, 2020

[0001437749-22-004080:mdna:71]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-22-004080:mdna:72]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 411,156 |  |  | $ | 486,533 |  |  | $ | (75,377 | ) |  |  | -15.5 | % |
| Net cash used in investing activities |  |  | (817,287 | ) |  |  | (124,095 | ) |  |  | (693,192 | ) |  |  | 558.6 | % |
| Net cash used in financing activities |  |  | (102,970 | ) |  |  | (30,428 | ) |  |  | (72,542 | ) |  |  | 238.4 | % |

[0001437749-22-004080:mdna:73]
The decrease in net cash provided by operating activities was primarily due to increased working capital investment and higher income taxes paid in the current year, partially offset by higher sales volumes and resulting higher operating earnings in the current year. The higher working capital investment was primarily driven by further elevated inventory levels at the end of the year resulting from extended logistics in-transit times, ongoing supply chain constraints, increasing production rates and continued investments in the ramping of our new manufacturing facility in Trenton, SC.

[0001437749-22-004080:mdna:74]
Net cash used in investing activities for the year ended December 31, 2021 primarily consisted of cash payments of $713.5 million related to the acquisition of businesses and $110.0 million for the purchase of property and equipment, which were partially offset by cash proceeds on sale of an investment of $5.0 million. Net cash used in investing activities for the year ended December 31, 2020 primarily consisted of cash payments of $64.8 million related to the acquisition of businesses and $62.1 million for the purchase of property and equipment.

[0001437749-22-004080:mdna:75]
Net cash used in financing activities for the year ended December 31, 2021 primarily consisted of $347.7 million of debt repayments ($239.1 million of short-term borrowings and $108.6 million of long-term borrowings), $126.0 million of stock repurchases, $58.9 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of PR Industrial S.r.l. and its subsidiaries (Pramac), and $3.8 million of contingent consideration for acquired businesses. These payments were partially offset by $272.8 million cash proceeds from short-term borrowings, $150.1 million cash proceeds from long-term borrowings and $38.8 million of proceeds from the exercise of stock options.

[0001437749-22-004080:mdna:76]
Net cash used in financing activities for the year ended December 31, 2020 primarily consisted of $282.5 million of debt repayments ($277.7 million of short-term borrowings and $4.8 million of long-term borrowings), $14.9 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These payments were partially offset by $257.9 million of cash proceeds from borrowings ($257.6 million from short-term borrowings and $0.3 million from long-term borrowings) and $13.1 million of proceeds from the exercise of stock options.

[0001437749-22-004080:mdna:77]
Senior Secured Credit Facilities

[0001437749-22-004080:mdna:78]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on our senior secured credit facilities.

[0001437749-22-004080:mdna:79]
Covenant Compliance

[0001437749-22-004080:mdna:80]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. The Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-22-004080:mdna:81]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-22-004080:mdna:82]
The ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-22-004080:mdna:83]
Contractual Obligations

[0001437749-22-004080:mdna:84]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2021, using the interest rates in effect as of that date:

[0001437749-22-004080:mdna:85]
| (U.S. Dollars in thousands) |  | Total |  |  | 2022 |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | After 2026 |  |
| Long-term debt, including current portion (1) |  | $ | 882,060 |  |  | $ | 1,765 |  |  | $ | 59 |  |  | $ | 59 |  |  | $ | 92 |  |  | $ | 880,034 |  |  | $ | 51 |  |
| Finance lease obligations, including current portion |  |  | 39,175 |  |  |  | 4,195 |  |  |  | 3,348 |  |  |  | 3,393 |  |  |  | 3,243 |  |  |  | 3,167 |  |  |  | 21,829 |  |
| Interest on long-term debt and finance lease obligations |  |  | 97,175 |  |  |  | 18,414 |  |  |  | 18,189 |  |  |  | 17,965 |  |  |  | 17,712 |  |  |  | 16,079 |  |  |  | 8,816 |  |
| Short-term borrowings (2) |  |  | 72,035 |  |  |  | 72,035 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Operating leases |  |  | 115,164 |  |  |  | 26,615 |  |  |  | 26,220 |  |  |  | 25,062 |  |  |  | 15,751 |  |  |  | 6,469 |  |  |  | 15,047 |  |
| Total contractual cash obligations |  | $ | 1,205,609 |  |  | $ | 123,024 |  |  | $ | 47,816 |  |  | $ | 46,479 |  |  | $ | 36,798 |  |  | $ | 905,749 |  |  | $ | 45,743 |  |

[0001437749-22-004080:mdna:86]
(1) The Term Loan matures on December 13, 2026. The ABL Facility provides for a $500.0 million senior secured ABL revolving credit facility, which matures on May 27, 2026. As of December 31, 2021, there was $100 million outstanding under the ABL Facility classified as long-term debt.

[0001437749-22-004080:mdna:87]
(2) Short-term borrowings consist of borrowings by our foreign subsidiaries on local lines of credit.

[0001437749-22-004080:mdna:88]
Capital Expenditures

[0001437749-22-004080:mdna:89]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, IT systems & infrastructure and upgrades. Specifically, capital expenditures in 2021 included the addition of the Trenton, South Carolina, manufacturing facility. Capital expenditures were $110.0 million, $62.1 million, and $60.8 million for the years ended December 31, 2021, 2020 and 2019, respectively, and were funded through cash from operations.

[0001437749-22-004080:mdna:90]
Critical Accounting Policies

[0001437749-22-004080:mdna:91]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-22-004080:mdna:92]
Business Combinations and Purchase Accounting

[0001437749-22-004080:mdna:93]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets, tangible long-lived assets, and contingent consideration. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, profit margins, forecasted cash flows, discount rates and terminal growth rates. The initial measurement of contingent consideration and the corresponding liability is evaluated using the Monte Carlo Method. For this valuation method, management develops projections during the earn-out period utilizing various potential pay-out scenarios. Probabilities are applied to each potential scenario and the resulting values are discounted using a rate that considers weighted average cost of capital as well as a specific risk premium associated with the riskiness of the earn-out itself, the related projections, and the overall business. Refer to Note 1, “Description of Business,” and Note 3, "Acquisitions," to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-22-004080:mdna:94]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-22-004080:mdna:95]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets. The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2021, 2020 and 2019, and found no impairment.

[0001437749-22-004080:mdna:96]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-22-004080:mdna:97]
In our October 31, 2021 impairment test calculation, the Latin America reporting unit had an estimated fair value that exceeded its carrying value by approximately 23%.

[0001437749-22-004080:mdna:98]
The carrying value of the Latin America goodwill was $45.7 million. Key financial assumptions utilized to determine the fair value of the reporting unit include revenue growth levels that reflect the impact of increasing Telecom production for the U.S. market, improving profit margins, a 3% terminal growth rate and an 11.4% discount rate. The reporting unit’s fair value would approximate its carrying value with a 175 basis point increase in the discount rate or a 150 basis point reduction in the average earnings margin and 100 basis point reduction in the terminal growth rate.

[0001437749-22-004080:mdna:99]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-22-004080:mdna:100]
|  | ● | continued negative impact from the COVID-19 pandemic; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-22-004080:mdna:101]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-22-004080:mdna:102]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-22-004080:mdna:103]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-22-004080:mdna:104]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-22-004080:mdna:105]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-22-004080:mdna:106]
|  | ● | disruptions to the Company’s business; |

[0001437749-22-004080:mdna:107]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-22-004080:mdna:108]
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-22-004080:mdna:109]
|  | ● | business divestitures. |

[0001437749-22-004080:mdna:110]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-22-004080:mdna:111]
Income Taxes

[0001437749-22-004080:mdna:112]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-22-004080:mdna:113]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-22-004080:mdna:114]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and income tax positions.

[0001437749-22-004080:mdna:115]
New Accounting Standards

[0001437749-22-004080:mdna:116]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-22-004080:mdna:117]
Non-GAAP Measures

[0001437749-22-004080:mdna:118]
Adjusted EBITDA

[0001437749-22-004080:mdna:119]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement, as amended. To supplement our consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-22-004080:mdna:120]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-22-004080:mdna:121]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-22-004080:mdna:122]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-22-004080:mdna:123]
|  | ● | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-22-004080:mdna:124]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-22-004080:mdna:125]
|  | ● | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-22-004080:mdna:126]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-22-004080:mdna:127]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-22-004080:mdna:128]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-22-004080:mdna:129]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-22-004080:mdna:130]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-22-004080:mdna:131]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-22-004080:mdna:132]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-22-004080:mdna:133]
|  | ● | are non-cash in nature, such as share-based compensation expense. |

[0001437749-22-004080:mdna:134]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-22-004080:mdna:135]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-22-004080:mdna:136]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-22-004080:mdna:137]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-22-004080:mdna:138]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-22-004080:mdna:139]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-22-004080:mdna:140]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-22-004080:mdna:141]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-22-004080:mdna:142]
32

[0001437749-22-004080:mdna:143]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board of Directors in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-22-004080:mdna:144]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-22-004080:mdna:145]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-22-004080:mdna:146]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 550,494 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Net income attributable to noncontrolling interests |  |  | 6,075 |  |  |  | (3,358 | ) |  |  | 301 |  |
| Net income |  |  | 556,569 |  |  |  | 347,218 |  |  |  | 252,308 |  |
| Interest expense |  |  | 32,953 |  |  |  | 32,991 |  |  |  | 41,544 |  |
| Depreciation and amortization |  |  | 92,041 |  |  |  | 68,773 |  |  |  | 60,767 |  |
| Provision for income taxes |  |  | 134,957 |  |  |  | 98,973 |  |  |  | 67,299 |  |
| Non-cash write-down and other adjustments (a) |  |  | (3,070 | ) |  |  | (327 | ) |  |  | 240 |  |
| Non-cash share-based compensation expense (b) |  |  | 23,954 |  |  |  | 20,882 |  |  |  | 16,694 |  |
| Loss on extinguishment of debt (c) |  |  | 831 |  |  |  | - |  |  |  | 926 |  |
| Loss on pension settlement (d) |  |  | - |  |  |  | - |  |  |  | 10,920 |  |
| Transaction costs and credit facility fees (e) |  |  | 22,357 |  |  |  | 2,151 |  |  |  | 2,724 |  |
| Business optimization and other charges (f) |  |  | 33 |  |  |  | 12,158 |  |  |  | 1,572 |  |
| Other |  |  | 800 |  |  |  | 954 |  |  |  | (879 | ) |
| Adjusted EBITDA |  |  | 861,425 |  |  |  | 583,773 |  |  |  | 454,115 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 9,351 |  |  |  | 2,358 |  |  |  | 4,965 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 852,074 |  |  | $ | 581,415 |  |  | $ | 449,150 |  |

[0001437749-22-004080:mdna:147]
(a) Represents the following non-cash adjustments: gains/losses on disposals of assets and gains on certain investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. We believe that adjusting net income for these non-cash items is useful for the following reasons:

[0001437749-22-004080:mdna:148]
|  | ● | The gains/losses on disposals of assets and gains on certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-22-004080:mdna:149]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-22-004080:mdna:150]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. Purchase accounting adjustments also include adjustments to earn-out obligations related to business acquisitions. |

[0001437749-22-004080:mdna:151]
(b) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-22-004080:mdna:152]
(c) Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayments of Term Loan debt. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt.

[0001437749-22-004080:mdna:153]
(d) Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information regarding the Company’s pension plans.

[0001437749-22-004080:mdna:154]
(e) Represents transaction costs incurred directly in connection with any investment (including business acquisitions), as defined in our credit agreement, equity issuance, or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-22-004080:mdna:155]
(f) For the year-ended December 31, 2020, represents severance, non-cash asset write-downs and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products. These charges represent expenses that are nonrecurring and do not reflect our ongoing operations.

[0001437749-22-004080:mdna:156]
33

[0001437749-22-004080:mdna:157]
Adjusted Net Income

[0001437749-22-004080:mdna:158]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-22-004080:mdna:159]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-22-004080:mdna:160]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt. We also make adjustments to present cash taxes paid as a result of our favorable tax attributes, causing our cash tax rate to be lower than our U.S GAAP tax rate.

[0001437749-22-004080:mdna:161]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-22-004080:mdna:162]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-22-004080:mdna:163]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-22-004080:mdna:164]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-22-004080:mdna:165]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-22-004080:mdna:166]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 550,494 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Net income attributable to noncontrolling interests |  |  | 6,075 |  |  |  | (3,358 | ) |  |  | 301 |  |
| Net income |  |  | 556,569 |  |  |  | 347,218 |  |  |  | 252,308 |  |
| Provision for income taxes |  |  | 134,957 |  |  |  | 98,973 |  |  |  | 67,299 |  |
| Income before provision for income taxes |  |  | 691,526 |  |  |  | 446,191 |  |  |  | 319,607 |  |
| Amortization of intangible assets |  |  | 49,886 |  |  |  | 32,280 |  |  |  | 28,644 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 2,589 |  |  |  | 2,598 |  |  |  | 4,712 |  |
| Loss on extinguishment of debt |  |  | 831 |  |  |  | - |  |  |  | 926 |  |
| Loss on pension settlement |  |  | - |  |  |  | - |  |  |  | 10,920 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 19,655 |  |  |  | (1,328 | ) |  |  | 874 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | (4,383 | ) |  |  | - |  |  |  | - |  |
| Business optimization and other charges |  |  | 33 |  |  |  | 12,158 |  |  |  | 1,572 |  |
| Adjusted net income before provision for income taxes |  |  | 760,137 |  |  |  | 491,899 |  |  |  | 367,255 |  |
| Cash income tax expense (c) |  |  | (136,231 | ) |  |  | (79,723 | ) |  |  | (47,945 | ) |
| Adjusted net income |  |  | 623,906 |  |  |  | 412,176 |  |  |  | 319,310 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 4,971 |  |  |  | (32 | ) |  |  | 1,488 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 618,935 |  |  | $ | 412,208 |  |  | $ | 317,822 |  |

[0001437749-22-004080:mdna:167]
(a) Represents transaction costs incurred directly in connection with any investment (including business acquisitions), as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-22-004080:mdna:168]
(b) Represents gains on certain investments occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-22-004080:mdna:169]
(c) For the years ended December 31, 2021, 2020, and 2019, the amount is based on a cash income tax rate of 19.7%, 17.9%, and 15.0%, respectively. Cash income tax expense is based on the projected taxable income and corresponding cash taxes payable for the full year after considering the effects of current and deferred income tax items, and is calculated by applying the derived cash tax rate to the period’s pretax income. We expect our cash income tax rate to increase after 2021 due to the expiration of the tax shield created by the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC.
