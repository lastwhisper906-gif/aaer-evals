# GNRC 8-K — 0001437749-22-003484 filed 2022-02-16

## item codes, every 8-K on or before 2022-02-22

- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2022-02-22

- none on or before 2022-02-22

## item 2.02 — earnings release, exhibit 99.1

[0001437749-22-003484:8k_2_02:1]
EX-99.1
2
ex_336002.htm
EXHIBIT 99.1

[0001437749-22-003484:8k_2_02:2]
ex_336002.htm

[0001437749-22-003484:8k_2_02:3]
Exhibit 99.1

[0001437749-22-003484:8k_2_02:4]
Generac Reports Record Fourth Quarter and Full-Year 2021 Results

[0001437749-22-003484:8k_2_02:5]
Continued significant end market demand and strong execution drive record shipments; 2022 outlook anticipates another year of exceptional and broad-based growth

[0001437749-22-003484:8k_2_02:6]
WAUKESHA, WISCONSIN (February 16, 2022) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2021 and initiated its outlook for the full year 2022.

[0001437749-22-003484:8k_2_02:7]
Fourth Quarter 2021 Highlights

[0001437749-22-003484:8k_2_02:8]
| ● | Net sales increased 40% to a record $1.07 billion during the fourth quarter of 2021 as compared to $761 million in the prior-year fourth quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 35%. |

[0001437749-22-003484:8k_2_02:9]
|  | - | Residential product sales grew 42% to $706 million as compared to $499 million last year. |

[0001437749-22-003484:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 43% to $284 million as compared to $199 million in the prior year. |

[0001437749-22-003484:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter was $143 million, or $2.04 per share, as compared to $125 million, or $1.97 per share, for the same period of 2020. |

[0001437749-22-003484:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was a record $162 million, or $2.51 per share, as compared to $136 million, or $2.12 per share, in the fourth quarter of 2020. |

[0001437749-22-003484:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was a record $220 million, or 20.7% of net sales, as compared to $196 million, or 25.7% of net sales, in the prior year. |

[0001437749-22-003484:8k_2_02:14]
| ● | As previously disclosed, on October 1st, the Company closed on the acquisition of Tank Utility, a provider of IoT propane tank monitoring solutions that enable the optimization of propane fuel logistics, headquartered in Boston, Massachusetts. |

[0001437749-22-003484:8k_2_02:15]
| ● | As previously disclosed, on December 1st, the Company closed on the acquisition of ecobee, a leader in sustainable home technology solutions including smart home energy devices that deliver significant energy savings, security and peace of mind, headquartered in Toronto, Canada. |

[0001437749-22-003484:8k_2_02:16]
| ● | The Company is initiating its full-year 2022 net sales growth guidance to be approximately 32 to 36% compared to the prior year on an as-reported basis, which includes approximately 5 to 7% of net impact from acquisitions and foreign currency. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 22.0 to 23.0%. |

[0001437749-22-003484:8k_2_02:17]
Full-Year 2021 Highlights

[0001437749-22-003484:8k_2_02:18]
| ● | Net sales increased 50% to a record $3.74 billion during 2021 as compared to $2.49 billion in 2020. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 46%. |

[0001437749-22-003484:8k_2_02:19]
|  | - | Residential product sales increased 58% to $2.46 billion as compared to $1.56 billion last year. |

[0001437749-22-003484:8k_2_02:20]
|  | - | C&I product sales grew 42% to $1.0 billion as compared to $702 million in the prior year. |

[0001437749-22-003484:8k_2_02:21]
| ● | Net income attributable to the Company during 2021 was a record $550 million, or $8.30 per share, as compared to $351 million, or $5.48 per share for 2020. |

[0001437749-22-003484:8k_2_02:22]
| ● | Adjusted net income attributable to the Company was a record $619 million, or $9.63 per share, as compared to $412 million, or $6.47 per share, in 2020. |

[0001437749-22-003484:8k_2_02:23]
| ● | Adjusted EBITDA before deducting for non-controlling interests for 2021 was a record $861 million, or 23.1% of net sales, as compared to $584 million, or 23.5% of net sales, last year. |

[0001437749-22-003484:8k_2_02:24]
| ● | Cash flow from operations was $411 million as compared to $487 million in the prior year. Free cash flow was $306 million as compared to $427 million in 2020. |

[0001437749-22-003484:8k_2_02:25]
“We continued to experience exceptional demand during the fourth quarter and achieved record quarterly shipments and production levels as we exited 2021,” said Aaron Jagdfeld, President and Chief Executive Officer. “We’re proud of our execution during the quarter as the continued progress on our capacity expansion helped drive top line results ahead of our expectations despite ongoing supply chain challenges. We enter 2022 with considerable visibility and momentum given ongoing robust home standby demand, an expanding Energy Technology solutions portfolio, and strong global demand for our C&I products.”

[0001437749-22-003484:8k_2_02:26]
Jagdfeld continued, “We are making important progress on Generac’s evolution into an energy technology solutions company as we completed several strategic acquisitions during the year and introduced a number of innovative technologies that will significantly expand our addressable markets. We also introduced a new enterprise strategy called ‘Powering a Smarter World’ focused on improving energy resiliency, optimizing energy efficiency, and protecting critical infrastructure. Our strong balance sheet and cash flow generation give us the confidence to make the necessary investments to further capitalize on the key mega-trends that support our long-term growth outlook.”

[0001437749-22-003484:8k_2_02:27]
Additional Fourth Quarter 2021 Consolidated Highlights

[0001437749-22-003484:8k_2_02:28]
Gross profit margin was 34.0% as compared to 39.4% in the prior-year fourth quarter. Gross margins continued to be pressured by a challenging supply chain and overall inflationary environment leading to higher input costs, which include increased commodity prices, logistics costs, labor and plant start-up costs. These costs were partially offset by the initial impacts of several pricing actions implemented throughout the past year, with the full impact expected to be realized throughout 2022 as the higher pricing works through backlog.

[0001437749-22-003484:8k_2_02:29]
Operating expenses increased $57.9 million, or 44.8%, as compared to the fourth quarter of 2020. The increase was primarily driven by the impact of acquisitions and related transaction costs, higher employee and marketing costs, and additional variable expenses from the significant increase in sales volumes.

[0001437749-22-003484:8k_2_02:30]
Provision for income taxes for the current year quarter was $20.6 million, or an effective tax rate of 12.4%, as compared to $39.0 million, or a 23.8% effective tax rate, for the prior year. The decline in effective tax rate was primarily due to certain discrete items related to acquisitions and higher stock compensation deduction.

[0001437749-22-003484:8k_2_02:31]
Cash flow from operations was $62 million during the fourth quarter, as compared to $218 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $42 million as compared to $191 million in the fourth quarter of 2020. The decline in free cash flow was due to a much higher working capital investment in the current year quarter primarily due to supply chain and logistics challenges, partially offset by an increase in operating earnings and lower capital expenditures.

[0001437749-22-003484:8k_2_02:32]
The Company repurchased 350,000 shares of its common stock during the fourth quarter for $126 million under its current share repurchase program. There is approximately $124 million remaining under the current share repurchase program as of December 31, 2021.

[0001437749-22-003484:8k_2_02:33]
Business Segment Results

[0001437749-22-003484:8k_2_02:34]
Domestic Segment

[0001437749-22-003484:8k_2_02:35]
Domestic segment sales increased 39% to $896.4 million as compared to $645.1 million in the prior year quarter, with the impact of acquisitions contributing approximately 2% of the revenue growth for the quarter. The strong core sales growth was broad based led by home standby generators and PWRcell® energy storage systems, while C&I channels experienced significant year-over-year growth in the quarter, highlighted by national telecom and rental equipment customers.

[0001437749-22-003484:8k_2_02:36]
Adjusted EBITDA for the segment was $196.7 million, or 21.9% of net sales, as compared to $188.0 million in the prior year, or 29.1% of net sales. This margin performance was impacted by the previously mentioned higher input costs and the impact of acquisitions, partially offset by the early impacts of recent pricing actions.

[0001437749-22-003484:8k_2_02:37]
International Segment

[0001437749-22-003484:8k_2_02:38]
International segment sales increased 47% to $170.7 million as compared to $116.0 million in the prior year quarter, with the impact of acquisitions and foreign currency contributing approximately 21% of the revenue growth for the quarter. The core sales growth for the segment was driven by broad-based strength across all regions as compared to the softer prior year impacted by COVID, with sales recovering well above 2019 levels.

[0001437749-22-003484:8k_2_02:39]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $23.7 million, or 13.9% of net sales, as compared to $7.8 million, or 6.8% of net sales, in the prior year. The increase in margin was primarily due to the positive impact of recent acquisitions, improved absorption and operating leverage, as well as price realization.

[0001437749-22-003484:8k_2_02:40]
2022 Outlook

[0001437749-22-003484:8k_2_02:41]
The Company is initiating guidance for 2022 that anticipates another year of exceptional revenue growth as compared to the prior year. This is expected to be driven primarily by ramping home standby production capacity throughout the year, significant growth in clean energy markets, strong broad-based global demand for C&I products, and recent acquisitions. As a result, net sales are expected to increase between 32 to 36% as compared to the prior year on an as-reported basis, which includes approximately 5 to 7% of net impact from acquisitions and foreign currency.

[0001437749-22-003484:8k_2_02:42]
Net income margin, before deducting for non-controlling interests, is expected to be approximately 13.0 to 14.0% for the full-year 2022, with the corresponding adjusted EBITDA margin expected to be approximately 22.0 to 23.0%.

[0001437749-22-003484:8k_2_02:43]
Conference Call and Webcast

[0001437749-22-003484:8k_2_02:44]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, February 16, 2022 to discuss fourth quarter and full-year 2021 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 9757974.

[0001437749-22-003484:8k_2_02:45]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-22-003484:8k_2_02:46]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 9757974. The telephonic replay will be available for 7 days.

[0001437749-22-003484:8k_2_02:47]
About Generac

[0001437749-22-003484:8k_2_02:48]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-22-003484:8k_2_02:49]
Forward-looking Information

[0001437749-22-003484:8k_2_02:50]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-22-003484:8k_2_02:51]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-22-003484:8k_2_02:52]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-22-003484:8k_2_02:53]
|  | ● | availability, cost and quality of raw materials, key components from our global supply chain and labor needed in producing our products; |

[0001437749-22-003484:8k_2_02:54]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-22-003484:8k_2_02:55]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-22-003484:8k_2_02:56]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-22-003484:8k_2_02:57]
|  | ● | the duration and impact of the COVID-19 pandemic; |

[0001437749-22-003484:8k_2_02:58]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-22-003484:8k_2_02:59]
|  | ● | our dependence on our distribution network; |

[0001437749-22-003484:8k_2_02:60]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-22-003484:8k_2_02:61]
|  | ● | loss of our key management and employees; |

[0001437749-22-003484:8k_2_02:62]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-22-003484:8k_2_02:63]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-22-003484:8k_2_02:64]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; |

[0001437749-22-003484:8k_2_02:65]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations. |

[0001437749-22-003484:8k_2_02:66]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2020 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-22-003484:8k_2_02:67]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-22-003484:8k_2_02:68]
Non-GAAP Financial Metrics

[0001437749-22-003484:8k_2_02:69]
Core Sales

[0001437749-22-003484:8k_2_02:70]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-22-003484:8k_2_02:71]
Adjusted EBITDA

[0001437749-22-003484:8k_2_02:72]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-22-003484:8k_2_02:73]
Adjusted Net Income

[0001437749-22-003484:8k_2_02:74]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-22-003484:8k_2_02:75]
Free Cash Flow

[0001437749-22-003484:8k_2_02:76]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-22-003484:8k_2_02:77]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-22-003484:8k_2_02:78]
SOURCE: Generac Holdings Inc.

[0001437749-22-003484:8k_2_02:79]
CONTACT:

[0001437749-22-003484:8k_2_02:80]
Michael W. Harris

[0001437749-22-003484:8k_2_02:81]
Vice President – Corporate Development & Investor Relations

[0001437749-22-003484:8k_2_02:82]
(262) 506-6064

[0001437749-22-003484:8k_2_02:83]
InvestorRelations@generac.com

[0001437749-22-003484:8k_2_02:84]
| Generac Holdings Inc. |
| Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-003484:8k_2_02:85]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net sales |  | $ | 1,067,071 |  |  | $ | 761,082 |  |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |
| Costs of goods sold |  |  | 704,532 |  |  |  | 460,880 |  |  |  | 2,377,102 |  |  |  | 1,527,546 |  |
| Gross profit |  |  | 362,539 |  |  |  | 300,202 |  |  |  | 1,360,082 |  |  |  | 957,654 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 89,577 |  |  |  | 67,807 |  |  |  | 319,020 |  |  |  | 246,373 |  |
| Research and development |  |  | 29,406 |  |  |  | 21,489 |  |  |  | 104,303 |  |  |  | 80,251 |  |
| General and administrative |  |  | 37,758 |  |  |  | 30,113 |  |  |  | 144,272 |  |  |  | 118,233 |  |
| Acquisition related costs |  |  | 12,668 |  |  |  | 799 |  |  |  | 21,465 |  |  |  | 1,411 |  |
| Amortization of intangibles |  |  | 17,649 |  |  |  | 8,940 |  |  |  | 49,886 |  |  |  | 32,280 |  |
| Total operating expenses |  |  | 187,058 |  |  |  | 129,148 |  |  |  | 638,946 |  |  |  | 478,548 |  |
| Income from operations |  |  | 175,481 |  |  |  | 171,054 |  |  |  | 721,136 |  |  |  | 479,106 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (9,529 | ) |  |  | (7,910 | ) |  |  | (32,953 | ) |  |  | (32,991 | ) |
| Investment income |  |  | 403 |  |  |  | 261 |  |  |  | 1,415 |  |  |  | 2,182 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (831 | ) |  |  | – |  |
| Other, net |  |  | 223 |  |  |  | 581 |  |  |  | 2,759 |  |  |  | (2,106 | ) |
| Total other expense, net |  |  | (8,903 | ) |  |  | (7,068 | ) |  |  | (29,610 | ) |  |  | (32,915 | ) |
| Income before provision for income taxes |  |  | 166,578 |  |  |  | 163,986 |  |  |  | 691,526 |  |  |  | 446,191 |  |
| Provision for income taxes |  |  | 20,616 |  |  |  | 39,006 |  |  |  | 134,957 |  |  |  | 98,973 |  |
| Net income |  |  | 145,962 |  |  |  | 124,980 |  |  |  | 556,569 |  |  |  | 347,218 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,067 |  |  |  | (21 | ) |  |  | 6,075 |  |  |  | (3,358 | ) |
| Net income attributable to Generac Holdings Inc. |  | $ | 142,895 |  |  | $ | 125,001 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | (4,559 | ) |  | $ | 23,664 |  |  | $ | (41,030 | ) |  | $ | 4,948 |  |
| Net unrealized gain (loss) on derivatives |  |  | 5,345 |  |  |  | 4,121 |  |  |  | 20,529 |  |  |  | (14,285 | ) |
| Other comprehensive income (loss) |  |  | 786 |  |  |  | 27,785 |  |  |  | (20,501 | ) |  |  | (9,337 | ) |
| Total comprehensive income |  |  | 146,748 |  |  |  | 152,765 |  |  |  | 536,068 |  |  |  | 337,881 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 2,964 |  |  |  | 2,068 |  |  |  | 5,496 |  |  |  | (364 | ) |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 143,784 |  |  | $ | 150,697 |  |  | $ | 530,572 |  |  | $ | 338,245 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.09 |  |  | $ | 2.02 |  |  | $ | 8.51 |  |  | $ | 5.61 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,992,455 |  |  |  | 62,389,159 |  |  |  | 62,686,001 |  |  |  | 62,280,889 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.04 |  |  | $ | 1.97 |  |  | $ | 8.30 |  |  | $ | 5.48 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,487,071 |  |  |  | 63,985,879 |  |  |  | 64,253,408 |  |  |  | 63,737,734 |  |

[0001437749-22-003484:8k_2_02:86]
6

[0001437749-22-003484:8k_2_02:87]
| Generac Holdings Inc. |
| Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-003484:8k_2_02:88]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 147,339 |  |  | $ | 655,128 |  |
| Accounts receivable, less allowance for credit losses of $12,025 and $12,001 at December 31, 2021 and 2020, respectively |  |  | 546,466 |  |  |  | 374,906 |  |
| Inventories |  |  | 1,089,705 |  |  |  | 603,317 |  |
| Prepaid expenses and other assets |  |  | 64,954 |  |  |  | 36,382 |  |
| Total current assets |  |  | 1,848,464 |  |  |  | 1,669,733 |  |
| Property and equipment, net |  |  | 440,852 |  |  |  | 343,936 |  |
| Customer lists, net |  |  | 238,722 |  |  |  | 49,205 |  |
| Patents and technology, net |  |  | 492,473 |  |  |  | 86,727 |  |
| Other intangible assets, net |  |  | 66,436 |  |  |  | 9,932 |  |
| Tradenames, net |  |  | 243,531 |  |  |  | 146,159 |  |
| Goodwill |  |  | 1,409,674 |  |  |  | 855,228 |  |
| Deferred income taxes |  |  | 15,740 |  |  |  | 1,497 |  |
| Operating lease and other assets |  |  | 121,888 |  |  |  | 73,006 |  |
| Total assets |  | $ | 4,877,780 |  |  | $ | 3,235,423 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 72,035 |  |  | $ | 39,282 |  |
| Accounts payable |  |  | 674,208 |  |  |  | 330,247 |  |
| Accrued wages and employee benefits |  |  | 72,060 |  |  |  | 63,036 |  |
| Other accrued liabilities |  |  | 331,674 |  |  |  | 204,812 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 5,930 |  |  |  | 4,147 |  |
| Total current liabilities |  |  | 1,155,907 |  |  |  | 641,524 |  |
| Long-term borrowings and finance lease obligations |  |  | 902,091 |  |  |  | 841,764 |  |
| Deferred income taxes |  |  | 205,964 |  |  |  | 115,769 |  |
| Operating lease and other long-term liabilities |  |  | 341,681 |  |  |  | 179,955 |  |
| Total liabilities |  |  | 2,605,643 |  |  |  | 1,779,012 |  |
| Redeemable noncontrolling interest |  |  | 58,050 |  |  |  | 66,207 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,386,017 and 72,024,329 shares issued at December 31, 2021 and December 31, 2020, respectively |  |  | 725 |  |  |  | 721 |  |
| Additional paid-in capital |  |  | 952,939 |  |  |  | 525,541 |  |
| Treasury stock, at cost, 8,667,031 and 9,173,731 shares at December 31, 2021 and 2020, respectively |  |  | (448,976 | ) |  |  | (332,164 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,965,957 |  |  |  | 1,432,565 |  |
| Accumulated other comprehensive loss |  |  | (54,755 | ) |  |  | (34,254 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,213,774 |  |  |  | 1,390,293 |  |
| Noncontrolling interests |  |  | 313 |  |  |  | (89 | ) |
| Total stockholders’ equity |  |  | 2,214,087 |  |  |  | 1,390,204 |  |
| Total liabilities and stockholders’ equity |  | $ | 4,877,780 |  |  | $ | 3,235,423 |  |

[0001437749-22-003484:8k_2_02:89]
7

[0001437749-22-003484:8k_2_02:90]
| Generac Holdings Inc. |
| Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-003484:8k_2_02:91]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 556,569 |  |  | $ | 347,218 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 42,155 |  |  |  | 36,493 |  |
| Amortization of intangible assets |  |  | 49,886 |  |  |  | 32,280 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,589 |  |  |  | 2,598 |  |
| Loss on extinguishment of debt |  |  | 831 |  |  |  | – |  |
| Deferred income taxes |  |  | (2,096 | ) |  |  | 21,195 |  |
| Share-based compensation expense |  |  | 23,954 |  |  |  | 20,882 |  |
| Loss (gain) on disposal of assets |  |  | (4,393 | ) |  |  | – |  |
| Other, net |  |  | 206 |  |  |  | 7,145 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (131,861 | ) |  |  | (55,976 | ) |
| Inventories |  |  | (470,991 | ) |  |  | (77,983 | ) |
| Other assets |  |  | (819 | ) |  |  | 12,859 |  |
| Accounts payable |  |  | 297,323 |  |  |  | 66,040 |  |
| Accrued wages and employee benefits |  |  | 5,814 |  |  |  | 20,157 |  |
| Other accrued liabilities |  |  | 73,798 |  |  |  | 60,593 |  |
| Excess tax benefits from equity awards |  |  | (31,809 | ) |  |  | (6,968 | ) |
| Net cash provided by operating activities |  |  | 411,156 |  |  |  | 486,533 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 259 |  |  |  | 179 |  |
| Proceeds from sale of investment |  |  | 4,968 |  |  |  | – |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 4,609 |  |  |  | 2,651 |  |
| Contribution to equity method investment |  |  | (3,660 | ) |  |  | – |  |
| Expenditures for property and equipment |  |  | (109,992 | ) |  |  | (62,128 | ) |
| Acquisition of business, net of cash acquired |  |  | (713,471 | ) |  |  | (64,797 | ) |
| Net cash used in investing activities |  |  | (817,287 | ) |  |  | (124,095 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 272,818 |  |  |  | 257,593 |  |
| Proceeds from long-term borrowings |  |  | 150,088 |  |  |  | 277 |  |
| Repayments of short-term borrowings |  |  | (239,113 | ) |  |  | (277,719 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (108,556 | ) |  |  | (4,758 | ) |
| Stock repurchases |  |  | (125,992 | ) |  |  | – |  |
| Payment of contingent acquisition consideration |  |  | (3,750 | ) |  |  | (4,000 | ) |
| Payment of debt issuance costs |  |  | (1,185 | ) |  |  | – |  |
| Purchase of additional ownership interest |  |  | (27,164 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (58,903 | ) |  |  | (14,910 | ) |
| Proceeds from the exercise of stock options |  |  | 38,787 |  |  |  | 13,089 |  |
| Net cash used in financing activities |  |  | (102,970 | ) |  |  | (30,428 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,312 |  |  |  | 235 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (507,789 | ) |  |  | 332,245 |  |
| Cash and cash equivalents at beginning of period |  |  | 655,128 |  |  |  | 322,883 |  |
| Cash and cash equivalents at end of period |  | $ | 147,339 |  |  | $ | 655,128 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 27,842 |  |  | $ | 28,765 |  |
| Income taxes |  |  | 156,728 |  |  |  | 61,861 |  |

[0001437749-22-003484:8k_2_02:92]
8

[0001437749-22-003484:8k_2_02:93]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-003484:8k_2_02:94]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 896,402 |  |  | $ | 645,128 |  |  | $ | 3,164,050 |  |  | $ | 2,088,808 |  |
| International |  |  | 170,669 |  |  |  | 115,954 |  |  |  | 573,134 |  |  |  | 396,392 |  |
| Total net sales |  | $ | 1,067,071 |  |  | $ | 761,082 |  |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 705,808 |  |  | $ | 498,653 |  |  | $ | 2,456,765 |  |  | $ | 1,556,501 |  |
| Commercial & industrial products |  |  | 284,004 |  |  |  | 198,596 |  |  |  | 998,998 |  |  |  | 701,751 |  |
| Other |  |  | 77,259 |  |  |  | 63,833 |  |  |  | 281,421 |  |  |  | 226,948 |  |
| Total net sales |  | $ | 1,067,071 |  |  | $ | 761,082 |  |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |

[0001437749-22-003484:8k_2_02:95]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 196,691 |  |  | $ | 188,004 |  |  | $ | 795,417 |  |  | $ | 563,394 |  |
| International |  |  | 23,664 |  |  |  | 7,827 |  |  |  | 66,008 |  |  |  | 20,379 |  |
| Total adjusted EBITDA (1) |  | $ | 220,355 |  |  | $ | 195,831 |  |  | $ | 861,425 |  |  | $ | 583,773 |  |

[0001437749-22-003484:8k_2_02:96]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-22-003484:8k_2_02:97]
9

[0001437749-22-003484:8k_2_02:98]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-003484:8k_2_02:99]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 142,895 |  |  | $ | 125,001 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,067 |  |  |  | (21 | ) |  |  | 6,075 |  |  |  | (3,358 | ) |
| Net income |  |  | 145,962 |  |  |  | 124,980 |  |  |  | 556,569 |  |  |  | 347,218 |  |
| Interest expense |  |  | 9,529 |  |  |  | 7,910 |  |  |  | 32,953 |  |  |  | 32,991 |  |
| Depreciation and amortization |  |  | 29,359 |  |  |  | 18,686 |  |  |  | 92,041 |  |  |  | 68,773 |  |
| Provision for income taxes |  |  | 20,616 |  |  |  | 39,006 |  |  |  | 134,957 |  |  |  | 98,973 |  |
| Non-cash write-down and other adjustments (1) |  |  | (3,708 | ) |  |  | (2,195 | ) |  |  | (3,070 | ) |  |  | (327 | ) |
| Non-cash share-based compensation expense (2) |  |  | 5,750 |  |  |  | 6,555 |  |  |  | 23,954 |  |  |  | 20,882 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 12,886 |  |  |  | 991 |  |  |  | 22,357 |  |  |  | 2,151 |  |
| Business optimization and other charges (5) |  |  | (126 | ) |  |  | (345 | ) |  |  | 33 |  |  |  | 12,158 |  |
| Other |  |  | 87 |  |  |  | 243 |  |  |  | 800 |  |  |  | 954 |  |
| Adjusted EBITDA |  |  | 220,355 |  |  |  | 195,831 |  |  |  | 861,425 |  |  |  | 583,773 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,897 |  |  |  | 1,408 |  |  |  | 9,351 |  |  |  | 2,358 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 217,458 |  |  | $ | 194,423 |  |  | $ | 852,074 |  |  | $ | 581,415 |  |

[0001437749-22-003484:8k_2_02:100]
(1) Includes gains/losses on disposals of assets and gains on certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-22-003484:8k_2_02:101]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-22-003484:8k_2_02:102]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment.

[0001437749-22-003484:8k_2_02:103]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-22-003484:8k_2_02:104]
(5)  For the year ended December 31, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices.

[0001437749-22-003484:8k_2_02:105]
10

[0001437749-22-003484:8k_2_02:106]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 142,895 |  |  | $ | 125,001 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,067 |  |  |  | (21 | ) |  |  | 6,075 |  |  |  | (3,358 | ) |
| Net income |  |  | 145,962 |  |  |  | 124,980 |  |  |  | 556,569 |  |  |  | 347,218 |  |
| Provision for income taxes |  |  | 20,616 |  |  |  | 39,006 |  |  |  | 134,957 |  |  |  | 98,973 |  |
| Income before provision for income taxes |  |  | 166,578 |  |  |  | 163,986 |  |  |  | 691,526 |  |  |  | 446,191 |  |
| Amortization of intangible assets |  |  | 17,649 |  |  |  | 8,940 |  |  |  | 49,886 |  |  |  | 32,280 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 648 |  |  |  | 658 |  |  |  | 2,589 |  |  |  | 2,598 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | – |  |  |  | 831 |  |  |  | – |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 8,525 |  |  |  | (1,940 | ) |  |  | 19,655 |  |  |  | (1,328 | ) |
| (Gain)/loss attributable to business or asset dispositions (7) |  |  | (392 | ) |  |  | – |  |  |  | (4,383 | ) |  |  | – |  |
| Business optimization and other charges (5) |  |  | (126 | ) |  |  | (345 | ) |  |  | 33 |  |  |  | 12,158 |  |
| Adjusted net income before provision for income taxes |  |  | 192,882 |  |  |  | 171,299 |  |  |  | 760,137 |  |  |  | 491,899 |  |
| Cash income tax expense (8) |  |  | (29,667 | ) |  |  | (34,881 | ) |  |  | (136,231 | ) |  |  | (79,723 | ) |
| Adjusted net income |  |  | 163,215 |  |  |  | 136,418 |  |  |  | 623,906 |  |  |  | 412,176 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,355 |  |  |  | 693 |  |  |  | 4,971 |  |  |  | (32 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 161,860 |  |  | $ | 135,725 |  |  | $ | 618,935 |  |  | $ | 412,208 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.51 |  |  | $ | 2.12 |  |  | $ | 9.63 |  |  | $ | 6.47 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,487,071 |  |  |  | 63,985,879 |  |  |  | 64,253,408 |  |  |  | 63,737,734 |  |

[0001437749-22-003484:8k_2_02:107]
(6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-22-003484:8k_2_02:108]
(7) Represents gains on certain investments occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-22-003484:8k_2_02:109]
(8) Amount for the three months and year ended December 31, 2021 is based on an anticipated cash income tax rate of approximately 19.7% for the year ended 2021. Amount for the three months and year ended December 31, 2020 is based on an anticipated cash income tax rate of approximately 17.9% for the year ended 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-22-003484:8k_2_02:110]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net cash provided by operating activities |  | $ | 61,752 |  |  | $ | 218,223 |  |  | $ | 411,156 |  |  | $ | 486,533 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,369 |  |  |  | 653 |  |  |  | 4,609 |  |  |  | 2,651 |  |
| Expenditures for property and equipment |  |  | (22,536 | ) |  |  | (28,188 | ) |  |  | (109,992 | ) |  |  | (62,128 | ) |
| Free cash flow |  | $ | 41,585 |  |  | $ | 190,688 |  |  | $ | 305,773 |  |  | $ | 427,056 |  |

[0001437749-22-003484:8k_2_02:111]
11
