# GNRC notes — 0001437749-22-004080


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-22-004080:notes:1]
| 1. | Description of Business |

[0001437749-22-004080:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-22-004080:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of our "Powering a Smarter World" strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-22-004080:notes:4]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators for the India market. |

[0001437749-22-004080:notes:5]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

[0001437749-22-004080:notes:6]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or other power sources for homeowners and businesses, and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |

[0001437749-22-004080:notes:7]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-22-004080:notes:8]
| 2. | Summary of Accounting Policies |

[0001437749-22-004080:notes:9]
Principles of Consolidation

[0001437749-22-004080:notes:10]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-22-004080:notes:11]
Cash and Cash Equivalents

[0001437749-22-004080:notes:12]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-22-004080:notes:13]
Concentration of Credit Risk

[0001437749-22-004080:notes:14]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-22-004080:notes:15]
One customer accounted for approximately 8% and 13% of accounts receivable at  December 31, 2021 and 2020, respectively. No one customer accounted for greater than 6%, 6%, and 5%, of net sales during the years ended  December 31, 2021, 2020, and 2019, respectively.

[0001437749-22-004080:notes:16]
Accounts Receivable and Allowance for Credit Losses

[0001437749-22-004080:notes:17]
The Company's trade and other receivables primarily arise from the sale of our products and services to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, utilities, and certain end users with payment terms generally ranging from 30 to 90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-22-004080:notes:18]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity by entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-22-004080:notes:19]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds a credit insurance plan that covers the risk of loss up to specified amounts on certain trade receivables. As of  December 31, 2021, the Company had gross receivables of $558,491 and an allowance for credit losses of $12,025.

[0001437749-22-004080:notes:20]
The following is a tabular reconciliation of the Company's allowance for credit losses:

[0001437749-22-004080:notes:21]
|  |  | Year Ended December 31, 2021 |  |
| Balance at beginning of period |  | $ | 12,001 |  |
| Established for Acquisitions |  |  | 1,458 |  |
| Provision for credit losses |  |  | 206 |  |
| Charge-offs |  |  | (1,198 | ) |
| Currency translation |  |  | (442 | ) |
| Balance at end of period |  | $ | 12,025 |  |

[0001437749-22-004080:notes:22]
Inventories

[0001437749-22-004080:notes:23]
Inventories are stated at the lower of cost or market, with cost determined using the first-in, first-out method.

[0001437749-22-004080:notes:24]
Property and Equipment

[0001437749-22-004080:notes:25]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. Finance lease right of use assets are included in property and equipment. Refer to Note 10, "Leases," to the consolidated financial statements for the Company's lease disclosure.

[0001437749-22-004080:notes:26]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office equipment and systems |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-22-004080:notes:27]
Total depreciation expense was $42,155, $36,493, and $32,265 for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:28]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-22-004080:notes:29]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-22-004080:notes:30]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-22-004080:notes:31]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2021, 2020 and 2019, and found no impairment.

[0001437749-22-004080:notes:32]
Impairment of Long-Lived Assets

[0001437749-22-004080:notes:33]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-22-004080:notes:34]
Debt Issuance Costs

[0001437749-22-004080:notes:35]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $2,589, $2,598, and $4,712 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2021, 2020 and 2019, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2022 - $2,603; 2023 - $2,652; 2024 - $2,709; 2025 - $2,753; 2026 - $2,499.

[0001437749-22-004080:notes:36]
Income Taxes

[0001437749-22-004080:notes:37]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-22-004080:notes:38]
Revenue Recognition

[0001437749-22-004080:notes:39]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As a substantial portion of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-22-004080:notes:40]
At the request of certain customers, the Company will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-22-004080:notes:41]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $27,388 and $25,710 at  December 31, 2021 and  December 31, 2020, respectively. During the year ended  December 31, 2021, the Company recognized revenue of $25,184 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-22-004080:notes:42]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-22-004080:notes:43]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-22-004080:notes:44]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation, maintenance and grid services to utilities in certain circumstances. Total service revenues accounted for less than two percent of revenue during the year ended  December 31, 2021.

[0001437749-22-004080:notes:45]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-22-004080:notes:46]
Advertising and Co-Op Advertising

[0001437749-22-004080:notes:47]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $66,660, $53,678, and $44,153 for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:48]
Research and Development

[0001437749-22-004080:notes:49]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $104,303, $80,251, and $68,394 for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:50]
Foreign Currency Translation and Transactions

[0001437749-22-004080:notes:51]
Balance sheet amounts for non-U.S. Dollar functional currency subsidiaries are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:52]
Fair Value of Financial Instruments

[0001437749-22-004080:notes:53]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-22-004080:notes:54]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $768,119, was approximately $782,925 (Level 2) at  December 31, 2021, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-22-004080:notes:55]
For the fair value of the assets and liabilities measured on a recurring basis, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-22-004080:notes:56]
Contingent Consideration

[0001437749-22-004080:notes:57]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. This fair value measurement of contingent consideration is categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-22-004080:notes:58]
The fair value of contingent consideration as of  December 31, 2021 and  December 31, 2020 was $146,759 and $5,888, respectively. At  December 31, 2021, the Company recorded $68,665 in other accrued liabilities and $78,094 in other long-term liabilities in the consolidated balance sheets. At  December 31, 2020, the Company recorded $5,888 in other accrued liabilities in the consolidated balance sheets.

[0001437749-22-004080:notes:59]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-22-004080:notes:60]
| Beginning balance, January 1, 2021 |  | $ | 5,888 |  |
| Purchase price contingent consideration (1) |  |  | 149,761 |  |
| Changes in fair value |  |  | (6,002 | ) |
| Present value interest accretion |  |  | 862 |  |
| Payments |  |  | (3,750 | ) |
| Ending balance, December 31, 2021 |  | $ | 146,759 |  |

[0001437749-22-004080:notes:61]
|  | (1) | The increase in the contingent consideration liability is due to the contingent consideration associated with the acquisitions of Chilicon, Off Grid Energy, and ecobee. Refer to Note 3, "Acquisitions," to the consolidated financial statements for further information. |

[0001437749-22-004080:notes:62]
Use of Estimates

[0001437749-22-004080:notes:63]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-22-004080:notes:64]
Derivative Instruments and Hedging Activities

[0001437749-22-004080:notes:65]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes. Refer to Item 7A of this Annual Report on Form 10-K for further information on the Company’s derivatives.

[0001437749-22-004080:notes:66]
Share-Based Compensation

[0001437749-22-004080:notes:67]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.

[0001437749-22-004080:notes:68]
Acquisition related costs

[0001437749-22-004080:notes:69]
Acquisition related costs are external costs the Company incurs to effect a business combination including legal fees, professional and advisory services, transaction taxes such as stamp tax, and insurance premiums. The Company accounts for acquisition related costs as expense in the period in which the costs are incurred and the services are received. Total acquisition related costs were $21,465, $1,411, and $1,851 for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:70]
Certain immaterial reclassifications have been made to the Company’s historical financial statements as the Company has elected to report acquisition related costs as a separate line item in its Consolidated Statements of Comprehensive Income, within operating expenses. Previously, acquisition related costs were included in the general and administrative line item within operating expenses in the Consolidated Statements of Comprehensive Income. For the years ended  December 31, 2020, and 2019, the Company reclassified $1,411 and $1,851, respectively, from general and administrative expenses to acquisition related costs in the Consolidated Statements of Comprehensive Income.

[0001437749-22-004080:notes:71]
New Accounting Pronouncements

[0001437749-22-004080:notes:72]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

[0001437749-22-004080:notes:73]
Recently Adopted Accounting Standards

[0001437749-22-004080:notes:74]
On  October 1, 2021, the Company elected to early adopt ASU 2021-08, Business Combinations – Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This guidance was issued to improve the accounting for acquired revenue contracts with customers in a business combination by addressing diversity in practice and inconsistency related to the following: 1) recognition of an acquired contract liability; 2) payment terms and their effect on subsequent revenue recognized by the acquirer. Specifically, this guidance addresses how to determine whether a contract liability is recognized by the acquirer in a business combination as well as provides specific guidance on how to recognize and measure acquired contract assets and contract liabilities from revenue contracts in a business combination. The Company adopted this standard prospectively as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard allows for the Company to apply ASC 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities on the acquisition date, which the Company applied to all of its current year acquisitions. Refer to Note 3 “Acquisitions,” to the consolidated financial statements, for further information regarding the Company’s acquisitions and purchase price allocations.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-004080:notes:75]
| 3. | Acquisitions |

[0001437749-22-004080:notes:76]
Fiscal 2021

[0001437749-22-004080:notes:77]
Acquisition of Deep Sea

[0001437749-22-004080:notes:78]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. The acquisition purchase price was funded solely through cash on hand.

[0001437749-22-004080:notes:79]
The Company recorded its preliminary purchase price allocation during the second quarter of 2021, and was updated in the third and fourth quarters of 2021, based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $437,864 of intangible assets, including $266,427 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Deep Sea from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:80]
Acquisition of Chilicon

[0001437749-22-004080:notes:81]
On  July 2, 2021, the Company acquired Chilicon for a purchase price, net of cash acquired, of $61,129. Based in Los Angeles, California, Chilicon is a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. The fair value of the consideration transferred consisted of the following:

[0001437749-22-004080:notes:82]
| Cash |  | $ | 11,821 |  |
| Deferred cash payment (1) |  |  | 6,000 |  |
| Common stock issued |  |  | 12,000 |  |
| Contingent consideration (2) |  |  | 31,308 |  |
| Total purchase price |  | $ | 61,129 |  |

[0001437749-22-004080:notes:83]
| (1) | Payable on the third business day after December 31, 2023. |
| (2) | Payable within 45 calendar days following the conclusion of the earnout period, December 31, 2025. To be paid in the form of common stock issued upon achievement of certain performance targets at the end of the earnout period. |

[0001437749-22-004080:notes:84]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021, and was updated in the fourth quarter of 2021, based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $69,992 of intangible assets, including $37,492 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Chilicon from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:85]
Acquisition of Off Grid Energy

[0001437749-22-004080:notes:86]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $53,438, net of cash acquired and inclusive of estimated contingent consideration of $29,054 that is to be paid in cash upon achievement of certain performance targets at the end of the earnout period,  March 31, 2022. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-22-004080:notes:87]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021, and was updated in the fourth quarter of 2021, based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $52,565 of intangible assets, including $18,020 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:88]
Acquisition of ecobee

[0001437749-22-004080:notes:89]
On  December 1, 2021, the Company acquired ecobee for a purchase price, net of cash acquired, of $734,638. Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. The fair value of the consideration transferred consisted of the following:

[0001437749-22-004080:notes:90]
| Cash |  | $ | 224,464 |  |
| Common stock issued |  |  | 420,774 |  |
| Contingent consideration (1) |  |  | 89,400 |  |
| Total purchase price |  | $ | 734,638 |  |

[0001437749-22-004080:notes:91]
| (1) | To be paid in the form of common stock issued upon achievement of certain performance targets at the end of each of the two earnout periods, ending June 30, 2022, and June 30, 2023. |

[0001437749-22-004080:notes:92]
The Company recorded its preliminary purchase price allocation during the fourth quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $795,613 of intangible assets, including $231,213 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of ecobee from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:93]
Other Acquisitions

[0001437749-22-004080:notes:94]
On  September 1, 2021, the Company acquired Apricity Code, an advanced engineering and product design company located in Bend, Oregon.

[0001437749-22-004080:notes:95]
On  October 1, 2021, the Company acquired Tank Utility, a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.

[0001437749-22-004080:notes:96]
The combined purchase price for these acquisitions was $30,086 and was funded solely through cash on hand. The Company recorded its preliminary purchase price allocation for Apricity Code and Tank Utility during the third quarter and fourth quarter of 2021, respectively, based upon its estimates of the fair value of the acquired assets and assumed liabilities. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:97]
Fiscal 2020

[0001437749-22-004080:notes:98]
Acquisition of Enbala

[0001437749-22-004080:notes:99]
On  October 7, 2020, the Company acquired Enbala for a purchase price, net of cash acquired, of $41,982. The acquisition purchase price was funded solely through cash on hand.

[0001437749-22-004080:notes:100]
The Company finalized its purchase price allocation during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $46,338 of intangible assets, including $27,038 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of Enbala from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:101]
On  July 1, 2020, the Company acquired Energy Systems, its industrial distributor in northern California.

[0001437749-22-004080:notes:102]
On  September 1, 2020, the Company acquired Mean Green, a designer and manufacturer of commercial grade, battery-powered turf care products.

[0001437749-22-004080:notes:103]
The combined purchase price for these acquisitions was $22,958 and was funded solely through cash on hand. The Company finalized its purchase price allocation for these two acquisitions during the third quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:104]
Fiscal 2019

[0001437749-22-004080:notes:105]
Acquisition of Pika

[0001437749-22-004080:notes:106]
On  April 26, 2019, the Company acquired Pika for a purchase price, net of cash acquired, of $49,068. The acquisition purchase price was funded solely through cash on hand.

[0001437749-22-004080:notes:107]
The Company finalized the Pika purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Pika from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:108]
Acquisition of Neurio

[0001437749-22-004080:notes:109]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of a deferred payment of $7,922 which was made during the third quarter of 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-22-004080:notes:110]
The Company finalized the Neurio purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of Neurio from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:111]
In  February 2019, the Company acquired a majority share of Captiva, a manufacturer of customized industrial generators in Kolkata, India. The purchase price was immaterial to the Company and was funded solely through cash on hand. The accompanying consolidated financial statements include the results of the acquired business from the date of acquisition through  December 31, 2021.

[0001437749-22-004080:notes:112]
Summary Purchase Price Allocations

[0001437749-22-004080:notes:113]
The fair values assigned to certain assets acquired and liabilities assumed for all acquisitions completed during the reporting period, as of the acquisition dates, are as follows:

[0001437749-22-004080:notes:114]
|  |  | 2021 Acquisitions |  |  |  |  |  |  |  |  |  |
|  |  | Deep Sea |  |  | ecobee |  |  | All Other |  |  | Total |  |  | 2020 Acquisitions |  |  | 2019 Acquisitions |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,853 |  |  | $ | 46,764 |  |  | $ | 5,094 |  |  | $ | 4,643 |  |
| Inventories |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |  |  | 3,575 |  |  |  | 4,313 |  |
| Prepaid expenses and other assets |  |  | 826 |  |  |  | 5,531 |  |  |  | 6,594 |  |  |  | 12,951 |  |  |  | 858 |  |  |  | 304 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 12,838 |  |  |  | 480 |  |  |  | 22,156 |  |  |  | 635 |  |  |  | 384 |  |
| Intangible assets |  |  | 171,437 |  |  |  | 564,400 |  |  |  | 74,394 |  |  |  | 810,231 |  |  |  | 26,235 |  |  |  | 79,200 |  |
| Goodwill |  |  | 266,427 |  |  |  | 231,213 |  |  |  | 82,121 |  |  |  | 579,761 |  |  |  | 40,395 |  |  |  | 41,428 |  |
| Deferred income taxes |  |  | - |  |  |  | 52,329 |  |  |  | 6,547 |  |  |  | 58,876 |  |  |  | - |  |  |  | 3,217 |  |
| Other assets |  |  | 151 |  |  |  | 4,031 |  |  |  | 8,526 |  |  |  | 12,708 |  |  |  | 1,122 |  |  |  | 133 |  |
| Total assets acquired |  |  | 467,223 |  |  |  | 900,937 |  |  |  | 199,549 |  |  |  | 1,567,709 |  |  |  | 77,914 |  |  |  | 133,622 |  |
| Accounts payable |  |  | 8,998 |  |  |  | 29,855 |  |  |  | 7,675 |  |  |  | 46,528 |  |  |  | 4,088 |  |  |  | 4,380 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 862 |  |  |  | 4,322 |  |  |  | 700 |  |  |  | 4,408 |  |
| Other accrued liabilities |  |  | 2,272 |  |  |  | 18,830 |  |  |  | 18,258 |  |  |  | 39,360 |  |  |  | 2,151 |  |  |  | 602 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |  |  | - |  |  |  |  |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | - |  |  |  | 1,068 |  |  |  | 233 |  |  |  | 1,301 |  |  |  | - |  |  |  | 937 |  |
| Deferred income taxes |  |  | 33,057 |  |  |  | 81,429 |  |  |  | 18,169 |  |  |  | 132,655 |  |  |  | 3,827 |  |  |  | 9,958 |  |
| Other long-term liabilities |  |  | 90 |  |  |  | 24,097 |  |  |  | 7,275 |  |  |  | 31,462 |  |  |  | 2,208 |  |  |  | 778 |  |
| Long-term debt |  |  | - |  |  |  | 9,666 |  |  |  | 1,624 |  |  |  | 11,290 |  |  |  | - |  |  |  | - |  |
| Redeemable non-controlling interest |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,165 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 734,638 |  |  | $ | 144,653 |  |  | $ | 1,299,991 |  |  | $ | 64,940 |  |  | $ | 109,394 |  |

[0001437749-22-004080:notes:115]
The allocations of the purchase price to identifiable assets and liabilities for the 2021 acquisitions are based on the preliminary valuations performed to determine the fair value of the net assets as of their respective acquisition dates. The measurement period for the valuation of net assets acquired ends as soon as information on the facts and circumstances that existed as of the acquisition dates becomes available, but not to exceed 12 months following the acquisition date. As the Company finalizes valuations, adjustments in purchase price allocations  may require a change in the amounts allocated to net assets acquired during the periods in which the adjustments are determined.

[0001437749-22-004080:notes:116]
Pro Forma Information

[0001437749-22-004080:notes:117]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on  January 1, 2019. Refer to Note 1, “Description of Business,” for further information on the acquisitions included in the table.

[0001437749-22-004080:notes:118]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |
| Pro forma |  |  | 3,877,995 |  |  |  | 2,712,813 |  |  |  | 2,408,671 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 550,494 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Pro forma (1) |  |  | 465,983 |  |  |  | 276,579 |  |  |  | 135,778 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 8.30 |  |  | $ | 5.48 |  |  | $ | 4.03 |  |
| Pro forma |  |  | 7.16 |  |  |  | 4.29 |  |  |  | 2.15 |  |

[0001437749-22-004080:notes:119]
|  | (1) | Includes additional pro forma intangible amortization from the effect of all acquisitions as though the transactions had occurred on January 1, 2019 of $63,524, $78,840, and $83,100 for the years ended December 31, 2021, 2020, and 2019, respectively |

[0001437749-22-004080:notes:120]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on  January 1, 2019.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-22-004080:notes:121]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-22-004080:notes:122]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer held the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next three years.

[0001437749-22-004080:notes:123]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions, Ltd (Captiva). The 49% noncontrolling interest in Captiva has an acquisition date fair value of $3,165, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put option price is based on a multiple of earnings, subject to the terms of the acquisition. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings, subject to the terms of the acquisition.

[0001437749-22-004080:notes:124]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of subsequent comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-22-004080:notes:125]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 66,207 |  |  | $ | 61,227 |  |  | $ | 61,004 |  |
| Acquisition of noncontrolling interest in Captiva |  |  | - |  |  |  | - |  |  |  | 3,165 |  |
| Net income |  |  | 5,574 |  |  |  | (2,829 | ) |  |  | 75 |  |
| Foreign currency translation |  |  | (3,669 | ) |  |  | 6,562 |  |  |  | (1,764 | ) |
| Purchase of additional ownership interest |  |  | (27,164 | ) |  |  | - |  |  |  | - |  |
| Redemption value adjustment |  |  | 17,102 |  |  |  | 1,247 |  |  |  | (1,253 | ) |
| Balance at end of period |  | $ | 58,050 |  |  | $ | 66,207 |  |  | $ | 61,227 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-22-004080:notes:126]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-22-004080:notes:127]
Commodities

[0001437749-22-004080:notes:128]
The Company is exposed to price fluctuations in commodities including steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than eighteen months. At  December 31, 2021, the Company had no commodity contracts outstanding. At  December 31, 2020, the Company had one commodity contract outstanding.

[0001437749-22-004080:notes:129]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized were $613, $2,185, and $(174) for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:130]
Foreign Currencies

[0001437749-22-004080:notes:131]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less. As of  December 31, 2021 and 2020, the Company had eleven and forty-four foreign currency contracts outstanding, respectively.

[0001437749-22-004080:notes:132]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in "other, net" in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended  December 31, 2021, 2020 and 2019 were $(416), $355, and $(1,195), respectively.

[0001437749-22-004080:notes:133]
Interest Rate Swaps

[0001437749-22-004080:notes:134]
In 2017, the Company entered into twenty interest rate swap agreements, eight of which were still outstanding as of  December 31, 2021. In  December 2019, in conjunction with the amendment to its Term Loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to eleven as of  December 31, 2021. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking these hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets. The amount of after-tax gains (losses) recognized for the years ended  December 31, 2021, 2020 and 2019 were $20,529, $(14,285), and $(13,855), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-22-004080:notes:135]
Fair Value

[0001437749-22-004080:notes:136]
The following table presents the fair value of the Company’s derivatives:

[0001437749-22-004080:notes:137]
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Commodity contract |  | $ | - |  |  | $ | 1,386 |  |
| Foreign currency contracts |  |  | (36 | ) |  |  | (154 | ) |
| Interest rate swaps |  |  | (2,074 | ) |  |  | (29,536 | ) |

[0001437749-22-004080:notes:138]
The fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2021. The fair value of the commodity contract is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2020. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2021 and 2020 is a liability of $2,148 and $28,667, respectively, which represents the net amount the Company would pay to exit all of the agreements on those dates.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-22-004080:notes:139]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-22-004080:notes:140]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2021 and 2020, net of tax:

[0001437749-22-004080:notes:141]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (41,030 | ) | (1) |  |  | 20,529 |  | (2) |  |  | (20,501 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (41,030 | ) |  |  |  | 20,529 |  |  |  |  | (20,501 | ) |
| Ending Balance – December 31, 2021 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |

[0001437749-22-004080:notes:142]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 4,948 |  |  |  | (14,285 | ) | (3) |  |  | (9,337 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 4,948 |  |  |  | (14,285 | ) |  |  |  | (9,337 | ) |
| Ending Balance – December 31, 2020 |  | $ | (11,674 | ) |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |

[0001437749-22-004080:notes:143]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2021, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $27,462 on the interest rate swaps, net of tax effect of $(6,933) for the year ended December 31, 2021. |

[0001437749-22-004080:notes:144]
|  | (3) | Represents unrealized losses of $(19,111) on the interest rate swaps, net of tax effect of $4,826 for the year ended December 31, 2020. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-004080:notes:145]
| 7. | Segment Reporting |

[0001437749-22-004080:notes:146]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business' Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, Deep Sea, and Off Grid Energy acquisitions, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products and solutions, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-22-004080:notes:147]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, grid service solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-22-004080:notes:148]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,366,908 |  |  | $ | 89,857 |  |  | $ | 2,456,765 |  |
| Commercial & industrial products |  |  | 556,520 |  |  |  | 442,478 |  |  |  | 998,998 |  |
| Other |  |  | 240,622 |  |  |  | 40,799 |  |  |  | 281,421 |  |
| Total net sales |  | $ | 3,164,050 |  |  | $ | 573,134 |  |  | $ | 3,737,184 |  |

[0001437749-22-004080:notes:149]
|  |  | Year Ended December 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,495,383 |  |  | $ | 61,118 |  |  | $ | 1,556,501 |  |
| Commercial & industrial products |  |  | 404,867 |  |  |  | 296,884 |  |  |  | 701,751 |  |
| Other |  |  | 188,558 |  |  |  | 38,390 |  |  |  | 226,948 |  |
| Total net sales |  | $ | 2,088,808 |  |  | $ | 396,392 |  |  | $ | 2,485,200 |  |

[0001437749-22-004080:notes:150]
|  |  | Year Ended December 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,086,019 |  |  | $ | 57,704 |  |  | $ | 1,143,723 |  |
| Commercial & industrial products |  |  | 513,482 |  |  |  | 358,113 |  |  |  | 871,595 |  |
| Other |  |  | 143,397 |  |  |  | 45,621 |  |  |  | 189,018 |  |
| Total net sales |  | $ | 1,742,898 |  |  | $ | 461,438 |  |  | $ | 2,204,336 |  |

[0001437749-22-004080:notes:151]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-22-004080:notes:152]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage, mobile heaters, mobile pumps, and controllers. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-22-004080:notes:153]
Other consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-22-004080:notes:154]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-22-004080:notes:155]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 795,417 |  |  | $ | 563,394 |  |  | $ | 428,667 |  |
| International |  |  | 66,008 |  |  |  | 20,379 |  |  |  | 25,448 |  |
| Total adjusted EBITDA |  | $ | 861,425 |  |  | $ | 583,773 |  |  | $ | 454,115 |  |
| Interest expense |  |  | (32,953 | ) |  |  | (32,991 | ) |  |  | (41,544 | ) |
| Depreciation and amortization |  |  | (92,041 | ) |  |  | (68,773 | ) |  |  | (60,767 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 3,070 |  |  |  | 327 |  |  |  | (240 | ) |
| Non-cash share-based compensation expense (2) |  |  | (23,954 | ) |  |  | (20,882 | ) |  |  | (16,694 | ) |
| Loss on extinguishment of debt (3) |  |  | (831 | ) |  |  | - |  |  |  | (926 | ) |
| Loss on pension settlement (4) |  |  | - |  |  |  | - |  |  |  | (10,920 | ) |
| Transaction costs and credit facility fees (5) |  |  | (22,357 | ) |  |  | (2,151 | ) |  |  | (2,724 | ) |
| Business optimization and other charges (6) |  |  | (33 | ) |  |  | (12,158 | ) |  |  | (1,572 | ) |
| Other |  |  | (800 | ) |  |  | (954 | ) |  |  | 879 |  |
| Income before provision for income taxes |  | $ | 691,526 |  |  | $ | 446,191 |  |  | $ | 319,607 |  |

[0001437749-22-004080:notes:156]
|  | (1) | Includes gains/losses on disposals of assets and gains on certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting adjustments. |

[0001437749-22-004080:notes:157]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-22-004080:notes:158]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |

[0001437749-22-004080:notes:159]
|  | (4) | Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019. |

[0001437749-22-004080:notes:160]
|  | (5) | Represents transaction costs incurred directly in connection with any investment (including acquisitions), as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-22-004080:notes:161]
|  | (6) | For the year ended December 31, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. |

[0001437749-22-004080:notes:162]
The following tables summarize additional financial information by reportable segment:

[0001437749-22-004080:notes:163]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 3,742,101 |  |  | $ | 2,659,597 |  |  | $ | 2,123,251 |  |
| International |  |  | 1,135,679 |  |  |  | 575,826 |  |  |  | 542,418 |  |
| Total |  | $ | 4,877,780 |  |  | $ | 3,235,423 |  |  | $ | 2,665,669 |  |

[0001437749-22-004080:notes:164]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 66,675 |  |  | $ | 53,020 |  |  | $ | 46,145 |  |
| International |  |  | 25,366 |  |  |  | 15,753 |  |  |  | 14,764 |  |
| Total |  | $ | 92,041 |  |  | $ | 68,773 |  |  | $ | 60,909 |  |

[0001437749-22-004080:notes:165]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 100,672 |  |  | $ | 51,867 |  |  | $ | 36,007 |  |
| International |  |  | 9,320 |  |  |  | 10,261 |  |  |  | 24,795 |  |
| Total |  | $ | 109,992 |  |  | $ | 62,128 |  |  | $ | 60,802 |  |

[0001437749-22-004080:notes:166]
The Company’s sales in the United States represent approximately 82%, 82%, and 75% of total sales for the years ended  December 31, 2021, 2020 and 2019, respectively. Approximately 75% and 81% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2021 and 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-22-004080:notes:167]
| 8. | Balance Sheet Details |

[0001437749-22-004080:notes:168]
Inventories consist of the following:

[0001437749-22-004080:notes:169]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Raw material |  | $ | 727,162 |  |  | $ | 375,516 |  |
| Work-in-process |  |  | 10,756 |  |  |  | 6,833 |  |
| Finished goods |  |  | 351,787 |  |  |  | 220,968 |  |
| Total |  | $ | 1,089,705 |  |  | $ | 603,317 |  |

[0001437749-22-004080:notes:170]
As of  December 31, 2021 and 2020, inventories totaling $15,555 and $9,154, respectively, were on consignment at customer locations.

[0001437749-22-004080:notes:171]
Property and equipment consists of the following:

[0001437749-22-004080:notes:172]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Land and improvements |  | $ | 26,137 |  |  | $ | 18,363 |  |
| Buildings and improvements |  |  | 244,273 |  |  |  | 198,908 |  |
| Machinery and equipment |  |  | 186,611 |  |  |  | 153,696 |  |
| Dies and tools |  |  | 31,581 |  |  |  | 24,190 |  |
| Vehicles |  |  | 7,621 |  |  |  | 6,037 |  |
| Office equipment and systems |  |  | 125,048 |  |  |  | 107,923 |  |
| Leasehold improvements |  |  | 5,679 |  |  |  | 5,276 |  |
| Construction in progress |  |  | 47,602 |  |  |  | 30,227 |  |
| Gross property and equipment |  |  | 674,551 |  |  |  | 544,620 |  |
| Accumulated depreciation |  |  | (233,699 | ) |  |  | (200,684 | ) |
| Total |  | $ | 440,852 |  |  | $ | 343,936 |  |

[0001437749-22-004080:notes:173]
Total property and equipment included finance leases of $36,776 and $27,269 at  December 31, 2021 and 2020, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-22-004080:notes:174]
| 9. | Goodwill and Intangible Assets |

[0001437749-22-004080:notes:175]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2021 and 2020 are as follows:

[0001437749-22-004080:notes:176]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2019 |  | $ | 659,209 |  |  | $ | 146,075 |  |  | $ | 805,284 |  |
| Acquisitions of businesses, net |  |  | 42,722 |  |  |  | - |  |  |  | 42,722 |  |
| Foreign currency translation |  |  | 604 |  |  |  | 6,618 |  |  |  | 7,222 |  |
| Balance at December 31, 2020 |  |  | 702,535 |  |  |  | 152,693 |  |  |  | 855,228 |  |
| Acquisitions of businesses, net |  |  | 293,614 |  |  |  | 284,447 |  |  |  | 578,061 |  |
| Foreign currency translation |  |  | (705 | ) |  |  | (22,910 | ) |  |  | (23,615 | ) |
| Balance at December 31, 2021 |  | $ | 995,444 |  |  | $ | 414,230 |  |  | $ | 1,409,674 |  |

[0001437749-22-004080:notes:177]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-22-004080:notes:178]
The details of the gross goodwill applicable to each reportable segment at  December 31, 2021 and 2020 are as follows:

[0001437749-22-004080:notes:179]
|  |  | Year Ended December 31, 2021 |  |  | Year Ended December 31, 2020 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,498,637 |  |  | $ | (503,193 | ) |  | $ | 995,444 |  |  | $ | 1,205,728 |  |  | $ | (503,193 | ) |  | $ | 702,535 |  |
| International |  |  | 418,841 |  |  |  | (4,611 | ) |  | $ | 414,230 |  |  |  | 157,304 |  |  |  | (4,611 | ) |  | $ | 152,693 |  |
| Total |  | $ | 1,917,478 |  |  | $ | (507,804 | ) |  | $ | 1,409,674 |  |  | $ | 1,363,032 |  |  | $ | (507,804 | ) |  | $ | 855,228 |  |

[0001437749-22-004080:notes:180]
The following table summarizes intangible assets by major category as of  December 31, 2021 and 2020:

[0001437749-22-004080:notes:181]
|  |  | Weighted Average |  |  | December 31, 2021 |  |  | December 31, 2020 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  | 14 |  |  | $ | 162,563 |  |  | $ | (47,353 | ) |  | $ | 115,210 |  |  | $ | 58,729 |  |  | $ | (40,891 | ) |  | $ | 17,838 |  |
| Customer lists |  | 11 |  |  |  | 573,910 |  |  |  | (335,188 | ) |  |  | 238,722 |  |  |  | 370,736 |  |  |  | (321,531 | ) |  |  | 49,205 |  |
| Patents and technology |  | 14 |  |  |  | 662,341 |  |  |  | (169,868 | ) |  |  | 492,473 |  |  |  | 233,271 |  |  |  | (146,544 | ) |  |  | 86,727 |  |
| Software |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  | 5 |  |  |  | 79,416 |  |  |  | (12,980 | ) |  |  | 66,436 |  |  |  | 16,469 |  |  |  | (6,537 | ) |  |  | 9,932 |  |
| Total finite-lived intangible assets |  |  |  |  | $ | 1,479,276 |  |  | $ | (566,435 | ) |  | $ | 912,841 |  |  | $ | 680,251 |  |  | $ | (516,549 | ) |  | $ | 163,702 |  |
| Indefinite-lived tradenames |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  | $ | 1,607,597 |  |  | $ | (566,435 | ) |  | $ | 1,041,162 |  |  | $ | 808,572 |  |  | $ | (516,549 | ) |  | $ | 292,023 |  |

[0001437749-22-004080:notes:182]
Amortization expense of intangible assets was $49,886, $32,280, and $28,644 in 2021, 2020 and 2019, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2022 - $105,577; 2023 - $101,076; 2024 - $95,444; 2025 - $91,218; 2026 - $84,337.


## gnrc:LesseeOperatingLeasesAndFinanceLeasesTextBlock

[0001437749-22-004080:notes:183]
| 10. | Leases |

[0001437749-22-004080:notes:184]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (“ROU”) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-22-004080:notes:185]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-22-004080:notes:186]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 20 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 10 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arm's length transactions.

[0001437749-22-004080:notes:187]
The Company is a lessor of certain of its C&I mobile products as part of a rental fleet, as well as two of its buildings that it leases to third parties. The lease income related to these arrangements is not material to the consolidated financial statements.

[0001437749-22-004080:notes:188]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:189]
The components of total lease cost consist of the following:

[0001437749-22-004080:notes:190]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Operating lease cost |  | $ | 22,432 |  |  | $ | 18,648 |  |  | $ | 9,647 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 3,187 |  |  |  | 2,587 |  |  |  | 2,531 |  |
| Interest on lease liabilities |  |  | 2,021 |  |  |  | 2,237 |  |  |  | 2,227 |  |
| Total lease cost |  | $ | 27,640 |  |  | $ | 23,472 |  |  | $ | 14,405 |  |

[0001437749-22-004080:notes:191]
As of  January 1, 2019, the date of the adoption of ASU 2016-02, the Company recognized ROU assets and lease liabilities related to operating leases of $42,024 and $42,056, respectively, and there was no cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-22-004080:notes:192]
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Operating Leases |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 101,266 |  |  | $ | 62,030 |  |
| Operating lease liabilities - current (2) |  | $ | 23,549 |  |  | $ | 17,192 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 80,370 |  |  |  | 46,558 |  |
| Total operating lease liabilities |  | $ | 103,919 |  |  | $ | 63,750 |  |
| Finance Leases |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 47,119 |  |  | $ | 34,929 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (10,343 | ) |  |  | (7,660 | ) |
| Finance lease ROU assets, net (4) |  | $ | 36,776 |  |  | $ | 27,269 |  |
| Finance lease liabilities - current (5) |  | $ | 4,209 |  |  | $ | 2,311 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 34,966 |  |  |  | 25,060 |  |
| Total finance lease liabilities |  | $ | 39,175 |  |  | $ | 27,371 |  |

[0001437749-22-004080:notes:193]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-22-004080:notes:194]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-22-004080:notes:195]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-22-004080:notes:196]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-22-004080:notes:197]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-22-004080:notes:198]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-22-004080:notes:199]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-22-004080:notes:200]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 21,250 |  |  | $ | 18,412 |  |  | $ | 10,125 |  |
| Operating cash flows from finance leases |  |  | 1,972 |  |  |  | 1,871 |  |  |  | 1,864 |  |
| Financing cash flows from finance leases |  |  | 4,679 |  |  |  | 3,957 |  |  |  | 3,237 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 55,057 |  |  |  | 41,678 |  |  |  | 4,021 |  |
| Finance leases |  |  | 4,026 |  |  |  | 3,737 |  |  |  | 8,797 |  |

[0001437749-22-004080:notes:201]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2021 and 2020 is as follows:

[0001437749-22-004080:notes:202]
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 5.21 |  |  |  | 4.92 |  |
| Finance Leases |  |  | 11.94 |  |  |  | 12.90 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 3.58 | % |  |  | 4.48 | % |
| Finance Leases |  |  | 7.43 | % |  |  | 7.66 | % |

[0001437749-22-004080:notes:203]
The maturities of the Company’s lease liabilities as of  December 31, 2021 are as follows:

[0001437749-22-004080:notes:204]
| As of December 31, 2021 |  |  |  |  |  |  |  |  |
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2022 |  | $ | 7,085 |  |  | $ | 26,615 |  |
| 2023 |  |  | 6,014 |  |  |  | 26,220 |  |
| 2024 |  |  | 5,835 |  |  |  | 25,062 |  |
| 2025 |  |  | 5,432 |  |  |  | 15,751 |  |
| 2026 |  |  | 5,091 |  |  |  | 6,469 |  |
| After 2026 |  |  | 30,646 |  |  |  | 15,047 |  |
| Total minimum lease payments |  |  | 60,103 |  |  |  | 115,164 |  |
| Interest component |  |  | (20,928 | ) |  |  | (11,245 | ) |
| Present value of minimum lease payments |  | $ | 39,175 |  |  | $ | 103,919 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-22-004080:notes:205]
| 11. | Product Warranty Obligations |

[0001437749-22-004080:notes:206]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-22-004080:notes:207]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 59,218 |  |  | $ | 49,316 |  |  | $ | 41,785 |  |
| Product warranty reserve assumed in acquisition |  |  | 3,932 |  |  |  | 124 |  |  |  | 1,062 |  |
| Payments |  |  | (42,682 | ) |  |  | (33,496 | ) |  |  | (26,096 | ) |
| Provision for warranty issued |  |  | 69,280 |  |  |  | 42,093 |  |  |  | 32,060 |  |
| Changes in estimates for pre-existing warranties |  |  | 4,465 |  |  |  | 1,181 |  |  |  | 505 |  |
| Balance at end of period |  | $ | 94,213 |  |  | $ | 59,218 |  |  | $ | 49,316 |  |

[0001437749-22-004080:notes:208]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-22-004080:notes:209]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 89,788 |  |  | $ | 78,738 |  |  | $ | 68,340 |  |
| Extended warranty contracts issued |  |  | 41,560 |  |  |  | 26,968 |  |  |  | 24,483 |  |
| Amortization of extended warranty contracts |  |  | (19,701 | ) |  |  | (15,918 | ) |  |  | (14,085 | ) |
| Balance at end of period |  | $ | 111,647 |  |  | $ | 89,788 |  |  | $ | 78,738 |  |

[0001437749-22-004080:notes:210]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  December 31, 2021 is as follows:

[0001437749-22-004080:notes:211]
| 2022 |  | $ | 21,210 |  |
| 2023 |  |  | 22,051 |  |
| 2024 |  |  | 19,282 |  |
| 2025 |  |  | 15,413 |  |
| After 2025 |  |  | 33,691 |  |
| Total |  | $ | 111,647 |  |

[0001437749-22-004080:notes:212]
The Company has a post-sale extended warranty marketing program with a third party. In the program’s agreement, the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. These fees are deferred and recorded as other assets in the consolidated balance sheets, and then amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. The balance of deferred contract costs as of  December 31, 2021 and 2020 was $8,479 and $6,869, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2021, 2020 and 2019 was $1,739, $1,303 and $869, respectively.

[0001437749-22-004080:notes:213]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-22-004080:notes:214]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 59,052 |  |  | $ | 37,417 |  |
| Long-term portion - other long-term liabilities |  |  | 35,161 |  |  |  | 21,801 |  |
| Total |  | $ | 94,213 |  |  | $ | 59,218 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,556 |  |  | $ | 18,857 |  |
| Long-term portion - other long-term liabilities |  |  | 91,091 |  |  |  | 70,931 |  |
| Total |  | $ | 111,647 |  |  | $ | 89,788 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-004080:notes:215]
| 12. | Credit Agreements |

[0001437749-22-004080:notes:216]
Short-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-22-004080:notes:217]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 72,035 |  |  |  | 39,282 |  |
| Total |  | $ | 72,035 |  |  | $ | 39,282 |  |

[0001437749-22-004080:notes:218]
As of  December 31, 2021 and 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-22-004080:notes:219]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-22-004080:notes:220]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,214 | ) |  |  | (15,450 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 39,175 |  |  |  | 27,371 |  |
| Other |  |  | 2,060 |  |  |  | 3,990 |  |
| Total |  |  | 908,020 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,721 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 4,209 |  |  |  | 2,311 |  |
| Total |  | $ | 902,091 |  |  | $ | 841,764 |  |

[0001437749-22-004080:notes:221]
Maturities of long-term borrowings outstanding at  December 31, 2021, excluding finance lease obligations as their maturities are disclosed in Note 10, “Leases,” and before considering original issue discount and deferred financing costs, are as follows:

[0001437749-22-004080:notes:222]
| 2022 |  | $ | 1,765 |  |
| 2023 |  |  | 59 |  |
| 2024 |  |  | 59 |  |
| 2025 |  |  | 92 |  |
| 2026 |  |  | 880,034 |  |
| After 2026 |  |  | 51 |  |
| Total |  | $ | 882,060 |  |

[0001437749-22-004080:notes:223]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

[0001437749-22-004080:notes:224]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally, the Company made a voluntary prepayment of $49,000 on the Term Loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:225]
In connection with our Term Loan amendment in  December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases.

[0001437749-22-004080:notes:226]
The Term Loan does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  December 31, 2021, the Company’s net secured leverage ratio was 0.88 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-22-004080:notes:227]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is currently  May 27, 2026. Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case subject to adjustments based upon average availability under the ABL Facility.

[0001437749-22-004080:notes:228]
In  May 2021, the Company amended the ABL Facility, increasing it from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings. At the same time, the Company also amended its Term Loan agreement to reflect the same amendments made to the ABL Facility.

[0001437749-22-004080:notes:229]
In connection with the ABL Facility amendment in  May 2021, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases.

[0001437749-22-004080:notes:230]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. As of  December 31, 2021, there was $100,000 outstanding under the ABL Facility, leaving $399,480 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-22-004080:notes:231]
| 13. | Stock Repurchase Programs |

[0001437749-22-004080:notes:232]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program, which expired in  October 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the year ended  December 31, 2021, the Company repurchased 350,000 shares of its common stock for $125,992, all funded with cash on hand. During the years ended  December 31, 2020 and 2019, the Company did not repurchase any shares of its common stock. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 9,026,706 shares of its common stock for $431,539 (at an average cost per share of $47.81), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-004080:notes:233]
| 14. | Earnings Per Share |

[0001437749-22-004080:notes:234]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-22-004080:notes:235]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-22-004080:notes:236]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 550,494 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (17,102 | ) |  |  | (1,247 | ) |  |  | 1,253 |  |
| Net income attributable to common shareholders |  | $ | 533,392 |  |  | $ | 349,329 |  |  | $ | 253,260 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,686,001 |  |  |  | 62,280,889 |  |  |  | 61,926,986 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,534,603 |  |  |  | 1,456,845 |  |  |  | 938,460 |  |
| Dilutive effect of contingently issued shares |  |  | 32,804 |  |  |  | - |  |  |  | - |  |
| Diluted shares |  |  | 64,253,408 |  |  |  | 63,737,734 |  |  |  | 62,865,446 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.51 |  |  | $ | 5.61 |  |  | $ | 4.09 |  |
| Diluted |  | $ | 8.30 |  |  | $ | 5.48 |  |  | $ | 4.03 |  |

[0001437749-22-004080:notes:237]
|  | (1) | There were no awards with an anti-dilutive impact for the years ended December 31, 2021, 2020 and 2019. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-004080:notes:238]
| 15. | Income Taxes |

[0001437749-22-004080:notes:239]
The Company’s provision for income taxes consists of the following:

[0001437749-22-004080:notes:240]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 105,236 |  |  | $ | 62,714 |  |  | $ | 41,686 |  |
| State |  |  | 21,295 |  |  |  | 13,071 |  |  |  | 4,211 |  |
| Foreign |  |  | 10,536 |  |  |  | 1,974 |  |  |  | 2,660 |  |
|  |  |  | 137,067 |  |  |  | 77,759 |  |  |  | 48,557 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 10,518 |  |  |  | 20,452 |  |  |  | 19,393 |  |
| State |  |  | (3,728 | ) |  |  | 1,243 |  |  |  | 1,390 |  |
| Foreign |  |  | (7,863 | ) |  |  | (1,197 | ) |  |  | (1,263 | ) |
|  |  |  | (1,073 | ) |  |  | 20,498 |  |  |  | 19,520 |  |
| Change in valuation allowance |  |  | (1,037 | ) |  |  | 716 |  |  |  | (778 | ) |
| Provision for income taxes |  | $ | 134,957 |  |  | $ | 98,973 |  |  | $ | 67,299 |  |

[0001437749-22-004080:notes:241]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2021, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2018. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2007 through 2020 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2009 through 2020.

[0001437749-22-004080:notes:242]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made, and could impact the Company’s financial results.

[0001437749-22-004080:notes:243]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-22-004080:notes:244]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 37,797 |  |  | $ | 24,358 |  |
| Deferred revenue |  |  | 27,003 |  |  |  | 15,851 |  |
| Inventories |  |  | 14,907 |  |  |  | 11,795 |  |
| Stock-based compensation |  |  | 10,202 |  |  |  | 8,348 |  |
| Operating loss and credit carryforwards |  |  | 68,368 |  |  |  | 31,275 |  |
| Bad debt |  |  | 1,253 |  |  |  | 1,633 |  |
| Other |  |  | 12,203 |  |  |  | 8,558 |  |
| Valuation allowance |  |  | (7,874 | ) |  |  | (5,740 | ) |
| Total deferred tax assets |  |  | 163,859 |  |  |  | 96,078 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 328,162 |  |  |  | 171,831 |  |
| Depreciation |  |  | 21,340 |  |  |  | 33,716 |  |
| Debt refinancing costs |  |  | 2,916 |  |  |  | 3,544 |  |
| Prepaid expenses |  |  | 1,664 |  |  |  | 1,259 |  |
| Total deferred tax liabilities |  |  | 354,082 |  |  |  | 210,350 |  |
| Net deferred tax liabilities |  | $ | (190,223 | ) |  | $ | (114,272 | ) |

[0001437749-22-004080:notes:245]
As of  December 31, 2021 and 2020, deferred tax assets of $15,740 and $1,497, and deferred tax liabilities of $205,964 and $115,769, respectively, were reflected on the consolidated balance sheets.

[0001437749-22-004080:notes:246]
The Company maintains a valuation allowance against the deferred tax assets when it is uncertain it will generate sufficient taxable income to utilize the asset. During 2021, the valuation allowance increased by $2,134 primarily due to foreign net operating losses which are unlikely to be utilized, partially offset by utilization of loss carryforwards in certain domestic and foreign subsidiaries.

[0001437749-22-004080:notes:247]
At  December 31, 2021, the Company had state manufacturing tax credit carryforwards of approximately $28,270, which expire between 2028 and 2035. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-22-004080:notes:248]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-22-004080:notes:249]
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 7,613 |  |  | $ | 6,720 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 272 |  |  |  | 332 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 990 |  |  |  | 750 |  |
| Statute of limitation expirations |  |  | (228 | ) |  |  | (189 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 8,647 |  |  | $ | 7,613 |  |

[0001437749-22-004080:notes:250]
The unrecognized tax benefit as of  December 31, 2021 and 2020, if recognized, would favorably impact the effective tax rate.

[0001437749-22-004080:notes:251]
As of  December 31, 2021 and 2020, total accrued interest of approximately $127 and $95, respectively, and accrued penalties of approximately $357 and $274, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-22-004080:notes:252]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending  December 31, 2022.

[0001437749-22-004080:notes:253]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended  December 31, 2021, 2020 and 2019 are as follows:

[0001437749-22-004080:notes:254]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 21.0 | % |
| State taxes |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 4.3 |  |
| State tax rate differential |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.0 | ) |
| Research and development credits |  |  | (1.0 | ) |  |  | (1.1 | ) |  |  | (0.8 | ) |
| State credits |  |  | (1.1 | ) |  |  | (1.5 | ) |  |  | (1.0 | ) |
| Share-based compensation |  |  | (3.8 | ) |  |  | (1.0 | ) |  |  | (0.6 | ) |
| Nondeductible U.S. compensation |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign tax deduction |  |  | (1.5 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign deferred tax rate change |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Other |  |  | (1.1 | ) |  |  | 0.5 |  |  |  | (0.8 | ) |
| Effective tax rate |  |  | 19.5 | % |  |  | 22.2 | % |  |  | 21.1 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-22-004080:notes:255]
| 16. | Benefit Plans |

[0001437749-22-004080:notes:256]
Medical and Dental Plans

[0001437749-22-004080:notes:257]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $24,189, $24,617, and $18,290 for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:258]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans and other local plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-22-004080:notes:259]
Savings Plan

[0001437749-22-004080:notes:260]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008 that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures  may be applied against plan expenses and Company contributions. The Company recognized $6,725, $5,332, and $4,791 of expense related to these plans for the years ended  December 31, 2021, 2020 and 2019, respectively.

[0001437749-22-004080:notes:261]
Pension Plans

[0001437749-22-004080:notes:262]
Historically, the Company maintained noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The Pension Plans were frozen effective  December 31, 2008. Effective  December 31, 2018, the Pension Plans were merged into the same plan (Pension Plan), resulting in no change to benefits for participants. The benefits under the salaried plan were based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan were based on a unit amount at the date of termination multiplied by the participant’s years of credited service.

[0001437749-22-004080:notes:263]
In 2019, the Company completed the termination of its Pension Plan.  In connection with the Company’s activities to terminate the plan, lump sum distributions were made in the fourth quarter of 2019 to individuals who elected lump sum distributions, including rolling over their accounts to the Company’s 401(k) savings plan. Also in the fourth quarter of 2019, annuity contracts were purchased to settle obligations for the remaining participants. Upon settlement of the pension liability, the Company reclassified related unrecognized pension losses recorded in AOCL to the consolidated statements of comprehensive income. As a result, the Company recorded pre-tax settlement charges of $10,920 in the fourth quarter of the year ended  December 31, 2019.

[0001437749-22-004080:notes:264]
Certain of the Company’s foreign subsidiaries participate in local statutory defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in other long-term liabilities in the Company’s consolidated balance sheets and are not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-22-004080:notes:265]
| 17. | Share Plans |

[0001437749-22-004080:notes:266]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010 in connection with its initial public offering. The 2010 Plan, as amended, allowed for granting of up to 9.1 million share-based awards to executives, directors and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Awards under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the 2010 Plan, net of estimated forfeitures, was $6,249, $11,681, and $15,738, for the years ended  December 31, 2021, 2020 and 2019, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:267]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). Following the effectiveness of the 2019 Plan, no new awards  may be made under the 2010 Plan. The 2019 Plan allows for granting of up to 2.7 million share-based awards to executives, directors and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $17,705, $9,201 and $956 for the years ended  December 31, 2021, 2020 and 2019, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:268]
Stock Options - Stock options granted in 2021 have an exercise price between $323.66 per share and $438.83 per share; stock options granted in 2020 have an exercise price between $91.00 per share and $158.89 per share; and stock options granted in 2019 have an exercise price of $52.07 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-22-004080:notes:269]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 8,608, 24,070, and 32,211 for the years ended  December 31, 2021, 2020 and 2019, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-22-004080:notes:270]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds from the cashless for cash exercise of stock options were $38,787, $13,089, and $9,395 for the years ended  December 31, 2021, 2020 and 2019, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-22-004080:notes:271]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $31,680, $7,297, and $3,360 for the years ended  December 31, 2021, 2020 and 2019, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-22-004080:notes:272]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history and are trued up upon vesting based on actual forfeiture activity.

[0001437749-22-004080:notes:273]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2021, 2020 and 2019 are as follows:

[0001437749-22-004080:notes:274]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Weighted average grant date fair value |  | $ | 129.47 |  |  | $ | 35.79 |  |  | $ | 19.33 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 37 | % |  |  | 32 | % |  |  | 33 | % |
| Risk free interest rate |  |  | 0.45 | % |  |  | 1.56 | % |  |  | 2.52 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-22-004080:notes:275]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2021, 2020 and 2019 is as follows:

[0001437749-22-004080:notes:276]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2018 |  |  | 1,521,167 |  |  | $ | 37.70 |  |  |  | 7.0 |  |  | $ | 19,212 |  |
| Granted |  |  | 369,779 |  |  |  | 52.07 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (263,250 | ) |  |  | 30.75 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (35,010 | ) |  |  | 43.79 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2019 |  |  | 1,592,686 |  |  |  | 42.04 |  |  |  | 6.9 |  |  | $ | 93,242 |  |
| Granted |  |  | 173,650 |  |  |  | 102.32 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (216,196 | ) |  |  | 39.88 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (21,450 | ) |  |  | 50.25 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2020 |  |  | 1,528,690 |  |  |  | 49.08 |  |  |  | 6.3 |  |  | $ | 272,553 |  |
| Granted |  |  | 70,392 |  |  |  | 335.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (229,921 | ) |  |  | 45.95 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (27,030 | ) |  |  | 63.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2021 |  |  | 1,342,131 |  |  |  | 64.29 |  |  |  | 5.5 |  |  | $ | 386,069 |  |
| Exercisable as of December 31, 2021 |  |  | 896,456 |  |  |  | 42.04 |  |  |  | 4.4 |  |  | $ | 277,794 |  |

[0001437749-22-004080:notes:277]
As of  December 31, 2021, there was $12,829 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.6 years. Total share-based compensation cost related to the stock options for the years ended  December 31, 2021, 2020 and 2019 was $6,462, $5,860, and $5,597, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:278]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2019 awards covers the years 2019 through 2021, the performance period for the 2020 awards covers the years 2020 through 2022, and the performance period for the 2021 awards covers the years 2021 through 2023. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures and is trued up upon vesting based on actual forfeiture activity.

[0001437749-22-004080:notes:279]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 80,583, 70,718, and 55,953 for the years ended  December 31, 2021, 2020 and 2019, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $27,223, $7,613, and $3,078 for the years ended  December 31, 2021, 2020 and 2019, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-22-004080:notes:280]
A summary of the Company's restricted stock activity for the years ended  December 31, 2021, 2020 and 2019 is as follows:

[0001437749-22-004080:notes:281]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2018 |  |  | 425,996 |  |  | $ | 40.50 |  |
| Granted |  |  | 265,255 |  |  |  | 62.38 |  |
| Vested |  |  | (184,628 | ) |  |  | 38.78 |  |
| Forfeited |  |  | (14,986 | ) |  |  | 44.23 |  |
| Non-vested as of December 31, 2019 |  |  | 491,637 |  |  |  | 52.84 |  |
| Granted |  |  | 183,868 |  |  |  | 95.14 |  |
| Vested |  |  | (200,390 | ) |  |  | 45.10 |  |
| Forfeited |  |  | (18,921 | ) |  |  | 56.58 |  |
| Non-vested as of December 31, 2020 |  |  | 456,194 |  |  |  | 68.42 |  |
| Granted |  |  | 126,339 |  |  |  | 223.09 |  |
| Vested |  |  | (202,327 | ) |  |  | 58.99 |  |
| Forfeited |  |  | (14,241 | ) |  |  | 138.64 |  |
| Non-vested as of December 31, 2021 |  |  | 365,965 |  |  |  | 124.25 |  |

[0001437749-22-004080:notes:282]
As of  December 31, 2021, there was $35,104 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.2 years. Total share-based compensation cost related to the restricted stock for the years ended  December 31, 2021, 2020 and 2019, inclusive of performance shares, was $17,492, $15,022, and $11,097, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-22-004080:notes:283]
During 2021, 2020 and 2019, 4,677, 15,275, and 22,544 shares of stock, respectively, were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company or a triggering event occurs. 3,160, 10,528, and 16,604 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board of Directors for the years 2021, 2020, and 2019, respectively. Total share-based compensation cost for these share grants in 2021, 2020 and 2019 was $1,579, $1,558, and $1,391, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-004080:notes:284]
| 18. | Commitments and Contingencies |

[0001437749-22-004080:notes:285]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  December 31, 2021 and 2020 was approximately $115,900 and $55,600, respectively.

[0001437749-22-004080:notes:286]
From time to time, we are involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of  December 31, 2021, the Company believes there are no legal proceedings pending that would have a material adverse effect on its results of operations or financial condition.

[0001437749-22-004080:notes:287]
Federal Securities Law Class Actions

[0001437749-22-004080:notes:288]
On  August 20, 2021 and  August 31, 2021, the Company and certain of its officers were named as defendants in two putative federal securities law class actions filed in the U.S. District Court for the Central District of California (the "Federal Securities Law Class Actions"). These actions were filed, respectively, under the captions Khami v. Generac Holdings Inc., et al., Case No. 2:21-cv-06777, and Procter v. Generac Holdings Inc., et al., Case No. 2:21-cv-07009. The Federal Securities Law Class Actions were transferred to the U.S. District Court for the Eastern District of Wisconsin, after which the court consolidated the actions under the caption In re Generac Holdings Securities Litigation, Case No. 21-cv-1342, and appointed a lead plaintiff. On  February 14, 2022, the lead plaintiff in the consolidated action filed a notice of voluntary dismissal, without prejudice. Should this party, or any other prospective plaintiff, file a new case on the same basis as the actions now dismissed, the Company would resume its vigorous defense against such claims, and, unless new or different claims were presented that the Company has not evaluated, the Company would continue to believe such actions would not have a material adverse effect on our results of operations or financial condition.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-22-004080:notes:289]
| 19. | Quarterly Financial Information (Unaudited) |

[0001437749-22-004080:notes:290]
|  |  | Quarters Ended 2021 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 807,434 |  |  | $ | 919,981 |  |  | $ | 942,698 |  |  | $ | 1,067,071 |  |
| Gross profit |  |  | 321,814 |  |  |  | 339,735 |  |  |  | 335,994 |  |  |  | 362,539 |  |
| Operating income |  |  | 189,124 |  |  |  | 182,952 |  |  |  | 173,579 |  |  |  | 175,481 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 148,993 |  |  |  | 127,036 |  |  |  | 131,570 |  |  |  | 142,895 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.39 |  |  | $ | 2.06 |  |  | $ | 1.98 |  |  | $ | 2.09 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.33 |  |  | $ | 2.01 |  |  | $ | 1.93 |  |  | $ | 2.04 |  |

[0001437749-22-004080:notes:291]
|  |  | Quarters Ended 2020 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 475,915 |  |  | $ | 546,848 |  |  | $ | 701,355 |  |  | $ | 761,082 |  |
| Gross profit |  |  | 172,320 |  |  |  | 208,983 |  |  |  | 276,149 |  |  |  | 300,202 |  |
| Operating income |  |  | 62,862 |  |  |  | 89,553 |  |  |  | 155,637 |  |  |  | 171,054 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 44,460 |  |  |  | 66,145 |  |  |  | 114,970 |  |  |  | 125,001 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.69 |  |  | $ | 1.04 |  |  | $ | 1.86 |  |  | $ | 2.02 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.68 |  |  | $ | 1.02 |  |  | $ | 1.82 |  |  | $ | 1.96 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-22-004080:notes:292]
| 20. | Valuation and Qualifying Accounts |

[0001437749-22-004080:notes:293]
For the years ended  December 31, 2021, 2020 and 2019:

[0001437749-22-004080:notes:294]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Additions Charged to Retained Earnings (1) |  |  | Charges to Reserve, Net (2) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,001 |  |  | $ | 206 |  |  | $ | - |  |  | $ | (1,640 | ) |  | $ | 1,458 |  |  | $ | 12,025 |  |
| Reserves for inventory |  |  | 27,817 |  |  |  | 17,698 |  |  |  | - |  |  |  | (15,749 | ) |  |  | 3,771 |  |  |  | 33,537 |  |
| Valuation of deferred tax assets |  |  | 5,740 |  |  |  | 1,404 |  |  |  | - |  |  |  | (2,441 | ) |  |  | 3,171 |  |  |  | 7,874 |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 6,968 |  |  | $ | 4,645 |  |  | $ | 1,147 |  |  | $ | (957 | ) |  | $ | 198 |  |  | $ | 12,001 |  |
| Reserves for inventory |  |  | 24,293 |  |  |  | 11,353 |  |  |  | - |  |  |  | (8,788 | ) |  |  | 959 |  |  |  | 27,817 |  |
| Valuation of deferred tax assets |  |  | 5,024 |  |  |  | 716 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5,740 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4,873 |  |  | $ | 3,086 |  |  | $ | - |  |  | $ | (1,033 | ) |  | $ | 42 |  |  | $ | 6,968 |  |
| Reserves for inventory |  |  | 23,140 |  |  |  | 4,821 |  |  |  | - |  |  |  | (3,867 | ) |  |  | 199 |  |  |  | 24,293 |  |
| Valuation of deferred tax assets |  |  | 5,802 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (778 | ) |  |  | 5,024 |  |

[0001437749-22-004080:notes:295]
|  | (1) | Result of adopting ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. |
|  | (2) | Deductions from the allowance for doubtful accounts equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-004080:notes:296]
| 21. | Subsequent Events |

[0001437749-22-004080:notes:297]
The Company performed an evaluation of subsequent events through the date these financial statements were issued and no such events were identified.
