# GNRC 8-K — 0001437749-16-030671 filed 2016-05-04

## item codes, every 8-K on or before 2016-05-06

- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2016-05-06

- none on or before 2016-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-030671:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-030671:8k_2_02:2]
ex99-1.htm

[0001437749-16-030671:8k_2_02:3]
Exhibit 99.1

[0001437749-16-030671:8k_2_02:4]
Generac Reports First Quarter 2016 Results

[0001437749-16-030671:8k_2_02:5]
WAUKESHA, WISCONSIN, (May 4, 2016) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its first quarter ended March 31, 2016.

[0001437749-16-030671:8k_2_02:6]
First Quarter 2016 Highlights

[0001437749-16-030671:8k_2_02:7]
| ● | Net sales were $286.5 million during the first quarter of 2016 as compared to $311.8 million in the prior-year first quarter, including $37.2 million of contribution from recent acquisitions. |

[0001437749-16-030671:8k_2_02:8]
|  | - | Residential product sales increased 1.4% to $159.0 million as compared to $156.8 million in the prior-year quarter, which was primarily due to the contributions from recent acquisitions, mostly offset by a decline in shipments of home standby generators. |

[0001437749-16-030671:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales were $103.0 million as compared to $133.8 million in the prior-year quarter, which was primarily due to a significant decline in shipments of mobile products into oil & gas and general rental markets, partially offset by the contribution from a recent acquisition. |

[0001437749-16-030671:8k_2_02:10]
| ● | Net income attributable to the Company during the first quarter of 2016 was $10.2 million, or $0.15 per share, as compared to $19.7 million, or $0.28 per share, for the same period of 2015. The current-year net income includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. |

[0001437749-16-030671:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $30.9 million, or $0.46 per share, as compared to $34.1 million, or $0.49 per share, in the first quarter of 2015. |

[0001437749-16-030671:8k_2_02:12]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $49.1 million as compared to $57.1 million in the first quarter last year. |

[0001437749-16-030671:8k_2_02:13]
| ● | Cash flow from operations was $22.2 million as compared to $25.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $15.1 million as compared to $18.7 million in the first quarter of 2015. |

[0001437749-16-030671:8k_2_02:14]
| ● | As previously announced, the Company on March 1, 2016 acquired a majority ownership interest of PR Industrial S.r.l and its subsidiaries (collectively Pramac), headquartered in Siena, Italy. With over 600 employees, four manufacturing plants and 14 commercial branches located around the world, Pramac is a leading global manufacturer of stationary, mobile and portable generators sold in over 150 countries through a broad distribution network. |

[0001437749-16-030671:8k_2_02:15]
“Shipments of residential products came in modestly ahead of our expectations benefitting from improved activations over the prior year,” said Aaron Jagdfeld, President and Chief Executive Officer. “This performance, along with better-than-expected shipments from recent acquisitions, helped to largely offset weaker sales of mobile products caused by low energy prices. As a result of the ongoing and significant downturn in capital spending within the oil & gas industry, we initiated a number of meaningful but necessary actions during the first quarter to better align our current cost structure with customer demand. Regarding the integration of our recent acquisitions, we’re working to realize some compelling revenue and cost synergies with Country Home Products and Pramac, as the addition of these companies diversifies our business further and significantly expands our international sales mix and geographic footprint.”

[0001437749-16-030671:8k_2_02:16]
Additional First Quarter 2016 Highlights

[0001437749-16-030671:8k_2_02:17]
Residential product sales for the first quarter were $159.0 million as compared to $156.8 million for the first quarter of 2015. The increase was due to a combination of contributions from recent acquisitions, mostly offset by a decline in shipments of home standby generators. Improvements in end user demand for home standby generators were more than offset by higher levels of backlog and lower levels of field inventory entering the first quarter of 2015 as compared to the first quarter of 2016.

[0001437749-16-030671:8k_2_02:18]
C&I product sales were $103.0 million as compared to $133.8 million for the comparable period in 2015. The decline was primarily due to a significant reduction in shipments of mobile products into oil & gas and general rental markets and, to a lesser extent, continued softness in Latin America markets. Partially offsetting these declines was the contribution from a recent acquisition.

[0001437749-16-030671:8k_2_02:19]
The first quarter of 2016 results include the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within costs of goods sold and $4.4 million classified within operating expenses.

[0001437749-16-030671:8k_2_02:20]
Gross profit margin was 34.2% compared to 32.9% in the prior-year first quarter, which includes the impact of the aforementioned $2.7 million of charges classified within cost of goods sold. Excluding the impact of these charges, gross profit margin was 35.2%, an improvement of 230 basis points over the prior year. The increase was primarily driven by favorable overall product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar in recent quarters. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current-year quarter.

[0001437749-16-030671:8k_2_02:21]
Operating expenses increased $13.4 million as compared to the first quarter of 2015, which includes the impact of the aforementioned $4.4 million of charges classified within operating expenses. Excluding the impact of these charges, operating expenses for the quarter increased $9.0 million, or 15.6%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with recent acquisitions, partially offset by reductions in certain organic selling, general and administrative expenses.

[0001437749-16-030671:8k_2_02:22]
2016 Outlook Update

[0001437749-16-030671:8k_2_02:23]
The Company is maintaining its prior guidance for the full-year 2016 in terms of revenue growth, adjusted EBITDA margins and cash flows. Net sales are still expected to increase between 10 to 12% as compared to the prior year.  Total organic sales on a constant currency basis are still anticipated to be down between 5 to 7%, with nearly all of the decline expected to be from ongoing weakness in mobile product shipments into the oil & gas and general rental markets. This top-line guidance assumes no material changes in the current macroeconomic environment and also assumes no improvement in power outage severity for the remainder of the year relative to the very low levels experienced during 2015.  Adjusted EBITDA margins are still expected to be approximately 20.0% for the full-year 2016, and free cash flow generation is expected to be strong, with the conversion of adjusted net income anticipated to be over 90%.

[0001437749-16-030671:8k_2_02:24]
“As we navigate through the soft macro demand environment in certain parts of our business in the near term, we are focused on several important strategic initiatives to drive our Powering Ahead plan forward,” continued Mr. Jagdfeld. “We remain optimistic regarding the several long-term growth opportunities that exist for our business, and we intend to leverage our strong liquidity position as we evaluate our priority uses of capital to increase shareholder value.”

[0001437749-16-030671:8k_2_02:25]
Conference Call and Webcast

[0001437749-16-030671:8k_2_02:26]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, May 4, 2016 to discuss highlights of the first quarter of 2016 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 88714564.

[0001437749-16-030671:8k_2_02:27]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-16-030671:8k_2_02:28]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 88714564. The telephonic replay will be available for 30 days.

[0001437749-16-030671:8k_2_02:29]
About Generac

[0001437749-16-030671:8k_2_02:30]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-030671:8k_2_02:31]
Forward-looking Information

[0001437749-16-030671:8k_2_02:32]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-16-030671:8k_2_02:33]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-16-030671:8k_2_02:34]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-16-030671:8k_2_02:35]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-16-030671:8k_2_02:36]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-16-030671:8k_2_02:37]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-16-030671:8k_2_02:38]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-16-030671:8k_2_02:39]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-16-030671:8k_2_02:40]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-16-030671:8k_2_02:41]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-16-030671:8k_2_02:42]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-16-030671:8k_2_02:43]
|  | ● | loss of key management and employees; |

[0001437749-16-030671:8k_2_02:44]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-16-030671:8k_2_02:45]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-030671:8k_2_02:46]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2015 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-030671:8k_2_02:47]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-16-030671:8k_2_02:48]
Reconciliations to GAAP Financial Metrics

[0001437749-16-030671:8k_2_02:49]
Adjusted EBITDA

[0001437749-16-030671:8k_2_02:50]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-030671:8k_2_02:51]
Adjusted Net Income

[0001437749-16-030671:8k_2_02:52]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses and adjusted net income attributable to non-controlling interests.

[0001437749-16-030671:8k_2_02:53]
Free Cash Flow

[0001437749-16-030671:8k_2_02:54]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-16-030671:8k_2_02:55]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-16-030671:8k_2_02:56]
SOURCE: Generac Holdings Inc.

[0001437749-16-030671:8k_2_02:57]
CONTACT:

[0001437749-16-030671:8k_2_02:58]
Michael W. Harris

[0001437749-16-030671:8k_2_02:59]
Vice President – Finance 
(262) 544-4811 x2675

[0001437749-16-030671:8k_2_02:60]
Michael.Harris@Generac.com

[0001437749-16-030671:8k_2_02:61]
4

[0001437749-16-030671:8k_2_02:62]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-16-030671:8k_2_02:63]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net sales |  | $ | 286,535 |  |  | $ | 311,818 |  |
| Costs of goods sold |  |  | 188,475 |  |  |  | 209,215 |  |
| Gross profit |  |  | 98,060 |  |  |  | 102,603 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 37,269 |  |  |  | 30,128 |  |
| Research and development |  |  | 8,197 |  |  |  | 8,163 |  |
| General and administrative |  |  | 17,833 |  |  |  | 14,206 |  |
| Amortization of intangibles |  |  | 7,797 |  |  |  | 5,195 |  |
| Total operating expenses |  |  | 71,096 |  |  |  | 57,692 |  |
| Income from operations |  |  | 26,964 |  |  |  | 44,911 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,035 | ) |  |  | (11,268 | ) |
| Investment income |  |  | 32 |  |  |  | 37 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (1,368 | ) |
| Costs related to acquisition |  |  | (417 | ) |  |  | – |  |
| Other, net |  |  | 387 |  |  |  | (1,609 | ) |
| Total other expense, net |  |  | (11,033 | ) |  |  | (14,208 | ) |
| Income before provision for income taxes |  |  | 15,931 |  |  |  | 30,703 |  |
| Provision for income taxes |  |  | 5,719 |  |  |  | 11,018 |  |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |
| Net income attributable to noncontrolling interests |  |  | 4 |  |  |  | – |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 0.15 |  |  | $ | 0.29 |  |
| Weighted average common shares outstanding - basic: |  |  | 66,099,755 |  |  |  | 68,806,337 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.15 |  |  | $ | 0.28 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,600,040 |  |  |  | 70,088,935 |  |
| Comprehensive income |  | $ | 11,454 |  |  | $ | 12,867 |  |

[0001437749-16-030671:8k_2_02:64]
5

[0001437749-16-030671:8k_2_02:65]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-16-030671:8k_2_02:66]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 69,370 |  |  | $ | 115,857 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 230,338 |  |  |  | 182,185 |  |
| Inventories |  |  | 374,709 |  |  |  | 325,375 |  |
| Prepaid expenses and other assets |  |  | 11,839 |  |  |  | 8,600 |  |
| Total current assets |  |  | 686,256 |  |  |  | 632,017 |  |
| Property and equipment, net |  |  | 197,623 |  |  |  | 184,213 |  |
| Customer lists, net |  |  | 59,928 |  |  |  | 39,313 |  |
| Patents, net |  |  | 57,002 |  |  |  | 53,772 |  |
| Other intangible assets, net |  |  | 3,733 |  |  |  | 2,768 |  |
| Tradenames, net |  |  | 164,340 |  |  |  | 161,057 |  |
| Goodwill |  |  | 723,443 |  |  |  | 669,719 |  |
| Deferred income taxes |  |  | 36,713 |  |  |  | 34,812 |  |
| Other assets |  |  | 4,459 |  |  |  | 964 |  |
| Total assets |  | $ | 1,933,497 |  |  | $ | 1,778,635 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 34,055 |  |  | $ | 8,594 |  |
| Accounts payable |  |  | 148,357 |  |  |  | 108,332 |  |
| Accrued wages and employee benefits |  |  | 21,367 |  |  |  | 13,101 |  |
| Other accrued liabilities |  |  | 87,716 |  |  |  | 82,540 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 10,975 |  |  |  | 657 |  |
| Total current liabilities |  |  | 302,470 |  |  |  | 213,224 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,047,146 |  |  |  | 1,037,132 |  |
| Deferred income taxes |  |  | 13,241 |  |  |  | 4,950 |  |
| Other long-term liabilities |  |  | 61,134 |  |  |  | 57,458 |  |
| Total liabilities |  |  | 1,423,991 |  |  |  | 1,312,764 |  |
| Redeemable noncontrolling interests |  |  | 35,047 |  |  |  | – |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,131,132 and 69,582,669 shares issued at March 31, 2016 and December 31, 2015, respectively |  |  | 701 |  |  |  | 696 |  |
| Additional paid-in capital |  |  | 440,886 |  |  |  | 443,109 |  |
| Treasury stock, at cost |  |  | (112,197 | ) |  |  | (111,516 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 368,381 |  |  |  | 358,173 |  |
| Accumulated other comprehensive loss |  |  | (21,229 | ) |  |  | (22,475 | ) |
| Stockholders' equity attributable to Generac Holdings, Inc. |  |  | 474,426 |  |  |  | 465,871 |  |
| Noncontrolling interests |  |  | 33 |  |  |  | – |  |
| Total stockholders’ equity |  |  | 474,459 |  |  |  | 465,871 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,933,497 |  |  | $ | 1,778,635 |  |

[0001437749-16-030671:8k_2_02:67]
6

[0001437749-16-030671:8k_2_02:68]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |

[0001437749-16-030671:8k_2_02:69]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,212 |  |  | $ | 19,685 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 4,996 |  |  |  | 3,839 |  |
| Amortization of intangible assets |  |  | 7,797 |  |  |  | 5,195 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,056 |  |  |  | 1,705 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,368 |  |
| Deferred income taxes |  |  | 5,069 |  |  |  | 3,182 |  |
| Share-based compensation expense |  |  | 2,485 |  |  |  | 2,508 |  |
| Other |  |  | 81 |  |  |  | 9 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,237 |  |  |  | 31,930 |  |
| Inventories |  |  | (10,752 | ) |  |  | (37,472 | ) |
| Other assets |  |  | (3,882 | ) |  |  | 255 |  |
| Accounts payable |  |  | (6,348 | ) |  |  | 2,619 |  |
| Accrued wages and employee benefits |  |  | 7,301 |  |  |  | (2,304 | ) |
| Other accrued liabilities |  |  | 2,628 |  |  |  | (456 | ) |
| Excess tax benefits from equity awards |  |  | (6,729 | ) |  |  | (6,806 | ) |
| Net cash provided by operating activities |  |  | 22,151 |  |  |  | 25,257 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 7 |  |  |  | 29 |  |
| Expenditures for property and equipment |  |  | (7,093 | ) |  |  | (6,528 | ) |
| Acquisition of business, net of cash acquired |  |  | (61,280 | ) |  |  | 374 |  |
| Net cash used in investing activities |  |  | (68,366 | ) |  |  | (6,125 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 8,508 |  |  |  | 4,000 |  |
| Repayments of short-term borrowings |  |  | (4,151 | ) |  |  | (6,256 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (46 | ) |  |  | (50,375 | ) |
| Cash dividends paid |  |  | (76 | ) |  |  | (1,427 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,070 | ) |  |  | (9,304 | ) |
| Excess tax benefits from equity awards |  |  | 6,729 |  |  |  | 6,806 |  |
| Net cash used in financing activities |  |  | (1,106 | ) |  |  | (56,556 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 834 |  |  |  | (2,252 | ) |
| Net decrease in cash and cash equivalents |  |  | (46,487 | ) |  |  | (39,676 | ) |
| Cash and cash equivalents at beginning of period |  |  | 115,857 |  |  |  | 189,761 |  |
| Cash and cash equivalents at end of period |  | $ | 69,370 |  |  | $ | 150,085 |  |

[0001437749-16-030671:8k_2_02:70]
7

[0001437749-16-030671:8k_2_02:71]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| Net income to Adjusted EBITDA reconciliation |

[0001437749-16-030671:8k_2_02:72]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 4 |  |  |  | - |  |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |
| Interest expense |  |  | 11,035 |  |  |  | 11,268 |  |
| Depreciation and amortization |  |  | 12,793 |  |  |  | 9,034 |  |
| Income taxes provision |  |  | 5,719 |  |  |  | 11,018 |  |
| Non-cash write-down and other adjustments (2) |  |  | (127 | ) |  |  | 1,572 |  |
| Non-cash share-based compensation expense (3) |  |  | 2,485 |  |  |  | 2,508 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | 1,368 |  |
| Transaction costs and credit facility fees (5) |  |  | 523 |  |  |  | 201 |  |
| Business optimization expenses (6) |  |  | 7,106 |  |  |  | – |  |
| Other |  |  | 63 |  |  |  | 484 |  |
| Adjusted EBITDA |  |  | 49,809 |  |  |  | 57,138 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 684 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 49,125 |  |  | $ | 57,138 |  |

[0001437749-16-030671:8k_2_02:73]
| (1) Includes the noncontrolling interests' share of $1.2 million of expenses related to Pramac purchase accounting adjustments, including the step-up in value of inventories and intangible amortization. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (6) Represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.684 million classified within cost of goods sold and $4.422 million classified within operating expenses. |

[0001437749-16-030671:8k_2_02:74]
8

[0001437749-16-030671:8k_2_02:75]
| Net income to Adjusted net income reconciliation |

[0001437749-16-030671:8k_2_02:76]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 4 |  |  |  | - |  |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |
| Provision for income taxes |  |  | 5,719 |  |  |  | 11,018 |  |
| Income before provision for income taxes |  |  | 15,931 |  |  |  | 30,703 |  |
| Amortization of intangible assets |  |  | 7,797 |  |  |  | 5,195 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,056 |  |  |  | 1,705 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | 1,368 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 1,247 |  |  |  | 263 |  |
| Business optimization expenses (6) |  |  | 7,106 |  |  |  | – |  |
| Adjusted net income before provision for income taxes |  |  | 33,137 |  |  |  | 39,234 |  |
| Cash income tax expense (8) |  |  | (1,820 | ) |  |  | (5,115 | ) |
| Adjusted net income |  |  | 31,317 |  |  |  | 34,119 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 430 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 30,887 |  |  | $ | 34,119 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.46 |  |  | $ | 0.49 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,600,040 |  |  |  | 70,088,935 |  |

[0001437749-16-030671:8k_2_02:77]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (8) Amount for the three months ended March 31, 2016 is based on an anticipated cash income tax rate of approximately 9% for the full year ended 2016. Amount for the three months ended March 31, 2015 is based on an anticipated cash income tax rate of approximately 17% for the full year ended 2015. |

[0001437749-16-030671:8k_2_02:78]
| Free Cash Flow Reconciliation |

[0001437749-16-030671:8k_2_02:79]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 22,151 |  |  | $ | 25,257 |  |
| Expenditures for property and equipment |  |  | (7,093 | ) |  |  | (6,528 | ) |
| Free cash flow |  | $ | 15,058 |  |  | $ | 18,729 |  |

[0001437749-16-030671:8k_2_02:80]
9
