# GNRC MD&A — 0001437749-16-031130


## mdna

[0001437749-16-031130:mdna:1]
[same as prior period, unchanged from 0001437749-15-020022:mdna:1]

[0001437749-16-031130:mdna:2]
[same as prior period, unchanged from 0001437749-15-020022:mdna:2]

[0001437749-16-031130:mdna:3]
[same as prior period, unchanged from 0001437749-15-020022:mdna:3]

[0001437749-16-031130:mdna:4]
[same as prior period, unchanged from 0001437749-15-020022:mdna:4]

[0001437749-16-031130:mdna:5]
[same as prior period, unchanged from 0001437749-15-020022:mdna:5]

[0001437749-16-031130:mdna:6]
[same as prior period, unchanged from 0001437749-15-020022:mdna:6]

[0001437749-16-031130:mdna:7]
[same as prior period, unchanged from 0001437749-15-020022:mdna:7]

[0001437749-16-031130:mdna:8]
[same as prior period, unchanged from 0001437749-15-020022:mdna:8]

[0001437749-16-031130:mdna:9]
[same as prior period, unchanged from 0001437749-15-020022:mdna:9]

[0001437749-16-031130:mdna:10]
[same as prior period, unchanged from 0001437749-15-020022:mdna:10]

[0001437749-16-031130:mdna:11]
[same as prior period, unchanged from 0001437749-15-020022:mdna:11]

[0001437749-16-031130:mdna:12]
[same as prior period, unchanged from 0001437749-15-020022:mdna:12]

[0001437749-16-031130:mdna:13]
[same as prior period, unchanged from 0001437749-15-020022:mdna:13]

[0001437749-16-031130:mdna:14]
[same as prior period, unchanged from 0001437749-15-020022:mdna:14]

[0001437749-16-031130:mdna:15]
[same as prior period, unchanged from 0001437749-15-020022:mdna:15]

[0001437749-16-031130:mdna:16]
[same as prior period, unchanged from 0001437749-15-020022:mdna:16]

[0001437749-16-031130:mdna:17]
[same as prior period, unchanged from 0001437749-15-020022:mdna:17]

[0001437749-16-031130:mdna:18]
[same as prior period, unchanged from 0001437749-15-020022:mdna:18]

[0001437749-16-031130:mdna:19]
[same as prior period, unchanged from 0001437749-15-020022:mdna:19]

[0001437749-16-031130:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2015. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-031130:mdna:21]
[same as prior period, unchanged from 0001437749-15-020022:mdna:21]

[0001437749-16-031130:mdna:22]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas, and construction markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside the power equipment market. As the only significant market participant focused predominantly on these products, we are a market leader in the power equipment market in North America and have an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-16-031130:mdna:23]
Over the past several years, we have executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q.

[0001437749-16-031130:mdna:24]
[same as prior period, unchanged from 0001437749-15-020022:mdna:24]

[0001437749-16-031130:mdna:25]
[same as prior period, unchanged from 0001437749-15-020022:mdna:25]

[0001437749-16-031130:mdna:26]
[same as prior period, unchanged from 0001437749-15-020022:mdna:26]

[0001437749-16-031130:mdna:27]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-16-031130:mdna:28]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2013 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. In addition, the importance of backup power for telecommunications infrastructure is increasing due to the growing importance for uninterrupted voice and data services. Also, in recent years, a more stringent regulatory environment around the flaring of natural gas at oil & gas drilling and production sites has been a catalyst for increased demand for natural gas fueled generators, including mobile solutions. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-16-031130:mdna:29]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the multiple major outage events that occurred during the second half of both 2011 and 2012 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to substantial organic revenue growth in 2012 with strong growth continuing during 2013. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-16-031130:mdna:30]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-16-031130:mdna:31]
Impact of business capital investment cycle.   The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions and credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-16-031130:mdna:32]
[same as prior period, unchanged from 0001437749-15-020022:mdna:32]

[0001437749-16-031130:mdna:33]
[same as prior period, unchanged from 0001437749-15-020022:mdna:33]

[0001437749-16-031130:mdna:34]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum and other components we use in our products, together with foreign currency fluctuations, can have a material impact on our results of operations. We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-16-031130:mdna:35]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 23% to 27% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 28% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period, and for the subsequent quarters following the time period, varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-16-031130:mdna:36]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense decreased during the three months ended March 31, 2016 compared to the three months ended March 31, 2015, primarily due to voluntary prepayments of Term Loan principal and the lower interest rate on our ABL Facility borrowings. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q for further information.

[0001437749-16-031130:mdna:37]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $715 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2015 related to our acquisition by CCMP in 2006 that we expect to generate aggregate cash tax savings of approximately $279 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $42.0 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2015. We expect these assets to generate aggregate cash tax savings of $16.4 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-16-031130:mdna:38]
[same as prior period, unchanged from 0001437749-15-020022:mdna:38]

[0001437749-16-031130:mdna:39]
Three months ended March 31, 2016 compared to three months ended March 31, 2015

[0001437749-16-031130:mdna:40]
[same as prior period, unchanged from 0001437749-15-020022:mdna:40]

[0001437749-16-031130:mdna:41]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 286,535 |  |  | $ | 311,818 |  |  | $ | (25,283 | ) |  |  | -8.1 | % |
| Cost of goods sold |  |  | 188,475 |  |  |  | 209,215 |  |  |  | (20,740 | ) |  |  | -9.9 | % |
| Gross profit |  |  | 98,060 |  |  |  | 102,603 |  |  |  | (4,543 | ) |  |  | -4.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 37,269 |  |  |  | 30,128 |  |  |  | 7,141 |  |  |  | 23.7 | % |
| Research and development |  |  | 8,197 |  |  |  | 8,163 |  |  |  | 34 |  |  |  | 0.4 | % |
| General and administrative |  |  | 17,833 |  |  |  | 14,206 |  |  |  | 3,627 |  |  |  | 25.5 | % |
| Amortization of intangible assets |  |  | 7,797 |  |  |  | 5,195 |  |  |  | 2,602 |  |  |  | 50.1 | % |
| Total operating expenses |  |  | 71,096 |  |  |  | 57,692 |  |  |  | 13,404 |  |  |  | 23.2 | % |
| Income from operations |  |  | 26,964 |  |  |  | 44,911 |  |  |  | (17,947 | ) |  |  | -40.0 | % |
| Total other income (expense), net |  |  | (11,033 | ) |  |  | (14,208 | ) |  |  | 3,175 |  |  |  | -22.3 | % |
| Income before provision for income taxes |  |  | 15,931 |  |  |  | 30,703 |  |  |  | (14,772 | ) |  |  | -48.1 | % |
| Provision for income taxes |  |  | 5,719 |  |  |  | 11,018 |  |  |  | (5,299 | ) |  |  | -48.1 | % |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |  |  | (9,473 | ) |  |  | -48.1 | % |
| Net income attributable to noncontrolling interests |  |  | 4 |  |  |  | - |  |  |  | 4 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |  |  | (9,477 | ) |  |  | -48.1 | % |
| Residential power products |  | $ | 158,980 |  |  | $ | 156,835 |  |  |  | 2,145 |  |  |  | 1.4 | % |
| Commercial & industrial power products |  |  | 102,991 |  |  |  | 133,763 |  |  |  | (30,772 | ) |  |  | -23.0 | % |
| Other |  |  | 24,564 |  |  |  | 21,220 |  |  |  | 3,344 |  |  |  | 15.8 | % |
| Net sales |  | $ | 286,535 |  |  | $ | 311,818 |  |  |  | (25,283 | ) |  |  | -8.1 | % |

[0001437749-16-031130:mdna:42]
Net sales.    The increase in residential product sales was due to a combination of contributions from recent acquisitions, mostly offset by a decline in shipments of home standby generators. Improvements in end user demand for home standby generators were more than offset by higher levels of backlog and lower levels of field inventory entering the first quarter of 2015 as compared to the first quarter of 2016. The decrease in commercial and industrial (C&I) product sales was primarily due to a significant reduction in shipments of mobile products into oil & gas and general rental markets and, to a lesser extent, continued softness in Latin American markets. Partially offsetting these declines was the contribution from a recent acquisition. The contribution from non-annualized recent acquisitions to the three months ended March 31, 2016 was $37.2 million.

[0001437749-16-031130:mdna:43]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write-downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses.

[0001437749-16-031130:mdna:44]
Gross profit.    Gross profit margin for the first quarter of 2016 was 34.2% compared to 32.9% in the prior-year first quarter, which includes the impact of the aforementioned $2.7 million of charges classified within cost of goods sold. Excluding the impact of these charges, gross profit margin was 35.2%, an improvement of 230 basis points over the prior year. The increase was primarily driven by favorable overall product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar in recent quarters. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current year quarter.

[0001437749-16-031130:mdna:45]
Operating expenses.    Excluding the impact of the aforementioned $4.4 million of charges classified within operating expenses, operating expenses increased $9.0 million, or 15.6%, as compared to the prior year. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions, partially offset by reductions in certain organic selling, general and administrative expenses.

[0001437749-16-031130:mdna:46]
Other expense.    The decrease in other expense was primarily due to a prior year non-cash $1.4 million loss on extinguishment of debt, which was the result of a $50 million voluntary prepayment of Term Loan debt.

[0001437749-16-031130:mdna:47]
Provision for income taxes.   The effective income tax rates for the three months ended March 31, 2016 and 2015 were 35.9%.

[0001437749-16-031130:mdna:48]
Adjusted EBITDA.    Adjusted EBITDA decreased $8.0 million or 14.0%, to $49.1 million for the three months ended March 31, 2016 from $57.1 million for the three months ended March 31, 2015, due to the factors outlined above.

[0001437749-16-031130:mdna:49]
Adjusted Net Income.    Adjusted Net Income of $30.9 million for the three months ended March 31, 2016 decreased 8.2% from $34.1 million for the three months ended March 31, 2015, due to the factors outlined above partially offset by a decrease in cash income tax expense.

[0001437749-16-031130:mdna:50]
[same as prior period, unchanged from 0001437749-15-020022:mdna:55]

[0001437749-16-031130:mdna:51]
[same as prior period, unchanged from 0001437749-15-020022:mdna:56]

[0001437749-16-031130:mdna:52]
[same as prior period, unchanged from 0001437749-15-020022:mdna:57]

[0001437749-16-031130:mdna:53]
The Company’s credit agreements provide for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of March 31, 2016 was above 3.00 to 1.00. As of March 31, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-031130:mdna:54]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, which was used as a voluntary prepayment of Term Loan borrowings. As of March 31, 2016, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all of its covenants.

[0001437749-16-031130:mdna:55]
[same as prior period, unchanged from 0001437749-15-020022:mdna:60]

[0001437749-16-031130:mdna:56]
At March 31, 2016, we had cash and cash equivalents on hand of $69.4 million and $148.5 million of availability under our revolving ABL credit facility, net of outstanding letters of credit.

[0001437749-16-031130:mdna:57]
In August 2015, the Company’s Board of Directors approved a $200.0 million stock repurchase program. Under the program, the Company may repurchase up to $200.0 million of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand or available borrowings. The stock repurchase program may be suspended or discontinued at any time without prior notice. There were no common stock repurchases in the three months ended March 31, 2016. Since the inception of the program, the Company has repurchased 3,303,500 shares of its common stock for $99.9 million, funded with cash on hand.

[0001437749-16-031130:mdna:58]
[same as prior period, unchanged from 0001437749-15-020022:mdna:64]

[0001437749-16-031130:mdna:59]
[same as prior period, unchanged from 0001437749-15-020022:mdna:65]

[0001437749-16-031130:mdna:60]
[same as prior period, unchanged from 0001437749-15-020022:mdna:66]

[0001437749-16-031130:mdna:61]
Three months ended March 31, 2016 compared to three months ended March 31, 2015

[0001437749-16-031130:mdna:62]
[same as prior period, unchanged from 0001437749-15-020022:mdna:68]

[0001437749-16-031130:mdna:63]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 22,151 |  |  | $ | 25,257 |  |  | $ | (3,106 | ) |  |  | -12.3 | % |
| Net cash used in investing activities |  |  | (68,366 | ) |  |  | (6,125 | ) |  |  | (62,241 | ) |  |  | 1016.2 | % |
| Net cash used in financing activities |  |  | (1,106 | ) |  |  | (56,556 | ) |  |  | 55,450 |  |  |  | -98.0 | % |

[0001437749-16-031130:mdna:64]
The decrease in net cash provided by operating activities was primarily the result of lower operating earnings during the current year partially offset by a lower working capital investment as compared to the prior year period.

[0001437749-16-031130:mdna:65]
The increase in net cash used in investing activities was primarily due to cash payments of $61.3 million related to the acquisition of Pramac in the first quarter of 2016.

[0001437749-16-031130:mdna:66]
Net cash used in financing activities for the three months ended March 31, 2016 primarily represents payments of $12.1 million related to the net share settlement of equity awards and $4.2 million for the repayment of short-term borrowings. These payments were partially offset by $8.5 million cash proceeds from short-term borrowings and a $6.7 million cash inflow related to excess tax benefits of equity awards.

[0001437749-16-031130:mdna:67]
Net cash used in financing activities for the three months ended March 31, 2015 primarily represents $56.6 million of debt repayments ($50.4 million of long-term borrowings and $6.2 million of short-term borrowings) partially offset by $4.0 million cash proceeds from short-term borrowings. In addition, the Company paid $9.3 million related to the net share settlement of equity awards which was partially offset by $6.8 million of cash inflow related to the excess tax benefits of equity awards.

[0001437749-16-031130:mdna:68]
[same as prior period, unchanged from 0001437749-15-020022:mdna:74]

[0001437749-16-031130:mdna:69]
In connection with the Pramac acquisition on March 1, 2016, the Company assumed $21.1 million of short-term borrowings and $19.2 million of long-term debt and capital lease obligations. Refer to Note 2, “Acquisitions” to the condensed consolidated financial statements for further information. Other than the assumption of the Pramac debt, there have been no material changes to our contractual obligations since the February 26, 2016 filing of our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-031130:mdna:70]
[same as prior period, unchanged from 0001437749-15-020022:mdna:76]

[0001437749-16-031130:mdna:71]
There have been no material changes to off-balance sheet arrangements since the February 26, 2016 filing of our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-031130:mdna:72]
[same as prior period, unchanged from 0001437749-15-020022:mdna:78]

[0001437749-16-031130:mdna:73]
There have been no material changes in our critical accounting policies since the February 26, 2016 filing of our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-031130:mdna:74]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2015, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; income taxes and share based compensation.

[0001437749-16-031130:mdna:75]
[same as prior period, unchanged from 0001437749-15-020022:mdna:81]

[0001437749-16-031130:mdna:76]
[same as prior period, unchanged from 0001437749-15-020022:mdna:82]

[0001437749-16-031130:mdna:77]
[same as prior period, unchanged from 0001437749-15-020022:mdna:83]

[0001437749-16-031130:mdna:78]
[same as prior period, unchanged from 0001437749-15-020022:mdna:84]

[0001437749-16-031130:mdna:79]
[same as prior period, unchanged from 0001437749-15-020022:mdna:85]

[0001437749-16-031130:mdna:80]
[same as prior period, unchanged from 0001437749-15-020022:mdna:86]

[0001437749-16-031130:mdna:81]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2016 proxy statement; |

[0001437749-16-031130:mdna:82]
[same as prior period, unchanged from 0001437749-15-020022:mdna:88]

[0001437749-16-031130:mdna:83]
[same as prior period, unchanged from 0001437749-15-020022:mdna:89]

[0001437749-16-031130:mdna:84]
[same as prior period, unchanged from 0001437749-15-020022:mdna:90]

[0001437749-16-031130:mdna:85]
[same as prior period, unchanged from 0001437749-15-020022:mdna:91]

[0001437749-16-031130:mdna:86]
[same as prior period, unchanged from 0001437749-15-020022:mdna:92]

[0001437749-16-031130:mdna:87]
[same as prior period, unchanged from 0001437749-15-020022:mdna:93]

[0001437749-16-031130:mdna:88]
[same as prior period, unchanged from 0001437749-15-020022:mdna:94]

[0001437749-16-031130:mdna:89]
[same as prior period, unchanged from 0001437749-15-020022:mdna:95]

[0001437749-16-031130:mdna:90]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-16-031130:mdna:91]
[same as prior period, unchanged from 0001437749-15-020022:mdna:97]

[0001437749-16-031130:mdna:92]
[same as prior period, unchanged from 0001437749-15-020022:mdna:98]

[0001437749-16-031130:mdna:93]
[same as prior period, unchanged from 0001437749-15-020022:mdna:99]

[0001437749-16-031130:mdna:94]
[same as prior period, unchanged from 0001437749-15-020022:mdna:100]

[0001437749-16-031130:mdna:95]
[same as prior period, unchanged from 0001437749-15-020022:mdna:101]

[0001437749-16-031130:mdna:96]
[same as prior period, unchanged from 0001437749-15-020022:mdna:102]

[0001437749-16-031130:mdna:97]
[same as prior period, unchanged from 0001437749-15-020022:mdna:103]

[0001437749-16-031130:mdna:98]
[same as prior period, unchanged from 0001437749-15-020022:mdna:104]

[0001437749-16-031130:mdna:99]
[same as prior period, unchanged from 0001437749-15-020022:mdna:105]

[0001437749-16-031130:mdna:100]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-16-031130:mdna:101]
[same as prior period, unchanged from 0001437749-15-020022:mdna:107]

[0001437749-16-031130:mdna:102]
[same as prior period, unchanged from 0001437749-15-020022:mdna:108]

[0001437749-16-031130:mdna:103]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Net income attributable to noncontrolling interests (a) |  |  | 4 |  |  |  | - |  |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |
| Interest expense |  |  | 11,035 |  |  |  | 11,268 |  |
| Depreciation and amortization |  |  | 12,793 |  |  |  | 9,034 |  |
| Provision for income taxes |  |  | 5,719 |  |  |  | 11,018 |  |
| Non-cash write-down and other adjustments (b) |  |  | (127 | ) |  |  | 1,572 |  |
| Non-cash share-based compensation expense (c) |  |  | 2,485 |  |  |  | 2,508 |  |
| Loss on extinguishment of debt (d) |  |  | - |  |  |  | 1,368 |  |
| Transaction costs and credit facility fees (e) |  |  | 523 |  |  |  | 201 |  |
| Business optimization expenses (f) |  |  | 7,106 |  |  |  | - |  |
| Other |  |  | 63 |  |  |  | 484 |  |
| Adjusted EBITDA |  |  | 49,809 |  |  |  | 57,138 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 684 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 49,125 |  |  | $ | 57,138 |  |

[0001437749-16-031130:mdna:104]
(a)   Includes the noncontrolling interests’ share of $1.2 million of expenses related to Pramac purchase accounting adjustments, including the step-up in value of inventories and intangible amortization.

[0001437749-16-031130:mdna:105]
(b)   Represents the following non-cash charges for the three months ended March 31, 2016 and 2015: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments.

[0001437749-16-031130:mdna:106]
[same as prior period, unchanged from 0001437749-15-020022:mdna:111]

[0001437749-16-031130:mdna:107]
|  | ● | The gains/losses on disposals of assets described above result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-16-031130:mdna:108]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and |

[0001437749-16-031130:mdna:109]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. |

[0001437749-16-031130:mdna:110]
(c)   Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their vesting period.

[0001437749-16-031130:mdna:111]
(d)   Represents the non-cash write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment.

[0001437749-16-031130:mdna:112]
(e)   Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and revolving credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-16-031130:mdna:113]
(f)    Represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, and therefore do not reflect our ongoing operations.

[0001437749-16-031130:mdna:114]
[same as prior period, unchanged from 0001437749-15-020022:mdna:121]

[0001437749-16-031130:mdna:115]
Adjusted Net Income is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-16-031130:mdna:116]
[same as prior period, unchanged from 0001437749-15-020022:mdna:123]

[0001437749-16-031130:mdna:117]
[same as prior period, unchanged from 0001437749-15-020022:mdna:124]

[0001437749-16-031130:mdna:118]
[same as prior period, unchanged from 0001437749-15-020022:mdna:125]

[0001437749-16-031130:mdna:119]
[same as prior period, unchanged from 0001437749-15-020022:mdna:126]

[0001437749-16-031130:mdna:120]
[same as prior period, unchanged from 0001437749-15-020022:mdna:127]

[0001437749-16-031130:mdna:121]
[same as prior period, unchanged from 0001437749-15-020022:mdna:128]

[0001437749-16-031130:mdna:122]
The following table presents a reconciliation of net income to Adjusted Net Income:

[0001437749-16-031130:mdna:123]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Net income attributable to noncontrolling interests |  |  | 4 |  |  |  | - |  |
| Net income |  |  | 10,212 |  |  |  | 19,685 |  |
| Provision for income taxes |  |  | 5,719 |  |  |  | 11,018 |  |
| Income before provision for income taxes |  |  | 15,931 |  |  |  | 30,703 |  |
| Amortization of intangible assets |  |  | 7,797 |  |  |  | 5,195 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,056 |  |  |  | 1,705 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,368 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 1,247 |  |  |  | 263 |  |
| Business optimization expenses |  |  | 7,106 |  |  |  | - |  |
| Adjusted net income before provision for income taxes |  |  | 33,137 |  |  |  | 39,234 |  |
| Cash income tax expense (b) |  |  | (1,820 | ) |  |  | (5,115 | ) |
| Adjusted net income |  |  | 31,317 |  |  |  | 34,119 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 430 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 30,887 |  |  | $ | 34,119 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.46 |  |  | $ | 0.49 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,600,040 |  |  |  | 70,088,935 |  |

[0001437749-16-031130:mdna:124]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-16-031130:mdna:125]
(b) Amount for the three months ended March 31, 2016 is based on an anticipated cash income tax rate of approximately 9% for the full year-ended 2016. Amount for the three months ended March 31, 2015 is based on an anticipated cash income tax rate of approximately 17% for the full year-ended 2015.

[0001437749-16-031130:mdna:126]
[same as prior period, unchanged from 0001437749-15-020022:mdna:132]

[0001437749-16-031130:mdna:127]
[same as prior period, unchanged from 0001437749-15-020022:mdna:133]
