# GNRC notes — 0001437749-16-031130


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-16-031130:notes:1]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 23,433 |  |  | $ | 21,726 |  |
| Long-term portion - other long-term liabilities |  |  | 8,471 |  |  |  | 8,471 |  |
| Total |  | $ | 31,904 |  |  | $ | 30,197 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 5,189 |  |  | $ | 6,026 |  |
| Long-term portion - other long-term liabilities |  |  | 23,641 |  |  |  | 22,935 |  |
| Total |  | $ | 28,830 |  |  | $ | 28,961 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-16-031130:notes:2]
|  |  | March 31,2016 |  |  | December 31,2015 |  |
| Commodity contracts |  | $ | 5 |  |  | $ | (400 | ) |
| Foreign currency contracts |  |  | (177 | ) |  |  | (171 | ) |
| Interest rate swaps |  |  | (4,514 | ) |  |  | (2,618 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-16-031130:notes:3]
[same as prior period, unchanged from 0001437749-15-020022:notes:3]

[0001437749-16-031130:notes:4]
Acquisition of Pramac

[0001437749-16-031130:notes:5]
On March 1, 2016, a subsidiary of the Company acquired a 65% ownership interest in Pramac for a purchase price, net of cash acquired, of $61,280. Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand. The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the March 31, 2016 condensed consolidated balance sheet, as the noncontrolling interest party has within its control the right to require the Company to redeem its interest in Pramac.

[0001437749-16-031130:notes:6]
The Company recorded a preliminary purchase price allocation during the first quarter of 2016 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The preliminary purchase price allocation was as follows:

[0001437749-16-031130:notes:7]
|  |  | March 1, 2016 |  |
| Accounts receivable, net |  | $ | 56,756 |  |
| Inventories |  |  | 38,902 |  |
| Property and equipment, net |  |  | 11,425 |  |
| Intangible assets |  |  | 35,884 |  |
| Goodwill |  |  | 53,724 |  |
| Other assets |  |  | 4,829 |  |
| Total assets acquired |  |  | 201,520 |  |
| Short-term borrowings |  |  | 21,104 |  |
| Accounts payable |  |  | 46,392 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 19,244 |  |
| Other liabilities |  |  | 19,194 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 61,280 |  |

[0001437749-16-031130:notes:8]
The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through March 31, 2016.

[0001437749-16-031130:notes:9]
[same as prior period, unchanged from 0001437749-15-020022:notes:4]

[0001437749-16-031130:notes:10]
On August 1, 2015, a subsidiary of the Company acquired CHP for a purchase price, net of cash acquired, of $74,570. Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition purchase price was funded solely through cash on hand.

[0001437749-16-031130:notes:11]
The Company recorded a preliminary purchase price allocation during the third quarter of 2015 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $81,726 of intangible assets, including approximately $30,076 of goodwill, as of the acquisition date. The purchase price allocation was finalized in the fourth quarter of 2015, resulting in a $6,552 decrease to total intangible assets, including an increase of $6,208 in goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. In addition, the Company assumed $12,000 of CHP’s debt in conjunction with this acquisition. The accompanying condensed consolidated financial statements include the results of CHP from the date of acquisition through March 31, 2016.

[0001437749-16-031130:notes:12]
The following unaudited pro forma information of the Company gives effect to these acquisitions as though the transactions had occurred on January 1, 2015. Consolidated net sales on a pro forma basis for the three month periods ended March 31, 2016 and 2015 were $315,882 and $374,511, respectively. The pro forma impact of these acquisitions on net income and earnings per share is not significant due to amortization related to acquired intangible assets and the fair value step-up of inventory in purchase accounting. This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actuallywould have been achieved had the acquisitions been consummated  on January 1, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-16-031130:notes:13]
[same as prior period, unchanged from 0001437749-15-020022:notes:10]

[0001437749-16-031130:notes:14]
[same as prior period, unchanged from 0001437749-15-020022:notes:11]

[0001437749-16-031130:notes:15]
[same as prior period, unchanged from 0001437749-15-020022:notes:12]

[0001437749-16-031130:notes:16]
[same as prior period, unchanged from 0001437749-15-020022:notes:13]

[0001437749-16-031130:notes:17]
The Company has executed a number of acquisitions that support our strategic plan (as discussed in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2015). A summary of these acquisitions include the following:

[0001437749-16-031130:notes:18]
[same as prior period, unchanged from 0001437749-15-020022:notes:15]

[0001437749-16-031130:notes:19]
[same as prior period, unchanged from 0001437749-15-020022:notes:16]

[0001437749-16-031130:notes:20]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East, Africa and Asia Pacific. |

[0001437749-16-031130:notes:21]
[same as prior period, unchanged from 0001437749-15-020022:notes:18]

[0001437749-16-031130:notes:22]
[same as prior period, unchanged from 0001437749-15-020022:notes:19]

[0001437749-16-031130:notes:23]
[same as prior period, unchanged from 0001437749-15-020022:notes:20]

[0001437749-16-031130:notes:24]
[same as prior period, unchanged from 0001437749-15-020022:notes:21]

[0001437749-16-031130:notes:25]
|  | ● | On March 1, 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-16-031130:notes:26]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-16-031130:notes:27]
The condensed consolidated balance sheet as of March 31, 2016, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2016 and 2015, and the condensed consolidated statements of cash flows for the three months ended March 31, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-16-031130:notes:28]
The preparation of the condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-16-031130:notes:29]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-031130:notes:30]
[same as prior period, unchanged from 0001437749-15-020022:notes:26]

[0001437749-16-031130:notes:31]
In May 2014, the Financial Accounting Standards Board (

[0001437749-16-031130:notes:32]
FASB)

[0001437749-16-031130:notes:33]
issued Accounting Standards Update (

[0001437749-16-031130:notes:34]
ASU)

[0001437749-16-031130:notes:35]
2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-16-031130:notes:36]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965.

[0001437749-16-031130:notes:37]
In November 2015, the FASB issued ASU 2015-17, 
I

[0001437749-16-031130:notes:38]
ncome Taxes: Balance Sheet Classification of Deferred Taxes
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated balance sheets. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.

[0001437749-16-031130:notes:39]
In February 2016, the FASB issued ASU 2016-02, 
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 2019, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-16-031130:notes:40]
In March 2016, the FASB issued ASU 2016-09, 
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits and forfeitures. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classifications on the statements of cash flow.

[0001437749-16-031130:notes:41]
[same as prior period, unchanged from 0001437749-15-020022:notes:32]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-16-031130:notes:42]
1

[0001437749-16-031130:notes:43]
2

[0001437749-16-031130:notes:44]
. Commitments and Contingencies

[0001437749-16-031130:notes:45]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2016 and December 31, 2015 was approximately $30,900 and $32,400, respectively.

[0001437749-16-031130:notes:46]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-031130:notes:47]
[same as prior period, unchanged from 0001437749-15-020022:notes:38]

[0001437749-16-031130:notes:48]
[same as prior period, unchanged from 0001437749-15-020022:notes:39]

[0001437749-16-031130:notes:49]
The following presents a tabular disclosure of changes in AOCL during the three months ended March 31, 2016 and 2015, net of tax:

[0001437749-16-031130:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,400 |  |  |  | - |  |  |  | (1,154 | ) | (1) |  | 1,246 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 2,400 |  |  |  | - |  |  |  | (1,154 | ) |  |  | 1,246 |  |
| Ending Balance – March 31, 2016 |  | $ | (7,102 | ) |  | $ | (11,362 | ) |  | $ | (2,765 | ) |  | $ | (21,229 | ) |

[0001437749-16-031130:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (5,546 | ) |  |  | - |  |  |  | (1,272 | ) | (2) |  | (6,818 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (5,546 | ) |  |  | - |  |  |  | (1,272 | ) |  |  | (6,818 | ) |
| Ending Balance – March 31, 2015 |  | $ | (7,424 | ) |  | $ | (13,243 | ) |  | $ | (1,918 | ) |  | $ | (22,585 | ) |

[0001437749-16-031130:notes:52]
|  | (1) | Represents unrealized losses of $(1,896), net of tax benefit of $742 for the three months ended March 31, 2016. |

[0001437749-16-031130:notes:53]
|  | (2) | Represents unrealized losses of $(2,074), net of tax benefit of $802 for the three months ended March 31, 2015. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-031130:notes:54]
9

[0001437749-16-031130:notes:55]
. Credit Agreements

[0001437749-16-031130:notes:56]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-16-031130:notes:57]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 34,055 |  |  |  | 8,594 |  |
| Total |  | $ | 34,055 |  |  | $ | 8,594 |  |

[0001437749-16-031130:notes:58]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-16-031130:notes:59]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (28,848 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligations |  |  | 5,402 |  |  |  | 1,694 |  |
| Other |  |  | 27,567 |  |  |  | 12,000 |  |
| Total |  |  | 1,058,121 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 10,405 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 570 |  |  |  | 157 |  |
| Total |  | $ | 1,047,146 |  |  | $ | 1,037,132 |  |

[0001437749-16-031130:notes:60]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

[0001437749-16-031130:notes:61]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of March 31, 2016 was above 3.00 to 1.00. As of March 31, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-031130:notes:62]
The Company’s credit agreements also provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-16-031130:notes:63]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxed certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt).

[0001437749-16-031130:notes:64]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of March 31, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

[0001437749-16-031130:notes:65]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000, which was applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-16-031130:notes:66]
As of March 31, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $34,055 and $8,594, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-16-031130:notes:67]
3

[0001437749-16-031130:notes:68]
[same as prior period, unchanged from 0001437749-15-020022:notes:66]

[0001437749-16-031130:notes:69]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 815, 
Derivatives and Hedging
, which requires derivative instruments be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-16-031130:notes:70]
[same as prior period, unchanged from 0001437749-15-020022:notes:68]

[0001437749-16-031130:notes:71]
The Company is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than eighteen months. At March 31, 2016, December 31, 2015 and March 31, 2015, the Company had zero, one and three commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-16-031130:notes:72]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three months ended March 31, 2016 and 2015 were $6 and $726, respectively.

[0001437749-16-031130:notes:73]
[same as prior period, unchanged from 0001437749-15-020022:notes:72]

[0001437749-16-031130:notes:74]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of March 31, 2016, December 31, 2015 and March 31, 2015, the Company had nine, six and four foreign currency contracts outstanding, respectively.

[0001437749-16-031130:notes:75]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three months ended March 31, 2016 and 2015 were $179 and $321, respectively.

[0001437749-16-031130:notes:76]
[same as prior period, unchanged from 0001437749-15-020022:notes:75]

[0001437749-16-031130:notes:77]
[same as prior period, unchanged from 0001437749-15-020022:notes:76]

[0001437749-16-031130:notes:78]
[same as prior period, unchanged from 0001437749-15-020022:notes:77]

[0001437749-16-031130:notes:79]
[same as prior period, unchanged from 0001437749-15-020022:notes:78]

[0001437749-16-031130:notes:80]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other long-term liabilities in the condensed consolidated balance sheets as of March 31, 2016 and December 31, 2015. Excluding the impact of credit risk, the fair value of the derivative contracts as of March 31, 2016 and December 31, 2015 is a liability of $4,788 and $3,248, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-16-031130:notes:81]
The amount of losses recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three months ended March 31, 2016 and 2015 were $1,154 and $1,272, respectively. The amount of losses recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three months ended March 31, 2016 and 2015 were $185 and $1,047, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-031130:notes:82]
10

[0001437749-16-031130:notes:83]
[same as prior period, unchanged from 0001437749-15-020022:notes:83]

[0001437749-16-031130:notes:84]
Basic earnings per share is calculated by dividing net income attributable to the Company

[0001437749-16-031130:notes:85]
by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-16-031130:notes:86]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. (numerator) |  | $ | 10,208 |  |  | $ | 19,685 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |
| Basic |  |  | 66,099,755 |  |  |  | 68,806,337 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 500,285 |  |  |  | 1,282,598 |  |
| Diluted |  |  | 66,600,040 |  |  |  | 70,088,935 |  |
| Net income attributable to Generac Holdings Inc. per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.15 |  |  | $ | 0.29 |  |
| Diluted |  | $ | 0.15 |  |  | $ | 0.28 |  |

[0001437749-16-031130:notes:87]
(1) Excludes approximately 256,600 stock options and 3,400 shares of restricted stock for the three month period ended March 31, 2016, and 89,100 stock options and 200 shares of restricted stock for the three month period ended March 31, 2015, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-031130:notes:88]
[same as prior period, unchanged from 0001437749-15-020022:notes:87]

[0001437749-16-031130:notes:89]
[same as prior period, unchanged from 0001437749-15-020022:notes:88]

[0001437749-16-031130:notes:90]
[same as prior period, unchanged from 0001437749-15-020022:notes:89]

[0001437749-16-031130:notes:91]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $925,369, was approximately $920,742 (Level 2) at March 31, 2016, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-16-031130:notes:92]
[same as prior period, unchanged from 0001437749-15-020022:notes:91]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-031130:notes:93]
11

[0001437749-16-031130:notes:94]
[same as prior period, unchanged from 0001437749-15-020022:notes:93]

[0001437749-16-031130:notes:95]
The effective income tax rates for the three months ended March 31, 2016 and 2015 were 35.9%.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-16-031130:notes:96]
[same as prior period, unchanged from 0001437749-15-020022:notes:95]

[0001437749-16-031130:notes:97]
[same as prior period, unchanged from 0001437749-15-020022:notes:96]

[0001437749-16-031130:notes:98]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contract.

[0001437749-16-031130:notes:99]
[same as prior period, unchanged from 0001437749-15-020022:notes:98]

[0001437749-16-031130:notes:100]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 30,197 |  |  | $ | 30,909 |  |
| Product warranty reserve assumed in acquisition |  |  | 840 |  |  |  | - |  |
| Payments |  |  | (3,652 | ) |  |  | (5,433 | ) |
| Provision for warranties issued |  |  | 3,482 |  |  |  | 4,549 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,037 |  |  |  | (748 | ) |
| Balance at end of period |  | $ | 31,904 |  |  | $ | 29,277 |  |

[0001437749-16-031130:notes:101]
[same as prior period, unchanged from 0001437749-15-020022:notes:100]

[0001437749-16-031130:notes:102]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 28,961 |  |  | $ | 27,193 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,144 |  |  |  | 1,380 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,275 | ) |  |  | (1,042 | ) |
| Balance at end of period |  | $ | 28,830 |  |  | $ | 27,531 |  |

[0001437749-16-031130:notes:103]
[same as prior period, unchanged from 0001437749-15-020022:notes:102]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-16-031130:notes:104]
|  |  | March 31, 2016 |  |  | December 31, 2015 |  |
| Land and improvements |  | $ | 10,812 |  |  | $ | 8,553 |  |
| Buildings and improvements |  |  | 110,390 |  |  |  | 104,774 |  |
| Machinery and equipment |  |  | 76,431 |  |  |  | 72,280 |  |
| Dies and tools |  |  | 20,603 |  |  |  | 20,066 |  |
| Vehicles |  |  | 1,448 |  |  |  | 1,244 |  |
| Office equipment and systems |  |  | 57,118 |  |  |  | 29,395 |  |
| Leasehold improvements |  |  | 4,005 |  |  |  | 3,338 |  |
| Construction in progress |  |  | 7,322 |  |  |  | 30,482 |  |
| Gross property and equipment |  |  | 288,129 |  |  |  | 270,132 |  |
| Accumulated depreciation |  |  | (90,506 | ) |  |  | (85,919 | ) |
| Total |  | $ | 197,623 |  |  | $ | 184,213 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-16-031130:notes:105]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Residential products |  | $ | 158,980 |  |  | $ | 156,835 |  |
| Commercial & industrial products |  |  | 102,991 |  |  |  | 133,763 |  |
| Other |  |  | 24,564 |  |  |  | 21,220 |  |
| Total |  | $ | 286,535 |  |  | $ | 311,818 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-16-031130:notes:106]
|  |  | March 31, 2016 |  |  | December 31, 2015 |  |
| Raw material |  | $ | 223,346 |  |  | $ | 188,354 |  |
| Work-in-process |  |  | 5,836 |  |  |  | 2,856 |  |
| Finished goods |  |  | 159,112 |  |  |  | 144,747 |  |
| Reserves for excess and obsolete |  |  | (13,585 | ) |  |  | (10,582 | ) |
| Total |  | $ | 374,709 |  |  | $ | 325,375 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-031130:notes:107]
[same as prior period, unchanged from 0001437749-15-020022:notes:106]

[0001437749-16-031130:notes:108]
[same as prior period, unchanged from 0001437749-15-020022:notes:107]

[0001437749-16-031130:notes:109]
The Company has multiple operating segments, which it aggregates into a single reportable segment, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. The single reportable segment is the design and manufacture of a wide range of engine powered products. The Company’s sales in the United States represented approximately 83% and 86% of total sales for the three months ended March 31, 2016 and 2015, respectively. Approximately 85% and 93% of the Company’s identifiable long-lived assets are located in the United States at March 31, 2016 and December 31, 2015, respectively.

[0001437749-16-031130:notes:110]
[same as prior period, unchanged from 0001437749-15-020022:notes:110]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-16-031130:notes:111]
[same as prior period, unchanged from 0001437749-15-020022:notes:111]

[0001437749-16-031130:notes:112]
[same as prior period, unchanged from 0001437749-15-020022:notes:112]

[0001437749-16-031130:notes:113]
[same as prior period, unchanged from 0001437749-15-020022:notes:113]

[0001437749-16-031130:notes:114]
[same as prior period, unchanged from 0001437749-15-020022:notes:114]
