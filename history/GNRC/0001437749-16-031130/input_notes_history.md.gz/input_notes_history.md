# GNRC note change history — 0001437749-15-020022 → 0001437749-16-031130


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001437749-16-031130:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2016 and December 31, 2015 was approximately $30,900 and $32,400, respectively.
  (was, 2015-11-06, similarity 0.9881):
[0001437749-15-020022:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2015 and December 31, 2014 was approximately $35,700 and $26,100, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001437749-16-031130:note_history:2]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East, Africa and Asia Pacific. |
  (was, 2015-11-06, similarity 0.9613):
[0001437749-15-020022:note_history:2]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- added (2016-05-06):
[0001437749-16-031130:note_history:3]
|  | ● | On March 1, 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

- added (2016-05-06):
[0001437749-16-031130:note_history:4]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

- changed (2016-05-06):
[0001437749-16-031130:note_history:5]
The condensed consolidated balance sheet as of March 31, 2016, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2016 and 2015, and the condensed consolidated statements of cash flows for the three months ended March 31, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2015-11-06, similarity 0.9111):
[0001437749-15-020022:note_history:5]
The condensed consolidated balance sheet as of September 30, 2015, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2016-05-06):
[0001437749-16-031130:note_history:6]
The preparation of the condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.
  (was, 2015-11-06, similarity 0.9435):
[0001437749-15-020022:note_history:6]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- added (2016-05-06):
[0001437749-16-031130:note_history:7]
In May 2014, the Financial Accounting Standards Board (

- added (2016-05-06):
[0001437749-16-031130:note_history:8]
FASB)

- added (2016-05-06):
[0001437749-16-031130:note_history:9]
issued Accounting Standards Update (

- added (2016-05-06):
[0001437749-16-031130:note_history:10]
ASU)

- changed (2016-05-06):
[0001437749-16-031130:note_history:11]
2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.
  (was, 2015-11-06, similarity 0.9528):
[0001437749-15-020022:note_history:11]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- changed (2016-05-06):
[0001437749-16-031130:note_history:12]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965.
  (was, 2015-11-06, similarity 0.6134):
[0001437749-15-020022:note_history:12]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

- changed (2016-05-06):
[0001437749-16-031130:note_history:13]
In November 2015, the FASB issued ASU 2015-17, 
I
  (was, 2015-11-06, similarity 0.6429):
[0001437749-15-020022:note_history:13]
In September 2015, the FASB issued ASU 2015-16, 
Business Combinations: Simplifying

- added (2016-05-06):
[0001437749-16-031130:note_history:14]
ncome Taxes: Balance Sheet Classification of Deferred Taxes
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated balance sheets. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.

- added (2016-05-06):
[0001437749-16-031130:note_history:15]
In February 2016, the FASB issued ASU 2016-02, 
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 2019, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- added (2016-05-06):
[0001437749-16-031130:note_history:16]
In March 2016, the FASB issued ASU 2016-09, 
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits and forfeitures. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classifications on the statements of cash flow.

- removed (2016-05-06):
[0001437749-15-020022:note_history:17]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts in the condensed consolidated financial statements and notes thereto have been reclassified to conform to the current period’s presentation.

- removed (2016-05-06):
[0001437749-15-020022:note_history:18]
the Accounting for Measurement

- removed (2016-05-06):
[0001437749-15-020022:note_history:19]
Period Adjustments
. This guidance eliminates the requirement for an acquirer to recognize measurement period adjustments retrospectively; rather an acquirer will recognize a measurement period adjustment during the period in which it determines the amount of the adjustment. The guidance should be applied on a prospective basis, and is effective for the Company in 2016, with early adoption permitted. The Company has early adopted this guidance; however, there is no impact on the Company’s results of operations for the third quarter of 2015 as there were no material measurement period adjustments.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001437749-16-031130:note_history:20]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 34,055 |  |  |  | 8,594 |  |
| Total |  | $ | 34,055 |  |  | $ | 8,594 |  |
  (was, 2015-11-06, similarity 0.9718):
[0001437749-15-020022:note_history:20]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 4,481 |  |  |  | 5,359 |  |
| Total |  | $ | 4,481 |  |  | $ | 5,359 |  |

- added (2016-05-06):
[0001437749-16-031130:note_history:21]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (28,848 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligations |  |  | 5,402 |  |  |  | 1,694 |  |
| Other |  |  | 27,567 |  |  |  | 12,000 |  |
| Total |  |  | 1,058,121 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 10,405 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 570 |  |  |  | 157 |  |
| Total |  | $ | 1,047,146 |  |  | $ | 1,037,132 |  |

- changed (2016-05-06):
[0001437749-16-031130:note_history:22]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of March 31, 2016 was above 3.00 to 1.00. As of March 31, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2015-11-06, similarity 0.8364):
[0001437749-15-020022:note_history:22]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

- changed (2016-05-06):
[0001437749-16-031130:note_history:23]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxed certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt).
  (was, 2015-11-06, similarity 0.8334):
[0001437749-15-020022:note_history:23]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $490 of new debt issuance costs in 2015.

- changed (2016-05-06):
[0001437749-16-031130:note_history:24]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of March 31, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.
  (was, 2015-11-06, similarity 0.9757):
[0001437749-15-020022:note_history:24]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of September 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

- changed (2016-05-06):
[0001437749-16-031130:note_history:25]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000, which was applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.
  (was, 2015-11-06, similarity 0.8921):
[0001437749-15-020022:note_history:25]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2016-05-06):
[0001437749-16-031130:note_history:26]
As of March 31, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $34,055 and $8,594, respectively.
  (was, 2015-11-06, similarity 0.9709):
[0001437749-15-020022:note_history:26]
As of September 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $4,481 and $5,359, respectively.

- removed (2016-05-06):
[0001437749-15-020022:note_history:27]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (17,496 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,783 |  |  |  | 2,059 |  |
| Other |  |  | 12,142 |  |  |  | 460 |  |
| Total |  |  | 1,050,429 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 160 |  |  |  | 168 |  |
| Total |  | $ | 1,050,127 |  |  | $ | 1,082,101 |  |

- removed (2016-05-06):
[0001437749-15-020022:note_history:28]
Because the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs in the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan, as the Company expected the net debt leverage ratio to remain below 3.00 to 1.00.

- removed (2016-05-06):
[0001437749-15-020022:note_history:29]
Because the Company’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a cumulative catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is forecasted to be above 3.00 to 1.00.

- removed (2016-05-06):
[0001437749-15-020022:note_history:30]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of September 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- removed (2016-05-06):
[0001437749-15-020022:note_history:31]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which were applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0001437749-16-031130:note_history:32]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (28,848 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligations |  |  | 5,402 |  |  |  | 1,694 |  |
| Other |  |  | 27,567 |  |  |  | 12,000 |  |
| Total |  |  | 1,058,121 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 10,405 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 570 |  |  |  | 157 |  |
| Total |  | $ | 1,047,146 |  |  | $ | 1,037,132 |  |

- removed (2016-05-06):
[0001437749-15-020022:note_history:33]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (17,496 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,783 |  |  |  | 2,059 |  |
| Other |  |  | 12,142 |  |  |  | 460 |  |
| Total |  |  | 1,050,429 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 160 |  |  |  | 168 |  |
| Total |  | $ | 1,050,127 |  |  | $ | 1,082,101 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001437749-16-031130:note_history:34]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 34,055 |  |  |  | 8,594 |  |
| Total |  | $ | 34,055 |  |  | $ | 8,594 |  |
  (was, 2015-11-06, similarity 0.9718):
[0001437749-15-020022:note_history:34]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 4,481 |  |  |  | 5,359 |  |
| Total |  | $ | 4,481 |  |  | $ | 5,359 |  |
