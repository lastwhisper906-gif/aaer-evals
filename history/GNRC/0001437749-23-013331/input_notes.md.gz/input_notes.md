# GNRC notes — 0001437749-23-013331


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-23-013331:notes:1]
[same as prior period, unchanged from 0001437749-22-026207:notes:1]

[0001437749-23-013331:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-23-013331:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2022). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-23-013331:notes:4]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. (Blue Pillar), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems (REFUstor), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market. |

[0001437749-23-013331:notes:5]
[same as prior period, unchanged from 0001437749-22-026207:notes:5]

[0001437749-23-013331:notes:6]
The condensed consolidated balance sheet as of  March 31, 2023, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2023 and 2022, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-23-013331:notes:7]
[same as prior period, unchanged from 0001437749-22-026207:notes:7]

[0001437749-23-013331:notes:8]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2022.

[0001437749-23-013331:notes:9]
[same as prior period, unchanged from 0001437749-22-026207:notes:14]

[0001437749-23-013331:notes:10]
[same as prior period, unchanged from 0001437749-22-026207:notes:15]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-23-013331:notes:11]
[same as prior period, unchanged from 0001437749-22-026207:notes:16]

[0001437749-23-013331:notes:12]
Fiscal 2023 Acquisitions

[0001437749-23-013331:notes:13]
On  February 1, 2023, the Company acquired REFU Storage Systems (REFUstor), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market.

[0001437749-23-013331:notes:14]
The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  March 31, 2023. The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized prior to  March 31, 2024. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-23-013331:notes:15]
[same as prior period, unchanged from 0001437749-22-026207:notes:17]

[0001437749-23-013331:notes:16]
On  June 30, 2022, the Company acquired EEC. Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services.

[0001437749-23-013331:notes:17]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control.

[0001437749-23-013331:notes:18]
The combined purchase price for these two acquisitions was $25,654, net of cash acquired. The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized in 2023. Through Q1 2023, the combined purchase price has increased to $27,138. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  March 31, 2023. Pro forma and other financial information are not presented as the effects of the 2022 acquisitions are not material to the Company's results of operations or financial position prior to the acquisition date.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-23-013331:notes:19]
[same as prior period, unchanged from 0001437749-22-026207:notes:46]

[0001437749-23-013331:notes:20]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price included $105,264 of initial consideration (which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement) and $11,490 of contingent deferred consideration to be paid in up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025.

[0001437749-23-013331:notes:21]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand.

[0001437749-23-013331:notes:22]
The redeemable noncontrolling interests are recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 13, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest for both Captiva and Pramac:

[0001437749-23-013331:notes:23]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 110,471 |  |  | $ | 58,050 |  |
| Net income |  |  | 1,448 |  |  |  | 2,856 |  |
| Foreign currency translation |  |  | (367 | ) |  |  | (881 | ) |
| Purchase of additional ownership interest |  |  | (116,754 | ) |  |  | (461 | ) |
| Redemption value adjustment |  |  | 9,016 |  |  |  | 11,947 |  |
| Balance at end of period |  | $ | 3,814 |  |  | $ | 71,511 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-23-013331:notes:24]
[same as prior period, unchanged from 0001437749-22-026207:notes:51]

[0001437749-23-013331:notes:25]
[same as prior period, unchanged from 0001437749-22-026207:notes:52]

[0001437749-23-013331:notes:26]
[same as prior period, unchanged from 0001437749-22-026207:notes:53]

[0001437749-23-013331:notes:27]
[same as prior period, unchanged from 0001437749-22-026207:notes:54]

[0001437749-23-013331:notes:28]
In 2017, the Company entered into twenty interest rate swap agreements, four of which were still outstanding as of  March 31, 2023. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to seven as of  March 31, 2023.

[0001437749-23-013331:notes:29]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 11, “Credit Agreements,” the Company amended its interest rate swaps to match that of the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss ("AOCL") in the condensed consolidated balance sheets.

[0001437749-23-013331:notes:30]
The amount of gains/(losses), net of tax, recognized for the three months ended  March 31, 2023 and 2022 were ($4,488) and $18,728, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-23-013331:notes:31]
[same as prior period, unchanged from 0001437749-22-026207:notes:58]

[0001437749-23-013331:notes:32]
[same as prior period, unchanged from 0001437749-22-026207:notes:59]

[0001437749-23-013331:notes:33]
|  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Commodity contracts |  | $ | 111 |  |  | $ | - |  |
| Foreign currency contracts |  |  | 112 |  |  |  | 94 |  |
| Interest rate swaps |  |  | 43,291 |  |  |  | 49,279 |  |

[0001437749-23-013331:notes:34]
In the condensed consolidated balance sheets, the fair value of the commodity and foreign currency contracts are included in prepaid expenses & other current assets, and the fair value of the interest rate swaps is included in prepaid expenses & other current assets and operating lease & other assets. Excluding the impact of credit risk, the fair value of the derivative contracts as of  March 31, 2023 and  December 31, 2022 is an asset of $45,003 and $51,184 respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-013331:notes:35]
[same as prior period, unchanged from 0001437749-22-026207:notes:62]

[0001437749-23-013331:notes:36]
[same as prior period, unchanged from 0001437749-22-026207:notes:63]

[0001437749-23-013331:notes:37]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $523,706, was $528,675 (Level 2) at  March 31, 2023, as calculated based on independent valuations whose inputs and significant value drivers are observable. The fair value of Term Loan A approximates the carrying value.

[0001437749-23-013331:notes:38]
[same as prior period, unchanged from 0001437749-22-026207:notes:65]

[0001437749-23-013331:notes:39]
[same as prior period, unchanged from 0001437749-22-026207:notes:66]

[0001437749-23-013331:notes:40]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's condensed consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-23-013331:notes:41]
At  March 31, 2023, the fair value of contingent consideration is $10,500 in other accrued liabilities and $33,385 in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2022, the Company had contingent consideration of $49,500 in other accrued liabilities and $32,033 in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-23-013331:notes:42]
[same as prior period, unchanged from 0001437749-22-026207:notes:69]

[0001437749-23-013331:notes:43]
| Beginning balance, January 1, 2023 |  | $ | 81,533 |  |
| Changes in fair value |  |  | - |  |
| Additional contingent consideration (1) |  |  | 11,490 |  |
| Payment of contingent consideration (2) |  |  | (49,286 | ) |
| Present value interest accretion |  |  | 148 |  |
| Ending balance, March 31, 2023 |  | $ | 43,885 |  |

[0001437749-23-013331:notes:44]
(1) Represents $11,490 of contingent deferred consideration for the Pramac buyout. See Note 3, "Redeemable Noncontrolling Interest".

[0001437749-23-013331:notes:45]
(2) Includes payments of $479 in cash and $44,521 in shares for the ecobee acquisition and $4,286 in shares for the Chilicon acquisition. The payment of common stock is accounted for as a non-cash item in the condensed consolidated statement of cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-23-013331:notes:46]
[same as prior period, unchanged from 0001437749-22-026207:notes:71]

[0001437749-23-013331:notes:47]
The following presents a tabular disclosure of changes in AOCL during the three months ended  March 31, 2023 and 2022, net of tax:

[0001437749-23-013331:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 27,247 |  | (1) |  |  | (4,488 | ) | (2) |  |  | 22,759 |  |
| Ending Balance – March 31, 2023 |  | $ | (74,298 | ) |  |  | $ | 31,955 |  |  |  | $ | (42,343 | ) |

[0001437749-23-013331:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) |  |  | (10,375 | ) | (3) |  |  | 18,728 |  | (4) |  |  | 8,353 |  |
| Ending Balance – March 31, 2022 |  | $ | (63,079 | ) |  |  | $ | 16,677 |  |  |  | $ | (46,402 | ) |

[0001437749-23-013331:notes:50]
|  | (1) | Represents favorable impact from the weaking of the U.S. dollar against foreign currencies during the three months ended March 31, 2023, including the Euro and British Pound. |
|  | (2) | Represents unrealized losses of $(5,988) on the interest rate swaps, net of tax effect of $1,500 for the three months ended March 31, 2023. |

[0001437749-23-013331:notes:51]
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2022, including the Euro and British Pound. |
|  | (4) | Represents unrealized gains of $25,054 on the interest rate swaps, net of tax effect of $(6,326) for the three months ended March 31, 2022. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-013331:notes:52]
[same as prior period, unchanged from 0001437749-22-026207:notes:79]

[0001437749-23-013331:notes:53]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, Deep Sea, Off Grid Energy, and REFUstor acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-23-013331:notes:54]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial &

[0001437749-23-013331:notes:55]
Industrial (C&I) products include similar products, they differ based on power output and end customer. The breakout of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-23-013331:notes:56]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |

[0001437749-23-013331:notes:57]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 750,327 |  |  | $ | 26,617 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 145,737 |  |  |  | 132,991 |  |  |  | 278,728 |  |
| Other |  |  | 68,610 |  |  |  | 11,574 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | 1,135,856 |  |

[0001437749-23-013331:notes:58]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which they in turn sell or rent to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential product's revenues are transferred to the customer at a point in time.

[0001437749-23-013331:notes:59]
C&I products consist of larger output stationary generators used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which they in turn sell or rent to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-23-013331:notes:60]
[same as prior period, unchanged from 0001437749-22-026207:notes:88]

[0001437749-23-013331:notes:61]
[same as prior period, unchanged from 0001437749-22-026207:notes:89]

[0001437749-23-013331:notes:62]
|  |  | Three Months Ended March 31, 2023 |  |  | Three Months Ended March 31, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | - |  |  | $ | 887,910 |  |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | - |  |  | $ | 1,135,856 |  |
| Intersegment sales |  |  | 15,607 |  |  |  | 32,942 |  |  |  | (48,549 | ) |  |  | - |  |  |  | 10,270 |  |  |  | 14,250 |  |  |  | (24,520 | ) |  |  | - |  |
| Total sales |  | $ | 719,993 |  |  | $ | 216,466 |  |  | $ | (48,549 | ) |  | $ | 887,910 |  |  | $ | 974,944 |  |  | $ | 185,432 |  |  | $ | (24,520 | ) |  | $ | 1,135,856 |  |

[0001437749-23-013331:notes:63]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to income before provision for income taxes below. The computation of Adjusted EBITDA is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests.

[0001437749-23-013331:notes:64]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 67,662 |  |  | $ | 170,421 |  |
| International |  |  | 32,413 |  |  |  | 25,992 |  |
| Total adjusted EBITDA |  | $ | 100,075 |  |  | $ | 196,413 |  |
| Interest expense |  |  | (22,995 | ) |  |  | (9,554 | ) |
| Depreciation and amortization |  |  | (39,951 | ) |  |  | (38,461 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 3,160 |  |  |  | 7,792 |  |
| Non-cash share-based compensation expense (2) |  |  | (10,334 | ) |  |  | (8,827 | ) |
| Transaction costs and credit facility fees (3) |  |  | (1,091 | ) |  |  | (989 | ) |
| Business optimization and other charges (4) |  |  | (1,100 | ) |  |  | (1,159 | ) |
| Provision for regulatory charges (5) |  |  | (5,800 | ) |  |  | - |  |
| Other |  |  | 46 |  |  |  | 289 |  |
| Income before provision for income taxes |  | $ | 22,010 |  |  | $ | 145,504 |  |

[0001437749-23-013331:notes:65]
[same as prior period, unchanged from 0001437749-22-026207:notes:94]

[0001437749-23-013331:notes:66]
[same as prior period, unchanged from 0001437749-22-026207:notes:95]

[0001437749-23-013331:notes:67]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-23-013331:notes:68]
|  | (4) | Represents severance and other non-recurring restructuring charges. |
|  | (5) | Represents a provision of $5,800 for a matter with the Consumer Product Safety Commission concerning the imposition of penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. |

[0001437749-23-013331:notes:69]
The Company’s sales in the U.S. represented approximately 75% and 83% of total sales for the three months ended  March 31, 2023 and  March 31, 2022, respectively. Approximately 76% and 77% of the Company’s identifiable long-lived assets were located in the U.S. at  March 31, 2023 and  December 31, 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-23-013331:notes:70]
[same as prior period, unchanged from 0001437749-22-026207:notes:99]

[0001437749-23-013331:notes:71]
[same as prior period, unchanged from 0001437749-22-026207:notes:103]

[0001437749-23-013331:notes:72]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Raw material |  | $ | 825,487 |  |  | $ | 798,340 |  |
| Work-in-process |  |  | 11,530 |  |  |  | 14,899 |  |
| Finished goods |  |  | 601,279 |  |  |  | 592,145 |  |
| Total |  | $ | 1,438,296 |  |  | $ | 1,405,384 |  |

[0001437749-23-013331:notes:73]
[same as prior period, unchanged from 0001437749-22-026207:notes:105]

[0001437749-23-013331:notes:74]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Land and improvements |  | $ | 23,866 |  |  | $ | 22,589 |  |
| Buildings and improvements |  |  | 250,056 |  |  |  | 243,553 |  |
| Machinery and equipment |  |  | 241,332 |  |  |  | 229,593 |  |
| Dies and tools |  |  | 39,269 |  |  |  | 37,343 |  |
| Vehicles |  |  | 10,052 |  |  |  | 9,807 |  |
| Office equipment and systems |  |  | 159,098 |  |  |  | 148,166 |  |
| Leasehold improvements |  |  | 7,093 |  |  |  | 6,849 |  |
| Construction in progress |  |  | 58,021 |  |  |  | 52,522 |  |
| Gross property and equipment |  |  | 788,787 |  |  |  | 750,422 |  |
| Accumulated depreciation |  |  | (298,644 | ) |  |  | (282,818 | ) |
| Total |  | $ | 490,143 |  |  | $ | 467,604 |  |

[0001437749-23-013331:notes:75]
Total property and equipment includes finance leases of $26,926 and $24,719 on  March 31, 2023 and  December 31, 2022, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-23-013331:notes:76]
[same as prior period, unchanged from 0001437749-22-026207:notes:108]

[0001437749-23-013331:notes:77]
[same as prior period, unchanged from 0001437749-22-026207:notes:109]

[0001437749-23-013331:notes:78]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 138,011 |  |  | $ | 94,213 |  |
| Payments |  |  | (26,152 | ) |  |  | (13,024 | ) |
| Provision for warranty issued |  |  | 15,865 |  |  |  | 21,425 |  |
| Changes in estimates for pre-existing warranties |  |  | 875 |  |  |  | (1,123 | ) |
| Balance at end of period |  | $ | 128,599 |  |  | $ | 101,491 |  |

[0001437749-23-013331:notes:79]
[same as prior period, unchanged from 0001437749-22-026207:notes:112]

[0001437749-23-013331:notes:80]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 132,813 |  |  | $ | 111,647 |  |
| Deferred revenue contracts issued |  |  | 9,726 |  |  |  | 9,546 |  |
| Amortization of deferred revenue contracts |  |  | (5,854 | ) |  |  | (5,270 | ) |
| Balance at end of period |  | $ | 136,685 |  |  | $ | 115,923 |  |

[0001437749-23-013331:notes:81]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  March 31, 2023 is as follows:

[0001437749-23-013331:notes:82]
| Remainder of 2023 |  | $ | 18,638 |  |
| 2024 |  |  | 25,688 |  |
| 2025 |  |  | 25,085 |  |
| 2026 |  |  | 20,734 |  |
| 2027 |  |  | 15,881 |  |
| After 2027 |  |  | 30,659 |  |
| Total |  | $ | 136,685 |  |

[0001437749-23-013331:notes:83]
[same as prior period, unchanged from 0001437749-22-026207:notes:116]

[0001437749-23-013331:notes:84]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 80,902 |  |  | $ | 89,141 |  |
| Long-term portion - other long-term liabilities |  |  | 47,697 |  |  |  | 48,870 |  |
| Total |  | $ | 128,599 |  |  | $ | 138,011 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 30,890 |  |  | $ | 30,291 |  |
| Long-term portion - other long-term liabilities |  |  | 105,795 |  |  |  | 102,522 |  |
| Total |  | $ | 136,685 |  |  | $ | 132,813 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-013331:notes:85]
[same as prior period, unchanged from 0001437749-22-026207:notes:118]

[0001437749-23-013331:notes:86]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $25,326 and $33,551 on  March 31, 2023 and  December 31, 2022, respectively. During the three months ended  March 31, 2023, the Company recognized revenue of $11,290 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-013331:notes:87]
11.   Credit Agreements

[0001437749-23-013331:notes:88]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $64,093 and $48,990, respectively.

[0001437749-23-013331:notes:89]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-23-013331:notes:90]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,614 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,765 |  |  |  | 27,420 |  |
| Other |  |  | 1,233 |  |  |  | 966 |  |
| Total |  |  | 1,545,384 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 15,050 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 2,979 |  |  |  | 2,650 |  |
| Total |  | $ | 1,527,355 |  |  | $ | 1,369,085 |  |

[0001437749-23-013331:notes:91]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  March 31, 2023 are as follows:

[0001437749-23-013331:notes:92]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

[0001437749-23-013331:notes:93]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in  September 2023, as noted in the table above.

[0001437749-23-013331:notes:94]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2023, was 6.52%.

[0001437749-23-013331:notes:95]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2023, the Company’s net secured leverage ratio was 2.13 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-23-013331:notes:96]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-013331:notes:97]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  March 31, 2023, was 6.27%.

[0001437749-23-013331:notes:98]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2023, the Company’s total leverage ratio was 2.22 to 1.00 times, and the Company's interest coverage ratio was 30.99 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2023.

[0001437749-23-013331:notes:99]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-23-013331:notes:100]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-013331:notes:101]
As of  March 31, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $998,580 of availability, net of outstanding letters of credit.

[0001437749-23-013331:notes:102]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.


## us-gaap:TreasuryStockTextBlock

[0001437749-23-013331:notes:103]
[same as prior period, unchanged from 0001437749-22-026207:notes:139]

[0001437749-23-013331:notes:104]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allowed for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three months ended  March 31, 2023 and 2022. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 11,748,713 shares of common stock for $777,379 (at an average cost per share of $66.17).


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-013331:notes:105]
[same as prior period, unchanged from 0001437749-22-026207:notes:141]

[0001437749-23-013331:notes:106]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest,” to the condensed consolidated financial statements, for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-23-013331:notes:107]
[same as prior period, unchanged from 0001437749-22-026207:notes:143]

[0001437749-23-013331:notes:108]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (9,016 | ) |  |  | (11,947 | ) |
| Net income attributable to common shareholders |  | $ | 3,414 |  |  | $ | 101,911 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,556,044 |  |  |  | 63,449,380 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 738,403 |  |  |  | 1,279,626 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | 99,813 |  |
| Diluted shares |  |  | 62,294,447 |  |  |  | 64,828,819 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 1.61 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 1.57 |  |

[0001437749-23-013331:notes:109]
(1) Excludes approximately 411,000 and 17,000 stock options and restricted stock awards for the three months ended  March 31, 2023 and  March 31, 2022, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-013331:notes:110]
[same as prior period, unchanged from 0001437749-22-026207:notes:146]

[0001437749-23-013331:notes:111]
The effective income tax rates for the three months ended  March 31, 2023 and 2022 were 35.7% and 19.7%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation on a low pre-tax earnings base in the current period compared to the prior period.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-013331:notes:112]
15. Commitments and Contingencies

[0001437749-23-013331:notes:113]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2023 and  December 31, 2022 was approximately $179.8 million and $212.2 million respectively.

[0001437749-23-013331:notes:114]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred. The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which Power Home Solar characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll Power Home Solar’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Company intends to vigorously defend against the claims in the complaint, whichever forum in which it  may proceed.

[0001437749-23-013331:notes:115]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

[0001437749-23-013331:notes:116]
Five additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  March 21, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative class allegedly incurred. The cases are pending in the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386-NJ and Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034-NJ), the Northern District of California (Moon v. Generac Power Systems, Inc. et al., Case No. 22-cv-09183-CRB), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203-TLN), and the County of Wake, State of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23CV006415-910. Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints. Generac Power and the Company have filed motions to dismiss in the Haak, Basler, and Moon cases.

[0001437749-23-013331:notes:117]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and others seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. Subsequently, the parties to each of the federal court actions filed motions to stay those actions until the Judicial Panel on Multidistrict Litigation (“JPML”) determines whether to grant the MDL Motion. Those motions to stay were granted by the respective courts. On  March 28, 2023, Generac Power and the plaintiffs in the other putative federal class actions each filed responses to the MDL Motion in which all agreed that the pending cases should be transferred to the proposed Multidistrict Litigation. A hearing on the MDL Motion is scheduled for  May 25, 2023.

[0001437749-23-013331:notes:118]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. Motions to consolidate the putative class actions and to appoint a lead plaintiff have been filed and are pending with the court. The Company disputes the allegations and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-23-013331:notes:119]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief.

[0001437749-23-013331:notes:120]
Between  March 20, 2023 and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-23-013331:notes:121]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resources Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-23-013331:notes:122]
On  November 30, 2022, the U.S. Consumer Product Safety Commission ("CPSC") notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act ("CPSA"), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the CPSC provisionally accepted the terms of a mutual settlement agreement between the CPSC and the Company. The parties entered into such agreement for settlement purposes only. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement, once finalized, would require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. The settlement agreement with CPSC under its current terms will not have a material adverse effect on the Company’s financial condition, results of operations or cash flows.

[0001437749-23-013331:notes:123]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.
