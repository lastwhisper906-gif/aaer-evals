# GNRC MD&A — 0001437749-23-013331


## mdna

[0001437749-23-013331:mdna:1]
[same as prior period, unchanged from 0001437749-22-026207:mdna:1]

[0001437749-23-013331:mdna:2]
[same as prior period, unchanged from 0001437749-22-026207:mdna:2]

[0001437749-23-013331:mdna:3]
[same as prior period, unchanged from 0001437749-22-026207:mdna:3]

[0001437749-23-013331:mdna:4]
[same as prior period, unchanged from 0001437749-22-026207:mdna:4]

[0001437749-23-013331:mdna:5]
[same as prior period, unchanged from 0001437749-22-026207:mdna:5]

[0001437749-23-013331:mdna:6]
[same as prior period, unchanged from 0001437749-22-026207:mdna:6]

[0001437749-23-013331:mdna:7]
[same as prior period, unchanged from 0001437749-22-026207:mdna:7]

[0001437749-23-013331:mdna:8]
[same as prior period, unchanged from 0001437749-22-026207:mdna:8]

[0001437749-23-013331:mdna:9]
[same as prior period, unchanged from 0001437749-22-026207:mdna:9]

[0001437749-23-013331:mdna:10]
|  | ● | availability of both labor and key components from our manufacturing operations and global supply chain, including single-sourced components and contract manufacturers, needed in producing our products; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-23-013331:mdna:11]
[same as prior period, unchanged from 0001437749-22-026207:mdna:11]

[0001437749-23-013331:mdna:12]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-23-013331:mdna:13]
[same as prior period, unchanged from 0001437749-22-026207:mdna:13]

[0001437749-23-013331:mdna:14]
|  | ● | our ability to remain competitive by investing in, developing or adapting to changing technologies and manufacturing techniques, as well as protecting our intellectual property rights; |

[0001437749-23-013331:mdna:15]
[same as prior period, unchanged from 0001437749-22-026207:mdna:15]

[0001437749-23-013331:mdna:16]
[same as prior period, unchanged from 0001437749-22-026207:mdna:16]

[0001437749-23-013331:mdna:17]
[same as prior period, unchanged from 0001437749-22-026207:mdna:17]

[0001437749-23-013331:mdna:18]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations; and |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-013331:mdna:19]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2022 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-23-013331:mdna:20]
[same as prior period, unchanged from 0001437749-22-026207:mdna:20]

[0001437749-23-013331:mdna:21]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, energy management devices and energy services, advanced power grid software platforms, and engine- & battery-powered tools and equipment. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-23-013331:mdna:22]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial and industrial standby generators; as well as portable and mobile generators used in a variety of applications. In recent years, the Company has been evolving its business model to focus on building out an ecosystem of energy technology products, solutions, and services for home and business purposes. As part of this evolution, we have made significant investments into rapidly growing markets such as residential clean energy storage, solar module-level power electronics (MLPE), and energy monitoring & management devices, all of which are distributed energy resources (DERs) that can be aggregated into virtual power plants (VPPs) within grid services programs. In addition, we have been leveraging our leading position in the growing market for natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I customers. We believe natural gas represents a cleaner transition fuel to more renewable and energy storage sources compared to diesel.

[0001437749-23-013331:mdna:23]
We have also made investments in next-generation platforms and controls for both residential and C&I applications that facilitate the connection of our products to the grid. Expanding these capabilities will enable the increasing utilization of our equipment as DERs as the nascent market for grid services expands over the next several years. Our growing presence in grid services programs will enhance the value of our power generation and storage products that might otherwise sit idle, as they are now able to be dispatched and orchestrated as part of a distributed energy solution, thereby generating additional return-on-investment for the home or business owner while also delivering value to utilities and grid operators by helping to balance, support and enhance the reliability of the electrical grid. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will build-out, and Generac’s energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid referred to as “Grid 2.0”.

[0001437749-23-013331:mdna:24]
As our traditional power generation markets remain strong due to multiple mega-trends that are driving increased penetration of our products, we believe we are in an excellent position to execute on this opportunity given our competitive strengths. In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe that Generac is well-positioned for success over the long term.

[0001437749-23-013331:mdna:25]
[same as prior period, unchanged from 0001437749-22-026207:mdna:25]

[0001437749-23-013331:mdna:26]
In 2021, we unveiled our “Powering A Smarter World” strategic plan, which serves as the framework for the significant investments we have made and will continue to make to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is based on the combination of several key mega-trends that we believe will drive several significant strategic growth themes for our business. See our Annual Report on Form 10-K for the year ended December 31, 2022 for more information on our "Powering A Smarter World" strategic plan.

[0001437749-23-013331:mdna:27]
[same as prior period, unchanged from 0001437749-22-026207:mdna:27]

[0001437749-23-013331:mdna:28]
|  | ● | “Grid 2.0”: which is the evolution of the traditional electrical utility model as supply/demand imbalances are created due to the accelerating adoption of renewable energy generation and the “electrification of everything” in society’s energy consumption. It includes the decarbonization, digitization, and decentralization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward. |

[0001437749-23-013331:mdna:29]
|  | ● | Impact of climate change: which includes the expectation of more volatile and severe weather driving increased power outage activity, and more global regulation accelerating renewable investments. |
|  | ● | Natural gas as an important transition fuel to the future: as natural gas will remain in demand as a source of cleaner, reliable power generation for backup power and beyond standby applications, compared to diesel fuel. |
|  | ● | Legacy infrastructure needs a major investment cycle: to rebuild and upgrade aging networks and systems including transportation, water and power. |
|  | ● | Telecommunications infrastructure shifting to next generation: which involves the “5G” architecture that will enable new technologies requiring significant improvement in network uptime through backup power solutions. |
|  | ● | Home as a Sanctuary: in recent years, there has been a trend of more people working, shopping, entertaining, aging in place, and generally spending more time at home. As a result of this and the “electrification of everything” trend, homeowners are becoming increasingly sensitive to power outages due to lost productivity and functionality. These trends combined with ongoing elevated power outage activity has led to significantly increased awareness regarding the importance and need for backup power security. |

[0001437749-23-013331:mdna:30]
[same as prior period, unchanged from 0001437749-22-026207:mdna:30]

[0001437749-23-013331:mdna:31]
Power quality issues continue to increase. Power disruptions are an important driver of consumer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for backup power. Attitudes around climate change have shifted and undergone increased global focus, and an aging and underinvested electrical grid infrastructure remains highly vulnerable to the expectation of more volatile and severe weather. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply, further impairing the reliable supply of electricity at a time when demand is starting to increase meaningfully with the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. These developments are causing a growing supply/demand imbalance for grid operators across North America, which has led to recent high-profile examples of rolling blackouts necessary to maintain grid integrity. In fact, the North American Electric Reliability Corporation has labeled significant portions of the continent as being at high risk of resource adequacy shortfalls during normal seasonal peak conditions in the 2023-2027 period due in part to these supply/demand dynamics. Further, in California, Public Safety Power Shutoff events have occurred whereby public utilities are turning off power supply to their customers under certain circumstances to prevent their transmission equipment from starting wildfires, which we anticipate may continue in the future. Taken together, we expect these factors to continue driving increased awareness and demand for Generac’s products within multiple categories.

[0001437749-23-013331:mdna:32]
Home standby penetration opportunity is significant. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. With only approximately 5.75% penetration of the addressable market of homes in the United States (which we define as single-family detached, owner-occupied households with a home value of over $150,000, as defined by the U.S. Census Bureau's 2021 American Housing Survey for the United States), we believe there are significant opportunities to further penetrate the residential standby generator market both domestically and internationally. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our home standby generators. Additionally, Smart Grid Ready capabilities have the potential to turn an asset previously utilized only in emergency power outage situations into a source of recurring revenue for the homeowner and a contributor to grid stability for utilities and grid operators, therefore driving incremental interest in the product category.

[0001437749-23-013331:mdna:33]
Solar, storage, and energy management markets developing quickly. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from renewable sources such as solar and wind, and cleaner-burning natural gas generators, is projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. We expect to further advance our capabilities in clean energy by increasing our product development, sourcing, distribution, and marketing efforts, as we leverage our significant competencies in the residential standby generator market to augment our market position in the emerging residential solar, storage, monitoring and management markets. Additionally, these markets are receiving an increasing level of regulatory and legislative support, most notably from the Inflation Reduction Act that was passed in 2022. This legislation includes significant subsidies and investment tax credits for consumers and business over the coming decade and provides necessary opportunity for long-term, value-creating investments for market participants.

[0001437749-23-013331:mdna:34]
Grid services and Energy-as-a-Service open new revenue streams.  We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will continue to drive the need for grid operators to access and control DERs. This will require highly intelligent software platforms that are able to optimize an increasingly complex supply and demand equation, such as our Concerto software platform. As the grid services market matures, Generac will continue to explore opportunities beyond the traditional software-as-a-service subscription model, including but not limited to the aggregation and sale of power from a fleet of DERs in performance-based contracts, wholesale power market participation, turn-key solutions that combine hardware and software with services, and other monitoring and management services. Additionally, growing interest in our C&I products across a variety of “beyond standby” applications is driving an increase in demand for subscription-like models for end customers, in which Generac will partner with third parties to deliver peace of mind and resiliency solutions while also enabling contributions to grid stability with minimal upfront capital outlays. The significant advancements made in recent years in the connectivity of our products is core to these newer capabilities, which play a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-23-013331:mdna:35]
Natural gas generators driving growth.  We believe natural gas will continue to be an important and cleaner transition fuel of the future, in comparison to diesel, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, which we believe will continue to grow at a faster rate than traditional diesel fueled generators. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids and overall use as a distributed energy resource in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having Smart Grid Ready capabilities, which allows for end users to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators.

[0001437749-23-013331:mdna:36]
Rollout of 5G will require improved network quality.  As the number of “connected” devices continues to rapidly increase and wireless networks are now being considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States, where approximately half of all existing tower sites have yet to be hardened with backup power. As more mission-critical data is transmitted over wireless networks, we believe this penetration rate must increase considerably to maintain a higher level of reliability across the network. Increased adoption of high-speed wireless networks around the globe may lead to similar demand trends internationally as growing cell tower density and the need for onsite backup power expand the market opportunity for our international telecom products. We have relationships with key Tier 1 carriers and tower companies globally in addition to having the distribution partners to support the global market from a service standpoint. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-23-013331:mdna:37]
[same as prior period, unchanged from 0001437749-22-026207:mdna:37]

[0001437749-23-013331:mdna:38]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. Finally, the existence of renewable energy mandates, investment tax credits and other subsidies, which have become even more prevalent with the recent passing of the Inflation Reduction Act, can also have an impact on the demand for solar and energy storage systems.

[0001437749-23-013331:mdna:39]
Impact of business capital investment and other economic cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions in the countries where we serve, as well as credit availability in those regions.

[0001437749-23-013331:mdna:40]
[same as prior period, unchanged from 0001437749-22-026207:mdna:40]

[0001437749-23-013331:mdna:41]
[same as prior period, unchanged from 0001437749-22-026207:mdna:41]

[0001437749-23-013331:mdna:42]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-23-013331:mdna:43]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in the first quarter of 2023. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-23-013331:mdna:44]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. For Residential products, we are currently experiencing higher field inventories for home standby generators given installation capacity constraints in our distribution network that resulted in lower orders from our channel partners in the first quarter of 2023 and this headwind is expected to moderate as we enter the second half of 2023.

[0001437749-23-013331:mdna:45]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia. Our sales to customers in Russia and Ukraine represented less than 1% of our total revenue for the year ended December 31, 2021, and therefore the impact on our financial results has not been and is not expected to be material. However, the situation remains uncertain, and it is difficult to predict the impact that the conflict and actions taken in response to the conflict will have on our business. In particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-23-013331:mdna:46]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions to the existing Tranche B Term Loan Facility were replaced with SOFR provisions. During the three months ended March 31, 2023, interest expense increased compared to the three months ended March 31, 2022, primarily due to increased borrowings, higher interest rates, and interest accretion on contingent acquisition consideration. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-23-013331:mdna:47]
Factors influencing provision for income taxes and cash income taxes paid.   The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation on a low pre-tax earnings base in the current period compared to the prior period. On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not impact the current quarter results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-23-013331:mdna:48]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2022.

[0001437749-23-013331:mdna:49]
[same as prior period, unchanged from 0001437749-22-026207:mdna:52]

[0001437749-23-013331:mdna:50]
Three months ended March 31, 2023 compared to the three months ended March 31, 2022

[0001437749-23-013331:mdna:51]
[same as prior period, unchanged from 0001437749-22-026207:mdna:54]

[0001437749-23-013331:mdna:52]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 887,910 |  |  | $ | 1,135,856 |  |  | $ | (247,946 | ) |  |  | -21.8 | % |
| Costs of goods sold |  |  | 615,411 |  |  |  | 775,108 |  |  |  | (159,697 | ) |  |  | -20.6 | % |
| Gross profit |  |  | 272,499 |  |  |  | 360,748 |  |  |  | (88,249 | ) |  |  | -24.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 100,688 |  |  |  | 98,243 |  |  |  | 2,445 |  |  |  | 2.5 | % |
| Research and development |  |  | 41,820 |  |  |  | 39,744 |  |  |  | 2,076 |  |  |  | 5.2 | % |
| General and administrative |  |  | 59,685 |  |  |  | 41,972 |  |  |  | 17,713 |  |  |  | 42.2 | % |
| Amortization of intangible assets |  |  | 25,823 |  |  |  | 26,054 |  |  |  | (231 | ) |  |  | -0.9 | % |
| Total operating expenses |  |  | 228,016 |  |  |  | 206,013 |  |  |  | 22,003 |  |  |  | 10.7 | % |
| Income from operations |  |  | 44,483 |  |  |  | 154,735 |  |  |  | (110,252 | ) |  |  | -71.3 | % |
| Total other expense, net |  |  | (22,473 | ) |  |  | (9,231 | ) |  |  | (13,242 | ) |  |  | 143.4 | % |
| Income before provision for income taxes |  |  | 22,010 |  |  |  | 145,504 |  |  |  | (123,494 | ) |  |  | -84.9 | % |
| Provision for income taxes |  |  | 7,849 |  |  |  | 28,608 |  |  |  | (20,759 | ) |  |  | -72.6 | % |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |  |  | (102,735 | ) |  |  | -87.9 | % |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |  |  | (1,307 | ) |  |  | -43.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |  | $ | (101,428 | ) |  |  | -89.1 | % |

[0001437749-23-013331:mdna:53]
[same as prior period, unchanged from 0001437749-22-026207:mdna:56]

[0001437749-23-013331:mdna:54]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 704,386 |  |  | $ | 964,674 |  |  | $ | (260,288 | ) |  |  | -27.0 | % |
| International |  |  | 183,524 |  |  |  | 171,182 |  |  |  | 12,342 |  |  |  | 7.2 | % |
| Total net sales |  | $ | 887,910 |  |  | $ | 1,135,856 |  |  | $ | (247,946 | ) |  |  | -21.8 | % |

[0001437749-23-013331:mdna:55]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |  | Three Months Ended March 31, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 704,386 |  |  | $ | 15,607 |  |  | $ | 719,993 |  |  | $ | 964,674 |  |  | $ | 10,270 |  |  | $ | 974,944 |  |
| International |  |  | 183,524 |  |  |  | 32,942 |  |  |  | 216,466 |  |  |  | 171,182 |  |  |  | 14,250 |  |  |  | 185,432 |  |
| Intercompany elimination |  |  | - |  |  |  | (48,549 | ) |  |  | (48,549 | ) |  |  | - |  |  |  | (24,520 | ) |  |  | (24,520 | ) |
| Total net sales |  | $ | 887,910 |  |  | $ | - |  |  | $ | 887,910 |  |  | $ | 1,135,856 |  |  | $ | - |  |  | $ | 1,135,856 |  |

[0001437749-23-013331:mdna:56]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 67,662 |  |  | $ | 170,421 |  |  | $ | (102,759 | ) |  |  | -60.3 | % |
| International |  |  | 32,413 |  |  |  | 25,992 |  |  |  | 6,421 |  |  |  | 24.7 | % |
| Total Adjusted EBITDA |  | $ | 100,075 |  |  | $ | 196,413 |  |  | $ | (96,338 | ) |  |  | -49.0 | % |

[0001437749-23-013331:mdna:57]
[same as prior period, unchanged from 0001437749-22-026207:mdna:60]

[0001437749-23-013331:mdna:58]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 418,863 |  |  | $ | 776,944 |  |  | $ | (358,081 | ) |  |  | -46.1 | % |
| Commercial & industrial products |  |  | 362,990 |  |  |  | 278,728 |  |  |  | 84,262 |  |  |  | 30.2 | % |
| Other |  |  | 106,057 |  |  |  | 80,184 |  |  |  | 25,873 |  |  |  | 32.3 | % |
| Total net sales |  | $ | 887,910 |  |  | $ | 1,135,856 |  |  | $ | (247,946 | ) |  |  | -21.8 | % |

[0001437749-23-013331:mdna:59]
Net sales.   Domestic segment total sales (including inter-segment sales) declined $255.0 million or 26.2% to $720.0 million in the first quarter of 2023, with the impact of acquisitions contributing approximately 3% revenue growth for the quarter. The decline in sales was driven primarily by lower home standby and clean energy product shipments. This decline was partially offset by strong C&I product sales growth across all channels, highlighted by national rental equipment, industrial distributors, telecom and other direct customers for "beyond standby" applications.

[0001437749-23-013331:mdna:60]
International segment total sales (including inter-segment sales) increased $31.0 million or 16.7% to $216.5 million, with the net impact of acquisitions and foreign currency contributing approximately 2% net headwind to revenue growth for the quarter. The sales growth for the segment was primarily driven by strength in the Company's European operations.

[0001437749-23-013331:mdna:61]
In addition, total contribution from non-annualized acquisitions for first quarter of 2023 was $27.3 million, including $25.9 million for the domestic segment and $1.4 million for the international segment.

[0001437749-23-013331:mdna:62]
Gross profit.  Gross profit margin for the first quarter of 2023 was 30.7% compared to 31.8% in the prior year first quarter. Margins declined primarily due to the significant impact of unfavorable sales mix, partially offset by the realization of previously implemented pricing actions and lower input costs.

[0001437749-23-013331:mdna:63]
Operating Expenses.  Operating expenses increased $22.0 million or 10.7%, as compared to the prior year first quarter, including a $5.8 million provision for a regulatory matter with the CPSC (see Note 15, “Commitments and Contingencies” for additional information). The remaining increase was primarily driven by increased marketing, promotion and employee costs as well as recurring operating expenses from recent acquisitions.

[0001437749-23-013331:mdna:64]
Other Expense.  The increase in other expense, net was driven primarily by higher interest expense due to higher borrowings and interest rates than the prior year quarter.

[0001437749-23-013331:mdna:65]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2023 and 2022 were 35.7% and 19.7%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation on a lower pre-tax earnings base in the current quarter compared to the prior year.

[0001437749-23-013331:mdna:66]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $12.4 million as compared to $113.9 million in the prior year first quarter. This decrease was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-23-013331:mdna:67]
Adjusted EBITDA.    Adjusted EBITDA for the Domestic segment in the first quarter of 2023 was $67.7 million or 9.4% of total domestic segment sales as compared to $170.4 million or 17.5% in the prior year quarter. Additionally, this lower margin performance was primarily driven by unfavorable sales mix and reduced operating leverage on lower shipments. The impact of acquisitions and continued energy technology growth investments negatively affected margins during the quarter. These impacts were partially offset by previously implemented pricing actions and lower input costs.

[0001437749-23-013331:mdna:68]
Adjusted EBITDA for the international segment in the first quarter of 2023, before deducting for non-controlling interests, was $32.4 million, or 15.0% of international total sales, as compared to $26.0 million, or 14.0% of total sales, in the prior year quarter. This strong margin performance was primarily driven by favorable price/cost dynamics and improved operating leverage on higher sales volumes.

[0001437749-23-013331:mdna:69]
Adjusted Net Income.    Adjusted Net Income of $39.4 million for the three months ended March 31, 2023 decreased 69.2% from $128.2 million for the three months ended March 31, 2022. This decrease was primarily driven by lower net income due to the factors outlined above, partially offset by the impact of various add-backs in the current year quarter.

[0001437749-23-013331:mdna:70]
[same as prior period, unchanged from 0001437749-22-026207:mdna:73]

[0001437749-23-013331:mdna:71]
[same as prior period, unchanged from 0001437749-22-026207:mdna:96]

[0001437749-23-013331:mdna:72]
Our primary cash requirements include payment for our raw materials and components, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, and capital expenditures. We finance our operations through cash flow generated from operations and borrowings under our revolving credit facility.

[0001437749-23-013331:mdna:73]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility.

[0001437749-23-013331:mdna:74]
In June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-013331:mdna:75]
As of March 31, 2023, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and $250 million of borrowings on our Revolving Facility, leaving $998.6 million of availability, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's Revolving Facility total leverage ratio and subject to a SOFR floor of 0.0%. At March 31, 2023 The interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 6.27%, 6.27%, and 6.52%, respectively. See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.

[0001437749-23-013331:mdna:76]
The Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in September 2023. Payments on the Revolving Facility are not due until 2027. Principal payments are due on these facilities as follows:

[0001437749-23-013331:mdna:77]
| 2023 |  | $ | 9,375 |
| 2024 |  |  | 28,125 |
| 2025 |  |  | 46,875 |
| 2026 |  |  | 595,625 |
| 2027 |  |  | 850,000 |
| Total |  | $ | 1,530,000 |

[0001437749-23-013331:mdna:78]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2023, our net secured leverage ratio was 2.13 to 1.00 times. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of March 31, 2023, the Company’s total leverage ratio was 2.22 to 1.00 times, and the Company's interest coverage ratio was 30.99 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of March 31, 2023.

[0001437749-23-013331:mdna:79]
As of March 31, 2023, we had $1,136 million of available liquidity comprised of $137.4 million of cash and cash equivalents and $998.6 million available under our Revolving Facility, net of outstanding letters of credit. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-23-013331:mdna:80]
In September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allowed for the repurchase of up to $250 million of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three months ended March 31, 2023. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 11,748,713 shares of our common stock for $777,379 (at an average cost per share of $66.17).

[0001437749-23-013331:mdna:81]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase program.

[0001437749-23-013331:mdna:82]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 10% of net sales for the three months ended March 31, 2023 and 2022. The amount financed by dealers which remained outstanding was $179.8 million and $212.2 million as of March 31, 2023, and December 31, 2022, respectively.

[0001437749-23-013331:mdna:83]
[same as prior period, unchanged from 0001437749-22-026207:mdna:108]

[0001437749-23-013331:mdna:84]
We believe that our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay principal on our outstanding debt, as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-23-013331:mdna:85]
[same as prior period, unchanged from 0001437749-22-026207:mdna:110]

[0001437749-23-013331:mdna:86]
Three months ended March 31, 2023 compared to the three months ended March 31, 2022

[0001437749-23-013331:mdna:87]
[same as prior period, unchanged from 0001437749-22-026207:mdna:112]

[0001437749-23-013331:mdna:88]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net cash used in operating activities |  | $ | (18,559 | ) |  | $ | (10,142 | ) |  | $ | (8,417 | ) |  |  | 83.0 | % |
| Net cash used in investing activities |  |  | (41,286 | ) |  |  | (27,375 | ) |  |  | (13,911 | ) |  |  | 50.8 | % |
| Net cash provided by financing activities |  |  | 63,673 |  |  |  | 95,601 |  |  |  | (31,928 | ) |  |  | -33.4 | % |

[0001437749-23-013331:mdna:89]
The decline in operating cash flows for the three months ended March 31, 2023 primarily represents lower operating earnings and a $36 million one-time cash tax payment for tax planning related to a recent acquisition, mostly offset by lower investment in working capital as compared to the prior year.

[0001437749-23-013331:mdna:90]
Net cash used in investing activities for the three months ended March 31, 2023 primarily represents cash payments of $24.0 million related to the purchase of property and equipment, $16.2 million for the acquisition of REFUstor and a $2.0 million minority investment in Rolling Energy Resources.

[0001437749-23-013331:mdna:91]
Net cash used in investing activities for the three months ended March 31, 2022 primarily represents cash payments of $28.2 million related to the purchase of property and equipment and $2.9 million related to an equity method investment in a tax equity fund, which were partially offset by cash proceeds from beneficial interests in securitization transactions of $1.6 million, cash proceeds on the sale of an investment of $1.3 million, and cash proceeds from the sale of property and equipment of $1.9 million.

[0001437749-23-013331:mdna:92]
Net cash provided by financing activities for the three months ended March 31, 2023 primarily represents proceeds of $267.9 million from long-term borrowings, $19.5 million from short-term borrowings, and $5.0 million from the exercise of stock options. These cash proceeds were partially offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $118.7 million of debt repayments ($5.1 million of short-term borrowings and $113.6 million of long-term borrowings and finance lease obligations), and $4.7 million of taxes paid related to equity awards.

[0001437749-23-013331:mdna:93]
Net cash provided by financing activities for the three months ended March 31, 2022 primarily represents proceeds of $136.7 million from short-term borrowings, $110.0 million from long-term borrowings, and $9.9 million from the exercise of stock options. These cash proceeds were partially offset by $126.3 million of debt repayments ($124.6 million of short-term borrowings and $1.7 million of long-term borrowings and finance lease obligations), and $34.6 million of taxes paid related to equity awards.

[0001437749-23-013331:mdna:94]
[same as prior period, unchanged from 0001437749-22-026207:mdna:118]

[0001437749-23-013331:mdna:95]
There have been no material changes to our contractual obligations since the February 22, 2023 filing of our Annual Report on Form 10-K for the year ended December 31, 2022, except for the Revolving Facility draws as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-23-013331:mdna:96]
[same as prior period, unchanged from 0001437749-22-026207:mdna:120]

[0001437749-23-013331:mdna:97]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2022, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-23-013331:mdna:98]
There have been no material changes in our critical accounting policies since the February 22, 2023 filing of our Annual Report on Form 10-K for the year ended December 31, 2022.

[0001437749-23-013331:mdna:99]
[same as prior period, unchanged from 0001437749-22-026207:mdna:127]

[0001437749-23-013331:mdna:100]
[same as prior period, unchanged from 0001437749-22-026207:mdna:128]

[0001437749-23-013331:mdna:101]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-013331:mdna:102]
[same as prior period, unchanged from 0001437749-22-026207:mdna:130]

[0001437749-23-013331:mdna:103]
[same as prior period, unchanged from 0001437749-22-026207:mdna:131]

[0001437749-23-013331:mdna:104]
[same as prior period, unchanged from 0001437749-22-026207:mdna:132]

[0001437749-23-013331:mdna:105]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2023 Proxy Statement; |

[0001437749-23-013331:mdna:106]
[same as prior period, unchanged from 0001437749-22-026207:mdna:134]

[0001437749-23-013331:mdna:107]
[same as prior period, unchanged from 0001437749-22-026207:mdna:135]

[0001437749-23-013331:mdna:108]
[same as prior period, unchanged from 0001437749-22-026207:mdna:136]

[0001437749-23-013331:mdna:109]
[same as prior period, unchanged from 0001437749-22-026207:mdna:137]

[0001437749-23-013331:mdna:110]
[same as prior period, unchanged from 0001437749-22-026207:mdna:138]

[0001437749-23-013331:mdna:111]
[same as prior period, unchanged from 0001437749-22-026207:mdna:139]

[0001437749-23-013331:mdna:112]
[same as prior period, unchanged from 0001437749-22-026207:mdna:140]

[0001437749-23-013331:mdna:113]
[same as prior period, unchanged from 0001437749-22-026207:mdna:141]

[0001437749-23-013331:mdna:114]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-23-013331:mdna:115]
[same as prior period, unchanged from 0001437749-22-026207:mdna:143]

[0001437749-23-013331:mdna:116]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-23-013331:mdna:117]
[same as prior period, unchanged from 0001437749-22-026207:mdna:145]

[0001437749-23-013331:mdna:118]
|  | • | Adjusted EBITDA does not reflect our capital expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-23-013331:mdna:119]
[same as prior period, unchanged from 0001437749-22-026207:mdna:147]

[0001437749-23-013331:mdna:120]
[same as prior period, unchanged from 0001437749-22-026207:mdna:148]

[0001437749-23-013331:mdna:121]
[same as prior period, unchanged from 0001437749-22-026207:mdna:149]

[0001437749-23-013331:mdna:122]
[same as prior period, unchanged from 0001437749-22-026207:mdna:150]

[0001437749-23-013331:mdna:123]
[same as prior period, unchanged from 0001437749-22-026207:mdna:151]

[0001437749-23-013331:mdna:124]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-23-013331:mdna:125]
[same as prior period, unchanged from 0001437749-22-026207:mdna:153]

[0001437749-23-013331:mdna:126]
[same as prior period, unchanged from 0001437749-22-026207:mdna:154]

[0001437749-23-013331:mdna:127]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |
| Interest expense |  |  | 22,995 |  |  |  | 9,554 |  |
| Depreciation and amortization |  |  | 39,951 |  |  |  | 38,461 |  |
| Provision for income taxes |  |  | 7,849 |  |  |  | 28,608 |  |
| Non-cash write-down and other adjustments (a) |  |  | (3,160 | ) |  |  | (7,792 | ) |
| Non-cash share-based compensation expense (b) |  |  | 10,334 |  |  |  | 8,827 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,091 |  |  |  | 989 |  |
| Business optimization and other charges (d) |  |  | 1,100 |  |  |  | 1,159 |  |
| Provision for regulatory charges (e) |  |  | 5,800 |  |  |  | - |  |
| Other |  |  | (46 | ) |  |  | (289 | ) |
| Adjusted EBITDA |  |  | 100,075 |  |  |  | 196,413 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,133 |  |  |  | 3,425 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 96,942 |  |  | $ | 192,988 |  |

[0001437749-23-013331:mdna:128]
[same as prior period, unchanged from 0001437749-22-026207:mdna:156]

[0001437749-23-013331:mdna:129]
|  | • | The gains/losses on disposals of assets and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations. |

[0001437749-23-013331:mdna:130]
|  | • | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |
|  | • | Purchase accounting and contingent consideration related adjustments relate to the acquisition of businesses and the accounting related to those acquisitions. |

[0001437749-23-013331:mdna:131]
[same as prior period, unchanged from 0001437749-22-026207:mdna:159]

[0001437749-23-013331:mdna:132]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-23-013331:mdna:133]
(d)  Represents severance and other non-recurring restructuring charges.

[0001437749-23-013331:mdna:134]
(e)  Represents a provision of $5.8 million for a matter with the Consumer Product Safety Commission concerning the imposition of penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021.

[0001437749-23-013331:mdna:135]
[same as prior period, unchanged from 0001437749-22-026207:mdna:164]

[0001437749-23-013331:mdna:136]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses or charges, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-013331:mdna:137]
[same as prior period, unchanged from 0001437749-22-026207:mdna:166]

[0001437749-23-013331:mdna:138]
[same as prior period, unchanged from 0001437749-22-026207:mdna:167]

[0001437749-23-013331:mdna:139]
[same as prior period, unchanged from 0001437749-22-026207:mdna:168]

[0001437749-23-013331:mdna:140]
[same as prior period, unchanged from 0001437749-22-026207:mdna:169]

[0001437749-23-013331:mdna:141]
[same as prior period, unchanged from 0001437749-22-026207:mdna:170]

[0001437749-23-013331:mdna:142]
[same as prior period, unchanged from 0001437749-22-026207:mdna:171]

[0001437749-23-013331:mdna:143]
[same as prior period, unchanged from 0001437749-22-026207:mdna:172]

[0001437749-23-013331:mdna:144]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |
| Amortization of intangible assets |  |  | 25,823 |  |  |  | 26,054 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 954 |  |  |  | 637 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 718 |  |  |  | (5,756 | ) |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (c) |  |  | 1,100 |  |  |  | 1,159 |  |
| Provision for regulatory charges (d) |  |  | 5,800 |  |  |  | - |  |
| Tax effect of add backs (e) |  |  | (7,131 | ) |  |  | (9,256 | ) |
| Adjusted net income |  |  | 41,306 |  |  |  | 129,505 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,861 |  |  |  | 1,355 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 39,445 |  |  | $ | 128,150 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.63 |  |  | $ | 1.98 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,294,447 |  |  |  | 64,828,819 |  |

[0001437749-23-013331:mdna:145]
(a)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-23-013331:mdna:146]
(b)  Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-23-013331:mdna:147]
(c)  Represents severance and other non-recurring restructuring charges.

[0001437749-23-013331:mdna:148]
(d)  Represents a provision of $5.8 million for a matter with the Consumer Product Safety Commission concerning the imposition of penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021.

[0001437749-23-013331:mdna:149]
(e)  In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the first quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the first quarter ended 2022 of $135,271 or $2.09.  Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the first quarter ended 2022 is $128,150 or $1.98.

[0001437749-23-013331:mdna:150]
[same as prior period, unchanged from 0001437749-22-026207:mdna:179]

[0001437749-23-013331:mdna:151]
[same as prior period, unchanged from 0001437749-22-026207:mdna:180]
