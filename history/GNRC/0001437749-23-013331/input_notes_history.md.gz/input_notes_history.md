# GNRC note change history — 0001437749-22-026207 → 0001437749-23-013331


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001437749-23-013331:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2023 and  December 31, 2022 was approximately $179.8 million and $212.2 million respectively.
  (was, 2022-11-07, similarity 0.9747):
[0001437749-22-026207:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2022 and  December 31, 2021 was approximately $222,400 and $115,900, respectively.

- changed (2023-05-09):
[0001437749-23-013331:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred. The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which Power Home Solar characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll Power Home Solar’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Company intends to vigorously defend against the claims in the complaint, whichever forum in which it  may proceed.
  (was, 2022-11-07, similarity 0.7785):
[0001437749-22-026207:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”).  The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred.  The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement.  On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors.  The petition listed a $17,700 liability to Generac Power, which Power Home Solar characterized as disputed.  The $17,700 claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for.  The parties agreed to toll Power Home Solar’s deadline to respond to the motion to dismiss after Power Home Solar filed the petition for bankruptcy to allow the bankruptcy trustee to evaluate the complaint.  The Company intends to vigorously defend against the claims in the complaint, whichever forum it  may proceed in.

- added (2023-05-09):
[0001437749-23-013331:note_history:3]
Five additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  March 21, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative class allegedly incurred. The cases are pending in the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386-NJ and Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034-NJ), the Northern District of California (Moon v. Generac Power Systems, Inc. et al., Case No. 22-cv-09183-CRB), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203-TLN), and the County of Wake, State of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23CV006415-910. Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints. Generac Power and the Company have filed motions to dismiss in the Haak, Basler, and Moon cases.

- added (2023-05-09):
[0001437749-23-013331:note_history:4]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and others seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. Subsequently, the parties to each of the federal court actions filed motions to stay those actions until the Judicial Panel on Multidistrict Litigation (“JPML”) determines whether to grant the MDL Motion. Those motions to stay were granted by the respective courts. On  March 28, 2023, Generac Power and the plaintiffs in the other putative federal class actions each filed responses to the MDL Motion in which all agreed that the pending cases should be transferred to the proposed Multidistrict Litigation. A hearing on the MDL Motion is scheduled for  May 25, 2023.

- added (2023-05-09):
[0001437749-23-013331:note_history:5]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. Motions to consolidate the putative class actions and to appoint a lead plaintiff have been filed and are pending with the court. The Company disputes the allegations and intends to vigorously defend against the claims in the consolidated class action.

- added (2023-05-09):
[0001437749-23-013331:note_history:6]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief.

- added (2023-05-09):
[0001437749-23-013331:note_history:7]
Between  March 20, 2023 and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

- changed (2023-05-09):
[0001437749-23-013331:note_history:8]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resources Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.
  (was, 2022-11-07, similarity 0.9776):
[0001437749-22-026207:note_history:8]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”).  The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

- added (2023-05-09):
[0001437749-23-013331:note_history:9]
On  November 30, 2022, the U.S. Consumer Product Safety Commission ("CPSC") notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act ("CPSA"), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the CPSC provisionally accepted the terms of a mutual settlement agreement between the CPSC and the Company. The parties entered into such agreement for settlement purposes only. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement, once finalized, would require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. The settlement agreement with CPSC under its current terms will not have a material adverse effect on the Company’s financial condition, results of operations or cash flows.

- changed (2023-05-09):
[0001437749-23-013331:note_history:10]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.
  (was, 2022-11-07, similarity 0.9994):
[0001437749-22-026207:note_history:10]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserve
      may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001437749-23-013331:note_history:11]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- added (2023-05-09):
[0001437749-23-013331:note_history:12]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. (Blue Pillar), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems (REFUstor), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market. |

- changed (2023-05-09):
[0001437749-23-013331:note_history:13]
The condensed consolidated balance sheet as of  March 31, 2023, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2023 and 2022, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2022-11-07, similarity 0.8989):
[0001437749-22-026207:note_history:13]
The condensed consolidated balance sheet as of  September 30, 2022, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2023-05-09):
[0001437749-22-026207:note_history:14]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- removed (2023-05-09):
[0001437749-22-026207:note_history:15]
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security, and peace of mind. |
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |

- removed (2023-05-09):
[0001437749-22-026207:note_history:16]
Summary of Accounting Policies

- removed (2023-05-09):
[0001437749-22-026207:note_history:17]
Goodwill and Other Indefinite-Lived Intangible Assets

- removed (2023-05-09):
[0001437749-22-026207:note_history:18]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis.  As disclosed in Note 2, "Significant Accounting Policies - Goodwill and Other Indefinite-Lived Intangible Assets," to the consolidated financial statements in Item 8 of its 2021 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2021.

- removed (2023-05-09):
[0001437749-22-026207:note_history:19]
During the three months ended  September 30, 2022, the Company identified a triggering event for its clean energy reporting unit requiring an interim impairment assessment to be performed due to the loss of a key customer as well as certain clean energy product warranty-related matters. Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test were based on updated projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows as well as the current discount rate based on the estimated weighted average cost of capital for the business.

- removed (2023-05-09):
[0001437749-22-026207:note_history:20]
Based on the interim impairment assessment as of  September 30, 2022, the Company determined that the goodwill and indefinite-lived intangible assets ascribed to the clean energy reporting unit are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001437749-23-013331:note_history:21]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $64,093 and $48,990, respectively.

- added (2023-05-09):
[0001437749-23-013331:note_history:22]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,614 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,765 |  |  |  | 27,420 |  |
| Other |  |  | 1,233 |  |  |  | 966 |  |
| Total |  |  | 1,545,384 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 15,050 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 2,979 |  |  |  | 2,650 |  |
| Total |  | $ | 1,527,355 |  |  | $ | 1,369,085 |  |

- added (2023-05-09):
[0001437749-23-013331:note_history:23]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  March 31, 2023 are as follows:

- added (2023-05-09):
[0001437749-23-013331:note_history:24]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

- added (2023-05-09):
[0001437749-23-013331:note_history:25]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in  September 2023, as noted in the table above.

- changed (2023-05-09):
[0001437749-23-013331:note_history:26]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2023, was 6.52%.
  (was, 2022-11-07, similarity 0.6693):
[0001437749-22-026207:note_history:26]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75%, or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.

- changed (2023-05-09):
[0001437749-23-013331:note_history:27]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2023, the Company’s net secured leverage ratio was 2.13 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.
  (was, 2022-11-07, similarity 0.9776):
[0001437749-22-026207:note_history:27]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2022, the Company’s net secured leverage ratio was 1.25 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2023-05-09):
[0001437749-23-013331:note_history:28]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2022-11-07, similarity 0.8962):
[0001437749-22-026207:note_history:28]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

- changed (2023-05-09):
[0001437749-23-013331:note_history:29]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  March 31, 2023, was 6.27%.
  (was, 2022-11-07, similarity 0.8372):
[0001437749-22-026207:note_history:29]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

- changed (2023-05-09):
[0001437749-23-013331:note_history:30]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2023, the Company’s total leverage ratio was 2.22 to 1.00 times, and the Company's interest coverage ratio was 30.99 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2023.
  (was, 2022-11-07, similarity 0.9596):
[0001437749-22-026207:note_history:30]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2022, the Company’s total leverage ratio was 1.33 to 1.00 times, and the Company's interest coverage ratio was 20.81 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2022.

- changed (2023-05-09):
[0001437749-23-013331:note_history:31]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2022-11-07, similarity 0.9965):
[0001437749-22-026207:note_history:31]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender by lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2023-05-09):
[0001437749-23-013331:note_history:32]
As of  March 31, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $998,580 of availability, net of outstanding letters of credit.
  (was, 2022-11-07, similarity 0.9638):
[0001437749-22-026207:note_history:32]
As of  September 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,248,580 of availability, net of outstanding letters of credit.

- added (2023-05-09):
[0001437749-23-013331:note_history:33]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.

- removed (2023-05-09):
[0001437749-22-026207:note_history:34]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

- removed (2023-05-09):
[0001437749-22-026207:note_history:35]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 64,588 |  |  |  | 72,035 |  |
| Total |  | $ | 64,588 |  |  | $ | 72,035 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:36]
As of  September 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

- removed (2023-05-09):
[0001437749-22-026207:note_history:37]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,541 | ) |  |  | (13,214 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,842 |  |  |  | 39,175 |  |
| Other |  |  | 611 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,912 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 5,057 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,999 |  |  |  | 4,209 |  |
| Total |  | $ | 1,282,856 |  |  | $ | 902,091 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:38]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date.

- removed (2023-05-09):
[0001437749-22-026207:note_history:39]
The Company’s credit agreements also originally provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- removed (2023-05-09):
[0001437749-22-026207:note_history:40]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

- removed (2023-05-09):
[0001437749-22-026207:note_history:41]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of the prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- removed (2023-05-09):
[0001437749-22-026207:note_history:42]
The Tranche A Term Loan Facility is repayable in quarterly installments in total for the twelve months ended 0.0% of the original principal amount during the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, in total for the twelve months ended 2.5% of the original principal amount during the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, in total for the twelve months ended 5.0% of the original principal amount during the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, in total for the twelve months ended 7.5% of the original principal amount during the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and in total for the twelve months ended 10.0% of the original principal amount during the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001437749-23-013331:note_history:43]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,614 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,765 |  |  |  | 27,420 |  |
| Other |  |  | 1,233 |  |  |  | 966 |  |
| Total |  |  | 1,545,384 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 15,050 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 2,979 |  |  |  | 2,650 |  |
| Total |  | $ | 1,527,355 |  |  | $ | 1,369,085 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:44]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,541 | ) |  |  | (13,214 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,842 |  |  |  | 39,175 |  |
| Other |  |  | 611 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,912 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 5,057 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,999 |  |  |  | 4,209 |  |
| Total |  | $ | 1,282,856 |  |  | $ | 902,091 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2023-05-09):
[0001437749-23-013331:note_history:45]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-09):
[0001437749-22-026207:note_history:46]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 64,588 |  |  |  | 72,035 |  |
| Total |  | $ | 64,588 |  |  | $ | 72,035 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001437749-23-013331:note_history:47]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |

- added (2023-05-09):
[0001437749-23-013331:note_history:48]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 750,327 |  |  | $ | 26,617 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 145,737 |  |  |  | 132,991 |  |  |  | 278,728 |  |
| Other |  |  | 68,610 |  |  |  | 11,574 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | 1,135,856 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:49]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:50]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 585,150 |  |  | $ | 23,666 |  |  | $ | 608,816 |  |
| Commercial & industrial products |  |  | 140,824 |  |  |  | 117,485 |  |  |  | 258,309 |  |
| Other |  |  | 64,790 |  |  |  | 10,783 |  |  |  | 75,573 |  |
| Total net sales |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | 942,698 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:51]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |

- removed (2023-05-09):
[0001437749-22-026207:note_history:52]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,690,707 |  |  | $ | 60,250 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 402,357 |  |  |  | 312,637 |  |  |  | 714,994 |  |
| Other |  |  | 174,584 |  |  |  | 29,578 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | 2,670,113 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001437749-23-013331:note_history:53]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $25,326 and $33,551 on  March 31, 2023 and  December 31, 2022, respectively. During the three months ended  March 31, 2023, the Company recognized revenue of $11,290 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

- removed (2023-05-09):
[0001437749-22-026207:note_history:54]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $34,257 and $27,388 on  September 30, 2022 and  December 31, 2021, respectively. During the nine months ended  September 30, 2022, the Company recognized revenue of $24,160 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-05-09):
[0001437749-22-026207:note_history:55]
16. Subsequent Events

- removed (2023-05-09):
[0001437749-22-026207:note_history:56]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial internet of things (IoT) platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control.
