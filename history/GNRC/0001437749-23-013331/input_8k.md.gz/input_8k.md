# GNRC 8-K — 0001437749-23-012184 filed 2023-05-03

## item codes, every 8-K on or before 2023-05-09

- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2023-05-09

- none on or before 2023-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001437749-23-012184:8k_2_02:1]
EX-99.1
2
ex_511687.htm
EXHIBIT 99.1

[0001437749-23-012184:8k_2_02:2]
ex_511687.htm

[0001437749-23-012184:8k_2_02:3]
Exhibit 99.1

[0001437749-23-012184:8k_2_02:4]
Generac Reports First Quarter 2023 Results

[0001437749-23-012184:8k_2_02:5]
WAUKESHA, WISCONSIN (May 3, 2023) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2023 and provided an update on its outlook for the full year 2023.

[0001437749-23-012184:8k_2_02:6]
First Quarter 2023 Highlights

[0001437749-23-012184:8k_2_02:7]
| ● | Net sales decreased 22% to $888 million during the first quarter of 2023 as compared to $1.14 billion in the prior-year first quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, decreased approximately 24%. |

[0001437749-23-012184:8k_2_02:8]
|  | - | Residential product sales declined 46% to $419 million as compared to $777 million last year. |

[0001437749-23-012184:8k_2_02:9]
|  | - | Commercial & Industrial (“C&I”) product sales increased 30% to $363 million as compared to $279 million in the prior year. |

[0001437749-23-012184:8k_2_02:10]
| ● | Net income attributable to the Company during the first quarter was $12 million, or $0.05 per share, as compared to $114 million, or $1.57 per share, for the same period of 2022. |

[0001437749-23-012184:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $39 million, or $0.63 per share, as compared to $128 million, or $1.98 per share, in the first quarter of 2022. |

[0001437749-23-012184:8k_2_02:12]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $100 million, or 11.3% of net sales, as compared to $196 million, or 17.3% of net sales, in the prior year. |

[0001437749-23-012184:8k_2_02:13]
| ● | On February 1st, the Company closed on the acquisition of REFU Storage Systems, a developer and supplier of battery storage hardware products, advanced software, and platform services for commercial and industrial applications, headquartered in Pfullingen, Germany. |

[0001437749-23-012184:8k_2_02:14]
| ● | On March 8th, the Company purchased the remaining 20% minority ownership interest in Pramac, bringing the Company’s total ownership to 100%. Headquartered in Italy, Pramac is a designer and manufacturer of stationary, mobile and portable generators along with energy storage solutions sold through a broad distribution network across the world. The Company’s initial majority ownership position was acquired in 2016. |

[0001437749-23-012184:8k_2_02:15]
| ● | The Company is maintaining its full-year 2023 net sales guidance of a decline of approximately -6 to -10%. Adjusted EBITDA margin, before deducting for non-controlling interests, is still expected to be approximately 17.0 to 18.0%. |

[0001437749-23-012184:8k_2_02:16]
“As expected, first quarter sales were down year-over-year due to a challenging prior year comparison related to the significant excess backlog for home standby products as we entered 2022,” said Aaron Jagdfeld, President and Chief Executive Officer. “In addition, residential product sales in the current year quarter were impacted by elevated levels of field inventory for home standby generators and a decline in clean energy products as we continue to expand our distribution network. However, power outage activity in the quarter was well above the long-term average, helping drive significant year-over-year growth for home standby in-home consultations and a meaningful reduction in field inventory levels for these products. Our global C&I product sales were at all-time highs in the quarter and exceeded our expectations with strength across all channels domestically and most regions internationally. As a result of these factors, we are maintaining our full-year 2023 net sales and adjusted EBITDA margin guidance.”

[0001437749-23-012184:8k_2_02:17]
Additional First Quarter 2023 Consolidated Highlights

[0001437749-23-012184:8k_2_02:18]
Gross profit margin was 30.7% as compared to 31.8% in the prior-year first quarter. This margin performance was primarily due to the significant impact of unfavorable sales mix, partially offset by the realization of previously implemented pricing actions and lower input costs.

[0001437749-23-012184:8k_2_02:19]
Operating expenses increased $22.0 million, or 10.7%, as compared to the first quarter of 2022 primarily driven by increased marketing, promotion, and employee costs, certain legal and regulatory expenses, and the impact of recurring operating expenses from recent acquisitions.

[0001437749-23-012184:8k_2_02:20]
Provision for income taxes for the current year quarter was $7.9 million, or an effective tax rate of 35.7%, as compared to $28.6 million, or a 19.7% effective tax rate, for the prior year. The increase in the effective tax rate was primarily due to a lower benefit from equity compensation on a low pre-tax earnings base in the current year quarter as compared to the prior year.

[0001437749-23-012184:8k_2_02:21]
Cash flow used in operations was $(18.6) million during the first quarter, as compared to $(10.1) million in the prior year.  Free cash flow, as defined in the accompanying reconciliation schedules, was $(41.7) million as compared to $(36.8) million in the first quarter of 2022. The modest decline in free cash flow in the current year quarter was primarily due to lower operating earnings and a $36 million one-time cash tax payment for tax planning related to a recent acquisition, mostly offset by lower investment in working capital as compared to the prior year.

[0001437749-23-012184:8k_2_02:22]
Business Segment Results

[0001437749-23-012184:8k_2_02:23]
Domestic Segment

[0001437749-23-012184:8k_2_02:24]
Domestic segment total sales (including inter-segment sales, as disclosed in the accompanying schedule) decreased 26% to $720.0 million as compared to $974.9 million in the prior year quarter, with the impact of acquisitions contributing approximately 3% revenue growth for the quarter. The decline in core sales was driven primarily by lower home standby and clean energy product shipments. This decline was partially offset by strong growth in C&I product sales across all channels, highlighted by national rental equipment, industrial distributors, telecom, and other direct customers for “beyond standby” applications.

[0001437749-23-012184:8k_2_02:25]
Adjusted EBITDA for the segment was $67.7 million, or 9.4% of total sales, as compared to $170.4 million in the prior year, or 17.5% of total sales. This margin performance was primarily driven by unfavorable sales mix and reduced operating leverage on lower shipments. Additionally, the impact of acquisitions and continued energy technology growth investments negatively affected margins during the quarter. These impacts were partially offset by previously implemented pricing actions and lower input costs.

[0001437749-23-012184:8k_2_02:26]
International Segment

[0001437749-23-012184:8k_2_02:27]
International segment total sales (including inter-segment sales, as disclosed in the accompanying schedule) increased 17% to $216.5 million as compared to $185.4 million in the prior year quarter, with the net impact of acquisitions and foreign currency contributing approximately 2% net headwind to revenue growth for the quarter. The core sales growth for the segment was driven primarily by strength in our European operations.

[0001437749-23-012184:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $32.4 million, or 15.0% of total sales, as compared to $26.0 million, or 14.0% of total sales, in the prior year. This strong margin performance was primarily driven by favorable price/cost dynamics and improved operating leverage on higher sales volumes.

[0001437749-23-012184:8k_2_02:29]
Updated 2023 Outlook

[0001437749-23-012184:8k_2_02:30]
Due to ongoing strength in leading indicators of demand for home standby generators and significant backlog for C&I products, the Company is maintaining its full-year 2023 net sales guidance. Consistent with the prior outlook, shipments of residential products are still expected to remain soft during the second quarter as home standby field inventory levels continue to normalize, with a return to year-over-year sales growth in the second half of the year partially offsetting the expected first half decline. In addition, our outlook for C&I product sales to grow at a mid to high-single digit rate during the year remains unchanged. Accordingly, the Company continues to expect full-year net sales to decline between -6 to -10% as compared to the prior year, which includes approximately 1 to 2% of net favorable impact from acquisitions and foreign currency.

[0001437749-23-012184:8k_2_02:31]
Additionally, the Company continues to expect net income margin, before deducting for non-controlling interests, to be approximately 7.5 to 8.5% for the full-year 2023. The corresponding adjusted EBITDA margin is still expected to be approximately 17.0 to 18.0% and disproportionately weighted towards the second half of the year.

[0001437749-23-012184:8k_2_02:32]
Operating and free cash flow generation is expected to return to strong levels for the full year, with conversion of adjusted net income to free cash flow expected to be well over 100%.

[0001437749-23-012184:8k_2_02:33]
Conference Call and Webcast

[0001437749-23-012184:8k_2_02:34]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, May 3, 2023 to discuss first quarter 2023 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIff9bb98e6aa7405b94d6f836a70bd366. Individuals that wish to listen via telephone will be given dial-in information.

[0001437749-23-012184:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-23-012184:8k_2_02:36]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-23-012184:8k_2_02:37]
About Generac

[0001437749-23-012184:8k_2_02:38]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-23-012184:8k_2_02:39]
Forward-looking Information

[0001437749-23-012184:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-23-012184:8k_2_02:41]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-23-012184:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-23-012184:8k_2_02:43]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-23-012184:8k_2_02:44]
|  | ● | availability of both labor and key components from our manufacturing operations and global supply chain, including single-sourced components and contract manufacturers, needed in producing our products; |

[0001437749-23-012184:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-23-012184:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-23-012184:8k_2_02:47]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-23-012184:8k_2_02:48]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |
|  | ● | our dependence on our distribution network; |
|  | ● | our ability to remain competitive by investing in, developing or adapting to changing technologies and manufacturing techniques, as well as protecting our intellectual property rights; |
|  | ● | loss of our key management and employees; |
|  | ● | increase in product and other liability claims or recalls; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |
|  | ● | significant legal proceedings, claims, lawsuits or government investigations; and |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-012184:8k_2_02:49]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2022 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-23-012184:8k_2_02:50]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-23-012184:8k_2_02:51]
Non-GAAP Financial Metrics

[0001437749-23-012184:8k_2_02:52]
Core Sales

[0001437749-23-012184:8k_2_02:53]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-23-012184:8k_2_02:54]
Adjusted EBITDA

[0001437749-23-012184:8k_2_02:55]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-012184:8k_2_02:56]
Adjusted Net Income

[0001437749-23-012184:8k_2_02:57]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-23-012184:8k_2_02:58]
Free Cash Flow

[0001437749-23-012184:8k_2_02:59]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-23-012184:8k_2_02:60]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-23-012184:8k_2_02:61]
SOURCE: Generac Holdings Inc.

[0001437749-23-012184:8k_2_02:62]
CONTACT:

[0001437749-23-012184:8k_2_02:63]
Michael W. Harris

[0001437749-23-012184:8k_2_02:64]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-23-012184:8k_2_02:65]
(262) 506-6064

[0001437749-23-012184:8k_2_02:66]
InvestorRelations@generac.com

[0001437749-23-012184:8k_2_02:67]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-012184:8k_2_02:68]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales |  | $ | 887,910 |  |  | $ | 1,135,856 |  |
| Costs of goods sold |  |  | 615,411 |  |  |  | 775,108 |  |
| Gross profit |  |  | 272,499 |  |  |  | 360,748 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 100,688 |  |  |  | 98,243 |  |
| Research and development |  |  | 41,820 |  |  |  | 39,744 |  |
| General and administrative |  |  | 59,685 |  |  |  | 41,972 |  |
| Amortization of intangibles |  |  | 25,823 |  |  |  | 26,054 |  |
| Total operating expenses |  |  | 228,016 |  |  |  | 206,013 |  |
| Income from operations |  |  | 44,483 |  |  |  | 154,735 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (22,995 | ) |  |  | (9,554 | ) |
| Investment income |  |  | 688 |  |  |  | 77 |  |
| Other, net |  |  | (166 | ) |  |  | 246 |  |
| Total other expense, net |  |  | (22,473 | ) |  |  | (9,231 | ) |
| Income before provision for income taxes |  |  | 22,010 |  |  |  | 145,504 |  |
| Provision for income taxes |  |  | 7,849 |  |  |  | 28,608 |  |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.06 |  |  | $ | 1.61 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,556,044 |  |  |  | 63,449,380 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.05 |  |  | $ | 1.57 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,294,447 |  |  |  | 64,828,819 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 35,362 |  |  | $ | 122,365 |  |

[0001437749-23-012184:8k_2_02:69]
5

[0001437749-23-012184:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-012184:8k_2_02:71]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 137,365 |  |  | $ | 132,723 |  |
| Accounts receivable, less allowance for credit losses of $28,660 and $27,664 at March 31, 2023 and December 31, 2022, respectively |  |  | 490,384 |  |  |  | 522,458 |  |
| Inventories |  |  | 1,438,296 |  |  |  | 1,405,384 |  |
| Prepaid expenses and other assets |  |  | 119,729 |  |  |  | 121,783 |  |
| Total current assets |  |  | 2,185,774 |  |  |  | 2,182,348 |  |
| Property and equipment, net |  |  | 490,143 |  |  |  | 467,604 |  |
| Customer lists, net |  |  | 202,556 |  |  |  | 206,987 |  |
| Patents and technology, net |  |  | 445,333 |  |  |  | 454,757 |  |
| Other intangible assets, net |  |  | 37,633 |  |  |  | 41,719 |  |
| Tradenames, net |  |  | 225,198 |  |  |  | 227,251 |  |
| Goodwill |  |  | 1,426,332 |  |  |  | 1,400,880 |  |
| Deferred income taxes |  |  | 8,320 |  |  |  | 12,746 |  |
| Operating lease and other assets |  |  | 189,843 |  |  |  | 175,170 |  |
| Total assets |  | $ | 5,211,132 |  |  | $ | 5,169,462 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 64,093 |  |  | $ | 48,990 |  |
| Accounts payable |  |  | 426,191 |  |  |  | 446,050 |  |
| Accrued wages and employee benefits |  |  | 48,088 |  |  |  | 45,741 |  |
| Accrued product warranty |  |  | 80,902 |  |  |  | 89,141 |  |
| Other accrued liabilities |  |  | 273,039 |  |  |  | 349,389 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 18,029 |  |  |  | 12,733 |  |
| Total current liabilities |  |  | 910,342 |  |  |  | 992,044 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,527,355 |  |  |  | 1,369,085 |  |
| Deferred income taxes |  |  | 110,447 |  |  |  | 125,691 |  |
| Operating lease and other long-term liabilities |  |  | 317,795 |  |  |  | 312,916 |  |
| Total liabilities |  |  | 2,865,939 |  |  |  | 2,799,736 |  |
| Redeemable noncontrolling interest |  |  | 3,814 |  |  |  | 110,471 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,052,760 and 72,701,275 shares issued at March 31, 2023 and December 31, 2022, respectively |  |  | 731 |  |  |  | 728 |  |
| Additional paid-in capital |  |  | 1,042,786 |  |  |  | 1,016,138 |  |
| Treasury stock, at cost, 10,855,203 and 11,284,350 shares at March 31, 2023 and December 31, 2022, respectively |  |  | (779,533 | ) |  |  | (808,491 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,319,638 |  |  |  | 2,316,224 |  |
| Accumulated other comprehensive loss |  |  | (42,343 | ) |  |  | (65,102 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,339,163 |  |  |  | 2,257,381 |  |
| Noncontrolling interests |  |  | 2,216 |  |  |  | 1,874 |  |
| Total stockholders’ equity |  |  | 2,341,379 |  |  |  | 2,259,255 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,211,132 |  |  | $ | 5,169,462 |  |

[0001437749-23-012184:8k_2_02:72]
6

[0001437749-23-012184:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-012184:8k_2_02:74]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 14,161 |  |  | $ | 116,896 |  |
| Adjustment to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 14,128 |  |  |  | 12,407 |  |
| Amortization of intangible assets |  |  | 25,823 |  |  |  | 26,054 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 954 |  |  |  | 637 |  |
| Deferred income taxes |  |  | (10,712 | ) |  |  | (49,156 | ) |
| Share-based compensation expense |  |  | 10,334 |  |  |  | 8,827 |  |
| Loss (gain) on disposal of assets |  |  | 30 |  |  |  | (571 | ) |
| Other noncash charges |  |  | (160 | ) |  |  | (6,446 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 33,925 |  |  |  | (66,510 | ) |
| Inventories |  |  | (23,820 | ) |  |  | (147,250 | ) |
| Other assets |  |  | (5,576 | ) |  |  | 2,253 |  |
| Accounts payable |  |  | (24,488 | ) |  |  | 26,363 |  |
| Accrued wages and employee benefits |  |  | 1,630 |  |  |  | (21,558 | ) |
| Other accrued liabilities |  |  | (53,790 | ) |  |  | 102,015 |  |
| Excess tax benefits from equity awards |  |  | (998 | ) |  |  | (14,103 | ) |
| Net cash used in operating activities |  |  | (18,559 | ) |  |  | (10,142 | ) |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 84 |  |  |  | 1,864 |  |
| Proceeds from sale of investment |  |  | – |  |  |  | 1,308 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 795 |  |  |  | 1,573 |  |
| Contribution to equity method investment |  |  | – |  |  |  | (2,921 | ) |
| Expenditures for property and equipment |  |  | (23,977 | ) |  |  | (28,200 | ) |
| Purchase of long-term investment |  |  | (2,000 | ) |  |  | – |  |
| Acquisition of business, net of cash acquired |  |  | (16,188 | ) |  |  | (999 | ) |
| Net cash used in investing activities |  |  | (41,286 | ) |  |  | (27,375 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 19,515 |  |  |  | 136,664 |  |
| Proceeds from long-term borrowings |  |  | 267,869 |  |  |  | 110,000 |  |
| Repayments of short-term borrowings |  |  | (5,080 | ) |  |  | (124,609 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (113,573 | ) |  |  | (1,737 | ) |
| Payment of contingent consideration |  |  | (479 | ) |  |  | – |  |
| Purchase of additional ownership interest |  |  | (104,844 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (4,710 | ) |  |  | (34,620 | ) |
| Proceeds from the exercise of stock options |  |  | 4,975 |  |  |  | 9,903 |  |
| Net cash provided by financing activities |  |  | 63,673 |  |  |  | 95,601 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 814 |  |  |  | 600 |  |
| Net increase in cash and cash equivalents |  |  | 4,642 |  |  |  | 58,684 |  |
| Cash and cash equivalents at beginning of period |  |  | 132,723 |  |  |  | 147,339 |  |
| Cash and cash equivalents at end of period |  | $ | 137,365 |  |  | $ | 206,023 |  |

[0001437749-23-012184:8k_2_02:75]
7

[0001437749-23-012184:8k_2_02:76]
| Generac Holdings Inc. |  |
| Segment Reporting and Product Class Information |  |
| (U.S. Dollars in Thousands) |  |
| (Unaudited) |  |

[0001437749-23-012184:8k_2_02:77]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |  | Three Months Ended March 31, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 704,386 |  |  | $ | 15,607 |  |  | $ | 719,993 |  |  | $ | 964,674 |  |  | $ | 10,270 |  |  | $ | 974,944 |  |
| International |  |  | 183,524 |  |  |  | 32,942 |  |  |  | 216,466 |  |  |  | 171,182 |  |  |  | 14,250 |  |  |  | 185,432 |  |
| Intercompany elimination |  |  | - |  |  |  | (48,549 | ) |  |  | (48,549 | ) |  |  |  |  |  |  | (24,520 | ) |  |  | (24,520 | ) |
| Total net sales |  | $ | 887,910 |  |  | $ | - |  |  | $ | 887,910 |  |  | $ | 1,135,856 |  |  | $ | - |  |  | $ | 1,135,856 |  |

[0001437749-23-012184:8k_2_02:78]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Residential products |  | $ | 418,863 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 362,990 |  |  |  | 278,728 |  |
| Other |  |  | 106,057 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 887,910 |  |  | $ | 1,135,856 |  |

[0001437749-23-012184:8k_2_02:79]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 67,662 |  |  | $ | 170,421 |  |
| International |  |  | 32,413 |  |  |  | 25,992 |  |
| Total adjusted EBITDA (1) |  | $ | 100,075 |  |  | $ | 196,413 |  |

[0001437749-23-012184:8k_2_02:80]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-23-012184:8k_2_02:81]
8

[0001437749-23-012184:8k_2_02:82]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-012184:8k_2_02:83]
Net income to Adjusted EBITDA reconciliation

[0001437749-23-012184:8k_2_02:84]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |
| Interest expense |  |  | 22,995 |  |  |  | 9,554 |  |
| Depreciation and amortization |  |  | 39,951 |  |  |  | 38,461 |  |
| Provision for income taxes |  |  | 7,849 |  |  |  | 28,608 |  |
| Non-cash write-down and other adjustments (1) |  |  | (3,160 | ) |  |  | (7,792 | ) |
| Non-cash share-based compensation expense (2) |  |  | 10,334 |  |  |  | 8,827 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,091 |  |  |  | 989 |  |
| Business optimization and other charges (4) |  |  | 1,100 |  |  |  | 1,159 |  |
| Provision for regulatory charges (5) |  |  | 5,800 |  |  |  | - |  |
| Other |  |  | (46 | ) |  |  | (289 | ) |
| Adjusted EBITDA |  |  | 100,075 |  |  |  | 196,413 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,133 |  |  |  | 3,425 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 96,942 |  |  | $ | 192,988 |  |

[0001437749-23-012184:8k_2_02:85]
(1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-23-012184:8k_2_02:86]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-23-012184:8k_2_02:87]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-23-012184:8k_2_02:88]
(4) Represents severance and other non-recurring restructuring charges.

[0001437749-23-012184:8k_2_02:89]
(5) The amount recorded in the first quarter 2023 represents a provision of $5.8 million for a pending matter with the Consumer Product Safety Commission concerning the imposition of penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021.

[0001437749-23-012184:8k_2_02:90]
9

[0001437749-23-012184:8k_2_02:91]
Net income to Adjusted net income reconciliation

[0001437749-23-012184:8k_2_02:92]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,430 |  |  | $ | 113,858 |  |
| Net income attributable to noncontrolling interests |  |  | 1,731 |  |  |  | 3,038 |  |
| Net income |  |  | 14,161 |  |  |  | 116,896 |  |
| Amortization of intangible assets |  |  | 25,823 |  |  |  | 26,054 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 954 |  |  |  | 637 |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 718 |  |  |  | (5,756 | ) |
| (Gain)/loss attributable to business or asset dispositions (7) |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (4) |  |  | 1,100 |  |  |  | 1,159 |  |
| Provision for regulatory charges (5) |  |  | 5,800 |  |  |  | – |  |
| Tax effect of add backs (8) |  |  | (7,131 | ) |  |  | (9,256 | ) |
| Adjusted net income |  |  | 41,306 |  |  |  | 129,505 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,861 |  |  |  | 1,355 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 39,445 |  |  | $ | 128,150 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.63 |  |  | $ | 1.98 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,294,447 |  |  |  | 64,828,819 |

[0001437749-23-012184:8k_2_02:93]
(6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-23-012184:8k_2_02:94]
(7) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-23-012184:8k_2_02:95]
(8) In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the first quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the first quarter ended 2022 of $135,271 or $2.09. Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the first quarter ended 2022 is $128,150 or $1.98.

[0001437749-23-012184:8k_2_02:96]
Free Cash Flow Reconciliation

[0001437749-23-012184:8k_2_02:97]
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net cash used in operating activities |  | $ | (18,559 | ) |  | $ | (10,142 | ) |
| Proceeds from beneficial interests in securitization transactions |  |  | 795 |  |  |  | 1,573 |  |
| Expenditures for property and equipment |  |  | (23,977 | ) |  |  | (28,200 | ) |
| Free cash flow |  | $ | (41,741 | ) |  | $ | (36,769 | ) |

[0001437749-23-012184:8k_2_02:98]
10
