# GNRC 8-K — 0001437749-25-013608 filed 2025-04-30

## item codes, every 8-K on or before 2025-05-06

- 2025-04-30 0001437749-25-013608 — 2.02, 9.01
- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2025-05-06

- none on or before 2025-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-013608:8k_2_02:1]
EX-99.1
2
ex_808112.htm
EXHIBIT 99.1

[0001437749-25-013608:8k_2_02:2]
ex_808112.htm

[0001437749-25-013608:8k_2_02:3]
Exhibit 99.1

[0001437749-25-013608:8k_2_02:4]
Generac Reports First Quarter 2025 Results

[0001437749-25-013608:8k_2_02:5]
WAUKESHA, WISCONSIN (April 30, 2025) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2025 and provided an update on its outlook for the full-year 2025.

[0001437749-25-013608:8k_2_02:6]
First Quarter 2025 Highlights

[0001437749-25-013608:8k_2_02:7]
| ● | Net sales increased 6% to $942 million during the first quarter of 2025 as compared to $889 million in the prior-year first quarter. The net effect of acquisitions and foreign currency had a slight favorable impact during the quarter. |

[0001437749-25-013608:8k_2_02:8]
|  | - | Residential product sales increased approximately 15% to $494 million as compared to $429 million last year. |

[0001437749-25-013608:8k_2_02:9]
|  | - | Commercial & Industrial (“C&I”) product sales decreased approximately 5% to $337 million as compared to $354 million in the prior year. |

[0001437749-25-013608:8k_2_02:10]
| ● | Net income attributable to the Company during the first quarter was $44 million, or $0.73 per share, as compared to $26 million, or $0.39 per share, for the same period of 2024. |

[0001437749-25-013608:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $75 million, or $1.26 per share, as compared to $53 million, or $0.88 per share, in the first quarter of 2024. |

[0001437749-25-013608:8k_2_02:12]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $150 million, or 15.9% of net sales, as compared to $127 million, or 14.3% of net sales, in the prior year. |

[0001437749-25-013608:8k_2_02:13]
| ● | Cash flow from operations was $58 million as compared to $112 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $27 million as compared to $85 million in the first quarter of 2024. |

[0001437749-25-013608:8k_2_02:14]
| ● | The Company repurchased 716,685 shares of its common stock during the first quarter for approximately $97 million. There is approximately $250 million remaining under the current repurchase program as of March 31, 2025. |

[0001437749-25-013608:8k_2_02:15]
| ● | The Company is updating its overall net sales growth guidance for the full-year 2025 to be 0 to 7% over the prior year as compared to the previous guidance range of 3 to 7%. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be 17.0 to 19.0% as compared to the previous guidance range of 18.0 to 19.0%. |

[0001437749-25-013608:8k_2_02:16]
“First quarter results exceeded our expectations as a result of continued strong growth in residential product sales,” said Aaron Jagdfeld, President and Chief Executive Officer. “Home standby generator shipments increased at a robust rate during the quarter as we executed on the continued higher demand created by elevated outage activity in 2024, and residential energy technology sales also grew significantly from the prior year. In addition, continued strong gross margins led adjusted EBITDA well ahead of our prior expectations.”

[0001437749-25-013608:8k_2_02:17]
Jagdfeld continued, “While near-term visibility has been impacted by trade policy and macroeconomic uncertainty, we remain confident in our enterprise strategy and believe the secular trends of lower power quality and higher power prices will continue well into the future. As we attempt to mitigate the significant impact of tariffs in the immediate term, we are taking specific actions across the organization through higher pricing, various supply chain initiatives, and other cost reduction efforts over the coming quarters.”

[0001437749-25-013608:8k_2_02:18]
Additional First Quarter 2025 Consolidated Highlights

[0001437749-25-013608:8k_2_02:19]
Gross profit margin was 39.5% as compared to 35.6% in the prior-year first quarter. The increase in gross margin was primarily driven by favorable sales mix and realization of lower input costs.

[0001437749-25-013608:8k_2_02:20]
Operating expenses increased $38.8 million, or 15.6%, as compared to the first quarter of 2024. The growth in operating expenses was primarily driven by increased employee costs to support future growth across the business, higher marketing spend to drive incremental awareness for our products, and ongoing operating expenses related to recent acquisitions.

[0001437749-25-013608:8k_2_02:21]
Provision for income taxes for the current year quarter was $14.2 million, or an effective tax rate of 24.3%, as compared to $12.0 million, or a 31.2% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year period that did not repeat in the current year.

[0001437749-25-013608:8k_2_02:22]
Cash flow from operations was $58.2 million during the first quarter, as compared to $111.9 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $27.2 million as compared to $85.1 million in the first quarter of 2024. The change in free cash flow was primarily driven by an increase in working capital during the current year quarter, which included the replenishment of certain residential product finished goods inventories, partially offset by higher operating earnings.

[0001437749-25-013608:8k_2_02:23]
Business Segment Results

[0001437749-25-013608:8k_2_02:24]
Domestic Segment

[0001437749-25-013608:8k_2_02:25]
Domestic segment total sales (including inter-segment sales) increased approximately 9% to $782.3 million as compared to $720.5 million in the prior year, including an approximate 2% benefit from acquisitions. The 7% core total sales increase was primarily driven by higher sales of home standby generators and energy technology solutions, as well as growth in C&I product shipments to national telecom customers and industrial distributors. This growth was partially offset by lower C&I product sales to national rental accounts and other direct customers for “beyond standby” applications.

[0001437749-25-013608:8k_2_02:26]
Adjusted EBITDA for the segment was $122.5 million, or 15.7% of domestic segment total sales, as compared to $99.2 million, or 13.8% of total sales, in the prior year. This margin improvement was primarily driven by favorable sales mix and lower input costs, partially offset by increased operating expense investments to support future growth.

[0001437749-25-013608:8k_2_02:27]
International Segment

[0001437749-25-013608:8k_2_02:28]
International segment total sales (including inter-segment sales) decreased slightly to $185.5 million from $186.7 million in the prior year quarter, including an approximate 5% unfavorable impact from foreign currency. The approximate 5% core total sales growth for the segment was primarily driven by strength in residential product shipments in Latin America as well as higher inter-segment sales to the U.S. market, partially offset by softer C&I shipments in most global end markets that we serve.

[0001437749-25-013608:8k_2_02:29]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $27.0 million, or 14.6% of international segment total sales, as compared to $28.0 million, or 15.0% of total sales, in the prior year. This slight margin decline was primarily driven by unfavorable sales mix and higher operating expenses during the quarter.

[0001437749-25-013608:8k_2_02:30]
2025 Outlook

[0001437749-25-013608:8k_2_02:31]
As a result of higher tariff levels, uncertain government policy actions, and a potentially softer global macroeconomic environment, the range of forecasted outcomes for our business has expanded relative to our prior guidance. Due to these factors, the Company is widening its guidance ranges for key financial metrics for the full year 2025. This updated outlook assumes that current tariff levels remain in place for the remainder of the year.

[0001437749-25-013608:8k_2_02:32]
The Company now expects full-year 2025 net sales growth to be between 0 to 7% compared to the prior year, which includes an approximate 1% favorable impact from foreign currency and acquisitions. This compares to our previous guidance range of 3 to 7% net sales growth compared to the prior year as price increases have the potential to be more than offset by lower shipment volumes.

[0001437749-25-013608:8k_2_02:33]
Additionally, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 6.5 to 8.5% for the full-year 2025. The corresponding adjusted EBITDA margin is now expected to be approximately 17.0 to 19.0% compared to our previous guidance range of 18.0 to 19.0%. This updated guidance range considers the potential impact of unfavorable operating leverage on lower shipment volumes, while the estimated impact of higher tariffs is expected to be fully offset by pricing actions and supply chain initiatives.

[0001437749-25-013608:8k_2_02:34]
The Company continues to expect strong free cash flow for the full year, with free cash flow conversion from adjusted net income between 70 to 90%.

[0001437749-25-013608:8k_2_02:35]
Conference Call and Webcast

[0001437749-25-013608:8k_2_02:36]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, April 30, 2025 to discuss first quarter 2025 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/axz3e8r5.

[0001437749-25-013608:8k_2_02:37]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-25-013608:8k_2_02:38]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-25-013608:8k_2_02:39]
About Generac

[0001437749-25-013608:8k_2_02:40]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-013608:8k_2_02:41]
Forward-looking Information

[0001437749-25-013608:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-25-013608:8k_2_02:43]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-25-013608:8k_2_02:44]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |

[0001437749-25-013608:8k_2_02:45]
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-013608:8k_2_02:46]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-25-013608:8k_2_02:47]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made. Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-25-013608:8k_2_02:48]
4

[0001437749-25-013608:8k_2_02:49]
Non-GAAP Financial Metrics

[0001437749-25-013608:8k_2_02:50]
Core Sales

[0001437749-25-013608:8k_2_02:51]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-25-013608:8k_2_02:52]
Adjusted EBITDA

[0001437749-25-013608:8k_2_02:53]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are significant and that are not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-25-013608:8k_2_02:54]
Adjusted Net Income

[0001437749-25-013608:8k_2_02:55]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-25-013608:8k_2_02:56]
Free Cash Flow

[0001437749-25-013608:8k_2_02:57]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-25-013608:8k_2_02:58]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-25-013608:8k_2_02:59]
SOURCE: Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:60]
CONTACT:

[0001437749-25-013608:8k_2_02:61]
Kris Rosemann

[0001437749-25-013608:8k_2_02:62]
Director – Corporate Development & Investor Relations

[0001437749-25-013608:8k_2_02:63]
(262) 506-6064

[0001437749-25-013608:8k_2_02:64]
InvestorRelations@generac.com

[0001437749-25-013608:8k_2_02:65]
Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:66]
Condensed Consolidated Balance Sheets

[0001437749-25-013608:8k_2_02:67]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-013608:8k_2_02:68]
(Unaudited)

[0001437749-25-013608:8k_2_02:69]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 187,464 |  |  | $ | 281,277 |  |
| Accounts receivable, less allowance for credit losses of $35,944 and $35,465 as of March 31, 2025 and December 31, 2024, respectively |  |  | 590,120 |  |  |  | 612,107 |  |
| Inventories |  |  | 1,095,082 |  |  |  | 1,031,647 |  |
| Prepaid expenses and other current assets |  |  | 115,873 |  |  |  | 107,139 |  |
| Total current assets |  |  | 1,988,539 |  |  |  | 2,032,170 |  |
| Property and equipment, net |  |  | 709,530 |  |  |  | 690,023 |  |
| Customer lists, net |  |  | 150,430 |  |  |  | 152,737 |  |
| Patents and technology, net |  |  | 369,053 |  |  |  | 379,095 |  |
| Other intangible assets, net |  |  | 17,623 |  |  |  | 20,026 |  |
| Tradenames, net |  |  | 204,977 |  |  |  | 206,664 |  |
| Goodwill |  |  | 1,442,571 |  |  |  | 1,436,261 |  |
| Deferred income taxes |  |  | 31,315 |  |  |  | 24,132 |  |
| Operating lease and other assets |  |  | 146,416 |  |  |  | 168,223 |  |
| Total assets |  | $ | 5,060,454 |  |  | $ | 5,109,331 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 56,533 |  |  | $ | 55,848 |  |
| Accounts payable |  |  | 439,699 |  |  |  | 458,693 |  |
| Accrued wages and employee benefits |  |  | 50,422 |  |  |  | 81,485 |  |
| Accrued product warranty |  |  | 56,161 |  |  |  | 56,127 |  |
| Other accrued liabilities |  |  | 332,466 |  |  |  | 313,401 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 72,307 |  |  |  | 67,598 |  |
| Total current liabilities |  |  | 1,007,588 |  |  |  | 1,033,152 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,195,861 |  |  |  | 1,210,776 |  |
| Deferred income taxes |  |  | 33,709 |  |  |  | 33,185 |  |
| Deferred revenue |  |  | 200,050 |  |  |  | 193,260 |  |
| Operating lease and other long-term liabilities |  |  | 150,221 |  |  |  | 141,515 |  |
| Total liabilities |  |  | 2,587,429 |  |  |  | 2,611,888 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 74,035,516 and 73,785,631 shares issued as of March 31, 2025 and December 31, 2024, respectively |  |  | 740 |  |  |  | 738 |  |
| Additional paid-in capital |  |  | 1,145,990 |  |  |  | 1,133,756 |  |
| Treasury stock, at cost, 14,953,986 and 14,173,697 shares at March 31, 2025 and December 31, 2024, respectively |  |  | (1,303,086 | ) |  |  | (1,196,997 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,888,136 |  |  |  | 2,844,296 |  |
| Accumulated other comprehensive loss |  |  | (60,440 | ) |  |  | (85,399 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,469,224 |  |  |  | 2,494,278 |  |
| Noncontrolling interests |  |  | 3,801 |  |  |  | 3,165 |  |
| Total stockholders’ equity |  |  | 2,473,025 |  |  |  | 2,497,443 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,060,454 |  |  | $ | 5,109,331 |  |

[0001437749-25-013608:8k_2_02:70]
6

[0001437749-25-013608:8k_2_02:71]
Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:72]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-25-013608:8k_2_02:73]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-013608:8k_2_02:74]
(Unaudited)

[0001437749-25-013608:8k_2_02:75]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net sales |  | $ | 942,121 |  |  | $ | 889,273 |  |
| Costs of goods sold |  |  | 570,135 |  |  |  | 572,894 |  |
| Gross profit |  |  | 371,986 |  |  |  | 316,379 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 126,065 |  |  |  | 108,586 |  |
| Research and development |  |  | 62,048 |  |  |  | 49,410 |  |
| General and administrative |  |  | 74,746 |  |  |  | 66,764 |  |
| Amortization of intangibles |  |  | 25,489 |  |  |  | 24,750 |  |
| Total operating expenses |  |  | 288,348 |  |  |  | 249,510 |  |
| Income from operations |  |  | 83,638 |  |  |  | 66,869 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (17,110 | ) |  |  | (23,605 | ) |
| Investment income |  |  | 2,225 |  |  |  | 1,688 |  |
| Change in fair value of investment |  |  | (9,947 | ) |  |  | (6,019 | ) |
| Other, net |  |  | (292 | ) |  |  | (422 | ) |
| Total other expense, net |  |  | (25,124 | ) |  |  | (28,358 | ) |
| Income before provision for income taxes |  |  | 58,514 |  |  |  | 38,511 |  |
| Provision for income taxes |  |  | 14,236 |  |  |  | 12,033 |  |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.74 |  |  | $ | 0.39 |  |
| Weighted average common shares outstanding - basic: |  |  | 59,062,534 |  |  |  | 59,849,362 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.73 |  |  | $ | 0.39 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,747,589 |  |  |  | 60,486,125 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 68,799 |  |  | $ | 22,564 |  |

[0001437749-25-013608:8k_2_02:76]
Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:77]
Condensed Consolidated Statements of Cash Flows

[0001437749-25-013608:8k_2_02:78]
(U.S. Dollars in Thousands)

[0001437749-25-013608:8k_2_02:79]
(Unaudited)

[0001437749-25-013608:8k_2_02:80]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 44,278 |  |  | $ | 26,478 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 20,652 |  |  |  | 17,152 |  |
| Amortization of intangible assets |  |  | 25,489 |  |  |  | 24,750 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 636 |  |  |  | 973 |  |
| Change in fair value of investment |  |  | 9,947 |  |  |  | 6,019 |  |
| Deferred income taxes |  |  | (4,182 | ) |  |  | (5,405 | ) |
| Share-based compensation expense |  |  | 11,608 |  |  |  | 12,440 |  |
| Loss (gain) on disposal of assets |  |  | 303 |  |  |  | (52 | ) |
| Other noncash charges |  |  | 626 |  |  |  | 1,410 |  |
| Excess tax (benefits) expense from equity awards |  |  | (164 | ) |  |  | 1,009 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 48,350 |  |  |  | 13,664 |  |
| Inventories |  |  | (57,203 | ) |  |  | (18,109 | ) |
| Other assets |  |  | 2,145 |  |  |  | (920 | ) |
| Accounts payable |  |  | (33,007 | ) |  |  | 44,682 |  |
| Accrued wages and employee benefits |  |  | (31,554 | ) |  |  | (8,512 | ) |
| Other accrued liabilities |  |  | 20,228 |  |  |  | (3,681 | ) |
| Net cash provided by operating activities |  |  | 58,152 |  |  |  | 111,898 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 54 |  |  |  | 51 |  |
| Contribution to tax equity investment |  |  | - |  |  |  | (1,629 | ) |
| Purchase of long-term investments |  |  | (2,656 | ) |  |  | (239 | ) |
| Proceeds from sale of long-term investment |  |  | - |  |  |  | 2,000 |  |
| Expenditures for property and equipment |  |  | (30,937 | ) |  |  | (26,820 | ) |
| Net cash used in investing activities |  |  | (33,539 | ) |  |  | (26,637 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 19,236 |  |  |  | 8,970 |  |
| Proceeds from long-term borrowings |  |  | 943 |  |  |  | 471 |  |
| Repayments of short-term borrowings |  |  | (19,985 | ) |  |  | (18,489 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (14,450 | ) |  |  | (7,030 | ) |
| Stock repurchases |  |  | (97,454 | ) |  |  | - |  |
| Payment of deferred acquisition consideration |  |  | - |  |  |  | (6,000 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | (9,117 | ) |
| Taxes paid related to equity awards |  |  | (8,601 | ) |  |  | (5,455 | ) |
| Proceeds from the exercise of stock options |  |  | 592 |  |  |  | 319 |  |
| Net cash used in financing activities |  |  | (119,719 | ) |  |  | (36,331 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,293 |  |  |  | (569 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (93,813 | ) |  |  | 48,361 |  |
| Cash and cash equivalents at beginning of period |  |  | 281,277 |  |  |  | 200,994 |  |
| Cash and cash equivalents at end of period |  | $ | 187,464 |  |  | $ | 249,355 |  |

[0001437749-25-013608:8k_2_02:81]
8

[0001437749-25-013608:8k_2_02:82]
Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:83]
Segment Reporting and Product Class Information

[0001437749-25-013608:8k_2_02:84]
(U.S. Dollars in Thousands)

[0001437749-25-013608:8k_2_02:85]
(Unaudited)

[0001437749-25-013608:8k_2_02:86]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2025 |  |  | Three Months Ended March 31, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 774,642 |  |  | $ | 7,694 |  |  | $ | 782,336 |  |  | $ | 712,337 |  |  | $ | 8,136 |  |  | $ | 720,473 |  |
| International |  |  | 167,479 |  |  |  | 18,062 |  |  |  | 185,541 |  |  |  | 176,936 |  |  |  | 9,772 |  |  |  | 186,708 |  |
| Intercompany elimination |  |  | - |  |  |  | (25,756 | ) |  |  | (25,756 | ) |  |  | - |  |  |  | (17,908 | ) |  |  | (17,908 | ) |
| Total net sales |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |  | $ | 889,273 |  |  | $ | - |  |  | $ | 889,273 |  |

[0001437749-25-013608:8k_2_02:87]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Residential products |  | $ | 494,152 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 337,372 |  |  |  | 353,970 |  |
| Other |  |  | 110,597 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 942,121 |  |  | $ | 889,273 |  |

[0001437749-25-013608:8k_2_02:88]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 122,513 |  |  | $ | 99,175 |  |
| International |  |  | 27,033 |  |  |  | 28,058 |  |
| Total adjusted EBITDA (1) |  | $ | 149,546 |  |  | $ | 127,233 |  |

[0001437749-25-013608:8k_2_02:89]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-25-013608:8k_2_02:90]
Generac Holdings Inc.

[0001437749-25-013608:8k_2_02:91]
Reconciliation Schedules

[0001437749-25-013608:8k_2_02:92]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-013608:8k_2_02:93]
(Unaudited)

[0001437749-25-013608:8k_2_02:94]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |
| Interest expense |  |  | 17,110 |  |  |  | 23,605 |  |
| Depreciation and amortization |  |  | 46,141 |  |  |  | 41,902 |  |
| Provision for income taxes |  |  | 14,236 |  |  |  | 12,033 |  |
| Non-cash write-down and other adjustments (1) |  |  | (13 | ) |  |  | 510 |  |
| Non-cash share-based compensation expense (2) |  |  | 11,608 |  |  |  | 12,440 |  |
| Transaction costs and credit facility fees (3) |  |  | 760 |  |  |  | 1,425 |  |
| Business optimization and other charges (4) |  |  | 1,575 |  |  |  | 486 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 3,751 |  |  |  | 2,535 |  |
| Change in fair value of investment (6) |  |  | 9,947 |  |  |  | 6,019 |  |
| Other |  |  | 153 |  |  |  | (200 | ) |
| Adjusted EBITDA |  |  | 149,546 |  |  |  | 127,233 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 632 |  |  |  | 477 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 148,914 |  |  | $ | 126,756 |  |
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |

[0001437749-25-013608:8k_2_02:95]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |
| Amortization of intangible assets |  |  | 25,489 |  |  |  | 24,750 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 636 |  |  |  | 973 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 107 |  |  |  | 844 |  |
| Loss attributable to business or asset dispositions (8) |  |  | 390 |  |  |  | 37 |  |
| Business optimization and other charges (4) |  |  | 1,575 |  |  |  | 486 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 3,751 |  |  |  | 2,535 |  |
| Change in fair value of investment (6) |  |  | 9,947 |  |  |  | 6,019 |  |
| Tax effect of add backs |  |  | (10,369 | ) |  |  | (8,925 | ) |
| Adjusted net income |  |  | 75,804 |  |  |  | 53,197 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 75,366 |  |  | $ | 52,951 |  |
| Adjusted net income attributable to Generac Holdings Inc. per |  |  |  |  |  |  |  |  |
| common share - diluted: |  | $ | 1.26 |  |  | $ | 0.88 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,747,589 |  |  |  | 60,486,125 |  |

[0001437749-25-013608:8k_2_02:96]
10

[0001437749-25-013608:8k_2_02:97]
(1) Includes (gains) losses on the disposition of assets other than in the ordinary course of business, (gains) losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-25-013608:8k_2_02:98]
(2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods.

[0001437749-25-013608:8k_2_02:99]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-25-013608:8k_2_02:100]
(4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-25-013608:8k_2_02:101]
(5) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-013608:8k_2_02:102]
•  A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1.5 million in the first quarter of 2025 and $2.1 million in the first quarter of 2024.

[0001437749-25-013608:8k_2_02:103]
•  Legal expenses related to certain class action lawsuits - $1.3 million in the first quarter of 2025.

[0001437749-25-013608:8k_2_02:104]
•  Legal expenses related to certain government inquiries and other significant matters - $0.9 million in the first quarter of 2025.

[0001437749-25-013608:8k_2_02:105]
•  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024.

[0001437749-25-013608:8k_2_02:106]
(6) Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-013608:8k_2_02:107]
(7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-25-013608:8k_2_02:108]
(8) Represents losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-25-013608:8k_2_02:109]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 58,152 |  |  | $ | 111,898 |  |
| Expenditures for property and equipment |  |  | (30,937 | ) |  |  | (26,820 | ) |
| Free cash flow |  | $ | 27,215 |  |  | $ | 85,078 |  |
