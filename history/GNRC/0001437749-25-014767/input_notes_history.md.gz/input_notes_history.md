# GNRC note change history — 0001437749-24-033337 → 0001437749-25-014767


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001437749-25-014767:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  March 31, 2025, and  December 31, 2024, was $184,956 and $165,432, respectively.
  (was, 2024-11-05, similarity 0.9799):
[0001437749-24-033337:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2024, and  December 31, 2023, was $146,366 and $158,028, respectively.

- changed (2025-05-06):
[0001437749-25-014767:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.
  (was, 2024-11-05, similarity 0.9969):
[0001437749-24-033337:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy ("PHS") filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

- changed (2025-05-06):
[0001437749-25-014767:note_history:3]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025, which the Company intends to move to dismiss.
  (was, 2024-11-05, similarity 0.6246):
[0001437749-24-033337:note_history:3]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

- changed (2025-05-06):
[0001437749-25-014767:note_history:4]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.
  (was, 2024-11-05, similarity 0.9001):
[0001437749-24-033337:note_history:4]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.

- added (2025-05-06):
[0001437749-25-014767:note_history:5]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

- changed (2025-05-06):
[0001437749-25-014767:note_history:6]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023, jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.
  (was, 2024-11-05, similarity 0.7142):
[0001437749-24-033337:note_history:6]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

- changed (2025-05-06):
[0001437749-25-014767:note_history:7]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics' purchasing practices, and is pursuing a counterclaim in connection with the arbitration.
  (was, 2024-11-05, similarity 0.9989):
[0001437749-24-033337:note_history:7]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronic's purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

- changed (2025-05-06):
[0001437749-25-014767:note_history:8]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.
  (was, 2024-11-05, similarity 0.9988):
[0001437749-24-033337:note_history:8]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

- added (2025-05-06):
[0001437749-25-014767:note_history:9]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies the allegations and intends to vigorously defend the matter.

- changed (2025-05-06):
[0001437749-25-014767:note_history:10]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.
  (was, 2024-11-05, similarity 0.8165):
[0001437749-24-033337:note_history:10]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida. Case No. 24-cv-02412. The complaint alleges that home standby generators manufactured or sold to consumers from 2021-2024 contain a latent defect that  may cause the generator to malfunction. Plaintiffs assert breaches of warranty, tort-based, statutory, and unjust enrichment claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

- removed (2025-05-06):
[0001437749-24-033337:note_history:11]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001437749-25-014767:note_history:12]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2024-11-05, similarity 0.9227):
[0001437749-24-033337:note_history:12]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers. A summary of acquisitions affecting the reporting periods presented include:

- added (2025-05-06):
[0001437749-25-014767:note_history:13]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in the Company's Annual Report on Form 10-K for the year ended  December 31, 2024, for a discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

- added (2025-05-06):
[0001437749-25-014767:note_history:14]
|  | ● | In November 2024, the Company acquired Wolverine Power Systems (Wolverine), headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC (Ageto). Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System (C&I BESS) product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. (Huntington), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |

- changed (2025-05-06):
[0001437749-25-014767:note_history:15]
The condensed consolidated balance sheet as of  March 31, 2025, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2025 and 2024, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2024-11-05, similarity 0.8989):
[0001437749-24-033337:note_history:15]
The condensed consolidated balance sheet as of  September 30, 2024, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2025-05-06):
[0001437749-25-014767:note_history:16]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates. The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.
  (was, 2024-11-05, similarity 0.7617):
[0001437749-24-033337:note_history:16]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- changed (2025-05-06):
[0001437749-25-014767:note_history:17]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended  December 31, 2024.
  (was, 2024-11-05, similarity 0.987):
[0001437749-24-033337:note_history:17]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2023.

- changed (2025-05-06):
[0001437749-25-014767:note_history:18]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC).
  (was, 2024-11-05, similarity 0.984):
[0001437749-24-033337:note_history:18]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC").

- added (2025-05-06):
[0001437749-25-014767:note_history:19]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

- changed (2025-05-06):
[0001437749-25-014767:note_history:20]
In  March 2024, the Securities and Exchange Commission (SEC) adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. On  March 27, 2025, the SEC voted to discontinue the agency's defense of the climate disclosure rule in court. The rule will remain under a stay pending a final court decision. The Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the disclosures are required.
  (was, 2024-11-05, similarity 0.7682):
[0001437749-24-033337:note_history:20]
In  March 2024, the Securities and Exchange Commission ("SEC") adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with the Company's annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, the Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

- changed (2025-05-06):
[0001437749-25-014767:note_history:21]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.
  (was, 2024-11-05, similarity 0.9988):
[0001437749-24-033337:note_history:21]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

- changed (2025-05-06):
[0001437749-25-014767:note_history:22]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update was effective for fiscal year 2024 and is effective for interim periods in fiscal 2025. The required annual disclosures are reflected in Note 7, "Segment Reporting," to the 2024 Annual Report on Form 10-K and the required quarterly disclosures are reflected in Note 6, "Segment Reporting," of this Quarterly Report on Form 10-Q.
  (was, 2024-11-05, similarity 0.6611):
[0001437749-24-033337:note_history:22]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements or disclosures.

- changed (2025-05-06):
[0001437749-25-014767:note_history:23]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the three months ended  March 31, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2024-11-05, similarity 0.9137):
[0001437749-24-033337:note_history:23]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2025-05-06):
[0001437749-24-033337:note_history:24]
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |

- removed (2025-05-06):
[0001437749-24-033337:note_history:25]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles ("GAAP"). All intercompany amounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001437749-25-014767:note_history:26]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2025, and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $56,533 and $55,848, respectively. As of  March 31, 2025, and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.85% and 5.44%, respectively.
  (was, 2024-11-05, similarity 0.7585):
[0001437749-24-033337:note_history:26]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $65,540 and $81,769, respectively.

- added (2025-05-06):
[0001437749-25-014767:note_history:27]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 703,125 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 497,500 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (7,567 | ) |  |  | (8,203 | ) |
| Finance lease obligation |  |  | 67,042 |  |  |  | 66,355 |  |
| Other |  |  | 8,068 |  |  |  | 8,972 |  |
| Total |  |  | 1,268,168 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 64,550 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 7,757 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,195,861 |  |  | $ | 1,210,776 |  |

- added (2025-05-06):
[0001437749-25-014767:note_history:28]
The Tranche A Term Loan Facility matures on  June 29, 2027. The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility and Term Loan B Facility outstanding on  March 31, 2025, before considering original issue discount and deferred financing costs, are as follows:

- added (2025-05-06):
[0001437749-25-014767:note_history:29]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Total |  |
| 2025 |  | $ | 37,500 |  |  | $ | 3,750 |  |  | $ | 41,250 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | 468,750 |  |
| Total |  | $ | 703,125 |  |  | $ | 497,500 |  |  | $ | 1,200,625 |  |

- changed (2025-05-06):
[0001437749-25-014767:note_history:30]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.
  (was, 2024-11-05, similarity 0.9355):
[0001437749-24-033337:note_history:30]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (“original Term Loan B Facility”) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.

- added (2025-05-06):
[0001437749-25-014767:note_history:31]
In
      July 2024, the Company extinguished the
     $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new
     $500,000 Tranche B Term Loan Facility maturing on
      July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a
     $300,000 uncommitted incremental term loan on that facility. In accordance with ASC
     470-
     50, the Company capitalized
     $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of
     $4,236 and expensed
     $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of
     1.75%, subject to a SOFR floor of
     0.0%,
     resulting in a 6.06% combined rate as of  March 31, 2025.

- changed (2025-05-06):
[0001437749-25-014767:note_history:32]
The New Term Loan B Facility does
      not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below
      3.75 to
      1.00. As of
       March 31, 2025, the Company’s net secured leverag
      e ratio was 1.33 to 1.0
      0, and the Company was in compliance with all covenants under the Facility. There are
      no financial maintenance covenants on the Term Loan B Facility.
  (was, 2024-11-05, similarity 0.8064):
[0001437749-24-033337:note_history:32]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2024, the Company’s net secured leverage ratio was 1.70 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- added (2025-05-06):
[0001437749-25-014767:note_history:33]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2025, the interest rate for the Tranche A Term Loan Facility is 5.92% and the interest rate for the Revolving Facility is 5.93%. There were no borrowings under the Revolving Facility as of  March 31, 2025, and  December 31, 2024.

- changed (2025-05-06):
[0001437749-25-014767:note_history:34]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2025, the Company’s total leverage ratio was 1.40 to 1.00, and the Company's interest coverage ratio was 11.25 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2025.
  (was, 2024-11-05, similarity 0.9596):
[0001437749-24-033337:note_history:34]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2024, the Company’s total leverage ratio was 1.79 to 1.00, and the Company's interest coverage ratio was 8.69 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2024.

- added (2025-05-06):
[0001437749-25-014767:note_history:35]
The New Term Loan B Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

- changed (2025-05-06):
[0001437749-25-014767:note_history:36]
As of  March 31, 2025, the Revolving Facility had $1,249,203 of unused capacity, net of outstanding letters of credit.
  (was, 2024-11-05, similarity 0.7967):
[0001437749-24-033337:note_history:36]
As of  September 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

- added (2025-05-06):
[0001437749-25-014767:note_history:37]
See Item 7A of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.

- removed (2025-05-06):
[0001437749-24-033337:note_history:38]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan Facility |  | $ | 721,875 |  |  | $ | 745,313 |  |
| Tranche B Term Loan Facility |  |  | 500,000 |  |  |  | 530,000 |  |
| Original issue discount and capitalized debt fees |  |  | (8,853 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 90,622 |  |  |  | 71,308 |  |
| Other |  |  | 6,169 |  |  |  | 9,512 |  |
| Total |  |  | 1,459,813 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 53,193 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 45,983 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,360,637 |  |  | $ | 1,447,553 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:39]
The Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments maturing at the end of each quarter commencing  September 2023, with a balloon payment due  June 2027. The Tranche B Term Loan Facility matures on  July 3, 2031, and is repayable in installments maturing at the end of each quarter commencing  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  September 30, 2024, are as follows:

- removed (2025-05-06):
[0001437749-24-033337:note_history:40]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 9,375 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 11,875 |  |
| 2025 |  |  | 46,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 150,000 |  |  |  | 755,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 467,500 |  |  |  | - |  |  |  | 467,500 |  |
| Total |  | $ | 721,875 |  |  | $ | 500,000 |  |  | $ | 150,000 |  |  | $ | 1,371,875 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:41]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the former Tranche B Term Loan Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031. The new Tranche B Term Loan Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the former Tranche B Term Loan Facility of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The new Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.95% combined rate as of  September 30, 2024.

- removed (2025-05-06):
[0001437749-24-033337:note_history:42]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan A facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%, resulting in a 6.93% combined interest rate for the Tranche A Term Loan Facility and Revolving Facility as of  September 30, 2024.

- removed (2025-05-06):
[0001437749-24-033337:note_history:43]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

- removed (2025-05-06):
[0001437749-24-033337:note_history:44]
See Note 5, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0001437749-25-014767:note_history:45]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 703,125 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 497,500 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (7,567 | ) |  |  | (8,203 | ) |
| Finance lease obligation |  |  | 67,042 |  |  |  | 66,355 |  |
| Other |  |  | 8,068 |  |  |  | 8,972 |  |
| Total |  |  | 1,268,168 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 64,550 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 7,757 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,195,861 |  |  | $ | 1,210,776 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:46]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan Facility |  | $ | 721,875 |  |  | $ | 745,313 |  |
| Tranche B Term Loan Facility |  |  | 500,000 |  |  |  | 530,000 |  |
| Original issue discount and capitalized debt fees |  |  | (8,853 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 90,622 |  |  |  | 71,308 |  |
| Other |  |  | 6,169 |  |  |  | 9,512 |  |
| Total |  |  | 1,459,813 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 53,193 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 45,983 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,360,637 |  |  | $ | 1,447,553 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0001437749-25-014767:note_history:47]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Total |  |
| 2025 |  | $ | 37,500 |  |  | $ | 3,750 |  |  | $ | 41,250 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | 468,750 |  |
| Total |  | $ | 703,125 |  |  | $ | 497,500 |  |  | $ | 1,200,625 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:48]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 9,375 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 11,875 |  |
| 2025 |  |  | 46,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 150,000 |  |  |  | 755,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 467,500 |  |  |  | - |  |  |  | 467,500 |  |
| Total |  | $ | 721,875 |  |  | $ | 500,000 |  |  | $ | 150,000 |  |  | $ | 1,371,875 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0001437749-25-014767:note_history:49]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 473,291 |  |  | $ | 20,861 |  |  | $ | 494,152 |  |
| Commercial & industrial products |  |  | 206,145 |  |  |  | 131,227 |  |  |  | 337,372 |  |
| Other |  |  | 95,206 |  |  |  | 15,391 |  |  |  | 110,597 |  |
| Total net sales |  | $ | 774,642 |  |  | $ | 167,479 |  |  | $ | 942,121 |  |

- added (2025-05-06):
[0001437749-25-014767:note_history:50]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:51]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:52]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:53]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |

- removed (2025-05-06):
[0001437749-24-033337:note_history:54]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001437749-25-014767:note_history:55]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $29,424 and $26,858 on  March 31, 2025, and  December 31, 2024, respectively. During the three months ended  March 31, 2025 the Company recognized revenue of $10,189 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2024-11-05, similarity 0.9561):
[0001437749-24-033337:note_history:55]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $19,881 and $19,173 on  September 30, 2024 and  December 31, 2023, respectively. During the nine months ended  September 30, 2024 the Company recognized revenue of $16,104 related to amounts included in the  December 31, 2023, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-06):
[0001437749-24-033337:note_history:56]
16. Subsequent Events

- removed (2025-05-06):
[0001437749-24-033337:note_history:57]
On  October 1, 2024, the Company purchased legal entities that primarily owned manufacturing and office buildings in Casole d’Elsa, Italy as their main operation for approximately 35,000 Euro. Prior to the purchase, these buildings were leased to the Company. The lease was remeasured in the third quarter of 2024 to reflect the purchase price.
