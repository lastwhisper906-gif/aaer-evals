# GNRC MD&A — 0001437749-25-014767


## mdna

[0001437749-25-014767:mdna:1]
[same as prior period, unchanged from 0001437749-24-033337:mdna:1]

[0001437749-25-014767:mdna:2]
[same as prior period, unchanged from 0001437749-24-033337:mdna:2]

[0001437749-25-014767:mdna:3]
The forward-looking statements contained in this quarterly report are based on assumptions that we have made in light of our industry experience and on our perceptions of historical trends, current conditions, expected future developments and other factors we believe are appropriate under the circumstances. As you read and consider this report, you should understand that these statements are not guarantees of performance or results. They involve risks, uncertainties (some of which are beyond our control) and assumptions. Although we believe that these forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect our actual financial results and cause them to differ materially from those anticipated in the forward-looking statements. The forward-looking statements contained in this quarterly report include estimates regarding:

[0001437749-25-014767:mdna:4]
[same as prior period, unchanged from 0001437749-24-033337:mdna:4]

[0001437749-25-014767:mdna:5]
[same as prior period, unchanged from 0001437749-24-033337:mdna:5]

[0001437749-25-014767:mdna:6]
|  | ● | management's goals, expectations, and objectives, and other similar expressions concerning matters that are not historical facts. |

[0001437749-25-014767:mdna:7]
[same as prior period, unchanged from 0001437749-24-033337:mdna:7]

[0001437749-25-014767:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinance our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-014767:mdna:9]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2024 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-25-014767:mdna:10]
Recent Developments

[0001437749-25-014767:mdna:11]
As disclosed in Part I, Item 1A: Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, the company’s business is subject to risks related to, among other factors, tariffs and other changes in U.S. trade policy and international trade relations. Starting in the first quarter of 2025, the United States government announced additional tariffs on goods imported into the U.S. from numerous countries and multiple nations countered with reciprocal tariffs and other actions in response. The U.S. government stated it is willing to negotiate with other countries regarding the tariffs. The tariffs may negatively impact demand due to higher prices and result in lower margins for some of our products. Generac is currently analyzing the impacts of the tariffs and actions that can be taken to moderate and/or minimize their effects.

[0001437749-25-014767:mdna:12]
[same as prior period, unchanged from 0001437749-24-033337:mdna:10]

[0001437749-25-014767:mdna:13]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. Generac provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-014767:mdna:14]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading positions in the North American market for power equipment with an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial, and industrial standby generators, as well as portable and mobile generators used in a variety of applications. The Company is evolving its product portfolio by building out ecosystems of energy technology products, solutions, and services for homes and businesses, enabling end users to better manage their energy costs and needs. As part of this evolution, we have made significant investments into developing markets such as residential and commercial & industrial (C&I) energy storage, solar power inverters, energy monitoring & management devices, and electric vehicle (EV) charging. Central to these ecosystems are the Company’s advanced connectivity devices, controls capabilities, and software platforms that facilitate the integration of our products into grid services programs. In addition, we have been leveraging our leading position in the growing market for natural gas fueled generators, which we believe represents a cleaner fuel compared to diesel, to expand into applications beyond standby power, allowing us to participate in multi-purpose microgrid projects for C&I customers. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will develop, and our energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid.

[0001437749-25-014767:mdna:15]
Given our competitive strengths in our traditional power generation markets, we believe we are well-positioned to execute on the growing opportunity for backup power for homes and businesses, where increased penetration is being driven by multiple mega-trends that are resulting in poorer power quality for end users. In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe we can continue to be a leader as energy costs rise and end markets evolve over time.

[0001437749-25-014767:mdna:16]
[same as prior period, unchanged from 0001437749-24-033337:mdna:14]

[0001437749-25-014767:mdna:17]
In 2021, we unveiled our “Powering A Smarter World” strategic plan, which serves as the framework for the significant investments we have made and will continue to make to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is based on the combination of several key mega-trends that we believe will drive a number of significant strategic growth themes for our business.

[0001437749-25-014767:mdna:18]
[same as prior period, unchanged from 0001437749-24-033337:mdna:16]

[0001437749-25-014767:mdna:19]
|  | ● | Lower power quality continuing to drive demand for backup power solutions: |
|  |  | o | More frequent severe and volatile weather impacting an aging grid, causing increased power outage activity. |
|  |  | o | Increasing deployment of intermittent generation sources coupled with accelerating electricity demand trends driving supply/demand imbalances for utilities and grid operators. |
|  | ● | Higher power prices driving the need for energy management solutions: |
|  |  | o | Electrification trends causing power demand to exceed supply, driving up power prices. |
|  |  | o | Investment required to upgrade grid infrastructure and transition to renewable power sources, pushing prices higher. |
|  | ● | Artificial intelligence adoption accelerating, creating a large market opportunity for backup power: |
|  |  | o | Significant power requirements for the buildout of data centers to enable AI adoption could drive further grid instability. |
|  |  | o | Acceleration in the number of hyperscale and edge data centers that require significant backup power. |
|  | ● | Growing demand for cleaner burning fuels: |
|  |  | o | Natural gas and other alternative fuels are vital to the energy transition. |
|  |  | o | Demand for natural gas-fueled backup generators growing as homes and businesses desire cleaner-burning fuel sources of generation. |
|  | ● | Required investment in global infrastructure, driving demand for our products: |
|  |  | o | Upgrading of aging and underinvested legacy infrastructure systems, such as power, telecommunications, transportation, and water. |
|  |  | o | Expanding investment for increasingly critical technology infrastructure as we transition to a more "connected" society. |
|  | ● | Home as a Sanctuary, driving increased demand for resiliency solutions that provide peace of mind: |
|  |  | o | Increasing importance of the home with more people working from home and aging in place. |
|  |  | o | Growing market for intelligent and connected homes that can provide improved energy efficiency. |

[0001437749-25-014767:mdna:20]
[same as prior period, unchanged from 0001437749-24-033337:mdna:19]

[0001437749-25-014767:mdna:21]
Power quality issues continue to increase. Power disruptions are an important driver of consumer awareness for backup power and have historically influenced demand for generators both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for backup power. The impact of climate change has received increased global focus in recent years, and an aging and underinvested electrical grid infrastructure remains highly vulnerable to the expectation of more severe and volatile weather. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply as more traditional thermal generation assets are retired, further impairing the reliable supply of electricity. At the same time, power demand is expected to meaningfully accelerate as a result of the rapid adoption of artificial intelligence and related data center energy requirements, the re-industrialization of North America, and the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. These developments are causing growing supply/demand imbalances for grid operators across North America, which has led to high-profile examples of rolling blackouts and calls for utility customers to reduce consumption to maintain grid integrity. In fact, the North American Electric Reliability Corporation has labeled significant portions of the United States and Canada as being at high or elevated risk of resource adequacy shortfalls in the 2025-2029 period due in part to these supply/demand dynamics. We believe utility supply shortfalls and related warnings may continue in the future, resulting in continued deterioration of power quality in North America. Finally, certain utilities are adopting preventative power shutoff policies to reduce the risk of wildfires caused by their electrical distribution equipment, predominately in the western half of the country. Taken together, we expect these factors to continue driving increased awareness of the need for backup power and demand for Generac’s products within multiple categories.

[0001437749-25-014767:mdna:22]
Home standby penetration opportunity is significant. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. With only approximately 6.5% penetration of the addressable market of homes in the United States (which we define as single-family detached, owner-occupied households with a home value of over $175,000, as defined by the U.S. Census Bureau's 2023 American Housing Survey for the United States), we believe there are significant opportunities to further penetrate the residential standby generator market both domestically and internationally. In addition to the mega-trends supporting growth of the category, we believe by expanding and developing our distribution network, continuing to invest in our product lines and technologies, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our home standby generators.

[0001437749-25-014767:mdna:23]
Solar, storage, and energy management markets continue to develop. We believe the electric utility landscape will undergo significant changes in the decade ahead due to accelerating demand growth, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. Importantly, we expect that a confluence of factors will continue to drive meaningful increases in power prices for end users in the future. As a result, on-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity as utility customers seek alternative solutions to combat rising power prices. In addition, battery storage provides customers another source of power resiliency for shorter duration outages. Additionally, these markets are currently being supported by significant subsidies and investment tax credits for consumers and businesses to help advance the adoption of clean energy technologies. Further, production tax credits are being offered to businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. While the expected duration of these subsidies and tax credits may change, we believe the overall mega-trends that are driving the solar, storage, and energy management markets currently provide sufficient incentive for long-term, value-creating investments for market participants in this space. Given the significant market opportunity ahead of us, we expect to further advance our capabilities in energy technology by increasing our product development, sourcing, distribution, and marketing efforts. In addition, we plan to leverage our significant competencies in the residential standby generator market to build our market position in the emerging residential solar, storage, and energy management markets.

[0001437749-25-014767:mdna:24]
Emerging applications and business models utilizing our solutions open new market opportunities. We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will create new market opportunities for our products. We believe that we can participate in this future electrical grid in a bigger way by utilizing our products and solutions as DERs by grid operators. This will require intelligent software platforms that are able to optimize an increasingly complex supply and demand equation at both the individual site and grid level, such as our Concerto DERMS software. Our residential and C&I connectivity, controls, and energy management capabilities will also enable new recurring revenue opportunities as grid services programs continue to build out over time. Additionally, we believe that growing interest in our C&I generator and BESS solutions that can be deployed in multi-asset microgrid and “beyond standby” applications will continue to emerge and create incremental market opportunities in the future. The significant advancements made in recent years in the connectivity of our products are core to these newer capabilities, which have played a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-25-014767:mdna:25]
Natural gas generators, a continuing growth opportunity. We believe natural gas will continue to be an important and cleaner transition fuel of the future, compared to diesel, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, as the benefits of natural gas power generation are very compelling relative to traditional diesel fueled generators. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids, and overall use as a DERs in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having the capability to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators. As a leader in natural gas power generation, we believe we are well positioned to capitalize on this strategic growth theme.

[0001437749-25-014767:mdna:26]
Increasingly critical nature and growing power consumption of digital infrastructure. As the number of “connected” devices continues to rapidly increase and wireless networks are considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States. As more mission-critical data is transmitted over wireless networks, we believe the penetration rate of backup generators on cell towers must increase considerably to maintain a higher level of reliability across the network. We have relationships with key Tier 1 carriers and tower companies globally, in addition to having the distribution partners to provide local service support to the global market. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-25-014767:mdna:27]
Additionally, the rapid increase in data centers is driving increased demand for backup power solutions, given the critical nature of this infrastructure. AI requirements, hyperscalers, and the expansion of edge computing and “connected devices” are expected to quadruple United States data center energy consumption from 2023 to 2030, according to certain market forecasts. We believe this significant growth in power consumption will drive demand for backup power and intelligent energy management solutions for individual data center locations, the broader electrical grid, and other grid participants.

[0001437749-25-014767:mdna:28]
[same as prior period, unchanged from 0001437749-24-033337:mdna:27]

[0001437749-25-014767:mdna:29]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators, energy storage systems, and energy management devices. Trends in interest rates and the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. The existence of renewable energy mandates, investment tax credits, and other subsidies can also have an impact on the demand for solar and energy storage systems.

[0001437749-25-014767:mdna:30]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. The capital investment cycle may differ for the various C&I end markets that we serve, including light commercial, retail, office, telecommunications, rental, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions, fluctuations in interest rates, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-25-014767:mdna:31]
[same as prior period, unchanged from 0001437749-24-033337:mdna:30]

[0001437749-25-014767:mdna:32]
[same as prior period, unchanged from 0001437749-24-033337:mdna:31]

[0001437749-25-014767:mdna:33]
[same as prior period, unchanged from 0001437749-24-033337:mdna:32]

[0001437749-25-014767:mdna:34]
[same as prior period, unchanged from 0001437749-24-033337:mdna:33]

[0001437749-25-014767:mdna:35]
[same as prior period, unchanged from 0001437749-24-033337:mdna:34]

[0001437749-25-014767:mdna:36]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2024.

[0001437749-25-014767:mdna:37]
[same as prior period, unchanged from 0001437749-24-033337:mdna:37]

[0001437749-25-014767:mdna:38]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Refer to Note 10, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for further information. The year-over-year decrease in interest expense in the current period was primarily driven by lower borrowings and lower interest rates during the period.

[0001437749-25-014767:mdna:39]
[same as prior period, unchanged from 0001437749-24-033337:mdna:39]

[0001437749-25-014767:mdna:40]
The decrease year-over-year in the effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period that did not repeat in the current period.

[0001437749-25-014767:mdna:41]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to implement the Pillar Two rules and evaluate their potential impact on future periods. There was no impact to our financial results for the three months ended March 31, 2025, and we do not expect the rules to have a material impact on our effective tax rate for the remainder of the year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-25-014767:mdna:42]
[same as prior period, unchanged from 0001437749-24-033337:mdna:43]

[0001437749-25-014767:mdna:43]
Three months ended March 31, 2025, compared to the three months ended March 31, 2024

[0001437749-25-014767:mdna:44]
[same as prior period, unchanged from 0001437749-24-033337:mdna:45]

[0001437749-25-014767:mdna:45]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 942,121 |  |  | $ | 889,273 |  |  | $ | 52,848 |  |  |  | 5.9 | % |
| Costs of goods sold |  |  | 570,135 |  |  |  | 572,894 |  |  |  | (2,759 | ) |  |  | -0.5 | % |
| Gross profit |  |  | 371,986 |  |  |  | 316,379 |  |  |  | 55,607 |  |  |  | 17.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 126,065 |  |  |  | 108,586 |  |  |  | 17,479 |  |  |  | 16.1 | % |
| Research and development |  |  | 62,048 |  |  |  | 49,410 |  |  |  | 12,638 |  |  |  | 25.6 | % |
| General and administrative |  |  | 74,746 |  |  |  | 66,764 |  |  |  | 7,982 |  |  |  | 12.0 | % |
| Amortization of intangible assets |  |  | 25,489 |  |  |  | 24,750 |  |  |  | 739 |  |  |  | 3.0 | % |
| Total operating expenses |  |  | 288,348 |  |  |  | 249,510 |  |  |  | 38,838 |  |  |  | 15.6 | % |
| Income from operations |  |  | 83,638 |  |  |  | 66,869 |  |  |  | 16,769 |  |  |  | 25.1 | % |
| Total other expense, net |  |  | (25,124 | ) |  |  | (28,358 | ) |  |  | 3,234 |  |  |  | 11.4 | % |
| Income before provision for income taxes |  |  | 58,514 |  |  |  | 38,511 |  |  |  | 20,003 |  |  |  | 51.9 | % |
| Provision for income taxes |  |  | 14,236 |  |  |  | 12,033 |  |  |  | 2,203 |  |  |  | 18.3 | % |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |  |  | 17,800 |  |  |  | 67.2 | % |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |  |  | 192 |  |  |  | 78.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |  | $ | 17,608 |  |  |  | 67.1 | % |

[0001437749-25-014767:mdna:46]
[same as prior period, unchanged from 0001437749-24-033337:mdna:47]

[0001437749-25-014767:mdna:47]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 774,642 |  |  | $ | 712,337 |  |  | $ | 62,305 |  |  |  | 8.7 | % |
| International |  |  | 167,479 |  |  |  | 176,936 |  |  |  | (9,457 | ) |  |  | -5.3 | % |
| Total net sales |  | $ | 942,121 |  |  | $ | 889,273 |  |  | $ | 52,848 |  |  |  | 5.9 | % |

[0001437749-25-014767:mdna:48]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2025 |  |  | Three Months Ended March 31, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 774,642 |  |  | $ | 7,694 |  |  | $ | 782,336 |  |  | $ | 712,337 |  |  | $ | 8,136 |  |  | $ | 720,473 |  |
| International |  |  | 167,479 |  |  |  | 18,062 |  |  |  | 185,541 |  |  |  | 176,936 |  |  |  | 9,772 |  |  |  | 186,708 |  |
| Intercompany elimination |  |  | - |  |  |  | (25,756 | ) |  |  | (25,756 | ) |  |  | - |  |  |  | (17,908 | ) |  |  | (17,908 | ) |
| Total net sales |  | $ | 942,121 |  |  | $ | - |  |  | $ | 942,121 |  |  | $ | 889,273 |  |  | $ | - |  |  | $ | 889,273 |  |

[0001437749-25-014767:mdna:49]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 122,513 |  |  | $ | 99,175 |  |  | $ | 23,338 |  |  |  | 23.5 | % |
| International |  |  | 27,033 |  |  |  | 28,058 |  |  |  | (1,025 | ) |  |  | -3.7 | % |
| Total Adjusted EBITDA |  | $ | 149,546 |  |  | $ | 127,233 |  |  | $ | 22,313 |  |  |  | 17.5 | % |

[0001437749-25-014767:mdna:50]
[same as prior period, unchanged from 0001437749-24-033337:mdna:51]

[0001437749-25-014767:mdna:51]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 494,152 |  |  | $ | 428,950 |  |  | $ | 65,202 |  |  |  | 15.2 | % |
| Commercial & industrial products |  |  | 337,372 |  |  |  | 353,970 |  |  |  | (16,598 | ) |  |  | -4.7 | % |
| Other |  |  | 110,597 |  |  |  | 106,353 |  |  |  | 4,244 |  |  |  | 4.0 | % |
| Total net sales |  | $ | 942,121 |  |  | $ | 889,273 |  |  | $ | 52,848 |  |  |  | 5.9 | % |

[0001437749-25-014767:mdna:52]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 9% to $782.3 million in the first quarter of 2025, as compared to $720.5 million in the prior-year first quarter, including an approximately 2% benefit from acquisitions. This increase was primarily driven by higher sales of home standby generators and energy technology solutions, as well as growth in C&I product shipments to national telecom customers and industrial distributors. This growth was partially offset by lower C&I product sales to national rental accounts and other direct customers for “beyond standby” applications.

[0001437749-25-014767:mdna:53]
International segment total sales (including inter-segment sales) decreased slightly to $185.5 million in the first quarter of 2025, as compared to $186.7 million in the prior-year first quarter, including an approximate 5% unfavorable impact from foreign currency. Excluding the impact of foreign currency, the total sales growth for the segment was primarily driven by strength in residential product shipments in Latin America as well as higher inter-segment sales to the U.S. market, partially offset by softer C&I shipments in most global end markets that we serve.

[0001437749-25-014767:mdna:54]
In addition, total contribution from non-annualized acquisitions for the first quarter of 2025 was $11.2 million for the domestic segment.

[0001437749-25-014767:mdna:55]
Gross profit.   Gross profit margin for the first quarter of 2025 was 39.5%, as compared to 35.6% in the prior-year first quarter. The increase in gross margin was primarily driven by favorable sales mix and realization of lower input costs.

[0001437749-25-014767:mdna:56]
Operating Expenses.   Operating expenses increased $38.8 million, or 15.6%, as compared to the prior-year first quarter. The growth in operating expenses was primarily driven by increased employee costs to support future growth across the business, higher marketing spend to drive incremental awareness for our products, and ongoing operating expenses related to recent acquisitions.

[0001437749-25-014767:mdna:57]
Other Expense.   The decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings and lower interest rates compared to the prior-year first quarter. This was partially offset by a larger loss on the change in the fair value of the Company's investment in Wallbox N.V. shares and warrants.

[0001437749-25-014767:mdna:58]
Provision for income taxes.   Provision for income taxes for the first quarter of 2025 was $14.2 million, or an effective tax rate of 24.3%, as compared to $12.0 million, or a 31.2% effective tax rate, for the prior-year first quarter. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period that did not repeat in the current period.

[0001437749-25-014767:mdna:59]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the first quarter of 2025 was $43.8 million compared to $26.2 million in the prior-year first quarter. This increase was primarily driven by the factors outlined above.

[0001437749-25-014767:mdna:60]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the first quarter of 2025 was $122.5 million, or 15.7% of domestic segment total sales, as compared to $99.2 million, or 13.8% of total sales, in the prior-year first quarter. This margin improvement was primarily driven by favorable sales mix and lower input costs, partially offset by increased operating expense investments to support future growth.

[0001437749-25-014767:mdna:61]
Adjusted EBITDA for the international segment in the first quarter of 2025, before deducting for non-controlling interests, was $27.0 million, or 14.6% of international segment total sales, as compared to $28.0 million, or 15.0% of total sales, in the prior-year first quarter. This slight margin decline was primarily driven by unfavorable sales mix and higher operating expenses during the quarter.

[0001437749-25-014767:mdna:62]
Adjusted Net Income.   Adjusted Net Income in the first quarter of 2025 was $75.4 million compared to $53.0 million in the prior-year first quarter. This increase was primarily driven by higher net income in the current period as outlined above together with changes in certain add-back items.

[0001437749-25-014767:mdna:63]
[same as prior period, unchanged from 0001437749-24-033337:mdna:64]

[0001437749-25-014767:mdna:64]
[same as prior period, unchanged from 0001437749-24-033337:mdna:87]

[0001437749-25-014767:mdna:65]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-25-014767:mdna:66]
As of March 31, 2025, there was $497.5 million outstanding under the New Term Loan B Facility, $703.1 million outstanding under the Tranche A Term Loan Facility, and no borrowings on the Revolving Facility, leaving $1,249.2 million of unused capacity, net of outstanding letters of credit. The New Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of March 31, 2025, the interest rate for the New Term Loan B Facility is 6.06%. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of March 31, 2025, the interest rate for the Tranche A Term Loan Facility is 5.92% and the interest rate for the Revolving Facility is 5.93%. There were no borrowings under the Revolving Facility as of March 31, 2025.

[0001437749-25-014767:mdna:67]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in our Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of March 31, 2025, our net secured leverage ratio was 1.33 to 1.00, and we were in compliance with all covenants of the Facility. There are no financial maintenance covenants on the Term Loan B Facility. The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of March 31, 2025, our total leverage ratio was 1.40 to 1.00, and our interest coverage ratio was 11.25 to 1.00. We were also in compliance with all other covenants of the Amended Credit Agreement as of March 31, 2025.

[0001437749-25-014767:mdna:68]
In July 2022, our Board of Directors approved a stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaced the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. As of March 31, 2025, the remaining unused buyback authorization under the current program was $249.8 million.

[0001437749-25-014767:mdna:69]
During the first quarter of 2025, we repurchased 716,685 shares of common stock for $97.5 million. There were no share repurchases under the program during the first quarter of 2024. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-25-014767:mdna:70]
See Note 10, “Credit Agreements,” and Note 11, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-25-014767:mdna:71]
As of March 31, 2025, we had total liquidity of $1,436.7 million which consists of $187.5 million of cash and cash equivalents and $1,249.2 million of availability under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan, fund common stock buybacks, and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-25-014767:mdna:72]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 15% and 12% of net sales for the three months ended March 31, 2025 and 2024, respectively. The amount financed by dealers which remained outstanding under this arrangement was $185.0 million and $165.4 million as of March 31, 2025, and December 31, 2024, respectively.

[0001437749-25-014767:mdna:73]
[same as prior period, unchanged from 0001437749-24-033337:mdna:103]

[0001437749-25-014767:mdna:74]
We believe our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other activities that drive incremental shareholder value.

[0001437749-25-014767:mdna:75]
[same as prior period, unchanged from 0001437749-24-033337:mdna:105]

[0001437749-25-014767:mdna:76]
Three months ended March 31, 2025, compared to the three months ended March 31, 2024

[0001437749-25-014767:mdna:77]
[same as prior period, unchanged from 0001437749-24-033337:mdna:107]

[0001437749-25-014767:mdna:78]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 58,152 |  |  | $ | 111,898 |  |  | $ | (53,746 | ) |  |  | -48.0 | % |
| Net cash used in investing activities |  |  | (33,539 | ) |  |  | (26,637 | ) |  |  | (6,902 | ) |  |  | -25.9 | % |
| Net cash used in financing activities |  |  | (119,719 | ) |  |  | (36,331 | ) |  |  | (83,388 | ) |  |  | -229.5 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 1,293 |  |  |  | (569 | ) |  |  | 1,862 |  |  |  | 327.2 | % |
| Net (decrease) increase in cash and cash equivalents |  | $ | (93,813 | ) |  | $ | 48,361 |  |  | $ | (142,174 | ) |  |  | -294.0 | % |

[0001437749-25-014767:mdna:79]
The decrease in operating cash flows for the three months ended March 31, 2025 was primarily driven by an increase in working capital in the current year period, which included the replenishment of certain residential product finished good inventories, partially offset by higher operating earnings.

[0001437749-25-014767:mdna:80]
The $33.5 million net cash used in investing activities for the three months ended March 31, 2025 primarily represents cash payments of $30.9 million related to the purchase of property and equipment and $2.6 million for the purchase of long-term investments.

[0001437749-25-014767:mdna:81]
The $26.6 million net cash used in investing activities for the three months ended March 31, 2024 primarily represents cash payments of $26.8 million related to the purchase of property and equipment, and $1.6 million for a tax equity investment. These were partially offset by $2.0 million of cash proceeds from the sale of our minority investment in Rolling Energy Resources.

[0001437749-25-014767:mdna:82]
The $119.7 million net cash used in financing activities for the three months ended March 31, 2025 primarily represents proceeds of $19.2 million from short-term borrowings, $0.9 million from long-term borrowings, and $0.6 million from the exercise of stock options. These cash proceeds were more than offset by $34.4 million of debt repayments ($20.0 million of short-term borrowings and $14.4 million of long-term borrowings and finance lease obligations), $97.5 million of share repurchases, and $8.6 million for taxes paid related to equity awards.

[0001437749-25-014767:mdna:83]
The $36.3 million net cash used in financing activities for the three months ended March 31, 2024 primarily represents proceeds of $9.0 million from short-term borrowings, $0.5 million from long-term borrowings, and $0.3 million from the exercise of stock options. These cash proceeds were more than offset by $25.5 million of debt repayments ($18.5 million of short-term borrowings and $7.0 million of long-term borrowings and finance lease obligations), a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment of deferred acquisition consideration related to our Chilicon acquisition, and $5.5 million for taxes paid related to equity awards.

[0001437749-25-014767:mdna:84]
[same as prior period, unchanged from 0001437749-24-033337:mdna:114]

[0001437749-25-014767:mdna:85]
There have been no material changes to our contractual obligations between the February 19, 2025, filing of our Annual Report on Form 10-K for the year ended December 31, 2024, and March 31, 2025, except for the changes in outstanding borrowings and interest rates as discussed in Note 10, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-25-014767:mdna:86]
[same as prior period, unchanged from 0001437749-24-033337:mdna:116]

[0001437749-25-014767:mdna:87]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2024, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes.

[0001437749-25-014767:mdna:88]
There have been no material changes in our critical accounting policies since the February 19, 2025, filing of our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001437749-25-014767:mdna:89]
[same as prior period, unchanged from 0001437749-24-033337:mdna:119]

[0001437749-25-014767:mdna:90]
[same as prior period, unchanged from 0001437749-24-033337:mdna:120]

[0001437749-25-014767:mdna:91]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Amended Credit Agreement.

[0001437749-25-014767:mdna:92]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes certain items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-25-014767:mdna:93]
[same as prior period, unchanged from 0001437749-24-033337:mdna:123]

[0001437749-25-014767:mdna:94]
[same as prior period, unchanged from 0001437749-24-033337:mdna:124]

[0001437749-25-014767:mdna:95]
|  | • | as a target for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-25-014767:mdna:96]
|  | • | to evaluate the effectiveness of our business strategies and as a tool in evaluating our performance against our budget for each period; and |

[0001437749-25-014767:mdna:97]
[same as prior period, unchanged from 0001437749-24-033337:mdna:127]

[0001437749-25-014767:mdna:98]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-25-014767:mdna:99]
|  | • | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-25-014767:mdna:100]
|  | • | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-25-014767:mdna:101]
[same as prior period, unchanged from 0001437749-24-033337:mdna:131]

[0001437749-25-014767:mdna:102]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-25-014767:mdna:103]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses, certain other specific provisions, and mark-to-market gains and losses on a minority investment; |

[0001437749-25-014767:mdna:104]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-25-014767:mdna:105]
|  | • | are non-cash in nature, such as share-based compensation. |
|  | • | the provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. |

[0001437749-25-014767:mdna:106]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-25-014767:mdna:107]
[same as prior period, unchanged from 0001437749-24-033337:mdna:137]

[0001437749-25-014767:mdna:108]
[same as prior period, unchanged from 0001437749-24-033337:mdna:138]

[0001437749-25-014767:mdna:109]
[same as prior period, unchanged from 0001437749-24-033337:mdna:139]

[0001437749-25-014767:mdna:110]
[same as prior period, unchanged from 0001437749-24-033337:mdna:140]

[0001437749-25-014767:mdna:111]
[same as prior period, unchanged from 0001437749-24-033337:mdna:141]

[0001437749-25-014767:mdna:112]
[same as prior period, unchanged from 0001437749-24-033337:mdna:142]

[0001437749-25-014767:mdna:113]
[same as prior period, unchanged from 0001437749-24-033337:mdna:143]

[0001437749-25-014767:mdna:114]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-25-014767:mdna:115]
[same as prior period, unchanged from 0001437749-24-033337:mdna:145]

[0001437749-25-014767:mdna:116]
[same as prior period, unchanged from 0001437749-24-033337:mdna:146]

[0001437749-25-014767:mdna:117]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |
| Interest expense |  |  | 17,110 |  |  |  | 23,605 |  |
| Depreciation and amortization |  |  | 46,141 |  |  |  | 41,902 |  |
| Provision for income taxes |  |  | 14,236 |  |  |  | 12,033 |  |
| Non-cash write-down and other adjustments (a) |  |  | (13 | ) |  |  | 510 |  |
| Non-cash share-based compensation expense (b) |  |  | 11,608 |  |  |  | 12,440 |  |
| Transaction costs and credit facility fees (c) |  |  | 760 |  |  |  | 1,425 |  |
| Business optimization and other charges (d) |  |  | 1,575 |  |  |  | 486 |  |
| Provision for legal, regulatory, and other matters (e) |  |  | 3,751 |  |  |  | 2,535 |  |
| Change in fair value of investment (f) |  |  | 9,947 |  |  |  | 6,019 |  |
| Other |  |  | 153 |  |  |  | (200 | ) |
| Adjusted EBITDA |  |  | 149,546 |  |  |  | 127,233 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 632 |  |  |  | 477 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 148,914 |  |  | $ | 126,756 |  |

[0001437749-25-014767:mdna:118]
(a)  Represents the following non-cash charges, gains, and other adjustments: gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-25-014767:mdna:119]
|  | • | The gains/losses on disposals of assets and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains/losses that are not from our core operations; |

[0001437749-25-014767:mdna:120]
|  | • | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and |
|  | • | The purchase accounting adjustments represent non-cash items to reflect fair value of certain assets at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price. |

[0001437749-25-014767:mdna:121]
(b)  Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods.

[0001437749-25-014767:mdna:122]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-25-014767:mdna:123]
[same as prior period, unchanged from 0001437749-24-033337:mdna:153]

[0001437749-25-014767:mdna:124]
(e)  Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-014767:mdna:125]
•  A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1.5 million in the first quarter of 2025 and $2.1 million in the first quarter of 2024.
       •  Legal expenses related to certain class action lawsuits - $1.4 million in the first quarter of 2025.
       •  Legal expenses related to certain government inquiries and other significant matters - $0.9 million in the first quarter of 2025.
       •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024.

[0001437749-25-014767:mdna:126]
(f) Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-014767:mdna:127]
[same as prior period, unchanged from 0001437749-24-033337:mdna:159]

[0001437749-25-014767:mdna:128]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests, as set forth in the reconciliation table below.

[0001437749-25-014767:mdna:129]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-25-014767:mdna:130]
[same as prior period, unchanged from 0001437749-24-033337:mdna:162]

[0001437749-25-014767:mdna:131]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-25-014767:mdna:132]
[same as prior period, unchanged from 0001437749-24-033337:mdna:164]

[0001437749-25-014767:mdna:133]
[same as prior period, unchanged from 0001437749-24-033337:mdna:165]

[0001437749-25-014767:mdna:134]
[same as prior period, unchanged from 0001437749-24-033337:mdna:166]

[0001437749-25-014767:mdna:135]
[same as prior period, unchanged from 0001437749-24-033337:mdna:167]

[0001437749-25-014767:mdna:136]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Net income |  |  | 44,278 |  |  |  | 26,478 |  |
| Amortization of intangible assets |  |  | 25,489 |  |  |  | 24,750 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 636 |  |  |  | 973 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 107 |  |  |  | 844 |  |
| Loss attributable to business or asset dispositions (b) |  |  | 390 |  |  |  | 37 |  |
| Business optimization and other charges (c) |  |  | 1,575 |  |  |  | 486 |  |
| Provision for legal, regulatory, and other matters (c) |  |  | 3,751 |  |  |  | 2,535 |  |
| Change in fair value of investment (c) |  |  | 9,947 |  |  |  | 6,019 |  |
| Tax effect of add backs |  |  | (10,369 | ) |  |  | (8,925 | ) |
| Adjusted net income |  |  | 75,804 |  |  |  | 53,197 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 438 |  |  |  | 246 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 75,366 |  |  | $ | 52,951 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.26 |  |  | $ | 0.88 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,747,589 |  |  |  | 60,486,125 |  |

[0001437749-25-014767:mdna:137]
[same as prior period, unchanged from 0001437749-24-033337:mdna:169]

[0001437749-25-014767:mdna:138]
(b)  Represents losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-25-014767:mdna:139]
[same as prior period, unchanged from 0001437749-24-033337:mdna:171]

[0001437749-25-014767:mdna:140]
[same as prior period, unchanged from 0001437749-24-033337:mdna:172]

[0001437749-25-014767:mdna:141]
[same as prior period, unchanged from 0001437749-24-033337:mdna:173]
