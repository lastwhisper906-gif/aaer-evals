# GNRC notes — 0001437749-25-014767


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-25-014767:notes:1]
[same as prior period, unchanged from 0001437749-24-033337:notes:1]

[0001437749-25-014767:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-25-014767:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in the Company's Annual Report on Form 10-K for the year ended  December 31, 2024, for a discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-25-014767:notes:4]
|  | ● | In November 2024, the Company acquired Wolverine Power Systems (Wolverine), headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC (Ageto). Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System (C&I BESS) product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. (Huntington), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |

[0001437749-25-014767:notes:5]
The condensed consolidated balance sheet as of  March 31, 2025, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2025 and 2024, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-25-014767:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates. The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-25-014767:notes:7]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended  December 31, 2024.

[0001437749-25-014767:notes:8]
[same as prior period, unchanged from 0001437749-24-033337:notes:8]

[0001437749-25-014767:notes:9]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC).

[0001437749-25-014767:notes:10]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-25-014767:notes:11]
In  March 2024, the Securities and Exchange Commission (SEC) adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. On  March 27, 2025, the SEC voted to discontinue the agency's defense of the climate disclosure rule in court. The rule will remain under a stay pending a final court decision. The Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the disclosures are required.

[0001437749-25-014767:notes:12]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-25-014767:notes:13]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update was effective for fiscal year 2024 and is effective for interim periods in fiscal 2025. The required annual disclosures are reflected in Note 7, "Segment Reporting," to the 2024 Annual Report on Form 10-K and the required quarterly disclosures are reflected in Note 6, "Segment Reporting," of this Quarterly Report on Form 10-Q.

[0001437749-25-014767:notes:14]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the three months ended  March 31, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-014767:notes:15]
[same as prior period, unchanged from 0001437749-24-033337:notes:14]

[0001437749-25-014767:notes:16]
[same as prior period, unchanged from 0001437749-24-033337:notes:15]

[0001437749-25-014767:notes:17]
On  November 1, 2024, the Company acquired Wolverine, headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-25-014767:notes:18]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto. Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado.

[0001437749-25-014767:notes:19]
[same as prior period, unchanged from 0001437749-24-033337:notes:17]

[0001437749-25-014767:notes:20]
[same as prior period, unchanged from 0001437749-24-033337:notes:18]

[0001437749-25-014767:notes:21]
The combined preliminary purchase price for these acquisitions was $46,265, net of cash acquired and inclusive of holdbacks and estimated contingent consideration. The Company recorded its preliminary purchase price allocations based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington will be finalized prior to  June 30, 2025, while purchase accounting for Ageto will be finalized prior to  September 30, 2025, and purchase accounting for Wolverine will be finalized prior to  December 31, 2025. There have not been any material changes to the preliminary purchase price allocation for Wolverine, Ageto, C&I BESS, or Huntington as of  March 31, 2025.

[0001437749-25-014767:notes:22]
The accompanying condensed consolidated financial statements include the results of Wolverine, Ageto, C&I BESS, and Huntington from their dates of acquisition through  March 31, 2025. Pro forma and other financial information are not presented as the effects of these acquisitions are not material to the Company's results of operations or financial position.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-25-014767:notes:23]
3.   Derivative Instruments and Hedging Activities

[0001437749-25-014767:notes:24]
[same as prior period, unchanged from 0001437749-24-033337:notes:30]

[0001437749-25-014767:notes:25]
[same as prior period, unchanged from 0001437749-24-033337:notes:31]

[0001437749-25-014767:notes:26]
[same as prior period, unchanged from 0001437749-24-033337:notes:32]

[0001437749-25-014767:notes:27]
[same as prior period, unchanged from 0001437749-24-033337:notes:33]

[0001437749-25-014767:notes:28]
In  March 2020, the Company entered into three interest rate swap agreements, which were still outstanding as of  March 31, 2025. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets.

[0001437749-25-014767:notes:29]
The amount of after-tax unrealized (losses) gains recognized in AOCL for the three months ended  March 31, 2025 and 2024, was $(4,313) and $1,982, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-25-014767:notes:30]
[same as prior period, unchanged from 0001437749-24-033337:notes:37]

[0001437749-25-014767:notes:31]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. (Wallbox) to purchase 5% of its Class A common stock (Wallbox Shares) and acquire stock warrants, the latter of which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024, the Company received additional warrants in connection with an additional round of funding performed by Wallbox through the Company's anti-dilution protection rights. In accordance with U.S. GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the condensed consolidated statements of comprehensive income.

[0001437749-25-014767:notes:32]
The loss attributable to the stock warrants was $3,356 and $4,849 for the three months ended  March 31, 2025 and 2024, respectively.

[0001437749-25-014767:notes:33]
[same as prior period, unchanged from 0001437749-24-033337:notes:40]

[0001437749-25-014767:notes:34]
The following table presents the fair value of all the Company’s interest rate swaps and stock warrants.

[0001437749-25-014767:notes:35]
|  |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Interest rate swaps |  | $ | 22,634 |  |  | $ | 28,367 |  |
| Stock warrants |  |  | 4,563 |  |  |  | 7,919 |  |

[0001437749-25-014767:notes:36]
The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the condensed consolidated balance sheet as of  March 31, 2025, and  December 31, 2024. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  March 31, 2025, and  December 31, 2024, is an asset of $23,323 and $29,254, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-014767:notes:37]
4.   Fair Value Measurements

[0001437749-25-014767:notes:38]
[same as prior period, unchanged from 0001437749-24-033337:notes:45]

[0001437749-25-014767:notes:39]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility (Revolving Facility) borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Tranche A Term Loan Facility borrowing, which has a net carrying value of $701,530, was approximately $696,094 (Level 2) as of  March 31, 2025. The fair value of the Term Loan B Facility borrowing, which has a net carrying value of $494,774, was approximately $497,500 (Level 2) as of  March 31, 2025. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-25-014767:notes:40]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 3, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements of this Quarterly Report on Form 10-Q. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-25-014767:notes:41]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these warrants is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in the third quarter of 2024 and fourth quarter of 2023 expire at the earlier of when the price per share equals or exceeds $6.00 or in 2028 and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-25-014767:notes:42]
[same as prior period, unchanged from 0001437749-24-033337:notes:49]

[0001437749-25-014767:notes:43]
Equity securities primarily consist of Wallbox Shares. During the third quarter of 2024, the Company invested an incremental $35,000 in additional Wallbox Shares, increasing its ownership interest to 38,096,057 Wallbox Shares. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $12,484 and $19,075 as of  March 31, 2025, and  December 31, 2024, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the condensed consolidated statements of comprehensive income. The loss recognized on the Wallbox Shares was $6,591 and $1,170 for the three months ended  March 31, 2025 and 2024, respectively.

[0001437749-25-014767:notes:44]
[same as prior period, unchanged from 0001437749-24-033337:notes:51]

[0001437749-25-014767:notes:45]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's condensed consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-25-014767:notes:46]
The combined fair value of contingent consideration for the Chilicon, Ageto, and Pramac acquisitions as of  March 31, 2025, and  December 31, 2024, was $34,451 and $34,114, respectively. The contingent consideration period for Chilicon extends through  December 31, 2028, while the contingent consideration period for Pramac extends through  December 31, 2025. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration capable of being earned each year as of  August 1, 2025,  August 1, 2026, and  August 1, 2027. The current portion of contingent consideration is reported in other accrued liabilities and the non-current portion is reported in operating lease and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-25-014767:notes:47]
[same as prior period, unchanged from 0001437749-24-033337:notes:54]

[0001437749-25-014767:notes:48]
| Beginning balance, January 1, 2025 |  | $ | 34,114 |  |
| Present value interest accretion |  |  | 337 |  |
| Ending balance, March 31, 2025 |  | $ | 34,451 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-25-014767:notes:49]
5.   Accumulated Other Comprehensive Loss

[0001437749-25-014767:notes:50]
The following table presents a disclosure of changes in AOCL during the three months ended  March 31, 2025 and 2024, net of tax:

[0001437749-25-014767:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2025 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |
| Other comprehensive income (loss) |  |  | 29,272 |  | (1) |  |  | (4,313 | ) | (2) |  |  | 24,959 |  |
| Ending Balance – March 31, 2025 |  | $ | (76,894 | ) |  |  | $ | 16,454 |  |  |  | $ | (60,440 | ) |

[0001437749-25-014767:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  |  | (5,671 | ) | (3) |  |  | 1,982 |  | (4) |  |  | (3,689 | ) |
| Ending Balance – March 31, 2024 |  | $ | (49,253 | ) |  |  | $ | 30,421 |  |  |  | $ | (18,832 | ) |

[0001437749-25-014767:notes:53]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three months ended March 31, 2025, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized losses of $(5,732) on the interest rate swaps, net of tax recognized of $1,419, for the three months ended March 31, 2025. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2024. |
|  | (4) | Represents unrealized gains of $2,644 on the interest rate swaps, net of tax recognized of $(662), for the three months ended March 31, 2024. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-014767:notes:54]
6.   Segment Reporting

[0001437749-25-014767:notes:55]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and all historical acquisitions based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes all historical acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations. Intersegment sales are at an appropriate transfer price.

[0001437749-25-014767:notes:56]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-25-014767:notes:57]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 473,291 |  |  | $ | 20,861 |  |  | $ | 494,152 |  |
| Commercial & industrial products |  |  | 206,145 |  |  |  | 131,227 |  |  |  | 337,372 |  |
| Other |  |  | 95,206 |  |  |  | 15,391 |  |  |  | 110,597 |  |
| Total net sales |  | $ | 774,642 |  |  | $ | 167,479 |  |  | $ | 942,121 |  |

[0001437749-25-014767:notes:58]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |

[0001437749-25-014767:notes:59]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end consumer, sometimes including installation and maintenance services. In some cases, residential products are sold directly to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-25-014767:notes:60]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction (EPC) companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end customer, sometimes including installation and maintenance services. In some cases, C&I products are sold directly to the end customer. Substantially all of the C&I products' revenues are transferred to the customer at a point in time.

[0001437749-25-014767:notes:61]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain design, build, installation, and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes after certain milestones are met.

[0001437749-25-014767:notes:62]
The Company views Adjusted EBITDA as a key measure of the Company's performance. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements. The Company presents Adjusted EBITDA not only due to its importance for purposes of the Company's credit agreements, but also because it assists the Company in comparing performance across reporting periods on a consistent basis as it excludes items the Company's management does not believe are indicative of the Company's core operating performance. The Company's Chief Operating Decision Maker (CODM) is Aaron Jagdfeld, President and Chief Executive Officer (CEO). He uses Adjusted EBITDA, along with the Company's management:

[0001437749-25-014767:notes:63]
|  | ● | for planning purposes, including the preparation of the Company's annual operating budget and developing and refining internal projections for future periods; |
|  | ● | to allocate resources to enhance the financial performance of the Company's business; |
|  | ● | as a target for the determination of the bonus component of compensation for the Company's senior executives under the Company's management incentive plan, as described further in the Company's Proxy Statement; |
|  | ● | to evaluate the effectiveness of the Company's business strategies and as a tool in evaluating the Company's performance against the Company's budget for each period; and |
|  | ● | in communications with the Company's Board of Directors and investors concerning the Company's financial performance. |

[0001437749-25-014767:notes:64]
The table below presents sales (external and intersegment), significant segment expenses, other segment items, and Adjusted EBITDA by reportable segment, reconciled to consolidated income before provision for income taxes.

[0001437749-25-014767:notes:65]
|  |  | Three Months Ended March 31, 2025 |  |  | Three Months Ended March 31, 2024 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 774,642 |  |  | $ | 167,479 |  |  | $ | 942,121 |  |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |
| Intersegment sales |  |  | 7,694 |  |  |  | 18,062 |  |  |  | 25,756 |  |  |  | 8,136 |  |  |  | 9,772 |  |  |  | 17,908 |  |
| Total sales |  |  | 782,336 |  |  |  | 185,541 |  |  |  | 967,877 |  |  |  | 720,473 |  |  |  | 186,708 |  |  |  | 907,181 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (25,756 | ) |  |  |  |  |  |  |  |  |  |  | (17,908 | ) |
| Costs of goods sold |  |  | 460,972 |  |  |  | 134,919 |  |  |  | 595,891 |  |  |  | 455,321 |  |  |  | 135,481 |  |  |  | 590,802 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (25,756 | ) |  |  |  |  |  |  |  |  |  |  | (17,908 | ) |
| Operating expenses |  |  | 254,709 |  |  |  | 33,639 |  |  |  | 288,348 |  |  |  | 215,648 |  |  |  | 33,862 |  |  |  | 249,510 |  |
| Other segment items (1) |  |  | (55,858 | ) |  |  | (10,050 | ) |  |  | (65,908 | ) |  |  | (49,671 | ) |  |  | (10,693 | ) |  |  | (60,364 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 122,513 |  |  | $ | 27,033 |  |  | $ | 149,546 |  |  | $ | 99,175 |  |  | $ | 28,058 |  |  | $ | 127,233 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (17,110 | ) |  |  |  |  |  |  |  |  |  |  | (23,605 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (46,141 | ) |  |  |  |  |  |  |  |  |  |  | (41,902 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  | (510 | ) |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (11,608 | ) |  |  |  |  |  |  |  |  |  |  | (12,440 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (760 | ) |  |  |  |  |  |  |  |  |  |  | (1,425 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (1,575 | ) |  |  |  |  |  |  |  |  |  |  | (486 | ) |
| Provision for legal, regulatory, and other matters (6) |  |  |  |  |  |  |  |  |  |  | (3,751 | ) |  |  |  |  |  |  |  |  |  |  | (2,535 | ) |
| Change in fair value of investment (7) |  |  |  |  |  |  |  |  |  |  | (9,947 | ) |  |  |  |  |  |  |  |  |  |  | (6,019 | ) |
| Other |  |  |  |  |  |  |  |  |  |  | (153 | ) |  |  |  |  |  |  |  |  |  |  | 200 |  |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 58,514 |  |  |  |  |  |  |  |  |  |  | $ | 38,511 |  |

[0001437749-25-014767:notes:66]
|  | (1) | Other segment items primarily represent depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; and Provision for legal, regulatory, and clean energy product charges. |
|  | (2) | Includes gains (losses) on dispositions of assets other than in the ordinary course of business, gains (losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-25-014767:notes:67]
|  | (3) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-25-014767:notes:68]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's Amended Credit Agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (6) | Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1,492 in the first quarter of 2025 and $2,170 in the first quarter of 2024. • Legal expenses related to certain class action lawsuits - $1,343 in the first quarter of 2025. • Legal expenses related to certain government inquiries and other significant matters - $916 in the first quarter of 2025. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 in the first quarter of 2024. |
|  | (7) | Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |

[0001437749-25-014767:notes:69]
The following tables summarize additional financial information by reportable segment:

[0001437749-25-014767:notes:70]
|  |  | Assets by Reportable Segment |  |
|  |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Domestic |  | $ | 3,753,902 |  |  | $ | 3,873,904 |  |
| International |  |  | 1,306,552 |  |  |  | 1,235,427 |  |
| Total |  | $ | 5,060,454 |  |  | $ | 5,109,331 |  |

[0001437749-25-014767:notes:71]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 37,821 |  |  | $ | 34,148 |  |
| International |  |  | 8,320 |  |  |  | 7,754 |  |
| Total |  | $ | 46,141 |  |  | $ | 41,902 |  |

[0001437749-25-014767:notes:72]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 28,297 |  |  | $ | 24,166 |  |
| International |  |  | 2,640 |  |  |  | 2,654 |  |
| Total |  | $ | 30,937 |  |  | $ | 26,820 |  |

[0001437749-25-014767:notes:73]
The Company’s sales in the U.S. represented approximately 78% and 76% of total sales for the three months ended  March 31, 2025 and 2024, respectively. Approximately 76% of the Company's identifiable long-lived assets were located in the U.S. as of both  March 31, 2025, and  December 31, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-25-014767:notes:74]
7.   Balance Sheet Details

[0001437749-25-014767:notes:75]
[same as prior period, unchanged from 0001437749-24-033337:notes:83]

[0001437749-25-014767:notes:76]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Raw material |  | $ | 597,640 |  |  | $ | 611,735 |  |
| Work-in-process |  |  | 8,510 |  |  |  | 6,814 |  |
| Finished goods |  |  | 488,932 |  |  |  | 413,098 |  |
| Total |  | $ | 1,095,082 |  |  | $ | 1,031,647 |  |

[0001437749-25-014767:notes:77]
[same as prior period, unchanged from 0001437749-24-033337:notes:85]

[0001437749-25-014767:notes:78]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Land and improvements |  | $ | 30,552 |  |  | $ | 30,220 |  |
| Buildings and improvements |  |  | 359,181 |  |  |  | 358,055 |  |
| Machinery and equipment |  |  | 302,515 |  |  |  | 296,409 |  |
| Dies and tools |  |  | 50,871 |  |  |  | 48,681 |  |
| Vehicles |  |  | 18,466 |  |  |  | 13,887 |  |
| Office & information technology equipment and internal use software |  |  | 220,619 |  |  |  | 213,003 |  |
| Leasehold improvements |  |  | 9,976 |  |  |  | 9,776 |  |
| Construction in progress |  |  | 127,611 |  |  |  | 110,651 |  |
| Gross property and equipment |  |  | 1,119,791 |  |  |  | 1,080,682 |  |
| Accumulated depreciation |  |  | (410,261 | ) |  |  | (390,659 | ) |
| Total |  | $ | 709,530 |  |  | $ | 690,023 |  |

[0001437749-25-014767:notes:79]
Total property and equipment includes finance leases of $61,722 and $61,214 on  March 31, 2025, and  December 31, 2024, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-25-014767:notes:80]
8.   Product Warranty Obligations

[0001437749-25-014767:notes:81]
[same as prior period, unchanged from 0001437749-24-033337:notes:89]

[0001437749-25-014767:notes:82]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 110,987 |  |  | $ | 116,408 |  |
| Payments |  |  | (20,887 | ) |  |  | (21,347 | ) |
| Provision for warranty issued |  |  | 18,118 |  |  |  | 15,304 |  |
| Changes in estimates for pre-existing warranties |  |  | 2,499 |  |  |  | 761 |  |
| Balance at end of period |  | $ | 110,717 |  |  | $ | 111,126 |  |

[0001437749-25-014767:notes:83]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the condensed consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-25-014767:notes:84]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 186,922 |  |  | $ | 155,870 |  |
| Deferred revenue contracts issued |  |  | 15,818 |  |  |  | 14,784 |  |
| Amortization of deferred revenue contracts |  |  | (8,337 | ) |  |  | (6,861 | ) |
| Balance at end of period |  | $ | 194,403 |  |  | $ | 163,793 |  |

[0001437749-25-014767:notes:85]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  March 31, 2025 is as follows:

[0001437749-25-014767:notes:86]
| Remainder of 2025 |  | $ | 25,671 |  |
| 2026 |  |  | 36,529 |  |
| 2027 |  |  | 35,203 |  |
| 2028 |  |  | 28,666 |  |
| 2029 |  |  | 22,491 |  |
| After 2029 |  |  | 45,843 |  |
| Total |  | $ | 194,403 |  |

[0001437749-25-014767:notes:87]
[same as prior period, unchanged from 0001437749-24-033337:notes:95]

[0001437749-25-014767:notes:88]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 56,161 |  |  | $ | 56,127 |  |
| Long-term portion - other long-term liabilities |  |  | 54,556 |  |  |  | 54,860 |  |
| Total |  | $ | 110,717 |  |  | $ | 110,987 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - Other accrued liabilities |  | $ | 34,670 |  |  | $ | 34,069 |  |
| Long-term portion - Deferred Revenue |  |  | 159,733 |  |  |  | 152,853 |  |
| Total |  | $ | 194,403 |  |  | $ | 186,922 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-014767:notes:89]
9.   Contract Balances

[0001437749-25-014767:notes:90]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $29,424 and $26,858 on  March 31, 2025, and  December 31, 2024, respectively. During the three months ended  March 31, 2025 the Company recognized revenue of $10,189 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-014767:notes:91]
10.   Credit Agreements

[0001437749-25-014767:notes:92]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2025, and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $56,533 and $55,848, respectively. As of  March 31, 2025, and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.85% and 5.44%, respectively.

[0001437749-25-014767:notes:93]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-25-014767:notes:94]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 703,125 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 497,500 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (7,567 | ) |  |  | (8,203 | ) |
| Finance lease obligation |  |  | 67,042 |  |  |  | 66,355 |  |
| Other |  |  | 8,068 |  |  |  | 8,972 |  |
| Total |  |  | 1,268,168 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 64,550 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 7,757 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,195,861 |  |  | $ | 1,210,776 |  |

[0001437749-25-014767:notes:95]
The Tranche A Term Loan Facility matures on  June 29, 2027. The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility and Term Loan B Facility outstanding on  March 31, 2025, before considering original issue discount and deferred financing costs, are as follows:

[0001437749-25-014767:notes:96]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Total |  |
| 2025 |  | $ | 37,500 |  |  | $ | 3,750 |  |  | $ | 41,250 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | 468,750 |  |
| Total |  | $ | 703,125 |  |  | $ | 497,500 |  |  | $ | 1,200,625 |  |

[0001437749-25-014767:notes:97]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.

[0001437749-25-014767:notes:98]
In
      July 2024, the Company extinguished the
     $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new
     $500,000 Tranche B Term Loan Facility maturing on
      July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a
     $300,000 uncommitted incremental term loan on that facility. In accordance with ASC
     470-
     50, the Company capitalized
     $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of
     $4,236 and expensed
     $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of
     1.75%, subject to a SOFR floor of
     0.0%,
     resulting in a 6.06% combined rate as of  March 31, 2025.

[0001437749-25-014767:notes:99]
The New Term Loan B Facility does
      not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below
      3.75 to
      1.00. As of
       March 31, 2025, the Company’s net secured leverag
      e ratio was 1.33 to 1.0
      0, and the Company was in compliance with all covenants under the Facility. There are
      no financial maintenance covenants on the Term Loan B Facility.

[0001437749-25-014767:notes:100]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2025, the interest rate for the Tranche A Term Loan Facility is 5.92% and the interest rate for the Revolving Facility is 5.93%. There were no borrowings under the Revolving Facility as of  March 31, 2025, and  December 31, 2024.

[0001437749-25-014767:notes:101]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2025, the Company’s total leverage ratio was 1.40 to 1.00, and the Company's interest coverage ratio was 11.25 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2025.

[0001437749-25-014767:notes:102]
The New Term Loan B Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-25-014767:notes:103]
As of  March 31, 2025, the Revolving Facility had $1,249,203 of unused capacity, net of outstanding letters of credit.

[0001437749-25-014767:notes:104]
See Item 7A of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:TreasuryStockTextBlock

[0001437749-25-014767:notes:105]
11.   Stock Repurchase Program

[0001437749-25-014767:notes:106]
In  July 2022, the Company's Board of Directors approved a stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the following 24 months. The new program replaced the prior share repurchase program, which had $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-25-014767:notes:107]
During the first quarter of 2025, the Company repurchased 716,685 shares of common stock for $97,454. There were no share repurchases under the program during the first quarter of 2024. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-014767:notes:108]
12. Earnings Per Share

[0001437749-25-014767:notes:109]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of outstanding stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interest,” of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-25-014767:notes:110]
[same as prior period, unchanged from 0001437749-24-033337:notes:118]

[0001437749-25-014767:notes:111]
|  |  | Three Months Ended March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 43,840 |  |  | $ | 26,232 |  |
| Redemption value adjustment |  |  | - |  |  |  | (2,686) |  |
| Net income attributable to common shareholders |  | $ | 43,840 |  |  | $ | 23,546 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 59,062,534 |  |  |  | 59,849,362 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 685,055 |  |  |  | 636,763 |  |
| Diluted shares |  |  | 59,747,589 |  |  |  | 60,486,125 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.74 |  |  | $ | 0.39 |  |
| Diluted |  | $ | 0.73 |  |  | $ | 0.39 |  |

[0001437749-25-014767:notes:112]
(1) Excludes approximately 402,000 and 427,000 stock options and restricted stock awards for the three months  March 31, 2025 and 2024, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-014767:notes:113]
13. Income Taxes

[0001437749-25-014767:notes:114]
The effective income tax rates for the three months ended  March 31, 2025 and 2024 were 24.3% and 31.2%, respectively. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period that did not repeat in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-014767:notes:115]
14. Commitments and Contingencies

[0001437749-25-014767:notes:116]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  March 31, 2025, and  December 31, 2024, was $184,956 and $165,432, respectively.

[0001437749-25-014767:notes:117]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-25-014767:notes:118]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-25-014767:notes:119]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025, which the Company intends to move to dismiss.

[0001437749-25-014767:notes:120]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-25-014767:notes:121]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.

[0001437749-25-014767:notes:122]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-25-014767:notes:123]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023, jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-25-014767:notes:124]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics' purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

[0001437749-25-014767:notes:125]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-25-014767:notes:126]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-25-014767:notes:127]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies the allegations and intends to vigorously defend the matter.

[0001437749-25-014767:notes:128]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

[0001437749-25-014767:notes:129]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-25-014767:notes:130]
Item 5.           Other Information

[0001437749-25-014767:notes:131]
On  March 6, 2025, Aaron Jagdfeld, our Chief Executive Officer, modified a Rule 10b5-1 trading arrangement originally adopted on  November 19, 2024, to change the amount of shares to be sold under the arrangement, the price limits for sales under the arrangement, and timing of sales under the arrangement. The modified Rule 10b5-1 trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c) and provides for (i) the sale of up to 31,303 shares of the Company’s common stock; and (ii) the exercise of stock options to acquire 13,697 shares of the Company’s common stock and the sale of those acquired shares until  February 27, 2026.
