# GNRC notes — 0001437749-22-019367


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-22-019367:notes:1]
[same as prior period, unchanged from 0001437749-22-011515:notes:1]

[0001437749-22-019367:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-22-019367:notes:3]
[same as prior period, unchanged from 0001437749-22-011515:notes:3]

[0001437749-22-019367:notes:4]
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security, and peace of mind. |
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |

[0001437749-22-019367:notes:5]
[same as prior period, unchanged from 0001437749-22-011515:notes:5]

[0001437749-22-019367:notes:6]
The condensed consolidated balance sheet as of  June 30, 2022, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-22-019367:notes:7]
[same as prior period, unchanged from 0001437749-22-011515:notes:7]

[0001437749-22-019367:notes:8]
[same as prior period, unchanged from 0001437749-22-011515:notes:8]

[0001437749-22-019367:notes:9]
[same as prior period, unchanged from 0001437749-22-011515:notes:9]

[0001437749-22-019367:notes:10]
[same as prior period, unchanged from 0001437749-22-011515:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-019367:notes:11]
[same as prior period, unchanged from 0001437749-22-011515:notes:11]

[0001437749-22-019367:notes:12]
Fiscal 2022 Acquisitions

[0001437749-22-019367:notes:13]
On  June 30, 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services.

[0001437749-22-019367:notes:14]
[same as prior period, unchanged from 0001437749-22-011515:notes:12]

[0001437749-22-019367:notes:15]
[same as prior period, unchanged from 0001437749-22-011515:notes:13]

[0001437749-22-019367:notes:16]
[same as prior period, unchanged from 0001437749-22-011515:notes:14]

[0001437749-22-019367:notes:17]
The Company finalized its purchase price allocation during the second quarter of 2022 based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $437,874 of intangible assets, including $263,604 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Deep Sea from the date of acquisition through  June 30, 2022.

[0001437749-22-019367:notes:18]
[same as prior period, unchanged from 0001437749-22-011515:notes:16]

[0001437749-22-019367:notes:19]
[same as prior period, unchanged from 0001437749-22-011515:notes:17]

[0001437749-22-019367:notes:20]
| Cash paid at closing |  | $ | 11,821 |  |
| Deferred cash payment (1) |  |  | 6,000 |  |
| Common stock issued at closing |  |  | 12,000 |  |
| Contingent consideration (2) |  |  | 31,308 |  |
| Total purchase price |  | $ | 61,129 |  |

[0001437749-22-019367:notes:21]
[same as prior period, unchanged from 0001437749-22-011515:notes:19]

[0001437749-22-019367:notes:22]
The Company finalized its purchase price allocation during the second quarter of 2022 based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $70,174 of intangible assets, including $36,974 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Chilicon from the date of acquisition through  June 30, 2022.

[0001437749-22-019367:notes:23]
[same as prior period, unchanged from 0001437749-22-011515:notes:21]

[0001437749-22-019367:notes:24]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $56,949, net of cash acquired and inclusive of estimated contingent consideration of $29,054 that is to be paid in cash upon achievement of certain performance targets at the end of the earnout period which ended on  March 31, 2022. The contingent consideration is expected to be paid during Q3 2022. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-22-019367:notes:25]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021, and it was updated in the fourth quarter of 2021 as well as in the first and second quarters of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $56,076 of intangible assets, including $21,531 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  June 30, 2022.

[0001437749-22-019367:notes:26]
The allocation of the purchase price to identifiable assets and liabilities is based on the preliminary valuations performed to determine the fair value of the net assets as of the acquisition date. The measurement period for the valuation of net assets acquired ends as soon as information on the facts and circumstances that existed as of the acquisition date becomes available, but not to exceed 12 months following the acquisition date. As the Company finalizes valuations, adjustments in purchase price allocations  may require a change in the amounts allocated to net assets acquired during the periods in which the adjustments are determined.

[0001437749-22-019367:notes:27]
[same as prior period, unchanged from 0001437749-22-011515:notes:24]

[0001437749-22-019367:notes:28]
[same as prior period, unchanged from 0001437749-22-011515:notes:25]

[0001437749-22-019367:notes:29]
| Cash paid at closing |  | $ | 225,458 |  |
| Common stock issued at closing |  |  | 420,774 |  |
| Contingent consideration (1) |  |  | 89,400 |  |
| Total purchase price |  | $ | 735,632 |  |

[0001437749-22-019367:notes:30]
| (1) | To be paid in the form of common stock issued upon achievement of certain performance targets following the end of each of two earnout periods, one ended June 30, 2022, and one ending June 30, 2023. |

[0001437749-22-019367:notes:31]
The Company recorded its preliminary purchase price allocation during the fourth quarter of 2021, which was updated in the first and second quarters of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $798,746 of intangible assets, including $243,346 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of ecobee from the date of acquisition through  June 30, 2022.

[0001437749-22-019367:notes:32]
[same as prior period, unchanged from 0001437749-22-011515:notes:29]

[0001437749-22-019367:notes:33]
[same as prior period, unchanged from 0001437749-22-011515:notes:30]

[0001437749-22-019367:notes:34]
[same as prior period, unchanged from 0001437749-22-011515:notes:31]

[0001437749-22-019367:notes:35]
The combined purchase price for these two acquisitions was $29,945, net of cash acquired, and was funded solely through cash on hand. The Company recorded its preliminary purchase price allocation for Apricity Code and Tank Utility during the third and fourth quarters of 2021, respectively, and then updated in the first and second quarters of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  June 30, 2022.

[0001437749-22-019367:notes:36]
Pro forma financial information is not presented for the above acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-22-019367:notes:37]
[same as prior period, unchanged from 0001437749-22-011515:notes:34]

[0001437749-22-019367:notes:38]
[same as prior period, unchanged from 0001437749-22-011515:notes:35]

[0001437749-22-019367:notes:39]
|  |  | Deep Sea |  |  | ecobee |  |  | All Other |  |  | Total |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,852 |  |  | $ | 46,763 |  |
| Inventories |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |
| Prepaid expenses and other assets |  |  | 1,181 |  |  |  | 5,689 |  |  |  | 6,594 |  |  |  | 13,464 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 3,588 |  |  |  | 480 |  |  |  | 12,906 |  |
| Intangible assets |  |  | 174,270 |  |  |  | 555,400 |  |  |  | 81,171 |  |  |  | 810,841 |  |
| Goodwill |  |  | 263,604 |  |  |  | 243,346 |  |  |  | 80,871 |  |  |  | 587,821 |  |
| Deferred income taxes |  |  | - |  |  |  | 46,721 |  |  |  | 6,547 |  |  |  | 53,268 |  |
| Other assets |  |  | 151 |  |  |  | 11,722 |  |  |  | 8,526 |  |  |  | 20,399 |  |
| Total assets acquired |  |  | 467,588 |  |  |  | 897,061 |  |  |  | 205,075 |  |  |  | 1,569,724 |  |
| Accounts payable |  |  | 8,998 |  |  |  | 25,968 |  |  |  | 7,473 |  |  |  | 42,439 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 872 |  |  |  | 4,332 |  |
| Other accrued liabilities |  |  | 1,737 |  |  |  | 19,898 |  |  |  | 18,258 |  |  |  | 39,893 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |
| Current portion of long-term debt |  |  | - |  |  |  | - |  |  |  | 233 |  |  |  | 233 |  |
| Deferred income taxes |  |  | 33,957 |  |  |  | 80,447 |  |  |  | 19,930 |  |  |  | 134,334 |  |
| Other long-term liabilities |  |  | 90 |  |  |  | 33,762 |  |  |  | 7,862 |  |  |  | 41,714 |  |
| Long-term borrowings and finance lease obligations |  |  | - |  |  |  | - |  |  |  | 1,624 |  |  |  | 1,624 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 735,632 |  |  | $ | 148,023 |  |  | $ | 1,304,355 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-22-019367:notes:40]
[same as prior period, unchanged from 0001437749-22-011515:notes:38]

[0001437749-22-019367:notes:41]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five-year period, and providing that the noncontrolling interest holder no longer held the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next 3 years.

[0001437749-22-019367:notes:42]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand. The Company still holds its call option right to purchase the remaining 34% ownership interest any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances.

[0001437749-22-019367:notes:43]
[same as prior period, unchanged from 0001437749-22-011515:notes:41]

[0001437749-22-019367:notes:44]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 71,511 |  |  | $ | 63,254 |  |  | $ | 58,050 |  |  | $ | 66,207 |  |
| Net income |  |  | 816 |  |  |  | 672 |  |  |  | 3,672 |  |  |  | 1,693 |  |
| Foreign currency translation |  |  | (3,228 | ) |  |  | 2,230 |  |  |  | (4,109 | ) |  |  | (1,621 | ) |
| Purchase of additional ownership interest |  |  | 86 |  |  |  | (27,164 | ) |  |  | (375 | ) |  |  | (27,164 | ) |
| Redemption value adjustment |  |  | 13,645 |  |  |  | (1,747 | ) |  |  | 25,592 |  |  |  | (1,870 | ) |
| Balance at end of period |  | $ | 82,830 |  |  | $ | 37,245 |  |  | $ | 82,830 |  |  | $ | 37,245 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-22-019367:notes:45]
[same as prior period, unchanged from 0001437749-22-011515:notes:43]

[0001437749-22-019367:notes:46]
[same as prior period, unchanged from 0001437749-22-011515:notes:44]

[0001437749-22-019367:notes:47]
[same as prior period, unchanged from 0001437749-22-011515:notes:45]

[0001437749-22-019367:notes:48]
[same as prior period, unchanged from 0001437749-22-011515:notes:46]

[0001437749-22-019367:notes:49]
In 2017, the Company entered into twenty interest rate swap agreements, eight of which were still outstanding as of  June 30, 2022. In  December 2019, in conjunction with an amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to eleven as of  June 30, 2022.

[0001437749-22-019367:notes:50]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 11, “Credit Agreements,” to the condensed consolidated financial statements, the Company amended its interest rate swaps to match that of the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets.

[0001437749-22-019367:notes:51]
The amount of gains, net of tax, recognized for the three and six months ended  June 30, 2022 were $7,129 and $25,857, respectively. The amount of gains and losses, net of tax, recognized for the three and six months ended  June 30, 2021 were $(2,752) and $12,243, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-22-019367:notes:52]
[same as prior period, unchanged from 0001437749-22-011515:notes:48]

[0001437749-22-019367:notes:53]
[same as prior period, unchanged from 0001437749-22-011515:notes:49]

[0001437749-22-019367:notes:54]
|  |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Commodity contracts |  | $ | (157 | ) |  | $ | - |  |
| Foreign currency contracts |  |  | 130 |  |  |  | (36 | ) |
| Interest rate swaps |  |  | 32,517 |  |  |  | (2,074 | ) |

[0001437749-22-019367:notes:55]
The fair value of the commodity contracts is included in other accrued liabilities, and the fair value of the foreign currency contracts and interest rate swaps is included in other assets in the condensed consolidated balance sheets as of  June 30, 2022. The fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  December 31, 2021. Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2022 and  December 31, 2021 is an asset of $33,682 and a liability of $2,148, respectively, which represents the amount the Company would receive or pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-22-019367:notes:56]
[same as prior period, unchanged from 0001437749-22-011515:notes:52]

[0001437749-22-019367:notes:57]
[same as prior period, unchanged from 0001437749-22-011515:notes:53]

[0001437749-22-019367:notes:58]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, revolving facility borrowings, and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $1,268,716, was approximately $1,279,338 (Level 2) at  June 30, 2022, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-22-019367:notes:59]
[same as prior period, unchanged from 0001437749-22-011515:notes:55]

[0001437749-22-019367:notes:60]
[same as prior period, unchanged from 0001437749-22-011515:notes:56]

[0001437749-22-019367:notes:61]
[same as prior period, unchanged from 0001437749-22-011515:notes:57]

[0001437749-22-019367:notes:62]
The  June 30, 2022 fair value is reported as $67,596 in other accrued liabilities and $75,500 in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2021, the Company's contingent consideration balance included $68,665 in other accrued liabilities and $78,094 in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-22-019367:notes:63]
[same as prior period, unchanged from 0001437749-22-011515:notes:59]

[0001437749-22-019367:notes:64]
| Beginning balance, January 1, 2022 |  | $ | 146,759 |  |
| Changes in fair value |  |  | (2,641 | ) |
| Present value interest accretion |  |  | 1,383 |  |
| Currency translation |  |  | (2,405 | ) |
| Ending balance, June 30, 2022 |  | $ | 143,096 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-22-019367:notes:65]
[same as prior period, unchanged from 0001437749-22-011515:notes:61]

[0001437749-22-019367:notes:66]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended  June 30, 2022 and 2021, net of tax:

[0001437749-22-019367:notes:67]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2022 |  | $ | (63,079 | ) |  |  | $ | 16,677 |  |  |  | $ | (46,402 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (43,566 | ) | (1) |  |  | 7,129 |  | (2) |  |  | (36,437 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (43,566 | ) |  |  |  | 7,129 |  |  |  |  | (36,437 | ) |
| Ending Balance – June 30, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |

[0001437749-22-019367:notes:68]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2021 |  | $ | (23,914 | ) |  | $ | (7,585 | ) |  |  | $ | (31,499 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (3,332 | ) |  |  | (2,752 | ) | (3) |  |  | (6,084 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (3,332 | ) |  |  | (2,752 | ) |  |  |  | (6,084 | ) |
| Ending Balance – June 30, 2021 |  | $ | (27,246 | ) |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |

[0001437749-22-019367:notes:69]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (53,941 | ) | (4) |  |  | 25,857 |  | (5) |  |  | (28,084 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (53,941 | ) |  |  |  | 25,857 |  |  |  |  | (28,084 | ) |
| Ending Balance – June 30, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |

[0001437749-22-019367:notes:70]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (15,572 | ) | (6) |  |  | 12,243 |  | (7) |  |  | (3,329 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (15,572 | ) |  |  |  | 12,243 |  |  |  |  | (3,329 | ) |
| Ending Balance – June 30, 2021 |  | $ | (27,246 | ) |  |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |

[0001437749-22-019367:notes:71]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended June 30, 2022, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $9,537 on the interest rate swaps, net of tax effect of $(2,408) for the three months ended June 30, 2022. |

[0001437749-22-019367:notes:72]
|  | (3) | Represents unrealized losses of $(3,682) on the interest rate swaps, net of tax effect of $930 for the three months ended June 30, 2021. |
|  | (4) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the six months ended June 30, 2022, particularly the Euro and British Pound. |
|  | (5) | Represents unrealized gains of $34,591 on the interest rate swaps, net of tax effect of $(8,734) for the six months ended June 30, 2022. |
|  | (6) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the six months ended June 30, 2021 particularly the Euro and British Pound. |
|  | (7) | Represents unrealized gains of $16,379 on the interest rate swaps, net of tax effect of $(4,136) for the six months ended June 30, 2021. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-019367:notes:73]
[same as prior period, unchanged from 0001437749-22-011515:notes:67]

[0001437749-22-019367:notes:74]
[same as prior period, unchanged from 0001437749-22-011515:notes:68]

[0001437749-22-019367:notes:75]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, grid service devices & solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products and services by reportable segment is as follows:

[0001437749-22-019367:notes:76]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

[0001437749-22-019367:notes:77]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

[0001437749-22-019367:notes:78]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |

[0001437749-22-019367:notes:79]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |

[0001437749-22-019367:notes:80]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-22-019367:notes:81]
C&I products consist of larger output stationary generators used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage systems, mobile heaters, mobile pumps, and related controllers. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-22-019367:notes:82]
[same as prior period, unchanged from 0001437749-22-011515:notes:74]

[0001437749-22-019367:notes:83]
The following table sets forth total sales by reportable segment and inclusive of intersegment sales:

[0001437749-22-019367:notes:84]
|  |  | Three Months Ended June 30, 2022 |  |  | Three Months Ended June 30, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | - |  |  | $ | 1,291,391 |  |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | - |  |  | $ | 919,981 |  |
| Intersegment sales |  |  | 18,987 |  |  |  | 19,334 |  |  |  | (38,321 | ) |  |  | - |  |  |  | 8,798 |  |  |  | 6,549 |  |  |  | (15,347 | ) |  |  | - |  |
| Total sales |  | $ | 1,126,418 |  |  | $ | 203,294 |  |  | $ | (38,321 | ) |  | $ | 1,291,391 |  |  | $ | 792,944 |  |  | $ | 142,384 |  |  | $ | (15,347 | ) |  | $ | 919,981 |  |

[0001437749-22-019367:notes:85]
|  |  | Six Months Ended June 30, 2022 |  |  | Six Months Ended June 30, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | - |  |  | $ | 2,427,247 |  |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | - |  |  | $ | 1,727,415 |  |
| Intersegment sales |  |  | 29,257 |  |  |  | 33,659 |  |  |  | (62,916 | ) |  |  | - |  |  |  | 15,479 |  |  |  | 8,552 |  |  |  | (24,031 | ) |  |  | - |  |
| Total sales |  | $ | 2,101,362 |  |  | $ | 388,801 |  |  | $ | (62,916 | ) |  | $ | 2,427,247 |  |  | $ | 1,492,363 |  |  | $ | 259,083 |  |  | $ | (24,031 | ) |  | $ | 1,727,415 |  |

[0001437749-22-019367:notes:86]
[same as prior period, unchanged from 0001437749-22-011515:notes:75]

[0001437749-22-019367:notes:87]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 241,928 |  |  | $ | 203,931 |  |  | $ | 412,349 |  |  | $ | 411,004 |  |
| International |  |  | 29,534 |  |  |  | 13,748 |  |  |  | 55,526 |  |  |  | 20,869 |  |
| Total adjusted EBITDA |  | $ | 271,462 |  |  | $ | 217,679 |  |  | $ | 467,875 |  |  | $ | 431,873 |  |
| Interest expense |  |  | (10,235 | ) |  |  | (7,721 | ) |  |  | (19,789 | ) |  |  | (15,444 | ) |
| Depreciation and amortization |  |  | (39,098 | ) |  |  | (21,229 | ) |  |  | (77,559 | ) |  |  | (39,466 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (4,607 | ) |  |  | (1,173 | ) |  |  | 3,185 |  |  |  | 2,695 |  |
| Non-cash share-based compensation expense (2) |  |  | (7,735 | ) |  |  | (6,973 | ) |  |  | (16,562 | ) |  |  | (12,421 | ) |
| Loss on extinguishment of debt (3) |  |  | (3,743 | ) |  |  | (831 | ) |  |  | (3,743 | ) |  |  | (831 | ) |
| Transaction costs and credit facility fees (4) |  |  | (1,592 | ) |  |  | (5,172 | ) |  |  | (2,581 | ) |  |  | (6,086 | ) |
| Business optimization and other charges (5) |  |  | (1,590 | ) |  |  | - |  |  |  | (2,749 | ) |  |  | (159 | ) |
| Other |  |  | 601 |  |  |  | (309 | ) |  |  | 890 |  |  |  | (577 | ) |
| Income before provision for income taxes |  | $ | 203,463 |  |  | $ | 174,271 |  |  | $ | 348,967 |  |  | $ | 359,584 |  |

[0001437749-22-019367:notes:88]
[same as prior period, unchanged from 0001437749-22-011515:notes:77]

[0001437749-22-019367:notes:89]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-22-019367:notes:90]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due primarily to a voluntary prepayment of Term Loan debt. |

[0001437749-22-019367:notes:91]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance, or refinancing, together with certain fees relating to our senior secured credit facilities. |
|  | (5) | The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities. |

[0001437749-22-019367:notes:92]
The Company’s sales in the U.S. represented approximately 82% of total sales for the three months ended  June 30, 2022 and 2021. The Company’s sales in the U.S. represented approximately 82% and 83% of total sales for the six months ended  June 30, 2022 and 2021, respectively. Approximately 77% and 75% of the Company’s identifiable long-lived assets were located in the U.S. at  June 30, 2022 and  December 31, 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-22-019367:notes:93]
[same as prior period, unchanged from 0001437749-22-011515:notes:82]

[0001437749-22-019367:notes:94]
[same as prior period, unchanged from 0001437749-22-011515:notes:83]

[0001437749-22-019367:notes:95]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Raw material |  | $ | 766,235 |  |  | $ | 727,162 |  |
| Work-in-process |  |  | 14,034 |  |  |  | 10,756 |  |
| Finished goods |  |  | 460,255 |  |  |  | 351,787 |  |
| Total |  | $ | 1,240,524 |  |  | $ | 1,089,705 |  |

[0001437749-22-019367:notes:96]
[same as prior period, unchanged from 0001437749-22-011515:notes:85]

[0001437749-22-019367:notes:97]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Land and improvements |  | $ | 26,147 |  |  | $ | 26,137 |  |
| Buildings and improvements |  |  | 235,438 |  |  |  | 244,273 |  |
| Machinery and equipment |  |  | 208,004 |  |  |  | 186,611 |  |
| Dies and tools |  |  | 33,880 |  |  |  | 31,581 |  |
| Vehicles |  |  | 8,572 |  |  |  | 7,621 |  |
| Office equipment and systems |  |  | 141,736 |  |  |  | 125,048 |  |
| Leasehold improvements |  |  | 6,264 |  |  |  | 5,679 |  |
| Construction in progress |  |  | 42,350 |  |  |  | 47,601 |  |
| Gross property and equipment |  |  | 702,391 |  |  |  | 674,551 |  |
| Accumulated depreciation |  |  | (256,384 | ) |  |  | (233,699 | ) |
| Total |  | $ | 446,007 |  |  | $ | 440,852 |  |

[0001437749-22-019367:notes:98]
Total property and equipment included finance leases of $26,383 and $36,776 on  June 30, 2022 and  December 31, 2021, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-22-019367:notes:99]
[same as prior period, unchanged from 0001437749-22-011515:notes:88]

[0001437749-22-019367:notes:100]
[same as prior period, unchanged from 0001437749-22-011515:notes:89]

[0001437749-22-019367:notes:101]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 101,491 |  |  | $ | 65,297 |  |  | $ | 94,213 |  |  | $ | 59,218 |  |
| Payments |  |  | (18,434 | ) |  |  | (9,282 | ) |  |  | (31,458 | ) |  |  | (19,061 | ) |
| Provision for warranty issued |  |  | 21,668 |  |  |  | 17,164 |  |  |  | 43,093 |  |  |  | 31,994 |  |
| Changes in estimates for pre-existing warranties |  |  | 5,613 |  |  |  | 1,579 |  |  |  | 4,490 |  |  |  | 2,607 |  |
| Balance at end of period |  | $ | 110,338 |  |  | $ | 74,758 |  |  | $ | 110,338 |  |  | $ | 74,758 |  |

[0001437749-22-019367:notes:102]
[same as prior period, unchanged from 0001437749-22-011515:notes:91]

[0001437749-22-019367:notes:103]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 115,923 |  |  | $ | 93,182 |  |  | $ | 111,647 |  |  | $ | 89,788 |  |
| Deferred revenue contracts issued |  |  | 11,332 |  |  |  | 12,168 |  |  |  | 20,878 |  |  |  | 20,199 |  |
| Amortization of deferred revenue contracts |  |  | (5,357 | ) |  |  | (4,866 | ) |  |  | (10,627 | ) |  |  | (9,503 | ) |
| Balance at end of period |  | $ | 121,898 |  |  | $ | 100,484 |  |  | $ | 121,898 |  |  | $ | 100,484 |  |

[0001437749-22-019367:notes:104]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  June 30, 2022 is as follows:

[0001437749-22-019367:notes:105]
| Remainder of 2022 |  | $ | 10,929 |  |
| 2023 |  |  | 23,300 |  |
| 2024 |  |  | 22,741 |  |
| 2025 |  |  | 19,314 |  |
| 2026 |  |  | 15,263 |  |
| After 2026 |  |  | 30,351 |  |
| Total |  | $ | 121,898 |  |

[0001437749-22-019367:notes:106]
[same as prior period, unchanged from 0001437749-22-011515:notes:95]

[0001437749-22-019367:notes:107]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 68,405 |  |  | $ | 59,052 |  |
| Long-term portion - other long-term liabilities |  |  | 41,933 |  |  |  | 35,161 |  |
| Total |  | $ | 110,338 |  |  | $ | 94,213 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 22,503 |  |  | $ | 20,556 |  |
| Long-term portion - other long-term liabilities |  |  | 99,395 |  |  |  | 91,091 |  |
| Total |  | $ | 121,898 |  |  | $ | 111,647 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-22-019367:notes:108]
[same as prior period, unchanged from 0001437749-22-011515:notes:97]

[0001437749-22-019367:notes:109]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $28,933 and $27,388 on  June 30, 2022 and  December 31, 2021, respectively. During the six months ended  June 30, 2022, the Company recognized revenue of $21,470 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-019367:notes:110]
11.   Credit Agreements

[0001437749-22-019367:notes:111]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-019367:notes:112]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 77,514 |  |  |  | 72,035 |  |
| Total |  | $ | 77,514 |  |  | $ | 72,035 |  |

[0001437749-22-019367:notes:113]
As of  June 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-22-019367:notes:114]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-019367:notes:115]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,515 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,600 |  |  |  | 39,175 |  |
| Other |  |  | 1,088 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,173 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,866 |  |  |  | 4,208 |  |
| Total |  | $ | 1,286,499 |  |  | $ | 902,091 |  |

[0001437749-22-019367:notes:116]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is currently  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.

[0001437749-22-019367:notes:117]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date.

[0001437749-22-019367:notes:118]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2022, the Company’s net secured leverage ratio was 1.09 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-22-019367:notes:119]
The Company’s credit agreements also provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-22-019367:notes:120]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

[0001437749-22-019367:notes:121]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of the prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-22-019367:notes:122]
In  June 2022, the Company amended and restated its existing credit agreements by entering into a new credit agreement (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayment, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-22-019367:notes:123]
The Tranche A Term Loan Facility is repayable in quarterly installments of 0.0% of the original principal amount for each of the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, 2.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, 5.0% of the original principal amount for each of the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, 7.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and 10% of the original principal amount for each of the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.

[0001437749-22-019367:notes:124]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based upon adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-22-019367:notes:125]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2022, the Company’s total leverage ratio was 1.18 to 1.00 times, and the Company's interest coverage ratio was 25.56 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2022.

[0001437749-22-019367:notes:126]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-22-019367:notes:127]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender by lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-22-019367:notes:128]
As of  June 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,249,480 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-22-019367:notes:129]
[same as prior period, unchanged from 0001437749-22-011515:notes:109]

[0001437749-22-019367:notes:130]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three and six months ended  June 30, 2022 and 2021. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 9,026,706 shares of its common stock for $431,539 (at an average cost per share of $47.81), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-019367:notes:131]
[same as prior period, unchanged from 0001437749-22-011515:notes:111]

[0001437749-22-019367:notes:132]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options as well as the satisfaction of certain contingent consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest,” to the condensed consolidated financial statements, for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-22-019367:notes:133]
[same as prior period, unchanged from 0001437749-22-011515:notes:113]

[0001437749-22-019367:notes:134]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (13,645 | ) |  |  | 1,747 |  |  |  | (25,592 | ) |  |  | 1,870 |  |
| Net income attributable to common shareholders |  | $ | 142,714 |  |  | $ | 128,783 |  |  | $ | 244,625 |  |  | $ | 277,899 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 63,662,510 |  |  |  | 62,605,166 |  |  |  | 63,607,711 |  |  |  | 62,533,725 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,040,295 |  |  |  | 1,483,543 |  |  |  | 1,180,348 |  |  |  | 1,563,653 |  |
| Dilutive effect of contingently issued shares |  |  | 10,943 |  |  |  | - |  |  |  | 10,943 |  |  |  | - |  |
| Diluted shares |  |  | 64,713,748 |  |  |  | 64,088,709 |  |  |  | 64,799,002 |  |  |  | 64,097,378 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.24 |  |  | $ | 2.06 |  |  | $ | 3.85 |  |  | $ | 4.44 |  |
| Diluted |  | $ | 2.21 |  |  | $ | 2.01 |  |  | $ | 3.78 |  |  | $ | 4.34 |  |

[0001437749-22-019367:notes:135]
(1) Excludes approximately 79,000 and 33,000 stock options and restricted stock awards for the three and six months ended  June 30, 2022, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three and six months ended  June 30, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-019367:notes:136]
[same as prior period, unchanged from 0001437749-22-011515:notes:116]

[0001437749-22-019367:notes:137]
The effective income tax rates for the six months ended  June 30, 2022 and 2021 were 21.3% and 22.7%, respectively. The decrease in the effective tax rate was primarily due to a discrete tax item in the prior year second quarter resulting from a legislative tax rate change in a foreign jurisdiction that revalued deferred tax liabilities increasing the effective income tax rate for the six months ended  June 30, 2021 by approximately 1.9%. This adjustment from the prior year was partially offset in the current year by the mix of earnings in the jurisdictions where the Company operates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-019367:notes:138]
15. Commitments and Contingencies

[0001437749-22-019367:notes:139]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2022 and  December 31, 2021 was approximately $238,643 and $115,900, respectively.

[0001437749-22-019367:notes:140]
From time to time, the Company is involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      June 
     30,
     2022, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-019367:notes:141]
16. Subsequent Events

[0001437749-22-019367:notes:142]
Subsequent to  June 30, 2022, the Company repurchased 536,633 shares of its common stock for $123,900, all funded with cash on hand. Additionally, on  July 29, 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period.
