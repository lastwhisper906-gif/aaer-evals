# GNRC MD&A — 0001437749-22-019367


## mdna

[0001437749-22-019367:mdna:1]
[same as prior period, unchanged from 0001437749-22-011515:mdna:1]

[0001437749-22-019367:mdna:2]
[same as prior period, unchanged from 0001437749-22-011515:mdna:2]

[0001437749-22-019367:mdna:3]
[same as prior period, unchanged from 0001437749-22-011515:mdna:3]

[0001437749-22-019367:mdna:4]
[same as prior period, unchanged from 0001437749-22-011515:mdna:4]

[0001437749-22-019367:mdna:5]
[same as prior period, unchanged from 0001437749-22-011515:mdna:5]

[0001437749-22-019367:mdna:6]
[same as prior period, unchanged from 0001437749-22-011515:mdna:6]

[0001437749-22-019367:mdna:7]
[same as prior period, unchanged from 0001437749-22-011515:mdna:7]

[0001437749-22-019367:mdna:8]
[same as prior period, unchanged from 0001437749-22-011515:mdna:8]

[0001437749-22-019367:mdna:9]
[same as prior period, unchanged from 0001437749-22-011515:mdna:9]

[0001437749-22-019367:mdna:10]
[same as prior period, unchanged from 0001437749-22-011515:mdna:10]

[0001437749-22-019367:mdna:11]
[same as prior period, unchanged from 0001437749-22-011515:mdna:11]

[0001437749-22-019367:mdna:12]
[same as prior period, unchanged from 0001437749-22-011515:mdna:12]

[0001437749-22-019367:mdna:13]
[same as prior period, unchanged from 0001437749-22-011515:mdna:13]

[0001437749-22-019367:mdna:14]
[same as prior period, unchanged from 0001437749-22-011515:mdna:14]

[0001437749-22-019367:mdna:15]
[same as prior period, unchanged from 0001437749-22-011515:mdna:15]

[0001437749-22-019367:mdna:16]
[same as prior period, unchanged from 0001437749-22-011515:mdna:16]

[0001437749-22-019367:mdna:17]
[same as prior period, unchanged from 0001437749-22-011515:mdna:17]

[0001437749-22-019367:mdna:18]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; and |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations. |

[0001437749-22-019367:mdna:19]
[same as prior period, unchanged from 0001437749-22-011515:mdna:19]

[0001437749-22-019367:mdna:20]
[same as prior period, unchanged from 0001437749-22-011515:mdna:20]

[0001437749-22-019367:mdna:21]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, energy management devices and controls, advanced power grid software platforms and services, and engine- and battery-powered tools and equipment.  We are committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid. As an energy technology company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-22-019367:mdna:22]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential and C&I standby generators; as well as portable and mobile generators used in a variety of applications.  In recent years, the Company has been evolving its business model to focus on building out a residential and C&I ecosystem of energy technology products, solutions, and services.  As part of this evolution, we have made significant investments into rapidly growing new markets such as residential clean energy storage, solar microinverters, and energy monitoring and management devices, all of which are distributed energy resources (DERs) that can be aggregated into virtual power plants (VPPs) within grid services programs. In addition, a key strategic focus has been leveraging our leading position in the growing market for cleaner burning natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I applications.

[0001437749-22-019367:mdna:23]
[same as prior period, unchanged from 0001437749-22-011515:mdna:23]

[0001437749-22-019367:mdna:24]
[same as prior period, unchanged from 0001437749-22-011515:mdna:24]

[0001437749-22-019367:mdna:25]
[same as prior period, unchanged from 0001437749-22-011515:mdna:25]

[0001437749-22-019367:mdna:26]
[same as prior period, unchanged from 0001437749-22-011515:mdna:26]

[0001437749-22-019367:mdna:27]
[same as prior period, unchanged from 0001437749-22-011515:mdna:27]

[0001437749-22-019367:mdna:28]
[same as prior period, unchanged from 0001437749-22-011515:mdna:28]

[0001437749-22-019367:mdna:29]
|  | ● | Attitudes around global warming and climate change are shifting: which includes the expectation of more volatile and severe weather driving increased power outage activity. |
|  | ● | Natural gas is expected to be an important fuel of the future: as natural gas will remain in demand as a source of reliable power generation for backup power and beyond standby applications. |
|  | ● | Legacy infrastructure needs a major investment cycle: to rebuild and upgrade aging networks and systems including transportation, water and power. |
|  | ● | Telecommunications infrastructure shifting to next generation: which involves the “5G” architecture that will enable new technologies requiring significant improvement in network uptime through backup power solutions. |
|  | ● | Home as a Sanctuary: in recent years, there has been a trend of more people working, shopping, entertaining, aging in place, and generally spending more time at home. As a result of this and the electrification of everything trend, homeowners are becoming increasingly sensitive to power outages due to lost productivity and functionality. These trends combined with ongoing elevated power outage activity has led to significantly increased awareness regarding the importance and need for backup power security. |

[0001437749-22-019367:mdna:30]
[same as prior period, unchanged from 0001437749-22-011515:mdna:30]

[0001437749-22-019367:mdna:31]
Power quality issues continue to increase.  Power disruptions are an important driver of consumer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event for standby generators. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for back up power. Baseline outage activity in each of the past five years has been above the long-term average as climate change has driven an increase in severe weather activity, while an aging and underinvested electrical grid infrastructure remains highly vulnerable to such activity. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply, further impairing the reliable supply of electricity at a time when demand is starting to increase meaningfully with the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. Further, in California, Public Safety Power Shutoff events have taken place whereby public utilities have turned off power supply to their customers under certain circumstances to prevent their transmission equipment from starting wildfires, which we anticipate may continue in the future. Taken together, we expect these factors to continue driving increased awareness of the need for backup power and demand for Generac’s products within multiple categories.

[0001437749-22-019367:mdna:32]
[same as prior period, unchanged from 0001437749-22-011515:mdna:32]

[0001437749-22-019367:mdna:33]
Solar, storage, monitoring and management markets developing quickly.  During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the introduction of PWRcell™ and PWRview™. In 2021, we expanded our capabilities in the residential solar market with the introduction of the PWRmicro, a grid-interactive microinverter which is expected to be available in 2022.  In addition, in 2021, we acquired ecobee, a leader in sustainable home technology solutions. We believe ecobee’s technologies combined with Generac’s product offering will allow us to create a clean, efficient, and reliable home energy ecosystem and platform that will save homeowners money and help grid operators meet the challenges of an electrical grid under increasing stress by providing solutions to better balance supply and demand. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from renewable sources such as solar and wind, and cleaner-burning natural gas generators is projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. We expect to further advance our growing capabilities in clean energy by increasing our product development, sourcing, distribution, and marketing efforts, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential solar, storage, monitoring and management markets.

[0001437749-22-019367:mdna:34]
Grid services and Energy-as-a-Service open new revenue streams.  We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will continue to drive the need for grid operators to access and control distributed energy resources (DERs). This will require highly intelligent software platforms that are able to optimize an increasingly complex supply and demand equation, such as our Concerto™ software platform. As the grid services market matures, Generac will continue to explore new opportunities beyond the traditional software-as-a-service subscription model, including but not limited to the aggregation and sale of power from a fleet of DERs in performance-based contracts, wholesale power market participation, turn-key solutions that combine hardware and software with services, and other monitoring and management services. Additionally, growing interest in our products across a variety of residential and C&I “beyond standby” applications is driving an increase in demand for subscription-like models for end customers, in which Generac will partner with third parties to deliver peace of mind and resiliency solutions while also enabling contributions to grid stability with minimal upfront capital outlays. The significant advancements made in recent years in the connectivity of our products is core to these newer capabilities, which play a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-22-019367:mdna:35]
[same as prior period, unchanged from 0001437749-22-011515:mdna:35]

[0001437749-22-019367:mdna:36]
[same as prior period, unchanged from 0001437749-22-011515:mdna:36]

[0001437749-22-019367:mdna:37]
[same as prior period, unchanged from 0001437749-22-011515:mdna:37]

[0001437749-22-019367:mdna:38]
[same as prior period, unchanged from 0001437749-22-011515:mdna:38]

[0001437749-22-019367:mdna:39]
[same as prior period, unchanged from 0001437749-22-011515:mdna:39]

[0001437749-22-019367:mdna:40]
[same as prior period, unchanged from 0001437749-22-011515:mdna:40]

[0001437749-22-019367:mdna:41]
[same as prior period, unchanged from 0001437749-22-011515:mdna:41]

[0001437749-22-019367:mdna:42]
[same as prior period, unchanged from 0001437749-22-011515:mdna:42]

[0001437749-22-019367:mdna:43]
[same as prior period, unchanged from 0001437749-22-011515:mdna:43]

[0001437749-22-019367:mdna:44]
[same as prior period, unchanged from 0001437749-22-011515:mdna:45]

[0001437749-22-019367:mdna:45]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia.  Our sales to customers in Russia and Ukraine represented less than 1% of our total revenue for the year ended on December 31, 2021, and therefore the impact on our financial results is not expected to be material. However, the situation remains uncertain and it is difficult to predict the impact that the conflict and actions taken in response to the conflict will have on our business; and in particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-22-019367:mdna:46]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, there continues to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs and delays for certain of our products that are reducing our margins.

[0001437749-22-019367:mdna:47]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past year to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in the second quarter with the full realization occurring in the second half of 2022 as the higher pricing continues to work through backlog. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-22-019367:mdna:48]
[same as prior period, unchanged from 0001437749-22-011515:mdna:49]

[0001437749-22-019367:mdna:49]
[same as prior period, unchanged from 0001437749-22-011515:mdna:50]

[0001437749-22-019367:mdna:50]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility and all LIBOR provisions to the existing Tranche B Term Loan Facility were replaced with SOFR provisions. During the six months ended June 30, 2022, interest expense increased compared to the six months ended June 30, 2021, primarily due to increased borrowings and higher interest rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-22-019367:mdna:51]
Factors influencing provision for income taxes and cash income taxes paid.   As of December 31, 2021, the tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006 were fully amortized. This will result in a higher cash income tax obligation in 2022 and on a go-forward basis.

[0001437749-22-019367:mdna:52]
[same as prior period, unchanged from 0001437749-22-011515:mdna:53]

[0001437749-22-019367:mdna:53]
[same as prior period, unchanged from 0001437749-22-011515:mdna:54]

[0001437749-22-019367:mdna:54]
Three months ended June 30, 2022 compared to the three months ended June 30, 2021

[0001437749-22-019367:mdna:55]
[same as prior period, unchanged from 0001437749-22-011515:mdna:56]

[0001437749-22-019367:mdna:56]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | 371,410 |  |  |  | 40.4 | % |
| Costs of goods sold |  |  | 834,406 |  |  |  | 580,246 |  |  |  | 254,160 |  |  |  | 43.8 | % |
| Gross profit |  |  | 456,985 |  |  |  | 339,735 |  |  |  | 117,250 |  |  |  | 34.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 120,066 |  |  |  | 78,777 |  |  |  | 41,289 |  |  |  | 52.4 | % |
| Research and development |  |  | 41,599 |  |  |  | 25,344 |  |  |  | 16,255 |  |  |  | 64.1 | % |
| General and administrative |  |  | 52,600 |  |  |  | 41,610 |  |  |  | 10,990 |  |  |  | 26.4 | % |
| Amortization of intangible assets |  |  | 25,876 |  |  |  | 11,052 |  |  |  | 14,824 |  |  |  | 134.1 | % |
| Total operating expenses |  |  | 240,141 |  |  |  | 156,783 |  |  |  | 83,358 |  |  |  | 53.2 | % |
| Income from operations |  |  | 216,844 |  |  |  | 182,952 |  |  |  | 33,892 |  |  |  | 18.5 | % |
| Total other expense, net |  |  | (13,381 | ) |  |  | (8,681 | ) |  |  | (4,700 | ) |  |  | 54.1 | % |
| Income before provision for income taxes |  |  | 203,463 |  |  |  | 174,271 |  |  |  | 29,192 |  |  |  | 16.8 | % |
| Provision for income taxes |  |  | 45,826 |  |  |  | 46,362 |  |  |  | (536 | ) |  |  | -1.2 | % |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 29,728 |  |  |  | 23.2 | % |
| Net income attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 405 |  |  |  | 46.4 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 29,323 |  |  |  | 23.1 | % |

[0001437749-22-019367:mdna:57]
The following tables set forth our reportable segment information for the periods indicated:

[0001437749-22-019367:mdna:58]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,107,431 |  |  | $ | 784,146 |  |  | $ | 323,285 |  |  |  | 41.2 | % |
| International |  |  | 183,960 |  |  |  | 135,835 |  |  |  | 48,125 |  |  |  | 35.4 | % |
| Total net sales |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | 371,410 |  |  |  | 40.4 | % |

[0001437749-22-019367:mdna:59]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |  | Three Months Ended June 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,107,431 |  |  | $ | 18,987 |  |  | $ | 1,126,418 |  |  | $ | 784,146 |  |  | $ | 8,798 |  |  | $ | 792,944 |  |
| International |  |  | 183,960 |  |  |  | 19,334 |  |  |  | 203,294 |  |  |  | 135,835 |  |  |  | 6,549 |  |  |  | 142,384 |  |
| Intercompany elimination |  |  | - |  |  |  | (38,321 | ) |  |  | (38,321 | ) |  |  |  |  |  |  | (15,347 | ) |  |  | (15,347 | ) |
| Total net sales |  | $ | 1,291,391 |  |  | $ | - |  |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | - |  |  | $ | 919,981 |  |

[0001437749-22-019367:mdna:60]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 241,928 |  |  | $ | 203,931 |  |  | $ | 37,997 |  |  |  | 18.6 | % |
| International |  |  | 29,534 |  |  |  | 13,748 |  |  |  | 15,786 |  |  |  | 114.8 | % |
| Total Adjusted EBITDA |  | $ | 271,462 |  |  | $ | 217,679 |  |  | $ | 53,783 |  |  |  | 24.7 | % |

[0001437749-22-019367:mdna:61]
[same as prior period, unchanged from 0001437749-22-011515:mdna:61]

[0001437749-22-019367:mdna:62]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 896,013 |  |  | $ | 599,991 |  |  | $ | 296,022 |  |  |  | 49.3 | % |
| Commercial & industrial products |  |  | 309,348 |  |  |  | 254,295 |  |  |  | 55,053 |  |  |  | 21.6 | % |
| Other |  |  | 86,030 |  |  |  | 65,695 |  |  |  | 20,335 |  |  |  | 31.0 | % |
| Total net sales |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | 371,410 |  |  |  | 40.4 | % |

[0001437749-22-019367:mdna:63]
Net sales.    Domestic segment total sales (including inter-segment sales) increased 42.1% to $1,126.4 million as compared to $792.9 million in the prior year quarter, with the impact of non-annualized acquisitions contributing $50.0 million of the revenue growth for the quarter. The strong core sales growth was led by home standby generators, while C&I channels also experienced significant year-over-year growth in the quarter, highlighted by national rental equipment and telecom customers and the industrial distributor channel.

[0001437749-22-019367:mdna:64]
International segment total sales (including inter-segment sales) increased 42.8% to $203.3 million as compared to $142.4 million in the prior year quarter, with the net impact of non-annualized acquisitions and foreign currency contributing $13.3 million of the revenue growth for the quarter. The core sales growth for the segment was driven by growth across all major regions as compared to the prior year quarter, most notably in Europe and Latin America.

[0001437749-22-019367:mdna:65]
The net sales contribution from all non-annualized recent acquisitions for the three months ended June 30, 2022 was $73.4 million.

[0001437749-22-019367:mdna:66]
Gross profit.    Gross profit margin for the second quarter of 2022 was 35.4% compared to 36.9% in the prior year second quarter. Gross margins continued to be impacted by higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor.  These costs were mostly offset by the growing realization of previously implemented pricing actions and favorable sales mix. The increasing benefit of pricing actions implemented over the past several quarters and projected easing of input costs are expected to result in gross margins continuing to improve in the second half of the year.

[0001437749-22-019367:mdna:67]
Operating expenses.   Operating expenses increased $83.4 million, or 53.2%, as compared to the prior year second quarter, including a $14.8 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes.

[0001437749-22-019367:mdna:68]
Other expense.    The increase in Other expense, net was driven by an increase in interest expense due to increased borrowings and higher interest rates in the current year quarter, as well as a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to our credit agreement refinancing during the current year quarter.

[0001437749-22-019367:mdna:69]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2022 and 2021 were 22.5% and 26.6%, respectively. The decrease in the effective tax rate was primarily due to a discrete tax item in the prior year quarter resulting from a legislative tax rate change in a foreign jurisdiction that unfavorably revalued deferred tax liabilities by $7.0 million, or approximately 4% tax rate impact to the prior year.

[0001437749-22-019367:mdna:70]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $156.4 million as compared to $127.0 million in the prior year second quarter. This increase was primarily driven by increased operating earnings due to the factors outlined above.

[0001437749-22-019367:mdna:71]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the second quarter of 2022 was $241.9 million, or 21.5% of domestic segment total sales, as compared to $203.9 million, or 25.7% of total sales, in the prior year quarter. This margin performance was primarily impacted by the higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-019367:mdna:72]
Adjusted EBITDA for the International segment in the second quarter of 2022, before deducting for non-controlling interests, was $29.5 million, or 14.5% of international segment total sales, as compared to $13.7 million, or 9.7% of total sales, in the prior year quarter. This strong margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on higher sales volumes.

[0001437749-22-019367:mdna:73]
Adjusted Net Income.    Adjusted Net Income of $193.5 million for the three months ended June 30, 2022 increased 26.3% from $153.2 million for the three months ended June 30, 2021. This increase was primarily driven by increased net income due to the factors outlined above, the add-back of amortization of intangible assets, and an increase in GAAP income tax expense relative to cash income tax expense in the prior year.

[0001437749-22-019367:mdna:74]
[same as prior period, unchanged from 0001437749-22-011515:mdna:74]

[0001437749-22-019367:mdna:75]
Results of Operations

[0001437749-22-019367:mdna:76]
Six months ended June 30, 2022 compared to the six months ended June 30, 2021

[0001437749-22-019367:mdna:77]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-22-019367:mdna:78]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |  | $ | 699,832 |  |  |  | 40.5 | % |
| Costs of goods sold |  |  | 1,609,514 |  |  |  | 1,065,866 |  |  |  | 543,648 |  |  |  | 51.0 | % |
| Gross profit |  |  | 817,733 |  |  |  | 661,549 |  |  |  | 156,184 |  |  |  | 23.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 218,309 |  |  |  | 147,201 |  |  |  | 71,108 |  |  |  | 48.3 | % |
| Research and development |  |  | 81,343 |  |  |  | 47,732 |  |  |  | 33,611 |  |  |  | 70.4 | % |
| General and administrative |  |  | 94,572 |  |  |  | 74,509 |  |  |  | 20,063 |  |  |  | 26.9 | % |
| Amortization of intangible assets |  |  | 51,930 |  |  |  | 20,031 |  |  |  | 31,899 |  |  |  | 159.2 | % |
| Total operating expenses |  |  | 446,154 |  |  |  | 289,473 |  |  |  | 156,681 |  |  |  | 54.1 | % |
| Income from operations |  |  | 371,579 |  |  |  | 372,076 |  |  |  | (497 | ) |  |  | -0.1 | % |
| Total other expense, net |  |  | (22,612 | ) |  |  | (12,492 | ) |  |  | (10,120 | ) |  |  | 81.0 | % |
| Income before provision for income taxes |  |  | 348,967 |  |  |  | 359,584 |  |  |  | (10,617 | ) |  |  | -3.0 | % |
| Provision for income taxes |  |  | 74,434 |  |  |  | 81,730 |  |  |  | (7,296 | ) |  |  | -8.9 | % |
| Net income |  |  | 274,533 |  |  |  | 277,854 |  |  |  | (3,321 | ) |  |  | -1.2 | % |
| Net income attributable to noncontrolling interests |  |  | 4,316 |  |  |  | 1,825 |  |  |  | 2,491 |  |  |  | 136.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 270,217 |  |  | $ | 276,029 |  |  | $ | (5,812 | ) |  |  | -2.1 | % |

[0001437749-22-019367:mdna:79]
The following tables set forth our reportable segment information for the periods indicated:

[0001437749-22-019367:mdna:80]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,072,105 |  |  | $ | 1,476,884 |  |  | $ | 595,221 |  |  |  | 40.3 | % |
| International |  |  | 355,142 |  |  |  | 250,531 |  |  |  | 104,611 |  |  |  | 41.8 | % |
| Total net sales |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |  | $ | 699,832 |  |  |  | 40.5 | % |

[0001437749-22-019367:mdna:81]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |  | Six Months Ended June 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,072,105 |  |  | $ | 29,257 |  |  | $ | 2,101,362 |  |  | $ | 1,476,884 |  |  | $ | 15,479 |  |  | $ | 1,492,363 |  |
| International |  |  | 355,142 |  |  |  | 33,659 |  |  |  | 388,801 |  |  |  | 250,531 |  |  |  | 8,552 |  |  |  | 259,083 |  |
| Intercompany elimination |  |  | - |  |  |  | (62,916 | ) |  |  | (62,916 | ) |  |  | - |  |  |  | (24,031 | ) |  |  | (24,031 | ) |
| Total net sales |  | $ | 2,427,247 |  |  | $ | - |  |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |  | $ | - |  |  | $ | 1,727,415 |  |

[0001437749-22-019367:mdna:82]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 412,349 |  |  | $ | 411,004 |  |  | $ | 1,345 |  |  |  | 0.3 | % |
| International |  |  | 55,526 |  |  |  | 20,869 |  |  |  | 34,657 |  |  |  | 166.1 | % |
| Total Adjusted EBITDA |  | $ | 467,875 |  |  | $ | 431,873 |  |  | $ | 36,002 |  |  |  | 8.3 | % |

[0001437749-22-019367:mdna:83]
The following table sets forth our product class information for the periods indicated:

[0001437749-22-019367:mdna:84]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,672,957 |  |  | $ | 1,142,140 |  |  | $ | 530,817 |  |  |  | 46.5 | % |
| Commercial & industrial products |  |  | 588,077 |  |  |  | 456,686 |  |  |  | 131,391 |  |  |  | 28.8 | % |
| Other |  |  | 166,213 |  |  |  | 128,589 |  |  |  | 37,624 |  |  |  | 29.3 | % |
| Total net sales |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |  | $ | 699,832 |  |  |  | 40.5 | % |

[0001437749-22-019367:mdna:85]
Net sales.    Domestic segment total sales (including inter-segment sales) increased 40.8% to $2,101.4 million as compared to $1,492.4 million in the prior year, with the impact of non-annualized acquisitions contributing $83.7 million of the revenue growth for the quarter. The strong core sales growth was led by home standby generators and PWRcell™ energy storage systems, while C&I channels also experienced significant year-over-year growth, highlighted by national rental equipment and telecom customers and the industrial distributor channel.

[0001437749-22-019367:mdna:86]
International segment total sales (including inter-segment sales) increased 50.1% to $388.8 million as compared to $259.1 million in the prior year, with the net impact of non-annualized acquisitions and foreign currency contributing $39.0 million of the revenue growth for the quarter. The core sales growth for the segment was driven by growth across all major regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-22-019367:mdna:87]
The net sales contribution from all non-annualized recent acquisitions for the six months ended June 30, 2022 was $138.0 million.

[0001437749-22-019367:mdna:88]
Gross profit.    Gross profit margin for the six months ended June 30, 2022 was 33.7% compared to 38.3% in the prior year. Gross margins were pressured by higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor.  These higher costs were partially offset by the lagging realization of previously implemented pricing actions and favorable sales mix. The full realization of pricing actions implemented over the past several quarters and projected easing of input costs are expected to result in gross margins continuing to improve in the second half of the year.

[0001437749-22-019367:mdna:89]
Operating expenses.   Operating expenses increased $156.7 million, or 54.1%, as compared to the prior year, including a $31.9 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes.

[0001437749-22-019367:mdna:90]
Other expense.    The increase in Other expense, net was driven by an increase in interest expense due to increased borrowings and higher interest rates in the current year quarter, as well as a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to our credit agreement refinancing during the current year quarter.

[0001437749-22-019367:mdna:91]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2022 and 2021 were 21.3% and 22.7%, respectively. The decrease in the effective tax rate was primarily due to a discrete tax item in the prior year second quarter resulting from a legislative tax rate change in a foreign jurisdiction that unfavorably revalued deferred tax liabilities, increasing the effective income tax rate for the six months ended June 30, 2021 by approximately 1.9%. This adjustment from the prior year was partially offset in the current year by the mix of earnings in the jurisdictions where the Company operates.

[0001437749-22-019367:mdna:92]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $270.2 million as compared to $276.0 million in the prior year period. This reduction was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-22-019367:mdna:93]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $412.3 million, or 19.6% of domestic segment total sales, as compared to $411.0 million, or 27.5% of total sales, in the prior year period. This margin performance was primarily impacted by the higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-019367:mdna:94]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $55.5 million, or 14.3% of international segment total sales, as compared to $20.9 million, or 8.1% of total sales, in the prior year period. This strong margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on significantly higher sales volumes.

[0001437749-22-019367:mdna:95]
Adjusted Net Income.    Adjusted Net Income of $328.8 million for the six months ended June 30, 2022 increased 7.5% from $305.9 million for the six months ended June 30, 2021. This increase was primarily driven by the add-back of amortization of intangible assets partially off-set by decreased net income due to the factors outlined above.

[0001437749-22-019367:mdna:96]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-22-019367:mdna:97]
[same as prior period, unchanged from 0001437749-22-011515:mdna:75]

[0001437749-22-019367:mdna:98]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, income taxes, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our new Revolving Facility.

[0001437749-22-019367:mdna:99]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements also provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-22-019367:mdna:100]
In June 2022, we amended and restated the existing credit agreements by entering into a new credit agreement (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1.25 billion (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility, make a $250 million voluntary prepayment on our Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-22-019367:mdna:101]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date.

[0001437749-22-019367:mdna:102]
The Tranche A Term Loan Facility is repayable in quarterly installments of 0.0% of the original principal amount for each of the fiscal quarters ending June 30, 2022 through and including June 30, 2023, 2.5% of the original principal amount for each of the fiscal quarters ending September 30, 2023 through and including June 30, 2024, 5.0% of the original principal amount for each of the fiscal quarters ending September 30, 2024 through and including June 30, 2025, 7.5% of the original principal amount for each of the fiscal quarters ending September 30, 2025 through and including June 30, 2026, and 10% of the original principal amount for each of the fiscal quarters ending September 30, 2026 through and including March 31, 2027, with the remaining principal balance due and payable on the maturity date.

[0001437749-22-019367:mdna:103]
As of June 30, 2022, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and no borrowings outstanding on our Revolving Facility, leaving $1,249.5 million of availability, net of outstanding letters of credit. Our Tranche B Term Loan Facility matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Our Tranche A Term Loan Facility and the Revolving Facility mature on June 29, 2027 and initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility will bear interest at a rate based upon adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-22-019367:mdna:104]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2022, our secured leverage ratio was 1.09 to 1.00 times, and we are in compliance with all covenants of the Tranche B Term Loan Facility. Additionally, the Tranche A Term Loan Facility and Revolving Facility added certain financial covenants that require us to maintain a total leverage below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of June 30, 2022, our total leverage ratio was 1.18 to 1.00 times, and our interest coverage ratio was 25.56 to 1.00. We are also in compliance with all other covenants of the Amended Credit Agreement as of June 30, 2022.

[0001437749-22-019367:mdna:105]
As of June 30, 2022, we had $1,716.6 million of liquidity comprised of $467.1 million of cash and equivalents and $1,249.5 million available under our Revolving Facility. We believe this strong liquidity position will allow us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-22-019367:mdna:106]
In September 2020, our Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allows for the repurchase of up to $250 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the six months ended June 30, 2022 and 2021, no share repurchases were made under this plan. Subsequent to the quarter, we repurchased 536,633 shares of our common stock for $123.9 million, all funded with cash on hand. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 9,563,339 shares of our common stock for $555.4 million (at an average cost per share of $58.08), all funded with cash on hand. Additionally, on July 29, 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period.

[0001437749-22-019367:mdna:107]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-22-019367:mdna:108]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. The amount financed by dealers which remained outstanding was $238.6 million and $115.9 million as of June 30, 2022 and December 31, 2021, respectively.

[0001437749-22-019367:mdna:109]
[same as prior period, unchanged from 0001437749-22-011515:mdna:83]

[0001437749-22-019367:mdna:110]
We believe that our cash flow from operations and availability under our Revolving Facility and other short-term lines of credit, combined with our cash on hand, provide us with sufficient capital to fund our operations into the future. We may use a portion of our cash flow to pay principal on our outstanding debt, fund acquisitions, as well as to repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures, acquisitions, or share repurchases.

[0001437749-22-019367:mdna:111]
[same as prior period, unchanged from 0001437749-22-011515:mdna:85]

[0001437749-22-019367:mdna:112]
Six months ended June 30, 2022 compared to the six months ended June 30, 2021

[0001437749-22-019367:mdna:113]
[same as prior period, unchanged from 0001437749-22-011515:mdna:87]

[0001437749-22-019367:mdna:114]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 13,693 |  |  | $ | 274,993 |  |  | $ | (261,300 | ) |  |  | -95.0 | % |
| Net cash used in investing activities |  |  | (63,119 | ) |  |  | (467,116 | ) |  |  | 403,997 |  |  |  | 86.5 | % |
| Net cash provided by (used in) financing activities |  |  | 366,367 |  |  |  | (72,680 | ) |  |  | 439,047 |  |  |  | 604.1 | % |

[0001437749-22-019367:mdna:115]
The decline in operating cash flow for the six months ended June 30, 2022, was primarily due to significantly higher working capital investment in the current year given our substantial growth coupled with the challenging supply chain environment.

[0001437749-22-019367:mdna:116]
Net cash used in investing activities for the six months ended June 30, 2022 primarily represents cash payments of $46.5 million related to the purchase of property and equipment, $11.4 million related to the acquisition of businesses, and $10.2 million for a contribution to an equity method investment, which were partially offset by cash proceeds from the sale of property and equipment of $1.9 million, cash proceeds from beneficial interests in securitization transactions of $1.8 million, and cash proceeds from the sale of an investment of $1.3 million. Net cash used in investing activities for the six months ended June 30, 2021 primarily represents cash payments of $419.0 million related to the acquisition of businesses and $54.2 million related to the purchase of property and equipment, which were partially offset by cash proceeds from the sale of an investment of $4.9 million.

[0001437749-22-019367:mdna:117]
Net cash provided by financing activities for the six months ended June 30, 2022 primarily represents proceeds of $935.0 million from long-term borrowings, $216.7 million from short-term borrowings, and $10.4 million from the exercise of stock options. These cash proceeds were partially offset by $746.6 million of debt repayments ($208.2 million of short-term borrowings and $538.4 million of long-term borrowings and finance lease obligations), $38.3 million of taxes paid related to equity awards, and $10.3 million for payment of debt issuance costs.

[0001437749-22-019367:mdna:118]
Net cash used in financing activities for the six months ended June 30, 2021 primarily represents $126.8 million of debt repayments ($73.7 million of short-term borrowings and $53.1 million of long-term borrowings and finance lease obligations), $40.0 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of Pramac, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $57.6 million from short-term borrowings, $50.0 million from long-term borrowings, and $18.6 million from the exercise of stock options.

[0001437749-22-019367:mdna:119]
[same as prior period, unchanged from 0001437749-22-011515:mdna:93]

[0001437749-22-019367:mdna:120]
There have been no material changes to our contractual obligations since the February 22, 2022 filing of our Annual Report on Form 10-K for the year ended December 31, 2021, except for the amendment and restatement of our credit agreements as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-22-019367:mdna:121]
[same as prior period, unchanged from 0001437749-22-011515:mdna:95]

[0001437749-22-019367:mdna:122]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2021, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-22-019367:mdna:123]
[same as prior period, unchanged from 0001437749-22-011515:mdna:97]

[0001437749-22-019367:mdna:124]
[same as prior period, unchanged from 0001437749-22-011515:mdna:98]

[0001437749-22-019367:mdna:125]
[same as prior period, unchanged from 0001437749-22-011515:mdna:99]

[0001437749-22-019367:mdna:126]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in the Amended Credit Agreement. To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-22-019367:mdna:127]
[same as prior period, unchanged from 0001437749-22-011515:mdna:101]

[0001437749-22-019367:mdna:128]
[same as prior period, unchanged from 0001437749-22-011515:mdna:102]

[0001437749-22-019367:mdna:129]
[same as prior period, unchanged from 0001437749-22-011515:mdna:103]

[0001437749-22-019367:mdna:130]
[same as prior period, unchanged from 0001437749-22-011515:mdna:104]

[0001437749-22-019367:mdna:131]
[same as prior period, unchanged from 0001437749-22-011515:mdna:105]

[0001437749-22-019367:mdna:132]
[same as prior period, unchanged from 0001437749-22-011515:mdna:106]

[0001437749-22-019367:mdna:133]
We believe Adjusted EBITDA is used by securities analysts, investors, and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. GAAP and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-22-019367:mdna:134]
|  | • | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures, and the methods by which assets were acquired; |

[0001437749-22-019367:mdna:135]
[same as prior period, unchanged from 0001437749-22-011515:mdna:109]

[0001437749-22-019367:mdna:136]
[same as prior period, unchanged from 0001437749-22-011515:mdna:110]

[0001437749-22-019367:mdna:137]
The adjustments included in the reconciliation table listed below are provided for under our Amended Credit Agreement, and are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-22-019367:mdna:138]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs, and other restructuring-related business optimization expenses; |

[0001437749-22-019367:mdna:139]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-22-019367:mdna:140]
[same as prior period, unchanged from 0001437749-22-011515:mdna:114]

[0001437749-22-019367:mdna:141]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-22-019367:mdna:142]
[same as prior period, unchanged from 0001437749-22-011515:mdna:116]

[0001437749-22-019367:mdna:143]
[same as prior period, unchanged from 0001437749-22-011515:mdna:117]

[0001437749-22-019367:mdna:144]
[same as prior period, unchanged from 0001437749-22-011515:mdna:118]

[0001437749-22-019367:mdna:145]
[same as prior period, unchanged from 0001437749-22-011515:mdna:119]

[0001437749-22-019367:mdna:146]
[same as prior period, unchanged from 0001437749-22-011515:mdna:120]

[0001437749-22-019367:mdna:147]
[same as prior period, unchanged from 0001437749-22-011515:mdna:121]

[0001437749-22-019367:mdna:148]
[same as prior period, unchanged from 0001437749-22-011515:mdna:122]

[0001437749-22-019367:mdna:149]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-22-019367:mdna:150]
[same as prior period, unchanged from 0001437749-22-011515:mdna:124]

[0001437749-22-019367:mdna:151]
[same as prior period, unchanged from 0001437749-22-011515:mdna:125]

[0001437749-22-019367:mdna:152]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Net income attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 4,316 |  |  |  | 1,825 |  |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 274,533 |  |  |  | 277,854 |  |
| Interest expense |  |  | 10,235 |  |  |  | 7,721 |  |  |  | 19,789 |  |  |  | 15,444 |  |
| Depreciation and amortization |  |  | 39,098 |  |  |  | 21,229 |  |  |  | 77,559 |  |  |  | 39,466 |  |
| Provision for income taxes |  |  | 45,826 |  |  |  | 46,362 |  |  |  | 74,434 |  |  |  | 81,730 |  |
| Non-cash write-down and other adjustments (a) |  |  | 4,607 |  |  |  | 1,173 |  |  |  | (3,185 | ) |  |  | (2,695 | ) |
| Non-cash share-based compensation expense (b) |  |  | 7,735 |  |  |  | 6,973 |  |  |  | 16,562 |  |  |  | 12,421 |  |
| Loss on extinguishment of debt (c) |  |  | 3,743 |  |  |  | 831 |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (d) |  |  | 1,592 |  |  |  | 5,172 |  |  |  | 2,581 |  |  |  | 6,086 |  |
| Business optimization and other charges (e) |  |  | 1,590 |  |  |  | - |  |  |  | 2,749 |  |  |  | 159 |  |
| Other |  |  | (601 | ) |  |  | 309 |  |  |  | (890 | ) |  |  | 577 |  |
| Adjusted EBITDA |  |  | 271,462 |  |  |  | 217,679 |  |  |  | 467,875 |  |  |  | 431,873 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,742 |  |  |  | 2,015 |  |  |  | 7,167 |  |  |  | 4,207 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 267,720 |  |  | $ | 215,664 |  |  | $ | 460,708 |  |  | $ | 427,666 |  |

[0001437749-22-019367:mdna:153]
[same as prior period, unchanged from 0001437749-22-011515:mdna:127]

[0001437749-22-019367:mdna:154]
[same as prior period, unchanged from 0001437749-22-011515:mdna:128]

[0001437749-22-019367:mdna:155]
[same as prior period, unchanged from 0001437749-22-011515:mdna:129]

[0001437749-22-019367:mdna:156]
[same as prior period, unchanged from 0001437749-22-011515:mdna:130]

[0001437749-22-019367:mdna:157]
(c)  Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayments of debt.

[0001437749-22-019367:mdna:158]
(d)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-22-019367:mdna:159]
(e)  The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-22-019367:mdna:160]
[same as prior period, unchanged from 0001437749-22-011515:mdna:133]

[0001437749-22-019367:mdna:161]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-22-019367:mdna:162]
[same as prior period, unchanged from 0001437749-22-011515:mdna:135]

[0001437749-22-019367:mdna:163]
[same as prior period, unchanged from 0001437749-22-011515:mdna:136]

[0001437749-22-019367:mdna:164]
[same as prior period, unchanged from 0001437749-22-011515:mdna:137]

[0001437749-22-019367:mdna:165]
[same as prior period, unchanged from 0001437749-22-011515:mdna:138]

[0001437749-22-019367:mdna:166]
[same as prior period, unchanged from 0001437749-22-011515:mdna:139]

[0001437749-22-019367:mdna:167]
[same as prior period, unchanged from 0001437749-22-011515:mdna:140]

[0001437749-22-019367:mdna:168]
[same as prior period, unchanged from 0001437749-22-011515:mdna:141]

[0001437749-22-019367:mdna:169]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Net income attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 4,316 |  |  |  | 1,825 |  |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 274,533 |  |  |  | 277,854 |  |
| Provision for income taxes (c) |  |  | - |  |  |  | 46,362 |  |  |  | - |  |  |  | 81,730 |  |
| Amortization of intangible assets |  |  | 25,876 |  |  |  | 11,052 |  |  |  | 51,930 |  |  |  | 20,031 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 650 |  |  |  | 649 |  |  |  | 1,287 |  |  |  | 1,295 |  |
| Loss on extinguishment of debt |  |  | 3,743 |  |  |  | 831 |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 5,710 |  |  |  | 4,954 |  |  |  | (46 | ) |  |  | 5,643 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | - |  |  |  | - |  |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges |  |  | 1,590 |  |  |  | - |  |  |  | 2,749 |  |  |  | 159 |  |
| Cash income tax expense (c) |  |  | - |  |  |  | (37,406 | ) |  |  | - |  |  |  | (75,274 | ) |
| Adjusted net income |  |  | 195,206 |  |  |  | 154,351 |  |  |  | 333,967 |  |  |  | 308,278 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,678 |  |  |  | 1,121 |  |  |  | 5,168 |  |  |  | 2,344 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 193,528 |  |  | $ | 153,230 |  |  | $ | 328,799 |  |  | $ | 305,934 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.99 |  |  | $ | 2.39 |  |  | $ | 5.07 |  |  | $ | 4.77 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,713,748 |  |  |  | 64,088,709 |  |  |  | 64,799,002 |  |  |  | 64,097,378 |  |

[0001437749-22-019367:mdna:170]
[same as prior period, unchanged from 0001437749-22-011515:mdna:143]

[0001437749-22-019367:mdna:171]
[same as prior period, unchanged from 0001437749-22-011515:mdna:144]

[0001437749-22-019367:mdna:172]
(c) Amount for the three and six months ended June 30, 2021 is based on an anticipated cash income tax rate at the time of approximately 21.0% to 21.5% for the full year ended December 31, 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP income tax expense for the three and six months ended June 30, 2021 would result in an adjusted net income per diluted share of $2.25 and $4.67, respectively, on a pro forma basis.

[0001437749-22-019367:mdna:173]
[same as prior period, unchanged from 0001437749-22-011515:mdna:146]

[0001437749-22-019367:mdna:174]
[same as prior period, unchanged from 0001437749-22-011515:mdna:147]
