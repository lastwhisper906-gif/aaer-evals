# GNRC note change history — 0001437749-22-011515 → 0001437749-22-019367


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-08):
[0001437749-22-019367:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2022 and  December 31, 2021 was approximately $238,643 and $115,900, respectively.
  (was, 2022-05-09, similarity 0.9923):
[0001437749-22-011515:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2022 and  December 31, 2021 was approximately $168,400 and $115,900, respectively.

- changed (2022-08-08):
[0001437749-22-019367:note_history:2]
From time to time, the Company is involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      June 
     30,
     2022, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.
  (was, 2022-05-09, similarity 0.9622):
[0001437749-22-011515:note_history:2]
From time to time, we are involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      March 
     31,
     2022, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-08-08):
[0001437749-22-019367:note_history:3]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2022-08-08):
[0001437749-22-019367:note_history:4]
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security, and peace of mind. |
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
  (was, 2022-05-09, similarity 0.9175):
[0001437749-22-011515:note_history:4]
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. |

- changed (2022-08-08):
[0001437749-22-019367:note_history:5]
The condensed consolidated balance sheet as of  June 30, 2022, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2022-05-09, similarity 0.9119):
[0001437749-22-011515:note_history:5]
The condensed consolidated balance sheet as of  March 31, 2022, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2022 and 2021, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2022-08-08):
[0001437749-22-011515:note_history:6]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-08):
[0001437749-22-019367:note_history:7]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 77,514 |  |  |  | 72,035 |  |
| Total |  | $ | 77,514 |  |  | $ | 72,035 |  |
  (was, 2022-05-09, similarity 0.9742):
[0001437749-22-011515:note_history:7]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 84,995 |  |  |  | 72,035 |  |
| Total |  | $ | 84,995 |  |  | $ | 72,035 |  |

- changed (2022-08-08):
[0001437749-22-019367:note_history:8]
As of  June 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.
  (was, 2022-05-09, similarity 0.9682):
[0001437749-22-011515:note_history:8]
As of  March 31, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

- added (2022-08-08):
[0001437749-22-019367:note_history:9]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,515 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,600 |  |  |  | 39,175 |  |
| Other |  |  | 1,088 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,173 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,866 |  |  |  | 4,208 |  |
| Total |  | $ | 1,286,499 |  |  | $ | 902,091 |  |

- added (2022-08-08):
[0001437749-22-019367:note_history:10]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is currently  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.

- added (2022-08-08):
[0001437749-22-019367:note_history:11]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date.

- changed (2022-08-08):
[0001437749-22-019367:note_history:12]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2022, the Company’s net secured leverage ratio was 1.09 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.
  (was, 2022-05-09, similarity 0.8455):
[0001437749-22-011515:note_history:12]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2022, the Company’s net secured leverage ratio was 1.00 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- added (2022-08-08):
[0001437749-22-019367:note_history:13]
The Company’s credit agreements also provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- added (2022-08-08):
[0001437749-22-019367:note_history:14]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

- added (2022-08-08):
[0001437749-22-019367:note_history:15]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of the prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- added (2022-08-08):
[0001437749-22-019367:note_history:16]
In  June 2022, the Company amended and restated its existing credit agreements by entering into a new credit agreement (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayment, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

- added (2022-08-08):
[0001437749-22-019367:note_history:17]
The Tranche A Term Loan Facility is repayable in quarterly installments of 0.0% of the original principal amount for each of the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, 2.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, 5.0% of the original principal amount for each of the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, 7.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and 10% of the original principal amount for each of the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.

- added (2022-08-08):
[0001437749-22-019367:note_history:18]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based upon adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

- added (2022-08-08):
[0001437749-22-019367:note_history:19]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2022, the Company’s total leverage ratio was 1.18 to 1.00 times, and the Company's interest coverage ratio was 25.56 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2022.

- added (2022-08-08):
[0001437749-22-019367:note_history:20]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

- added (2022-08-08):
[0001437749-22-019367:note_history:21]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender by lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2022-08-08):
[0001437749-22-019367:note_history:22]
As of  June 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,249,480 of availability, net of outstanding letters of credit.
  (was, 2022-05-09, similarity 0.9283):
[0001437749-22-011515:note_history:22]
As of  March 31, 2022, there was $210,000 outstanding under the ABL Facility, leaving $289,480 of availability, net of outstanding letters of credit.

- removed (2022-08-08):
[0001437749-22-011515:note_history:23]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (12,577 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | 210,000 |  |  |  | 100,000 |  |
| Finance lease obligation |  |  | 27,941 |  |  |  | 39,175 |  |
| Other |  |  | 1,600 |  |  |  | 2,060 |  |
| Total |  |  | 1,006,964 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 1,292 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,987 |  |  |  | 4,208 |  |
| Total |  | $ | 1,002,685 |  |  | $ | 902,091 |  |

- removed (2022-08-08):
[0001437749-22-011515:note_history:24]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

- removed (2022-08-08):
[0001437749-22-011515:note_history:25]
The Company’s credit agreements also provide for a $500,000 senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. The ABL Facility has been amended a number of times since inception.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-08-08):
[0001437749-22-019367:note_history:26]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,515 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,600 |  |  |  | 39,175 |  |
| Other |  |  | 1,088 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,173 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,866 |  |  |  | 4,208 |  |
| Total |  | $ | 1,286,499 |  |  | $ | 902,091 |  |

- removed (2022-08-08):
[0001437749-22-011515:note_history:27]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (12,577 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | 210,000 |  |  |  | 100,000 |  |
| Finance lease obligation |  |  | 27,941 |  |  |  | 39,175 |  |
| Other |  |  | 1,600 |  |  |  | 2,060 |  |
| Total |  |  | 1,006,964 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 1,292 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,987 |  |  |  | 4,208 |  |
| Total |  | $ | 1,002,685 |  |  | $ | 902,091 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-08):
[0001437749-22-019367:note_history:28]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 77,514 |  |  |  | 72,035 |  |
| Total |  | $ | 77,514 |  |  | $ | 72,035 |  |
  (was, 2022-05-09, similarity 0.9742):
[0001437749-22-011515:note_history:28]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 84,995 |  |  |  | 72,035 |  |
| Total |  | $ | 84,995 |  |  | $ | 72,035 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-08-08):
[0001437749-22-019367:note_history:29]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

- added (2022-08-08):
[0001437749-22-019367:note_history:30]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

- added (2022-08-08):
[0001437749-22-019367:note_history:31]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |

- added (2022-08-08):
[0001437749-22-019367:note_history:32]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |

- removed (2022-08-08):
[0001437749-22-011515:note_history:33]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 750,327 |  |  | $ | 26,617 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 145,737 |  |  |  | 132,991 |  |  |  | 278,728 |  |
| Other |  |  | 68,610 |  |  |  | 11,574 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | 1,135,856 |  |

- removed (2022-08-08):
[0001437749-22-011515:note_history:34]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 522,215 |  |  | $ | 19,934 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 117,879 |  |  |  | 84,512 |  |  |  | 202,391 |  |
| Other |  |  | 52,644 |  |  |  | 10,250 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 692,738 |  |  | $ | 114,696 |  |  | $ | 807,434 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-08):
[0001437749-22-019367:note_history:35]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $28,933 and $27,388 on  June 30, 2022 and  December 31, 2021, respectively. During the six months ended  June 30, 2022, the Company recognized revenue of $21,470 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2022-05-09, similarity 0.953):
[0001437749-22-011515:note_history:35]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $30,347 and $27,388 on  March 31, 2022 and  December 31, 2021, respectively. During the three months ended  March 31, 2022, the Company recognized revenue of $11,047 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-08-08):
[0001437749-22-019367:note_history:36]
Subsequent to  June 30, 2022, the Company repurchased 536,633 shares of its common stock for $123,900, all funded with cash on hand. Additionally, on  July 29, 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period.

- removed (2022-08-08):
[0001437749-22-011515:note_history:37]
The Company performed an evaluation of subsequent events through the date these financial statements were issued, and no such events were identified.
