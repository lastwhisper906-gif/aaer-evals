# GNRC 8-K — 0001437749-22-018543 filed 2022-08-03

## item codes, every 8-K on or before 2022-08-08

- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2022-08-08

- none on or before 2022-08-08

## item 2.02 — earnings release, exhibit 99.1

[0001437749-22-018543:8k_2_02:1]
EX-99.1
2
ex_405036.htm
EXHIBIT 99.1

[0001437749-22-018543:8k_2_02:2]
ex_405036.htm

[0001437749-22-018543:8k_2_02:3]
Exhibit 99.1

[0001437749-22-018543:8k_2_02:4]
Generac Reports Record Second Quarter 2022 Results

[0001437749-22-018543:8k_2_02:5]
Increased capacity, strong execution and improving margins drive record results; maintaining 2022 outlook which anticipates continued strong sales growth and sequentially improving margin profile

[0001437749-22-018543:8k_2_02:6]
WAUKESHA, WISCONSIN (August 3, 2022) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its second quarter ended June 30, 2022 and provided an update on its outlook for the full year 2022.

[0001437749-22-018543:8k_2_02:7]
Second Quarter 2022 Highlights

[0001437749-22-018543:8k_2_02:8]
| ● | Net sales increased 40% to a record $1.29 billion during the second quarter of 2022 as compared to $920 million in the prior-year second quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 33%. |

[0001437749-22-018543:8k_2_02:9]
|  | - | Residential product sales grew 49% to $896 million as compared to $600 million last year. |

[0001437749-22-018543:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 22% to $309 million as compared to $254 million in the prior year. |

[0001437749-22-018543:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter was $156 million, or $2.21 per share, as compared to $127 million, or $2.01 per share, for the same period of 2021. |

[0001437749-22-018543:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was a record $194 million, or $2.99 per share, as compared to $153 million, or $2.39 per share, in the second quarter of 2021. |

[0001437749-22-018543:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was a record $271 million, or 21.0% of net sales, as compared to $218 million, or 23.7% of net sales, in the prior year. |

[0001437749-22-018543:8k_2_02:14]
| ● | The Company is maintaining its full-year 2022 net sales growth guidance of approximately 36 to 40% compared to the prior year on an as-reported basis. Adjusted EBITDA margin, before deducting for non-controlling interests, is still expected to be approximately 21.5 to 22.5%. |

[0001437749-22-018543:8k_2_02:15]
| ● | On June 29th, the Company amended its existing term loan credit agreement. This included establishing a new term loan facility in an aggregate principal amount of $750 million and establishing a new revolving facility in an aggregate principal amount of $1.25 billion, which was unfunded at closing. Proceeds were used to prepay $250 million of the existing term loan B facility and to fully pay off the existing ABL revolving credit facility, with the remaining funds to be used for general corporate purposes. |

[0001437749-22-018543:8k_2_02:16]
| ● | Subsequent to quarter end, the Company repurchased approximately $124.0 million of its common stock, which was the amount remaining under its share repurchase authorization at the time. Additionally, on July 29, 2022, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period. |

[0001437749-22-018543:8k_2_02:17]
“We continued to experience robust growth during the second quarter as ongoing capacity expansion helped drive shipments to new records,” said Aaron Jagdfeld, President and Chief Executive Officer. “In addition to the tremendous year-over-year increase in sales, we experienced significant sequential margin improvement in the quarter, which reinforces our prior expectations that margins bottomed in the first quarter and will continue to improve throughout 2022. Given the positive underlying demand trends and elevated backlog, we are maintaining our sales growth and adjusted EBITDA margin guidance for the full-year 2022. The mega-trends supporting this demand remain as compelling as ever, and we believe our unique suite of energy technology solutions has Generac well-positioned to lead the evolution to a more resilient, efficient and sustainable energy future.”

[0001437749-22-018543:8k_2_02:18]
Additional Second Quarter 2022 Consolidated Highlights

[0001437749-22-018543:8k_2_02:19]
Gross profit margin was 35.4% as compared to 36.9% in the prior-year second quarter. While headwinds eased relative to previous quarters, gross margins continued to be impacted by higher input costs including increased commodity prices, logistics costs, and labor. These costs were mostly offset by the growing realization of previously implemented pricing actions and favorable sales mix. The increasing benefit of pricing actions implemented over the past several quarters and projected easing of input costs are expected to result in gross margins continuing to improve in the second half of the year.

[0001437749-22-018543:8k_2_02:20]
Operating expenses increased $83.4 million, or 53.2%, as compared to the second quarter of 2021, including a $14.8 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes.

[0001437749-22-018543:8k_2_02:21]
Provision for income taxes for the current year quarter was $45.8 million, or an effective tax rate of 22.5%, as compared to $46.4 million, or a 26.6% effective tax rate, for the prior year. The decrease in effective tax rate was primarily due to a discrete tax item in the prior year quarter resulting from a legislative tax rate change in a foreign jurisdiction that unfavorably revalued deferred tax liabilities by $7.0 million, or approximately 4% tax rate impact to the prior year quarter.

[0001437749-22-018543:8k_2_02:22]
Cash flow from operations was $23.8 million during the second quarter, as compared to $122.5 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $5.8 million as compared to $96.3 million in the second quarter of 2021. The decline in free cash flow was due to significantly higher working capital investment in the current year quarter, partially offset by higher operating earnings.

[0001437749-22-018543:8k_2_02:23]
Business Segment Results

[0001437749-22-018543:8k_2_02:24]
Domestic Segment

[0001437749-22-018543:8k_2_02:25]
Domestic segment total sales (including inter-segment sales) increased 42% to $1.13 billion as compared to $792.9 million in the prior year quarter, with the impact of acquisitions contributing approximately 6% of the revenue growth for the quarter. The strong core sales growth was led by home standby generators, while C&I channels also experienced significant year-over-year growth in the quarter, highlighted by national rental equipment and telecom customers and the industrial distributor channel.

[0001437749-22-018543:8k_2_02:26]
Adjusted EBITDA for the segment was $241.9 million, or 21.5% of domestic segment total sales, as compared to $203.9 million in the prior year, or 25.7% of total sales. This margin performance was primarily impacted by higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-018543:8k_2_02:27]
International Segment

[0001437749-22-018543:8k_2_02:28]
International segment total sales (including inter-segment sales) increased 43% to $203.3 million as compared to $142.4 million in the prior year quarter, with the net impact of acquisitions and foreign currency contributing approximately 9% of the revenue growth for the quarter. The core sales growth for the segment was driven by growth across all major regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-22-018543:8k_2_02:29]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $29.5 million, or 14.5% of international segment total sales, as compared to $13.7 million, or 9.7% of total sales, in the prior year. This strong margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on higher volumes.

[0001437749-22-018543:8k_2_02:30]
2022 Outlook Update

[0001437749-22-018543:8k_2_02:31]
The Company is maintaining its full-year 2022 net sales growth guidance range of approximately 36 to 40% compared to the prior year, which includes approximately 5 to 7% net impact from acquisitions and foreign currency.

[0001437749-22-018543:8k_2_02:32]
Additionally, the Company still expects net income margin, before deducting for non-controlling interests, to be approximately 13.0 to 14.0% for the full-year 2022. The corresponding adjusted EBITDA margin is still expected to be approximately 21.5 to 22.5%.

[0001437749-22-018543:8k_2_02:33]
Conference Call and Webcast

[0001437749-22-018543:8k_2_02:34]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, August 3, 2022 to discuss second quarter 2022 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIa03208708aae4babae97d724881c5969. Individuals that wish to listen via telephone will be given dial-in information.

[0001437749-22-018543:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-22-018543:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's website.

[0001437749-22-018543:8k_2_02:37]
About Generac

[0001437749-22-018543:8k_2_02:38]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-22-018543:8k_2_02:39]
Forward-looking Information

[0001437749-22-018543:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-22-018543:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-22-018543:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-22-018543:8k_2_02:43]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-22-018543:8k_2_02:44]
|  | ● | availability of both labor and key components from our global supply chain, including single-sourced components, needed in producing our products; |

[0001437749-22-018543:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-22-018543:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-22-018543:8k_2_02:47]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-22-018543:8k_2_02:48]
|  | ● | the duration and impact of the COVID-19 pandemic; |

[0001437749-22-018543:8k_2_02:49]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-22-018543:8k_2_02:50]
|  | ● | our dependence on our distribution network; |

[0001437749-22-018543:8k_2_02:51]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-22-018543:8k_2_02:52]
|  | ● | loss of our key management and employees; |

[0001437749-22-018543:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-22-018543:8k_2_02:54]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-22-018543:8k_2_02:55]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; |

[0001437749-22-018543:8k_2_02:56]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations. |

[0001437749-22-018543:8k_2_02:57]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2021 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-22-018543:8k_2_02:58]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-22-018543:8k_2_02:59]
Non-GAAP Financial Metrics

[0001437749-22-018543:8k_2_02:60]
Core Sales

[0001437749-22-018543:8k_2_02:61]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-22-018543:8k_2_02:62]
Adjusted EBITDA

[0001437749-22-018543:8k_2_02:63]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreements. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-22-018543:8k_2_02:64]
Adjusted Net Income

[0001437749-22-018543:8k_2_02:65]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-22-018543:8k_2_02:66]
Free Cash Flow

[0001437749-22-018543:8k_2_02:67]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-22-018543:8k_2_02:68]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-22-018543:8k_2_02:69]
SOURCE: Generac Holdings Inc.

[0001437749-22-018543:8k_2_02:70]
CONTACT:

[0001437749-22-018543:8k_2_02:71]
Michael W. Harris

[0001437749-22-018543:8k_2_02:72]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-22-018543:8k_2_02:73]
(262) 506-6064

[0001437749-22-018543:8k_2_02:74]
InvestorRelations@generac.com

[0001437749-22-018543:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-018543:8k_2_02:76]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |
| Costs of goods sold |  |  | 834,406 |  |  |  | 580,246 |  |  |  | 1,609,514 |  |  |  | 1,065,866 |  |
| Gross profit |  |  | 456,985 |  |  |  | 339,735 |  |  |  | 817,733 |  |  |  | 661,549 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 120,066 |  |  |  | 78,777 |  |  |  | 218,309 |  |  |  | 147,201 |  |
| Research and development |  |  | 41,599 |  |  |  | 25,344 |  |  |  | 81,343 |  |  |  | 47,732 |  |
| General and administrative |  |  | 52,600 |  |  |  | 41,610 |  |  |  | 94,572 |  |  |  | 74,509 |  |
| Amortization of intangibles |  |  | 25,876 |  |  |  | 11,052 |  |  |  | 51,930 |  |  |  | 20,031 |  |
| Total operating expenses |  |  | 240,141 |  |  |  | 156,783 |  |  |  | 446,154 |  |  |  | 289,473 |  |
| Income from operations |  |  | 216,844 |  |  |  | 182,952 |  |  |  | 371,579 |  |  |  | 372,076 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,235 | ) |  |  | (7,721 | ) |  |  | (19,789 | ) |  |  | (15,444 | ) |
| Investment income |  |  | 92 |  |  |  | 244 |  |  |  | 169 |  |  |  | 847 |  |
| Loss on extinguishment of debt |  |  | (3,743 | ) |  |  | (831 | ) |  |  | (3,743 | ) |  |  | (831 | ) |
| Other, net |  |  | 505 |  |  |  | (373 | ) |  |  | 751 |  |  |  | 2,936 |  |
| Total other expense, net |  |  | (13,381 | ) |  |  | (8,681 | ) |  |  | (22,612 | ) |  |  | (12,492 | ) |
| Income before provision for income taxes |  |  | 203,463 |  |  |  | 174,271 |  |  |  | 348,967 |  |  |  | 359,584 |  |
| Provision for income taxes |  |  | 45,826 |  |  |  | 46,362 |  |  |  | 74,434 |  |  |  | 81,730 |  |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 274,533 |  |  |  | 277,854 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 4,316 |  |  |  | 1,825 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.24 |  |  | $ | 2.06 |  |  | $ | 3.85 |  |  | $ | 4.44 |  |
| Weighted average common shares outstanding - basic: |  |  | 63,662,510 |  |  |  | 62,605,166 |  |  |  | 63,607,711 |  |  |  | 62,533,725 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.21 |  |  | $ | 2.01 |  |  | $ | 3.78 |  |  | $ | 4.34 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,713,748 |  |  |  | 64,088,709 |  |  |  | 64,799,002 |  |  |  | 64,097,378 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 120,864 |  |  | $ | 119,246 |  |  | $ | 243,229 |  |  | $ | 273,062 |  |

[0001437749-22-018543:8k_2_02:77]
6

[0001437749-22-018543:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-018543:8k_2_02:79]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 467,140 |  |  | $ | 147,339 |  |
| Accounts receivable, less allowance for credit losses |  |  | 692,291 |  |  |  | 546,466 |  |
| Inventories |  |  | 1,240,524 |  |  |  | 1,089,705 |  |
| Prepaid expenses and other assets |  |  | 91,356 |  |  |  | 64,954 |  |
| Total current assets |  |  | 2,491,311 |  |  |  | 1,848,464 |  |
| Property and equipment, net |  |  | 446,007 |  |  |  | 440,852 |  |
| Customer lists, net |  |  | 217,152 |  |  |  | 238,722 |  |
| Patents and technology, net |  |  | 469,384 |  |  |  | 492,473 |  |
| Other intangible assets, net |  |  | 51,727 |  |  |  | 66,436 |  |
| Tradenames, net |  |  | 233,023 |  |  |  | 243,531 |  |
| Goodwill |  |  | 1,388,051 |  |  |  | 1,409,674 |  |
| Deferred income taxes |  |  | 14,091 |  |  |  | 15,740 |  |
| Operating lease and other assets |  |  | 162,205 |  |  |  | 121,888 |  |
| Total assets |  | $ | 5,472,951 |  |  | $ | 4,877,780 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 77,514 |  |  | $ | 72,035 |  |
| Accounts payable |  |  | 614,009 |  |  |  | 674,208 |  |
| Accrued wages and employee benefits |  |  | 61,249 |  |  |  | 72,060 |  |
| Other accrued liabilities |  |  | 415,730 |  |  |  | 331,674 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 3,674 |  |  |  | 5,930 |  |
| Total current liabilities |  |  | 1,172,176 |  |  |  | 1,155,907 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,286,499 |  |  |  | 902,091 |  |
| Deferred income taxes |  |  | 151,643 |  |  |  | 205,964 |  |
| Operating lease and other long-term liabilities |  |  | 360,041 |  |  |  | 341,681 |  |
| Total liabilities |  |  | 2,970,359 |  |  |  | 2,605,643 |  |
| Redeemable noncontrolling interest |  |  | 82,830 |  |  |  | 58,050 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,588,588 and 72,386,017 shares issued at June 30, 2022 and December 31, 2021, respectively |  |  | 727 |  |  |  | 725 |  |
| Additional paid-in capital |  |  | 967,819 |  |  |  | 952,939 |  |
| Treasury stock, at cost |  |  | (475,294 | ) |  |  | (448,976 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,210,582 |  |  |  | 1,965,957 |  |
| Accumulated other comprehensive loss |  |  | (82,839 | ) |  |  | (54,755 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,418,879 |  |  |  | 2,213,774 |  |
| Noncontrolling interests |  |  | 883 |  |  |  | 313 |  |
| Total stockholders’ equity |  |  | 2,419,762 |  |  |  | 2,214,087 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,472,951 |  |  | $ | 4,877,780 |  |

[0001437749-22-018543:8k_2_02:80]
7

[0001437749-22-018543:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-018543:8k_2_02:82]
|  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 274,533 |  |  | $ | 277,854 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 25,629 |  |  |  | 19,435 |  |
| Amortization of intangible assets |  |  | 51,930 |  |  |  | 20,031 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,287 |  |  |  | 1,295 |  |
| Loss on extinguishment of debt |  |  | 3,743 |  |  |  | 831 |  |
| Deferred income taxes |  |  | (61,625 | ) |  |  | 7,003 |  |
| Share-based compensation expense |  |  | 16,562 |  |  |  | 12,421 |  |
| Gain on disposal of assets |  |  | (587 | ) |  |  | (3,978 | ) |
| Other noncash (gains) charges |  |  | (2,037 | ) |  |  | (142 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (143,308 | ) |  |  | (96,846 | ) |
| Inventories |  |  | (158,232 | ) |  |  | (163,820 | ) |
| Other assets |  |  | 1,637 |  |  |  | (4,172 | ) |
| Accounts payable |  |  | (54,583 | ) |  |  | 186,041 |  |
| Accrued wages and employee benefits |  |  | (11,876 | ) |  |  | 2,537 |  |
| Other accrued liabilities |  |  | 86,616 |  |  |  | 38,028 |  |
| Excess tax benefits from equity awards |  |  | (15,996 | ) |  |  | (21,525 | ) |
| Net cash provided by operating activities |  |  | 13,693 |  |  |  | 274,993 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,883 |  |  |  | 74 |  |
| Proceeds from sale of investment |  |  | 1,308 |  |  |  | 4,902 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,843 |  |  |  | 1,363 |  |
| Contribution to equity method investment |  |  | (10,229 | ) |  |  | (216 | ) |
| Expenditures for property and equipment |  |  | (46,503 | ) |  |  | (54,222 | ) |
| Acquisition of business, net of cash acquired |  |  | (11,421 | ) |  |  | (419,017 | ) |
| Net cash used in investing activities |  |  | (63,119 | ) |  |  | (467,116 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 216,681 |  |  |  | 57,589 |  |
| Proceeds from long-term borrowings |  |  | 935,000 |  |  |  | 50,000 |  |
| Repayments of short-term borrowings |  |  | (208,244 | ) |  |  | (73,675 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (538,401 | ) |  |  | (53,095 | ) |
| Payment of contingent acquisition consideration |  |  | – |  |  |  | (3,750 | ) |
| Payment of debt issuance costs |  |  | (10,330 | ) |  |  | (1,185 | ) |
| Purchase of additional ownership interest |  |  | (375 | ) |  |  | (27,164 | ) |
| Taxes paid related to equity awards |  |  | (38,347 | ) |  |  | (39,967 | ) |
| Proceeds from the exercise of stock options |  |  | 10,383 |  |  |  | 18,567 |  |
| Net cash provided by (used in) financing activities |  |  | 366,367 |  |  |  | (72,680 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,860 |  |  |  | (239 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 319,801 |  |  |  | (265,042 | ) |
| Cash and cash equivalents at beginning of period |  |  | 147,339 |  |  |  | 655,128 |  |
| Cash and cash equivalents at end of period |  | $ | 467,140 |  |  | $ | 390,086 |  |

[0001437749-22-018543:8k_2_02:83]
8

[0001437749-22-018543:8k_2_02:84]
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-018543:8k_2_02:85]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |  | Three Months Ended June 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,107,431 |  |  | $ | 18,987 |  |  | $ | 1,126,418 |  |  | $ | 784,146 |  |  | $ | 8,798 |  |  | $ | 792,944 |  |
| International |  |  | 183,960 |  |  |  | 19,334 |  |  |  | 203,294 |  |  |  | 135,835 |  |  |  | 6,549 |  |  |  | 142,384 |  |
| Intercompany elimination |  |  | - |  |  |  | (38,321 | ) |  |  | (38,321 | ) |  |  |  |  |  |  | (15,347 | ) |  |  | (15,347 | ) |
| Total net sales |  | $ | 1,291,391 |  |  | $ | - |  |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | - |  |  | $ | 919,981 |  |

[0001437749-22-018543:8k_2_02:86]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |  | Six Months Ended June 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,072,105 |  |  | $ | 29,257 |  |  | $ | 2,101,362 |  |  | $ | 1,476,884 |  |  | $ | 15,479 |  |  | $ | 1,492,363 |  |
| International |  |  | 355,142 |  |  |  | 33,659 |  |  |  | 388,801 |  |  |  | 250,531 |  |  |  | 8,552 |  |  |  | 259,083 |  |
| Intercompany elimination |  |  | - |  |  |  | (62,916 | ) |  |  | (62,916 | ) |  |  | - |  |  |  | (24,031 | ) |  |  | (24,031 | ) |
| Total net sales |  | $ | 2,427,247 |  |  | $ | - |  |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |  | $ | - |  |  | $ | 1,727,415 |  |

[0001437749-22-018543:8k_2_02:87]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Residential products |  | $ | 896,013 |  |  | $ | 599,991 |  |  | $ | 1,672,957 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 309,348 |  |  |  | 254,295 |  |  |  | 588,077 |  |  |  | 456,686 |  |
| Other |  |  | 86,030 |  |  |  | 65,695 |  |  |  | 166,213 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,291,391 |  |  | $ | 919,981 |  |  | $ | 2,427,247 |  |  | $ | 1,727,415 |  |

[0001437749-22-018543:8k_2_02:88]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, 2022 |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 241,928 |  |  | $ | 203,931 |  |  | $ | 412,349 |  |  | $ | 411,004 |  |
| International |  |  | 29,534 |  |  |  | 13,748 |  |  |  | 55,526 |  |  |  | 20,869 |  |
| Total adjusted EBITDA (1) |  | $ | 271,462 |  |  | $ | 217,679 |  |  | $ | 467,875 |  |  | $ | 431,873 |  |

[0001437749-22-018543:8k_2_02:89]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-22-018543:8k_2_02:90]
9

[0001437749-22-018543:8k_2_02:91]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-018543:8k_2_02:92]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Net income attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 4,316 |  |  |  | 1,825 |  |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 274,533 |  |  |  | 277,854 |  |
| Interest expense |  |  | 10,235 |  |  |  | 7,721 |  |  |  | 19,789 |  |  |  | 15,444 |  |
| Depreciation and amortization |  |  | 39,098 |  |  |  | 21,229 |  |  |  | 77,559 |  |  |  | 39,466 |  |
| Provision for income taxes |  |  | 45,826 |  |  |  | 46,362 |  |  |  | 74,434 |  |  |  | 81,730 |  |
| Non-cash write-down and other adjustments (1) |  |  | 4,607 |  |  |  | 1,173 |  |  |  | (3,185 | ) |  |  | (2,695 | ) |
| Non-cash share-based compensation expense (2) |  |  | 7,735 |  |  |  | 6,973 |  |  |  | 16,562 |  |  |  | 12,421 |  |
| Loss on extinguishment of debt (3) |  |  | 3,743 |  |  |  | 831 |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (4) |  |  | 1,592 |  |  |  | 5,172 |  |  |  | 2,581 |  |  |  | 6,086 |  |
| Business optimization and other charges (5) |  |  | 1,590 |  |  |  | - |  |  |  | 2,749 |  |  |  | 159 |  |
| Other |  |  | (601 | ) |  |  | 309 |  |  |  | (890 | ) |  |  | 577 |  |
| Adjusted EBITDA |  |  | 271,462 |  |  |  | 217,679 |  |  |  | 467,875 |  |  |  | 431,873 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,742 |  |  |  | 2,015 |  |  |  | 7,167 |  |  |  | 4,207 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 267,720 |  |  | $ | 215,664 |  |  | $ | 460,708 |  |  | $ | 427,666 |  |

[0001437749-22-018543:8k_2_02:93]
(1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-22-018543:8k_2_02:94]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-22-018543:8k_2_02:95]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-22-018543:8k_2_02:96]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-22-018543:8k_2_02:97]
(5)  The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-22-018543:8k_2_02:98]
10

[0001437749-22-018543:8k_2_02:99]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 156,359 |  |  | $ | 127,036 |  |  | $ | 270,217 |  |  | $ | 276,029 |  |
| Net income attributable to noncontrolling interests |  |  | 1,278 |  |  |  | 873 |  |  |  | 4,316 |  |  |  | 1,825 |  |
| Net income |  |  | 157,637 |  |  |  | 127,909 |  |  |  | 274,533 |  |  |  | 277,854 |  |
| Provision for income taxes (8) |  |  | - |  |  |  | 46,362 |  |  |  | - |  |  |  | 81,730 |  |
| Amortization of intangible assets |  |  | 25,876 |  |  |  | 11,052 |  |  |  | 51,930 |  |  |  | 20,031 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 650 |  |  |  | 649 |  |  |  | 1,287 |  |  |  | 1,295 |  |
| Loss on extinguishment of debt (3) |  |  | 3,743 |  |  |  | 831 |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 5,710 |  |  |  | 4,954 |  |  |  | (46 | ) |  |  | 5,643 |  |
| (Gain)/loss attributable to business or asset dispositions (7) |  |  | - |  |  |  | – |  |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges (5) |  |  | 1,590 |  |  |  | – |  |  |  | 2,749 |  |  |  | 159 |  |
| Cash income tax expense (8) |  |  | - |  |  |  | (37,406 | ) |  |  | - |  |  |  | (75,274 | ) |
| Adjusted net income |  |  | 195,206 |  |  |  | 154,351 |  |  |  | 333,967 |  |  |  | 308,278 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,678 |  |  |  | 1,121 |  |  |  | 5,168 |  |  |  | 2,344 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 193,528 |  |  | $ | 153,230 |  |  | $ | 328,799 |  |  | $ | 305,934 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.99 |  |  | $ | 2.39 |  |  | $ | 5.07 |  |  | $ | 4.77 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,713,748 |  |  |  | 64,088,709 |  |  |  | 64,799,002 |  |  |  | 64,097,378 |  |

[0001437749-22-018543:8k_2_02:100]
(6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-22-018543:8k_2_02:101]
(7) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-22-018543:8k_2_02:102]
(8) Amount for the three and six months ended June 30, 2021 is based on an anticipated cash income tax rate at the time of approximately 21.0% to 21.5% for the full year ended 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP tax expense for the three and six months ended June 30, 2021 would result in adjusted net income per diluted share of $2.25 and $4.67, respectively, on a pro forma basis.

[0001437749-22-018543:8k_2_02:103]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash provided by operating activities |  | $ | 23,835 |  |  | $ | 122,450 |  |  | $ | 13,693 |  |  | $ | 274,993 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 270 |  |  |  | 651 |  |  |  | 1,843 |  |  |  | 1,363 |  |
| Expenditures for property and equipment |  |  | (18,303 | ) |  |  | (26,753 | ) |  |  | (46,503 | ) |  |  | (54,222 | ) |
| Free cash flow |  | $ | 5,802 |  |  | $ | 96,348 |  |  | $ | (30,967 | ) |  | $ | 222,134 |  |

[0001437749-22-018543:8k_2_02:104]
11
