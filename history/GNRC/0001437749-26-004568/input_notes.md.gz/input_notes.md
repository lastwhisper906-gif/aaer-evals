# GNRC notes — 0001437749-26-004568


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001437749-26-004568:notes:1]
Item 1C. Cybersecurity

[0001437749-26-004568:notes:2]
The Company’s management and Board recognize the importance of strong oversight of cybersecurity risk, information security and technology in maintaining the trust and confidence of our customers, partners, employees and stockholders. Our processes for assessing, identifying and managing material risks from cybersecurity threats is incorporated into our Enterprise Risk Management (ERM) program in a similar fashion to other legal, compliance, operational, and financial risk areas. The Company maintains cybersecurity measures aligned with the National Institute of Standards and Technology Cybersecurity Framework (Framework) which organizes cybersecurity risks into six categories: govern, identify, protect, detect, respond and recover, and looks to other standards as well to help identify, assess, and manage cybersecurity risks relevant to our business.

[0001437749-26-004568:notes:3]
Our Chief Information Officer (CIO) oversees our information systems and cybersecurity function and reports to our Chief Executive Officer (CEO). He has over 20 years of experience in leading information systems management, strategy, and operational execution, including incident prevention, management, and response. Our Company’s Chief Information Security Officer (CISO) is responsible for developing and implementing our information security program and reports to our CIO. The CISO has over 25 years of experience supporting cybersecurity and information technology. They are supported by a direct and cross-functional team of professionals with expertise and experience in threat assessment and detection, mitigation strategies, incident response, training, and regulatory compliance.

[0001437749-26-004568:notes:4]
In addition, we have established a Cybersecurity Steering Committee comprised of members of executive leadership. The Steering Committee, in which our CIO and CISO participate, meets regularly and has established Company-wide policies and standards concerning cybersecurity matters. These policies cover areas such as threat protection, access controls, multifactor authentication, containment of confidential information and the use of the internet, email and wireless devices. We have an established incident response plan led by our CIO and CISO and depending on the nature and severity of the incident, requires escalating notifications up to our CEO and Board.

[0001437749-26-004568:notes:5]
Our Board oversees our enterprise risk management activities. The Board receives periodic updates on our cybersecurity risk management program as well as regular updates and education on relevant legislation and trends related to cybersecurity. Our Audit Committee assists the Board in its oversight role and receives regular reports from management on the Company’s information systems and cybersecurity program. Several members of our Board's Audit Committee have expertise and experience in cybersecurity, and one director is the President of a major cybersecurity services provider.

[0001437749-26-004568:notes:6]
The CISO and information technology security team conduct regular risk assessments to assess the overall technology infrastructure and related business processes, identify and address potential security gaps and vulnerabilities, and identify areas requiring additional focus. These risk assessments extend to our supply chain, where cybersecurity health assessments are employed for certain critical suppliers. The results are used to calculate a Cybersecurity Risk Score, a key component of our Supply Chain Scorecard used to proactively identify and manage potential risks. Additionally, we require certain third parties that could introduce significant cybersecurity risk to us to agree by contract to manage their cybersecurity risks in specified ways, as appropriate. Risk assessments are also performed on new products and software as part of our new product development process.

[0001437749-26-004568:notes:7]
As part of our risk assessments, we engage third-party services for network penetration testing and security evaluations, conduct incident response table-top exercises, and perform regular testing of controls related to our financial information systems by our Internal Audit function.

[0001437749-26-004568:notes:8]
In order to promote a culture of security awareness across our organization, employees are required to complete an annual cybersecurity awareness training and are provided with periodic information updates on cybersecurity threats. We also maintain cyber insurance policies to help partially mitigate the financial impact of a significant cybersecurity incident.

[0001437749-26-004568:notes:9]
Despite our best efforts, we cannot guarantee that our security measures will prevent all potential cybersecurity incidents or breaches. Our systems are continually subject to sophisticated and evolving cyber threats, such as phishing, ransomware, social engineering, and advanced persistent threats. However, to date, we have not been subject to any incidents or cyber-attacks that have materially impacted our operations or financial condition. The Company has invested in developing and acquiring cybersecurity capabilities allowing us to monitor threats and manage incident response. We have also developed internal policies to reduce the impact of cybersecurity incidents, including providing clear guidelines for incident classification, escalation, and response. We recognize the importance of continued monitoring and improvement of our cybersecurity program, and will continue to evolve our security controls, cybersecurity risk management, incident response capabilities, and third-party vendor management protocols.

[0001437749-26-004568:notes:10]
For additional information on the cybersecurity risks that we face, also see Item 1A. “Risk Factors” of this Annual Report on Form 10-K.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-26-004568:notes:11]
| 1. | Description of Business |

[0001437749-26-004568:notes:12]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services to the residential, commercial, data center, telecom, rental, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-26-004568:notes:13]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-26-004568:notes:14]
|  | ● |  | In November 2024, the Company acquired Wolverine Power Systems (Wolverine), headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● |  | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC (Ageto). Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado. |
|  | ● |  | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System (C&I BESS) product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● |  | In April 2024, the Company acquired Huntington Power Equipment, Inc. (Huntington), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● |  | In February 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market, primarily in Europe. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-26-004568:notes:15]
| 2. | Summary of Accounting Policies |

[0001437749-26-004568:notes:16]
Principles of Consolidation

[0001437749-26-004568:notes:17]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-26-004568:notes:18]
Cash and Cash Equivalents

[0001437749-26-004568:notes:19]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-26-004568:notes:20]
Concentration of Credit Risk

[0001437749-26-004568:notes:21]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured. One customer accounted for approximately 9% and 10% of accounts receivable as of  December 31, 2025 and 2024, respectively. No one customer accounted for greater than 4%, 5%, and 4%, of net sales during the years ended  December 31, 2025, 2024, and 2023, respectively.

[0001437749-26-004568:notes:22]
Accounts Receivable and Allowance for Credit Losses

[0001437749-26-004568:notes:23]
The Company's trade and other receivables primarily arise from the sale of its products and services to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, EPC companies, telecommunications and data center customers, and certain end users with payment terms generally ranging from
      30 to
      90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that
       may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-26-004568:notes:24]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity-by-entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-26-004568:notes:25]
The Company holds various credit insurance plans that cover the risk of loss up to specified amounts on certain trade receivables. As of
       December 31, 2025, the Company had gross receivables of
      $637,243 and an allowance for credit losses of
      $34,504.

[0001437749-26-004568:notes:26]
Inventories

[0001437749-26-004568:notes:27]
Inventories are stated at the lower of cost or market, with cost determined using the
      first-in,
      first-out method.

[0001437749-26-004568:notes:28]
Property and Equipment

[0001437749-26-004568:notes:29]
Property and equipment, including internal use software, is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. The Company capitalizes internal use software and significant enhancements when the Company obtains a software license or develops the software internally. The Company capitalizes cloud computing software arrangements that qualify as service contracts if the Company has the contractual right to take possession of the software at any time during the contract period, without significant penalty and if it is feasible for the Company to either operate the software internally or contract with a third party to host the software on our behalf. Implementation costs incurred in cloud computing arrangements that are service contracts are recorded in prepaid expenses and other assets and operating lease and other assets in the Consolidated Balance Sheets and are amortized over the expected service period of the cloud computing arrangements. Finance lease right of use assets are included in property and equipment.

[0001437749-26-004568:notes:30]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office & information technology equipment and internal use software |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-26-004568:notes:31]
Total depreciation and finance lease amortization expense was $93,328, $74,025, and $62,408 for the years ended  December 31, 2025, 2024 and 2023, respectively.

[0001437749-26-004568:notes:32]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-26-004568:notes:33]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-26-004568:notes:34]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-26-004568:notes:35]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2025, 2024 and 2023, and found no impairment.

[0001437749-26-004568:notes:36]
Impairment of Long-Lived Assets

[0001437749-26-004568:notes:37]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-26-004568:notes:38]
Debt Issuance Costs

[0001437749-26-004568:notes:39]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt or included in operating lease and other assets in the consolidated balance sheets. Deferred financing costs and original issue discount are amortized to interest expense using the effective interest method over the terms of the related credit agreements. $2,380, $3,242, and $3,885 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2025, 2024, and 2023, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2026 - $2,195; 2027 - $2,242; 2028 - $2,280; 2029 - $2,295; 2030 - $1,385.

[0001437749-26-004568:notes:40]
Income Taxes

[0001437749-26-004568:notes:41]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax basis of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-26-004568:notes:42]
Revenue Recognition

[0001437749-26-004568:notes:43]
The Company recognizes revenue as products are transferred to, or services are performed for, customers in an amount reflecting the consideration which we expect to receive in return for those products and services.

[0001437749-26-004568:notes:44]
The Company’s revenues primarily consist of product sales including residential and commercial & industrial generators, energy storage systems, smart thermostats and home monitoring products, and other power products including light towers and a broad line of outdoor power equipment.

[0001437749-26-004568:notes:45]
The Company also offers various services and solutions, including extended warranties, remote monitoring offered through SaaS arrangements, installation, maintenance, data center and telecom design and build, and customer support and software maintenance.

[0001437749-26-004568:notes:46]
We use executed sales agreements and purchase orders to determine the existence of a customer contract.

[0001437749-26-004568:notes:47]
For each customer contract, we determine if the products and services promised to the customer are distinct performance obligations.  A product or service is distinct if both the following criteria are met at contract inception: (1) The customer can benefit from the product or service on its own or with other readily available resources, and (2) our promise to transfer the product or perform the service is separately identifiable from other promises in the contract.

[0001437749-26-004568:notes:48]
For each performance obligation in a contract, we first determine whether the performance obligation is satisfied over time.  A performance obligation is satisfied over time if it meets any of the following criteria:

[0001437749-26-004568:notes:49]
|  | ● | The customer simultaneously receives and consumes the benefits provided by our performance as we perform; |

[0001437749-26-004568:notes:50]
|  | ● | Our performance creates or enhances an asset that the customer controls as the asset is created or enhanced; |

[0001437749-26-004568:notes:51]
|  | ● | Our performance does not create an asset for which we have an alternative use and we have an enforceable right to payment for performance completed to date. |

[0001437749-26-004568:notes:52]
If one or more of these criteria are met, then we recognize revenue over time using a method that reflects performance under the contract.  If none of these criteria are met, then we recognize revenue at a point in time, when control transfers to the customer.

[0001437749-26-004568:notes:53]
For the majority of our product sales, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue generally reflects the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based on historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based on historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms predominantly have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add, and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are typically recognized upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer.

[0001437749-26-004568:notes:54]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based on historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information regarding the Company’s standard warranties.

[0001437749-26-004568:notes:55]
For services and solutions, the Company recognizes revenue at a point in time or over the period the related services are performed.

[0001437749-26-004568:notes:56]
The Company’s services relate mainly to extended warranty coverage for certain products, which are accounted for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as prepaid expenses and other assets when cost will be recognized in less than twelve months, and operating lease and other assets when cost will be recognized in more than twelve months, in the consolidated balance sheets. The deferred contract costs are amortized to cost of goods sold in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information regarding the Company’s extended warranties.

[0001437749-26-004568:notes:57]
Revenue from the Company’s SaaS arrangements, such as remote monitoring services which allow our customers to use hosted software over a contract period without taking possession of the software, are recognized over time during the period the customer is provided access to the software.

[0001437749-26-004568:notes:58]
Lifetime customer support and software maintenance (support and maintenance) are provided primarily in conjunction with the Company’s sale of its smart thermostats.  The company allocates revenue to support and maintenance based on estimated stand-alone selling prices and recognizes the revenue over the estimated life of the thermostat.

[0001437749-26-004568:notes:59]
The Company also provides back-up power solutions for data centers, including the product, enclosure packaging, project management and oversight of product delivery, installation, commissioning, and training. Revenue for the products sold under these contracts are typically recognized when the control of the underlying goods and services is transferred to the customer. In making this evaluation, the Company considers contractual terms and whether there is an alternative use for the good or service. Through this process, the Company has concluded that substantially all of the performance obligations under these contracts transfer control to the customer over time as a result of enforceable payment rights and the customized nature of its goods and services, which create assets without an alternative use. Revenue is recognized on performance obligations that are satisfied overtime by measuring progress using the cost-to-cost method of percentage-of-completion because it best depicts the transfer of control to the customer. Under this method, the Company measures progress based on the ratio of costs incurred to date to total estimated costs for the performance obligations. Each contract is evaluated at contract inception to identify risks and estimate revenue and costs. If a loss is expected on a contract, the complete estimated loss is recorded in the period in which the loss is identified. The Company recognizes changes in estimated sales or costs and the resulting profit or loss on a cumulative basis in the period when the estimate changes.

[0001437749-26-004568:notes:60]
Total service revenues accounted for approximately 4% of net sales during the years ended  December 31, 2025, 2024 and 2023.

[0001437749-26-004568:notes:61]
Contract Liabilities

[0001437749-26-004568:notes:62]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods or services; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears after shipment of the product to the customer or performance of the service. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance of performance are recognized as deferred revenue and recorded in other accrued liabilities (for the portion expected to be recognized within twelve months) or deferred revenue (for the portion not expected to be recognized within twelve months) in the consolidated balance sheets, until revenue is recognized.

[0001437749-26-004568:notes:63]
Below is a summary of our short-term and long-term contract liabilities balance, excluding the extended warranty deferred revenue balance disclosed in Note 11:

[0001437749-26-004568:notes:64]
|  | December 31, 2025 | December 31, 2024 |
| Balance as of beginning of year | $97,821 | $19,173 |
| Balance as of end of period | $151,257 | $26,858 |

[0001437749-26-004568:notes:65]
During the year ended  December 31, 2025, the Company recognized revenue of $61,299 related to amounts included in the  December 31, 2024 deferred revenue balance.  During the year ended  December 31, 2024, the Company recognized revenue of $19,173 related to amounts included in the  December 31, 2023 deferred revenue balance. As of  December 31, 2025, the aggregate amount of revenue that the Company expects to recognize on remaining performance obligations (excluding extended warranty) was $378,782, of which 100% is expected to be recognized as revenue over the next two years.  We have applied the practical expedient to exclude the value of remaining performance obligations for contracts with an original term of one year or less.

[0001437749-26-004568:notes:66]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-26-004568:notes:67]
Advertising and Co-Op Advertising

[0001437749-26-004568:notes:68]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $123,202, $116,550, and $118,303 for the years ended  December 31, 2025, 2024 and 2023, respectively.

[0001437749-26-004568:notes:69]
Research and Development

[0001437749-26-004568:notes:70]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $243,470, $219,600, and $173,443 for the years ended  December 31, 2025, 2024 and 2023, respectively.

[0001437749-26-004568:notes:71]
Foreign Currency Translation and Transactions

[0001437749-26-004568:notes:72]
Balance sheet amounts for non-U.S. Dollar functional currency subsidiaries are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related balance sheet translation adjustments are made directly to accumulated other comprehensive income (loss), a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:73]
Fair Value of Financial Instruments

[0001437749-26-004568:notes:74]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-26-004568:notes:75]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Tranche A Term Loan Facility borrowing, which has a net carrying value of $696,780, was approximately $693,000 (Level 2) as of  December 31, 2025. The fair value of the Tranche B Term Loan Facility borrowing, which has a net carrying value of $491,297, was approximately $494,984 (Level 2) as of  December 31, 2025. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-26-004568:notes:76]
For the fair value of the assets and liabilities measured on a recurring basis, excluding the contingent consideration discussed below, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements of this Annual Report on Form 10-K. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-26-004568:notes:77]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these warrants is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in 2025, 2024, and 2023 expire at the earlier of when the price per share equals or exceeds $120.00 or in 2028, 2028, and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-26-004568:notes:78]
Equity Securities

[0001437749-26-004568:notes:79]
Equity securities consist of shares of Wallbox N.V's (Wallbox) Class A common stock (Wallbox Shares). The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The investment in Wallbox Shares is included in operating lease and other assets in the consolidated balance sheets. The fair value of the investment in Wallbox Shares was $4,457 and $19,075 as of  December 31, 2025, and  December 31, 2024, respectively. Gains and losses attributable to the Wallbox Shares change in fair value are recognized in other expense, net in the consolidated statements of comprehensive income. The loss recognized on the investment in Wallbox Shares was $14,617 and $30,679 for the years ended  December 31, 2025 and 2024, respectively. For additional information regarding the Company's investment in Wallbox, see Note 5, “Derivative Instruments and Hedging Activities”.

[0001437749-26-004568:notes:80]
Contingent Consideration

[0001437749-26-004568:notes:81]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-26-004568:notes:82]
The combined fair value of contingent consideration for the Chilicon Power LLC (Chilicon) and Ageto acquisitions as of  December 31, 2025, and for the Chilicon, Ageto, and PR Industrial S.r.l. (Pramac) acquisitions as of  December 31, 2024, was $32,872 and $34,114, respectively. The contingent consideration period for Pramac ended as of  December 31, 2025. The contingent consideration period for Chilicon extends through  December 31, 2028 and is paid annually based on incremental earnings and upon achievement of certain milestones. The contingent consideration for Ageto is paid in equal increments with one third of the contingent consideration earned as of  August 1, 2025, and the remaining two increments capable of being earned on  August 1, 2026 and  August 1, 2027. The current portion of contingent consideration totals $11,175 and is reported in other accrued liabilities, and the non-current portion totals $21,697 and is reported in operating lease and other long-term liabilities in the consolidated balance sheets.

[0001437749-26-004568:notes:83]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-26-004568:notes:84]
| Beginning balance, January 1, 2025 |  | $ | 34,114 |  |
| Payment of contingent consideration (1) |  |  | (2,700 | ) |
| Present value interest accretion |  |  | 1,458 |  |
| Ending balance, December 31, 2025 |  | $ | 32,872 |  |

[0001437749-26-004568:notes:85]
(1) Represents payments of $2,700 in cash for the Ageto acquisition.

[0001437749-26-004568:notes:86]
Use of Estimates

[0001437749-26-004568:notes:87]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-26-004568:notes:88]
Derivative Instruments and Hedging Activities

[0001437749-26-004568:notes:89]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or trade derivative financial instruments for trading purposes.

[0001437749-26-004568:notes:90]
Share-Based Compensation

[0001437749-26-004568:notes:91]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements of this Annual Report on Form 10-K for further information on the Company’s share-based compensation plans and accounting.

[0001437749-26-004568:notes:92]
New Accounting Pronouncements

[0001437749-26-004568:notes:93]
Changes to U.S. GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification.

[0001437749-26-004568:notes:94]
In  September 2025, the FASB issued ASU 2025-06 Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40). The update is intended to better align internal use software guidance with modern development methods, which have evolved to commonly include incremental and iterative development approaches. The ASU requires an entity to start capitalizing software costs when management has authorized and committed to funding a software project and when it is probable the project will be completed and used to perform the intended function. The ASU amendments also supersede previous guidance on website development costs. The update is effective for fiscal years beginning after  December 15, 2027 and  may be adopted prospectively, retrospectively or with a modified transition approach. Early adoption is permitted. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-26-004568:notes:95]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated provisions.

[0001437749-26-004568:notes:96]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024. The Company adopted this ASU as of  December 31, 2025 on a retrospective basis, which did not have a material impact on the Company's consolidated financial statements. Refer to Note 15, “Income Taxes” for the additional disclosures required by the adoption of this ASU.

[0001437749-26-004568:notes:97]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during 2025 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-26-004568:notes:98]
| 3. | Acquisitions |

[0001437749-26-004568:notes:99]
Fiscal 2024 Acquisitions

[0001437749-26-004568:notes:100]
On  November 1, 2024, the Company acquired Wolverine, headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-26-004568:notes:101]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto. Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado.

[0001437749-26-004568:notes:102]
On  June 26, 2024, the Company closed on the acquisition of the C&I BESS product offering from SunGrid Solutions Inc. located in Cambridge, Canada.

[0001437749-26-004568:notes:103]
On  April 1, 2024, the Company acquired Huntington, headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-26-004568:notes:104]
The Company recorded its preliminary purchase price allocation for C&I BESS and Huntington during the second quarter of 2024, and the Company recorded its preliminary purchase price allocation for Ageto and Wolverine during the third quarter and fourth quarter of 2024, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington was finalized in the second quarter of 2025, while purchase accounting for Ageto and Wolverine was finalized in the third quarter and fourth quarter of 2025, respectively. There were no material adjustments to the Company's preliminary estimates for Wolverine, Ageto, C&I BESS, or Huntington. The final combined purchase price for Wolverine, Ageto, C&I BESS, and Huntington was $45,765. The accompanying consolidated financial statements include the results of the acquired businesses since their dates of acquisition.

[0001437749-26-004568:notes:105]
Fiscal 2023 Acquisitions

[0001437749-26-004568:notes:106]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial & industrial energy storage market.

[0001437749-26-004568:notes:107]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for REFUstor was finalized in the first quarter of 2024 and did not result in material adjustments to the Company's preliminary estimates. The final purchase price was $16,127. The accompanying consolidated financial statements include the results of REFUstor since the date of acquisition.

[0001437749-26-004568:notes:108]
Summary Purchase Price Allocations

[0001437749-26-004568:notes:109]
The fair values assigned to certain assets acquired and liabilities assumed for all acquisitions completed during 2023 and 2024 are shown below. No material acquisitions were completed in 2025.

[0001437749-26-004568:notes:110]
|  |  | 2024 Acquisitions |  |  | 2023 Acquisitions |  |
| Accounts receivable |  | $ | 9,528 |  |  | $ | 347 |  |
| Inventories |  |  | 9,835 |  |  |  | 1,239 |  |
| Prepaid expenses and other current assets |  |  | 786 |  |  |  | 166 |  |
| Property and equipment |  |  | 809 |  |  |  | 5,843 |  |
| Intangible assets |  |  | 19,311 |  |  |  | 6,174 |  |
| Goodwill |  |  | 16,354 |  |  |  | 5,363 |  |
| Other assets |  |  | 4,461 |  |  |  | 837 |  |
| Total assets acquired |  |  | 61,084 |  |  |  | 19,969 |  |
| Accounts payable |  |  | 2,420 |  |  |  | 1,278 |  |
| Accrued wages and employee benefits |  |  | 1,204 |  |  |  | 264 |  |
| Other accrued liabilities |  |  | 9,074 |  |  |  | 236 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 146 |  |  |  | - |  |
| Deferred income taxes |  |  | 803 |  |  |  | 2,007 |  |
| Other long-term liabilities |  |  | 1,490 |  |  |  | 57 |  |
| Long-term debt |  |  | 182 |  |  |  | - |  |
| Net assets acquired |  | $ | 45,765 |  |  | $ | 16,127 |  |

[0001437749-26-004568:notes:111]
Pro forma and other financial information are not presented as the effects of the Company's acquisitions since 2023 are not material to the Company's results of operations or financial position.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-26-004568:notes:112]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-26-004568:notes:113]
The Company entered into a joint venture with E.A. Juffali & Brothers ("Juffali") on  August 7, 2025, based in Bahrain, aiming to expand its footprint in the Middle East region. The joint venture, operating under the name Generac Juffali Generators WLL, will function as a distinct legal entity with ownership interests divided between the Company and Juffali at 51% and 49%, respectively. As the Company holds a controlling financial interest in the joint venture's operating entity, it will consolidate the entity. During the third quarter of 2025, Juffali funded 49% of the total capital contributed to the new legal entity. The issuance date fair value of the 49% noncontrolling interest was $979 and was recorded in the consolidated balance sheets as a redeemable noncontrolling interest. This classification is based on Juffali’s right to require redemption of its interest in Generac Juffali Generators under specific triggering circumstances outlined in the joint venture agreement. The redeemable noncontrolling interest is initially recognized at its issuance date fair value and is adjusted each reporting period to reflect the noncontrolling interests’ share of comprehensive income. If the redeemable noncontrolling interest becomes currently redeemable or is probable of becoming currently redeemable, it is then adjusted to the greater of the redemption value or the carrying value, with any redemption value adjustments being recorded directly to retained earnings in the consolidated balance sheets.

[0001437749-26-004568:notes:114]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price for the remaining 20% ownership interest included $105,264 of initial consideration, which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023, and $11,490 of contingent deferred consideration of up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022. Accordingly, there was no redeemable noncontrolling interest related to Pramac as of  December 31, 2023. This contingent deferred consideration was reduced to zero in the fourth quarter of 2024 and there was no additional change through the contingent consideration period which ended  December 31, 2025. Refer to Note 2, "Summary of Accounting Policies", to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the contingent deferred consideration.

[0001437749-26-004568:notes:115]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder had a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company had a call option that  may be redeemed any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price was based on a multiple of earnings, subject to the terms of the acquisition agreement. In  May 2022, the Company purchased an additional 15% ownership interest in Captiva for $375, which was paid with cash on hand, bringing the Company's total ownership interest in Captiva to 66%. On  April 5, 2024, the Company acquired the remaining 34% ownership interest in Captiva for $9,117 of cash.

[0001437749-26-004568:notes:116]
The Pramac and Captiva redeemable noncontrolling interests were recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements of this Annual Report on Form 10-K. The following table presents the changes in the redeemable noncontrolling interest for Juffali, Captiva, and Pramac for the years presented:

[0001437749-26-004568:notes:117]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | - |  |  | $ | 6,549 |  |  | $ | 110,471 |  |
| Contribution received from noncontrolling interest holder |  |  | 979 |  |  |  | - |  |  |  | - |  |
| Share of net income (loss) |  |  | (236 | ) |  |  | 58 |  |  |  | 1,864 |  |
| Foreign currency translation rate change |  |  | (1 | ) |  |  | (176 | ) |  |  | (549 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | (9,117 | ) |  |  | (116,754 | ) |
| Redemption value adjustment |  |  | - |  |  |  | 2,686 |  |  |  | 11,517 |  |
| Balance at end of period |  | $ | 742 |  |  | $ | - |  |  | $ | 6,549 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-26-004568:notes:118]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-26-004568:notes:119]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in the Company’s consolidated statements of comprehensive income. The commodity and foreign currency forward contract gains and losses are not material to the Company’s consolidated financial statements for the periods presented.

[0001437749-26-004568:notes:120]
Additionally, the Company maintains interest rate swap agreements and owns stock warrants described in more detail below.

[0001437749-26-004568:notes:121]
Interest Rate Swaps

[0001437749-26-004568:notes:122]
In  March 2020, the Company entered into three interest rate swap agreements, which were still outstanding as of  December 31, 2025. In  July 2025, in conjunction with the amendments to the Company’s credit agreements discussed further in Note 12, “Credit Agreements,” to the consolidated financial statements of this Annual Report on Form 10-K, the Company modified its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive income (loss) in the consolidated balance sheets.

[0001437749-26-004568:notes:123]
The amount of after-tax unrealized losses recognized for the years ended  December 31, 2025, 2024 and 2023 were $12,863, $7,672, and $8,004, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-26-004568:notes:124]
See Item 7A “Quantitative and Qualitative Disclosures About Market Risk” of this Annual Report on Form 10-K for additional information on these interest rate swaps.

[0001437749-26-004568:notes:125]
Stock Warrants

[0001437749-26-004568:notes:126]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox to purchase 5% of its Class A common stock and acquire stock warrants, the latter of which provide the right to acquire incremental Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024 and the first, second, and fourth quarters of 2025, the Company received additional warrants under the anti-dilution protection rights in connection with additional rounds of funding performed by Wallbox. In accordance with U.S. GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:127]
The loss attributable to the stock warrants was $5,839 and $7,327 for the years ended  December 31, 2025 and 2024, respectively.

[0001437749-26-004568:notes:128]
Fair Value

[0001437749-26-004568:notes:129]
The following table presents the fair value of the Company’s derivatives:

[0001437749-26-004568:notes:130]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Interest rate swaps |  | $ | 11,272 |  |  | $ | 28,367 |  |
| Stock warrants |  |  | 2,080 |  |  |  | 7,919 |  |

[0001437749-26-004568:notes:131]
The fair value of the interest rate swaps is included in prepaid expenses and other assets in the consolidated balance sheet as of  December 31, 2025. The fair value of stock warrants is included in operating lease and other assets in the consolidated balance sheet as of  December 31, 2025. The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the consolidated balance sheet as of  December 31, 2024. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  December 31, 2025, and  December 31, 2024, is an asset of $11,604 and $29,254, respectively, which represents the net amount the Company would receive to exit all of the agreements on that date.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-26-004568:notes:132]
| 6. | Accumulated Other Comprehensive Income (Loss) |

[0001437749-26-004568:notes:133]
The following presents a tabular disclosure of changes in accumulated other comprehensive income (loss) during the years ended  December 31, 2025 and 2024, net of tax:

[0001437749-26-004568:notes:134]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2025 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |
| Current-period comprehensive income (loss) |  |  | 99,136 |  | (1) |  |  | (12,863 | ) | (2) |  |  | 86,273 |  |
| Ending Balance – December 31, 2025 |  | $ | (7,030 | ) |  |  | $ | 7,904 |  |  |  | $ | 874 |  |

[0001437749-26-004568:notes:135]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Current-period comprehensive loss |  |  | (62,584 | ) | (3) |  |  | (7,672 | ) | (4) |  |  | (70,256 | ) |
| Ending Balance – December 31, 2024 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |

[0001437749-26-004568:notes:136]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the year ended December 31, 2025, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized losses of $(17,095) on the interest rate swaps, net of tax effect of $4,232 for the year ended December 31, 2025. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2024, particularly the Euro, British Pound, and Mexican Peso. |

[0001437749-26-004568:notes:137]
|  | (4) | Represents unrealized losses of $(10,235) on the interest rate swaps, net of tax effect of $2,563 for the year ended December 31, 2024. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-26-004568:notes:138]
| 7. | Segment Reporting |

[0001437749-26-004568:notes:139]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and all historical acquisitions based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes all historical acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations. Intersegment sales are at an appropriate transfer price.

[0001437749-26-004568:notes:140]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-26-004568:notes:141]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,182,105 |  |  | $ | 84,807 |  |  | $ | 2,266,912 |  |
| Commercial & Industrial products |  |  | 863,762 |  |  |  | 593,623 |  |  |  | 1,457,385 |  |
| Other |  |  | 425,099 |  |  |  | 59,751 |  |  |  | 484,850 |  |
| Total net sales |  | $ | 3,470,966 |  |  | $ | 738,181 |  |  | $ | 4,209,147 |  |

[0001437749-26-004568:notes:142]
|  |  | Year Ended December 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,352,629 |  |  | $ | 80,845 |  |  | $ | 2,433,474 |  |
| Commercial & Industrial products |  |  | 828,586 |  |  |  | 560,883 |  |  |  | 1,389,469 |  |
| Other |  |  | 417,934 |  |  |  | 54,957 |  |  |  | 472,891 |  |
| Total net sales |  | $ | 3,599,149 |  |  | $ | 696,685 |  |  | $ | 4,295,834 |  |

[0001437749-26-004568:notes:143]
|  |  | Year Ended December 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,945,273 |  |  | $ | 117,656 |  |  | $ | 2,062,929 |  |
| Commercial & Industrial products |  |  | 916,118 |  |  |  | 578,681 |  |  |  | 1,494,799 |  |
| Other |  |  | 414,933 |  |  |  | 50,006 |  |  |  | 464,939 |  |
| Total net sales |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | 4,022,667 |  |

[0001437749-26-004568:notes:144]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold directly to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-26-004568:notes:145]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction (EPC) companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold directly to the end customer.  C&I also provides back-up power solutions for data centers including delivery of large backup power generators, project management, installation commissioning and training. The majority of C&I products' revenues are transferred to the customer at a point in time.

[0001437749-26-004568:notes:146]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain design, build, installation, and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-26-004568:notes:147]
The Company views Adjusted EBITDA as a key measure of the Company's performance. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements. The Company presents Adjusted EBITDA
    not only due to its importance for purposes of the Company's credit agreements, but also because it assists the Company in comparing performance across reporting periods on a consistent basis as it excludes items the Company's management does
    not believe are indicative of the Company's core operating performance. The Company's Chief Operating Decision Maker (CODM) is Aaron Jagdfeld, President and Chief Executive Officer (CEO). He uses Adjusted EBITDA, along with the Company's management:

[0001437749-26-004568:notes:148]
|  | ● | for planning purposes, including the preparation of the Company's annual operating budget and developing and refining internal projections for future periods; |

[0001437749-26-004568:notes:149]
|  | ● | to allocate resources to enhance the financial performance of the Company's business; |

[0001437749-26-004568:notes:150]
|  | ● | as a target for the determination of the bonus component of compensation for the Company's senior executives under the Company's management incentive plan, as described further in the Company's Proxy Statement; |

[0001437749-26-004568:notes:151]
|  | ● | to evaluate the effectiveness of the Company's business strategies and as a supplemental tool in evaluating the Company's performance against the Company's budget for each period; and |

[0001437749-26-004568:notes:152]
|  | ● | in communications with the Company's Board and investors concerning the Company's financial performance. |

[0001437749-26-004568:notes:153]
See "Non-GAAP measures - Adjusted EBITDA" in Item 7 of this Annual Report on Form 10-K for more information on the Company's use of Adjusted EBITDA. The table below presents total sales (external and intersegment), significant segment expenses, and Adjusted EBITDA by reportable segment, reconciled to consolidated income before provision for income taxes.

[0001437749-26-004568:notes:154]
|  |  | Year Ended December 31, 2025 |  |  | Year Ended December 31, 2024 |  |  | Year Ended December 31, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 3,470,966 |  |  | $ | 738,181 |  |  | $ | 4,209,147 |  |  | $ | 3,599,149 |  |  | $ | 696,685 |  |  | $ | 4,295,834 |  |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | 4,022,667 |  |
| Intersegment sales |  |  | 23,205 |  |  |  | 39,250 |  |  |  | 62,455 |  |  |  | 35,932 |  |  |  | 28,700 |  |  |  | 64,632 |  |  |  | 43,937 |  |  |  | 91,552 |  |  |  | 135,489 |  |
| Total sales |  |  | 3,494,171 |  |  |  | 777,431 |  |  |  | 4,271,602 |  |  |  | 3,635,081 |  |  |  | 725,385 |  |  |  | 4,360,466 |  |  |  | 3,320,261 |  |  |  | 837,895 |  |  |  | 4,158,156 |  |
| Elimination of intersegment sales |  |  | - |  |  |  | - |  |  |  | (62,455 | ) |  |  | - |  |  |  | - |  |  |  | (64,632 | ) |  |  | - |  |  |  | - |  |  |  | (135,489 | ) |
| Costs of goods sold |  |  | 2,095,406 |  |  |  | 564,459 |  |  |  | 2,659,865 |  |  |  | 2,155,269 |  |  |  | 539,571 |  |  |  | 2,694,840 |  |  |  | 2,168,210 |  |  |  | 624,515 |  |  |  | 2,792,725 |  |
| Elimination of intersegment cost of goods sold |  |  | - |  |  |  | - |  |  |  | (62,455 | ) |  |  | - |  |  |  | - |  |  |  | (64,632 | ) |  |  | - |  |  |  | - |  |  |  | (135,489 | ) |
| Operating expenses |  |  | 1,175,856 |  |  |  | 146,690 |  |  |  | 1,322,546 |  |  |  | 991,042 |  |  |  | 137,842 |  |  |  | 1,128,884 |  |  |  | 839,827 |  |  |  | 139,405 |  |  |  | 979,232 |  |
| Other segment items (1) |  |  | (375,006 | ) |  |  | (51,345 | ) |  |  | (426,351 | ) |  |  | (204,433 | ) |  |  | (47,926 | ) |  |  | (252,359 | ) |  |  | (211,113 | ) |  |  | (40,547 | ) |  |  | (251,660 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 597,915 |  |  | $ | 117,627 |  |  | $ | 715,542 |  |  | $ | 693,203 |  |  | $ | 95,898 |  |  | $ | 789,101 |  |  | $ | 523,337 |  |  | $ | 114,522 |  |  | $ | 637,859 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (70,697 | ) |  |  |  |  |  |  |  |  |  |  | (89,713 | ) |  |  |  |  |  |  |  |  |  |  | (97,627 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (194,835 | ) |  |  |  |  |  |  |  |  |  |  | (171,768 | ) |  |  |  |  |  |  |  |  |  |  | (166,602 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (6,636 | ) |  |  |  |  |  |  |  |  |  |  | (4,757 | ) |  |  |  |  |  |  |  |  |  |  | 5,953 |  |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (49,947 | ) |  |  |  |  |  |  |  |  |  |  | (49,248 | ) |  |  |  |  |  |  |  |  |  |  | (35,492 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (3,976 | ) |  |  |  |  |  |  |  |  |  |  | (5,097 | ) |  |  |  |  |  |  |  |  |  |  | (4,054 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (7,301 | ) |  |  |  |  |  |  |  |  |  |  | (4,752 | ) |  |  |  |  |  |  |  |  |  |  | (10,551 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  | (157,981 | ) |  |  |  |  |  |  |  |  |  |  | (10,931 | ) |  |  |  |  |  |  |  |  |  |  | (38,490 | ) |
| Change in fair value of investments (7) |  |  |  |  |  |  |  |  |  |  | (20,610 | ) |  |  |  |  |  |  |  |  |  |  | (38,006 | ) |  |  |  |  |  |  |  |  |  |  | - |  |
| Loss on refinancing of debt (8) |  |  |  |  |  |  |  |  |  |  | (1,225 | ) |  |  |  |  |  |  |  |  |  |  | (4,861 | ) |  |  |  |  |  |  |  |  |  |  | - |  |
| Other |  |  |  |  |  |  |  |  |  |  | (3,274 | ) |  |  |  |  |  |  |  |  |  |  | (530 | ) |  |  |  |  |  |  |  |  |  |  | (696 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 199,060 |  |  |  |  |  |  |  |  |  |  | $ | 409,438 |  |  |  |  |  |  |  |  |  |  | $ | 290,300 |  |

[0001437749-26-004568:notes:155]
|  | (1) | Other segment items primarily represent adjustments for depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; Provision for legal, regulatory, and other costs. |
|  | (2) | Includes gains/(losses) on the disposition of assets other than in the ordinary course of business, gains/(losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-26-004568:notes:156]
|  | (3) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-26-004568:notes:157]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's credit agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |

[0001437749-26-004568:notes:158]
|  | (6) | Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations: • Legal expenses, judgments, and settlements related to certain patent lawsuits - $7,520 in 2025; $9,299 in 2024; $27,289 in 2023. • Legal expenses and settlements related to certain class action lawsuits - $22,698 in 2025, which includes a $15,000 provision for a multi-district class action settlement related to clean energy products; $1,267 in 2024; $1,051 in 2023. • Legal expenses related to certain government inquiries and other significant matters - $7,630 in 2025. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 and $4,350 in 2024 and 2023, respectively. • A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in 2023. • A provision of $104,500, net in the fourth quarter of 2025 for a settlement agreement (in principle) related to a certain portable generator product liability case deemed outside the ordinary course of routine litigation for the Company. • A $15,633 net inventory provision in the fourth quarter of 2025 related to the settlement of a contract dispute with a supplier for a discontinued product. |

[0001437749-26-004568:notes:159]
|  | (7) | Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (8) | For the year ended December 31, 2025, the loss represents third party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Original Tranche A Term Loan Facility and Original Revolving Facility. For the year ended December 31, 2024, the loss represents fees paid to creditors and the write-off of the original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility. |

[0001437749-26-004568:notes:160]
The following tables summarize additional financial information by reportable segment:

[0001437749-26-004568:notes:161]
|  |  | Assets |  |
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 4,186,567 |  |  | $ | 3,873,904 |  |  | $ | 3,770,883 |  |
| International |  |  | 1,387,112 |  |  |  | 1,235,427 |  |  |  | 1,322,429 |  |
| Total |  | $ | 5,573,679 |  |  | $ | 5,109,331 |  |  | $ | 5,093,312 |  |

[0001437749-26-004568:notes:162]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 158,999 |  |  | $ | 135,434 |  |  | $ | 129,648 |  |
| International |  |  | 35,836 |  |  |  | 36,334 |  |  |  | 36,954 |  |
| Total |  | $ | 194,835 |  |  | $ | 171,768 |  |  | $ | 166,602 |  |

[0001437749-26-004568:notes:163]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 143,056 |  |  | $ | 117,836 |  |  | $ | 103,036 |  |
| International |  |  | 26,794 |  |  |  | 18,897 |  |  |  | 26,024 |  |
| Total |  | $ | 169,850 |  |  | $ | 136,733 |  |  | $ | 129,060 |  |

[0001437749-26-004568:notes:164]
The Company’s sales in the United States represent approximately 78%, 79%, and 77% of total sales for the years ended  December 31, 2025, 2024 and 2023, respectively. Approximately 74% and 76% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2025 and 2024, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-26-004568:notes:165]
| 8. | Balance Sheet Details |

[0001437749-26-004568:notes:166]
Inventories consist of the following:

[0001437749-26-004568:notes:167]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Raw material |  | $ | 705,610 |  |  | $ | 611,735 |  |
| Work-in-process |  |  | 12,592 |  |  |  | 6,814 |  |
| Finished goods |  |  | 530,665 |  |  |  | 413,098 |  |
| Total |  | $ | 1,248,867 |  |  | $ | 1,031,647 |  |

[0001437749-26-004568:notes:168]
Property and equipment consists of the following:

[0001437749-26-004568:notes:169]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Land and improvements |  | $ | 31,937 |  |  | $ | 30,220 |  |
| Buildings and improvements |  |  | 444,171 |  |  |  | 358,055 |  |
| Machinery and equipment |  |  | 374,791 |  |  |  | 296,409 |  |
| Dies and tools |  |  | 63,666 |  |  |  | 48,681 |  |
| Vehicles |  |  | 19,743 |  |  |  | 13,887 |  |
| Office & information technology equipment and internal use software |  |  | 252,425 |  |  |  | 213,003 |  |
| Leasehold improvements |  |  | 10,670 |  |  |  | 9,776 |  |
| Construction in progress |  |  | 86,116 |  |  |  | 110,651 |  |
| Gross property and equipment |  |  | 1,283,519 |  |  |  | 1,080,682 |  |
| Accumulated depreciation |  |  | (469,914 | ) |  |  | (390,659 | ) |
| Total |  | $ | 813,605 |  |  | $ | 690,023 |  |

[0001437749-26-004568:notes:170]
Total property and equipment included finance leases of $83,963 and $61,214 as of  December 31, 2025 and 2024, respectively, primarily comprised of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statements of cash flows. Similarly, the buyout of finance lease obligations is accounted for as a non-cash exchange of the ROU asset for the underlying leased asset. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases.

[0001437749-26-004568:notes:171]
Other accrued liabilities consist of the following:

[0001437749-26-004568:notes:172]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Accrued selling expenses |  | $ | 118,962 |  |  | $ | 105,627 |  |
| Current contract liabilities |  |  | 153,745 |  |  |  | 113,899 |  |
| Accrued legal & professional fees |  |  | 248,445 |  |  |  | 27,237 |  |
| Operating lease liabilities |  |  | 15,731 |  |  |  | 29,316 |  |
| Accrued other |  |  | 54,504 |  |  |  | 37,321 |  |
| Total |  | $ | 591,387 |  |  | $ | 313,401 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-26-004568:notes:173]
| 9. | Goodwill and Intangible Assets |

[0001437749-26-004568:notes:174]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2025 and 2024 are as follows:

[0001437749-26-004568:notes:175]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance as of December 31, 2023 |  | $ | 1,018,528 |  |  | $ | 413,856 |  |  | $ | 1,432,384 |  |
| Acquisitions of businesses, net |  |  | 22,641 |  |  |  | - |  |  |  | 22,641 |  |
| Foreign currency translation rate changes |  |  | (22 | ) |  |  | (18,742 | ) |  |  | (18,764 | ) |
| Balance as of December 31, 2024 |  |  | 1,041,147 |  |  |  | 395,114 |  |  |  | 1,436,261 |  |
| Purchase accounting adjustments |  |  | (6,182 | ) |  |  | 310 |  |  |  | (5,872 | ) |
| Foreign currency translation rate changes |  |  | 112 |  |  |  | 36,593 |  |  |  | 36,705 |  |
| Balance as of December 31, 2025 |  | $ | 1,035,077 |  |  | $ | 432,017 |  |  | $ | 1,467,094 |  |

[0001437749-26-004568:notes:176]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the Company’s acquisitions.

[0001437749-26-004568:notes:177]
Goodwill applicable to each reportable segment as of  December 31, 2025 and 2024 is as follows:

[0001437749-26-004568:notes:178]
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,538,270 |  |  | $ | (503,193 | ) |  | $ | 1,035,077 |  |  | $ | 1,544,340 |  |  | $ | (503,193 | ) |  | $ | 1,041,147 |  |
| International |  |  | 436,628 |  |  |  | (4,611 | ) |  |  | 432,017 |  |  |  | 399,725 |  |  |  | (4,611 | ) |  |  | 395,114 |  |
| Total |  | $ | 1,974,898 |  |  | $ | (507,804 | ) |  | $ | 1,467,094 |  |  | $ | 1,944,065 |  |  | $ | (507,804 | ) |  | $ | 1,436,261 |  |

[0001437749-26-004568:notes:179]
The following table summarizes intangible assets by major category as of  December 31, 2025 and 2024:

[0001437749-26-004568:notes:180]
|  |  |  |  |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
|  |  | Weighted Average Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 15 |  |  | $ | 162,098 |  |  | $ | (89,942 | ) |  | $ | 72,156 |  |  | $ | 160,473 |  |  | $ | (81,083 | ) |  | $ | 79,390 |  |
| Customer lists |  |  | 13 |  |  |  | 602,526 |  |  |  | (475,009 | ) |  |  | 127,517 |  |  |  | 591,745 |  |  |  | (439,008 | ) |  |  | 152,737 |  |
| Patents and technology |  |  | 14 |  |  |  | 678,953 |  |  |  | (340,645 | ) |  |  | 338,308 |  |  |  | 673,425 |  |  |  | (294,330 | ) |  |  | 379,095 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 5 |  |  |  | 76,568 |  |  |  | (66,557 | ) |  |  | 10,011 |  |  |  | 76,251 |  |  |  | (56,225 | ) |  |  | 20,026 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 1,521,191 |  |  | $ | (973,199 | ) |  | $ | 547,992 |  |  | $ | 1,502,940 |  |  | $ | (871,692 | ) |  | $ | 631,248 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 127,274 |  |  |  | - |  |  |  | 127,274 |  |  |  | 127,274 |  |  |  | - |  |  |  | 127,274 |  |
| Total intangible assets |  |  |  |  |  | $ | 1,648,465 |  |  | $ | (973,199 | ) |  | $ | 675,266 |  |  | $ | 1,630,214 |  |  | $ | (871,692 | ) |  | $ | 758,522 |  |

[0001437749-26-004568:notes:181]
Amortization expense of intangible assets was $101,507, $97,743, and $104,194 in 2025, 2024 and 2023, respectively. Excluding the impact of future acquisitions or divestitures, the Company estimates amortization expense for the next five years to be as follows: 2026 - $103,153; 2027 - $58,853; 2028 - $53,033; 2029 - $48,024; 2030 - $43,998.


## gnrc:LesseeOperatingLeasesAndFinanceLeasesTextBlock

[0001437749-26-004568:notes:182]
| 10. | Leases |

[0001437749-26-004568:notes:183]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to approximately 15 years, of which certain leases, primarily within the buildings and improvements asset class, include further options to extend for up to 5 additional years.

[0001437749-26-004568:notes:184]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (ROU) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit interest rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-26-004568:notes:185]
The Company has lease agreements with both lease and non-lease components, which it elected to account for as a single lease component. In addition, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-26-004568:notes:186]
The Company is a lessor of certain of its C&I mobile products as part of a rental fleet, as well as one of its buildings that it leases to a third party. The lease income related to these arrangements is not material to the consolidated financial statements.

[0001437749-26-004568:notes:187]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:188]
The components of total lease cost consist of the following:

[0001437749-26-004568:notes:189]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Operating lease cost |  | $ | 28,644 |  |  | $ | 46,887 |  |  | $ | 38,980 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 11,160 |  |  |  | 7,639 |  |  |  | 4,142 |  |
| Interest on lease liabilities |  |  | 5,374 |  |  |  | 5,323 |  |  |  | 2,540 |  |
| Total lease cost |  | $ | 45,178 |  |  | $ | 59,849 |  |  | $ | 45,662 |  |

[0001437749-26-004568:notes:190]
Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-26-004568:notes:191]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating leases: |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 51,253 |  |  | $ | 57,999 |  |
| Operating lease liabilities - current (2) |  | $ | 15,731 |  |  | $ | 29,316 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 36,150 |  |  |  | 29,173 |  |
| Total operating lease liabilities |  | $ | 51,881 |  |  | $ | 58,489 |  |
| Finance leases: |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 110,291 |  |  | $ | 78,801 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (26,328 | ) |  |  | (17,587 | ) |
| Finance lease ROU assets, net (4) |  | $ | 83,963 |  |  | $ | 61,214 |  |
| Finance lease liabilities - current (5) |  | $ | 9,463 |  |  | $ | 6,845 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 81,452 |  |  |  | 59,510 |  |
| Total finance lease liabilities |  | $ | 90,915 |  |  | $ | 66,355 |  |

[0001437749-26-004568:notes:192]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-26-004568:notes:193]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-26-004568:notes:194]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-26-004568:notes:195]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-26-004568:notes:196]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-26-004568:notes:197]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-26-004568:notes:198]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-26-004568:notes:199]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flows - operating leases |  | $ | 27,880 |  |  | $ | 48,089 |  |  | $ | 39,073 |  |
| Operating cash flows - finance leases |  |  | 5,347 |  |  |  | 4,924 |  |  |  | 2,409 |  |
| Financing cash flows - finance leases |  |  | 14,351 |  |  |  | 45,906 |  |  |  | 3,618 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 26,350 |  |  |  | 41,389 |  |  |  | 17,830 |  |
| Finance leases |  |  | 36,433 |  |  |  | 43,799 |  |  |  | 47,715 |  |

[0001437749-26-004568:notes:200]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2025 and 2024 is as follows:

[0001437749-26-004568:notes:201]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 5.66 |  |  |  | 4.27 |  |
| Finance Leases |  |  | 9.58 |  |  |  | 8.92 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 6.18 | % |  |  | 6.03 | % |
| Finance Leases |  |  | 6.57 | % |  |  | 7.03 | % |

[0001437749-26-004568:notes:202]
The maturities of the Company’s lease liabilities as of  December 31, 2025, are as follows:

[0001437749-26-004568:notes:203]
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2026 |  | $ | 15,040 |  |  | $ | 18,064 |  |
| 2027 |  |  | 14,532 |  |  |  | 11,630 |  |
| 2028 |  |  | 13,355 |  |  |  | 8,561 |  |
| 2029 |  |  | 11,606 |  |  |  | 6,040 |  |
| 2030 |  |  | 10,574 |  |  |  | 4,626 |  |
| After 2030 |  |  | 60,117 |  |  |  | 13,556 |  |
| Total minimum lease payments |  |  | 125,224 |  |  |  | 62,477 |  |
| Interest component |  |  | (34,309 | ) |  |  | (10,596 | ) |
| Present value of minimum lease payments |  | $ | 90,915 |  |  | $ | 51,881 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-26-004568:notes:204]
| 11. | Product Warranty Obligations |

[0001437749-26-004568:notes:205]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the related product to a customer based on historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-26-004568:notes:206]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 110,987 |  |  | $ | 116,408 |  |  | $ | 138,011 |  |
| Payments |  |  | (86,448 | ) |  |  | (88,990 | ) |  |  | (92,200 | ) |
| Provision for warranty issued |  |  | 100,589 |  |  |  | 77,802 |  |  |  | 67,104 |  |
| Changes in estimates for pre-existing warranties |  |  | 6,794 |  |  |  | 5,767 |  |  |  | 3,493 |  |
| Balance at end of period |  | $ | 131,922 |  |  | $ | 110,987 |  |  | $ | 116,408 |  |

[0001437749-26-004568:notes:207]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-26-004568:notes:208]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 186,922 |  |  | $ | 155,870 |  |  | $ | 132,813 |  |
| Deferred revenue contracts issued |  |  | 67,598 |  |  |  | 60,651 |  |  |  | 48,107 |  |
| Amortization of deferred revenue contracts |  |  | (35,116 | ) |  |  | (29,599 | ) |  |  | (25,050 | ) |
| Balance at end of period |  | $ | 219,404 |  |  | $ | 186,922 |  |  | $ | 155,870 |  |

[0001437749-26-004568:notes:209]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  December 31, 2025 is as follows:

[0001437749-26-004568:notes:210]
| 2026 |  | $ | 38,958 |  |
| 2027 |  |  | 41,161 |  |
| 2028 |  |  | 37,912 |  |
| 2029 |  |  | 31,155 |  |
| 2030 |  |  | 24,050 |  |
| After 2030 |  |  | 46,168 |  |
| Total |  | $ | 219,404 |  |

[0001437749-26-004568:notes:211]
The Company has a post-sale extended warranty marketing agreement with a third party, pursuant to which the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts the provider sells, which it classifies as costs to obtain a contract. These fees are deferred and recorded in the consolidated balance sheets as prepaid expenses and other assets when cost will be recognized in less than twelve months and operating lease and other assets when cost will be recognized in more than twelve months. These deferred costs are then amortized to cost of goods sold in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. Deferred contract costs as of  December 31, 2025 and 2024 were $24,313 and $17,140, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2025, 2024 and 2023 was $3,824, $2,958, and $2,306, respectively.

[0001437749-26-004568:notes:212]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-26-004568:notes:213]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Product warranty liability: |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 44,716 |  |  | $ | 56,127 |  |
| Long-term portion - other long-term liabilities |  |  | 87,206 |  |  |  | 54,860 |  |
| Total |  | $ | 131,922 |  |  | $ | 110,987 |  |
| Deferred revenue related to extended warranties: |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 38,958 |  |  | $ | 34,069 |  |
| Long-term portion - Deferred revenue |  |  | 180,446 |  |  |  | 152,853 |  |
| Total |  | $ | 219,404 |  |  | $ | 186,922 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-26-004568:notes:214]
| 12. | Credit Agreements |

[0001437749-26-004568:notes:215]
Short-term borrowings included in the consolidated balance sheets as of  December 31, 2025, and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $50,618 and $55,848, respectively. As of  December 31, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.67% and 5.44%, respectively.

[0001437749-26-004568:notes:216]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-26-004568:notes:217]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 493,750 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,673 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 90,915 |  |  |  | 66,355 |  |
| Other |  |  | 3,456 |  |  |  | 8,972 |  |
| Total |  |  | 1,282,448 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 12,729 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,463 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,260,256 |  |  | $ | 1,210,776 |  |

[0001437749-26-004568:notes:218]
As of  December 31, 2025, there were $4,987 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the consolidated balance sheets, and $5,673 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the consolidated balance sheets.

[0001437749-26-004568:notes:219]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.

[0001437749-26-004568:notes:220]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan that is available on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B facility of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 5.62% combined rate as of 
      December 31, 2025
     .

[0001437749-26-004568:notes:221]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company's net secured leverage ratio is maintained below 3.75 to 1.00. As of 
      December 31, 2025
     , the Company's net secured leverage ratio was 1.32 to 1.00, and the Company was in compliance with all covenants under the facility. There are no financial maintenance covenants on the Term Loan B Facility.

[0001437749-26-004568:notes:222]
The Company's original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-26-004568:notes:223]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Original Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%. Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements. As of  December 31, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 5.12%
     .

[0001437749-26-004568:notes:224]
In accordance with ASC 470-50, the Company capitalized $5,275 of debt issuance costs related to this credit agreement amendment transaction. Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of $443 and expensed $782 of third-party fees as a loss on refinancing of debt.

[0001437749-26-004568:notes:225]
Both the New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  
       December 31, 2025
      , the Company’s total leverage ratio was 1.39 to 1.00, and the Company's interest coverage ratio was 11.76 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of 
       December 31, 2025
      .

[0001437749-26-004568:notes:226]
The New Term Loan B Facility, New Tranche A Term Loan Facility and New Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-26-004568:notes:227]
As of 
       December 31, 2025
      , there was $0 outstanding under the New Revolving Facility, leaving $999,250 of unused capacity, net of outstanding letters of credit.

[0001437749-26-004568:notes:228]
﻿The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030. The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on 
       December 31, 2025
      , before considering original issue discount and deferred financing costs, were as follows:

[0001437749-26-004568:notes:229]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2026 |  | $ | 4,375 |  |  | $ | 5,000 |  |  | $ | - |  |  | $ | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 600,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 493,750 |  |  | $ | - |  |  | $ | 1,193,750 |  |


## us-gaap:TreasuryStockTextBlock

[0001437749-26-004568:notes:230]
| 13. | Stock Repurchase Programs |

[0001437749-26-004568:notes:231]
In  July 2022, the Company's Board approved a stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board approved a new stock repurchase program that authorized repurchases of up to $500,000 of the Company’s common stock over the following 24 months. The new program replaced the prior share repurchase program, which had $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-26-004568:notes:232]
During the year ended  December 31, 2025, the Company repurchased 1,109,206 shares of its common stock for $147,917. During the year ended  December 31, 2024, the Company repurchased 1,046,351 shares of its common stock for $152,743. During the year ended  December 31, 2023, the Company repurchased 2,188,475 shares of its common stock for $251,513. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-26-004568:notes:233]
On  February 9, 2026, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the next twenty-four months. Refer to Note 20, "Subsequent Events", to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the new stock repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001437749-26-004568:notes:234]
| 14. | Earnings Per Share |

[0001437749-26-004568:notes:235]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain conditions related to acquisition contingent consideration as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-26-004568:notes:236]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-26-004568:notes:237]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,554 |  |  | $ | 316,315 |  |  | $ | 214,606 |  |
| Redemption value adjustment |  |  | - |  |  |  | 8,941 |  |  |  | (11,517 | ) |
| Net income attributable to common shareholders |  | $ | 159,554 |  |  | $ | 325,256 |  |  | $ | 203,089 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 58,523,642 |  |  |  | 59,559,797 |  |  |  | 61,265,060 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 742,061 |  |  |  | 790,615 |  |  |  | 793,327 |  |
| Dilutive effect of contingently issued shares |  |  | 10,078 |  |  |  | - |  |  |  | - |  |
| Weighted average shares, diluted |  |  | 59,275,781 |  |  |  | 60,350,412 |  |  |  | 62,058,387 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.73 |  |  | $ | 5.46 |  |  | $ | 3.31 |  |
| Diluted |  | $ | 2.69 |  |  | $ | 5.39 |  |  | $ | 3.27 |  |

[0001437749-26-004568:notes:238]
|  | (1) | For the years ended December 31, 2025, December 31, 2024, and December 31, 2023, excludes approximately 300,000, 428,000 and 348,000 stock options and restricted stock awards, respectively, as the impact of such awards was anti-dilutive. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-26-004568:notes:239]
| 15. | Income Taxes |

[0001437749-26-004568:notes:240]
The Company’s provision for income taxes consists of the following:

[0001437749-26-004568:notes:241]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Income (Loss) from continuing operations before income tax expense (benefit) |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Federal |  | $ | 137,475 |  |  | $ | 369,150 |  |  | $ | 218,371 |  |
| Foreign |  |  | 61,585 |  |  |  | 40,288 |  |  |  | 71,929 |  |
| Total |  | $ | 199,060 |  |  | $ | 409,438 |  |  | $ | 290,300 |  |
| Income tax expense / (benefit) from continuing operations |  |  |  |  |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 10,045 |  |  | $ | 117,749 |  |  | $ | 71,741 |  |
| State |  |  | (2,825 | ) |  |  | 20,970 |  |  |  | 13,802 |  |
| Foreign |  |  | 15,406 |  |  |  | 14,356 |  |  |  | 22,115 |  |
| Total current tax expense |  |  | 22,626 |  |  |  | 153,075 |  |  |  | 107,658 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 17,913 |  |  |  | (46,526 | ) |  |  | (26,504 | ) |
| State |  |  | 3,109 |  |  |  | (8,613 | ) |  |  | (5,254 | ) |
| Foreign |  |  | (7,255 | ) |  |  | (5,565 | ) |  |  | (3,218 | ) |
| Total deferred tax expense (benefit) |  |  | 13,767 |  |  |  | (60,704 | ) |  |  | (34,976 | ) |
| Total income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 27,958 |  |  |  | 71,223 |  |  |  | 45,237 |  |
| State and local |  |  | 284 |  |  |  | 12,357 |  |  |  | 8,548 |  |
| Foreign |  |  | 8,151 |  |  |  | 8,791 |  |  |  | 18,897 |  |
| Total income tax expense |  |  | 36,393 |  |  |  | 92,371 |  |  |  | 72,682 |  |
| Change in valuation allowance |  |  | 1,313 |  |  |  | 89 |  |  |  | 498 |  |
| Provision for income taxes |  | $ | 37,706 |  |  | $ | 92,460 |  |  | $ | 73,180 |  |

[0001437749-26-004568:notes:242]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2025, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2021. For Wisconsin state income taxes, the statute of limitation is generally four years from the date the tax return is filed, unless the Company carries over certain tax attributes that were generated in prior years (e.g., net operating losses and R&D credits), then the state  may also review those years to validate the tax attributes.  The Company has utilized net operating losses or R&D credits on their state income tax returns since 2007.   In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2014 through 2024.

[0001437749-26-004568:notes:243]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made and could impact the Company’s financial results.

[0001437749-26-004568:notes:244]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-26-004568:notes:245]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 54,731 |  |  | $ | 52,351 |  |
| Deferred revenue |  |  | 39,679 |  |  |  | 43,261 |  |
| Inventories |  |  | 17,853 |  |  |  | 14,103 |  |
| Stock-based compensation |  |  | 8,633 |  |  |  | 16,959 |  |
| Operating loss and credit carryforwards |  |  | 55,585 |  |  |  | 50,327 |  |
| Debt refinancing costs |  |  | 446 |  |  |  | - |  |
| Bad debt |  |  | 1,218 |  |  |  | 1,803 |  |
| Other |  |  | 12,829 |  |  |  | 13,031 |  |
| Capitalized R&D |  |  | 30,605 |  |  |  | 98,323 |  |
| Prepaid expenses |  |  | 1,268 |  |  |  | - |  |
| Valuation allowance |  |  | (6,538 | ) |  |  | (5,225 | ) |
| Total deferred tax assets |  |  | 216,309 |  |  |  | 284,933 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 183,106 |  |  |  | 234,271 |  |
| Depreciation |  |  | 52,001 |  |  |  | 49,935 |  |
| Interest Swap, Derivative |  |  | 166 |  |  |  | 6,496 |  |
| Prepaid expenses |  |  | - |  |  |  | 3,284 |  |
| Total deferred tax liabilities |  |  | 235,273 |  |  |  | 293,986 |  |
| Net deferred tax liabilities |  | $ | (18,964 | ) |  | $ | (9,053 | ) |

[0001437749-26-004568:notes:246]
As of  December 31, 2025 and 2024, deferred tax assets of $41,949 and $24,132, and deferred tax liabilities of $60,913 and $33,185, respectively, were reflected in the consolidated balance sheets.

[0001437749-26-004568:notes:247]
The Company maintains a $6,538 valuation allowance against the deferred tax assets primarily related to certain tax loss carryforwards which  may not be realized. Realization of the deferred income tax asset related to the tax loss carryforward is dependent upon generating sufficient taxable income in these jurisdictions prior to their expiration. During 2025, the valuation allowance increased by $1,313 on our deferred tax assets where we believe the tax asset  may not be fully utilized.

[0001437749-26-004568:notes:248]
At  December 31, 2025, the Company had tax loss carryforwards of approximately $197,981, which have varying expiration periods ranging from 2025 to indefinite. For carryforward amounts which the Company believes the losses will expire prior to use, a valuation allowance has been established. For all other carryforwards, the Company believes it will generate sufficient taxable income in these jurisdictions to utilize its loss carryforwards prior to their expiration.

[0001437749-26-004568:notes:249]
At  December 31, 2025, the Company had state manufacturing investment tax credit carryforwards of approximately $31,871, which expire between 2028 and 2040. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-26-004568:notes:250]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-26-004568:notes:251]
|  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 11,178 |  |  | $ | 9,703 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 745 |  |  |  | 1,068 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 1,402 |  |  |  | 943 |  |
| Statute of limitation expirations |  |  | (721 | ) |  |  | (536 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 12,604 |  |  | $ | 11,178 |  |

[0001437749-26-004568:notes:252]
The unrecognized tax benefit as of  December 31, 2025 and 2024, if recognized, would favorably impact the effective tax rate.

[0001437749-26-004568:notes:253]
As of  December 31, 2025 and 2024, total accrued interest of approximately $1,736 and $1,142, respectively, and accrued penalties of approximately $1,080 and $954, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-26-004568:notes:254]
The Company does not expect a significant change to the total amount of unrecognized tax benefits during the fiscal year ending  December 31, 2026.

[0001437749-26-004568:notes:255]
A reconciliation of the U.S. federal statutory tax rate to the effective tax rate for the years ended  December 31, 2025, 2024 and 2023 is as follows:

[0001437749-26-004568:notes:256]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Earnings from continuing operations, before income tax expense |  | $ | 199,060 |  |  |  |  |  |  | $ | 409,438 |  |  |  |  |  |  | $ | 290,300 |  |  |  |  |  |
| Tax provision at the U.S. federal statutory rate |  | $ | 41,803 |  |  |  | 21.0 | % |  | $ | 85,982 |  |  |  | 21.0 | % |  | $ | 60,963 |  |  |  | 21.0 | % |
| Federal |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Effect of cross-border tax laws |  |  | (1,857 | ) |  |  | -0.9 | % |  |  | (974 | ) |  |  | -0.2 | % |  |  | 4,180 |  |  |  | 1.4 | % |
| Tax Credits |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and Development Credit |  |  | (7,252 | ) |  |  | -3.6 | % |  |  | (5,533 | ) |  |  | -1.4 | % |  |  | (7,361 | ) |  |  | -2.5 | % |
| Other Credits |  |  | (310 | ) |  |  | -0.2 | % |  |  | (485 | ) |  |  | -0.1 | % |  |  | (1,403 | ) |  |  | -0.5 | % |
| Changes in valuation allowances |  |  | - |  |  |  | 0.0 | % |  |  | - |  |  |  | 0.0 | % |  |  | - |  |  |  | 0.0 | % |
| Nontaxable or nondeductible items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense (benefit) |  |  | 7,584 |  |  |  | 3.8 | % |  |  | (4,720 | ) |  |  | -1.2 | % |  |  | (1,102 | ) |  |  | -0.4 | % |
| Nondeductible U.S. compensation expense |  |  | 1,003 |  |  |  | 0.5 | % |  |  | 4,369 |  |  |  | 1.1 | % |  |  | 3,648 |  |  |  | 1.3 | % |
| Worthless Stock Deduction |  |  | (6,463 | ) |  |  | -3.2 | % |  |  | - |  |  |  | 0.0 | % |  |  | - |  |  |  | 0.0 | % |
| Effect of changes in tax laws or rates enacted in current period |  |  | - |  |  |  | 0.0 | % |  |  | - |  |  |  | 0.0 | % |  |  | - |  |  |  | 0.0 | % |
| Other |  |  | 870 |  |  |  | 0.4 | % |  |  | (2,279 | ) |  |  | -0.6 | % |  |  | 3,350 |  |  |  | 1.2 | % |
| Foreign Tax Effects |  |  | (1,329 | ) |  |  | -0.7 | % |  |  | 2,683 |  |  |  | 0.7 | % |  |  | 1,288 |  |  |  | 0.4 | % |
| State and local income tax, net of federal income tax benefit (1) |  |  | 1,837 |  |  |  | 0.9 | % |  |  | 11,452 |  |  |  | 2.8 | % |  |  | 7,151 |  |  |  | 2.5 | % |
| Changes in unrecognized tax benefits |  |  | 1,820 |  |  |  | 0.9 | % |  |  | 1,965 |  |  |  | 0.5 | % |  |  | 2,466 |  |  |  | 0.8 | % |
| Income tax expense |  | $ | 37,706 |  |  |  | 18.9 | % |  | $ | 92,460 |  |  |  | 22.6 | % |  | $ | 73,180 |  |  |  | 25.2 | % |

[0001437749-26-004568:notes:257]
| (1) | During the year ended December 31, 2025, state taxes and credits in South Carolina, Wisconsin, California, Illinois, Pennsylvania, New York, Georgia, Michigan, New Jersey, Florida, Massachusetts, Texas, Indiana, Maine, Connecticut comprised greater than 50% of the tax effect in this category. |

[0001437749-26-004568:notes:258]
Income taxes paid are as follows:

[0001437749-26-004568:notes:259]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| U.S Federal |  | $ | 58,803 |  |  | $ | 113,496 |  |  | $ | 32,886 |  |
| Total U.S. State and Local |  |  | 15,132 |  |  |  | 17,973 |  |  |  | 12,003 |  |
| United Kingdom (1) |  |  | 8,731 |  |  |  | - |  |  |  | 5,951 |  |
| Canada (2) |  |  | - |  |  |  | - |  |  |  | 36,560 |  |
| Other |  |  | 6,749 |  |  |  | 17,359 |  |  |  | 12,682 |  |
| Total Foreign |  |  | 15,480 |  |  |  | 17,359 |  |  |  | 55,193 |  |
| Total income taxes paid, net |  | $ | 89,415 |  |  | $ | 148,828 |  |  | $ | 100,082 |  |

[0001437749-26-004568:notes:260]
| (1) | The amount of income taxes paid during the year ended December 31, 2024 does not meet the 5% disaggregation threshold. |
| (2) | The amount of income taxes paid during the years ended December 31, 2025 and 2024 does not meet the 5% disaggregation threshold. |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-26-004568:notes:261]
| 16. | Benefit Plans |

[0001437749-26-004568:notes:262]
Medical and Dental Plans

[0001437749-26-004568:notes:263]
The Company maintains medical and dental benefit plans covering its full-time U.S. employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $33,163, $32,964, and $26,090 for the years ended  December 31, 2025, 2024 and 2023, respectively.

[0001437749-26-004568:notes:264]
Employees of the Company’s foreign subsidiaries participate in government sponsored medical benefit plans and other local plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-26-004568:notes:265]
Savings Plan

[0001437749-26-004568:notes:266]
The Company maintains a defined-contribution 401(k) savings plan for eligible U.S. employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 8% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008, that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures of unvested company contributions  may be applied against plan expenses and future Company contributions. The Company recognized $9,316, $7,779, and $3,735 of expense related to these plans for the years ended  December 31, 2025, 2024 and 2023, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-26-004568:notes:267]
| 17. | Share Plans |

[0001437749-26-004568:notes:268]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010, in connection with its initial public offering. The 2010 Plan, as amended, allowed for the grant of up to 9.1 million share-based awards to executives, directors, and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. New grants under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the 2010 Plan, net of estimated forfeitures, was $0, $0, and $309 for the years ended  December 31, 2025, 2024 and 2023, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:269]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). The 2019 Plan allows for the grant of up to 2.7 million share-based awards to executives, directors, and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. On  June 13, 2024, the stockholders of Generac Holdings Inc. approved an amendment to the 2019 Plan to increase the number of shares available for issuance by 3.9 million. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $49,947, $49,248, and $35,183 for the years ended  December 31, 2025, 2024 and 2023, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:270]
Stock Options - Stock options granted in 2025 have an exercise price of $135.79 per share; stock options granted in 2024 have an exercise price between $112.45 and $147.41 per share; and stock options granted in 2023 have an exercise price between $110.86 and $119.57 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-26-004568:notes:271]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 0, 9,701, and 31,030 for the years ended  December 31, 2025, 2024 and 2023, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-26-004568:notes:272]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds to the Company from the cashless for cash exercise of stock options were $4,860, $27,558, and $7,815 for the years ended  December 31, 2025, 2024 and 2023, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-26-004568:notes:273]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $1,154, $13,672, and $4,895 for the years ended  December 31, 2025, 2024 and 2023, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-26-004568:notes:274]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history and are trued up upon vesting based on actual forfeiture activity.

[0001437749-26-004568:notes:275]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2025, 2024 and 2023 are as follows:

[0001437749-26-004568:notes:276]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Weighted average grant date fair value per share |  | $ | 72.16 |  |  | $ | 59.30 |  |  | $ | 57.73 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 50 | % |  |  | 49 | % |  |  | 45 | % |
| Risk free interest rate |  |  | 4.10 | % |  |  | 4.19 | % |  |  | 3.64 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-26-004568:notes:277]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2025, 2024 and 2023 is as follows:

[0001437749-26-004568:notes:278]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2022 |  |  | 1,268,404 |  |  |  | 81.35 |  |  |  | 4.9 |  |  | $ | 47,764 |  |
| Granted |  |  | 208,392 |  |  |  | 119.31 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (159,316 | ) |  |  | 42.46 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (33,144 | ) |  |  | 185.81 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2023 |  |  | 1,284,336 |  |  |  | 89.64 |  |  |  | 5.0 |  |  | $ | 75,587 |  |
| Granted |  |  | 118,681 |  |  |  | 112.66 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (310,201 | ) |  |  | 57.20 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (63,265 | ) |  |  | 152.06 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2024 |  |  | 1,029,551 |  |  |  | 96.10 |  |  |  | 4.9 |  |  | $ | 78,310 |  |
| Granted |  |  | 62,817 |  |  |  | 135.79 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (41,070 | ) |  |  | 90.23 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (41,564 | ) |  |  | 183.49 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2025 |  |  | 1,009,734 |  |  |  | 95.28 |  |  |  | 4.0 |  |  | $ | 58,823 |  |
| Exercisable as of December 31, 2025 |  |  | 792,351 |  |  |  | 84.65 |  |  |  | 3.0 |  |  | $ | 55,872 |  |

[0001437749-26-004568:notes:279]
As of  December 31, 2025, there was $9,334 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.2 years. Total share-based compensation cost related to stock options for the years ended  December 31, 2025, 2024 and 2023 was $6,910, $8,122, and $8,229, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:280]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2023 awards covers the years 2023 through 2025. The performance period for the 2024 awards covers the years 2024 through 2026. The performance period for the 2025 awards covers the years 2025 through 2027. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's stock on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures and is trued up upon vesting based on actual forfeiture activity.

[0001437749-26-004568:notes:281]
All restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 91,087, 78,465, and 50,577 for the years ended  December 31, 2025, 2024 and 2023, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $13,130, $11,097, and $6,002 for the years ended  December 31, 2025, 2024 and 2023, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-26-004568:notes:282]
A summary of the Company's restricted stock activity for the years ended  December 31, 2025, 2024 and 2023 is as follows:

[0001437749-26-004568:notes:283]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2022 |  |  | 378,298 |  |  | $ | 203.04 |  |
| Granted |  |  | 425,099 |  |  |  | 117.62 |  |
| Vested |  |  | (133,222 | ) |  |  | 175.94 |  |
| Forfeited |  |  | (44,789 | ) |  |  | 213.80 |  |
| Non-vested as of December 31, 2023 |  |  | 625,386 |  |  |  | 153.01 |  |
| Granted |  |  | 503,937 |  |  | $ | 120.77 |  |
| Vested |  |  | (206,435 | ) |  |  | 177.28 |  |
| Forfeited |  |  | (115,135 | ) |  |  | 130.89 |  |
| Non-vested as of December 31, 2024 |  |  | 807,753 |  |  |  | 127.07 |  |
| Granted |  |  | 409,762 |  |  | $ | 139.44 |  |
| Vested |  |  | (245,059 | ) |  |  | 139.27 |  |
| Forfeited |  |  | (114,500 | ) |  |  | 126.10 |  |
| Non-vested as of December 31, 2025 |  |  | 857,956 |  |  |  | 127.21 |  |

[0001437749-26-004568:notes:284]
As of
      December 31, 2025, there was
     $60,662 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of
     1.9 years. Total share-based compensation cost related to the restricted stock for the years ended
      December 31, 
     2025,
     2024 and
     2023, inclusive of performance shares, was
     $43
     ,037,
     $41,126, and
     $27,263, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-26-004568:notes:285]
During
     2025,
     2024 and
     2023,
     14,489,
     14,814, and
     16,174 shares of stock, respectively, were granted to certain members of the Company’s Board as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company, or a triggering event occurs.
     9,224,
     8,484, and
     8,832 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board for the years
     2025,
     2024, and
     2023, respectively. Total share-based compensation cost for shares of stock granted to the Company's Board in 
     2025,
     2024 and
     2023 was
     $1,749,
     $1,992, and
     $1,846, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-26-004568:notes:286]
| 18. | Commitments and Contingencies |

[0001437749-26-004568:notes:287]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  December 31, 2025, and  December 31, 2024, was $149,737 and $165,432, respectively.

[0001437749-26-004568:notes:288]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred.  The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee decided to pursue PHS’s claims against Generac in arbitration. Generac Power intends to vigorously defend against the claims and contends that PHS cannot recover certain damages on behalf of its customers upon final approval of the settlement in the Multidistrict Litigation noted herein below to the extent the claims relate to the performance of a certain solar system component.

[0001437749-26-004568:notes:289]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis. The parties have obtained preliminary approval for the classwide settlement and will be seeking final approval.  Generac Power has reserved for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.

[0001437749-26-004568:notes:290]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025 and the Company has filed a motion to dismiss.

[0001437749-26-004568:notes:291]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-26-004568:notes:292]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.

[0001437749-26-004568:notes:293]
On  November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company has cooperated fully with both the CPSC and DOJ investigations and believes that the matters have been resolved with no further action by the CPSC or DOJ.

[0001437749-26-004568:notes:294]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest and continues to accrue for post-judgment interest thereafter. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-26-004568:notes:295]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims and Generac filed a counterclaim. On  August 18, 2025, Generac Power prevailed in the defense of Spartronics’ arbitration claims and substantially prevailed on its counterclaim seeking possession of pre-paid raw materials and owned tooling. Generac Power also received an award of its legal fees in connection with the action. The award is binding and not subject of an appeal.

[0001437749-26-004568:notes:296]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). On  February 3, 2026, the court granted the Company’s motion to dismiss the amended complaint and found that plaintiffs failed to adequately plead a securities fraud claim.

[0001437749-26-004568:notes:297]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-26-004568:notes:298]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages.  On  January 26, 2026, the Company, together with other co-defendants, agreed to enter a settlement in principle to resolve all asserted claims, while denying any wrongdoing, to eliminate the uncertainty, burden, and expense of protracted litigation. The Company agreed to pay $104,500 in addition to the Company’s excess insurance for the applicable policy year. The Company has recorded a reserve for $206,500 within other accrued liabilities and an insurance receivable for $102,000 in prepaid expenses and other assets in the consolidated balance sheets as of  December 31, 2025.

[0001437749-26-004568:notes:299]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies. Champion in turn filed new patent infringement claims relating to its own carbon monoxide detection and shutoff technology. Generac Power denies the infringement allegations and intends to vigorously defend the matter.

[0001437749-26-004568:notes:300]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The court dismissed (1) all claims against the Company and (2) all non-Florida residents’ claims against Generac Power for lack of personal jurisdiction and limited the Florida plaintiffs’ claims against Generac Power to a claim for breach of express warranty.  The Company disputes the allegations and intends to vigorously defend against the remaining claims in the Amended Complaint, including that the case should not proceed as a class action.

[0001437749-26-004568:notes:301]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-26-004568:notes:302]
| 19. | Valuation and Qualifying Accounts |

[0001437749-26-004568:notes:303]
For the years ended  December 31, 2025, 2024 and 2023:

[0001437749-26-004568:notes:304]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 35,465 |  |  | $ | 1,398 |  |  | $ | (2,359 | ) |  | $ | - |  |  | $ | 34,504 |  |
| Reserves for inventory |  |  | 48,173 |  |  |  | 23,375 |  |  |  | (2,282 | ) |  |  | - |  |  |  | 69,266 |  |
| Valuation of deferred tax assets |  |  | 5,225 |  |  |  | 1,822 |  |  |  | (509 | ) |  |  | - |  |  |  | 6,538 |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 33,925 |  |  | $ | 4,524 |  |  | $ | (3,509 | ) |  | $ | 525 |  |  | $ | 35,465 |  |
| Reserves for inventory |  |  | 39,027 |  |  |  | 10,738 |  |  |  | (2,924 | ) |  |  | 1,332 |  |  |  | 48,173 |  |
| Valuation of deferred tax assets |  |  | 5,136 |  |  |  | 447 |  |  |  | (358 | ) |  |  | - |  |  |  | 5,225 |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 27,664 |  |  | $ | 7,443 |  |  | $ | (1,206 | ) |  | $ | 24 |  |  | $ | 33,925 |  |
| Reserves for inventory |  |  | 39,714 |  |  |  | 4,621 |  |  |  | (5,308 | ) |  |  | - |  |  |  | 39,027 |  |
| Valuation of deferred tax assets |  |  | 4,638 |  |  |  | 516 |  |  |  | (18 | ) |  |  | - |  |  |  | 5,136 |  |

[0001437749-26-004568:notes:305]
|  | (1) | Deductions from the allowance for credit losses equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |


## us-gaap:SubsequentEventsTextBlock

[0001437749-26-004568:notes:306]
| 20. | Subsequent Events |

[0001437749-26-004568:notes:307]
On  January 5, 2026, the Company completed the acquisition of Allmand, a leading manufacturer of mobile power equipment for C&I markets, headquartered in Holdrege, Nebraska, for a purchase price of $123,201. Due to the close proximity of the acquisition date and the Company's filing of its annual report on Form 10-K for the year ended  December 31, 2025, the initial accounting for the business combination is not yet complete and is pending identification and measurement of the assets acquired and liabilities assumed. Accordingly, the information required by ASC 805, Business Combinations will be disclosed in the Company's subsequent Form 10-Q.

[0001437749-26-004568:notes:308]
On  February 9, 2026, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the next twenty-four months. The new program replaces the prior share repurchase program, which had approximately $199,340 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-26-004568:notes:309]
Item 9B. Other Information

[0001437749-26-004568:notes:310]
Adoption: On  December 4, 2025, Aaron Jagdfeld, Chief Executive Officer and director, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 60,000 shares of the Company’s common stock until  February 26, 2027.
