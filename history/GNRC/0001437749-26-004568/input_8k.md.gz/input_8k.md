# GNRC 8-K — 0001437749-26-003700 filed 2026-02-11

## item codes, every 8-K on or before 2026-02-18

- 2026-02-11 0001437749-26-003700 — 2.02, 9.01
- 2025-10-29 0001437749-25-032069 — 2.02, 9.01
- 2025-07-30 0001437749-25-023858 — 2.02, 9.01
- 2025-07-02 0001437749-25-021956 — 1.01, 9.01
- 2025-06-13 0001437749-25-020324 — 5.07
- 2025-04-30 0001437749-25-013608 — 2.02, 9.01
- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2026-02-18

- none on or before 2026-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001437749-26-003700:8k_2_02:1]
EX-99.1
2
ex_919348.htm
EXHIBIT 99.1

[0001437749-26-003700:8k_2_02:2]
ex_919348.htm

[0001437749-26-003700:8k_2_02:3]
Exhibit 99.1

[0001437749-26-003700:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2025 Results

[0001437749-26-003700:8k_2_02:5]
Data center opportunities and assumed recovery in power outage environment support expectations for strong sales growth in 2026

[0001437749-26-003700:8k_2_02:6]
WAUKESHA, WISCONSIN (February 11, 2026) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2025 and initiated its outlook for the full-year 2026.

[0001437749-26-003700:8k_2_02:7]
Fourth Quarter 2025 Highlights

[0001437749-26-003700:8k_2_02:8]
| ● | Net sales decreased 12% to $1.09 billion during the fourth quarter of 2025 as compared to $1.23 billion in the prior year fourth quarter. Acquisitions and foreign currency had a slight favorable impact of 1% during the quarter. |

[0001437749-26-003700:8k_2_02:9]
|  | - | Residential product sales decreased approximately 23% to $572 million as compared to $743 million last year. Continued weakness in power outage activity resulted in lower shipments of home standby and portable generators as compared to a much stronger outage environment in the prior year period. |

[0001437749-26-003700:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased approximately 10% to $400 million as compared to $363 million in the prior year. This growth was primarily due to higher revenue from products sold to data center customers. |

[0001437749-26-003700:8k_2_02:11]
| ● | Net loss attributable to the Company during the fourth quarter was ($24) million, or ($0.42) per share, as compared to net income of $117 million, or $2.15 per share, for the same period of 2024. The current quarter includes a $104.5 million provision for the settlement of a legal matter. |

[0001437749-26-003700:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $95 million, or $1.61 per share, as compared to $168 million, or $2.80 per share, in the fourth quarter of 2024. |

[0001437749-26-003700:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $185 million, or 17.0% of net sales, as compared to $265 million, or 21.5% of net sales, in the prior year. |

[0001437749-26-003700:8k_2_02:14]
| ● | Cash flow from operations was $189 million as compared to $339 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $130 million as compared to $286 million in the fourth quarter of 2024. |

[0001437749-26-003700:8k_2_02:15]
Full-Year 2025 Highlights

[0001437749-26-003700:8k_2_02:16]
| ● | Net sales decreased 2% to $4.21 billion during 2025 as compared to $4.30 billion in 2024. Acquisitions and foreign currency had a slight favorable impact of 1% during the year. |

[0001437749-26-003700:8k_2_02:17]
|  | - | Residential product sales decreased 7% to $2.27 billion as compared to $2.43 billion in the prior year. |

[0001437749-26-003700:8k_2_02:18]
|  | - | C&I product sales increased 5% to $1.46 billion as compared to $1.39 billion in the prior year. |

[0001437749-26-003700:8k_2_02:19]
| ● | Net income attributable to the Company during 2025 was $160 million, or $2.69 per share, as compared to $316 million, or $5.39 per share for 2024. |

[0001437749-26-003700:8k_2_02:20]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $376 million, or $6.34 per share, as compared to $438 million, or $7.27 per share, in 2024. |

[0001437749-26-003700:8k_2_02:21]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, for 2025 was $716 million, or 17.0% of net sales, as compared to $789 million, or 18.4% of net sales, in the prior year. |

[0001437749-26-003700:8k_2_02:22]
| ● | Cash flow from operations was $438 million as compared to $741 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $268 million as compared to $605 million for 2024. |

[0001437749-26-003700:8k_2_02:23]
| ● | The Company repurchased approximately 1.1 million shares of its common stock during 2025 for $148 million. Additionally, on February 9, 2026, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500 million of the Company’s common stock over the next 24 months, replacing the remaining balance of the previous program. |

[0001437749-26-003700:8k_2_02:24]
2026 Highlights

[0001437749-26-003700:8k_2_02:25]
| ● | On January 5th, the Company completed the acquisition of Allmand, a leading manufacturer of mobile power equipment for C&I markets, headquartered in Holdrege, Nebraska. |

[0001437749-26-003700:8k_2_02:26]
| ● | The Company is initiating its full-year 2026 net sales growth guidance to be in the mid-teens percent range as compared to the prior year, which includes a 1% favorable impact from the net effect of foreign currency and completed acquisitions and divestitures. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 18.0 to 19.0%. |

[0001437749-26-003700:8k_2_02:27]
“Although our fourth quarter results reflect a softer outage environment and lower shipments of home standby and portable generators, our momentum in the data center end market has further accelerated as we continue to develop our position as a key supplier to multiple hyperscale customers which are expected to add significant volumes to our backlog over the next several quarters,” said Aaron Jagdfeld, President and Chief Executive Officer. “As a result, we are focused on dramatically increasing our capacity and capabilities for large megawatt generators, including the purchase of an additional manufacturing facility in Wisconsin in the fourth quarter and ongoing investments in our existing facilities around the world. These opportunities and investments put us well on our way to doubling our C&I product sales in the years ahead.”

[0001437749-26-003700:8k_2_02:28]
Additional Fourth Quarter 2025 Consolidated Highlights

[0001437749-26-003700:8k_2_02:29]
Gross profit margin was 36.3% as compared to 40.6% in the prior-year fourth quarter. The decrease in gross margin was primarily driven by unfavorable sales mix and a certain inventory provision in the current year quarter, as disclosed in the reconciliation schedules attached to this release. In addition, higher input costs and lower manufacturing absorption were mostly offset by increased price realization.

[0001437749-26-003700:8k_2_02:30]
Operating expenses increased to $405.4 million, or 34%, as compared to the fourth quarter of 2024. The increase was primarily driven by a $104.5 million provision for the settlement of a legal matter, as disclosed in the reconciliation schedules attached to this release.

[0001437749-26-003700:8k_2_02:31]
The Company had a ($3.7) million tax benefit for the current year quarter, or an effective tax rate of 13.4%, compared to a $27.3 million tax expense for the prior year, or an 18.9% effective tax rate. The lower effective tax rate was driven primarily by the impact of certain favorable discrete tax items and their impact on a lower pre-tax income in the current year.

[0001437749-26-003700:8k_2_02:32]
Cash flow from operations was $189 million during the fourth quarter, as compared to $339 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $130 million as compared to $286 million in the fourth quarter of 2024. The change in free cash flow was primarily driven by a significant reduction in net working capital in the prior year which did not repeat and lower operating income in the current year, partially offset by lower cash tax payments.

[0001437749-26-003700:8k_2_02:33]
Fourth Quarter Business Segment Results

[0001437749-26-003700:8k_2_02:34]
Domestic Segment

[0001437749-26-003700:8k_2_02:35]
Domestic segment total sales (including inter-segment sales) decreased approximately 17% to $889 million as compared to $1.07 billion in the prior year. This sales decrease was primarily driven by weaker home standby and portable generator shipments as a result of the lower power outage environment in the current year together with a strong prior year comparison which included multiple major landed hurricanes. This was partially offset by strength in residential energy technology sales and increased revenue from products sold to data center customers.

[0001437749-26-003700:8k_2_02:36]
Adjusted EBITDA for the segment was $151.5 million, or 17.0% of domestic segment total sales, as compared to $242.8 million, or 22.7% of total sales, in the prior year. This decline was primarily driven by unfavorable sales mix, higher input costs, and operating deleverage on lower sales volumes, partially offset by increased price realization.

[0001437749-26-003700:8k_2_02:37]
International Segment

[0001437749-26-003700:8k_2_02:38]
International segment total sales (including inter-segment sales) increased approximately 12% to $209.2 million from $187.5 million in the prior year quarter, including an approximate 6% favorable impact from foreign currency. The core total sales growth for the segment was primarily driven by higher revenue for data center customers and an increase in global shipments for our controls product offering, partially offset by lower inter-segment sales.

[0001437749-26-003700:8k_2_02:39]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $33.7 million, or 16.1% of international segment total sales, as compared to $22.5 million, or 12.0% of total sales, in the prior year. This margin increase was primarily driven by favorable sales mix and improved price/cost realization.

[0001437749-26-003700:8k_2_02:40]
2026 Outlook

[0001437749-26-003700:8k_2_02:41]
The Company is initiating guidance for full-year 2026 that anticipates strong net sales growth in the mid-teens percent range as compared to the prior year, which includes a 1% favorable impact from the net effect of foreign currency and completed acquisitions and divestitures. C&I product sales are expected to increase in the 30% range during the year, primarily due to increased revenue from products sold to data center customers and the recent acquisition of Allmand. Residential product sales are projected to increase in the 10% range from the prior year, driven by higher home standby generator price realization and increased shipments assuming a return to power outage activity in line with the longer-term baseline average for the remainder of the year.

[0001437749-26-003700:8k_2_02:42]
Additionally, the Company expects net income margin, before deducting for non-controlling interests, to be approximately 8.0 to 9.0% for the full-year 2026. The corresponding adjusted EBITDA margin is expected to be approximately 18.0 to 19.0%.

[0001437749-26-003700:8k_2_02:43]
Conference Call and Webcast

[0001437749-26-003700:8k_2_02:44]
Generac management will hold a conference call at 10:00 a.m. EST on Wednesday, February 11, 2026 to discuss 2025 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/n5idfpix

[0001437749-26-003700:8k_2_02:45]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-26-003700:8k_2_02:46]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-26-003700:8k_2_02:47]
About Generac

[0001437749-26-003700:8k_2_02:48]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company’s broad portfolio of energy technology offerings for homes and businesses enables its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and innovative energy solutions.

[0001437749-26-003700:8k_2_02:49]
Forward-looking Information

[0001437749-26-003700:8k_2_02:50]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-26-003700:8k_2_02:51]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-26-003700:8k_2_02:52]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products including as part of the growing data center market and energy technology product offerings; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |

[0001437749-26-003700:8k_2_02:53]
4

[0001437749-26-003700:8k_2_02:54]
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-26-003700:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-26-003700:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-26-003700:8k_2_02:57]
Non-GAAP Financial Metrics

[0001437749-26-003700:8k_2_02:58]
Core Sales

[0001437749-26-003700:8k_2_02:59]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-26-003700:8k_2_02:60]
Adjusted EBITDA

[0001437749-26-003700:8k_2_02:61]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income (loss) before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense (benefit), certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries and certain intellectual property litigation. The adjustments to net income (loss) in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-26-003700:8k_2_02:62]
Adjusted Net Income

[0001437749-26-003700:8k_2_02:63]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income (loss) before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-26-003700:8k_2_02:64]
Free Cash Flow

[0001437749-26-003700:8k_2_02:65]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-26-003700:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-26-003700:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-26-003700:8k_2_02:68]
CONTACT:

[0001437749-26-003700:8k_2_02:69]
Kris Rosemann

[0001437749-26-003700:8k_2_02:70]
Director – Corporate Finance & Investor Relations

[0001437749-26-003700:8k_2_02:71]
(262) 506-6064

[0001437749-26-003700:8k_2_02:72]
InvestorRelations@generac.com

[0001437749-26-003700:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-003700:8k_2_02:74]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 341,413 |  |  | $ | 281,277 |  |
| Accounts receivable, less allowance for credit losses of $34,504 and $35,465 as of December 31, 2025 and December 31, 2024, respectively |  |  | 602,739 |  |  |  | 612,107 |  |
| Inventories |  |  | 1,248,867 |  |  |  | 1,031,647 |  |
| Prepaid expenses and other current assets |  |  | 269,459 |  |  |  | 107,139 |  |
| Total current assets |  |  | 2,462,478 |  |  |  | 2,032,170 |  |
| Property and equipment, net |  |  | 813,605 |  |  |  | 690,023 |  |
| Customer lists, net |  |  | 127,517 |  |  |  | 152,737 |  |
| Patents and technology, net |  |  | 338,308 |  |  |  | 379,095 |  |
| Other intangible assets, net |  |  | 10,011 |  |  |  | 20,026 |  |
| Tradenames, net |  |  | 199,430 |  |  |  | 206,664 |  |
| Goodwill |  |  | 1,467,094 |  |  |  | 1,436,261 |  |
| Deferred income taxes |  |  | 41,949 |  |  |  | 24,132 |  |
| Operating lease and other assets |  |  | 113,287 |  |  |  | 168,223 |  |
| Total assets |  | $ | 5,573,679 |  |  | $ | 5,109,331 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 50,618 |  |  | $ | 55,848 |  |
| Accounts payable |  |  | 436,583 |  |  |  | 458,693 |  |
| Accrued wages and employee benefits |  |  | 69,850 |  |  |  | 81,485 |  |
| Accrued product warranty |  |  | 44,716 |  |  |  | 56,127 |  |
| Other accrued liabilities |  |  | 591,387 |  |  |  | 313,401 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 22,192 |  |  |  | 67,598 |  |
| Total current liabilities |  |  | 1,215,346 |  |  |  | 1,033,152 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,260,256 |  |  |  | 1,210,776 |  |
| Deferred income taxes |  |  | 60,913 |  |  |  | 33,185 |  |
| Deferred revenue |  |  | 232,921 |  |  |  | 193,260 |  |
| Operating lease and other long-term liabilities |  |  | 165,197 |  |  |  | 141,515 |  |
| Total liabilities |  |  | 2,934,633 |  |  |  | 2,611,888 |  |
| Redeemable noncontrolling interest |  |  | 742 |  |  |  | - |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 74,050,753 and 73,785,631 shares issued as of December 31, 2025 and December 31, 2024, respectively |  |  | 741 |  |  |  | 738 |  |
| Additional paid-in capital |  |  | 1,187,419 |  |  |  | 1,133,756 |  |
| Treasury stock, at cost, 15,373,990 and 14,173,697 shares at December 31, 2025 and December 31, 2024, respectively |  |  | (1,358,053 | ) |  |  | (1,196,997 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 3,003,557 |  |  |  | 2,844,296 |  |
| Accumulated other comprehensive income (loss) |  |  | 874 |  |  |  | (85,399 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,632,422 |  |  |  | 2,494,278 |  |
| Noncontrolling interests |  |  | 5,882 |  |  |  | 3,165 |  |
| Total stockholders’ equity |  |  | 2,638,304 |  |  |  | 2,497,443 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,573,679 |  |  | $ | 5,109,331 |  |

[0001437749-26-003700:8k_2_02:75]
7

[0001437749-26-003700:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-003700:8k_2_02:77]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net sales |  | $ | 1,091,504 |  |  | $ | 1,234,801 |  |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |
| Costs of goods sold |  |  | 695,424 |  |  |  | 733,384 |  |  |  | 2,597,410 |  |  |  | 2,630,208 |  |
| Gross profit |  |  | 396,080 |  |  |  | 501,417 |  |  |  | 1,611,737 |  |  |  | 1,665,626 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 144,694 |  |  |  | 144,397 |  |  |  | 555,358 |  |  |  | 526,446 |  |
| Research and development |  |  | 61,009 |  |  |  | 59,258 |  |  |  | 243,470 |  |  |  | 219,600 |  |
| General and administrative |  |  | 174,287 |  |  |  | 75,703 |  |  |  | 422,211 |  |  |  | 285,095 |  |
| Amortization of intangibles |  |  | 25,405 |  |  |  | 24,045 |  |  |  | 101,507 |  |  |  | 97,743 |  |
| Total operating expenses |  |  | 405,395 |  |  |  | 303,403 |  |  |  | 1,322,546 |  |  |  | 1,128,884 |  |
| Income from operations |  |  | (9,315 | ) |  |  | 198,014 |  |  |  | 289,191 |  |  |  | 536,742 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (16,884 | ) |  |  | (19,880 | ) |  |  | (70,697 | ) |  |  | (89,713 | ) |
| Investment income |  |  | 2,055 |  |  |  | 2,319 |  |  |  | 7,673 |  |  |  | 7,605 |  |
| Change in fair value of investments |  |  | (3,472 | ) |  |  | (35,068 | ) |  |  | (20,610 | ) |  |  | (38,006 | ) |
| Loss on refinancing of debt |  |  | - |  |  |  | - |  |  |  | (1,225 | ) |  |  | (4,861 | ) |
| Other, net |  |  | (28 | ) |  |  | (380 | ) |  |  | (5,272 | ) |  |  | (2,329 | ) |
| Total other expense, net |  |  | (18,329 | ) |  |  | (53,009 | ) |  |  | (90,131 | ) |  |  | (127,304 | ) |
| (Loss) income before provision for income taxes |  |  | (27,644 | ) |  |  | 145,005 |  |  |  | 199,060 |  |  |  | 409,438 |  |
| (Benefit) provision for income taxes |  |  | (3,710 | ) |  |  | 27,336 |  |  |  | 37,706 |  |  |  | 92,460 |  |
| Net (loss) income |  |  | (23,934 | ) |  |  | 117,669 |  |  |  | 161,354 |  |  |  | 316,978 |  |
| Net income attributable to noncontrolling interests |  |  | 529 |  |  |  | 443 |  |  |  | 1,800 |  |  |  | 663 |  |
| Net (loss) income attributable to Generac Holdings Inc. |  |  | (24,463 | ) |  |  | 117,226 |  |  |  | 159,554 |  |  |  | 316,315 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  |  | 5,817 |  |  |  | (59,923 | ) |  |  | 99,817 |  |  |  | (62,842 | ) |
| Net unrealized (loss) gain on derivatives |  |  | (2,636 | ) |  |  | 2,253 |  |  |  | (12,863 | ) |  |  | (7,672 | ) |
| Other comprehensive income (loss) |  |  | 3,181 |  |  |  | (57,670 | ) |  |  | 86,954 |  |  |  | (70,514 | ) |
| Total comprehensive (loss) income: |  |  | (20,753 | ) |  |  | 59,999 |  |  |  | 248,308 |  |  |  | 246,464 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 545 |  |  |  | 200 |  |  |  | 2,481 |  |  |  | 405 |  |
| Comprehensive (loss) income attributable to Generac Holdings Inc. |  | $ | (21,298 | ) |  | $ | 59,799 |  |  | $ | 245,827 |  |  | $ | 246,059 |  |
| Net (loss) income attributable to common shareholders per common share - basic: |  | $ | (0.42 | ) |  | $ | 2.18 |  |  | $ | 2.73 |  |  | $ | 5.46 |  |
| Weighted average common shares outstanding - basic: |  |  | 58,296,527 |  |  |  | 59,122,093 |  |  |  | 58,523,642 |  |  |  | 59,559,797 |  |
| Net (loss) income attributable to common shareholders per common share - diluted: |  | $ | (0.42 | ) |  | $ | 2.15 |  |  | $ | 2.69 |  |  | $ | 5.39 |  |
| Weighted average common shares outstanding - diluted: |  |  | 58,296,527 |  |  |  | 60,012,948 |  |  |  | 59,275,781 |  |  |  | 60,350,412 |  |

[0001437749-26-003700:8k_2_02:78]
8

[0001437749-26-003700:8k_2_02:79]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-26-003700:8k_2_02:80]
|  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 161,354 |  |  | $ | 316,978 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 93,328 |  |  |  | 74,025 |  |
| Amortization of intangible assets |  |  | 101,507 |  |  |  | 97,743 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 2,380 |  |  |  | 3,242 |  |
| Change in fair value of investments |  |  | 20,610 |  |  |  | 38,006 |  |
| Loss on refinancing of debt |  |  | 1,225 |  |  |  | 4,861 |  |
| Deferred income tax expense (benefit) |  |  | 15,080 |  |  |  | (60,615 | ) |
| Share-based compensation expense |  |  | 49,947 |  |  |  | 49,248 |  |
| Loss (gain) on disposal of assets |  |  | (688 | ) |  |  | 138 |  |
| Loss attributable to the disposition of a business |  |  | 3,905 |  |  |  | - |  |
| Other noncash charges |  |  | 2,857 |  |  |  | 5,780 |  |
| Excess tax benefits from equity awards |  |  | (404 | ) |  |  | (5,069 | ) |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 45,637 |  |  |  | (82,816 | ) |
| Inventories |  |  | (163,117 | ) |  |  | 122,952 |  |
| Other assets |  |  | (40,109 | ) |  |  | 546 |  |
| Accounts payable |  |  | (40,701 | ) |  |  | 123,571 |  |
| Accrued wages and employee benefits |  |  | (13,555 | ) |  |  | 26,870 |  |
| Other accrued liabilities |  |  | 198,722 |  |  |  | 25,841 |  |
| Net cash provided by operating activities |  |  | 437,978 |  |  |  | 741,301 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 3,078 |  |  |  | 211 |  |
| Contribution to tax equity investment |  |  | - |  |  |  | (1,629 | ) |
| Purchase of long-term investments |  |  | (3,035 | ) |  |  | (37,821 | ) |
| Proceeds from sale of long-term investments |  |  | - |  |  |  | 2,000 |  |
| Expenditures for property and equipment |  |  | (169,850 | ) |  |  | (136,733 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (762 | ) |  |  | (34,740 | ) |
| Other investing activities |  |  | (2,335 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (172,904 | ) |  |  | (208,712 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 36,402 |  |  |  | 29,219 |  |
| Proceeds from long-term borrowings |  |  | 132,826 |  |  |  | 541,475 |  |
| Repayments of short-term borrowings |  |  | (48,211 | ) |  |  | (54,548 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (168,503 | ) |  |  | (794,600 | ) |
| Stock repurchases |  |  | (147,917 | ) |  |  | (152,743 | ) |
| Payment of debt issuance costs |  |  | (5,275 | ) |  |  | (3,616 | ) |
| Payment of contingent acquisition consideration |  |  | (2,700 | ) |  |  | - |  |
| Payment of deferred acquisition consideration |  |  | (603 | ) |  |  | (7,421 | ) |
| Contributions received from noncontrolling interest in subsidiary |  |  | 979 |  |  |  | - |  |
| Dividends paid to noncontrolling interest of subsidiary |  |  | (293 | ) |  |  | (273 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | (9,117 | ) |
| Taxes paid related to equity awards |  |  | (14,284 | ) |  |  | (24,769 | ) |
| Proceeds from the exercise of stock options |  |  | 4,860 |  |  |  | 27,558 |  |
| Net cash used in financing activities |  |  | (212,719 | ) |  |  | (448,835 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 7,781 |  |  |  | (3,471 | ) |
| Net increase in cash and cash equivalents |  |  | 60,136 |  |  |  | 80,283 |  |
| Cash and cash equivalents at beginning of period |  |  | 281,277 |  |  |  | 200,994 |  |
| Cash and cash equivalents at end of period |  | $ | 341,413 |  |  | $ | 281,277 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 75,874 |  |  | $ | 89,420 |  |
| Income taxes |  |  | 89,415 |  |  |  | 148,828 |  |

[0001437749-26-003700:8k_2_02:81]
9

[0001437749-26-003700:8k_2_02:82]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-26-003700:8k_2_02:83]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended December 31, 2025 |  |  | Three Months Ended December 31, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 884,447 |  |  | $ | 4,787 |  |  | $ | 889,234 |  |  | $ | 1,057,907 |  |  | $ | 9,361 |  |  | $ | 1,067,268 |  |
| International |  |  | 207,057 |  |  |  | 2,137 |  |  |  | 209,194 |  |  |  | 176,894 |  |  |  | 10,572 |  |  |  | 187,466 |  |
| Intercompany elimination |  |  | - |  |  |  | (6,924 | ) |  |  | (6,924 | ) |  |  | - |  |  |  | (19,933 | ) |  |  | (19,933 | ) |
| Total net sales |  | $ | 1,091,504 |  |  | $ | - |  |  | $ | 1,091,504 |  |  | $ | 1,234,801 |  |  | $ | - |  |  | $ | 1,234,801 |  |

[0001437749-26-003700:8k_2_02:84]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2025 |  |  | Year Ended December 31, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,470,966 |  |  | $ | 23,205 |  |  | $ | 3,494,171 |  |  | $ | 3,599,149 |  |  | $ | 35,932 |  |  | $ | 3,635,081 |  |
| International |  |  | 738,181 |  |  |  | 39,250 |  |  |  | 777,431 |  |  |  | 696,685 |  |  |  | 28,700 |  |  |  | 725,385 |  |
| Intercompany elimination |  |  | - |  |  |  | (62,455 | ) |  |  | (62,455 | ) |  |  | - |  |  |  | (64,632 | ) |  |  | (64,632 | ) |
| Total net sales |  | $ | 4,209,147 |  |  | $ | - |  |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |  | $ | - |  |  | $ | 4,295,834 |  |

[0001437749-26-003700:8k_2_02:85]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Residential products |  | $ | 571,866 |  |  | $ | 743,336 |  |  | $ | 2,266,912 |  |  | $ | 2,433,474 |  |
| Commercial & industrial products |  |  | 399,536 |  |  |  | 363,376 |  |  |  | 1,457,385 |  |  |  | 1,389,469 |  |
| Other |  |  | 120,102 |  |  |  | 128,089 |  |  |  | 484,850 |  |  |  | 472,891 |  |
| Total net sales |  | $ | 1,091,504 |  |  | $ | 1,234,801 |  |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |

[0001437749-26-003700:8k_2_02:86]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 151,459 |  |  | $ | 242,787 |  |  | $ | 597,915 |  |  | $ | 693,203 |  |
| International |  |  | 33,693 |  |  |  | 22,527 |  |  |  | 117,627 |  |  |  | 95,898 |  |
| Total adjusted EBITDA (1) |  | $ | 185,152 |  |  | $ | 265,314 |  |  | $ | 715,542 |  |  | $ | 789,101 |  |

[0001437749-26-003700:8k_2_02:87]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-26-003700:8k_2_02:88]
10

[0001437749-26-003700:8k_2_02:89]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-26-003700:8k_2_02:90]
| Net income to Adjusted EBITDA reconciliation |

[0001437749-26-003700:8k_2_02:91]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net (loss) income attributable to Generac Holdings Inc. |  | $ | (24,463 | ) |  | $ | 117,226 |  |  | $ | 159,554 |  |  | $ | 316,315 |  |
| Net income attributable to noncontrolling interests |  |  | 529 |  |  |  | 443 |  |  |  | 1,800 |  |  |  | 663 |  |
| Net (loss) income |  |  | (23,934 | ) |  |  | 117,669 |  |  |  | 161,354 |  |  |  | 316,978 |  |
| Interest expense |  |  | 16,884 |  |  |  | 19,880 |  |  |  | 70,697 |  |  |  | 89,713 |  |
| Depreciation and amortization |  |  | 51,162 |  |  |  | 43,834 |  |  |  | 194,835 |  |  |  | 171,768 |  |
| (Benefit) provision for income taxes |  |  | (3,710 | ) |  |  | 27,336 |  |  |  | 37,706 |  |  |  | 92,460 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,663 |  |  |  | 1,894 |  |  |  | 6,636 |  |  |  | 4,757 |  |
| Non-cash share-based compensation expense (2) |  |  | 10,836 |  |  |  | 10,978 |  |  |  | 49,947 |  |  |  | 49,248 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,385 |  |  |  | 1,068 |  |  |  | 3,976 |  |  |  | 5,097 |  |
| Business optimization and other charges (4) |  |  | 1,916 |  |  |  | 1,562 |  |  |  | 7,301 |  |  |  | 4,752 |  |
| Provision for legal, regulatory, and other costs (5) |  |  | 126,111 |  |  |  | 5,651 |  |  |  | 157,981 |  |  |  | 10,931 |  |
| Change in fair value of investments (6) |  |  | 3,472 |  |  |  | 35,068 |  |  |  | 20,610 |  |  |  | 38,006 |  |
| Loss on refinancing of debt (7) |  |  | - |  |  |  | - |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Other |  |  | (633 | ) |  |  | 374 |  |  |  | 3,274 |  |  |  | 530 |  |
| Adjusted EBITDA |  |  | 185,152 |  |  |  | 265,314 |  |  |  | 715,542 |  |  |  | 789,101 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 749 |  |  |  | 654 |  |  |  | 2,648 |  |  |  | 1,175 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 184,403 |  |  | $ | 264,660 |  |  | $ | 712,894 |  |  | $ | 787,926 |  |

[0001437749-26-003700:8k_2_02:92]
| Net income to Adjusted net income reconciliation |

[0001437749-26-003700:8k_2_02:93]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net (loss) income attributable to Generac Holdings Inc. |  | $ | (24,463 | ) |  | $ | 117,226 |  |  | $ | 159,554 |  |  | $ | 316,315 |  |
| Net income attributable to noncontrolling interests |  |  | 529 |  |  |  | 443 |  |  |  | 1,800 |  |  |  | 663 |  |
| Net (loss) income |  |  | (23,934 | ) |  |  | 117,669 |  |  |  | 161,354 |  |  |  | 316,978 |  |
| Amortization of intangible assets |  |  | 25,405 |  |  |  | 24,045 |  |  |  | 101,507 |  |  |  | 97,743 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 545 |  |  |  | 650 |  |  |  | 2,380 |  |  |  | 3,242 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 1,141 |  |  |  | 445 |  |  |  | 1,797 |  |  |  | 2,717 |  |
| Loss attributable to business or asset dispositions (9) |  |  | - |  |  |  | - |  |  |  | 4,295 |  |  |  | 65 |  |
| Business optimization and other charges (4) |  |  | 1,916 |  |  |  | 1,562 |  |  |  | 7,301 |  |  |  | 4,752 |  |
| Provision for legal, regulatory, and other costs (5) |  |  | 126,111 |  |  |  | 5,651 |  |  |  | 157,981 |  |  |  | 10,931 |  |
| Change in fair value of investments (6) |  |  | 3,472 |  |  |  | 35,068 |  |  |  | 20,610 |  |  |  | 38,006 |  |
| Loss on refinancing of debt (7) |  |  | - |  |  |  | - |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Tax effect of add backs |  |  | (39,251 | ) |  |  | (16,411 | ) |  |  | (80,658 | ) |  |  | (40,173 | ) |
| Adjusted net income |  |  | 95,405 |  |  |  | 168,679 |  |  |  | 377,792 |  |  |  | 439,122 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 529 |  |  |  | 443 |  |  |  | 1,800 |  |  |  | 663 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 94,876 |  |  | $ | 168,236 |  |  | $ | 375,992 |  |  | $ | 438,459 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.61 |  |  | $ | 2.80 |  |  | $ | 6.34 |  |  | $ | 7.27 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,103,751 |  |  |  | 60,012,948 |  |  |  | 59,275,781 |  |  |  | 60,350,412 |  |

[0001437749-26-003700:8k_2_02:94]
(1) Includes (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-26-003700:8k_2_02:95]
11

[0001437749-26-003700:8k_2_02:96]
(2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods.

[0001437749-26-003700:8k_2_02:97]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-26-003700:8k_2_02:98]
(4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-26-003700:8k_2_02:99]
(5) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-26-003700:8k_2_02:100]
|  | ● | Legal expenses, judgments, and settlements related to certain patent lawsuits - $1.6 million in the fourth quarter of 2025; $7.5 million for the full year 2025; $5.4 million in the fourth quarter of 2024; and $9.2 million for the full year 2024. |
|  | ● | Legal expenses and settlements related to certain class action lawsuits - $1.1 million in the fourth quarter of 2025; $22.7 million for the full year 2025, which includes a $15.0 million provision for a multi-district class action settlement related to clean energy products; $0.3 million in the fourth quarter of 2024; and $1.3 million for the full year 2024. |
|  | ● | Legal expenses related to certain government inquiries and other significant matters - $3.3 million in the fourth quarter of 2025; and $7.6 million for the full year 2025. |
|  | ● | A provision of $104.5 million, net in the fourth quarter of 2025 for a settlement agreement (in principle) related to a certain portable generator product liability case deemed outside the ordinary course of routine litigation for the Company. |
|  | ● | A $15.6 million net inventory provision in the fourth quarter of 2025 related to the settlement of a contract dispute with a supplier for a discontinued product. |

[0001437749-26-003700:8k_2_02:101]
(6) Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-26-003700:8k_2_02:102]
(7) For the full year ended December 31, 2025, the loss represents the third-party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Tranche A Term Loan Facility and Revolving Debt Facility.  For the full year ended December 31, 2024, the loss represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility.

[0001437749-26-003700:8k_2_02:103]
(8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-26-003700:8k_2_02:104]
(9) The pre-tax loss for the full year 2025 relates primarily to the sale of our immaterial Tank Utility fleet business during the second quarter of 2025.

[0001437749-26-003700:8k_2_02:105]
| Free Cash Flow Reconciliation |

[0001437749-26-003700:8k_2_02:106]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 189,259 |  |  | $ | 339,454 |  |  | $ | 437,978 |  |  | $ | 741,301 |  |
| Expenditures for property and equipment |  |  | (59,316 | ) |  |  | (53,334 | ) |  |  | (169,850 | ) |  |  | (136,733 | ) |
| Free cash flow |  | $ | 129,943 |  |  | $ | 286,120 |  |  | $ | 268,128 |  |  | $ | 604,568 |  |

[0001437749-26-003700:8k_2_02:107]
12
