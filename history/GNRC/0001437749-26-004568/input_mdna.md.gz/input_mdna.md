# GNRC MD&A — 0001437749-26-004568


## mdna

[0001437749-26-004568:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-26-004568:mdna:2]
Overview

[0001437749-26-004568:mdna:3]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. Generac provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, commercial, data center, telecom, rental, and industrial markets. The Company’s broad portfolio of energy technology offerings for homes and businesses enables its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and innovative energy solutions.

[0001437749-26-004568:mdna:4]
Further information regarding our business is provided in “Part I, Item 1. Business” of this Annual Report on Form 10-K.

[0001437749-26-004568:mdna:5]
Business Drivers and Operational Factors

[0001437749-26-004568:mdna:6]
“Part I, Item 1. Business” of this Annual Report on Form 10-K contains information regarding business drivers, including key mega-trends and strategic growth themes under the subheading “Key Mega-Trends and Strategic Growth Themes.”

[0001437749-26-004568:mdna:7]
We are subject to various other business drivers and factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control, and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-26-004568:mdna:8]
Impact of residential investment cycle. The market for our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators, solar and energy storage systems, and energy management devices. Trends in interest rates and the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. The existence of renewable energy mandates, investment tax credits, and other subsidies can also have an impact on the demand for solar and energy storage systems. The “One Big Beautiful Bill Act” (OBBBA) that was enacted in the United States in July 2025 accelerated the phase out of certain investment tax credits, resulting in a negative impact to the solar & storage market thereafter.

[0001437749-26-004568:mdna:9]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. The capital investment cycle may differ for the various C&I end markets that we serve, including data centers, light commercial, retail, office, telecommunications, rental, industrial, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions around the world, fluctuations in interest rates & foreign currencies, trade policies, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-26-004568:mdna:10]
Effect of commodity, currency, component price fluctuations, and resource availability. Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells that can fluctuate in terms of pricing and availability. Our international operations, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-26-004568:mdna:11]
Commodity, currency, and component price levels are increasingly subject to geopolitical uncertainty, including ongoing regional conflicts, shifts in U.S. and international trade policies, and the potential for new or increased tariffs. These factors, along with increased demand from data centers, have contributed to heightened volatility in commodity prices, particularly for raw materials such as steel, copper, and aluminum. Additionally, geopolitical instability can contribute to significant fluctuations in foreign currency exchange rates which can impact our reported financial performance from our foreign operations and supply chain.

[0001437749-26-004568:mdna:12]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-26-004568:mdna:13]
Tariffs and international trade relations. Given our global supply chain and international operations, our business is impacted by tariffs and other changes in U.S. trade policy and international trade relations. For example, starting in the first quarter of 2025, the United States government enacted additional tariffs on goods imported into the U.S. from numerous countries, and certain countries announced tariffs on U.S. goods. Some of these tariffs have been subsequently modified or delayed, and the U.S. government has also stated it is willing to negotiate with respect to the tariffs it has enacted.

[0001437749-26-004568:mdna:14]
We have implemented price increases across many of our product offerings and are executing a number of supply chain initiatives to attempt to mitigate the impact of these tariffs on our profitability. Despite our efforts, these tariff actions and resulting price increases have created inflationary pressures for consumers, negatively impacting demand and margins for certain of our products. As U.S. trade policy continues to evolve, we will continue to evaluate the impact of future tariffs and take actions to mitigate and/or minimize their effects.

[0001437749-26-004568:mdna:15]
Seasonality. Although there is demand for our products throughout the year, in each of the past five years, approximately 20% to 25% of our net sales occurred in the first quarter, 23% to 28% in the second quarter, 24% to 27% in the third quarter, and 23% to 29% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. The second half of 2025 represented a very low level of baseline power outage activity, impacting demand for our residential products and resulting in quarterly net sales being more level-loaded as compared to our historical averages.

[0001437749-26-004568:mdna:16]
Acquisitions. Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business" to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K.

[0001437749-26-004568:mdna:17]
Factors Influencing Interest Expense

[0001437749-26-004568:mdna:18]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for further information. The decrease in interest expense in the current year was primarily driven by lower borrowings, lower SOFR interest rates, and lower interest rate spreads during the year.

[0001437749-26-004568:mdna:19]
On July 1, 2025, we amended our Term Loan A Facility and Revolving Credit Facility, extending the maturity of both to July 1, 2030, revising the Term Loan A Facility outstanding principal balance to $700,000, reducing the Revolving Credit Facility borrowing capacity to $1,000,000, and redefining the Term Benchmark to replace the Adjusted Term SOFR Rate with the Term SOFR Rate, resulting in an interest rate spread reduction of 0.10%.

[0001437749-26-004568:mdna:20]
Factors Influencing Provision for Income Taxes and Cash Income Taxes Paid

[0001437749-26-004568:mdna:21]
The effective income tax rates for the years ended December 31, 2025 and 2024 were 18.9% and 22.6%, respectively. The lower 2025 effective tax rate was driven primarily by the impact of certain favorable discrete tax items and their impact on a lower pre-tax income in the current year.

[0001437749-26-004568:mdna:22]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. In January 2026, the OECD released a new package of administrative guidance that effectively deems the United States tax system as compliant with Pillar Two, which is expected to eliminate additional top-up taxes across our global operations. This updated guidance package does not exempt the Company from Qualified Domestic Minimum Top-Up Taxes in foreign jurisdictions. As a result, we expect our cash taxes paid to remain subject to local minimum tax regimes where applicable. There was no impact to the financial results of the year ended December 31, 2025, and we do not expect the rules to have a material impact on our effective tax rate for the following year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-26-004568:mdna:23]
On July 4, 2025, the United States signed the OBBBA into law. This legislation makes permanent several key provisions related to 100% bonus depreciation and the immediate expensing of domestic research and development costs. Under ASC 740, “Income Taxes,” the effects of changes in tax laws are reflected in the Company’s financial statements in the quarter in which the legislation was passed. We expect to realize cash tax savings as a result of provisions related to bonus depreciation and domestic research and development expensing. These changes did not have a material impact on our effective income tax rate for 2025 as the changes relate to temporary differences in basis.

[0001437749-26-004568:mdna:24]
Components of Net Sales and Expenses

[0001437749-26-004568:mdna:25]
Net Sales

[0001437749-26-004568:mdna:26]
Our net sales primarily consist of the sale of products to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, installation, maintenance, telecom facility design and build, and remote monitoring. These services accounted for approximately 4% of our net sales for the year ended December 31, 2025. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-26-004568:mdna:27]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 4% of our net sales, and our top ten customers representing approximately 18% of our net sales in aggregate for the year ended December 31, 2025.

[0001437749-26-004568:mdna:28]
Costs of Goods Sold

[0001437749-26-004568:mdna:29]
The principal elements of costs of goods sold are component parts, raw materials, inbound and outbound freight, factory overhead and labor. The principal component parts are engines, alternators, batteries, electronic controls, and steel enclosures. We design and manufacture air-cooled engines for certain of our generators up to 28kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our generators. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high-quality suppliers. In some cases, these relationships are proprietary. For certain energy technology products, we source these products complete from certain contract manufacturers using our designs.

[0001437749-26-004568:mdna:30]
The principal sourced raw materials used in the manufacturing process are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity price changes on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations and global trade policies given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-26-004568:mdna:31]
Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-26-004568:mdna:32]
The balance of cost of goods sold include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted if we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-26-004568:mdna:33]
Operating Expenses

[0001437749-26-004568:mdna:34]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, warranty, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include, among others, personnel costs such as salaries, bonuses, employee benefit costs, payroll taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-26-004568:mdna:35]
Selling and service. Our selling and service expenses consist primarily of personnel costs, marketing expense, standard assurance warranty expense, bad debt provisions, and other sales expenses. Our personnel costs recorded in selling and services expenses include the expense of our sales force, customer support teams, outbound shipping and distribution functions, and other personnel involved in the marketing, sales and service of our products. Standard warranty expense is estimated based on historical trends or based on specific warranty matters as they become known and reasonably estimable. Our marketing expenses include media advertising, promotional expenses, co-op advertising costs, direct mail costs, printed material costs, product display costs, market research expenses, and trade show expenses. Marketing expenses are generally related to the launch of new product offerings, opportunities to create market awareness for our products, and general brand awareness marketing efforts. Our marketing campaigns are an important source for lead generation.

[0001437749-26-004568:mdna:36]
Research and development. Our research and development expenses include mechanical engineering, electronics engineering, and software development costs and support numerous projects covering all of our product lines. They also support our connectivity, remote monitoring, and energy management initiatives. We operate engineering facilities with extensive capabilities at many locations around the world with a focus on new product development, existing product improvement and cost containment. We are committed to innovation, research and development and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-26-004568:mdna:37]
General and administrative. Our general and administrative expenses include personnel costs for accounting, information technology, human resources, legal, general and administrative employees, legal and professional services fees, information technology costs, insurance, travel and entertainment expense, adjustments to contingent acquisition consideration, share-based compensation costs, and other corporate expenses.

[0001437749-26-004568:mdna:38]
Amortization of intangibles. Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-26-004568:mdna:39]
Other (Expense) Income

[0001437749-26-004568:mdna:40]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of deferred financing costs and original issue discount, credit facility commitment fees, and interest accretion on contingent acquisition consideration. Other (expense) income also includes other financial items such as losses on debt refinancing, investment income earned on our cash and cash equivalents, gains/losses on the sale of certain investments, and changes in the fair value of our investment in Wallbox N.V. warrants and equity securities.

[0001437749-26-004568:mdna:41]
Results of Operations

[0001437749-26-004568:mdna:42]
A detailed discussion of the year-over-year changes from the Company's fiscal 2023 results of operations to fiscal 2024 results of operations can be found in the Management's Discussion and Analysis section of the Company's fiscal 2024 Annual Report on Form 10-K filed February 19, 2025.

[0001437749-26-004568:mdna:43]
Year ended December 31, 2025 compared to year ended December 31, 2024

[0001437749-26-004568:mdna:44]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-26-004568:mdna:45]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |  | $ | (86,687 | ) |  |  | -2.0 | % |
| Cost of goods sold |  |  | 2,597,410 |  |  |  | 2,630,208 |  |  |  | (32,798 | ) |  |  | -1.2 | % |
| Gross profit |  |  | 1,611,737 |  |  |  | 1,665,626 |  |  |  | (53,889 | ) |  |  | -3.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 555,358 |  |  |  | 526,446 |  |  |  | 28,912 |  |  |  | 5.5 | % |
| Research and development |  |  | 243,470 |  |  |  | 219,600 |  |  |  | 23,870 |  |  |  | 10.9 | % |
| General and administrative |  |  | 422,211 |  |  |  | 285,095 |  |  |  | 137,116 |  |  |  | 48.1 | % |
| Amortization of intangible assets |  |  | 101,507 |  |  |  | 97,743 |  |  |  | 3,764 |  |  |  | 3.9 | % |
| Total operating expenses |  |  | 1,322,546 |  |  |  | 1,128,884 |  |  |  | 193,662 |  |  |  | 17.2 | % |
| Income from operations |  |  | 289,191 |  |  |  | 536,742 |  |  |  | (247,551 | ) |  |  | -46.1 | % |
| Total other expense, net |  |  | (90,131 | ) |  |  | (127,304 | ) |  |  | 37,173 |  |  |  | 29.2 | % |
| Income before provision for income taxes |  |  | 199,060 |  |  |  | 409,438 |  |  |  | (210,378 | ) |  |  | -51.4 | % |
| Provision for income taxes |  |  | 37,706 |  |  |  | 92,460 |  |  |  | (54,754 | ) |  |  | -59.2 | % |
| Net income |  |  | 161,354 |  |  |  | 316,978 |  |  |  | (155,624 | ) |  |  | -49.1 | % |
| Net income attributable to noncontrolling interests |  |  | 1,800 |  |  |  | 663 |  |  |  | 1,137 |  |  |  | 171.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,554 |  |  | $ | 316,315 |  |  | $ | (156,761 | ) |  |  | -49.6 | % |

[0001437749-26-004568:mdna:46]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-26-004568:mdna:47]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,470,966 |  |  | $ | 3,599,149 |  |  | $ | (128,183 | ) |  |  | -3.6 | % |
| International |  |  | 738,181 |  |  |  | 696,685 |  |  |  | 41,496 |  |  |  | 6.0 | % |
| Total net sales |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |  | $ | (86,687 | ) |  |  | -2.0 | % |

[0001437749-26-004568:mdna:48]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2025 |  |  | Year Ended December 31, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,470,966 |  |  | $ | 23,205 |  |  | $ | 3,494,171 |  |  | $ | 3,599,149 |  |  | $ | 35,932 |  |  | $ | 3,635,081 |  |
| International |  |  | 738,181 |  |  |  | 39,250 |  |  |  | 777,431 |  |  |  | 696,685 |  |  |  | 28,700 |  |  |  | 725,385 |  |
| Intercompany elimination |  |  | - |  |  |  | (62,455 | ) |  |  | (62,455 | ) |  |  | - |  |  |  | (64,632 | ) |  |  | (64,632 | ) |
| Total net sales |  | $ | 4,209,147 |  |  | $ | - |  |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |  | $ | - |  |  | $ | 4,295,834 |  |

[0001437749-26-004568:mdna:49]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 597,915 |  |  | $ | 693,203 |  |  | $ | (95,288 | ) |  |  | -13.7 | % |
| International |  |  | 117,627 |  |  |  | 95,898 |  |  |  | 21,729 |  |  |  | 22.7 | % |
| Total Adjusted EBITDA |  | $ | 715,542 |  |  | $ | 789,101 |  |  | $ | (73,559 | ) |  |  | -9.3 | % |

[0001437749-26-004568:mdna:50]
The following table sets forth our net sales by product class for the periods indicated:

[0001437749-26-004568:mdna:51]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,266,912 |  |  | $ | 2,433,474 |  |  | $ | (166,562 | ) |  |  | -6.8 | % |
| Commercial & Industrial products |  |  | 1,457,385 |  |  |  | 1,389,469 |  |  |  | 67,916 |  |  |  | 4.9 | % |
| Other |  |  | 484,850 |  |  |  | 472,891 |  |  |  | 11,959 |  |  |  | 2.5 | % |
| Total net sales |  | $ | 4,209,147 |  |  | $ | 4,295,834 |  |  | $ | (86,687 | ) |  |  | -2.0 | % |

[0001437749-26-004568:mdna:52]
Net sales.    The decrease in domestic segment sales for the year ended December 31, 2025, was primarily driven by a decrease in residential product sales, most notably in home standby and portable generators as a result of the significantly lower power outage environment together with a strong prior year comparison which included multiple major landed hurricanes. This was partially offset by robust growth in residential energy technology sales, revenue from products sold to data center customers, and higher shipments of C&I products to the industrial distributor and telecom channels.

[0001437749-26-004568:mdna:53]
The increase in international segment sales for the year ended December 31, 2025, was primarily driven by revenue to data center customers, an increase in global sales of controls solutions, and the favorable impact of foreign exchange rates.

[0001437749-26-004568:mdna:54]
In addition, total net sales from non-annualized acquisitions for the year ended December 31, 2025, were $28.3 million, entirely in the domestic segment.

[0001437749-26-004568:mdna:55]
Gross profit.    Gross profit margin for the year ended December 31, 2025 was 38.3% compared to 38.8% for the year ended December 31, 2024. The decrease in gross profit margin was primarily driven by higher inputs costs, unfavorable sales mix, and a certain inventory provision as disclosed in the reconciliation table below. This decline was partially offset by higher price realization.

[0001437749-26-004568:mdna:56]
Operating expenses.    Operating expenses increased $193.7 million, or 17.2%  as compared to the prior year. The increase in operating expenses was driven by higher employee & marketing costs along with higher warranty provision related to the Department of Energy program in Puerto Rico, partially offset by lower incentive-based compensation. 2025 operating expenses also include $142.3 million of legal provisions, settlements, patent related costs, and other costs related to certain legal matters. (see Note 18, “Commitments and Contingencies” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information).  2024 operating expenses included $10.5 million of legal provisions and other costs related to patent and other litigation (see Note 18, “Commitments and Contingencies” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information).

[0001437749-26-004568:mdna:57]
Other expense.    The decrease in other expense, net in 2025 was driven primarily by a reduced loss from the change in fair value of our investment in warrants and equity securities of Wallbox N.V. and a decrease in interest expense, as compared to the prior year.

[0001437749-26-004568:mdna:58]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2025 and 2024 were 18.9%  and 22.6%, respectively. The decrease in the effective tax rate was driven primarily by the impact of certain discrete tax items and their impact on a lower pre-tax income in the current year.

[0001437749-26-004568:mdna:59]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $159.6 million as compared to $316.3 million in the prior year period. The decrease was primarily driven by lower sales and gross margin, along with the higher 2025 operating expenses noted above.

[0001437749-26-004568:mdna:60]
Adjusted EBITDA.    Adjusted EBITDA is defined and reconciled to net income in, “Non-GAAP Measures – Adjusted EBITDA” included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the domestic segment for the year ended December 31, 2025 were 17.1% of domestic segment total sales compared to 19.1% for the year ended December 31, 2024. This margin decline was primarily driven by unfavorable sales mix, higher input costs, and operating deleverage on lower sales volumes, partially offset by increased price cost realization.

[0001437749-26-004568:mdna:61]
Adjusted EBITDA margins for the international segment, before deducting for non-controlling interests, for the year ended December 31, 2025 were 15.1% of international segment total sales compared to 13.2% in the prior year. This margin increase was primarily due to favorable sales mix and price/cost realization.

[0001437749-26-004568:mdna:62]
Adjusted net income.    Adjusted Net Income is defined and reconciled to net income in, “Non-GAAP Measures – Adjusted Net Income” included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income was $376.0 million for the year ended December 31, 2025 compared to $438.5 million for the year ended December 31, 2024, with the decrease primarily due to lower net income in the current year as outlined above, together with the impact of various add-backs in the current and prior years.

[0001437749-26-004568:mdna:63]
Liquidity and Financial Position

[0001437749-26-004568:mdna:64]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-26-004568:mdna:65]
On July 1, 2025, we amended our Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700 million (New Tranche A Term Loan Facility), reducing the Original Revolving Facility borrowing capacity to $1 billion (New Revolving Facility) (collectively the New Credit Agreements) and redefining the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreements), resulting in an interest rate reduction of 0.10%. The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on October 1, 2026. The New Tranche A Term Loan Facility and the New Revolving Facility bear interest at a rate based on SOFR plus an applicable margin between 1.25% and 1.75%, both based on our total leverage ratio and subject to a SOFR floor of 0.0%. As of December 31, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility was 5.12%.

[0001437749-26-004568:mdna:66]
In accordance with ASC 470-50, we capitalized $5.3 million of debt issuance costs related to this refinancing transaction. Additionally, we wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of $0.4 million and expensed $0.8 million of third-party fees as a loss on refinancing of debt.

[0001437749-26-004568:mdna:67]
As of December 31, 2025, there was $494 million outstanding under the Term Loan B Facility, $700 million outstanding under the New Tranche A Term Loan Facility, and there were no borrowings on the New Revolving Facility, leaving $999.3 million of unused capacity, net of outstanding letters of credit.

[0001437749-26-004568:mdna:68]
The Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of December 31, 2025, the interest rate for the Term Loan B Facility was 5.62%. The Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the Term Loan B Facility credit agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of December 31, 2025, our net secured leverage ratio was 1.32 to 1.00, and we were in compliance with all covenants of the Facility. There are no financial maintenance covenants on the Term Loan B Facility. The New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of December 31, 2025, our total leverage ratio was 1.39 to 1.00, and our interest coverage ratio was 11.76 to 1.00. We were also in compliance with all other covenants of the New Credit Agreements as of December 31, 2025.

[0001437749-26-004568:mdna:69]
On February 12, 2024, our Board of Directors approved a stock repurchase program that allowed for the repurchase of up to $500.0 million of our common stock over a twenty-four-month period. Additionally, on February 9, 2026, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaces the prior share repurchase program, which had approximately $199.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-26-004568:mdna:70]
During the years ended December 31, 2025, and 2024, we repurchased 1,109,206 shares of our common stock for $147.9 million, and 1,046,351 shares of our common stock for $152.7 million, respectively. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-26-004568:mdna:71]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer at cost. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 13% of net sales for the years ended December 31, 2025 and 2024. The amount financed by dealers which remained outstanding was $149.7 million and $165.4 million as of December 31, 2025 and 2024, respectively.

[0001437749-26-004568:mdna:72]
See Note 12, “Credit Agreements,” and Note 13, “Stock Repurchase Program,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for more information on our credit agreements and stock repurchase programs. See Note 10, “Leases,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for the maturity schedule of our lease liabilities.

[0001437749-26-004568:mdna:73]
Long-term Liquidity

[0001437749-26-004568:mdna:74]
As of December 31, 2025, we had total liquidity of $1,340.7 million which consisted of $341.4 million of cash and cash equivalents and $999.3 million of availability under our New Revolving Facility.

[0001437749-26-004568:mdna:75]
We believe our cash and cash equivalents, cash flow from operations, availability under our New Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other activities that could potentially drive incremental shareholder value.

[0001437749-26-004568:mdna:76]
Cash Flow

[0001437749-26-004568:mdna:77]
Year ended December 31, 2025 compared to year ended December 31, 2024

[0001437749-26-004568:mdna:78]
The following table summarizes our cash flows by source (use) for the periods presented:

[0001437749-26-004568:mdna:79]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 437,978 |  |  | $ | 741,301 |  |  | $ | (303,323 | ) |  |  | -40.9 | % |
| Net cash used in investing activities |  |  | (172,904 | ) |  |  | (208,712 | ) |  |  | 35,808 |  |  |  | 17.2 | % |
| Net cash used in financing activities |  |  | (212,719 | ) |  |  | (448,835 | ) |  |  | 236,116 |  |  |  | 52.6 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 7,781 |  |  |  | (3,471 | ) |  |  | 11,252 |  |  |  | -324.2 | % |
| Net increase in cash and cash equivalents |  | $ | 60,136 |  |  | $ | 80,283 |  |  | $ | (20,147 | ) |  |  | -25.1 | % |

[0001437749-26-004568:mdna:80]
The decrease in net cash provided by operating activities was primarily driven by a significant reduction in net working capital in the prior year which did not repeat and lower operating earnings as compared to the prior year. This was partially offset by lower cash tax payments.

[0001437749-26-004568:mdna:81]
The $172.9 million net cash used in investing activities for the year ended December 31, 2025 primarily represents cash payments of $169.9 million for the purchase of property and equipment (net of $12.2 million of capital expenditures in accounts payable as of December 31, 2025), $3.0 million for the purchase of long-term investments, and $3.1 million related to other investing activities. These were partially offset by $3.1 million of cash proceeds received from the sale of property and equipment.

[0001437749-26-004568:mdna:82]
The $208.7 million net cash used in investing activities for the year ended December 31, 2024 primarily represents cash payments of $136.7 million for the purchase of property and equipment (net of $11.1 million of capital expenditures in accounts payable as of December 31, 2024), $35.0 million for an incremental minority investment in Wallbox N.V., $2.8 million for a minority investment in Earth Foundry Fund, $1.6 million for a tax equity investment, and $34.7 million collectively for the acquisitions of Huntington, C&I BESS, Ageto, and Wolverine. These were partially offset by $2.0 million of cash proceeds from the sale of our minority interest in Rolling Energy Resources.

[0001437749-26-004568:mdna:83]
The $212.7 million net cash used in financing activities for the year ended December 31, 2025 primarily represents proceeds of $36.4 million from short-term borrowings, $132.8 million from long-term borrowings, $1.0 million of contributions received from the noncontrolling interest holder of a subsidiary, and $4.9 million from the exercise of stock options. These cash proceeds were more than offset by $216.7 million of debt repayments ($48.2 million of short-term borrowings and $168.5 million of long-term borrowings and finance lease obligations), $147.9 million of share repurchases, $5.3 million of debt issuance costs, $2.7 million payment of contingent acquisition consideration, $14.3 million for taxes paid related to equity awards, and $0.9 million of other financing activities.

[0001437749-26-004568:mdna:84]
The $448.8 million net cash used in financing activities for the year ended December 31, 2024 primarily represents $849.1 million of debt repayments ($54.5 million of short-term borrowings and $794.6 million of long-term borrowings and finance lease obligations), $152.7 million of stock repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, $7.4 million of payments for deferred acquisition consideration, $24.8 million for taxes paid related to equity awards, and $3.6 million of payments for debt issuance costs related to our amended Tranche B Term Loan credit agreement refinancing. These uses of cash were partially offset by proceeds of $29.2 million from short-term borrowings, $541.5 million from long-term borrowings, and $27.6 million from the exercise of stock options.

[0001437749-26-004568:mdna:85]
Senior Secured Credit Facilities

[0001437749-26-004568:mdna:86]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for information on our senior secured credit facilities.

[0001437749-26-004568:mdna:87]
Covenant Compliance

[0001437749-26-004568:mdna:88]
Our Term Loans restrict the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. Our Term Loans also contain other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness, and modifications of our organizational documents. The New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, an interest coverage ratio above 3.00 to 1.00, and may require an excess cash flow payment. As of December 31, 2025, the Company’s total leverage ratio was 1.39 to 1.00, and the Company's interest coverage ratio was 11.76 to 1.00. The Company was not required to make an excess cash flow payment as of December 31, 2025. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of December 31, 2025.

[0001437749-26-004568:mdna:89]
Our Term Loans contain customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Amended Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the Term Loans to automatically become immediately due and payable.

[0001437749-26-004568:mdna:90]
The Revolving Facility also contains covenants and events of default substantially similar to those in the Term Loans, as described above.

[0001437749-26-004568:mdna:91]
Capital Expenditures

[0001437749-26-004568:mdna:92]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, internal use software, IT systems & infrastructure, and upgrades. Capital expenditures were $169.9 million, $136.7 million, and $129.1 million in the years ended December 31, 2025, 2024 and 2023, respectively, and were funded primarily from cash from operations.

[0001437749-26-004568:mdna:93]
Critical Accounting Policies and Estimates

[0001437749-26-004568:mdna:94]
In preparing the financial statements, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. generally accepted accounting principles (U.S. GAAP), and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes. The following is a discussion of critical accounting estimates in each of these areas.

[0001437749-26-004568:mdna:95]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-26-004568:mdna:96]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the underlying business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-26-004568:mdna:97]
In our October 31, 2025 impairment test calculation, the Clean Energy reporting unit had an estimated fair value that exceeded its carrying value by approximately 20%. The carrying value of the Clean Energy goodwill was $79.0 million. Key financial assumptions utilized to determine the fair value of the reporting unit include accelerating long-term demand growth due to a confluence of factors expected to drive power prices meaningfully higher in the future, cost improvements in renewable energy and energy storage technologies which are expected to improve profit margins, the development and launch of additional products, a 3% terminal growth rate and a 13.6% discount rate. The reporting unit’s fair value would approximate its carrying value with a 100 basis point increase in the discount rate or a 210 basis point reduction in the compound annual sales growth rate and terminal growth rate.

[0001437749-26-004568:mdna:98]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-26-004568:mdna:99]
|  | ● | a rising interest rate environment; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-26-004568:mdna:100]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-26-004568:mdna:101]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-26-004568:mdna:102]
|  | ● | a significant adverse change in legal factors, the business climate, or regulatory environment; |

[0001437749-26-004568:mdna:103]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-26-004568:mdna:104]
|  | ● | an inability to gain market share in our markets; |

[0001437749-26-004568:mdna:105]
|  | ● | disruptions to the Company’s business; |

[0001437749-26-004568:mdna:106]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-26-004568:mdna:107]
|  | ● | loss of key management and employees |
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-26-004568:mdna:108]
|  | ● | business divestitures. |

[0001437749-26-004568:mdna:109]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition. We performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2025, 2024 and 2023, and found no impairment.

[0001437749-26-004568:mdna:110]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other indefinite-lived intangible assets.

[0001437749-26-004568:mdna:111]
Income Taxes

[0001437749-26-004568:mdna:112]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimates of income taxes payable, deferred income taxes and the effective tax rate are based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known. In assessing the net realizable value of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-26-004568:mdna:113]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and income tax positions.

[0001437749-26-004568:mdna:114]
New Accounting Standards

[0001437749-26-004568:mdna:115]
For information on new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-26-004568:mdna:116]
Non-GAAP Measures

[0001437749-26-004568:mdna:117]
Adjusted EBITDA

[0001437749-26-004568:mdna:118]
To supplement our consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Amended Credit Agreement.

[0001437749-26-004568:mdna:119]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes certain items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-26-004568:mdna:120]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-26-004568:mdna:121]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-26-004568:mdna:122]
|  | ● | as a target for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-26-004568:mdna:123]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-26-004568:mdna:124]
|  | ● | in communications with our Board and investors concerning our financial performance. |

[0001437749-26-004568:mdna:125]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-26-004568:mdna:126]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance excluding the impact of items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-26-004568:mdna:127]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-26-004568:mdna:128]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-26-004568:mdna:129]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board. These adjustments eliminate the impact of a number of items that:

[0001437749-26-004568:mdna:130]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, and mark-to-market gains and losses on a minority investment; |

[0001437749-26-004568:mdna:131]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-26-004568:mdna:132]
|  | ● | are non-cash in nature, such as share-based compensation expense; or |
|  | ● | the provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, including but not limited to large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. |

[0001437749-26-004568:mdna:133]
We explain in more detail in the footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-26-004568:mdna:134]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-26-004568:mdna:135]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-26-004568:mdna:136]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-26-004568:mdna:137]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-26-004568:mdna:138]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-26-004568:mdna:139]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-26-004568:mdna:140]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-26-004568:mdna:141]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-26-004568:mdna:142]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-26-004568:mdna:143]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-26-004568:mdna:144]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,554 |  |  | $ | 316,315 |  |  | $ | 214,606 |  |
| Net income attributable to noncontrolling interests |  |  | 1,800 |  |  |  | 663 |  |  |  | 2,514 |  |
| Net income |  |  | 161,354 |  |  |  | 316,978 |  |  |  | 217,120 |  |
| Interest expense |  |  | 70,697 |  |  |  | 89,713 |  |  |  | 97,627 |  |
| Depreciation and amortization |  |  | 194,835 |  |  |  | 171,768 |  |  |  | 166,602 |  |
| Provision for income taxes |  |  | 37,706 |  |  |  | 92,460 |  |  |  | 73,180 |  |
| Non-cash write-down and other adjustments (a) |  |  | 6,636 |  |  |  | 4,757 |  |  |  | (5,953 | ) |
| Non-cash share-based compensation expense (b) |  |  | 49,947 |  |  |  | 49,248 |  |  |  | 35,492 |  |
| Transaction costs and credit facility fees (c) |  |  | 3,976 |  |  |  | 5,097 |  |  |  | 4,054 |  |
| Business optimization and other charges (d) |  |  | 7,301 |  |  |  | 4,752 |  |  |  | 10,551 |  |
| Provision for legal, regulatory, and other costs (e) |  |  | 157,981 |  |  |  | 10,931 |  |  |  | 38,490 |  |
| Change in fair value of investments (f) |  |  | 20,610 |  |  |  | 38,006 |  |  |  | - |  |
| Loss on refinancing of debt (g) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | - |  |
| Other |  |  | 3,274 |  |  |  | 530 |  |  |  | 696 |  |
| Adjusted EBITDA |  |  | 715,542 |  |  |  | 789,101 |  |  |  | 637,859 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,648 |  |  |  | 1,175 |  |  |  | 4,687 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 712,894 |  |  | $ | 787,926 |  |  | $ | 633,172 |  |

[0001437749-26-004568:mdna:145]
(a) Represents the following non-cash charges, gains, and other adjustments: (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-26-004568:mdna:146]
|  | ● | The gains/losses on disposition of assets other than in the ordinary course of business and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-26-004568:mdna:147]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-26-004568:mdna:148]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value of certain assets at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price. |

[0001437749-26-004568:mdna:149]
(b) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting period.

[0001437749-26-004568:mdna:150]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-26-004568:mdna:151]
(d) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-26-004568:mdna:152]
(e) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-26-004568:mdna:153]
•  Legal expenses, judgments, and settlements related to certain patent lawsuits - $7.5 million in 2025; $9.2 million in 2024; $27.3 million in 2023. 
    •  Legal expenses and settlements related to certain class action lawsuits - $22.7 million in 2025, which includes a $15.0 million provision for a multi-district class action settlement related to clean energy products; $1.3 million in 2024; $1.0 million in 2023.

[0001437749-26-004568:mdna:154]
•  Legal expenses related to certain government inquiries and other significant matters - $7.6 million in 2025.
    •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in 2024; $4.4 million additional customer support costs in 2023.
   •  A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in 2023.

[0001437749-26-004568:mdna:155]
•  A provision of $104.5 million, net in the fourth quarter of 2025 for a settlement agreement (in principle) related to a certain portable generator product liability case deemed outside the ordinary course of routine litigation for the Company.

[0001437749-26-004568:mdna:156]
•  A $15.6 million net inventory provision in the fourth quarter of 2025 related to the settlement of a contract dispute with a supplier for a discontinued product.

[0001437749-26-004568:mdna:157]
(f) Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-26-004568:mdna:158]
(g) For the year ended December 31, 2025, the loss represents the third-party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Tranche A Term Loan Facility and Revolving Debt Facility.  For the year ended December 31, 2024, the loss represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-26-004568:mdna:159]
Adjusted Net Income

[0001437749-26-004568:mdna:160]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests, as set forth in the reconciliation table below.

[0001437749-26-004568:mdna:161]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-26-004568:mdna:162]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt.

[0001437749-26-004568:mdna:163]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-26-004568:mdna:164]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-26-004568:mdna:165]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-26-004568:mdna:166]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-26-004568:mdna:167]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-26-004568:mdna:168]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,554 |  |  | $ | 316,315 |  |  | $ | 214,606 |  |
| Net income attributable to noncontrolling interests |  |  | 1,800 |  |  |  | 663 |  |  |  | 2,514 |  |
| Net income |  |  | 161,354 |  |  |  | 316,978 |  |  |  | 217,120 |  |
| Amortization of intangible assets |  |  | 101,507 |  |  |  | 97,743 |  |  |  | 104,194 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 2,380 |  |  |  | 3,242 |  |  |  | 3,885 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 1,797 |  |  |  | 2,717 |  |  |  | 2,089 |  |
| Loss/(gain) attributable to business or asset dispositions (b) |  |  | 4,295 |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (c) |  |  | 7,301 |  |  |  | 4,752 |  |  |  | 10,551 |  |
| Provision for legal, regulatory, and other costs (c) |  |  | 157,981 |  |  |  | 10,931 |  |  |  | 38,490 |  |
| Change in fair value of investments (c) |  |  | 20,610 |  |  |  | 38,006 |  |  |  | - |  |
| Loss on refinancing of debt (c) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | - |  |
| Tax effect of add backs |  |  | (80,658 | ) |  |  | (40,173 | ) |  |  | (38,384 | ) |
| Adjusted net income |  |  | 377,792 |  |  |  | 439,122 |  |  |  | 337,826 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,800 |  |  |  | 663 |  |  |  | 2,514 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 375,992 |  |  | $ | 438,459 |  |  | $ | 335,312 |  |

[0001437749-26-004568:mdna:169]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-26-004568:mdna:170]
(b) Represents losses/(gains) attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-26-004568:mdna:171]
(c) See reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc. above.
