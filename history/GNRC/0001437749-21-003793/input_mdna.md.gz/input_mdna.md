# GNRC MD&A — 0001437749-21-003793


## mdna

[0001437749-21-003793:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-21-003793:mdna:2]
Overview

[0001437749-21-003793:mdna:3]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid services solutions, and other power products serving the residential, light commercial and industrial markets.

[0001437749-21-003793:mdna:4]
Power generation and storage is a key focus of the Company, which differentiates us from our competitors who also have broad operations outside of the power equipment market. As the only significant market participant with a primary focus on these products, we maintain one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators; as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost-effective natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in distributed generation projects. The Company in recent years has been evolving its business model to also focus on clean energy products, solutions, and services. In 2019, we began providing energy storage systems as a clean energy solution for residential use that capture and store electricity from solar panels or other power sources and help reduce home energy costs while also protecting homes from shorter-duration power outages. During 2020, we entered the market for grid services involving distributed energy optimization and control software that helps support the operational stability of the world's power grids. We have also been focused on connecting the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product lifecycle. The strategic focus on expanding the connectivity of our products will broaden our monitoring capabilities and also enable the increasing utilization of this equipment as distributed energy resources as the nascent market for grid-services expands over the next several years. Overall, as the traditional centralized utility model evolves over time, we believe that a cleaner, more decentralized grid infrastructure will build-out, and Generac's energy technology solutions are strategically positioned to participate in this future "Grid 2.0".

[0001437749-21-003793:mdna:5]
In addition to power generation and storage solutions, other products that we design and manufacture include light towers which provide temporary lighting for various end markets, and a broad and growing product line of outdoor power equipment for residential and commercial use.

[0001437749-21-003793:mdna:6]
Impact of COVID-19 on Our Business

[0001437749-21-003793:mdna:7]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty. Our management team has been very proactive in addressing the impact of COVID-19 on our business. The situation continues to evolve, and we are working to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have, to-date, been operational. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-21-003793:mdna:8]
The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers.

[0001437749-21-003793:mdna:9]
Demand

[0001437749-21-003793:mdna:10]
The COVID-19 pandemic has created significant uncertainty within various global markets that we serve. Several areas of our business have been and may continue to be negatively impacted, in particular our Commercial and Industrial (C&I) products around the world. The decline in oil prices has impacted our C&I mobile products demand significantly as national rental customers are deferring their capital spending. C&I stationary product shipments through our North American distributor channel and our Telecom customers have slowed during 2020 due to declines in quoting activity. Additionally, the COVID-19 pandemic has caused a broad-based sharp drop in global demand for our C&I products in our International segment, which magnified the slower economic growth and geopolitical headwinds that were already being experienced by our international business. Given the magnitude of the downturn in demand for C&I products, we initiated a number of meaningful cost-cutting actions for this part of our business during the second quarter of 2020 to better align our cost structure with customer demand. We are continuing to monitor these negative impacts on our C&I product demand closely and may implement additional measures in response.

[0001437749-21-003793:mdna:11]
With regard to our Residential products, historical experience and our current year results have shown that demand for Residential products can decouple from broader economic trends as these products are largely driven by power outages. The aging and underinvested electrical grid in the U.S. continues to be more vulnerable to elevated power outages across the country. As the vast majority of U.S. citizens are spending much more time at home due to the pandemic, it is becoming more essential to have a backup power strategy, especially as homeowners are doing more critical activities like working and learning from home. In addition, with California emerging as a major market for back-up power and our entrance into clean energy, these incremental growth drivers have helped to more than offset the impact of lower consumer spending due to COVID-19.

[0001437749-21-003793:mdna:12]
Supply Chain and Operations

[0001437749-21-003793:mdna:13]
As a result of the COVID-19 pandemic, governmental authorities have implemented and are continuing to implement numerous and constantly evolving measures to try to contain the virus, such as travel bans and restrictions, limits on gatherings, quarantines, and business shutdowns. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience increased employee absences at several of our production facilities. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time.

[0001437749-21-003793:mdna:14]
The COVID-19 pandemic has disrupted the global supply chain and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant impacts or interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies. The COVID-19 pandemic has also impacted the global logistics network. Although we have experienced inbound and outbound logistics delays and increased costs in moving shipments across several regions, the impact to our business thus far has not been significant. This could change if freight carriers are delayed or not able to operate.

[0001437749-21-003793:mdna:15]
Liquidity

[0001437749-21-003793:mdna:16]
Although the COVID-19 outbreak has created uncertain market conditions, we believe our business model, current cash balance, projected cash flow generation, and availability under our ABL credit facility provide us with a strong balance sheet and liquidity position. This financial strength allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-21-003793:mdna:17]
Business Drivers and Operational Factors

[0001437749-21-003793:mdna:18]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-21-003793:mdna:19]
Business Drivers and Trends

[0001437749-21-003793:mdna:20]
Our performance is affected by the demand for reliable power generation products, energy storage systems, grid services solutions, and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-21-003793:mdna:21]
Key Mega-trends:    There are some important mega-trends that we believe represent major themes that will drive significant secular growth opportunities across our business over the long term. “Grid 2.0”, which is the evolution of the traditional electrical utility model, includes the decentralization and de-carbonization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward.  Attitudes around global warming and climate change are shifting, which includes the expectation of more severe weather driving increased power outage activity.  Natural gas is expected to be a key fuel of the future with the abundance of supply globally leading to increasing demand for natural gas generators in applications beyond standby power.  The legacy infrastructure is in need of a major investment cycle to rebuild and upgrade aging networks and systems including transportation, water and power.  The wireless telecommunications infrastructure is shifting to the next generation “5G” architecture, which will enable new technologies requiring significant improvement in network uptime through backup power solutions.

[0001437749-21-003793:mdna:22]
The onset of the COVID-19 pandemic in early 2020 has led to a new and emerging mega-trend that we refer to as “Home as a Sanctuary,” where millions of people are working, learning, shopping, entertaining, and in general, spending more time at home.  As working adults spend much more time working from home and school-age children learning from home, they become more sensitive to power outages due to lost productivity.  These trends combined with ongoing elevated power outage activity has led to a significant increased awareness, importance and need for backup power security.  As a result of spending more time at home, homeowners are also investing more into home improvement projects and outdoor project activity, which is leading to increased and broad-based demand for home standby generators as well as chore products used in a variety of property maintenance applications.

[0001437749-21-003793:mdna:23]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are still only approximately 5.0% of the addressable market of homes in the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and, as a result, these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to a variety of factors, including the impending rollout of next-generation 5G wireless networks enabling new technologies and the growing importance for critical communications being transmitted over wireless networks. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-21-003793:mdna:24]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, there have been a number of major outage events that occurred over the past decade that drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both the year they occurred along with the following subsequent year. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-21-003793:mdna:25]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the acquisitions of Pika Energy and Neurio Technologies, along with the subsequent introduction of complete energy storage systems - marketed under the names PWRcell™ and PWRview™. We believe the electric utility landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets, which enabled us to quickly ramp shipments for these clean energy solutions during 2020, and we believe will position Generac as a key participant going forward. Although different from the emergency backup power space, we believe this market will develop similarly as the home standby generator market has over the past two decades given both products can provide power resiliency to homeowners. We expect to further advance our growing capabilities for energy storage systems including product development, sourcing, distribution, and marketing, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential energy storage, monitoring and management markets.

[0001437749-21-003793:mdna:26]
California market for backup power increasing.    Over the past two years, utilities in the state of California have executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were pro-active measures to prevent their equipment from potentially causing catastrophic wildfires during the dry and windy season of the year. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, have resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators still stand at only approximately 1%. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity are some of the highest in the U.S., and the regulatory environment is increasingly mandating renewable energy on new construction applications.

[0001437749-21-003793:mdna:27]
Impact of residential investment cycle.    The market for residential generators and energy storage systems is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns. Finally, the existence of renewable energy mandates and investment tax credits and other subsidies can also have an impact on the demand for energy storage systems.

[0001437749-21-003793:mdna:28]
Impact of business capital investment and other economic cycles.    The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve.

[0001437749-21-003793:mdna:29]
Factors Affecting Results of Operations

[0001437749-21-003793:mdna:30]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-21-003793:mdna:31]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-21-003793:mdna:32]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-21-003793:mdna:33]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 21% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 26% to 28% in the third quarter and 27% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-21-003793:mdna:34]
During 2020, elevated power outage activity and the emergence of the "Home as a Sanctuary" trend driven by the COVID-19 pandemic led to a significant increase in demand for home standby generators.  This increased demand has resulted in extended lead times for these products as of December 31, 2020, and as a result, our net sales during 2021 are expected to be more level-loaded throughout the year relative to historical seasonal patterns.

[0001437749-21-003793:mdna:35]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease. Interest expense decreased during 2020 compared to 2019, primarily due to lower LIBOR rates and lower outstanding borrowings. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-21-003793:mdna:36]
Factors influencing provision for income taxes and cash income taxes paid.    On December 22, 2017, the U.S. government enacted the Tax Cuts and Jobs Act, which significantly changed how the U.S. taxes corporations. Since enactment, the U.S. Treasury Department (Treasury) issued several new regulations and other guidance which we have incorporated into our final tax calculations.

[0001437749-21-003793:mdna:37]
As of December 31, 2020, we had approximately $102 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006. This remaining balance will fully amortize in our 2021 tax return, resulting in approximately $26 million of cash tax savings during 2021. Beginning in 2022, this tax amortization will no longer exist, resulting in a higher cash tax obligation on a go-forward basis.

[0001437749-21-003793:mdna:38]
Components of Net Sales and Expenses

[0001437749-21-003793:mdna:39]
Net Sales

[0001437749-21-003793:mdna:40]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, light commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, remote monitoring, grid optimization, installation and maintenance services. However, these services accounted for less than two percent of our net sales for the year ended December 31, 2020. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-21-003793:mdna:41]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 6% of our sales, and our top ten customers representing less than 24% of our net sales for the year ended December 31, 2020.

[0001437749-21-003793:mdna:42]
Costs of Goods Sold

[0001437749-21-003793:mdna:43]
The principal elements of costs of goods sold are component parts, raw materials, freight, factory overhead and labor. Component parts and raw materials comprised approximately 75% of costs of goods sold for the year ended December 31, 2020. The principal component parts are engines, alternators, and batteries. We design and manufacture air-cooled engines for certain of our generators up to 24kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-21-003793:mdna:44]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-21-003793:mdna:45]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-21-003793:mdna:46]
Operating Expenses

[0001437749-21-003793:mdna:47]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs, taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-21-003793:mdna:48]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard assurance warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Standard warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising, promotional expenses and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, opportunities to create market awareness for our products, and general brand awareness marketing efforts.

[0001437749-21-003793:mdna:49]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. They also support our connectivity, remote monitoring, and energy monitoring initiatives. We operate engineering facilities with extensive capabilities at many locations globally and employ over 500 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-21-003793:mdna:50]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-21-003793:mdna:51]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-21-003793:mdna:52]
Other (Expense) Income

[0001437749-21-003793:mdna:53]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and cash flows related to interest rate swap agreements. Other (expense) income also includes other financial items such as losses on extinguishment of debt, loss on pension settlement, and investment income earned on our cash and cash equivalents.

[0001437749-21-003793:mdna:54]
Results of Operations

[0001437749-21-003793:mdna:55]
A detailed discussion of the year-over-year changes from the Company's fiscal 2018 to fiscal 2019 can be found in the Management's Discussion and Analysis section of the Company's fiscal 2019 Annual Report on Form 10-K filed February 25, 2020.

[0001437749-21-003793:mdna:56]
Year ended December 31, 2020 compared to year ended December 31, 2019

[0001437749-21-003793:mdna:57]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-21-003793:mdna:58]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |  | $ | 280,864 |  |  |  | 12.7 | % |
| Cost of goods sold |  |  | 1,527,546 |  |  |  | 1,406,584 |  |  |  | 120,962 |  |  |  | 8.6 | % |
| Gross profit |  |  | 957,654 |  |  |  | 797,752 |  |  |  | 159,902 |  |  |  | 20.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 246,373 |  |  |  | 217,683 |  |  |  | 28,690 |  |  |  | 13.2 | % |
| Research and development |  |  | 80,251 |  |  |  | 68,394 |  |  |  | 11,857 |  |  |  | 17.3 | % |
| General and administrative |  |  | 119,644 |  |  |  | 110,868 |  |  |  | 8,776 |  |  |  | 7.9 | % |
| Amortization of intangible assets |  |  | 32,280 |  |  |  | 28,644 |  |  |  | 3,636 |  |  |  | 12.7 | % |
| Total operating expenses |  |  | 478,548 |  |  |  | 425,589 |  |  |  | 52,959 |  |  |  | 12.4 | % |
| Income from operations |  |  | 479,106 |  |  |  | 372,163 |  |  |  | 106,943 |  |  |  | 28.7 | % |
| Total other expense, net |  |  | (32,915 | ) |  |  | (52,556 | ) |  |  | 19,641 |  |  |  | -37.4 | % |
| Income before provision for income taxes |  |  | 446,191 |  |  |  | 319,607 |  |  |  | 126,584 |  |  |  | 39.6 | % |
| Provision for income taxes |  |  | 98,973 |  |  |  | 67,299 |  |  |  | 31,674 |  |  |  | 47.1 | % |
| Net income |  |  | 347,218 |  |  |  | 252,308 |  |  |  | 94,910 |  |  |  | 37.6 | % |
| Net income attributable to noncontrolling interests |  |  | (3,358 | ) |  |  | 301 |  |  |  | (3,659 | ) |  |  | -1215.6 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 350,576 |  |  | $ | 252,007 |  |  | $ | 98,569 |  |  |  | 39.1 | % |

[0001437749-21-003793:mdna:59]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-21-003793:mdna:60]
|  |  | Net Sales by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,088,808 |  |  | $ | 1,742,898 |  |  | $ | 345,910 |  |  |  | 19.8 | % |
| International |  |  | 396,392 |  |  |  | 461,438 |  |  |  | (65,046 | ) |  |  | -14.1 | % |
| Total net sales |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |  | $ | 280,864 |  |  |  | 12.7 | % |

[0001437749-21-003793:mdna:61]
|  |  | Adjusted EBITDA by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 563,394 |  |  | $ | 428,667 |  |  | $ | 134,727 |  |  |  | 31.4 | % |
| International |  |  | 20,379 |  |  |  | 25,448 |  |  |  | (5,069 | ) |  |  | -19.9 | % |
| Total Adjusted EBITDA |  | $ | 583,773 |  |  | $ | 454,115 |  |  | $ | 129,658 |  |  |  | 28.6 | % |

[0001437749-21-003793:mdna:62]
The following table sets forth our product class information for the periods indicated:

[0001437749-21-003793:mdna:63]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,556,501 |  |  | $ | 1,143,723 |  |  | $ | 412,778 |  |  |  | 36.1 | % |
| Commercial & industrial products |  |  | 701,751 |  |  |  | 871,595 |  |  |  | (169,844 | ) |  |  | -19.5 | % |
| Other |  |  | 226,948 |  |  |  | 189,018 |  |  |  | 37,930 |  |  |  | 20.1 | % |
| Total net sales |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |  | $ | 280,864 |  |  |  | 12.7 | % |

[0001437749-21-003793:mdna:64]
Net sales.    The increase in Domestic segment sales for the year ended December 31, 2020 was primarily due to strong growth in shipments of home standby generators and portable generators as elevated outage activity and nationwide stay-at-home orders heightened consumer awareness of power reliability concerns. Chore products sold directly to consumers were also strong during the current year as homeowners increased outdoor project activity. In addition, shipments of the PWRcell™ energy storage system had a strong impact on growth as we expanded our presence in the rapidly developing solar-plus-storage market. This broad-based residential products growth was partially offset by continued weakness in sales of C&I mobile products due to the ongoing impacts from the COVID-19 pandemic, as well as lower shipments of C&I products to national telecom customers as compared to a strong prior year comparison.

[0001437749-21-003793:mdna:65]
The decrease in International segment sales for the year ended December 31, 2020 was primarily driven by a broad-based sharp drop in global demand caused by the COVID-19 pandemic and its impact on the C&I power generation market in certain key regions of the world, which magnified the slower economic growth and geopolitical headwinds already being experienced prior to the pandemic. However, the year-over-year decline in the fourth quarter was at a notably lesser rate relative to recent quarters as certain regions are beginning to show signs of recovery.

[0001437749-21-003793:mdna:66]
Total contribution from non-annualized recent acquisitions for the year ended December 31, 2020 was $32.4 million.

[0001437749-21-003793:mdna:67]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $350.6 million as compared to $252.0 million in the prior year period. The current year net income includes $11.5 million of pre-tax charges taken in the second quarter of 2020 relating to business optimization, restructuring, and other costs to address the impact of the COVID-19 pandemic and the decline in oil prices on end markets for our products. The cost reduction actions taken include certain headcount reductions, non-cash asset write-downs, and other charges. The charges, which primarily relate to C&I products, consist of $6.3 million classified within costs of goods sold and $5.2 million classified within operating expenses.

[0001437749-21-003793:mdna:68]
Gross profit.    Gross profit margin for the year ended December 31, 2020 was 38.5% compared to 36.2% for the year ended December 31, 2019. The overall increase in gross profit margin reflected a favorable sales mix towards significantly higher shipments of residential products, along with a lower mix of C&I products. The current year period includes the impact of the aforementioned $6.3 million of charges classified within costs of goods sold.

[0001437749-21-003793:mdna:69]
Operating expenses.    Operating expenses increased $53.0 million, or 12.4%, as compared to the prior year. The current year period includes the impact of the aforementioned $5.2 million of charges classified within operating expenses. In addition, the increase in operating expenses was primarily driven by higher variable expenses from the significant increase in sales volume, incremental spend related to clean energy products and the impact of acquisitions, higher employee costs, and additional intangible amortization. These increases were partially offset by a reduction in operating expenses as a result of the restructuring actions initiated in the second quarter of 2020 and an overall reduction in controllable operating expenses.

[0001437749-21-003793:mdna:70]
Other expense.    The decrease in other expense, net was driven by a reduction in interest expense due to lower LIBOR rates and lower outstanding borrowings in the current year, as well as a $10.9 million pre-tax settlement charge related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019.

[0001437749-21-003793:mdna:71]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2020 and 2019 were 22.2% and 21.1%, respectively. The increase in the effective tax rate is primarily due to a reduction in the prior year U.S. state income tax expense, which did not repeat in the current year, as well as higher earnings in the current year, which dilute the impact of discrete tax benefits.

[0001437749-21-003793:mdna:72]
Adjusted EBITDA.    Adjusted EBITDA is defined in, and there is a reconciliation of net income to Adjusted EBITDA attributable to the Company in, "Non-GAAP Measures - Adjusted EBITDA" included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2020 were 27.0% of net sales as compared to 24.6% of net sales for the year ended December 31, 2019. Adjusted EBITDA margin in the current year benefited from favorable sales mix and higher operating leverage from the significant revenue growth, partially offset by the aforementioned higher operating expense investments.

[0001437749-21-003793:mdna:73]
Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2020 were 5.1% of net sales as compared to 5.5% of net sales for the year ended December 31, 2019. Decreased operating leverage on lower sales volumes was the primary contributor to the margin decline, partially offset by lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020.

[0001437749-21-003793:mdna:74]
Adjusted net income.    Adjusted Net Income is defined in, and there is a reconciliation of net income to Adjusted Net Income attributable to the Company in, "Non-GAAP Measures - Adjusted Net Income" included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income of $412.2 million for the year ended December 31, 2020 increased 29.7% from $317.8 million for the year ended December 31, 2019, due to the factors outlined above together with an increase in the cash income tax rate from 15.0% in 2019 to 17.9% in 2020.

[0001437749-21-003793:mdna:75]
Liquidity and Financial Position

[0001437749-21-003793:mdna:76]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-21-003793:mdna:77]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan currently matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of December 31, 2020, our secured leverage ratio was 1.12 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-003793:mdna:78]
Our credit agreements also provide for the $300.0 million ABL Facility, which matures on June 12, 2023. As of December 31, 2020, there was no outstanding balance under the ABL Facility, leaving $299.6 million of availability, net of outstanding letters of credit. We were in compliance with all covenants of the ABL Facility as of December 31, 2020.

[0001437749-21-003793:mdna:79]
As of December 31, 2020, we had $954.7 million of liquidity comprised of $655.1 million of cash and cash equivalents and $299.6 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan until December 2026. We believe we have a strong liquidity position that allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-21-003793:mdna:80]
In September 2018, our Board of Directors approved a $250.0 million stock repurchase program, which expired in October 2020. In September 2020, the Board of Directors approved another stock repurchase program, which commenced on October 27, 2020, and under which we may repurchase $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the year ended December 31, 2020, no repurchases were made. Since the inception of all stock repurchase programs starting in August 2015, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-21-003793:mdna:81]
Long-term Liquidity

[0001437749-21-003793:mdna:82]
We believe that our cash and cash equivalents, cash flow from operations, and availability under our ABL Facility and other short-term lines of credit provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay interest and principal on our outstanding debt, as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-21-003793:mdna:83]
Cash Flow

[0001437749-21-003793:mdna:84]
Year ended December 31, 2020 compared to year ended December 31, 2019

[0001437749-21-003793:mdna:85]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-21-003793:mdna:86]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 486,533 |  |  | $ | 308,887 |  |  | $ | 177,646 |  |  |  | 57.5 | % |
| Net cash used in investing activities |  |  | (124,095 | ) |  |  | (170,078 | ) |  |  | 45,983 |  |  |  | -27.0 | % |
| Net cash used in financing activities |  |  | (30,428 | ) |  |  | (41,918 | ) |  |  | 11,490 |  |  |  | -27.4 | % |

[0001437749-21-003793:mdna:87]
The increase in net cash provided by operating activities was primarily driven by higher sales volumes and resulting higher operating earnings in the current year, as well as a significant working capital investment that was made in the prior year which did not repeat in the current year.

[0001437749-21-003793:mdna:88]
Net cash used in investing activities for the year ended December 31, 2020 primarily represented cash payments of $64.8 million related to the acquisition of businesses and $62.1 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2019 primarily consisted of cash payments of $112.0 million related to the acquisition of businesses and $60.8 million for the purchase of property and equipment.

[0001437749-21-003793:mdna:89]
Net cash used in financing activities for the year ended December 31, 2020 primarily consisted of $282.5 million of debt repayments ($277.7 million of short-term borrowings and $4.8 million of long-term borrowings), $14.9 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These payments were partially offset by $257.9 million cash proceeds from borrowings ($257.6 million for short-term borrowings and $0.3 million for long-term borrowings) and $13.1 million of proceeds from the exercise of stock options.

[0001437749-21-003793:mdna:90]
Net cash used in financing activities for the year ended December 31, 2019 primarily consisted of $112.6 million of debt repayments ($53.1 million of long-term borrowings and $59.5 million of short-term borrowings), $6.4 million of taxes paid related to equity awards, and $5.5 million of contingent consideration for acquired businesses. These payments were partially offset by $75.0 million of cash proceeds from borrowings ($73.3 million for short-term borrowings and $1.7 million for long-term borrowings) and $9.4 million of proceeds from the exercise of stock options.

[0001437749-21-003793:mdna:91]
Senior Secured Credit Facilities

[0001437749-21-003793:mdna:92]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-21-003793:mdna:93]
Covenant Compliance

[0001437749-21-003793:mdna:94]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-21-003793:mdna:95]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-21-003793:mdna:96]
The ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-21-003793:mdna:97]
Contractual Obligations

[0001437749-21-003793:mdna:98]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2020, using the interest rates in effect as of that date:

[0001437749-21-003793:mdna:99]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including current portion (1) |  | $ | 833,990 |  |  | $ | 1,836 |  |  | $ | 1,951 |  |  | $ | 142 |  |  | $ | 830,061 |  |
| Finance lease obligations, including current portion |  |  | 27,371 |  |  |  | 2,312 |  |  |  | 3,939 |  |  |  | 2,517 |  |  |  | 18,603 |  |
| Interest on long-term debt and finance lease obligations |  |  | 111,035 |  |  |  | 16,553 |  |  |  | 34,903 |  |  |  | 34,641 |  |  |  | 24,938 |  |
| Operating leases |  |  | 71,706 |  |  |  | 19,530 |  |  |  | 27,654 |  |  |  | 12,811 |  |  |  | 11,711 |  |
| Total contractual cash obligations |  | $ | 1,044,102 |  |  | $ | 40,231 |  |  | $ | 68,447 |  |  | $ | 50,111 |  |  | $ | 885,313 |  |

[0001437749-21-003793:mdna:100]
(1) The Term Loan matures on December 13, 2026. The ABL Facility provides for a $300.0 million senior secured ABL revolving credit facility, which matures on June 12, 2023. There was no outstanding balance on the ABL Facility as of December 31, 2020.

[0001437749-21-003793:mdna:101]
Capital Expenditures

[0001437749-21-003793:mdna:102]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, IT systems & infrastructure and upgrades. Capital expenditures were $62.1 million, $60.8 million, and $47.6 million for the years ended December 31, 2020, 2019 and 2018, respectively, and were funded through cash from operations.

[0001437749-21-003793:mdna:103]
As a result of increased demand for our products and in order to expand manufacturing and distribution capacity, we have entered into an agreement to purchase an approximate 420,000 square foot building in Trenton, South Carolina. The transaction funded in February 2021.

[0001437749-21-003793:mdna:104]
Off-Balance Sheet Arrangements

[0001437749-21-003793:mdna:105]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-21-003793:mdna:106]
Total dealer purchases financed under this arrangement accounted for approximately 12% and 11% of net sales for the years ended December 31, 2020 and 2019, respectively. The amount financed by dealers which remained outstanding was $55.6 million and $49.6 million as of December 31, 2020 and 2019, respectively.

[0001437749-21-003793:mdna:107]
Critical Accounting Policies

[0001437749-21-003793:mdna:108]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-21-003793:mdna:109]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-21-003793:mdna:110]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets. The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2020, 2019 and 2018, and found no impairment.

[0001437749-21-003793:mdna:111]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-21-003793:mdna:112]
In our October 31, 2020 impairment test calculation, the Latin America reporting unit and the Generac Mobile Products reporting unit each had an estimated fair value that exceeded its carrying value by approximately 10%.

[0001437749-21-003793:mdna:113]
The carrying value of the Latin America goodwill was $43.6 million. Key financial assumptions utilized to determine the fair value of the reporting unit include revenue growth levels that reflect the impact of the COVID-19 pandemic with an eventual return to normalized revenue growth patterns and profitability from recovering end markets, improving profit margins, a 3% terminal growth rate and an 11.7% discount rate. The reporting unit’s fair value would approximate its carrying value with a 70 basis point increase in the discount rate or a 75 basis point reduction in the sales continuous annual growth rate and terminal growth rate.

[0001437749-21-003793:mdna:114]
The carrying value of the Generac Mobile Products goodwill was $48.6 million. Key financial assumptions utilized to determine the fair value of the reporting unit include revenue growth levels that reflect the impact of the COVID-19 pandemic as well as the impact of a decline in oil prices on end markets with an eventual return to normalized revenue growth levels from recovering end markets, improving profit margins, a 3% terminal growth rate and a 14.6% discount rate. The reporting unit’s fair value would approximate its carrying value with a 100 basis point increase in the discount rate or a 100 basis point reduction in the sales continuous annual growth rate and terminal growth rate.

[0001437749-21-003793:mdna:115]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-21-003793:mdna:116]
|  | ● | continued negative impact from the COVID-19 pandemic; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-21-003793:mdna:117]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-21-003793:mdna:118]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-21-003793:mdna:119]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-21-003793:mdna:120]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-21-003793:mdna:121]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-21-003793:mdna:122]
|  | ● | disruptions to the Company’s business; |

[0001437749-21-003793:mdna:123]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-21-003793:mdna:124]
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-21-003793:mdna:125]
|  | ● | business divestitures. |

[0001437749-21-003793:mdna:126]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-21-003793:mdna:127]
Business Combinations and Purchase Accounting

[0001437749-21-003793:mdna:128]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, profit margins, forecasted cash flows, discount rates and terminal growth rates. Refer to Note 1, “Description of Business,” and Note 3, "Acquisitions," to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-21-003793:mdna:129]
Income Taxes

[0001437749-21-003793:mdna:130]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-21-003793:mdna:131]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-21-003793:mdna:132]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes.

[0001437749-21-003793:mdna:133]
New Accounting Standards

[0001437749-21-003793:mdna:134]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-21-003793:mdna:135]
Non-GAAP Measures

[0001437749-21-003793:mdna:136]
Adjusted EBITDA

[0001437749-21-003793:mdna:137]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement, as amended. To supplement our consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-21-003793:mdna:138]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-21-003793:mdna:139]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-21-003793:mdna:140]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-21-003793:mdna:141]
|  | ● | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-21-003793:mdna:142]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-21-003793:mdna:143]
|  | ● | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-21-003793:mdna:144]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-21-003793:mdna:145]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-21-003793:mdna:146]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-21-003793:mdna:147]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-21-003793:mdna:148]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-21-003793:mdna:149]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-21-003793:mdna:150]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-21-003793:mdna:151]
|  | ● | are non-cash in nature, such as share-based compensation expense. |

[0001437749-21-003793:mdna:152]
We explain in more detail in footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-21-003793:mdna:153]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-21-003793:mdna:154]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-21-003793:mdna:155]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-21-003793:mdna:156]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-21-003793:mdna:157]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-21-003793:mdna:158]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-21-003793:mdna:159]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-21-003793:mdna:160]
29

[0001437749-21-003793:mdna:161]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board of Directors in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-21-003793:mdna:162]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-21-003793:mdna:163]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-21-003793:mdna:164]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 350,576 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Net income attributable to noncontrolling interests (a) |  |  | (3,358 | ) |  |  | 301 |  |  |  | 2,963 |  |
| Net income |  |  | 347,218 |  |  |  | 252,308 |  |  |  | 241,220 |  |
| Interest expense |  |  | 32,991 |  |  |  | 41,544 |  |  |  | 40,956 |  |
| Depreciation and amortization |  |  | 68,773 |  |  |  | 60,767 |  |  |  | 47,408 |  |
| Provision for income taxes |  |  | 98,973 |  |  |  | 67,299 |  |  |  | 69,856 |  |
| Non-cash write-down and other adjustments (b) |  |  | (327 | ) |  |  | 240 |  |  |  | 3,532 |  |
| Non-cash share-based compensation expense (c) |  |  | 20,882 |  |  |  | 16,694 |  |  |  | 14,563 |  |
| Loss on extinguishment of debt (d) |  |  | - |  |  |  | 926 |  |  |  | 1,332 |  |
| Loss on pension settlement (e) |  |  | - |  |  |  | 10,920 |  |  |  | - |  |
| Transaction costs and credit facility fees (f) |  |  | 2,151 |  |  |  | 2,724 |  |  |  | 3,883 |  |
| Business optimization and other charges (g) |  |  | 12,158 |  |  |  | 1,572 |  |  |  | 952 |  |
| Other |  |  | 954 |  |  |  | (879 | ) |  |  | 850 |  |
| Adjusted EBITDA |  |  | 583,773 |  |  |  | 454,115 |  |  |  | 424,552 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,358 |  |  |  | 4,965 |  |  |  | 7,759 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 581,415 |  |  | $ | 449,150 |  |  | $ | 416,793 |  |

[0001437749-21-003793:mdna:165]
(a) Includes the noncontrolling interests’ share of expenses related to Pramac purchase accounting, including intangible amortization of $4.3 million, $4.2 million, and $4.6 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0001437749-21-003793:mdna:166]
(b) Represents the following non-cash adjustments: gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, transactional foreign currency gains/losses and certain purchase accounting related adjustments. We believe that adjusting net income for these non-cash items is useful for the following reasons:

[0001437749-21-003793:mdna:167]
|  | ● | The gains/losses on disposals of assets result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-21-003793:mdna:168]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-21-003793:mdna:169]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations |

[0001437749-21-003793:mdna:170]
(c) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-21-003793:mdna:171]
(d) Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayments of Term Loan debt. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt.

[0001437749-21-003793:mdna:172]
(e) Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information regarding the Company’s pension plans.

[0001437749-21-003793:mdna:173]
(f) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-21-003793:mdna:174]
(g) Typically, represents severance and non-recurring plant consolidation costs. For the year-ended December 31, 2020, represents severance, non-cash asset write-downs and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products. These charges represent expenses that are nonrecurring and do not reflect our ongoing operations.

[0001437749-21-003793:mdna:175]
Adjusted Net Income

[0001437749-21-003793:mdna:176]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-21-003793:mdna:177]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-21-003793:mdna:178]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt. We also make adjustments to present cash taxes paid as a result of our favorable tax attributes, causing our cash tax rate to be lower than our U.S GAAP tax rate.

[0001437749-21-003793:mdna:179]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-21-003793:mdna:180]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-21-003793:mdna:181]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-21-003793:mdna:182]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-21-003793:mdna:183]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-21-003793:mdna:184]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 350,576 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Net income attributable to noncontrolling interests |  |  | (3,358 | ) |  |  | 301 |  |  |  | 2,963 |  |
| Net income |  |  | 347,218 |  |  |  | 252,308 |  |  |  | 241,220 |  |
| Provision for income taxes |  |  | 98,973 |  |  |  | 67,299 |  |  |  | 69,856 |  |
| Income before provision for income taxes |  |  | 446,191 |  |  |  | 319,607 |  |  |  | 311,076 |  |
| Amortization of intangible assets |  |  | 32,280 |  |  |  | 28,644 |  |  |  | 22,112 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 2,598 |  |  |  | 4,712 |  |  |  | 4,749 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 926 |  |  |  | 1,332 |  |
| Loss on pension settlement |  |  | - |  |  |  | 10,920 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | (1,328 | ) |  |  | 874 |  |  |  | 2,578 |  |
| Business optimization and other charges |  |  | 12,158 |  |  |  | 1,572 |  |  |  | 952 |  |
| Adjusted net income before provision for income taxes |  |  | 491,899 |  |  |  | 367,255 |  |  |  | 342,799 |  |
| Cash income tax expense (b) |  |  | (79,723 | ) |  |  | (47,945 | ) |  |  | (47,064 | ) |
| Adjusted net income |  |  | 412,176 |  |  |  | 319,310 |  |  |  | 295,735 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (32 | ) |  |  | 1,488 |  |  |  | 3,522 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 412,208 |  |  | $ | 317,822 |  |  | $ | 292,213 |  |

[0001437749-21-003793:mdna:185]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-21-003793:mdna:186]
(b) For the years ended December 31, 2020, 2019, and 2018, the amount is based on a cash income tax rate of 17.9%, 15.0%, and 15.1%, respectively. Cash income tax expense is based on the projected taxable income and corresponding cash taxes payable for the full year after considering the effects of current and deferred income tax items, and is calculated by applying the derived cash tax rate to the period’s pretax income.
