# GNRC 8-K — 0001437749-21-002484 filed 2021-02-11

## item codes, every 8-K on or before 2021-02-23

- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2021-02-23

- none on or before 2021-02-23

## item 2.02 — earnings release, exhibit 99.1

[0001437749-21-002484:8k_2_02:1]
EX-99.1
2
ex_225749.htm
EXHIBIT 99.1

[0001437749-21-002484:8k_2_02:2]
ex_225749.htm

[0001437749-21-002484:8k_2_02:3]
Exhibit 99.1

[0001437749-21-002484:8k_2_02:4]
Generac Reports Record Fourth Quarter and Full-Year 2020 Results

[0001437749-21-002484:8k_2_02:5]
Continued robust residential product demand drives record results; 2021 outlook anticipates significant revenue growth highlighted by unprecedented home standby demand, expanding clean energy opportunity and recovering C&I markets

[0001437749-21-002484:8k_2_02:6]
WAUKESHA, WISCONSIN (February 11, 2021) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2020 and initiated its outlook for the full year 2021.

[0001437749-21-002484:8k_2_02:7]
Fourth Quarter 2020 Highlights

[0001437749-21-002484:8k_2_02:8]
| ● | Net sales increased 29% to a record $761 million during the fourth quarter of 2020 as compared to $591 million in the prior-year fourth quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 28%. |

[0001437749-21-002484:8k_2_02:9]
|  | - | Residential product sales increased 55% to $499 million as compared to $323 million last year. |

[0001437749-21-002484:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased 9% to $199 million as compared to $217 million in the prior year. |

[0001437749-21-002484:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter was $125 million, or $1.97 per share, as compared to $70 million, or $1.12 per share, for the same period of 2019. |

[0001437749-21-002484:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was a record $136 million, or $2.12 per share, as compared to $97 million, or $1.53 per share, in the fourth quarter of 2019. |

[0001437749-21-002484:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was a record $196 million, or 25.7% of net sales, as compared to $129 million, or 21.9% of net sales, in the prior year. |

[0001437749-21-002484:8k_2_02:14]
| ● | Cash flow from operations was a record $218 million as compared to $175 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was a record $191 million as compared to $160 million for 2019. The increase was primarily due to higher net income in the current year quarter, partially offset by the lower monetization of working capital and higher capital expenditures relative to the prior year quarter. |

[0001437749-21-002484:8k_2_02:15]
| ● | As previously announced on October 7, 2020, the Company closed on the acquisition of Enbala Power Networks Inc. (“Enbala”). Based in Denver, Colorado, Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world’s power grids. |

[0001437749-21-002484:8k_2_02:16]
| ● | The Company is initiating its full-year 2021 net sales growth guidance to be approximately 25 to 30% compared to the prior year on an as-reported basis, which includes approximately 2% of favorable impact from acquisitions and foreign currency. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 24.0 to 25.0%, which is an increase from the 23.5% reported for the full-year 2020. |

[0001437749-21-002484:8k_2_02:17]
Full-Year 2020 Highlights

[0001437749-21-002484:8k_2_02:18]
| ● | Net sales increased 13% to a record $2.5 billion during 2020 as compared to $2.2 billion in 2019, which includes $32 million of contribution from acquisitions. Total core sales growth for the year was approximately 12%. |

[0001437749-21-002484:8k_2_02:19]
|  | - | Residential product sales increased 36% to $1.56 billion as compared to $1.14 billion last year. |

[0001437749-21-002484:8k_2_02:20]
|  | - | C&I product sales declined 19% to $702 million as compared to $872 million in the prior year. |

[0001437749-21-002484:8k_2_02:21]
| ● | Net income attributable to the Company during 2020 was a record $351 million, or $5.48 per share, as compared to $252 million, or $4.03 per share for 2019. The current year net income includes $11.5 million of pre-tax charges relating to restructuring costs and asset write-downs recorded during the second quarter to address the impact of the COVID-19 pandemic. |

[0001437749-21-002484:8k_2_02:22]
| ● | Adjusted net income attributable to the Company was a record $412 million, or $6.47 per share, as compared to $318 million, or $5.06 per share, in 2019. |

[0001437749-21-002484:8k_2_02:23]
| ● | Adjusted EBITDA before deducting for non-controlling interests for 2020 was a record $584 million, or 23.5% of net sales, as compared to $454 million, or 20.6% of net sales, last year. |

[0001437749-21-002484:8k_2_02:24]
| ● | Cash flow from operations was a record $487 million as compared to $309 million in the prior year. Free cash flow was a record $427 million as compared to $251 million in 2019. |

[0001437749-21-002484:8k_2_02:25]
“We continued to experience incredible demand for our home standby generators due to significantly higher power outage activity in recent quarters and the “Home as a Sanctuary” trend gained further traction, resulting in substantial backlog for these products as we enter 2021,” said Aaron Jagdfeld, President and Chief Executive Officer. “In addition, shipments of our PWRcell energy storage systems continued to further ramp during the quarter and were significantly higher on a sequential basis, and have considerable momentum heading into 2021. C&I product shipments continued to be negatively impacted from the COVID-19 pandemic, but the year-over-year revenue decline moderated as we saw certain end markets began to recover.”

[0001437749-21-002484:8k_2_02:26]
Jagdfeld continued, “2020 was a very challenging year and I am extremely proud of the way our teams responded, particularly as we maintained operations with our designation as an essential business. In the face of a global pandemic, our record performance during the year was even more impressive as we made important progress with our evolution into an energy technology solutions company. We expect 2021 to be another very strong year given the significant momentum for our residential products and an expected return to growth for our C&I products. Our strong balance sheet and significant liquidity puts Generac in the enviable position to further capitalize on our key mega trends and drive additional shareholder value by expanding our addressable markets.”

[0001437749-21-002484:8k_2_02:27]
Additional Fourth Quarter 2020 Consolidated Highlights

[0001437749-21-002484:8k_2_02:28]
Gross profit margin improved 180 basis points to 39.4% compared to 37.6% in the prior-year fourth quarter. The increase was primarily driven by favorable sales mix from significantly higher shipments of residential products and a lower mix of C&I products.

[0001437749-21-002484:8k_2_02:29]
Operating expenses increased $11.4 million, or 9.7%, as compared to the fourth quarter of 2019. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, incremental spend related to clean energy products, and the impact of acquisitions. These increases were partially offset by a reduction in operating expenses as a result of restructuring actions initiated in the second quarter of 2020 and an overall reduction in controllable operating expenses.

[0001437749-21-002484:8k_2_02:30]
Provision for income taxes for the current year quarter was $39.0 million, or an effective tax rate of 23.8%, as compared to $13.4 million, or a 16.1% effective tax rate, for the prior year. The increase in effective tax rate was primarily due to the significant increase in pretax income in the current year, while the prior year quarter was impacted by more favorable discrete tax items. For the full year 2020, the effective tax rate was 22.2% compared to 21.1% in the prior year.

[0001437749-21-002484:8k_2_02:31]
Business Segment Results

[0001437749-21-002484:8k_2_02:32]
Domestic Segment

[0001437749-21-002484:8k_2_02:33]
Domestic segment sales increased 37.2% to $645.1 million as compared to $470.1 million in the prior year quarter. This growth was primarily driven by a significant increase in shipments of home standby generators, followed by the continued ramp of PWRcell energy storage systems. In addition, higher power outage activity drove elevated shipments of portable generators and aftermarket service parts, and shipments of chore products also improved at a strong rate as compared to the prior year. This broad-based residential products growth was partially offset by continued weakness in sales of C&I mobile products due to the impacts from the COVID-19 pandemic, while shipments to national telecom account customers increased at a significant rate compared to the prior year.

[0001437749-21-002484:8k_2_02:34]
Adjusted EBITDA for the segment was $188.0 million, or 29.1% of net sales, as compared to $122.9 million in the prior year, or 26.1% of net sales. This margin increase was driven by favorable sales mix and higher operating leverage from the significant revenue growth for residential products.

[0001437749-21-002484:8k_2_02:35]
International Segment

[0001437749-21-002484:8k_2_02:36]
International segment sales decreased 4.1% to $116.0 million as compared to $120.9 million in the prior year quarter. The decline was driven by continued weakness in global C&I product demand in several regions caused by the COVID-19 pandemic. However, the year-over-year decline in the fourth quarter was at a notably lesser rate relative to recent quarters as certain regions are beginning to show signs of recovery.

[0001437749-21-002484:8k_2_02:37]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $7.8 million, or 6.8% of net sales, as compared to $6.2 million, or 5.2% of net sales, in the prior year. The improvement in margin was due to the combination of lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020, partially offset by reduced operating leverage on the lower sales volumes.

[0001437749-21-002484:8k_2_02:38]
2021 Outlook

[0001437749-21-002484:8k_2_02:39]
Key demand metrics for home standby generators continued to trend much higher during the fourth quarter relative to prior year levels, leading to a substantial backlog for these products at the end of 2020, and this strength has continued thus far in the first quarter. In addition, the solar plus storage market is projected to experience significant year-over-year growth during 2021, contributing to the expectation of substantial growth of PWRcell energy storage systems as the Company continues to expand its presence in the clean energy market. Although demand for C&I products during 2020 was negatively impacted from the onset of the COVID-19 pandemic, shipments for these products are expected to return to growth across a number of key end markets and geographies.

[0001437749-21-002484:8k_2_02:40]
As a result of these factors, the Company is initiating guidance for 2021 that anticipates significant revenue growth as compared to the prior year. Net sales are expected to increase between 25 to 30% as compared to the prior year on an as-reported basis, which includes approximately 2% of favorable impact from acquisitions and foreign currency.

[0001437749-21-002484:8k_2_02:41]
Net income margin, before deducting for non-controlling interests, is expected to be approximately 15.0 to 16.0% for the full-year 2021, with the corresponding adjusted EBITDA margin expected to be approximately 24.0 to 25.0%, which is an increase from the 23.5% reported for the full-year 2020.

[0001437749-21-002484:8k_2_02:42]
Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income to free cash flow expected to be approximately 90%.

[0001437749-21-002484:8k_2_02:43]
Conference Call and Webcast

[0001437749-21-002484:8k_2_02:44]
Generac management will hold a conference call at 10:00 a.m. EST on Thursday, February 11, 2021 to discuss fourth quarter and full-year 2020 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 3877036.

[0001437749-21-002484:8k_2_02:45]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-21-002484:8k_2_02:46]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 3877036. The telephonic replay will be available for 7 days.

[0001437749-21-002484:8k_2_02:47]
About Generac

[0001437749-21-002484:8k_2_02:48]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-002484:8k_2_02:49]
Forward-looking Information

[0001437749-21-002484:8k_2_02:50]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-21-002484:8k_2_02:51]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-21-002484:8k_2_02:52]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-21-002484:8k_2_02:53]
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |

[0001437749-21-002484:8k_2_02:54]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-21-002484:8k_2_02:55]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-21-002484:8k_2_02:56]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-21-002484:8k_2_02:57]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-21-002484:8k_2_02:58]
|  | ● | our dependence on our distribution network; |

[0001437749-21-002484:8k_2_02:59]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-21-002484:8k_2_02:60]
|  | ● | loss of our key management and employees; |

[0001437749-21-002484:8k_2_02:61]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-21-002484:8k_2_02:62]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-21-002484:8k_2_02:63]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; and |

[0001437749-21-002484:8k_2_02:64]
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and may or will continue to adversely affect our operations, supply chain, distribution, and demand for certain of our products and services. |

[0001437749-21-002484:8k_2_02:65]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2019 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-21-002484:8k_2_02:66]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-21-002484:8k_2_02:67]
Non-GAAP Financial Metrics

[0001437749-21-002484:8k_2_02:68]
Core Sales

[0001437749-21-002484:8k_2_02:69]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-21-002484:8k_2_02:70]
Adjusted EBITDA

[0001437749-21-002484:8k_2_02:71]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-21-002484:8k_2_02:72]
Adjusted Net Income

[0001437749-21-002484:8k_2_02:73]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-21-002484:8k_2_02:74]
Free Cash Flow

[0001437749-21-002484:8k_2_02:75]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-21-002484:8k_2_02:76]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-21-002484:8k_2_02:77]
SOURCE: Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:78]
CONTACT:

[0001437749-21-002484:8k_2_02:79]
Michael W. Harris

[0001437749-21-002484:8k_2_02:80]
Vice President – Corporate Development & Investor Relations

[0001437749-21-002484:8k_2_02:81]
(262) 506-6064

[0001437749-21-002484:8k_2_02:82]
InvestorRelations@generac.com

[0001437749-21-002484:8k_2_02:83]
Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:84]
Consolidated Statements of Comprehensive Income

[0001437749-21-002484:8k_2_02:85]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-002484:8k_2_02:86]
(Unaudited)

[0001437749-21-002484:8k_2_02:87]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net sales |  | $ | 761,082 |  |  | $ | 590,932 |  |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |
| Costs of goods sold |  |  | 460,880 |  |  |  | 368,710 |  |  |  | 1,527,546 |  |  |  | 1,406,584 |  |
| Gross profit |  |  | 300,202 |  |  |  | 222,222 |  |  |  | 957,654 |  |  |  | 797,752 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 67,807 |  |  |  | 58,729 |  |  |  | 246,373 |  |  |  | 217,683 |  |
| Research and development |  |  | 21,489 |  |  |  | 19,488 |  |  |  | 80,251 |  |  |  | 68,394 |  |
| General and administrative |  |  | 30,912 |  |  |  | 30,852 |  |  |  | 119,644 |  |  |  | 110,868 |  |
| Amortization of intangibles |  |  | 8,940 |  |  |  | 8,645 |  |  |  | 32,280 |  |  |  | 28,644 |  |
| Total operating expenses |  |  | 129,148 |  |  |  | 117,714 |  |  |  | 478,548 |  |  |  | 425,589 |  |
| Income from operations |  |  | 171,054 |  |  |  | 104,508 |  |  |  | 479,106 |  |  |  | 372,163 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (7,910 | ) |  |  | (10,116 | ) |  |  | (32,991 | ) |  |  | (41,544 | ) |
| Investment income |  |  | 261 |  |  |  | 878 |  |  |  | 2,182 |  |  |  | 2,767 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (926 | ) |  |  | – |  |  |  | (926 | ) |
| Loss on pension settlement |  |  | – |  |  |  | (10,920 | ) |  |  | – |  |  |  | (10,920 | ) |
| Other, net |  |  | 581 |  |  |  | (65 | ) |  |  | (2,106 | ) |  |  | (1,933 | ) |
| Total other expense, net |  |  | (7,068 | ) |  |  | (21,149 | ) |  |  | (32,915 | ) |  |  | (52,556 | ) |
| Income before provision for income taxes |  |  | 163,986 |  |  |  | 83,359 |  |  |  | 446,191 |  |  |  | 319,607 |  |
| Provision for income taxes |  |  | 39,006 |  |  |  | 13,423 |  |  |  | 98,973 |  |  |  | 67,299 |  |
| Net income |  |  | 124,980 |  |  |  | 69,936 |  |  |  | 347,218 |  |  |  | 252,308 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (21 | ) |  |  | 322 |  |  |  | (3,358 | ) |  |  | 301 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 125,001 |  |  | $ | 69,614 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | 23,664 |  |  | $ | 9,862 |  |  | $ | 4,948 |  |  | $ | 2,210 |  |
| Net unrealized gain (loss) on derivatives |  |  | 4,121 |  |  |  | 1,043 |  |  |  | (14,285 | ) |  |  | (13,855 | ) |
| Pension liability adjustment |  |  | – |  |  |  | 10,541 |  |  |  | – |  |  |  | 10,541 |  |
| Other comprehensive income (loss) |  |  | 27,785 |  |  |  | 21,446 |  |  |  | (9,337 | ) |  |  | (1,104 | ) |
| Total comprehensive income |  |  | 152,765 |  |  |  | 91,382 |  |  |  | 337,881 |  |  |  | 251,204 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 2,068 |  |  |  | 1,371 |  |  |  | (364 | ) |  |  | (635 | ) |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 150,697 |  |  | $ | 90,011 |  |  | $ | 338,245 |  |  | $ | 251,839 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 2.02 |  |  | $ | 1.14 |  |  | $ | 5.61 |  |  | $ | 4.09 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,389,159 |  |  |  | 62,056,624 |  |  |  | 62,280,889 |  |  |  | 61,926,986 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.97 |  |  | $ | 1.12 |  |  | $ | 5.48 |  |  | $ | 4.03 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,985,879 |  |  |  | 63,219,078 |  |  |  | 63,737,734 |  |  |  | 62,865,446 |  |

[0001437749-21-002484:8k_2_02:88]
6

[0001437749-21-002484:8k_2_02:89]
Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:90]
Consolidated Balance Sheets

[0001437749-21-002484:8k_2_02:91]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-002484:8k_2_02:92]
(Unaudited)

[0001437749-21-002484:8k_2_02:93]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 655,128 |  |  | $ | 322,883 |  |
| Accounts receivable, less allowance for credit losses of $12,001 and $6,968 at December 31, 2020 and 2019, respectively |  |  | 374,906 |  |  |  | 319,538 |  |
| Inventories |  |  | 603,317 |  |  |  | 522,024 |  |
| Prepaid expenses and other assets |  |  | 36,382 |  |  |  | 31,384 |  |
| Total current assets |  |  | 1,669,733 |  |  |  | 1,195,829 |  |
| Property and equipment, net |  |  | 343,936 |  |  |  | 316,976 |  |
| Customer lists, net |  |  | 49,205 |  |  |  | 55,552 |  |
| Patents and technology, net |  |  | 86,727 |  |  |  | 85,546 |  |
| Other intangible assets, net |  |  | 9,932 |  |  |  | 8,259 |  |
| Tradenames, net |  |  | 146,159 |  |  |  | 148,377 |  |
| Goodwill |  |  | 855,228 |  |  |  | 805,284 |  |
| Deferred income taxes |  |  | 1,497 |  |  |  | 2,933 |  |
| Operating lease and other assets |  |  | 73,006 |  |  |  | 46,913 |  |
| Total assets |  | $ | 3,235,423 |  |  | $ | 2,665,669 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 39,282 |  |  | $ | 58,714 |  |
| Accounts payable |  |  | 330,247 |  |  |  | 261,977 |  |
| Accrued wages and employee benefits |  |  | 63,036 |  |  |  | 41,361 |  |
| Other accrued liabilities |  |  | 204,812 |  |  |  | 132,629 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 4,147 |  |  |  | 2,383 |  |
| Total current liabilities |  |  | 641,524 |  |  |  | 497,064 |  |
| Long-term borrowings and finance lease obligations |  |  | 841,764 |  |  |  | 837,767 |  |
| Deferred income taxes |  |  | 115,769 |  |  |  | 96,328 |  |
| Operating lease and other long-term liabilities |  |  | 179,955 |  |  |  | 140,432 |  |
| Total liabilities |  |  | 1,779,012 |  |  |  | 1,571,591 |  |
| Redeemable noncontrolling interest |  |  | 66,207 |  |  |  | 61,227 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,024,329 and 71,667,726 shares issued at December 31, 2020 and 2019, respectively |  |  | 721 |  |  |  | 717 |  |
| Additional paid-in capital |  |  | 525,541 |  |  |  | 498,866 |  |
| Treasury stock, at cost, 9,173,731 and 9,103,013 shares at December 31, 2020 and 2019, respectively |  |  | (332,164 | ) |  |  | (324,551 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,432,565 |  |  |  | 1,084,383 |  |
| Accumulated other comprehensive loss |  |  | (34,254 | ) |  |  | (24,917 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,390,293 |  |  |  | 1,032,382 |  |
| Noncontrolling interests |  |  | (89 | ) |  |  | 469 |  |
| Total stockholders’ equity |  |  | 1,390,204 |  |  |  | 1,032,851 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,235,423 |  |  | $ | 2,665,669 |  |

[0001437749-21-002484:8k_2_02:94]
Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:95]
Consolidated Statements of Cash Flows

[0001437749-21-002484:8k_2_02:96]
(U.S. Dollars in Thousands)

[0001437749-21-002484:8k_2_02:97]
(Unaudited)

[0001437749-21-002484:8k_2_02:98]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 347,218 |  |  | $ | 252,308 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 36,493 |  |  |  | 32,265 |  |
| Amortization of intangible assets |  |  | 32,280 |  |  |  | 28,644 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,598 |  |  |  | 4,712 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 926 |  |
| Loss on pension settlement |  |  | – |  |  |  | 10,920 |  |
| Deferred income taxes |  |  | 21,195 |  |  |  | 18,733 |  |
| Share-based compensation expense |  |  | 20,882 |  |  |  | 16,694 |  |
| Other non-cash charges |  |  | 7,145 |  |  |  | 1,086 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (55,976 | ) |  |  | 8,231 |  |
| Inventories |  |  | (77,983 | ) |  |  | 26,369 |  |
| Other assets |  |  | 12,859 |  |  |  | (358 | ) |
| Accounts payable |  |  | 66,040 |  |  |  | (69,404 | ) |
| Accrued wages and employee benefits |  |  | 20,157 |  |  |  | (3,724 | ) |
| Other accrued liabilities |  |  | 60,593 |  |  |  | (16,252 | ) |
| Excess tax benefits from equity awards |  |  | (6,968 | ) |  |  | (2,263 | ) |
| Net cash provided by operating activities |  |  | 486,533 |  |  |  | 308,887 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 179 |  |  |  | 95 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,651 |  |  |  | 2,630 |  |
| Expenditures for property and equipment |  |  | (62,128 | ) |  |  | (60,802 | ) |
| Acquisition of business, net of cash acquired |  |  | (64,797 | ) |  |  | (112,001 | ) |
| Net cash used in investing activities |  |  | (124,095 | ) |  |  | (170,078 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 257,593 |  |  |  | 73,340 |  |
| Proceeds from long-term borrowings |  |  | 277 |  |  |  | 1,660 |  |
| Repayments of short-term borrowings |  |  | (277,719 | ) |  |  | (59,518 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (4,758 | ) |  |  | (53,049 | ) |
| Payment of contingent acquisition consideration |  |  | (4,000 | ) |  |  | (5,550 | ) |
| Payment of debt issuance costs |  |  | – |  |  |  | (1,473 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | – |  |  |  | (285 | ) |
| Taxes paid related to equity awards |  |  | (14,910 | ) |  |  | (6,438 | ) |
| Proceeds from the exercise of stock options |  |  | 13,089 |  |  |  | 9,395 |  |
| Net cash used in financing activities |  |  | (30,428 | ) |  |  | (41,918 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 235 |  |  |  | 1,510 |  |
| Net increase in cash and cash equivalents |  |  | 332,245 |  |  |  | 98,401 |  |
| Cash and cash equivalents at beginning of period |  |  | 322,883 |  |  |  | 224,482 |  |
| Cash and cash equivalents at end of period |  | $ | 655,128 |  |  | $ | 322,883 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 28,765 |  |  | $ | 35,465 |  |
| Income taxes |  |  | 61,861 |  |  |  | 61,767 |  |

[0001437749-21-002484:8k_2_02:99]
8

[0001437749-21-002484:8k_2_02:100]
Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:101]
Segment Reporting and Product Class Information

[0001437749-21-002484:8k_2_02:102]
(U.S. Dollars in Thousands)

[0001437749-21-002484:8k_2_02:103]
(Unaudited)

[0001437749-21-002484:8k_2_02:104]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Reportable Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 645,128 |  |  | $ | 470,058 |  |  | $ | 2,088,808 |  |  | $ | 1,742,898 |  |
| International |  |  | 115,954 |  |  |  | 120,874 |  |  |  | 396,392 |  |  |  | 461,438 |  |
| Total net sales |  | $ | 761,082 |  |  | $ | 590,932 |  |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 498,653 |  |  | $ | 322,490 |  |  | $ | 1,556,501 |  |  | $ | 1,143,723 |  |
| Commercial & industrial products |  |  | 198,596 |  |  |  | 217,137 |  |  |  | 701,751 |  |  |  | 871,595 |  |
| Other |  |  | 63,833 |  |  |  | 51,305 |  |  |  | 226,948 |  |  |  | 189,018 |  |
| Total net sales |  | $ | 761,082 |  |  | $ | 590,932 |  |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |

[0001437749-21-002484:8k_2_02:105]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 188,004 |  |  | $ | 122,920 |  |  | $ | 563,394 |  |  | $ | 428,667 |  |
| International |  |  | 7,827 |  |  |  | 6,228 |  |  |  | 20,379 |  |  |  | 25,448 |  |
| Total adjusted EBITDA (1) |  | $ | 195,831 |  |  | $ | 129,148 |  |  | $ | 583,773 |  |  | $ | 454,115 |  |

[0001437749-21-002484:8k_2_02:106]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-21-002484:8k_2_02:107]
Generac Holdings Inc.

[0001437749-21-002484:8k_2_02:108]
Reconciliation Schedules

[0001437749-21-002484:8k_2_02:109]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-21-002484:8k_2_02:110]
(Unaudited)

[0001437749-21-002484:8k_2_02:111]
Net income to Adjusted EBITDA reconciliation

[0001437749-21-002484:8k_2_02:112]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 125,001 |  |  | $ | 69,614 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (21 | ) |  |  | 322 |  |  |  | (3,358 | ) |  |  | 301 |  |
| Net income |  |  | 124,980 |  |  |  | 69,936 |  |  |  | 347,218 |  |  |  | 252,308 |  |
| Interest expense |  |  | 7,910 |  |  |  | 10,116 |  |  |  | 32,991 |  |  |  | 41,544 |  |
| Depreciation and amortization |  |  | 18,686 |  |  |  | 17,926 |  |  |  | 68,773 |  |  |  | 60,767 |  |
| Provision for income taxes |  |  | 39,006 |  |  |  | 13,423 |  |  |  | 98,973 |  |  |  | 67,299 |  |
| Non-cash write-down and other adjustments (1) |  |  | (2,195 | ) |  |  | (433 | ) |  |  | (327 | ) |  |  | 240 |  |
| Non-cash share-based compensation expense (2) |  |  | 6,555 |  |  |  | 5,217 |  |  |  | 20,882 |  |  |  | 16,694 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 926 |  |  |  | - |  |  |  | 926 |  |
| Loss on pension settlement (4) |  |  | - |  |  |  | 10,920 |  |  |  | - |  |  |  | 10,920 |  |
| Transaction costs and credit facility fees (5) |  |  | 991 |  |  |  | 677 |  |  |  | 2,151 |  |  |  | 2,724 |  |
| Business optimization and other charges (6) |  |  | (345 | ) |  |  | 763 |  |  |  | 12,158 |  |  |  | 1,572 |  |
| Other |  |  | 243 |  |  |  | (323 | ) |  |  | 954 |  |  |  | (879 | ) |
| Adjusted EBITDA |  |  | 195,831 |  |  |  | 129,148 |  |  |  | 583,773 |  |  |  | 454,115 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,408 |  |  |  | 1,243 |  |  |  | 2,358 |  |  |  | 4,965 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 194,423 |  |  | $ | 127,905 |  |  | $ | 581,415 |  |  | $ | 449,150 |  |

[0001437749-21-002484:8k_2_02:113]
(1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-21-002484:8k_2_02:114]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-21-002484:8k_2_02:115]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-21-002484:8k_2_02:116]
(4) Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019.

[0001437749-21-002484:8k_2_02:117]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-21-002484:8k_2_02:118]
(6) For the three months and year ended December 31, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. For the three months and year ended December 31, 2019, represents severance and other charges related to the consolidation of certain of our facilities.

[0001437749-21-002484:8k_2_02:119]
Net income to Adjusted net income reconciliation

[0001437749-21-002484:8k_2_02:120]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 125,001 |  |  | $ | 69,614 |  |  | $ | 350,576 |  |  | $ | 252,007 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (21 | ) |  |  | 322 |  |  |  | (3,358 | ) |  |  | 301 |  |
| Net income |  |  | 124,980 |  |  |  | 69,936 |  |  |  | 347,218 |  |  |  | 252,308 |  |
| Provision for income taxes |  |  | 39,006 |  |  |  | 13,423 |  |  |  | 98,973 |  |  |  | 67,299 |  |
| Income before provision for income taxes |  |  | 163,986 |  |  |  | 83,359 |  |  |  | 446,191 |  |  |  | 319,607 |  |
| Amortization of intangible assets |  |  | 8,940 |  |  |  | 8,645 |  |  |  | 32,280 |  |  |  | 28,644 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 658 |  |  |  | 1,115 |  |  |  | 2,598 |  |  |  | 4,712 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 926 |  |  |  | - |  |  |  | 926 |  |
| Loss on pension settlement (4) |  |  | - |  |  |  | 10,920 |  |  |  | - |  |  |  | 10,920 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | (1,940 | ) |  |  | (499 | ) |  |  | (1,328 | ) |  |  | 874 |  |
| Business optimization and other charges (6) |  |  | (345 | ) |  |  | 763 |  |  |  | 12,158 |  |  |  | 1,572 |  |
| Adjusted net income before provision for income taxes |  |  | 171,299 |  |  |  | 105,229 |  |  |  | 491,899 |  |  |  | 367,255 |  |
| Cash income tax expense (8) |  |  | (34,881 | ) |  |  | (8,247 | ) |  |  | (79,723 | ) |  |  | (47,945 | ) |
| Adjusted net income |  |  | 136,418 |  |  |  | 96,982 |  |  |  | 412,176 |  |  |  | 319,310 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 693 |  |  |  | 530 |  |  |  | (32 | ) |  |  | 1,488 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 135,725 |  |  | $ | 96,452 |  |  | $ | 412,208 |  |  | $ | 317,822 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.12 |  |  | $ | 1.53 |  |  | $ | 6.47 |  |  | $ | 5.06 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,985,879 |  |  |  | 63,219,078 |  |  |  | 63,737,734 |  |  |  | 62,865,446 |  |

[0001437749-21-002484:8k_2_02:121]
(7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-21-002484:8k_2_02:122]
(8) Amounts for the three months and year ended December 31, 2020 are now based on an anticipated cash income tax rate of 17.9% for the year ending December 31, 2020. Amounts for the three months and year ended December 31, 2019 were based on an anticipated cash income tax rate of 15% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-21-002484:8k_2_02:123]
Free Cash Flow Reconciliation

[0001437749-21-002484:8k_2_02:124]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net cash provided by operating activities |  | $ | 218,223 |  |  | $ | 175,085 |  |  | $ | 486,533 |  |  | $ | 308,887 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 653 |  |  |  | 594 |  |  |  | 2,651 |  |  |  | 2,630 |  |
| Expenditures for property and equipment |  |  | (28,188 | ) |  |  | (15,355 | ) |  |  | (62,128 | ) |  |  | (60,802 | ) |
| Free cash flow |  | $ | 190,688 |  |  | $ | 160,324 |  |  | $ | 427,056 |  |  | $ | 250,715 |  |

[0001437749-21-002484:8k_2_02:125]
11
