# GNRC notes — 0001437749-21-003793


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-21-003793:notes:1]
| 1. | Description of Business |

[0001437749-21-003793:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-003793:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of our "Powering Our Future" strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-21-003793:notes:4]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |

[0001437749-21-003793:notes:5]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators for the India market. |

[0001437749-21-003793:notes:6]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

[0001437749-21-003793:notes:7]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or other power sources for homeowners and businesses, and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |

[0001437749-21-003793:notes:8]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-21-003793:notes:9]
| 2. | Summary of Accounting Policies |

[0001437749-21-003793:notes:10]
Principles of Consolidation

[0001437749-21-003793:notes:11]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-21-003793:notes:12]
Cash and Cash Equivalents

[0001437749-21-003793:notes:13]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-21-003793:notes:14]
Concentration of Credit Risk

[0001437749-21-003793:notes:15]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-21-003793:notes:16]
One customer accounted for approximately 13% and 9% of accounts receivable at  December 31, 2020 and 2019, respectively. No one customer accounted for greater than 6%, 5%, and 6%, of net sales during the years ended  December 31, 2020, 2019, or 2018, respectively.

[0001437749-21-003793:notes:17]
Accounts Receivable and Allowance for Credit Losses

[0001437749-21-003793:notes:18]
The Company's trade and other receivables primarily arise from the sale of our products to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, utilities, and certain end users with payment terms generally ranging from 30 to 90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-21-003793:notes:19]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity by entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-21-003793:notes:20]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds a credit insurance plan that covers the risk of loss up to specified amounts on certain trade receivables. As of  December 31, 2020, the Company had gross receivables of $386,907 and an allowance for credit losses of $12,001.

[0001437749-21-003793:notes:21]
The following is a tabular reconciliation of the Company's allowance for credit losses:

[0001437749-21-003793:notes:22]
|  |  | Year Ended December 31, 2020 |  |
| Balance at beginning of period |  | $ | 6,968 |  |
| Adoption of ASU 2016-13 |  |  | 1,147 |  |
| Established for Acquisitions |  |  | 198 |  |
| Provision for credit losses |  |  | 4,645 |  |
| Charge-offs |  |  | (1,448 | ) |
| Currency translation |  |  | 491 |  |
| Balance at end of period |  | $ | 12,001 |  |

[0001437749-21-003793:notes:23]
Inventories

[0001437749-21-003793:notes:24]
Inventories are stated at the lower of cost or market, with cost determined generally using the first-in, first-out method.

[0001437749-21-003793:notes:25]
Property and Equipment

[0001437749-21-003793:notes:26]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. Finance lease right of use assets are included in property and equipment. Refer to Note 10, "Leases," to the consolidated financial statements for the Company's lease disclosure.

[0001437749-21-003793:notes:27]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office equipment and systems |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-21-003793:notes:28]
Total depreciation expense was $36,493, $32,265, and $25,296 for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:29]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-21-003793:notes:30]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-21-003793:notes:31]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-21-003793:notes:32]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2020, 2019 and 2018, and found no impairment.

[0001437749-21-003793:notes:33]
Impairment of Long-Lived Assets

[0001437749-21-003793:notes:34]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-21-003793:notes:35]
Debt Issuance Costs

[0001437749-21-003793:notes:36]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $2,598, $4,712, and $4,749 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2020, 2019 and 2018, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2021 - $2,640; 2022 - $2,689; 2023 - $2,579; 2024 - $2,508; 2025 - $2,555.

[0001437749-21-003793:notes:37]
Income Taxes

[0001437749-21-003793:notes:38]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-21-003793:notes:39]
Revenue Recognition

[0001437749-21-003793:notes:40]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-21-003793:notes:41]
At the request of certain customers, the Company will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-21-003793:notes:42]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $25,710 and $9,952 at  December 31, 2020 and  December 31, 2019, respectively. During the year ended  December 31, 2020, the Company recognized revenue of $8,703 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-21-003793:notes:43]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-21-003793:notes:44]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-21-003793:notes:45]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation, maintenance and grid services in certain circumstances. Total service revenues accounted for less than two percent of revenue during the year ended  December 31, 2020.

[0001437749-21-003793:notes:46]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-21-003793:notes:47]
Advertising and Co-Op Advertising

[0001437749-21-003793:notes:48]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $53,678, $44,153, and $34,792 for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:49]
Research and Development

[0001437749-21-003793:notes:50]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $80,251, $68,394, and $50,019 for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:51]
Foreign Currency Translation and Transactions

[0001437749-21-003793:notes:52]
Balance sheet amounts for non-U.S. Dollar functional currency businesses are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:53]
Fair Value of Financial Instruments

[0001437749-21-003793:notes:54]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-21-003793:notes:55]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $815,260, was approximately $831,038 (Level 2) at  December 31, 2020, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-21-003793:notes:56]
For the fair value of the assets and liabilities measured on a recurring basis, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-21-003793:notes:57]
Use of Estimates

[0001437749-21-003793:notes:58]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-21-003793:notes:59]
Derivative Instruments and Hedging Activities

[0001437749-21-003793:notes:60]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes. Refer to Item 7A of this Annual Report on Form 10-K for further information on the Company’s derivatives.

[0001437749-21-003793:notes:61]
Share-Based Compensation

[0001437749-21-003793:notes:62]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.

[0001437749-21-003793:notes:63]
New Accounting Pronouncements

[0001437749-21-003793:notes:64]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

[0001437749-21-003793:notes:65]
Recently Adopted Accounting Standards

[0001437749-21-003793:notes:66]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 2 to the consolidated financial statements, “Summary of Accounting Policies - Accounts Receivable and Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

[0001437749-21-003793:notes:67]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-003793:notes:68]
| 3. | Acquisitions |

[0001437749-21-003793:notes:69]
Fiscal 2020

[0001437749-21-003793:notes:70]
Acquisition of Enbala

[0001437749-21-003793:notes:71]
On  October 7, 2020, the Company acquired Enbala for a purchase price, net of cash acquired, of $41,982. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-003793:notes:72]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $46,645 of intangible assets, including $27,545 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of Enbala from the date of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:73]
Other Acquisitions

[0001437749-21-003793:notes:74]
In  July 2020, the Company acquired Energy Systems, its industrial distributor in northern California.

[0001437749-21-003793:notes:75]
In  September 2020, the Company acquired Mean Green, a designer and manufacturer of commercial grade, battery-powered turf care products.

[0001437749-21-003793:notes:76]
The combined purchase price for these acquisitions was $22,815 and was funded solely through cash on hand. The accompanying consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:77]
Fiscal 2019

[0001437749-21-003793:notes:78]
Acquisition of Pika

[0001437749-21-003793:notes:79]
On  April 26, 2019, the Company acquired Pika for a purchase price, net of cash acquired, of $49,068. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-003793:notes:80]
The Company finalized the Pika purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Pika from the date of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:81]
Acquisition of Neurio

[0001437749-21-003793:notes:82]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of a deferred payment of $7,922 which was made during the third quarter of 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-003793:notes:83]
The Company finalized the Neurio purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of Neurio from the date of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:84]
In  February 2019, the Company acquired a majority share of Captiva, a manufacturer of customized industrial generators in Kolkata, India. The purchase price was immaterial to the Company and was funded solely through cash on hand. The accompanying consolidated financial statements include the results of the acquired business from the date of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:85]
Fiscal 2018

[0001437749-21-003793:notes:86]
Acquisition of Selmec

[0001437749-21-003793:notes:87]
On  June 1, 2018, the Company acquired Selmec for a purchase price of $79,972, net of cash acquired and inclusive of earnout payments of $14,902. Changes in the fair value of the earnout liability during 2020 and 2019 of $(2,241) and $(977), respectively, were recognized as a component of operating income in the Company's consolidated statements of comprehensive income. Changes in the fair value of the earnout liability during 2020 and 2019 included interest accretion of $536 and $2,740, respectively, and other fair value remeasurement adjustments of $(2,777) and $(3,717), respectively. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-003793:notes:88]
The Company finalized the Selmec purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $79,827 of intangible assets, including $46,196 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Selmec from the date of acquisition through  December 31, 2020.

[0001437749-21-003793:notes:89]
Summary Purchase Price Allocations

[0001437749-21-003793:notes:90]
The fair values assigned to certain assets acquired and liabilities assumed, as of the acquisition dates, for the years ended  December 31 are as follows:

[0001437749-21-003793:notes:91]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Accounts receivable |  | $ | 5,151 |  |  | $ | 4,643 |  |  | $ | 14,302 |  |
| Inventories |  |  | 3,711 |  |  |  | 4,313 |  |  |  | 8,000 |  |
| Prepaid expenses and other assets |  |  | 897 |  |  |  | 304 |  |  |  | 4,323 |  |
| Property and equipment |  |  | 635 |  |  |  | 384 |  |  |  | 5,572 |  |
| Intangible assets |  |  | 26,057 |  |  |  | 79,200 |  |  |  | 33,631 |  |
| Goodwill |  |  | 42,698 |  |  |  | 41,428 |  |  |  | 46,196 |  |
| Deferred income taxes |  |  | - |  |  |  | 3,217 |  |  |  | 3,252 |  |
| Other assets |  |  | 1,122 |  |  |  | 133 |  |  |  | 597 |  |
| Total assets acquired |  |  | 80,271 |  |  |  | 133,622 |  |  |  | 115,873 |  |
| Accounts payable |  |  | 4,088 |  |  |  | 4,380 |  |  |  | 7,216 |  |
| Accrued wages and employee benefits |  |  | 700 |  |  |  | 4,408 |  |  |  | 397 |  |
| Other accrued liabilities |  |  | 2,151 |  |  |  | 602 |  |  |  | 13,671 |  |
| Current portion of long-term debt |  |  | - |  |  |  | 937 |  |  |  | - |  |
| Deferred income taxes |  |  | 4,134 |  |  |  | 9,958 |  |  |  | 10,974 |  |
| Other long-term liabilities |  |  | 4,401 |  |  |  | 778 |  |  |  | 3,643 |  |
| Redeemable non-controlling interest |  |  | - |  |  |  | 3,165 |  |  |  | - |  |
| Net assets acquired |  | $ | 64,797 |  |  | $ | 109,394 |  |  | $ | 79,972 |  |

[0001437749-21-003793:notes:92]
Pro Forma Information

[0001437749-21-003793:notes:93]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on  January 1, 2018. Refer to Note 1, “Description of Business,” for further information on the acquisitions included in the table.

[0001437749-21-003793:notes:94]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 2,485,200 |  |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |
| Pro forma |  |  | 2,512,017 |  |  |  | 2,242,710 |  |  |  | 2,093,112 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 350,576 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Pro forma |  |  | 339,317 |  |  |  | 239,925 |  |  |  | 220,555 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 5.48 |  |  | $ | 4.03 |  |  | $ | 3.54 |  |
| Pro forma |  |  | 5.34 |  |  |  | 3.84 |  |  |  | 3.26 |  |

[0001437749-21-003793:notes:95]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on  January 1, 2018.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-21-003793:notes:96]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-21-003793:notes:97]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended.

[0001437749-21-003793:notes:98]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions, Ltd (Captiva). The 49% noncontrolling interest in Captiva has an acquisition date fair value of $3,165, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put option price is based on a multiple of earnings, subject to the terms of the acquisition. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings, subject to the terms of the acquisition.

[0001437749-21-003793:notes:99]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-21-003793:notes:100]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 61,227 |  |  | $ | 61,004 |  |  |  | $ | 43,929 |  |
| Noncontrolling interest |  |  | - |  |  |  | 3,165 |  | (1) |  |  | - |  |
| Net income |  |  | (2,829 | ) |  |  | 75 |  |  |  |  | 2,214 |  |
| Foreign currency translation |  |  | 6,562 |  |  |  | (1,764 | ) |  |  |  | (3,109 | ) |
| Redemption value adjustment |  |  | 1,247 |  |  |  | (1,253 | ) |  |  |  | 17,970 |  |
| Balance at end of period |  | $ | 66,207 |  |  | $ | 61,227 |  |  |  | $ | 61,004 |  |

[0001437749-21-003793:notes:101]
| (1) Represents the noncontrolling interest of Captiva calculated at the date of acquisition, February 1, 2019. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-21-003793:notes:102]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-21-003793:notes:103]
Commodities

[0001437749-21-003793:notes:104]
The Company is exposed to price fluctuations in commodities including steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than eighteen months. At  December 31, 2020 and 2019, the Company had one and no commodity contracts outstanding, respectively.

[0001437749-21-003793:notes:105]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized were $2,185, $(174), and $(874) for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:106]
Foreign Currencies

[0001437749-21-003793:notes:107]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less. As of  December 31, 2020 and 2019, the Company had forty-four and forty-three foreign currency contracts outstanding, respectively.

[0001437749-21-003793:notes:108]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in "other, net" in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended  December 31, 2020, 2019 and 2018 were $355, $(1,195), and $(653), respectively.

[0001437749-21-003793:notes:109]
Interest Rate Swaps

[0001437749-21-003793:notes:110]
In 2017, the Company entered into twenty interest rate swap agreements, twelve of which were still outstanding as of  December 31, 2020. In  December 2019, in conjunction with the amendment to its Term Loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to fifteen as of  December 31, 2020. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking these hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets. The amount of after-tax gains (losses) recognized for the years ended  December 31, 2020, 2019 and 2018 were $(14,285), $(13,855), and $2,924, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-21-003793:notes:111]
Fair Value

[0001437749-21-003793:notes:112]
The following table presents the fair value of the Company’s derivatives:

[0001437749-21-003793:notes:113]
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Commodity contracts |  | $ | 1,386 |  |  | $ | 6 |  |
| Foreign currency contracts |  |  | (154 | ) |  |  | 31 |  |
| Interest rate swaps |  |  | (29,536 | ) |  |  | (10,425 | ) |

[0001437749-21-003793:notes:114]
The fair value of the commodity contract is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2020. The fair value of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2019. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2020 and 2019 is a liability of $28,667 and $10,588, respectively, which represents the net amount the Company would pay to exit all of the agreements on those dates.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-21-003793:notes:115]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-21-003793:notes:116]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2020 and 2019, net of tax:

[0001437749-21-003793:notes:117]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  | $ | - |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 4,948 |  |  |  | - |  |  |  | (14,285 | ) | (1) |  |  | (9,337 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 4,948 |  |  |  | - |  |  |  | (14,285 | ) |  |  |  | (9,337 | ) |
| Ending Balance – December 31, 2020 |  | $ | (11,674 | ) |  | $ | - |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |

[0001437749-21-003793:notes:118]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  |  | $ | 5,560 |  |  |  | $ | (23,813 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,210 |  |  |  | 1,474 |  | (2) |  |  | (13,855 | ) | (3) |  |  | (10,171 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 9,067 |  | (4) |  |  | - |  |  |  |  | 9,067 |  |
| Net current-period other comprehensive income (loss) |  |  | 2,210 |  |  |  | 10,541 |  |  |  |  | (13,855 | ) |  |  |  | (1,104 | ) |
| Ending Balance – December 31, 2019 |  | $ | (16,622 | ) |  | $ | - |  |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |

[0001437749-21-003793:notes:119]
|  | (1) | Represents unrealized losses of $(19,111), net of tax effect of $4,826 for the year ended December 31, 2020. |
|  | (2) | Represents unrecognized actuarial gains of $1,992 net of tax effect of $(518), included in the computation of net periodic pension cost for the year ended December 31, 2019. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-21-003793:notes:120]
|  | (3) | Represents unrealized losses of $(18,732), net of tax effect of $4,877 for the year ended December 31, 2019. |

[0001437749-21-003793:notes:121]
|  | (4) | Details of reclassifications from AOCL during 2019 are as follows: |

[0001437749-21-003793:notes:122]
|  |  | Amounts reclassified from AOCL |  |
| Loss on pension settlement |  | $ | 10,920 |  |
| Amortization of net loss |  |  | 843 |  |
| Total before tax |  |  | 11,763 |  |
| Income tax impact |  |  | (2,696 | ) |
| Amounts reclassified from AOCL during 2019 |  | $ | 9,067 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-003793:notes:123]
| 7. | Segment Reporting |

[0001437749-21-003793:notes:124]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-21-003793:notes:125]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-21-003793:notes:126]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,495,383 |  |  | $ | 61,118 |  |  | $ | 1,556,501 |  |
| Commercial & industrial products |  |  | 404,867 |  |  |  | 296,884 |  |  |  | 701,751 |  |
| Other |  |  | 188,558 |  |  |  | 38,390 |  |  |  | 226,948 |  |
| Total net sales |  | $ | 2,088,808 |  |  | $ | 396,392 |  |  | $ | 2,485,200 |  |

[0001437749-21-003793:notes:127]
|  |  | Year Ended December 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,086,019 |  |  | $ | 57,704 |  |  | $ | 1,143,723 |  |
| Commercial & industrial products |  |  | 513,482 |  |  |  | 358,113 |  |  |  | 871,595 |  |
| Other |  |  | 143,397 |  |  |  | 45,621 |  |  |  | 189,018 |  |
| Total net sales |  | $ | 1,742,898 |  |  | $ | 461,438 |  |  | $ | 2,204,336 |  |

[0001437749-21-003793:notes:128]
|  |  | Year Ended December 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 980,707 |  |  | $ | 62,032 |  |  | $ | 1,042,739 |  |
| Commercial & industrial products |  |  | 461,415 |  |  |  | 358,855 |  |  |  | 820,270 |  |
| Other |  |  | 124,398 |  |  |  | 36,057 |  |  |  | 160,455 |  |
| Total net sales |  | $ | 1,566,520 |  |  | $ | 456,944 |  |  | $ | 2,023,464 |  |

[0001437749-21-003793:notes:129]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage and monitoring solutions, and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-21-003793:notes:130]
C&I products consist of larger output stationary generators used in C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 10kW up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-21-003793:notes:131]
Other consists primarily of aftermarket service parts and product accessories sold to our dealers, the amortization of extended warranty deferred revenue, remote monitoring subscription revenue, grid services, installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-21-003793:notes:132]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-21-003793:notes:133]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 563,394 |  |  | $ | 428,667 |  |  | $ | 388,495 |  |
| International |  |  | 20,379 |  |  |  | 25,448 |  |  |  | 36,057 |  |
| Total adjusted EBITDA |  | $ | 583,773 |  |  | $ | 454,115 |  |  | $ | 424,552 |  |
| Interest expense |  |  | (32,991 | ) |  |  | (41,544 | ) |  |  | (40,956 | ) |
| Depreciation and amortization |  |  | (68,773 | ) |  |  | (60,767 | ) |  |  | (47,408 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 327 |  |  |  | (240 | ) |  |  | (3,532 | ) |
| Non-cash share-based compensation expense (2) |  |  | (20,882 | ) |  |  | (16,694 | ) |  |  | (14,563 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | (926 | ) |  |  | (1,332 | ) |
| Loss on pension settlement (4) |  |  | - |  |  |  | (10,920 | ) |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | (2,151 | ) |  |  | (2,724 | ) |  |  | (3,883 | ) |
| Business optimization and other charges (6) |  |  | (12,158 | ) |  |  | (1,572 | ) |  |  | (952 | ) |
| Other |  |  | (954 | ) |  |  | 879 |  |  |  | (850 | ) |
| Income before provision for income taxes |  | $ | 446,191 |  |  | $ | 319,607 |  |  | $ | 311,076 |  |

[0001437749-21-003793:notes:134]
|  | (1) | Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposal of assets and unrealized mark-to-market adjustments on commodity contracts. |

[0001437749-21-003793:notes:135]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-21-003793:notes:136]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |

[0001437749-21-003793:notes:137]
|  | (4) | Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019. |

[0001437749-21-003793:notes:138]
|  | (5) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-21-003793:notes:139]
|  | (6) | For the year ended December 31, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. For the year ended December 31, 2019, represents severance and other charges related to the consolidation of certain of our facilities. |

[0001437749-21-003793:notes:140]
The following tables summarize additional financial information by reportable segment:

[0001437749-21-003793:notes:141]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 2,659,597 |  |  | $ | 2,123,251 |  |  | $ | 1,868,554 |  |
| International |  |  | 575,826 |  |  |  | 542,418 |  |  |  | 557,760 |  |
| Total |  | $ | 3,235,423 |  |  | $ | 2,665,669 |  |  | $ | 2,426,314 |  |

[0001437749-21-003793:notes:142]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 53,020 |  |  | $ | 46,145 |  |  | $ | 35,586 |  |
| International |  |  | 15,753 |  |  |  | 14,764 |  |  |  | 11,822 |  |
| Total |  | $ | 68,773 |  |  | $ | 60,909 |  |  | $ | 47,408 |  |

[0001437749-21-003793:notes:143]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 51,867 |  |  | $ | 36,007 |  |  | $ | 38,242 |  |
| International |  |  | 10,261 |  |  |  | 24,795 |  |  |  | 9,359 |  |
| Total |  | $ | 62,128 |  |  | $ | 60,802 |  |  | $ | 47,601 |  |

[0001437749-21-003793:notes:144]
The Company’s sales in the United States represent approximately 82%, 75%, and 74% of total sales for the years ended  December 31, 2020, 2019 and 2018, respectively. Approximately 81% and 80% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2020 and 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-21-003793:notes:145]
| 8. | Balance Sheet Details |

[0001437749-21-003793:notes:146]
Inventories consist of the following:

[0001437749-21-003793:notes:147]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Raw material |  | $ | 375,516 |  |  | $ | 328,021 |  |
| Work-in-process |  |  | 6,833 |  |  |  | 10,387 |  |
| Finished goods |  |  | 220,968 |  |  |  | 183,616 |  |
| Total |  | $ | 603,317 |  |  | $ | 522,024 |  |

[0001437749-21-003793:notes:148]
As of  December 31, 2020 and 2019, inventories totaling $9,154 and $18,684, respectively, were on consignment at customer locations.

[0001437749-21-003793:notes:149]
Property and equipment consists of the following:

[0001437749-21-003793:notes:150]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Land and improvements |  | $ | 18,363 |  |  | $ | 18,252 |  |
| Buildings and improvements |  |  | 198,908 |  |  |  | 177,079 |  |
| Machinery and equipment |  |  | 153,696 |  |  |  | 117,114 |  |
| Dies and tools |  |  | 24,190 |  |  |  | 22,040 |  |
| Vehicles |  |  | 6,037 |  |  |  | 3,955 |  |
| Office equipment and systems |  |  | 107,923 |  |  |  | 99,124 |  |
| Leasehold improvements |  |  | 5,276 |  |  |  | 4,293 |  |
| Construction in progress |  |  | 30,227 |  |  |  | 36,299 |  |
| Gross property and equipment |  |  | 544,620 |  |  |  | 478,156 |  |
| Accumulated depreciation |  |  | (200,684 | ) |  |  | (161,180 | ) |
| Total |  | $ | 343,936 |  |  | $ | 316,976 |  |

[0001437749-21-003793:notes:151]
Total property and equipment included finance leases of $27,269 and $26,063 at  December 31, 2020 and 2019, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-21-003793:notes:152]
| 9. | Goodwill and Intangible Assets |

[0001437749-21-003793:notes:153]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2020 and 2019 are as follows:

[0001437749-21-003793:notes:154]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2018 |  | $ | 621,451 |  |  | $ | 143,204 |  |  | $ | 764,655 |  |
| Acquisitions of businesses, net |  |  | 37,758 |  |  |  | 3,078 |  |  |  | 40,836 |  |
| Foreign currency translation |  |  | - |  |  |  | (207 | ) |  |  | (207 | ) |
| Balance at December 31, 2019 |  |  | 659,209 |  |  |  | 146,075 |  |  |  | 805,284 |  |
| Acquisitions of businesses, net |  |  | 42,722 |  |  |  | - |  |  |  | 42,722 |  |
| Foreign currency translation |  |  | 604 |  |  |  | 6,618 |  |  |  | 7,222 |  |
| Balance at December 31, 2020 |  | $ | 702,535 |  |  | $ | 152,693 |  |  | $ | 855,228 |  |

[0001437749-21-003793:notes:155]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-21-003793:notes:156]
The details of the gross goodwill applicable to each reportable segment at  December 31, 2020 and 2019 are as follows:

[0001437749-21-003793:notes:157]
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,205,728 |  |  | $ | (503,193 | ) |  | $ | 702,535 |  |  | $ | 1,162,402 |  |  | $ | (503,193 | ) |  | $ | 659,209 |  |
| International |  |  | 157,304 |  |  |  | (4,611 | ) |  |  | 152,693 |  |  |  | 150,686 |  |  |  | (4,611 | ) |  |  | 146,075 |  |
| Total |  | $ | 1,363,032 |  |  | $ | (507,804 | ) |  | $ | 855,228 |  |  | $ | 1,313,088 |  |  | $ | (507,804 | ) |  | $ | 805,284 |  |

[0001437749-21-003793:notes:158]
The following table summarizes intangible assets by major category as of  December 31, 2020 and 2019:

[0001437749-21-003793:notes:159]
|  |  | Weighted Average |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  | 9 |  |  | $ | 58,729 |  |  | $ | (40,891 | ) |  | $ | 17,838 |  |  | $ | 56,669 |  |  | $ | (36,613 | ) |  | $ | 20,056 |  |
| Customer lists |  | 12 |  |  |  | 370,736 |  |  |  | (321,531 | ) |  |  | 49,205 |  |  |  | 369,932 |  |  |  | (314,380 | ) |  |  | 55,552 |  |
| Patents and technology |  | 10 |  |  |  | 233,271 |  |  |  | (146,544 | ) |  |  | 86,727 |  |  |  | 213,972 |  |  |  | (128,426 | ) |  |  | 85,546 |  |
| Software |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  | 4 |  |  |  | 16,469 |  |  |  | (6,537 | ) |  |  | 9,932 |  |  |  | 12,063 |  |  |  | (3,804 | ) |  |  | 8,259 |  |
| Total finite-lived intangible assets |  |  |  |  | $ | 680,251 |  |  | $ | (516,549 | ) |  | $ | 163,702 |  |  | $ | 653,682 |  |  | $ | (484,269 | ) |  | $ | 169,413 |  |
| Indefinite-lived tradenames |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  | $ | 808,572 |  |  | $ | (516,549 | ) |  | $ | 292,023 |  |  | $ | 782,003 |  |  | $ | (484,269 | ) |  | $ | 297,734 |  |

[0001437749-21-003793:notes:160]
Amortization of intangible assets was $32,280, $28,644 and $22,112 in 2020, 2019 and 2018, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2021 - $33,906; 2022 - $26,649; 2023 - $22,129; 2024 - $18,581; 2025 - $16,808.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001437749-21-003793:notes:161]
| 10. | Leases |

[0001437749-21-003793:notes:162]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (“ROU”) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-21-003793:notes:163]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-21-003793:notes:164]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 20 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 10 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arms’ length transactions.

[0001437749-21-003793:notes:165]
The Company is a lessor of one building that it leases to a third party. The lease income related to this arrangement is not material to the consolidated financial statements.

[0001437749-21-003793:notes:166]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:167]
The components of total lease cost consist of the following:

[0001437749-21-003793:notes:168]
|  |  | Year Ended December 31, 2020 |  |  | Year Ended December 31, 2019 |  |
| Operating lease cost |  | $ | 18,648 |  |  | $ | 9,647 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 2,587 |  |  |  | 2,531 |  |
| Interest on lease liabilities |  |  | 2,237 |  |  |  | 2,227 |  |
| Total lease cost |  | $ | 23,472 |  |  | $ | 14,405 |  |

[0001437749-21-003793:notes:169]
Prior to the adoption of ASU 2016-02 in 2019, lease expense consisted of payments on operating leases. Total rent expense related to operating leases for the year ended  December 31, 2018 was approximately $10,739.

[0001437749-21-003793:notes:170]
As of  January 1, 2019, the date of the adoption of ASU 2016-02, the Company recognized ROU assets and lease liabilities related to operating leases of $42,024 and $42,056, respectively, and there was no cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-21-003793:notes:171]
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Operating Leases |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 62,030 |  |  | $ | 35,950 |  |
| Operating lease liabilities - current (2) |  | $ | 17,192 |  |  | $ | 7,231 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 46,558 |  |  |  | 29,778 |  |
| Total operating lease liabilities |  | $ | 63,750 |  |  | $ | 37,009 |  |
| Finance Leases |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 34,929 |  |  | $ | 29,142 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (7,660 | ) |  |  | (3,079 | ) |
| Finance lease ROU assets, net (4) |  | $ | 27,269 |  |  | $ | 26,063 |  |
| Finance lease liabilities - current (5) |  | $ | 2,311 |  |  | $ | 1,830 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 25,060 |  |  |  | 24,132 |  |
| Total finance lease liabilities |  | $ | 27,371 |  |  | $ | 25,962 |  |

[0001437749-21-003793:notes:172]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-21-003793:notes:173]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-21-003793:notes:174]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-21-003793:notes:175]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-21-003793:notes:176]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-21-003793:notes:177]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-21-003793:notes:178]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-21-003793:notes:179]
|  |  | Year Ended December 31, 2020 |  |  | Year Ended December 31, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 18,412 |  |  | $ | 10,125 |  |
| Operating cash flows from finance leases |  |  | 1,871 |  |  |  | 1,864 |  |
| Financing cash flows from finance leases |  |  | 3,957 |  |  |  | 3,237 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 41,678 |  |  |  | 4,021 |  |
| Finance leases |  |  | 3,737 |  |  |  | 8,797 |  |

[0001437749-21-003793:notes:180]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2020 is as follows:

[0001437749-21-003793:notes:181]
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating Leases |  |  | 4.92 |  |
| Finance Leases |  |  | 12.90 |  |
| Weighted average discount rate |  |  |  |  |
| Operating Leases |  |  | 4.48 | % |
| Finance Leases |  |  | 7.66 | % |

[0001437749-21-003793:notes:182]
The maturities of the Company’s lease liabilities as of  December 31, 2020 are as follows:

[0001437749-21-003793:notes:183]
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2021 |  | $ | 4,146 |  |  | $ | 19,530 |  |
| 2022 |  |  | 4,292 |  |  |  | 18,135 |  |
| 2023 |  |  | 3,112 |  |  |  | 9,519 |  |
| 2024 |  |  | 2,999 |  |  |  | 7,452 |  |
| 2025 |  |  | 2,678 |  |  |  | 5,359 |  |
| After 2025 |  |  | 28,596 |  |  |  | 11,711 |  |
| Total minimum lease payments |  |  | 45,823 |  |  |  | 71,706 |  |
| Interest component |  |  | (18,452 | ) |  |  | (7,956 | ) |
| Present value of minimum lease payments |  | $ | 27,371 |  |  | $ | 63,750 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-21-003793:notes:184]
| 11. | Product Warranty Obligations |

[0001437749-21-003793:notes:185]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-21-003793:notes:186]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 49,316 |  |  | $ | 41,785 |  |  | $ | 35,422 |  |
| Product warranty reserve assumed in acquisition |  |  | 124 |  |  |  | 1,062 |  |  |  | - |  |
| Payments |  |  | (33,496 | ) |  |  | (26,096 | ) |  |  | (20,029 | ) |
| Provision for warranty issued |  |  | 42,093 |  |  |  | 32,060 |  |  |  | 26,910 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,181 |  |  |  | 505 |  |  |  | (518 | ) |
| Balance at end of period |  | $ | 59,218 |  |  | $ | 49,316 |  |  | $ | 41,785 |  |

[0001437749-21-003793:notes:187]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-21-003793:notes:188]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 78,738 |  |  | $ | 68,340 |  |  | $ | 57,854 |  |
| Deferred revenue contracts issued |  |  | 26,968 |  |  |  | 24,483 |  |  |  | 21,440 |  |
| Amortization of deferred revenue contracts |  |  | (15,918 | ) |  |  | (14,085 | ) |  |  | (10,954 | ) |
| Balance at end of period |  | $ | 89,788 |  |  | $ | 78,738 |  |  | $ | 68,340 |  |

[0001437749-21-003793:notes:189]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  December 31, 2020 is as follows:

[0001437749-21-003793:notes:190]
| 2021 |  | $ | 18,754 |  |
| 2022 |  |  | 18,819 |  |
| 2023 |  |  | 16,464 |  |
| 2024 |  |  | 11,849 |  |
| After 2024 |  |  | 23,902 |  |
| Total |  | $ | 89,788 |  |

[0001437749-21-003793:notes:191]
The Company has a post-sale extended warranty marketing program with a third party. In the program’s agreement, the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. The balance of deferred contract costs as of  December 31, 2020 and 2019 was $6,869 and $6,190, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2020, 2019 and 2018 was $1,303, $869 and $615, respectively.

[0001437749-21-003793:notes:192]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-21-003793:notes:193]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 37,417 |  |  | $ | 27,885 |  |
| Long-term portion - other long-term liabilities |  |  | 21,801 |  |  |  | 21,431 |  |
| Total |  | $ | 59,218 |  |  | $ | 49,316 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 18,857 |  |  | $ | 15,519 |  |
| Long-term portion - other long-term liabilities |  |  | 70,931 |  |  |  | 63,219 |  |
| Total |  | $ | 89,788 |  |  | $ | 78,738 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-003793:notes:194]
| 12. | Credit Agreements |

[0001437749-21-003793:notes:195]
Short-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-21-003793:notes:196]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | - |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,282 |  |  |  | 27,753 |  |
| Total |  | $ | 39,282 |  |  | $ | 58,714 |  |

[0001437749-21-003793:notes:197]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-21-003793:notes:198]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,450 | ) |  |  | (18,048 | ) |
| ABL facility |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,371 |  |  |  | 25,962 |  |
| Other |  |  | 3,990 |  |  |  | 2,236 |  |
| Total |  |  | 845,911 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,836 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,311 |  |  |  | 1,830 |  |
| Total |  | $ | 841,764 |  |  | $ | 837,767 |  |

[0001437749-21-003793:notes:199]
Maturities of long-term borrowings outstanding at  December 31, 2020, excluding finance lease obligations as their maturities are disclosed in Note 10, “Leases,” and before considering original issue discount and deferred financing costs, are as follows:

[0001437749-21-003793:notes:200]
| 2021 |  | $ | 1,836 |  |
| 2022 |  |  | 1,905 |  |
| 2023 |  |  | 46 |  |
| 2024 |  |  | 115 |  |
| After 2024 |  |  | 830,088 |  |
| Total |  | $ | 833,990 |  |

[0001437749-21-003793:notes:201]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%.

[0001437749-21-003793:notes:202]
In  June 2018, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 0.75% or adjusted LIBOR rate plus a fixed applicable margin of 1.75%. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $829 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $118 of transaction fees in the second quarter of 2018.

[0001437749-21-003793:notes:203]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally, the Company made a voluntary prepayment of $49,000 on the Term Loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:204]
In connection with our Term Loan amendment in  December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. The Company plans to work with its lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease.

[0001437749-21-003793:notes:205]
The Term Loan does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  December 31, 2020, the Company’s net secured leverage ratio was 1.12 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-003793:notes:206]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is currently  June 12, 2023. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case subject to adjustments based upon average availability under the ABL Facility.

[0001437749-21-003793:notes:207]
In  June 2018, the Company amended the ABL Facility; increasing it from $250,000 to $300,000 and extending the maturity date to  June 12, 2023. In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.375% or an adjusted LIBOR rate plus an applicable margin of 1.375%. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $755 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off $34 of capitalized debt issuance costs as a loss on extinguishment of debt in the second quarter of 2018.

[0001437749-21-003793:notes:208]
In  June 2018, the Company borrowed $50,000 under the ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off $1,298 of original issue discount and capitalized debt issuance costs during the second quarter of 2018 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. In  October 2018, the Company repaid the $50,000 outstanding ABL Facility balance with cash on hand.

[0001437749-21-003793:notes:209]
As of  December 31, 2020, there was no outstanding balance under the ABL Facility, leaving $299,621 of availability, net of outstanding letters of credit.

[0001437749-21-003793:notes:210]
As of  December 31, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $39,282 and $58,714, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-21-003793:notes:211]
| 13. | Stock Repurchase Programs |

[0001437749-21-003793:notes:212]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program, which expired in  October 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the years ended  December 31, 2020 and 2019, the Company did not repurchase any shares of its common stock. During the year ended  December 31, 2018, the Company repurchased 560,000 shares of its common stock for $25,656, all funded with cash on hand. Since the inception of all programs starting in  August 2015, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-003793:notes:213]
| 14. | Earnings Per Share |

[0001437749-21-003793:notes:214]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-21-003793:notes:215]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-21-003793:notes:216]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 350,576 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,247 | ) |  |  | 1,253 |  |  |  | (17,970 | ) |
| Net income attributable to common shareholders |  | $ | 349,329 |  |  | $ | 253,260 |  |  | $ | 220,287 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,280,889 |  |  |  | 61,926,986 |  |  |  | 61,662,031 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,456,845 |  |  |  | 938,460 |  |  |  | 571,194 |  |
| Diluted shares |  |  | 63,737,734 |  |  |  | 62,865,446 |  |  |  | 62,233,225 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.61 |  |  | $ | 4.09 |  |  | $ | 3.57 |  |
| Diluted |  | $ | 5.48 |  |  | $ | 4.03 |  |  | $ | 3.54 |  |

[0001437749-21-003793:notes:217]
|  | (1) | Excludes approximately 26,100 stock options for the year ended December 31, 2018, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the years ended December 31, 2020 and 2019. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-003793:notes:218]
| 15. | Income Taxes |

[0001437749-21-003793:notes:219]
The Company’s provision for income taxes consists of the following:

[0001437749-21-003793:notes:220]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 62,714 |  |  | $ | 41,686 |  |  | $ | 32,072 |  |
| State |  |  | 13,071 |  |  |  | 4,211 |  |  |  | 9,639 |  |
| Foreign |  |  | 1,974 |  |  |  | 2,660 |  |  |  | 4,546 |  |
| Total |  |  | 77,759 |  |  |  | 48,557 |  |  |  | 46,257 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 20,452 |  |  |  | 19,393 |  |  |  | 22,225 |  |
| State |  |  | 1,243 |  |  |  | 1,390 |  |  |  | 1,910 |  |
| Foreign |  |  | (1,197 | ) |  |  | (1,263 | ) |  |  | 479 |  |
| Total |  |  | 20,498 |  |  |  | 19,520 |  |  |  | 24,614 |  |
| Change in valuation allowance |  |  | 716 |  |  |  | (778 | ) |  |  | (1,015 | ) |
| Provision for income taxes |  | $ | 98,973 |  |  | $ | 67,299 |  |  | $ | 69,856 |  |

[0001437749-21-003793:notes:221]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2020, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2017. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2009 through 2019 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2015 through 2019.

[0001437749-21-003793:notes:222]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made, and could impact the Company’s financial results.

[0001437749-21-003793:notes:223]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-21-003793:notes:224]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 24,358 |  |  | $ | 21,053 |  |
| Deferred revenue |  |  | 15,851 |  |  |  | 14,697 |  |
| Inventories |  |  | 11,795 |  |  |  | 9,879 |  |
| Stock-based compensation |  |  | 8,348 |  |  |  | 7,490 |  |
| Operating loss and credit carryforwards |  |  | 31,275 |  |  |  | 28,356 |  |
| Bad debt |  |  | 1,633 |  |  |  | 1,094 |  |
| Other |  |  | 8,558 |  |  |  | 4,275 |  |
| Valuation allowance |  |  | (5,740 | ) |  |  | (5,024 | ) |
| Total deferred tax assets |  |  | 96,078 |  |  |  | 81,820 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 171,831 |  |  |  | 142,159 |  |
| Depreciation |  |  | 33,716 |  |  |  | 27,864 |  |
| Debt refinancing costs |  |  | 3,544 |  |  |  | 4,119 |  |
| Prepaid expenses |  |  | 1,259 |  |  |  | 1,073 |  |
| Total deferred tax liabilities |  |  | 210,350 |  |  |  | 175,215 |  |
| Net deferred tax liabilities |  | $ | (114,272 | ) |  | $ | (93,395 | ) |

[0001437749-21-003793:notes:225]
As of  December 31, 2020 and 2019, deferred tax assets of $1,497 and $2,933, and deferred tax liabilities of $115,769 and $96,328, respectively, were reflected on the consolidated balance sheets.

[0001437749-21-003793:notes:226]
The Company maintains a valuation allowance against the deferred tax assets when it is uncertain it will generate sufficient taxable income to utilize the asset. During 2020, the valuation allowance increased by $716 primarily due to state net operating losses which are unlikely to be utilized, partially offset by utilization of loss carryforwards in certain foreign subsidiaries.

[0001437749-21-003793:notes:227]
At  December 31, 2020, the Company had various state research & development and state manufacturing tax credit carryforwards of approximately $4,513 and $19,303, respectively, which expire between 2024 and 2035. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-21-003793:notes:228]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-21-003793:notes:229]
|  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 6,720 |  |  | $ | 5,635 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 332 |  |  |  | 633 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 750 |  |  |  | 495 |  |
| Statute of limitation expirations |  |  | (189 | ) |  |  | (43 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 7,613 |  |  | $ | 6,720 |  |

[0001437749-21-003793:notes:230]
The unrecognized tax benefit as of  December 31, 2020 and 2019, if recognized, would favorably impact the effective tax rate.

[0001437749-21-003793:notes:231]
As of  December 31, 2020 and 2019, total accrued interest of approximately $95 and $71, respectively, and accrued penalties of approximately $274 and $195, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-21-003793:notes:232]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending  December 31, 2021.

[0001437749-21-003793:notes:233]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended  December 31, 2020, 2019 and 2018 are as follows:

[0001437749-21-003793:notes:234]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 21.0 | % |
| State taxes |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 4.7 |  |
| State tax rate differential |  |  | 0.0 |  |  |  | (1.0 | ) |  |  | - |  |
| Research and development credits |  |  | (1.1 | ) |  |  | (0.8 | ) |  |  | (1.3 | ) |
| State credits |  |  | (1.5 | ) |  |  | (1.0 | ) |  |  | (1.0 | ) |
| Share-based compensation (1) |  |  | (1.0 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Tax Act impact |  |  | 0.0 |  |  |  | - |  |  |  | (0.2 | ) |
| Other |  |  | 0.5 |  |  |  | (0.8 | ) |  |  | (0.2 | ) |
| Effective tax rate |  |  | 22.2 | % |  |  | 21.1 | % |  |  | 22.5 | % |

[0001437749-21-003793:notes:235]
|  | (1) | With the adoption of ASU 2016-09 in 2017, excess tax benefits from equity awards are reflected within the provision for income taxes rather than within the consolidated balance sheet. |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-21-003793:notes:236]
| 16. | Benefit Plans |

[0001437749-21-003793:notes:237]
Medical and Dental Plans

[0001437749-21-003793:notes:238]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $24,617, $18,290, and $14,660 for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:239]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-21-003793:notes:240]
Savings Plan

[0001437749-21-003793:notes:241]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008 that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures  may be applied against plan expenses and Company contributions. The Company recognized $5,332, $4,791 and $4,193 of expense related to these plans for the years ended  December 31, 2020, 2019 and 2018, respectively.

[0001437749-21-003793:notes:242]
Pension Plans

[0001437749-21-003793:notes:243]
Historically, the Company maintained noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The Pension Plans were frozen effective  December 31, 2008. Effective  December 31, 2018, the Pension Plans were merged into the same plan (Pension Plan), resulting in no change to benefits for participants. The benefits under the salaried plan were based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan were based on a unit amount at the date of termination multiplied by the participant’s years of credited service.

[0001437749-21-003793:notes:244]
In 2019, the Company completed the termination of its Pension Plan.  In connection with the Company’s activities to terminate the plan, lump sum distributions were made in the fourth quarter of 2019 to individuals who elected lump sum distributions, including rolling over their accounts to the Company’s 401(k) savings plan. Also in the fourth quarter of 2019, annuity contracts were purchased to settle obligations for the remaining participants. Upon settlement of the pension liability, the Company reclassified related unrecognized pension losses recorded in AOCL to the consolidated statements of comprehensive income. As a result, the Company recorded pre-tax settlement charges of $10,920 in the fourth quarter of the year ended  December 31, 2019.

[0001437749-21-003793:notes:245]
Certain of the Company’s foreign subsidiaries participate in local statutory defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in other long-term liabilities in the Company’s consolidated balance sheets and are not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-21-003793:notes:246]
| 17. | Share Plans |

[0001437749-21-003793:notes:247]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010 in connection with its initial public offering. The 2010 Plan, as amended, allowed for granting of up to 9.1 million share-based awards to executives, directors and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Awards under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the Plan, net of estimated forfeitures, was $11,681, $15,738, and $14,563 for the years ended  December 31, 2020, 2019 and 2018, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:248]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). Following the effectiveness of the 2019 Plan, no new awards  may be made under the Plan. The 2019 Plan allows for granting of up to 2.7 million share-based awards to executives, directors and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $9,201 and $956 for the years ended  December 31, 2020 and 2019, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:249]
Stock Options - Stock options granted in 2020 have an exercise price between $91.00 per share and $158.89 per share; stock options granted in 2019 have an exercise price of $52.07 per share; and stock options granted in 2018 have an exercise price between $43.88 per share and $45.29 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-21-003793:notes:250]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 24,070, 32,211 and 63,817 for the years ended  December 31, 2020, 2019 and 2018, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-21-003793:notes:251]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds from the cashless for cash exercise of stock options were $13,089, $9,395 and $5,614 for the years ended  December 31, 2020, 2019 and 2018, respectively, and are reflected as a financing activity in the consolidated statement of cash flows.

[0001437749-21-003793:notes:252]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $7,297, $3,360 and $3,846 for the years ended  December 31, 2020, 2019 and 2018, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-21-003793:notes:253]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history.

[0001437749-21-003793:notes:254]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2020, 2019 and 2018 are as follows:

[0001437749-21-003793:notes:255]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Weighted average grant date fair value |  | $ | 35.79 |  |  | $ | 19.33 |  |  | $ | 17.86 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 32 | % |  |  | 33 | % |  |  | 37 | % |
| Risk free interest rate |  |  | 1.56 | % |  |  | 2.52 | % |  |  | 2.60 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-21-003793:notes:256]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2020, 2019 and 2018 is as follows:

[0001437749-21-003793:notes:257]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2017 |  |  | 1,472,130 |  |  | $ | 33.11 |  |  |  | 7.3 |  |  | $ | 25,281 |  |
| Granted |  |  | 366,231 |  |  |  | 43.88 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (267,909 | ) |  |  | 19.90 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (49,285 | ) |  |  | 43.34 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2018 |  |  | 1,521,167 |  |  |  | 37.70 |  |  |  | 7.0 |  |  | $ | 19,212 |  |
| Granted |  |  | 369,779 |  |  |  | 52.07 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (263,250 | ) |  |  | 30.75 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (35,010 | ) |  |  | 43.79 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2019 |  |  | 1,592,686 |  |  |  | 42.04 |  |  |  | 6.9 |  |  | $ | 93,242 |  |
| Granted |  |  | 173,650 |  |  |  | 102.32 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (216,196 | ) |  |  | 39.88 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (21,450 | ) |  |  | 50.25 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2020 |  |  | 1,528,690 |  |  |  | 49.08 |  |  |  | 6.3 |  |  | $ | 272,553 |  |
| Exercisable as of December 31, 2020 |  |  | 845,365 |  |  |  | 39.15 |  |  |  | 4.9 |  |  | $ | 159,145 |  |

[0001437749-21-003793:notes:258]
As of  December 31, 2020, there was $10,673 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.4 years. Total share-based compensation cost related to the stock options for the years ended  December 31, 2020, 2019 and 2018 was $5,860, $5,597 and $4,998, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:259]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2018 awards covers the years 2018 through 2020, the performance period for the 2019 awards covers the years 2019 through 2021, and the performance period for the 2020 awards covers the years 2020 through 2022. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-21-003793:notes:260]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 70,718, 55,953 and 38,186 for the years ended  December 31, 2020, 2019 and 2018, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $7,613, $3,078 and $1,812 for the years ended  December 31, 2020, 2019 and 2018, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-21-003793:notes:261]
A summary of the Company's restricted stock activity for the years ended  December 31, 2020, 2019 and 2018 is as follows:

[0001437749-21-003793:notes:262]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2017 |  |  | 392,276 |  |  | $ | 37.77 |  |
| Granted |  |  | 208,803 |  |  |  | 44.49 |  |
| Vested |  |  | (128,433 | ) |  |  | 39.03 |  |
| Forfeited |  |  | (46,650 | ) |  |  | 39.43 |  |
| Non-vested as of December 31, 2018 |  |  | 425,996 |  |  |  | 40.50 |  |
| Granted |  |  | 265,255 |  |  |  | 62.38 |  |
| Vested |  |  | (184,628 | ) |  |  | 38.78 |  |
| Forfeited |  |  | (14,986 | ) |  |  | 44.23 |  |
| Non-vested as of December 31, 2019 |  |  | 491,637 |  |  |  | 52.84 |  |
| Granted |  |  | 183,868 |  |  |  | 95.14 |  |
| Vested |  |  | (200,390 | ) |  |  | 45.10 |  |
| Forfeited |  |  | (18,921 | ) |  |  | 56.58 |  |
| Non-vested as of December 31, 2020 |  |  | 456,194 |  |  |  | 68.42 |  |

[0001437749-21-003793:notes:263]
As of  December 31, 2020, there was $20,608 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 1.9 years. Total share-based compensation cost related to the restricted stock for the years ended  December 31, 2020, 2019 and 2018, inclusive of performance shares, was $15,022, $11,097 and $9,565, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-21-003793:notes:264]
During 2020, 2019 and 2018, 15,275, 22,544 and 33,419 shares of stock, respectively, were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company or a triggering event occurs. 10,528, 16,604 and 22,675 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board of Directors for the years 2020, 2019, and 2018, respectively. Total share-based compensation cost for these share grants in 2020, 2019 and 2018 was $1,558, $1,391 and $1,718, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-003793:notes:265]
| 18. | Commitments and Contingencies |

[0001437749-21-003793:notes:266]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  December 31, 2020 and 2019 was approximately $55,600 and $49,600, respectively.

[0001437749-21-003793:notes:267]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-21-003793:notes:268]
| 19. | Quarterly Financial Information (Unaudited) |

[0001437749-21-003793:notes:269]
|  |  | Quarters in the Year Ended December 31, 2020 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 475,915 |  |  | $ | 546,848 |  |  | $ | 701,355 |  |  | $ | 761,082 |  |
| Gross profit |  |  | 172,320 |  |  |  | 208,983 |  |  |  | 276,149 |  |  |  | 300,202 |  |
| Operating income |  |  | 62,862 |  |  |  | 89,553 |  |  |  | 155,637 |  |  |  | 171,054 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 44,460 |  |  |  | 66,145 |  |  |  | 114,970 |  |  |  | 125,001 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.69 |  |  | $ | 1.04 |  |  | $ | 1.86 |  |  | $ | 2.02 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.68 |  |  | $ | 1.02 |  |  | $ | 1.82 |  |  | $ | 1.97 |  |

[0001437749-21-003793:notes:270]
|  |  | Quarters in the Year Ended December 31, 2019 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 470,353 |  |  | $ | 541,916 |  |  | $ | 601,135 |  |  | $ | 590,932 |  |
| Gross profit |  |  | 162,175 |  |  |  | 195,838 |  |  |  | 217,517 |  |  |  | 222,222 |  |
| Operating income |  |  | 71,173 |  |  |  | 90,926 |  |  |  | 105,556 |  |  |  | 104,508 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 44,861 |  |  |  | 61,958 |  |  |  | 75,574 |  |  |  | 69,614 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.77 |  |  | $ | 0.99 |  |  | $ | 1.20 |  |  | $ | 1.14 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.76 |  |  | $ | 0.98 |  |  | $ | 1.18 |  |  | $ | 1.12 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-21-003793:notes:271]
| 20. | Valuation and Qualifying Accounts |

[0001437749-21-003793:notes:272]
For the years ended  December 31, 2020, 2019 and 2018:

[0001437749-21-003793:notes:273]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Additions Charged to Retained Earnings (1) |  |  | Charges to Reserve, Net (2) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 6,968 |  |  | $ | 4,645 |  |  | $ | 1,147 |  |  | $ | (957 | ) |  | $ | 198 |  |  | $ | 12,001 |  |
| Reserves for inventory |  |  | 24,293 |  |  |  | 11,353 |  |  |  | - |  |  |  | (8,788 | ) |  |  | 959 |  |  |  | 27,817 |  |
| Valuation of deferred tax assets |  |  | 5,024 |  |  |  | 716 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5,740 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4,873 |  |  | $ | 3,086 |  |  | $ | - |  |  | $ | (1,033 | ) |  | $ | 42 |  |  | $ | 6,968 |  |
| Reserves for inventory |  |  | 23,140 |  |  |  | 4,821 |  |  |  | - |  |  |  | (3,867 | ) |  |  | 199 |  |  |  | 24,293 |  |
| Valuation of deferred tax assets |  |  | 5,802 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (778 | ) |  |  | 5,024 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4,805 |  |  | $ | 1,941 |  |  | $ | - |  |  | $ | (2,123 | ) |  | $ | 250 |  |  | $ | 4,873 |  |
| Reserves for inventory |  |  | 15,987 |  |  |  | 10,004 |  |  |  | - |  |  |  | (3,720 | ) |  |  | 869 |  |  |  | 23,140 |  |
| Valuation of deferred tax assets |  |  | 6,817 |  |  |  | 478 |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | 5,802 |  |

[0001437749-21-003793:notes:274]
|  | (1) | Result of adopting ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. |
|  | (2) | Deductions from the allowance for doubtful accounts equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-003793:notes:275]
| 21. | Subsequent Events |

[0001437749-21-003793:notes:276]
The Company performed an evaluation of subsequent events through the date these financial statements were issued and no such events were identified.
