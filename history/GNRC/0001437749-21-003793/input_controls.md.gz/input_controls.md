# GNRC 10-K controls and the auditor's report


## auditors_report

[0001437749-21-003793:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001437749-21-003793:auditors_report:2]
To the stockholders and the Board of Directors of Generac Holdings Inc.

[0001437749-21-003793:auditors_report:3]
Waukesha, WI

[0001437749-21-003793:auditors_report:4]
Opinion on the Financial Statements

[0001437749-21-003793:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Generac Holdings Inc. and subsidiaries (the "Company") as of December 31, 2020 and 2019, the related consolidated statements of  comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended December 31, 2020, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2020, in conformity with accounting principles generally accepted in the United States of America.

[0001437749-21-003793:auditors_report:6]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2020, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated February 23, 2021, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0001437749-21-003793:auditors_report:7]
Change in Accounting Principle

[0001437749-21-003793:auditors_report:8]
As discussed in Note 10 to the financial statements, effective January 1, 2019, the Company adopted FASB Accounting Standards Update 2016-02, Leases (Topic 842), using the modified retrospective approach.

[0001437749-21-003793:auditors_report:9]
Basis for Opinion

[0001437749-21-003793:auditors_report:10]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-21-003793:auditors_report:11]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001437749-21-003793:auditors_report:12]
Critical Audit Matter

[0001437749-21-003793:auditors_report:13]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001437749-21-003793:auditors_report:14]
Goodwill – Refer to Note 9 to the financial statements.

[0001437749-21-003793:auditors_report:15]
Critical Audit Matter Description

[0001437749-21-003793:auditors_report:16]
The Company’s evaluation of goodwill for impairment involves the comparison of the fair value of each reporting unit to its carrying value. The Company’s estimate for each reporting unit is based on the present value of estimated future cash flows attributable to the respective reporting unit. This requires management to make significant estimates and assumptions including estimates of future growth rates, inflation rates and discount rates based on the estimated weighted average cost of capital for the business. Changes in the assumptions could have a significant impact on the fair value, which could result in an impairment charge. The Company performed their annual impairment assessment of its reporting units as of October 31, 2020.  In the October 31, 2020 impairment test calculation, the Latin America and Generac Mobile reporting units each had an estimated fair value that exceeded their carrying value by approximately 10%. Because the estimated fair value exceeded the carrying value for each, no impairment was recorded.  The carrying value of goodwill for the Company’s Latin America and Generac Mobile reporting units as of the October 31, 2020 impairment assessment was $43.6 million and $48.6 million, respectively.

[0001437749-21-003793:auditors_report:17]
Key financial assumptions utilized to determine the fair value of the Latin America reporting unit include revenue growth levels that reflect the impact of the COVID-19 pandemic with an eventual return to normalized revenue growth patterns and profitability from recovering end markets, improving profit margins, a 3% terminal growth rate and a 11.7% discount rate. Key financial assumptions utilized to determine the fair value of the Generac Mobile reporting unit include revenue growth levels that reflect the impact of the COVID-19 pandemic as well as the impact of a decline in oil prices on end markets with an eventual return to normalized revenue growth levels from recovering end markets, improving profit margins, a 3% terminal growth rate and a 14.6% discount rate.

[0001437749-21-003793:auditors_report:18]
The principle consideration for our determination that the evaluation of goodwill is a critical audit matter is that there is a high degree of auditor effort, judgment and subjectivity involved in designing and performing procedures to evaluate the reasonableness of management’s key financial assumptions utilized to determine the fair value of the Latin America and Generac Mobile reporting units.

[0001437749-21-003793:auditors_report:19]
How the Critical Audit Matter Was Addressed in the Audit

[0001437749-21-003793:auditors_report:20]
Our audit procedures related to the forecasts of future revenue growth rates, improving profit margins, the terminal growth rate and the selection of the discount rate for the Latin America and Generac Mobile reporting units included the following, among others:

[0001437749-21-003793:auditors_report:21]
|  | ● | Evaluated the design and effectiveness of the controls over management’s goodwill impairment evaluation, including those over the determination of the fair value of the reporting unit, such as controls related to management’s forecast and the selection of the discount rate. |

[0001437749-21-003793:auditors_report:22]
|  | ● | Obtained the Company’s discounted cash flow model and evaluated the valuation analysis for mathematical accuracy. |

[0001437749-21-003793:auditors_report:23]
|  | ● | Utilized fair value specialists to evaluate whether the valuation techniques applied by management were appropriate. |

[0001437749-21-003793:auditors_report:24]
|  | ● | Assessed management’s historical ability to accurately forecast the Company’s results of operations. |

[0001437749-21-003793:auditors_report:25]
|  | ● | Assessed management’s intent and/or ability to take specific actions included in the discounted cash flow model. |

[0001437749-21-003793:auditors_report:26]
|  | ● | Evaluated the reasonableness of management’s forecasts by comparing the forecasts to (1) historical results, (2) internal communications to the Board of Directors, and (3) forecasted information included in industry reports. |

[0001437749-21-003793:auditors_report:27]
|  | ● | Independently calculated a discount rate and compared it to the rate utilized by the Company. |

[0001437749-21-003793:auditors_report:28]
/s/ Deloitte & Touche LLP

[0001437749-21-003793:auditors_report:29]
Milwaukee, Wisconsin

[0001437749-21-003793:auditors_report:30]
February 23, 2021

[0001437749-21-003793:auditors_report:31]
We have served as the Company’s auditor since 2016.

[0001437749-21-003793:auditors_report:32]
Report of Independent Registered Public Accounting Firm

[0001437749-21-003793:auditors_report:33]
To the stockholders and the Board of Directors of Generac Holdings Inc.

[0001437749-21-003793:auditors_report:34]
Waukesha, Wisconsin

[0001437749-21-003793:auditors_report:35]
Opinion on Internal Control over Financial Reporting

[0001437749-21-003793:auditors_report:36]
We have audited the internal control over financial reporting of Generac Holdings Inc. and subsidiaries (the “Company”) as of December 31, 2020, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2020, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0001437749-21-003793:auditors_report:37]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 31, 2020, of the Company and our report dated February 23, 2021, expressed an unqualified opinion on those financial statements.

[0001437749-21-003793:auditors_report:38]
As described in Management’s Report on Internal Control over Financial Reporting, management excluded West Coast Energy Systems LLC, which was acquired in July 2020, Mean Green Products, LLC, which was acquired in September 2020, and Enbala Power Networks Inc., which was acquired in October 2020, and whose financial statements constitute 4.7% and 2.6% of net and total assets, respectively, 0.6% of net sales, and (0.3)% of net income of the consolidated financial statements of the Company as of and for the year ended December 31, 2020. Accordingly, our audit did not include the internal control over financial reporting at West Coast Energy Systems LLC, Mean Green Products, LLC and Enbala Power Networks Inc.

[0001437749-21-003793:auditors_report:39]
Basis for Opinion

[0001437749-21-003793:auditors_report:40]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001437749-21-003793:auditors_report:41]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001437749-21-003793:auditors_report:42]
Definition and Limitations of Internal Control over Financial Reporting

[0001437749-21-003793:auditors_report:43]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001437749-21-003793:auditors_report:44]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-21-003793:auditors_report:45]
/s/ Deloitte & Touche LLP

[0001437749-21-003793:auditors_report:46]
Milwaukee, Wisconsin

[0001437749-21-003793:auditors_report:47]
February 23, 2021


## item_9a

[0001437749-21-003793:item_9a:1]
Item 9A. Controls and Procedures

[0001437749-21-003793:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-21-003793:item_9a:3]
Disclosure controls and procedures are controls and other procedures that are designed to ensure that information required to be disclosed by us in reports we file or submit under the Securities Exchange Act of 1934 (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure.

[0001437749-21-003793:item_9a:4]
Our management, with the participation of our Chief Executive Officer and our Chief Financial Officer, has conducted an evaluation of the design and operation of our disclosure controls and procedures as defined in Rule 13a-15(e) and 15d-15(e) under the Exchange Act as of the end of the period covered by this report on Form 10-K. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective in providing reasonable assurance that the information required to be disclosed in this report on Form 10-K has been recorded, processed, summarized and reported as of the end of the period covered by this report on Form 10-K.

[0001437749-21-003793:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001437749-21-003793:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Our internal control over financial reporting is designed under the supervision of our Chief Executive Officer and Chief Financial Officer to provide reasonable assurance regarding the reliability of financial reporting and the preparation of the consolidated financial statements in accordance with U.S. GAAP.

[0001437749-21-003793:item_9a:7]
Internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of the financial statements in accordance with U.S. GAAP, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the Company’s financial statements.

[0001437749-21-003793:item_9a:8]
There are inherent limitations to the effectiveness of any internal control over financial reporting, including the possibility of human error or the circumvention or overriding of the controls. Accordingly, even an effective internal control over financial reporting can provide only reasonable assurance of achieving its objective. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate, because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-21-003793:item_9a:9]
Under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, our management conducted an assessment of the effectiveness of internal control over financial reporting as of December 31, 2020 based on the criteria established in the 2013 Internal Control – Integrated Framework, issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, our management has concluded that our internal control over financial reporting was effective as of December 31, 2020. In conducting this assessment, our management excluded West Coast Energy Systems LLC, which was acquired in July 2020, Mean Green Products, LLC, which was acquired in September 2020, and Enbala Power Networks Inc., which was acquired in October 2020, and whose financial statements constitute 4.7% and 2.6% of net and total assets, respectively, 0.6% of net sales, and (0.3)% of net income of the consolidated financial statement amounts as of and for the year ended December 31, 2020.

[0001437749-21-003793:item_9a:10]
Deloitte & Touche LLP, the Company’s independent registered public accounting firm, issued an attestation report on the effectiveness of the Company’s internal control over financial reporting as of December 31, 2020, which is included herein.

[0001437749-21-003793:item_9a:11]
Changes in Internal Control Over Financial Reporting

[0001437749-21-003793:item_9a:12]
There have been no changes in our internal control over financial reporting that occurred during the three months ended December 31, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-21-003793:item_9a:13]
67
