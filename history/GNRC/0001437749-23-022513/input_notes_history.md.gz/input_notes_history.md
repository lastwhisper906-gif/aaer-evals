# GNRC note change history — 0001437749-23-013331 → 0001437749-23-022513


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-08):
[0001437749-23-022513:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2023 and  December 31, 2022 was approximately $166.9 million and $212.2 million respectively.
  (was, 2023-05-09, similarity 0.9925):
[0001437749-23-013331:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2023 and  December 31, 2022 was approximately $179.8 million and $212.2 million respectively.

- changed (2023-08-08):
[0001437749-23-022513:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (“PHS”) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, PHS filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which PHS characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to PHS but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.
  (was, 2023-05-09, similarity 0.8773):
[0001437749-23-013331:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred. The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which Power Home Solar characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll Power Home Solar’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Company intends to vigorously defend against the claims in the complaint, whichever forum in which it  may proceed.

- changed (2023-08-08):
[0001437749-23-022513:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Generac Power disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.
  (was, 2023-05-09, similarity 0.9803):
[0001437749-23-013331:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

- added (2023-08-08):
[0001437749-23-022513:note_history:4]
Eight additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  July 5, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power and/or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative classes allegedly incurred. In some of these cases, the Company as well as Generac Power has been named as a defendant. The cases were filed in or removed to the federal district courts for the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386; Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034; Kates v. Generac Power Systems, Inc., et al., Case No. 23-cv-00892; and Zukas, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-00874), the Northern District of California (Moon v. Generac Power Systems, Inc., et al., Case No. 22-cv-09183; Hufton, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-02462), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203), and the Eastern District of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23-cv-00217). Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints.

- added (2023-08-08):
[0001437749-23-022513:note_history:5]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings before the Honorable Lynn S. Adelman in the Eastern District of Wisconsin. On  July 19, 2023, Judge Adelman issued an order giving plaintiffs in these actions 45 days to file a consolidated master complaint and Generac Power and the Company 60 days thereafter to respond to the consolidated master complaint. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- changed (2023-08-08):
[0001437749-23-022513:note_history:6]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.
  (was, 2023-05-09, similarity 0.7941):
[0001437749-23-013331:note_history:6]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. Motions to consolidate the putative class actions and to appoint a lead plaintiff have been filed and are pending with the court. The Company disputes the allegations and intends to vigorously defend against the claims in the consolidated class action.

- changed (2023-08-08):
[0001437749-23-022513:note_history:7]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief. On  May 2, 2023, the court consolidated the two actions. On  May 30, 2023, the court entered an order staying the consolidated action.
  (was, 2023-05-09, similarity 0.9551):
[0001437749-23-013331:note_history:7]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief.

- changed (2023-08-08):
[0001437749-23-022513:note_history:8]
Between  March 20, 2023 and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. On  June 1, 2023, the court entered an order consolidating the three actions, appointing lead plaintiffs’ counsel, and staying the consolidated actions. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.
  (was, 2023-05-09, similarity 0.7516):
[0001437749-23-013331:note_history:8]
Between  March 20, 2023 and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

- changed (2023-08-08):
[0001437749-23-022513:note_history:9]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.
  (was, 2023-05-09, similarity 0.9842):
[0001437749-23-013331:note_history:9]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resources Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

- changed (2023-08-08):
[0001437749-23-022513:note_history:10]
On  November 30, 2022, the U.S. Consumer Product Safety Commission (“CPSC”) notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act (“CPSA”), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to our statutory obligations under the Consumer Product Safety Act in connection with this matter. We are cooperating fully with this investigation and, at this time, we are unable to predict the eventual scope, duration or final outcome of such investigation.
  (was, 2023-05-09, similarity 0.6322):
[0001437749-23-013331:note_history:10]
On  November 30, 2022, the U.S. Consumer Product Safety Commission ("CPSC") notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act ("CPSA"), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the CPSC provisionally accepted the terms of a mutual settlement agreement between the CPSC and the Company. The parties entered into such agreement for settlement purposes only. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement, once finalized, would require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. The settlement agreement with CPSC under its current terms will not have a material adverse effect on the Company’s financial condition, results of operations or cash flows.

- added (2023-08-08):
[0001437749-23-022513:note_history:11]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. ecobee has prevailed against EcoFactor in two separate proceedings before the International Trade Commission (Certain Smart Thermostats, Smart HVAC Systems, and Components Thereof (Inv. No. 337-TA-1185) and Certain Smart Thermostat Systems, Smart HVAC Systems, Smart HVAC Control Systems, and Components Thereof (Inv. No. 337-TA-1258) where EcoFactor accused ecobee of infringing its intellectual property.  In addition to the proceedings before the ITC, EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump sum payment of $5.4 million for past and future damages. EcoFactor has filed a motion seeking entry of a judgment based on the verdict plus pre-judgment interest, and ecobee filed its opposition to the motion. There are presently two remaining trials involving EcoFactor.  EcoFactor claims ecobee infringes two patents in Case No. 22-cv-000330-ADA, which is scheduled for a jury trial in the Western District of Texas on  October 30, 2023, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023 in the District of Delaware.  ecobee denies infringement and intends to vigorously defend each of the lawsuits.

- added (2023-08-08):
[0001437749-23-022513:note_history:12]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG).  Ollnova currently claims that ecobee infringes on four of its patents.  ecobee denies that its products infringe on any of the asserted patents and intends to vigorously defend the case, which is currently scheduled for jury trial on  September 11, 2023.

- added (2023-08-08):
[0001437749-23-022513:note_history:13]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)).  Spartronics made similar claims against Generac Power in a third-party complaint in a lawsuit Spartronics is defending brought by one of its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.)).  Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.

- removed (2023-08-08):
[0001437749-23-013331:note_history:14]
Five additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  March 21, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative class allegedly incurred. The cases are pending in the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386-NJ and Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034-NJ), the Northern District of California (Moon v. Generac Power Systems, Inc. et al., Case No. 22-cv-09183-CRB), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203-TLN), and the County of Wake, State of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23CV006415-910. Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints. Generac Power and the Company have filed motions to dismiss in the Haak, Basler, and Moon cases.

- removed (2023-08-08):
[0001437749-23-013331:note_history:15]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and others seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. Subsequently, the parties to each of the federal court actions filed motions to stay those actions until the Judicial Panel on Multidistrict Litigation (“JPML”) determines whether to grant the MDL Motion. Those motions to stay were granted by the respective courts. On  March 28, 2023, Generac Power and the plaintiffs in the other putative federal class actions each filed responses to the MDL Motion in which all agreed that the pending cases should be transferred to the proposed Multidistrict Litigation. A hearing on the MDL Motion is scheduled for  May 25, 2023.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-08):
[0001437749-23-022513:note_history:16]
The condensed consolidated balance sheet as of  June 30, 2023, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2023-05-09, similarity 0.9119):
[0001437749-23-013331:note_history:16]
The condensed consolidated balance sheet as of  March 31, 2023, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2023 and 2022, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-08):
[0001437749-23-022513:note_history:17]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2023 and  December 31, 2022 consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $77,889 and $48,990, respectively.
  (was, 2023-05-09, similarity 0.9802):
[0001437749-23-013331:note_history:17]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $64,093 and $48,990, respectively.

- changed (2023-08-08):
[0001437749-23-022513:note_history:18]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,647 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,770 |  |  |  | 27,420 |  |
| Other |  |  | 256 |  |  |  | 966 |  |
| Total |  |  | 1,545,379 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 18,767 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,302 |  |  |  | 2,650 |  |
| Total |  | $ | 1,523,310 |  |  | $ | 1,369,085 |  |
  (was, 2023-05-09, similarity 0.9786):
[0001437749-23-013331:note_history:18]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,614 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,765 |  |  |  | 27,420 |  |
| Other |  |  | 1,233 |  |  |  | 966 |  |
| Total |  |  | 1,545,384 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 15,050 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 2,979 |  |  |  | 2,650 |  |
| Total |  | $ | 1,527,355 |  |  | $ | 1,369,085 |  |

- changed (2023-08-08):
[0001437749-23-022513:note_history:19]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  June 30, 2023 are as follows:
  (was, 2023-05-09, similarity 0.9701):
[0001437749-23-013331:note_history:19]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  March 31, 2023 are as follows:

- added (2023-08-08):
[0001437749-23-022513:note_history:20]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

- changed (2023-08-08):
[0001437749-23-022513:note_history:21]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2023, was 7.01%.
  (was, 2023-05-09, similarity 0.9941):
[0001437749-23-013331:note_history:21]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2023, was 6.52%.

- added (2023-08-08):
[0001437749-23-022513:note_history:22]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2023, the Company’s net secured leverage ratio was 2.52 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2023-08-08):
[0001437749-23-022513:note_history:23]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2023-05-09, similarity 0.994):
[0001437749-23-013331:note_history:23]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2023-08-08):
[0001437749-23-022513:note_history:24]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  June 30, 2023 was 6.49%.
  (was, 2023-05-09, similarity 0.9876):
[0001437749-23-013331:note_history:24]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  March 31, 2023, was 6.27%.

- changed (2023-08-08):
[0001437749-23-022513:note_history:25]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2023, the Company’s total leverage ratio was2.66 to 1.00 times, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2023.
  (was, 2023-05-09, similarity 0.9694):
[0001437749-23-013331:note_history:25]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2023, the Company’s total leverage ratio was 2.22 to 1.00 times, and the Company's interest coverage ratio was 30.99 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2023.

- changed (2023-08-08):
[0001437749-23-022513:note_history:26]
As of  June 30, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $999,945 of availability, net of outstanding letters of credit.
  (was, 2023-05-09, similarity 0.9668):
[0001437749-23-013331:note_history:26]
As of  March 31, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $998,580 of availability, net of outstanding letters of credit.

- removed (2023-08-08):
[0001437749-23-013331:note_history:27]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

- removed (2023-08-08):
[0001437749-23-013331:note_history:28]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2023, the Company’s net secured leverage ratio was 2.13 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-08):
[0001437749-23-022513:note_history:29]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,647 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,770 |  |  |  | 27,420 |  |
| Other |  |  | 256 |  |  |  | 966 |  |
| Total |  |  | 1,545,379 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 18,767 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,302 |  |  |  | 2,650 |  |
| Total |  | $ | 1,523,310 |  |  | $ | 1,369,085 |  |
  (was, 2023-05-09, similarity 0.9786):
[0001437749-23-013331:note_history:29]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (15,614 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,765 |  |  |  | 27,420 |  |
| Other |  |  | 1,233 |  |  |  | 966 |  |
| Total |  |  | 1,545,384 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 15,050 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 2,979 |  |  |  | 2,650 |  |
| Total |  | $ | 1,527,355 |  |  | $ | 1,369,085 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-08):
[0001437749-23-022513:note_history:30]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

- removed (2023-08-08):
[0001437749-23-013331:note_history:31]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-08-08):
[0001437749-23-022513:note_history:32]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

- added (2023-08-08):
[0001437749-23-022513:note_history:33]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

- added (2023-08-08):
[0001437749-23-022513:note_history:34]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |

- added (2023-08-08):
[0001437749-23-022513:note_history:35]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |

- removed (2023-08-08):
[0001437749-23-013331:note_history:36]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |

- removed (2023-08-08):
[0001437749-23-013331:note_history:37]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 750,327 |  |  | $ | 26,617 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 145,737 |  |  |  | 132,991 |  |  |  | 278,728 |  |
| Other |  |  | 68,610 |  |  |  | 11,574 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | 1,135,856 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-08):
[0001437749-23-022513:note_history:38]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $24,096 and $33,551 on  June 30, 2023 and  December 31, 2022, respectively. During the six months ended  June 30, 2023, the Company recognized revenue of $15,529 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2023-05-09, similarity 0.9623):
[0001437749-23-013331:note_history:38]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $25,326 and $33,551 on  March 31, 2023 and  December 31, 2022, respectively. During the three months ended  March 31, 2023, the Company recognized revenue of $11,290 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
