# GNRC MD&A — 0001437749-23-022513


## mdna

[0001437749-23-022513:mdna:1]
[same as prior period, unchanged from 0001437749-23-013331:mdna:1]

[0001437749-23-022513:mdna:2]
[same as prior period, unchanged from 0001437749-23-013331:mdna:2]

[0001437749-23-022513:mdna:3]
[same as prior period, unchanged from 0001437749-23-013331:mdna:3]

[0001437749-23-022513:mdna:4]
[same as prior period, unchanged from 0001437749-23-013331:mdna:4]

[0001437749-23-022513:mdna:5]
[same as prior period, unchanged from 0001437749-23-013331:mdna:5]

[0001437749-23-022513:mdna:6]
[same as prior period, unchanged from 0001437749-23-013331:mdna:6]

[0001437749-23-022513:mdna:7]
[same as prior period, unchanged from 0001437749-23-013331:mdna:7]

[0001437749-23-022513:mdna:8]
[same as prior period, unchanged from 0001437749-23-013331:mdna:8]

[0001437749-23-022513:mdna:9]
[same as prior period, unchanged from 0001437749-23-013331:mdna:9]

[0001437749-23-022513:mdna:10]
[same as prior period, unchanged from 0001437749-23-013331:mdna:10]

[0001437749-23-022513:mdna:11]
[same as prior period, unchanged from 0001437749-23-013331:mdna:11]

[0001437749-23-022513:mdna:12]
[same as prior period, unchanged from 0001437749-23-013331:mdna:12]

[0001437749-23-022513:mdna:13]
[same as prior period, unchanged from 0001437749-23-013331:mdna:13]

[0001437749-23-022513:mdna:14]
[same as prior period, unchanged from 0001437749-23-013331:mdna:14]

[0001437749-23-022513:mdna:15]
[same as prior period, unchanged from 0001437749-23-013331:mdna:15]

[0001437749-23-022513:mdna:16]
[same as prior period, unchanged from 0001437749-23-013331:mdna:16]

[0001437749-23-022513:mdna:17]
[same as prior period, unchanged from 0001437749-23-013331:mdna:17]

[0001437749-23-022513:mdna:18]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations; and |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-022513:mdna:19]
[same as prior period, unchanged from 0001437749-23-013331:mdna:19]

[0001437749-23-022513:mdna:20]
[same as prior period, unchanged from 0001437749-23-013331:mdna:20]

[0001437749-23-022513:mdna:21]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial and industrial (C&I) applications, solar and battery storage solutions, energy management devices and energy services, advanced power grid software platforms, and engine and battery-powered tools and equipment. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-23-022513:mdna:22]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial and industrial standby generators; as well as portable and mobile generators used in a variety of applications. In recent years, the Company has been evolving its business model to focus on building out an ecosystem of energy technology products, solutions, and services for home and business purposes. As part of this evolution, we have made significant investments into rapidly growing markets such as residential clean energy storage, solar module-level power electronics (MLPE), and energy monitoring and management devices, all of which are distributed energy resources (DERs) that can be aggregated into virtual power plants (VPPs) within grid services programs. In addition, we have been leveraging our leading position in the growing market for natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I customers. We believe natural gas represents a cleaner transition fuel to more renewable and energy storage sources compared to diesel.

[0001437749-23-022513:mdna:23]
We have also made investments in next-generation platforms and controls for both residential and C&I applications that facilitate the connection of our products to the grid. Expanding these capabilities will enable the increasing utilization of our equipment as DERs as the nascent market for grid services expands over the next several years. Our growing presence in grid services programs will enhance the value of our power generation and storage products that might otherwise sit idle, as they are now able to be dispatched and orchestrated as part of a distributed energy solution, thereby generating additional return-on-investment for the home or business owner while also delivering value to utilities and grid operators by helping to balance, support and enhance the reliability of the electrical grid. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will develop, and Generac’s energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid referred to as “Grid 2.0”.

[0001437749-23-022513:mdna:24]
[same as prior period, unchanged from 0001437749-23-013331:mdna:24]

[0001437749-23-022513:mdna:25]
[same as prior period, unchanged from 0001437749-23-013331:mdna:25]

[0001437749-23-022513:mdna:26]
[same as prior period, unchanged from 0001437749-23-013331:mdna:26]

[0001437749-23-022513:mdna:27]
[same as prior period, unchanged from 0001437749-23-013331:mdna:27]

[0001437749-23-022513:mdna:28]
[same as prior period, unchanged from 0001437749-23-013331:mdna:28]

[0001437749-23-022513:mdna:29]
[same as prior period, unchanged from 0001437749-23-013331:mdna:29]

[0001437749-23-022513:mdna:30]
[same as prior period, unchanged from 0001437749-23-013331:mdna:30]

[0001437749-23-022513:mdna:31]
[same as prior period, unchanged from 0001437749-23-013331:mdna:31]

[0001437749-23-022513:mdna:32]
[same as prior period, unchanged from 0001437749-23-013331:mdna:32]

[0001437749-23-022513:mdna:33]
[same as prior period, unchanged from 0001437749-23-013331:mdna:33]

[0001437749-23-022513:mdna:34]
[same as prior period, unchanged from 0001437749-23-013331:mdna:34]

[0001437749-23-022513:mdna:35]
[same as prior period, unchanged from 0001437749-23-013331:mdna:35]

[0001437749-23-022513:mdna:36]
[same as prior period, unchanged from 0001437749-23-013331:mdna:36]

[0001437749-23-022513:mdna:37]
[same as prior period, unchanged from 0001437749-23-013331:mdna:37]

[0001437749-23-022513:mdna:38]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. We are experiencing softer than expected consumer spending for home improvement, and expect this softness to continue for the remainder of 2023, negatively impacting our outlook for residential products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. Finally, the existence of renewable energy mandates, investment tax credits and other subsidies, which have become even more prevalent with the recent passing of the Inflation Reduction Act, can also have an impact on the demand for solar and energy storage systems.

[0001437749-23-022513:mdna:39]
[same as prior period, unchanged from 0001437749-23-013331:mdna:39]

[0001437749-23-022513:mdna:40]
[same as prior period, unchanged from 0001437749-23-013331:mdna:40]

[0001437749-23-022513:mdna:41]
[same as prior period, unchanged from 0001437749-23-013331:mdna:41]

[0001437749-23-022513:mdna:42]
[same as prior period, unchanged from 0001437749-23-013331:mdna:42]

[0001437749-23-022513:mdna:43]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in the first half of 2023. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-23-022513:mdna:44]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. For Residential products, we are currently experiencing higher field inventories for home standby generators that resulted in lower orders from our channel partners in the first half of 2023 and this headwind is expected to impact the second half of 2023 as well.

[0001437749-23-022513:mdna:45]
[same as prior period, unchanged from 0001437749-23-013331:mdna:45]

[0001437749-23-022513:mdna:46]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. During the six months ended June 30, 2023, interest expense increased compared to the six months ended June 30, 2022, primarily due to increased borrowings and higher interest rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-23-022513:mdna:47]
Factors influencing provision for income taxes and cash income taxes paid.   The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation coupled with lower year-over-year pre-tax book income in the current year. On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not impact the current quarter results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-23-022513:mdna:48]
[same as prior period, unchanged from 0001437749-23-013331:mdna:48]

[0001437749-23-022513:mdna:49]
[same as prior period, unchanged from 0001437749-23-013331:mdna:49]

[0001437749-23-022513:mdna:50]
Three months ended June 30, 2023 compared to the three months ended June 30, 2022

[0001437749-23-022513:mdna:51]
[same as prior period, unchanged from 0001437749-23-013331:mdna:51]

[0001437749-23-022513:mdna:52]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | (290,971 | ) |  |  | -22.5 | % |
| Costs of goods sold |  |  | 671,999 |  |  |  | 834,406 |  |  |  | (162,407 | ) |  |  | -19.5 | % |
| Gross profit |  |  | 328,421 |  |  |  | 456,985 |  |  |  | (128,564 | ) |  |  | -28.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 115,743 |  |  |  | 120,066 |  |  |  | (4,323 | ) |  |  | -3.6 | % |
| Research and development |  |  | 43,942 |  |  |  | 41,599 |  |  |  | 2,343 |  |  |  | 5.6 | % |
| General and administrative |  |  | 56,371 |  |  |  | 52,600 |  |  |  | 3,771 |  |  |  | 7.2 | % |
| Amortization of intangible assets |  |  | 26,393 |  |  |  | 25,876 |  |  |  | 517 |  |  |  | 2.0 | % |
| Total operating expenses |  |  | 242,449 |  |  |  | 240,141 |  |  |  | 2,308 |  |  |  | 1.0 | % |
| Income from operations |  |  | 85,972 |  |  |  | 216,844 |  |  |  | (130,872 | ) |  |  | -60.4 | % |
| Total other expense, net |  |  | (24,550 | ) |  |  | (13,381 | ) |  |  | (11,169 | ) |  |  | 83.5 | % |
| Income before provision for income taxes |  |  | 61,422 |  |  |  | 203,463 |  |  |  | (142,041 | ) |  |  | -69.8 | % |
| Provision for income taxes |  |  | 15,907 |  |  |  | 45,826 |  |  |  | (29,919 | ) |  |  | -65.3 | % |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | (112,122 | ) |  |  | -71.1 | % |
| Net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | (961 | ) |  |  | -75.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | (111,161 | ) |  |  | -71.1 | % |

[0001437749-23-022513:mdna:53]
[same as prior period, unchanged from 0001437749-23-013331:mdna:53]

[0001437749-23-022513:mdna:54]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 804,539 |  |  | $ | 1,107,431 |  |  | $ | (302,892 | ) |  |  | -27.4 | % |
| International |  |  | 195,881 |  |  |  | 183,960 |  |  |  | 11,921 |  |  |  | 6.5 | % |
| Total net sales |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | (290,971 | ) |  |  | -22.5 | % |

[0001437749-23-022513:mdna:55]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |  | Three Months Ended June 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 804,539 |  |  | $ | 10,713 |  |  | $ | 815,252 |  |  | $ | 1,107,431 |  |  | $ | 18,987 |  |  | $ | 1,126,418 |  |
| International |  |  | 195,881 |  |  |  | 27,842 |  |  |  | 223,723 |  |  |  | 183,960 |  |  |  | 19,334 |  |  |  | 203,294 |  |
| Intercompany elimination |  |  | - |  |  |  | (38,555 | ) |  |  | (38,555 | ) |  |  | - |  |  |  | (38,321 | ) |  |  | (38,321 | ) |
| Total net sales |  | $ | 1,000,420 |  |  | $ | - |  |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | - |  |  | $ | 1,291,391 |  |

[0001437749-23-022513:mdna:56]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 103,202 |  |  | $ | 241,928 |  |  | $ | (138,726 | ) |  |  | -57.3 | % |
| International |  |  | 33,343 |  |  |  | 29,534 |  |  |  | 3,809 |  |  |  | 12.9 | % |
| Total Adjusted EBITDA |  | $ | 136,545 |  |  | $ | 271,462 |  |  | $ | (134,917 | ) |  |  | -49.7 | % |

[0001437749-23-022513:mdna:57]
[same as prior period, unchanged from 0001437749-23-013331:mdna:57]

[0001437749-23-022513:mdna:58]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 498,587 |  |  | $ | 896,013 |  |  | $ | (397,426 | ) |  |  | -44.4 | % |
| Commercial & industrial products |  |  | 384,353 |  |  |  | 309,348 |  |  |  | 75,005 |  |  |  | 24.2 | % |
| Other |  |  | 117,480 |  |  |  | 86,030 |  |  |  | 31,450 |  |  |  | 36.6 | % |
| Total net sales |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | (290,971 | ) |  |  | -22.5 | % |

[0001437749-23-022513:mdna:59]
Net sales.   Domestic segment total sales (including inter-segment sales) declined $311.2 million or 27.6% to $815.3 million in the second quarter of 2023, with the impact of acquisitions contributing approximately 3% revenue growth for the quarter. The decline in sales was driven by lower residential product shipments, primarily due to a decline in home standby and clean energy shipments, partially offset by growth in smart thermostat sales. The overall weakness in residential products was partially offset by continued strength in C&I products, highlighted by an increase in shipments to direct customers for “beyond standby” applications, industrial distributors, and the national rental equipment channel.

[0001437749-23-022513:mdna:60]
International segment total sales (including inter-segment sales) increased $20.4 million or 10.1% to $223.7 million, with the net impact of acquisitions and foreign currency contributing approximately 4% revenue growth for the quarter. The sales growth for the segment was primarily driven by strength in nearly all regions around the world.

[0001437749-23-022513:mdna:61]
In addition, total contribution from non-annualized acquisitions for second quarter of 2023 was $32.2 million, including $30.5 million for the domestic segment and $1.7 million for the international segment.

[0001437749-23-022513:mdna:62]
Gross profit.  Gross profit margin for the second quarter of 2023 was 32.8% compared to 35.4% in the prior year second quarter. This decline in margin was primarily due to the significant impact of unfavorable sales mix, partially offset by higher pricing and lower input costs.

[0001437749-23-022513:mdna:63]
Operating Expenses.  Operating expenses increased $2.3 million or 1.0%, as compared to the prior year second quarter. The increase was primarily driven by increased employee, marketing and promotion costs and the impact of recurring operating expenses from recent acquisitions, mostly offset by lower variable operating expenses.

[0001437749-23-022513:mdna:64]
Other Expense.  The increase in other expense, net was driven primarily by higher interest expense due to higher borrowings and interest rates than the prior year quarter.  The increase was partially offset by a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to a $250 million prepayment of our Tranche B Term Loan Facility in the prior year quarter.

[0001437749-23-022513:mdna:65]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2023 and 2022 were 25.9% and 22.5%, respectively. The increase in the effective tax rate was primarily due to a lower benefit from equity compensation in the current year quarter as compared to the prior year.

[0001437749-23-022513:mdna:66]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $45.2 million compared to $156.4 million in the prior year second quarter. This decrease was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-23-022513:mdna:67]
Adjusted EBITDA.    Adjusted EBITDA for the Domestic segment in the second quarter of 2023 was $103.2 million, or 12.7% of total domestic segment sales, as compared to $241.9 million, or 21.5%, in the prior year quarter. This margin decline was primarily driven by the significant impact of unfavorable sales mix and reduced operating leverage on lower shipments. The impact of acquisitions and continued investments for future growth also negatively affected margins during the quarter. These headwinds were partially offset by favorable price and cost benefits.

[0001437749-23-022513:mdna:68]
Adjusted EBITDA for the international segment in the second quarter of 2023, before deducting for non-controlling interests, was $33.3 million, or 14.9% of international total sales, as compared to $29.5 million, or 14.5% of total sales, in the prior year quarter. This stronger margin performance was primarily driven by favorable price and cost benefits.

[0001437749-23-022513:mdna:69]
Adjusted Net Income.    Adjusted Net Income of $67.5 million for the three months ended June 30, 2023 decreased 63.5% from $185.1 million for the three months ended June 30, 2022. This decrease was primarily driven by lower net income due to the factors outlined above, together with the impact of various add-backs in the current and prior year quarters.

[0001437749-23-022513:mdna:70]
[same as prior period, unchanged from 0001437749-23-013331:mdna:70]

[0001437749-23-022513:mdna:71]
Results of Operations

[0001437749-23-022513:mdna:72]
Six months ended June 30, 2023 compared to the six months ended June 30, 2022

[0001437749-23-022513:mdna:73]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-23-022513:mdna:74]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  | $ | (538,917 | ) |  |  | -22.2 | % |
| Costs of goods sold |  |  | 1,287,410 |  |  |  | 1,609,514 |  |  |  | (322,104 | ) |  |  | -20.0 | % |
| Gross profit |  |  | 600,920 |  |  |  | 817,733 |  |  |  | (216,813 | ) |  |  | -26.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 216,431 |  |  |  | 218,309 |  |  |  | (1,878 | ) |  |  | -0.9 | % |
| Research and development |  |  | 85,762 |  |  |  | 81,343 |  |  |  | 4,419 |  |  |  | 5.4 | % |
| General and administrative |  |  | 116,056 |  |  |  | 94,572 |  |  |  | 21,484 |  |  |  | 22.7 | % |
| Amortization of intangible assets |  |  | 52,216 |  |  |  | 51,930 |  |  |  | 286 |  |  |  | 0.6 | % |
| Total operating expenses |  |  | 470,465 |  |  |  | 446,154 |  |  |  | 24,311 |  |  |  | 5.4 | % |
| Income from operations |  |  | 130,455 |  |  |  | 371,579 |  |  |  | (241,124 | ) |  |  | -64.9 | % |
| Total other expense, net |  |  | (47,023 | ) |  |  | (22,612 | ) |  |  | (24,411 | ) |  |  | 108.0 | % |
| Income before provision for income taxes |  |  | 83,432 |  |  |  | 348,967 |  |  |  | (265,535 | ) |  |  | -76.1 | % |
| Provision for income taxes |  |  | 23,756 |  |  |  | 74,434 |  |  |  | (50,678 | ) |  |  | -68.1 | % |
| Net income |  |  | 59,676 |  |  |  | 274,533 |  |  |  | (214,857 | ) |  |  | -78.3 | % |
| Net income attributable to noncontrolling interests |  |  | 2,048 |  |  |  | 4,316 |  |  |  | (2,268 | ) |  |  | -52.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 57,628 |  |  | $ | 270,217 |  |  | $ | (212,589 | ) |  |  | -78.7 | % |

[0001437749-23-022513:mdna:75]
The following tables set forth our reportable segment information for the periods indicated:

[0001437749-23-022513:mdna:76]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,508,927 |  |  | $ | 2,072,105 |  |  | $ | (563,178 | ) |  |  | -27.2 | % |
| International |  |  | 379,403 |  |  |  | 355,142 |  |  |  | 24,261 |  |  |  | 6.8 | % |
| Total net sales |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  | $ | (538,917 | ) |  |  | -22.2 | % |

[0001437749-23-022513:mdna:77]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |  | Six Months Ended June 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,508,927 |  |  | $ | 26,320 |  |  | $ | 1,535,247 |  |  | $ | 2,072,105 |  |  | $ | 29,257 |  |  | $ | 2,101,362 |  |
| International |  |  | 379,403 |  |  |  | 60,784 |  |  |  | 440,187 |  |  |  | 355,142 |  |  |  | 33,659 |  |  |  | 388,801 |  |
| Intercompany elimination |  |  | - |  |  |  | (87,104 | ) |  |  | (87,104 | ) |  |  | - |  |  |  | (62,916 | ) |  |  | (62,916 | ) |
| Total net sales |  | $ | 1,888,330 |  |  | $ | - |  |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  | $ | - |  |  | $ | 2,427,247 |  |

[0001437749-23-022513:mdna:78]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 170,863 |  |  | $ | 412,349 |  |  | $ | (241,486 | ) |  |  | -58.6 | % |
| International |  |  | 65,757 |  |  |  | 55,526 |  |  |  | 10,231 |  |  |  | 18.4 | % |
| Total Adjusted EBITDA |  | $ | 236,620 |  |  | $ | 467,875 |  |  | $ | (231,255 | ) |  |  | -49.4 | % |

[0001437749-23-022513:mdna:79]
The following table sets forth our product class information for the periods indicated:

[0001437749-23-022513:mdna:80]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 917,450 |  |  | $ | 1,672,957 |  |  | $ | (755,507 | ) |  |  | -45.2 | % |
| Commercial & industrial products |  |  | 747,343 |  |  |  | 588,077 |  |  |  | 159,266 |  |  |  | 27.1 | % |
| Other |  |  | 223,537 |  |  |  | 166,213 |  |  |  | 57,324 |  |  |  | 34.5 | % |
| Total net sales |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  | $ | (538,917 | ) |  |  | -22.2 | % |

[0001437749-23-022513:mdna:81]
Net sales.   Domestic segment total sales (including inter-segment sales) declined $566.1 million or 26.9% to $1,535.2 million in the six months ended June 30, 2023, with the impact of acquisitions contributing approximately 3% revenue growth for the six month period. The decline in sales was driven primarily by lower home standby and clean energy product shipments. This decline was partially offset by strong C&I product sales growth across all channels, highlighted by national rental equipment, industrial distributors, telecom and other direct customers for "beyond standby" applications.

[0001437749-23-022513:mdna:82]
International segment total sales (including inter-segment sales) increased $51.4 million or 13.2% to $440.2 million, with the net impact of acquisitions and foreign currency contributing approximately 2% revenue growth for the six month period. The sales growth for the segment was primarily driven by strength in nearly all regions around the world.

[0001437749-23-022513:mdna:83]
In addition, total contribution from non-annualized acquisitions for the six months ended June 30, 2023 was $59.5 million, including $56.3 million for the domestic segment and $3.2 million for the international segment.

[0001437749-23-022513:mdna:84]
Gross profit.  Gross profit margin for the six months ended June 30, 2023 was 31.8% compared to 33.7% in the prior year comparable period. This decline in margin was primarily due to the significant impact of unfavorable sales mix, partially offset by higher pricing and lower input costs.

[0001437749-23-022513:mdna:85]
Operating Expenses.  Operating expenses for the six months ended June 30, 2023 increased $24.3 million or 5.4%, as compared to the prior year comparable period, including a $5.8 million provision for a regulatory matter with the CPSC (see Note 15, “Commitments and Contingencies” for additional information). The remaining increase was primarily driven by increased marketing, promotion and employee costs as well as recurring operating expenses from recent acquisitions, offset by lower variable operating expenses.

[0001437749-23-022513:mdna:86]
Other Expense.  The increase in other expense, net was driven primarily by higher interest expense due to higher borrowings and interest rates compared to the prior year comparable period. The increase was partially offset by a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to a $250 million prepayment of our Tranche B Term Loan Facility in the prior year period.

[0001437749-23-022513:mdna:87]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2023 and 2022 were 28.5% and 21.3%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation on a lower pre-tax earnings base in the current period compared to the prior year comparable period.

[0001437749-23-022513:mdna:88]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the six months ended June 30, 2023 was $57.6 million as compared to $270.2 million in the prior year comparable period. This decrease was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-23-022513:mdna:89]
Adjusted EBITDA.    Adjusted EBITDA for the Domestic segment in the six months ended June 30, 2023 was $170.9 million or 11.1% of total domestic segment sales as compared to $412.3 million or 19.6% in the prior year comparable period. This lower margin performance was primarily driven by the significant impact of unfavorable sales mix and reduced operating leverage on lower shipments. The impact of acquisitions and investments for future growth also negatively affected margins during the period. These headwinds were partially offset by favorable price and cost benefits.

[0001437749-23-022513:mdna:90]
Adjusted EBITDA for the international segment in the six months ended June 30, 2023, before deducting for non-controlling interests, was $65.8 million, or 14.9% of international segment total sales, as compared to $55.5 million or 14.3% of total sales, in the prior year comparable period.  This stronger margin performance was primarily driven by favorable price and cost benefits and improved operating leverage on higher sales volume.

[0001437749-23-022513:mdna:91]
Adjusted Net Income.    Adjusted Net Income of $107.1 million for the six months ended June 30, 2023 decreased 65.8% from $313.0 million for the six months ended June 30, 2022. This decrease was primarily driven by lower net income due to the factors outlined above, together with the impact of various add-backs in the first six months of the current and prior years.

[0001437749-23-022513:mdna:92]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-23-022513:mdna:93]
[same as prior period, unchanged from 0001437749-23-013331:mdna:71]

[0001437749-23-022513:mdna:94]
Our primary cash requirements include payment for our raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-23-022513:mdna:95]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements provided for a $500.0 million ABL facility (ABL Facility) that was paid off and terminated in June 2022.

[0001437749-23-022513:mdna:96]
In June 2022, we amended and restated our existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1.25 billion (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and make a $250 million voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-23-022513:mdna:97]
As of June 30, 2023, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and $250 million of borrowings on our Revolving Facility, leaving $999.9 million of availability, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. At June 30, 2023, the interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 6.49%, 6.49%, and 7.01%, respectively. See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense.

[0001437749-23-022513:mdna:98]
[same as prior period, unchanged from 0001437749-23-013331:mdna:76]

[0001437749-23-022513:mdna:99]
| 2023 | $ | 9,375 |
| 2024 |  | 28,125 |
| 2025 |  | 46,875 |
| 2026 |  | 595,625 |
| 2027 |  | 850,000 |
| Total | $ | 1,530,000 |

[0001437749-23-022513:mdna:100]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2023, our net secured leverage ratio was 2.52 to 1.00 times. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of June 30, 2023, the Company’s total leverage ratio was2.66 to 1.00 times, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of June 30, 2023.

[0001437749-23-022513:mdna:101]
As of June 30, 2023, we had $1,192.7 million of available liquidity, comprised of $192.8 million of cash and cash equivalents and $999.9 million available under our Revolving Facility, net of outstanding letters of credit. As of June 30, 2023, total liquidity is reduced to $798.3 million under the Company's most restrictive debt covenants, and consists of $192.8 million of cash and cash equivalents and $605.5 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-23-022513:mdna:102]
In September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allowed for the repurchase of up to $250 million of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three months and six months ended June 30, 2023 and 2022. Since the inception of all stock repurchase programs (starting in August 2015), the Company has repurchased 11,748,713 shares of common stock for $777,379 (at an average cost per share of $66.17).

[0001437749-23-022513:mdna:103]
[same as prior period, unchanged from 0001437749-23-013331:mdna:81]

[0001437749-23-022513:mdna:104]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 11% and 16% of net sales for the six months ended June 30, 2023 and 2022, respectively. The amount financed by dealers which remained outstanding was$166.9 million and $212.2 million as of June 30, 2023 and December 31, 2022, respectively.

[0001437749-23-022513:mdna:105]
[same as prior period, unchanged from 0001437749-23-013331:mdna:83]

[0001437749-23-022513:mdna:106]
[same as prior period, unchanged from 0001437749-23-013331:mdna:84]

[0001437749-23-022513:mdna:107]
[same as prior period, unchanged from 0001437749-23-013331:mdna:85]

[0001437749-23-022513:mdna:108]
Six months ended June 30, 2023 compared to the six months ended June 30, 2022

[0001437749-23-022513:mdna:109]
[same as prior period, unchanged from 0001437749-23-013331:mdna:87]

[0001437749-23-022513:mdna:110]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 64,588 |  |  | $ | 13,693 |  |  | $ | 50,895 |  |  |  | 371.7 | % |
| Net cash used in investing activities |  |  | (75,442 | ) |  |  | (63,119 | ) |  |  | (12,323 | ) |  |  | -19.5 | % |
| Net cash provided by financing activities |  |  | 69,496 |  |  |  | 366,367 |  |  |  | (296,871 | ) |  |  | 81.0 | % |

[0001437749-23-022513:mdna:111]
The increase in operating cash flows for the six months ended June 30, 2023 primarily represents a significantly lower investment in working capital as compared to the prior year, partially offset by lower operating earnings.

[0001437749-23-022513:mdna:112]
Net cash used in investing activities for the six months ended June 30, 2023 primarily represents cash payments of $53.9 million related to the purchase of property and equipment, $16.2 million for the acquisition of REFUstor, $6.6 million for a tax equity investment, and a $2.0 million minority investment in Rolling Energy Resources, an electric vehicle load management platform.

[0001437749-23-022513:mdna:113]
Net cash used in investing activities for the six months ended June 30, 2022 primarily represents cash payments of $46.5 million related to the purchase of property and equipment, $11.4 million related to the acquisition of businesses, and $10.2 million for a tax equity investment, which were partially offset by cash proceeds from the sale of property and equipment of $1.9 million, cash proceeds from beneficial interests in securitization transactions of $1.8 million, and cash proceeds from the sale of an investment of $1.3 million.

[0001437749-23-022513:mdna:114]
Net cash provided by financing activities for the six months ended June 30, 2023 primarily represents proceeds of $318.0 million from long-term borrowings, $46.0 million from short-term borrowings, and $6.2 million from the exercise of stock options. These cash proceeds were partially offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $181.7 million of debt repayments ($21.1 million of short-term borrowings and $160.6 million of long-term borrowings and finance lease obligations), and $9.2 million of taxes paid related to equity awards.

[0001437749-23-022513:mdna:115]
Net cash provided by financing activities for the six months ended June 30, 2022 primarily represents proceeds of $935.0 million from long-term borrowings, $216.7 million from short-term borrowings, and $10.4 million from the exercise of stock options. These cash proceeds were partially offset by $746.6 million of debt repayments ($208.2 million of short-term borrowings and $538.4 million of long-term borrowings and finance lease obligations), $38.3 million of taxes paid related to equity awards, and $10.3 million for payment of debt issuance costs.

[0001437749-23-022513:mdna:116]
[same as prior period, unchanged from 0001437749-23-013331:mdna:94]

[0001437749-23-022513:mdna:117]
[same as prior period, unchanged from 0001437749-23-013331:mdna:95]

[0001437749-23-022513:mdna:118]
Critical Accounting Policies and Estimates

[0001437749-23-022513:mdna:119]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2022, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-23-022513:mdna:120]
[same as prior period, unchanged from 0001437749-23-013331:mdna:98]

[0001437749-23-022513:mdna:121]
[same as prior period, unchanged from 0001437749-23-013331:mdna:99]

[0001437749-23-022513:mdna:122]
[same as prior period, unchanged from 0001437749-23-013331:mdna:100]

[0001437749-23-022513:mdna:123]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-022513:mdna:124]
[same as prior period, unchanged from 0001437749-23-013331:mdna:102]

[0001437749-23-022513:mdna:125]
[same as prior period, unchanged from 0001437749-23-013331:mdna:103]

[0001437749-23-022513:mdna:126]
[same as prior period, unchanged from 0001437749-23-013331:mdna:104]

[0001437749-23-022513:mdna:127]
[same as prior period, unchanged from 0001437749-23-013331:mdna:105]

[0001437749-23-022513:mdna:128]
[same as prior period, unchanged from 0001437749-23-013331:mdna:106]

[0001437749-23-022513:mdna:129]
[same as prior period, unchanged from 0001437749-23-013331:mdna:107]

[0001437749-23-022513:mdna:130]
[same as prior period, unchanged from 0001437749-23-013331:mdna:108]

[0001437749-23-022513:mdna:131]
[same as prior period, unchanged from 0001437749-23-013331:mdna:109]

[0001437749-23-022513:mdna:132]
|  | • | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of the Company, including our ability to service our debt and other cash needs; and |

[0001437749-23-022513:mdna:133]
[same as prior period, unchanged from 0001437749-23-013331:mdna:111]

[0001437749-23-022513:mdna:134]
[same as prior period, unchanged from 0001437749-23-013331:mdna:112]

[0001437749-23-022513:mdna:135]
[same as prior period, unchanged from 0001437749-23-013331:mdna:113]

[0001437749-23-022513:mdna:136]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-23-022513:mdna:137]
[same as prior period, unchanged from 0001437749-23-013331:mdna:115]

[0001437749-23-022513:mdna:138]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-23-022513:mdna:139]
[same as prior period, unchanged from 0001437749-23-013331:mdna:117]

[0001437749-23-022513:mdna:140]
[same as prior period, unchanged from 0001437749-23-013331:mdna:118]

[0001437749-23-022513:mdna:141]
[same as prior period, unchanged from 0001437749-23-013331:mdna:119]

[0001437749-23-022513:mdna:142]
[same as prior period, unchanged from 0001437749-23-013331:mdna:120]

[0001437749-23-022513:mdna:143]
[same as prior period, unchanged from 0001437749-23-013331:mdna:121]

[0001437749-23-022513:mdna:144]
[same as prior period, unchanged from 0001437749-23-013331:mdna:122]

[0001437749-23-022513:mdna:145]
[same as prior period, unchanged from 0001437749-23-013331:mdna:123]

[0001437749-23-022513:mdna:146]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees) involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-23-022513:mdna:147]
[same as prior period, unchanged from 0001437749-23-013331:mdna:125]

[0001437749-23-022513:mdna:148]
[same as prior period, unchanged from 0001437749-23-013331:mdna:126]

[0001437749-23-022513:mdna:149]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | 2,048 |  |  |  | 4,316 |  |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | 59,676 |  |  |  | 274,533 |  |
| Interest expense |  |  | 25,160 |  |  |  | 10,235 |  |  |  | 48,155 |  |  |  | 19,789 |  |
| Depreciation and amortization |  |  | 41,247 |  |  |  | 39,098 |  |  |  | 81,198 |  |  |  | 77,559 |  |
| Provision for income taxes |  |  | 15,907 |  |  |  | 45,826 |  |  |  | 23,756 |  |  |  | 74,434 |  |
| Non-cash write-down and other adjustments (a) |  |  | (4,152 | ) |  |  | 4,607 |  |  |  | (7,312 | ) |  |  | (3,185 | ) |
| Non-cash share-based compensation expense (b) |  |  | 10,045 |  |  |  | 7,735 |  |  |  | 20,379 |  |  |  | 16,562 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | 3,743 |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and credit facility fees (d) |  |  | 1,149 |  |  |  | 1,592 |  |  |  | 2,240 |  |  |  | 2,581 |  |
| Business optimization and other charges (e) |  |  | 1,760 |  |  |  | 1,590 |  |  |  | 2,860 |  |  |  | 2,749 |  |
| Provision for regulatory charges (f) |  |  | - |  |  |  | - |  |  |  | 5,800 |  |  |  | - |  |
| Other |  |  | (86 | ) |  |  | (601 | ) |  |  | (132 | ) |  |  | (890 | ) |
| Adjusted EBITDA |  |  | 136,545 |  |  |  | 271,462 |  |  |  | 236,620 |  |  |  | 467,875 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 520 |  |  |  | 3,742 |  |  |  | 3,653 |  |  |  | 7,167 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 136,025 |  |  | $ | 267,720 |  |  | $ | 232,967 |  |  | $ | 460,708 |  |

[0001437749-23-022513:mdna:150]
(a)  Represents gains/losses on the disposition of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these non-cash charges and gains is useful for the following reasons:

[0001437749-23-022513:mdna:151]
[same as prior period, unchanged from 0001437749-23-013331:mdna:129]

[0001437749-23-022513:mdna:152]
[same as prior period, unchanged from 0001437749-23-013331:mdna:130]

[0001437749-23-022513:mdna:153]
[same as prior period, unchanged from 0001437749-23-013331:mdna:131]

[0001437749-23-022513:mdna:154]
(c)  Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment.

[0001437749-23-022513:mdna:155]
(d)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-23-022513:mdna:156]
(e)  Represents severance and other restructuring charges.

[0001437749-23-022513:mdna:157]
(f)  The amount recorded in the first quarter of 2023 represents a provision of $5.8 million for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On May 25, 2023, the Company and the CPSC entered into a final mutual settlement agreement resolving this matter.

[0001437749-23-022513:mdna:158]
[same as prior period, unchanged from 0001437749-23-013331:mdna:135]

[0001437749-23-022513:mdna:159]
[same as prior period, unchanged from 0001437749-23-013331:mdna:136]

[0001437749-23-022513:mdna:160]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of the Company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-23-022513:mdna:161]
[same as prior period, unchanged from 0001437749-23-013331:mdna:138]

[0001437749-23-022513:mdna:162]
[same as prior period, unchanged from 0001437749-23-013331:mdna:139]

[0001437749-23-022513:mdna:163]
[same as prior period, unchanged from 0001437749-23-013331:mdna:140]

[0001437749-23-022513:mdna:164]
[same as prior period, unchanged from 0001437749-23-013331:mdna:141]

[0001437749-23-022513:mdna:165]
[same as prior period, unchanged from 0001437749-23-013331:mdna:142]

[0001437749-23-022513:mdna:166]
[same as prior period, unchanged from 0001437749-23-013331:mdna:143]

[0001437749-23-022513:mdna:167]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | 2,048 |  |  |  | 4,316 |  |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | 59,676 |  |  |  | 274,533 |  |
| Amortization of intangible assets |  |  | 26,393 |  |  |  | 25,876 |  |  |  | 52,216 |  |  |  | 51,930 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 967 |  |  |  | 650 |  |  |  | 1,921 |  |  |  | 1,287 |  |
| Loss on extinguishment of debt (a) |  |  | - |  |  |  | 3,743 |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and other purchase accounting adjustments (b) |  |  | 669 |  |  |  | 5,710 |  |  |  | 1,387 |  |  |  | (46 | ) |
| (Gain)/loss attributable to business or asset dispositions (c) |  |  | - |  |  |  | - |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (d) |  |  | 1,760 |  |  |  | 1,590 |  |  |  | 2,860 |  |  |  | 2,749 |  |
| Provision for regulatory charges (e) |  |  | - |  |  |  | - |  |  |  | 5,800 |  |  |  | - |  |
| Tax effect of add backs (f) |  |  | (7,459 | ) |  |  | (8,448 | ) |  |  | (14,590 | ) |  |  | (15,764 | ) |
| Adjusted net income |  |  | 67,844 |  |  |  | 186,758 |  |  |  | 109,151 |  |  |  | 318,203 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,678 |  |  |  | 2,048 |  |  |  | 5,168 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 67,527 |  |  | $ | 185,080 |  |  | $ | 107,103 |  |  | $ | 313,035 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.08 |  |  | $ | 2.86 |  |  | $ | 1.72 |  |  | $ | 4.83 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,348,184 |  |  |  | 64,713,748 |  |  |  | 62,429,911 |  |  |  | 64,799,002 |  |

[0001437749-23-022513:mdna:168]
(a)  Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment.

[0001437749-23-022513:mdna:169]
(b)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-23-022513:mdna:170]
(c)  Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-23-022513:mdna:171]
(d)  Represents severance and other restructuring charges.

[0001437749-23-022513:mdna:172]
(e)  Represents a provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On May 25, 2023, the Company and the CPSC entered into a final mutual settlement agreement resolving this matter.

[0001437749-23-022513:mdna:173]
(f)  In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the second quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the three months ended June 30, 2022 of $193,528 or $2.99 and six months ended June 30, 2022 of $328,799 or $5.07. Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the three months ended June 30, 2022 is $185,080 or $2.86 and six months ended June 30, 2022 is $313,035 or $4.83.

[0001437749-23-022513:mdna:174]
[same as prior period, unchanged from 0001437749-23-013331:mdna:150]

[0001437749-23-022513:mdna:175]
[same as prior period, unchanged from 0001437749-23-013331:mdna:151]
