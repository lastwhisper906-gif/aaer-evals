# GNRC notes — 0001437749-23-022513


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-23-022513:notes:1]
[same as prior period, unchanged from 0001437749-23-013331:notes:1]

[0001437749-23-022513:notes:2]
[same as prior period, unchanged from 0001437749-23-013331:notes:2]

[0001437749-23-022513:notes:3]
[same as prior period, unchanged from 0001437749-23-013331:notes:3]

[0001437749-23-022513:notes:4]
[same as prior period, unchanged from 0001437749-23-013331:notes:4]

[0001437749-23-022513:notes:5]
[same as prior period, unchanged from 0001437749-23-013331:notes:5]

[0001437749-23-022513:notes:6]
The condensed consolidated balance sheet as of  June 30, 2023, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-23-022513:notes:7]
[same as prior period, unchanged from 0001437749-23-013331:notes:7]

[0001437749-23-022513:notes:8]
[same as prior period, unchanged from 0001437749-23-013331:notes:8]

[0001437749-23-022513:notes:9]
[same as prior period, unchanged from 0001437749-23-013331:notes:9]

[0001437749-23-022513:notes:10]
[same as prior period, unchanged from 0001437749-23-013331:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-23-022513:notes:11]
[same as prior period, unchanged from 0001437749-23-013331:notes:11]

[0001437749-23-022513:notes:12]
[same as prior period, unchanged from 0001437749-23-013331:notes:12]

[0001437749-23-022513:notes:13]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market.

[0001437749-23-022513:notes:14]
The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  June 30, 2023. The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized prior to  March 31, 2024, and there have not been any material changes to the balances acquired as of  June 30, 2023. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-23-022513:notes:15]
[same as prior period, unchanged from 0001437749-23-013331:notes:15]

[0001437749-23-022513:notes:16]
[same as prior period, unchanged from 0001437749-23-013331:notes:16]

[0001437749-23-022513:notes:17]
[same as prior period, unchanged from 0001437749-23-013331:notes:17]

[0001437749-23-022513:notes:18]
The combined purchase price for these two acquisitions was $25,654, net of cash acquired. The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for EEC was finalized in the second quarter of 2023 and did not result in material adjustments to the Company's preliminary estimates. Through the second quarter of 2023, the combined purchase price for EEC and Blue Pillar has increased to $27,456 due to working capital true-ups. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  June 30, 2023. Pro forma and other financial information are not presented as the effects of the 2022 acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-23-022513:notes:19]
[same as prior period, unchanged from 0001437749-23-013331:notes:19]

[0001437749-23-022513:notes:20]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price included $105,264 of initial consideration (which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023) and $11,490 of contingent deferred consideration to be paid in up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025.

[0001437749-23-022513:notes:21]
[same as prior period, unchanged from 0001437749-23-013331:notes:21]

[0001437749-23-022513:notes:22]
[same as prior period, unchanged from 0001437749-23-013331:notes:22]

[0001437749-23-022513:notes:23]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 3,814 |  |  | $ | 71,511 |  |  | $ | 110,471 |  |  | $ | 58,050 |  |
| Net income |  |  | 222 |  |  |  | 816 |  |  |  | 1,670 |  |  |  | 3,672 |  |
| Foreign currency translation |  |  | (169 | ) |  |  | (3,228 | ) |  |  | (536 | ) |  |  | (4,109 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | 86 |  |  |  | (116,754 | ) |  |  | (375 | ) |
| Redemption value adjustment |  |  | 1,821 |  |  |  | 13,645 |  |  |  | 10,837 |  |  |  | 25,592 |  |
| Balance at end of period |  | $ | 5,688 |  |  | $ | 82,830 |  |  | $ | 5,688 |  |  | $ | 82,830 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-23-022513:notes:24]
[same as prior period, unchanged from 0001437749-23-013331:notes:24]

[0001437749-23-022513:notes:25]
[same as prior period, unchanged from 0001437749-23-013331:notes:25]

[0001437749-23-022513:notes:26]
[same as prior period, unchanged from 0001437749-23-013331:notes:26]

[0001437749-23-022513:notes:27]
[same as prior period, unchanged from 0001437749-23-013331:notes:27]

[0001437749-23-022513:notes:28]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements which were still outstanding as of  June 30, 2023.

[0001437749-23-022513:notes:29]
[same as prior period, unchanged from 0001437749-23-013331:notes:29]

[0001437749-23-022513:notes:30]
The amount of gains/(losses), net of tax recognized, for the three and six months ended  June 30, 2023, was $5,752 and $1,264, respectively. The amount of gains/(losses), net of tax, recognized for the three and six months ended  June 30, 2022, was $7,129 and $25,857, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-23-022513:notes:31]
[same as prior period, unchanged from 0001437749-23-013331:notes:31]

[0001437749-23-022513:notes:32]
[same as prior period, unchanged from 0001437749-23-013331:notes:32]

[0001437749-23-022513:notes:33]
|  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Commodity contracts |  | $ | 79 |  |  | $ | - |  |
| Foreign currency contracts |  |  | 130 |  |  |  | 94 |  |
| Interest rate swaps |  |  | 50,966 |  |  |  | 49,279 |  |

[0001437749-23-022513:notes:34]
In the condensed consolidated balance sheets, the fair value of the commodity and foreign currency contracts is included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in operating lease and other assets. Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2023 and  December 31, 2022 is an asset of $52,998 and $51,184 respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-23-022513:notes:35]
[same as prior period, unchanged from 0001437749-23-013331:notes:35]

[0001437749-23-022513:notes:36]
[same as prior period, unchanged from 0001437749-23-013331:notes:36]

[0001437749-23-022513:notes:37]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $524,114, was $528,013 (Level 2) at  June 30, 2023, as calculated based on independent valuations which contain inputs and significant value drivers that are observable. As the Term Loan A is not actively traded, the fair value of Term Loan A approximates the carrying value.

[0001437749-23-022513:notes:38]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-23-022513:notes:39]
[same as prior period, unchanged from 0001437749-23-013331:notes:39]

[0001437749-23-022513:notes:40]
[same as prior period, unchanged from 0001437749-23-013331:notes:40]

[0001437749-23-022513:notes:41]
At  June 30, 2023, the fair value of contingent consideration is $39,579 in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2022, the Company had contingent consideration of $49,500 in other accrued liabilities and $32,033 in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-23-022513:notes:42]
[same as prior period, unchanged from 0001437749-23-013331:notes:42]

[0001437749-23-022513:notes:43]
| Beginning balance, January 1, 2023 |  | $ | 81,533 |  |
| Changes in fair value |  |  | - |  |
| Additional contingent consideration (1) |  |  | 11,490 |  |
| Payment of contingent consideration (2) |  |  | (53,786 | ) |
| Present value interest accretion |  |  | 342 |  |
| Ending balance, June 30, 2023 |  | $ | 39,579 |  |

[0001437749-23-022513:notes:44]
[same as prior period, unchanged from 0001437749-23-013331:notes:44]

[0001437749-23-022513:notes:45]
(2) Includes payments of $479 in cash and $44,521 in shares for the ecobee acquisition, $4,286 in shares for the Chilicon acquisition, and $4,500 in cash for the Mean Green acquisition. The payment of common stock is accounted for as a non-cash item in the condensed consolidated statement of cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-23-022513:notes:46]
[same as prior period, unchanged from 0001437749-23-013331:notes:46]

[0001437749-23-022513:notes:47]
The following table presents a disclosure of changes in AOCL during the three and six months ended  June 30, 2023 and 2022, net of tax:

[0001437749-23-022513:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2023 |  | $ | (74,298 | ) |  |  | $ | 31,955 |  |  |  | $ | (42,343 | ) |
| Other comprehensive income (loss) |  |  | 20,375 |  | (1) |  |  | 5,752 |  | (2) |  |  | 26,127 |  |
| Ending Balance – June 30, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |

[0001437749-23-022513:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2022 |  | $ | (63,079 | ) |  |  | $ | 16,677 |  |  |  | $ | (46,402 | ) |
| Other comprehensive income (loss) |  |  | (43,566 | ) | (3) |  |  | 7,129 |  | (4) |  |  | (36,437 | ) |
| Ending Balance – June 30, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |

[0001437749-23-022513:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 47,622 |  | (1) |  |  | 1,264 |  | (5) |  |  | 48,886 |  |
| Ending Balance – June 30, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |

[0001437749-23-022513:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) |  |  | (53,941 | ) | (3) |  |  | 25,857 |  | (6) |  |  | (28,084 | ) |
| Ending Balance – June 30, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |

[0001437749-23-022513:notes:52]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized gains of $7,674 on the interest rate swaps, net of tax effect of $(1,922) for the three months ended June 30, 2023. |

[0001437749-23-022513:notes:53]
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2022, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized gains of $9,537 on the interest rate swaps, net of tax effect of $(2,408) for the three months ended June 30, 2022. |
|  | (5) | Represents unrealized gains of $1,687 on the interest rate swaps, net of tax effect of $(423) for the six months ended June 30, 2023. |
|  | (6) | Represents unrealized gains of $34,591 on the interest rate swaps, net of tax effect of $(8,734) for the six months ended June 30, 2022. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-022513:notes:54]
[same as prior period, unchanged from 0001437749-23-013331:notes:52]

[0001437749-23-022513:notes:55]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations and the Company's various international acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-23-022513:notes:56]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices and solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The breakout of net sales between residential, C&I, and other products and services by reportable segment is as follows:

[0001437749-23-022513:notes:57]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

[0001437749-23-022513:notes:58]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

[0001437749-23-022513:notes:59]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |

[0001437749-23-022513:notes:60]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |

[0001437749-23-022513:notes:61]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management devices and solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which they in turn sell or rent to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential product's revenues are transferred to the customer at a point in time.

[0001437749-23-022513:notes:62]
[same as prior period, unchanged from 0001437749-23-013331:notes:59]

[0001437749-23-022513:notes:63]
The Other product class consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-23-022513:notes:64]
The following table sets forth total sales by reportable segment and is inclusive of intersegment sales:

[0001437749-23-022513:notes:65]
|  |  | Three Months Ended June 30, 2023 |  |  | Three Months Ended June 30, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | - |  |  | $ | 1,000,420 |  |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | - |  |  | $ | 1,291,391 |  |
| Intersegment sales |  |  | 10,713 |  |  |  | 27,842 |  |  |  | (38,555 | ) |  |  | - |  |  |  | 18,987 |  |  |  | 19,334 |  |  |  | (38,321 | ) |  |  | - |  |
| Total sales |  | $ | 815,252 |  |  | $ | 223,723 |  |  | $ | (38,555 | ) |  | $ | 1,000,420 |  |  | $ | 1,126,418 |  |  | $ | 203,294 |  |  | $ | (38,321 | ) |  | $ | 1,291,391 |  |

[0001437749-23-022513:notes:66]
|  |  | Six Months Ended June 30, 2023 |  |  | Six Months Ended June 30, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | - |  |  | $ | 1,888,330 |  |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | - |  |  | $ | 2,427,247 |  |
| Intersegment sales |  |  | 26,320 |  |  |  | 60,784 |  |  |  | (87,104 | ) |  |  | - |  |  |  | 29,257 |  |  |  | 33,659 |  |  |  | (62,916 | ) |  |  | - |  |
| Total sales |  | $ | 1,535,247 |  |  | $ | 440,187 |  |  | $ | (87,104 | ) |  | $ | 1,888,330 |  |  | $ | 2,101,362 |  |  | $ | 388,801 |  |  | $ | (62,916 | ) |  | $ | 2,427,247 |  |

[0001437749-23-022513:notes:67]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to income before provision for income taxes below. The computation of Adjusted EBITDA is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, and certain other specific provisions.

[0001437749-23-022513:notes:68]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 103,202 |  |  | $ | 241,928 |  |  | $ | 170,863 |  |  | $ | 412,349 |  |
| International |  |  | 33,343 |  |  |  | 29,534 |  |  |  | 65,757 |  |  |  | 55,526 |  |
| Total adjusted EBITDA |  | $ | 136,545 |  |  | $ | 271,462 |  |  | $ | 236,620 |  |  | $ | 467,875 |  |
| Interest expense |  |  | (25,160 | ) |  |  | (10,235 | ) |  |  | (48,155 | ) |  |  | (19,789 | ) |
| Depreciation and amortization |  |  | (41,247 | ) |  |  | (39,098 | ) |  |  | (81,198 | ) |  |  | (77,559 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 4,152 |  |  |  | (4,607 | ) |  |  | 7,312 |  |  |  | 3,185 |  |
| Non-cash share-based compensation expense (2) |  |  | (10,045 | ) |  |  | (7,735 | ) |  |  | (20,379 | ) |  |  | (16,562 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | (3,743 | ) |  |  | - |  |  |  | (3,743 | ) |
| Transaction costs and credit facility fees (4) |  |  | (1,149 | ) |  |  | (1,592 | ) |  |  | (2,240 | ) |  |  | (2,581 | ) |
| Business optimization and other charges (5) |  |  | (1,760 | ) |  |  | (1,590 | ) |  |  | (2,860 | ) |  |  | (2,749 | ) |
| Provision for regulatory charges (6) |  |  | - |  |  |  | - |  |  |  | (5,800 | ) |  |  | - |  |
| Other |  |  | 86 |  |  |  | 601 |  |  |  | 132 |  |  |  | 890 |  |
| Income before provision for income taxes |  | $ | 61,422 |  |  | $ | 203,463 |  |  | $ | 83,432 |  |  | $ | 348,967 |  |

[0001437749-23-022513:notes:69]
[same as prior period, unchanged from 0001437749-23-013331:notes:65]

[0001437749-23-022513:notes:70]
[same as prior period, unchanged from 0001437749-23-013331:notes:66]

[0001437749-23-022513:notes:71]
|  | (3) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment. |
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-23-022513:notes:72]
|  | (5) | Represents severance and other restructuring charges. |
|  | (6) | The amount recorded in the first quarter of 2023 represents a provision of $5,800 for a matter with the Consumer Product Safety Commission (CPSC) concerning the imposition of penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On May 25, 2023, the Company and the CPSC entered into a final mutual settlement agreement resolving this matter. |

[0001437749-23-022513:notes:73]
The Company’s sales in the U.S. represented approximately 75% and 82% of total sales for the three months ended  June 30, 2023 and  June 30, 2022, respectively. The Company's sales in the U.S. represented approximately 75% and 82% of total sales for the six months ended  June 30, 2023 and  June 30, 2022, respectively. Approximately 75% and 77% of the Company’s identifiable long-lived assets were located in the U.S. at  June 30, 2023 and  December 31, 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-23-022513:notes:74]
[same as prior period, unchanged from 0001437749-23-013331:notes:70]

[0001437749-23-022513:notes:75]
[same as prior period, unchanged from 0001437749-23-013331:notes:71]

[0001437749-23-022513:notes:76]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Raw material |  | $ | 818,867 |  |  | $ | 798,340 |  |
| Work-in-process |  |  | 14,919 |  |  |  | 14,899 |  |
| Finished goods |  |  | 602,833 |  |  |  | 592,145 |  |
| Total |  | $ | 1,436,619 |  |  | $ | 1,405,384 |  |

[0001437749-23-022513:notes:77]
[same as prior period, unchanged from 0001437749-23-013331:notes:73]

[0001437749-23-022513:notes:78]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Land and improvements |  | $ | 23,065 |  |  | $ | 22,589 |  |
| Buildings and improvements |  |  | 252,437 |  |  |  | 243,553 |  |
| Machinery and equipment |  |  | 256,375 |  |  |  | 229,593 |  |
| Dies and tools |  |  | 40,448 |  |  |  | 37,343 |  |
| Vehicles |  |  | 10,148 |  |  |  | 9,807 |  |
| Office equipment and systems |  |  | 164,114 |  |  |  | 148,166 |  |
| Leasehold improvements |  |  | 8,072 |  |  |  | 6,849 |  |
| Construction in progress |  |  | 64,885 |  |  |  | 52,522 |  |
| Gross property and equipment |  |  | 819,544 |  |  |  | 750,422 |  |
| Accumulated depreciation |  |  | (314,518 | ) |  |  | (282,818 | ) |
| Total |  | $ | 505,026 |  |  | $ | 467,604 |  |

[0001437749-23-022513:notes:79]
Total property and equipment includes finance leases of $26,993 and $24,719 on  June 30, 2023 and  December 31, 2022, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-23-022513:notes:80]
[same as prior period, unchanged from 0001437749-23-013331:notes:76]

[0001437749-23-022513:notes:81]
[same as prior period, unchanged from 0001437749-23-013331:notes:77]

[0001437749-23-022513:notes:82]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 128,599 |  |  | $ | 101,491 |  |  | $ | 138,011 |  |  | $ | 94,213 |  |
| Payments |  |  | (25,490 | ) |  |  | (18,434 | ) |  |  | (51,642 | ) |  |  | (31,458 | ) |
| Provision for warranty issued |  |  | 17,352 |  |  |  | 21,668 |  |  |  | 33,217 |  |  |  | 43,093 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,761 |  |  |  | 5,613 |  |  |  | 2,636 |  |  |  | 4,490 |  |
| Balance at end of period |  | $ | 122,222 |  |  | $ | 110,338 |  |  | $ | 122,222 |  |  | $ | 110,338 |  |

[0001437749-23-022513:notes:83]
[same as prior period, unchanged from 0001437749-23-013331:notes:79]

[0001437749-23-022513:notes:84]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 136,685 |  |  | $ | 115,923 |  |  | $ | 132,813 |  |  | $ | 111,647 |  |
| Deferred revenue contracts issued |  |  | 10,433 |  |  |  | 11,332 |  |  |  | 20,159 |  |  |  | 20,878 |  |
| Amortization of deferred revenue contracts |  |  | (6,196 | ) |  |  | (5,357 | ) |  |  | (12,050 | ) |  |  | (10,627 | ) |
| Balance at end of period |  | $ | 140,922 |  |  | $ | 121,898 |  |  | $ | 140,922 |  |  | $ | 121,898 |  |

[0001437749-23-022513:notes:85]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  June 30, 2023 is as follows:

[0001437749-23-022513:notes:86]
| Remainder of 2023 |  | $ | 12,789 |  |
| 2024 |  |  | 26,454 |  |
| 2025 |  |  | 26,744 |  |
| 2026 |  |  | 22,638 |  |
| 2027 |  |  | 17,656 |  |
| After 2027 |  |  | 34,641 |  |
| Total |  | $ | 140,922 |  |

[0001437749-23-022513:notes:87]
[same as prior period, unchanged from 0001437749-23-013331:notes:83]

[0001437749-23-022513:notes:88]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 74,025 |  |  | $ | 89,141 |  |
| Long-term portion - other long-term liabilities |  |  | 48,197 |  |  |  | 48,870 |  |
| Total |  | $ | 122,222 |  |  | $ | 138,011 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 25,818 |  |  | $ | 30,291 |  |
| Long-term portion - other long-term liabilities |  |  | 115,104 |  |  |  | 102,522 |  |
| Total |  | $ | 140,922 |  |  | $ | 132,813 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-23-022513:notes:89]
[same as prior period, unchanged from 0001437749-23-013331:notes:85]

[0001437749-23-022513:notes:90]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $24,096 and $33,551 on  June 30, 2023 and  December 31, 2022, respectively. During the six months ended  June 30, 2023, the Company recognized revenue of $15,529 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-022513:notes:91]
11.   Credit Agreements

[0001437749-23-022513:notes:92]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2023 and  December 31, 2022 consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $77,889 and $48,990, respectively.

[0001437749-23-022513:notes:93]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-23-022513:notes:94]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,647 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,770 |  |  |  | 27,420 |  |
| Other |  |  | 256 |  |  |  | 966 |  |
| Total |  |  | 1,545,379 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 18,767 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,302 |  |  |  | 2,650 |  |
| Total |  | $ | 1,523,310 |  |  | $ | 1,369,085 |  |

[0001437749-23-022513:notes:95]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  June 30, 2023 are as follows:

[0001437749-23-022513:notes:96]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

[0001437749-23-022513:notes:97]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in  September 2023, as noted in the table above.

[0001437749-23-022513:notes:98]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2023, was 7.01%.

[0001437749-23-022513:notes:99]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2023, the Company’s net secured leverage ratio was 2.52 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-23-022513:notes:100]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-022513:notes:101]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  June 30, 2023 was 6.49%.

[0001437749-23-022513:notes:102]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2023, the Company’s total leverage ratio was2.66 to 1.00 times, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2023.

[0001437749-23-022513:notes:103]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-23-022513:notes:104]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-23-022513:notes:105]
As of  June 30, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $999,945 of availability, net of outstanding letters of credit.

[0001437749-23-022513:notes:106]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.


## us-gaap:TreasuryStockTextBlock

[0001437749-23-022513:notes:107]
[same as prior period, unchanged from 0001437749-23-013331:notes:103]

[0001437749-23-022513:notes:108]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allowed for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three and six months ended  June 30, 2023 and 2022. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 11,748,713 shares of common stock for $777,379 (at an average cost per share of $66.17). Since the inception of all stock repurchase programs, the Company has reissued shares out of Treasury stock, including for earnout payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-022513:notes:109]
[same as prior period, unchanged from 0001437749-23-013331:notes:105]

[0001437749-23-022513:notes:110]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest,” to the condensed consolidated financial statements, for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-23-022513:notes:111]
[same as prior period, unchanged from 0001437749-23-013331:notes:107]

[0001437749-23-022513:notes:112]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,821 | ) |  |  | (13,645 | ) |  |  | (10,837 | ) |  |  | (25,592 | ) |
| Net income attributable to common shareholders |  | $ | 43,377 |  |  | $ | 142,714 |  |  | $ | 46,791 |  |  | $ | 244,625 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,721,614 |  |  |  | 63,662,510 |  |  |  | 61,645,341 |  |  |  | 63,607,711 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 626,570 |  |  |  | 1,040,295 |  |  |  | 784,570 |  |  |  | 1,180,348 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | 10,943 |  |  |  | - |  |  |  | 10,943 |  |
| Diluted shares |  |  | 62,348,184 |  |  |  | 64,713,748 |  |  |  | 62,429,911 |  |  |  | 64,799,002 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 2.24 |  |  | $ | 0.76 |  |  | $ | 3.85 |  |
| Diluted |  | $ | 0.70 |  |  | $ | 2.21 |  |  | $ | 0.75 |  |  | $ | 3.78 |  |

[0001437749-23-022513:notes:113]
(1) Excludes approximately 393,000 and 360,000 stock options and restricted stock awards for the three and six months ended  June 30, 2023, respectively, because they would be anti-dilutive. Excludes approximately 79,000 and 33,000 stock options and restricted stock awards for the three and six months ended  June 30, 2022, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-022513:notes:114]
[same as prior period, unchanged from 0001437749-23-013331:notes:110]

[0001437749-23-022513:notes:115]
The effective income tax rates for the six months ended  June 30, 2023 and 2022 was 28.5% and 21.3%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation coupled with lower year-over-year pre-tax book income in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-022513:notes:116]
15. Commitments and Contingencies

[0001437749-23-022513:notes:117]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2023 and  December 31, 2022 was approximately $166.9 million and $212.2 million respectively.

[0001437749-23-022513:notes:118]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (“PHS”) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, PHS filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which PHS characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to PHS but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-23-022513:notes:119]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Generac Power disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

[0001437749-23-022513:notes:120]
Eight additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  July 5, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power and/or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative classes allegedly incurred. In some of these cases, the Company as well as Generac Power has been named as a defendant. The cases were filed in or removed to the federal district courts for the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386; Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034; Kates v. Generac Power Systems, Inc., et al., Case No. 23-cv-00892; and Zukas, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-00874), the Northern District of California (Moon v. Generac Power Systems, Inc., et al., Case No. 22-cv-09183; Hufton, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-02462), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203), and the Eastern District of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23-cv-00217). Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints.

[0001437749-23-022513:notes:121]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings before the Honorable Lynn S. Adelman in the Eastern District of Wisconsin. On  July 19, 2023, Judge Adelman issued an order giving plaintiffs in these actions 45 days to file a consolidated master complaint and Generac Power and the Company 60 days thereafter to respond to the consolidated master complaint. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-23-022513:notes:122]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-23-022513:notes:123]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief. On  May 2, 2023, the court consolidated the two actions. On  May 30, 2023, the court entered an order staying the consolidated action.

[0001437749-23-022513:notes:124]
Between  March 20, 2023 and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. On  June 1, 2023, the court entered an order consolidating the three actions, appointing lead plaintiffs’ counsel, and staying the consolidated actions. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-23-022513:notes:125]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-23-022513:notes:126]
On  November 30, 2022, the U.S. Consumer Product Safety Commission (“CPSC”) notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act (“CPSA”), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to our statutory obligations under the Consumer Product Safety Act in connection with this matter. We are cooperating fully with this investigation and, at this time, we are unable to predict the eventual scope, duration or final outcome of such investigation.

[0001437749-23-022513:notes:127]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. ecobee has prevailed against EcoFactor in two separate proceedings before the International Trade Commission (Certain Smart Thermostats, Smart HVAC Systems, and Components Thereof (Inv. No. 337-TA-1185) and Certain Smart Thermostat Systems, Smart HVAC Systems, Smart HVAC Control Systems, and Components Thereof (Inv. No. 337-TA-1258) where EcoFactor accused ecobee of infringing its intellectual property.  In addition to the proceedings before the ITC, EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump sum payment of $5.4 million for past and future damages. EcoFactor has filed a motion seeking entry of a judgment based on the verdict plus pre-judgment interest, and ecobee filed its opposition to the motion. There are presently two remaining trials involving EcoFactor.  EcoFactor claims ecobee infringes two patents in Case No. 22-cv-000330-ADA, which is scheduled for a jury trial in the Western District of Texas on  October 30, 2023, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023 in the District of Delaware.  ecobee denies infringement and intends to vigorously defend each of the lawsuits.

[0001437749-23-022513:notes:128]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG).  Ollnova currently claims that ecobee infringes on four of its patents.  ecobee denies that its products infringe on any of the asserted patents and intends to vigorously defend the case, which is currently scheduled for jury trial on  September 11, 2023.

[0001437749-23-022513:notes:129]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)).  Spartronics made similar claims against Generac Power in a third-party complaint in a lawsuit Spartronics is defending brought by one of its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.)).  Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.

[0001437749-23-022513:notes:130]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## gnrc:IssuerRule10b51MaterialTermsTextBlock

[0001437749-23-022513:notes:131]
Item 5.           Other Information

[0001437749-23-022513:notes:132]
During the three months ended  June 30, 2023, no director or officer of the Company adopted, modified or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.

[0001437749-23-022513:notes:133]
On  August 8, 2023, the Human Capital and Compensation Committee of the Board of Directors approved certain incremental equity awards to be granted to Mr. Norm Taffe, the Company’s President Energy Technology.  The equity awards include: (i) an award of restricted stock valued at $1 million to be granted on  September 1, 2023, which vests on the third anniversary of the date of grant, and (ii) an award of performance shares to be granted on  March 1, 2024 and valued at $2 million, at target achievement level, with a performance period ending  December 31, 2026, that will be subject to performance conditions to be approved by the Board. Such awards are intended to align Mr. Taffe’s interests with the Company's Energy Technology initiatives over the next three years.
