# GNRC 8-K — 0001437749-23-021513 filed 2023-08-02

## item codes, every 8-K on or before 2023-08-08

- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2023-08-08

- none on or before 2023-08-08

## item 2.02 — earnings release, exhibit 99.1

[0001437749-23-021513:8k_2_02:1]
EX-99.1
2
ex_553005.htm
EXHIBIT 99.1

[0001437749-23-021513:8k_2_02:2]
ex_553005.htm

[0001437749-23-021513:8k_2_02:3]
Exhibit 99.1

[0001437749-23-021513:8k_2_02:4]
Generac Reports Second Quarter 2023 Results

[0001437749-23-021513:8k_2_02:5]
WAUKESHA, WISCONSIN (August 2, 2023) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its second quarter ended June 30, 2023 and provided an update on its outlook for the full year 2023.

[0001437749-23-021513:8k_2_02:6]
Second Quarter 2023 Highlights

[0001437749-23-021513:8k_2_02:7]
| ● | Net sales decreased 23% to $1.00 billion during the second quarter of 2023 as compared to $1.29 billion in the prior-year second quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, decreased approximately 26%. |

[0001437749-23-021513:8k_2_02:8]
|  | - | Residential product sales declined 44% to $499 million as compared to $896 million last year. |

[0001437749-23-021513:8k_2_02:9]
|  | - | Commercial & Industrial (“C&I”) product sales increased 24% to $384 million as compared to $309 million in the prior year. |

[0001437749-23-021513:8k_2_02:10]
| ● | Net income attributable to the Company during the second quarter was $45 million, or $0.70 per share, as compared to $156 million, or $2.21 per share, for the same period of 2022. |

[0001437749-23-021513:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $68 million, or $1.08 per share, as compared to $185 million, or $2.86 per share, in the second quarter of 2022. |

[0001437749-23-021513:8k_2_02:12]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $137 million, or 13.6% of net sales, as compared to $271 million, or 21.0% of net sales, in the prior year. |

[0001437749-23-021513:8k_2_02:13]
| ● | Cash flow from operations was $83 million during the second quarter, as compared to $24 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $54 million as compared to $6 million in the second quarter of 2022. The increase in free cash flow was due to significantly lower working capital investment in the current year quarter, partially offset by lower operating earnings, higher interest payments, and higher capital expenditures. |

[0001437749-23-021513:8k_2_02:14]
“As expected, overall second quarter sales declined from a strong prior year comparable period that included the significant benefit of excess backlog reduction for home standby generators,” said Aaron Jagdfeld, President and Chief Executive Officer. “While leading indicators of end market demand remain strong and we continue to make progress in reducing field inventory levels, residential product sales were modestly lower than our expectations in the quarter as a softer consumer environment for home improvement impacted shipments of home standby generators and chore products. However, global C&I product shipments remained strong at all-time record levels and were better than expected with broad-based growth across nearly all regions and channels.”

[0001437749-23-021513:8k_2_02:15]
Jagdfeld continued, “While our expectations for the consumer environment are now softer than previously projected, we believe the long-term mega-trends that are driving awareness for backup power solutions are as compelling as ever. Homeowners and businesses are increasingly sensitive to the growing energy supply-demand imbalances and intensifying impacts of extreme weather, and to address these opportunities, we are further investing in the build out of our suite of products and solutions to position ourselves as a leader in energy technology.”

[0001437749-23-021513:8k_2_02:16]
Additional Second Quarter 2023 Consolidated Highlights

[0001437749-23-021513:8k_2_02:17]
Gross profit margin was 32.8% as compared to 35.4% in the prior-year second quarter. This decline in margin was primarily due to the significant impact of unfavorable sales mix, partially offset by higher pricing and lower input costs.

[0001437749-23-021513:8k_2_02:18]
Operating expenses increased $2.3 million, or 1.0%, as compared to the second quarter of 2022. The increase was primarily driven by increased employee and marketing costs and the impact of recurring operating expenses from recent acquisitions, mostly offset by lower variable operating expenses.

[0001437749-23-021513:8k_2_02:19]
Provision for income taxes for the current year quarter was $15.9 million, or an effective tax rate of 25.9%, as compared to $45.8 million, or a 22.5% effective tax rate, for the prior year. The increase in the effective tax rate was primarily due to a lower benefit from equity compensation in the current year quarter as compared to the prior year.

[0001437749-23-021513:8k_2_02:20]
Business Segment Results

[0001437749-23-021513:8k_2_02:21]
Domestic Segment

[0001437749-23-021513:8k_2_02:22]
Domestic segment total sales (including inter-segment sales) decreased 28% to $815.3 million as compared to $1.13 billion in the prior year quarter, with the impact of acquisitions contributing approximately 3% revenue growth for the quarter. The decline in core sales was driven by lower residential product shipments, primarily due to a decline in home standby and clean energy shipments, partially offset by growth in smart thermostat sales. The overall weakness in residential products was partially offset by continued strength in C&I products, highlighted by an increase in shipments to direct customers for “beyond standby” applications, industrial distributors, and the national rental equipment channel.

[0001437749-23-021513:8k_2_02:23]
Adjusted EBITDA for the segment was $103.2 million, or 12.7% of total sales, as compared to $241.9 million in the prior year, or 21.5% of total sales. This margin decline was primarily driven by the significant impact of unfavorable sales mix and reduced operating leverage on lower shipments. The impact of acquisitions and continued investments for future growth also negatively affected margins during the quarter. These headwinds were partially offset by favorable price and cost benefits.

[0001437749-23-021513:8k_2_02:24]
International Segment

[0001437749-23-021513:8k_2_02:25]
International segment total sales (including inter-segment sales) increased 10% to $223.7 million as compared to $203.3 million in the prior year quarter, with the net impact of acquisitions and foreign currency contributing approximately 4% revenue growth for the quarter. The core sales growth for the segment was highlighted by strength in nearly all regions around the world.

[0001437749-23-021513:8k_2_02:26]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $33.3 million, or 14.9% of total sales, as compared to $29.5 million, or 14.5% of total sales, in the prior year. This stronger margin performance was primarily driven by favorable price and cost benefits.

[0001437749-23-021513:8k_2_02:27]
2023 Outlook Update

[0001437749-23-021513:8k_2_02:28]
As a result of the softer-than-expected consumer environment, the Company now anticipates lower residential product sales during the second half relative to prior expectations. Partially offsetting this lower outlook, C&I product sales are now expected to grow at a mid-teens rate during 2023 compared to the previous guidance of a mid to high-single digit increase. Accordingly, the Company now anticipates its full-year 2023 net sales to decline between -10 to -12% as compared to the prior year, which includes approximately 2% of net favorable impact from acquisitions and foreign currency. This compares to the previous guidance range of a decline between -6 to -10%.

[0001437749-23-021513:8k_2_02:29]
Additionally, due to the revised sales outlook, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 6.0 to 7.0% for the full-year 2023 compared to the previous guidance range of 7.5 to 8.5%. The corresponding EBITDA margin is now expected to be approximately 15.5 to 16.5% compared to the previous guidance range of 17.0 to 18.0%.

[0001437749-23-021513:8k_2_02:30]
Operating and free cash flow generation are still expected to return to strong levels for the full year, with conversion of adjusted net income to free cash flow expected to be well over 100%.

[0001437749-23-021513:8k_2_02:31]
Conference Call and Webcast

[0001437749-23-021513:8k_2_02:32]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, August 2, 2023 to discuss second quarter 2023 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BI782af2dcf8804d9491b4bc440ee60103. Individuals who wish to listen via telephone will be given dial-in information.

[0001437749-23-021513:8k_2_02:33]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-23-021513:8k_2_02:34]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-23-021513:8k_2_02:35]
About Generac

[0001437749-23-021513:8k_2_02:36]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- & battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The Company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-23-021513:8k_2_02:37]
Forward-looking Information

[0001437749-23-021513:8k_2_02:38]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-23-021513:8k_2_02:39]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-23-021513:8k_2_02:40]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-23-021513:8k_2_02:41]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-23-021513:8k_2_02:42]
|  | ● | availability of both labor and key components from our manufacturing operations and global supply chain, including single-sourced components and contract manufacturers, needed in producing our products; |

[0001437749-23-021513:8k_2_02:43]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-23-021513:8k_2_02:44]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-23-021513:8k_2_02:45]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-23-021513:8k_2_02:46]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-23-021513:8k_2_02:47]
|  | ● | our dependence on our distribution network; |

[0001437749-23-021513:8k_2_02:48]
|  | ● | our ability to remain competitive by investing in, developing or adapting to changing technologies and manufacturing techniques, as well as protecting our intellectual property rights; |

[0001437749-23-021513:8k_2_02:49]
|  | ● | loss of our key management and employees; |

[0001437749-23-021513:8k_2_02:50]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-23-021513:8k_2_02:51]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-23-021513:8k_2_02:52]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |

[0001437749-23-021513:8k_2_02:53]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations; and |

[0001437749-23-021513:8k_2_02:54]
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-021513:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2022 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-23-021513:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-23-021513:8k_2_02:57]
Non-GAAP Financial Metrics

[0001437749-23-021513:8k_2_02:58]
Core Sales

[0001437749-23-021513:8k_2_02:59]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-23-021513:8k_2_02:60]
Adjusted EBITDA

[0001437749-23-021513:8k_2_02:61]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-021513:8k_2_02:62]
Adjusted Net Income

[0001437749-23-021513:8k_2_02:63]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-23-021513:8k_2_02:64]
Free Cash Flow

[0001437749-23-021513:8k_2_02:65]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-23-021513:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-23-021513:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-23-021513:8k_2_02:68]
CONTACT:

[0001437749-23-021513:8k_2_02:69]
Michael W. Harris

[0001437749-23-021513:8k_2_02:70]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-23-021513:8k_2_02:71]
(262) 506-6064

[0001437749-23-021513:8k_2_02:72]
InvestorRelations@generac.com

[0001437749-23-021513:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-021513:8k_2_02:74]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net sales |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |
| Costs of goods sold |  |  | 671,999 |  |  |  | 834,406 |  |  |  | 1,287,410 |  |  |  | 1,609,514 |  |
| Gross profit |  |  | 328,421 |  |  |  | 456,985 |  |  |  | 600,920 |  |  |  | 817,733 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 115,743 |  |  |  | 120,066 |  |  |  | 216,431 |  |  |  | 218,309 |  |
| Research and development |  |  | 43,942 |  |  |  | 41,599 |  |  |  | 85,762 |  |  |  | 81,343 |  |
| General and administrative |  |  | 56,371 |  |  |  | 52,600 |  |  |  | 116,056 |  |  |  | 94,572 |  |
| Amortization of intangibles |  |  | 26,393 |  |  |  | 25,876 |  |  |  | 52,216 |  |  |  | 51,930 |  |
| Total operating expenses |  |  | 242,449 |  |  |  | 240,141 |  |  |  | 470,465 |  |  |  | 446,154 |  |
| Income from operations |  |  | 85,972 |  |  |  | 216,844 |  |  |  | 130,455 |  |  |  | 371,579 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (25,160 | ) |  |  | (10,235 | ) |  |  | (48,155 | ) |  |  | (19,789 | ) |
| Investment income |  |  | 941 |  |  |  | 92 |  |  |  | 1,629 |  |  |  | 169 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | (3,743 | ) |  |  | - |  |  |  | (3,743 | ) |
| Other, net |  |  | (331 | ) |  |  | 505 |  |  |  | (497 | ) |  |  | 751 |  |
| Total other expense, net |  |  | (24,550 | ) |  |  | (13,381 | ) |  |  | (47,023 | ) |  |  | (22,612 | ) |
| Income before provision for income taxes |  |  | 61,422 |  |  |  | 203,463 |  |  |  | 83,432 |  |  |  | 348,967 |  |
| Provision for income taxes |  |  | 15,907 |  |  |  | 45,826 |  |  |  | 23,756 |  |  |  | 74,434 |  |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | 59,676 |  |  |  | 274,533 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | 2,048 |  |  |  | 4,316 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.70 |  |  | $ | 2.24 |  |  | $ | 0.76 |  |  | $ | 3.85 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,721,614 |  |  |  | 63,662,510 |  |  |  | 61,645,341 |  |  |  | 63,607,711 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.70 |  |  | $ | 2.21 |  |  | $ | 0.75 |  |  | $ | 3.78 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,348,184 |  |  |  | 64,713,748 |  |  |  | 62,429,911 |  |  |  | 64,799,002 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 69,060 |  |  | $ | 120,864 |  |  | $ | 104,422 |  |  | $ | 243,229 |  |

[0001437749-23-021513:8k_2_02:75]
5

[0001437749-23-021513:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-021513:8k_2_02:77]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 192,768 |  |  | $ | 132,723 |  |
| Accounts receivable, less allowance for credit losses of $29,610 and $27,664 at June 30, 2023 and December 31, 2022, respectively |  |  | 540,332 |  |  |  | 522,458 |  |
| Inventories |  |  | 1,436,619 |  |  |  | 1,405,384 |  |
| Prepaid expenses and other current assets |  |  | 103,334 |  |  |  | 121,783 |  |
| Total current assets |  |  | 2,273,053 |  |  |  | 2,182,348 |  |
| Property and equipment, net |  |  | 505,026 |  |  |  | 467,604 |  |
| Customer lists, net |  |  | 200,478 |  |  |  | 206,987 |  |
| Patents and technology, net |  |  | 438,148 |  |  |  | 454,757 |  |
| Other intangible assets, net |  |  | 34,515 |  |  |  | 41,719 |  |
| Tradenames, net |  |  | 223,229 |  |  |  | 227,251 |  |
| Goodwill |  |  | 1,430,283 |  |  |  | 1,400,880 |  |
| Deferred income taxes |  |  | 13,953 |  |  |  | 12,746 |  |
| Operating lease and other non-current assets |  |  | 203,286 |  |  |  | 175,170 |  |
| Total assets |  | $ | 5,321,971 |  |  | $ | 5,169,462 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 77,889 |  |  | $ | 48,990 |  |
| Accounts payable |  |  | 454,727 |  |  |  | 446,050 |  |
| Accrued wages and employee benefits |  |  | 53,417 |  |  |  | 45,741 |  |
| Accrued product warranty |  |  | 74,025 |  |  |  | 89,141 |  |
| Other accrued liabilities |  |  | 254,700 |  |  |  | 349,389 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 22,069 |  |  |  | 12,733 |  |
| Total current liabilities |  |  | 936,827 |  |  |  | 992,044 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,523,310 |  |  |  | 1,369,085 |  |
| Deferred income taxes |  |  | 114,990 |  |  |  | 125,691 |  |
| Operating lease and other long-term liabilities |  |  | 319,400 |  |  |  | 312,916 |  |
| Total liabilities |  |  | 2,894,527 |  |  |  | 2,799,736 |  |
| Redeemable noncontrolling interest |  |  | 5,688 |  |  |  | 110,471 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,097,016 and 72,701,257 shares issued at June 30, 2023 and December 31, 2022, respectively |  |  | 732 |  |  |  | 728 |  |
| Additional paid-in capital |  |  | 1,053,759 |  |  |  | 1,016,138 |  |
| Treasury stock, at cost, 10,858,348 and 11,284,350 shares at June 30, 2023 and December 31, 2022, respectively |  |  | (779,892 | ) |  |  | (808,491 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,363,015 |  |  |  | 2,316,224 |  |
| Accumulated other comprehensive loss |  |  | (16,216 | ) |  |  | (65,102 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,419,282 |  |  |  | 2,257,381 |  |
| Noncontrolling interests |  |  | 2,474 |  |  |  | 1,874 |  |
| Total stockholders’ equity |  |  | 2,421,756 |  |  |  | 2,259,255 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,321,971 |  |  | $ | 5,169,462 |  |

[0001437749-23-021513:8k_2_02:78]
6

[0001437749-23-021513:8k_2_02:79]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-021513:8k_2_02:80]
|  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 59,676 |  |  | $ | 274,533 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 28,982 |  |  |  | 25,629 |  |
| Amortization of intangible assets |  |  | 52,216 |  |  |  | 51,930 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,921 |  |  |  | 1,287 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 3,743 |  |
| Deferred income taxes |  |  | (14,152 | ) |  |  | (61,625 | ) |
| Share-based compensation expense |  |  | 20,379 |  |  |  | 16,562 |  |
| Gain on disposal of assets |  |  | (532 | ) |  |  | (587 | ) |
| Other noncash (gains) charges |  |  | 735 |  |  |  | (2,037 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (15,535 | ) |  |  | (143,308 | ) |
| Inventories |  |  | (15,897 | ) |  |  | (158,232 | ) |
| Other assets |  |  | 16,333 |  |  |  | 1,637 |  |
| Accounts payable |  |  | (2,449 | ) |  |  | (54,583 | ) |
| Accrued wages and employee benefits |  |  | 6,694 |  |  |  | (11,876 | ) |
| Other accrued liabilities |  |  | (72,743 | ) |  |  | 86,616 |  |
| Excess tax benefits from equity awards |  |  | (1,040 | ) |  |  | (15,996 | ) |
| Net cash provided by operating activities |  |  | 64,588 |  |  |  | 13,693 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,801 |  |  |  | 1,883 |  |
| Proceeds from sale of investment |  |  | - |  |  |  | 1,308 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,472 |  |  |  | 1,843 |  |
| Contribution to equity method investment |  |  | (6,627 | ) |  |  | (10,229 | ) |
| Purchase of long-term investment |  |  | (2,000 | ) |  |  | - |  |
| Expenditures for property and equipment |  |  | (53,900 | ) |  |  | (46,503 | ) |
| Acquisition of business, net of cash acquired |  |  | (16,188 | ) |  |  | (11,421 | ) |
| Net cash used in investing activities |  |  | (75,442 | ) |  |  | (63,119 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 45,989 |  |  |  | 216,681 |  |
| Proceeds from long-term borrowings |  |  | 317,975 |  |  |  | 935,000 |  |
| Repayments of short-term borrowings |  |  | (21,125 | ) |  |  | (208,244 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (160,557 | ) |  |  | (538,401 | ) |
| Payment of contingent acquisition consideration |  |  | (4,979 | ) |  |  | - |  |
| Payment of debt issuance costs |  |  | - |  |  |  | (10,330 | ) |
| Purchase of additional ownership interest |  |  | (104,844 | ) |  |  | (375 | ) |
| Taxes paid related to equity awards |  |  | (9,186 | ) |  |  | (38,347 | ) |
| Proceeds from the exercise of stock options |  |  | 6,223 |  |  |  | 10,383 |  |
| Net cash provided by financing activities |  |  | 69,496 |  |  |  | 366,367 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,403 |  |  |  | 2,860 |  |
| Net increase in cash and cash equivalents |  |  | 60,045 |  |  |  | 319,801 |  |
| Cash and cash equivalents at beginning of period |  |  | 132,723 |  |  |  | 147,339 |  |
| Cash and cash equivalents at end of period |  | $ | 192,768 |  |  | $ | 467,140 |  |

[0001437749-23-021513:8k_2_02:81]
7

[0001437749-23-021513:8k_2_02:82]
| Generac Holdings Inc. |  |
| Segment Reporting and Product Class Information |  |
| (U.S. Dollars in Thousands) |  |
| (Unaudited) |  |

[0001437749-23-021513:8k_2_02:83]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |  | Three Months Ended June 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 804,539 |  |  | $ | 10,713 |  |  | $ | 815,252 |  |  | $ | 1,107,431 |  |  | $ | 18,987 |  |  | $ | 1,126,418 |  |
| International |  |  | 195,881 |  |  |  | 27,842 |  |  |  | 223,723 |  |  |  | 183,960 |  |  |  | 19,334 |  |  |  | 203,294 |  |
| Intercompany elimination |  |  | - |  |  |  | (38,555 | ) |  |  | (38,555 | ) |  |  | - |  |  |  | (38,321 | ) |  |  | (38,321 | ) |
| Total net sales |  | $ | 1,000,420 |  |  | $ | - |  |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | - |  |  | $ | 1,291,391 |  |
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |  | Six Months Ended June 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,508,927 |  |  | $ | 26,320 |  |  | $ | 1,535,247 |  |  | $ | 2,072,105 |  |  | $ | 29,257 |  |  | $ | 2,101,362 |  |
| International |  |  | 379,403 |  |  |  | 60,784 |  |  |  | 440,187 |  |  |  | 355,142 |  |  |  | 33,659 |  |  |  | 388,801 |  |
| Intercompany elimination |  |  | - |  |  |  | (87,104 | ) |  |  | (87,104 | ) |  |  | - |  |  |  | (62,916 | ) |  |  | (62,916 | ) |
| Total net sales |  | $ | 1,888,330 |  |  | $ | - |  |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  | $ | - |  |  | $ | 2,427,247 |  |
|  |  | External Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 498,587 |  |  | $ | 896,013 |  |  | $ | 917,450 |  |  | $ | 1,672,957 |  |  |  |  |  |  |  |  |  |
| Commercial & industrial products |  |  | 384,353 |  |  |  | 309,348 |  |  |  | 747,343 |  |  |  | 588,077 |  |  |  |  |  |  |  |  |  |
| Other |  |  | 117,480 |  |  |  | 86,030 |  |  |  | 223,537 |  |  |  | 166,213 |  |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 1,000,420 |  |  | $ | 1,291,391 |  |  | $ | 1,888,330 |  |  | $ | 2,427,247 |  |  |  |  |  |  |  |  |  |
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, 2023 |  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 103,202 |  |  | $ | 241,928 |  |  | $ | 170,863 |  |  | $ | 412,349 |  |  |  |  |  |  |  |  |  |
| International |  |  | 33,343 |  |  |  | 29,534 |  |  |  | 65,757 |  |  |  | 55,526 |  |  |  |  |  |  |  |  |  |
| Total adjusted EBITDA (1) |  | $ | 136,545 |  |  | $ | 271,462 |  |  | $ | 236,620 |  |  | $ | 467,875 |  |  |  |  |  |  |  |  |  |

[0001437749-23-021513:8k_2_02:84]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-23-021513:8k_2_02:85]
8

[0001437749-23-021513:8k_2_02:86]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-021513:8k_2_02:87]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | 2,048 |  |  |  | 4,316 |  |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | 59,676 |  |  |  | 274,533 |  |
| Interest expense |  |  | 25,160 |  |  |  | 10,235 |  |  |  | 48,155 |  |  |  | 19,789 |  |
| Depreciation and amortization |  |  | 41,247 |  |  |  | 39,098 |  |  |  | 81,198 |  |  |  | 77,559 |  |
| Provision for income taxes |  |  | 15,907 |  |  |  | 45,826 |  |  |  | 23,756 |  |  |  | 74,434 |  |
| Non-cash write-down and other adjustments (1) |  |  | (4,152 | ) |  |  | 4,607 |  |  |  | (7,312 | ) |  |  | (3,185 | ) |
| Non-cash share-based compensation expense (2) |  |  | 10,045 |  |  |  | 7,735 |  |  |  | 20,379 |  |  |  | 16,562 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 3,743 |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and credit facility fees (4) |  |  | 1,149 |  |  |  | 1,592 |  |  |  | 2,240 |  |  |  | 2,581 |  |
| Business optimization and other charges (5) |  |  | 1,760 |  |  |  | 1,590 |  |  |  | 2,860 |  |  |  | 2,749 |  |
| Provision for regulatory charges (6) |  |  | - |  |  |  | - |  |  |  | 5,800 |  |  |  | - |  |
| Other |  |  | (86 | ) |  |  | (601 | ) |  |  | (132 | ) |  |  | (890 | ) |
| Adjusted EBITDA |  |  | 136,545 |  |  |  | 271,462 |  |  |  | 236,620 |  |  |  | 467,875 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 520 |  |  |  | 3,742 |  |  |  | 3,653 |  |  |  | 7,167 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 136,025 |  |  | $ | 267,720 |  |  | $ | 232,967 |  |  | $ | 460,708 |  |

[0001437749-23-021513:8k_2_02:88]
| (1) Includes gains/losses on the disposition of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) Represents severance and other restructuring charges. |
| (6) The amount recorded in the first quarter 2023 represents a provision of $5.8 million for a matter with the Consumer Product Safety Commission (CPSC) concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On May 25, 2023, the Company and the CPSC entered into a final mutual settlement agreement resolving this matter. |

[0001437749-23-021513:8k_2_02:89]
9

[0001437749-23-021513:8k_2_02:90]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 45,198 |  |  | $ | 156,359 |  |  | $ | 57,628 |  |  | $ | 270,217 |  |
| Net income attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,278 |  |  |  | 2,048 |  |  |  | 4,316 |  |
| Net income |  |  | 45,515 |  |  |  | 157,637 |  |  |  | 59,676 |  |  |  | 274,533 |  |
| Amortization of intangible assets |  |  | 26,393 |  |  |  | 25,876 |  |  |  | 52,216 |  |  |  | 51,930 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 967 |  |  |  | 650 |  |  |  | 1,921 |  |  |  | 1,287 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 3,743 |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 669 |  |  |  | 5,710 |  |  |  | 1,387 |  |  |  | (46 | ) |
| (Gain)/loss attributable to business or asset dispositions (8) |  |  | - |  |  |  | - |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (5) |  |  | 1,760 |  |  |  | 1,590 |  |  |  | 2,860 |  |  |  | 2,749 |  |
| Provision for regulatory charges (6) |  |  | - |  |  |  | - |  |  |  | 5,800 |  |  |  | - |  |
| Tax effect of add backs (9) |  |  | (7,459 | ) |  |  | (8,448 | ) |  |  | (14,590 | ) |  |  | (15,764 | ) |
| Adjusted net income |  |  | 67,844 |  |  |  | 186,758 |  |  |  | 109,151 |  |  |  | 318,203 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 317 |  |  |  | 1,678 |  |  |  | 2,048 |  |  |  | 5,168 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 67,527 |  |  | $ | 185,080 |  |  | $ | 107,103 |  |  | $ | 313,035 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.08 |  |  | $ | 2.86 |  |  | $ | 1.72 |  |  | $ | 4.83 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,348,184 |  |  |  | 64,713,748 |  |  |  | 62,429,911 |  |  |  | 64,799,002 |  |

[0001437749-23-021513:8k_2_02:91]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |
| (9) In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the second quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the three months ended June 30, 2022 of $193,528 or $2.99 and six months ended June 30, 2022 of $328,799 or $5.07. Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the three months ended June 30, 2022 is $185,080 or $2.86, and six months ended June 30, 2022 is $313,035 or $4.83. |

[0001437749-23-021513:8k_2_02:92]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net cash provided by operating activities |  | $ | 83,147 |  |  | $ | 23,835 |  |  | $ | 64,588 |  |  | $ | 13,693 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 677 |  |  |  | 270 |  |  |  | 1,472 |  |  |  | 1,843 |  |
| Expenditures for property and equipment |  |  | (29,923 | ) |  |  | (18,303 | ) |  |  | (53,900 | ) |  |  | (46,503 | ) |
| Free cash flow |  | $ | 53,901 |  |  | $ | 5,802 |  |  | $ | 12,160 |  |  | $ | (30,967 | ) |

[0001437749-23-021513:8k_2_02:93]
10
