# GNRC 8-K — 0001437749-25-032069 filed 2025-10-29

## item codes, every 8-K on or before 2025-11-04

- 2025-10-29 0001437749-25-032069 — 2.02, 9.01
- 2025-07-30 0001437749-25-023858 — 2.02, 9.01
- 2025-07-02 0001437749-25-021956 — 1.01, 9.01
- 2025-06-13 0001437749-25-020324 — 5.07
- 2025-04-30 0001437749-25-013608 — 2.02, 9.01
- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2025-11-04

- none on or before 2025-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-032069:8k_2_02:1]
EX-99.1
2
ex_878327.htm
EXHIBIT 99.1

[0001437749-25-032069:8k_2_02:2]
ex_878327.htm

[0001437749-25-032069:8k_2_02:3]
Exhibit 99.1

[0001437749-25-032069:8k_2_02:4]
Generac Reports Third Quarter 2025 Results

[0001437749-25-032069:8k_2_02:5]
Growing data center market opportunities provide counterweight to below average power outage environment

[0001437749-25-032069:8k_2_02:6]
WAUKESHA, WISCONSIN (October 29, 2025) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2025 and provided an update on its outlook for the full-year 2025.

[0001437749-25-032069:8k_2_02:7]
Third Quarter 2025 Highlights

[0001437749-25-032069:8k_2_02:8]
| ● | Net sales decreased 5% to $1.11 billion during the third quarter of 2025 as compared to $1.17 billion in the prior-year third quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, decreased approximately 6%. |

[0001437749-25-032069:8k_2_02:9]
|  | - | Residential product sales decreased approximately 13% to $627 million as compared to $723 million last year. |

[0001437749-25-032069:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased approximately 9% to $358 million as compared to $328 million in the prior year. |

[0001437749-25-032069:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $66 million, or $1.12 per share, as compared to $114 million, or $1.89 per share, for the same period of 2024. |

[0001437749-25-032069:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $108 million, or $1.83 per share, as compared to $136 million, or $2.25 per share, in the third quarter of 2024. |

[0001437749-25-032069:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $193 million, or 17.3% of net sales, as compared to $232 million, or 19.8% of net sales, in the prior year. |

[0001437749-25-032069:8k_2_02:14]
| ● | Cash flow from operations was $118 million as compared to $212 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $96 million as compared to $184 million in the third quarter of 2024. |

[0001437749-25-032069:8k_2_02:15]
| ● | The Company is updating its overall net sales guidance for the full-year 2025 to be approximately flat as compared to the prior year. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be approximately 17.0%. |

[0001437749-25-032069:8k_2_02:16]
“Home standby and portable generator shipments grew sequentially in the quarter but were below expectations as a result of a power outage environment that was significantly below baseline average and the lowest third quarter of total outage hours since 2015,” said Aaron Jagdfeld, President and Chief Executive Officer. “This softer seasonal demand was partially offset by robust growth in our shipments of residential energy technology products and a strong increase in global C&I product sales. The third quarter also included initial shipments of our new large-megawatt generators to the data center market, and we continue to rapidly develop a pipeline of opportunities with our backlog for these products doubling over the last 90 days.”

[0001437749-25-032069:8k_2_02:17]
Jagdfeld continued, “The mega-trends that support our future growth potential remain intact as lower power quality and higher power prices will be an ongoing challenge given the more frequent and severe weather patterns and broader electrification trends. Importantly, the massive increase in data center power demand is expected to further stress the already fragile power grid by amplifying the growing electricity supply/demand imbalance. As a leading energy technology company, we believe Generac is uniquely positioned at the center of these numerous mega-trends that have the potential to drive substantial and sustainable growth in the years ahead.”

[0001437749-25-032069:8k_2_02:18]
Additional Third Quarter 2025 Consolidated Highlights

[0001437749-25-032069:8k_2_02:19]
Gross profit margin was 38.3% as compared to 40.2% in the prior-year third quarter. The decrease in gross margin was primarily due to unfavorable sales mix together with the impact of higher tariffs and lower manufacturing absorption, partially offset by increased price realization.

[0001437749-25-032069:8k_2_02:20]
Operating expenses increased $20.2 million, or 6.7%, as compared to the third quarter of 2024 as a result of certain legal and regulatory charges in the current year, as disclosed in the accompanying Reconciliation Schedules.

[0001437749-25-032069:8k_2_02:21]
Provision for income taxes for the current year quarter was $11.8 million, or an effective tax rate of 15.0%, as compared to $33.5 million, or a 22.7% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by certain favorable discrete tax items in the current-year quarter that did not occur in the prior year.

[0001437749-25-032069:8k_2_02:22]
Cash flow from operations was $118.4 million during the third quarter, as compared to $212.3 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $96.5 million as compared to $183.7 million in the third quarter of 2024. The change in free cash flow was primarily driven by an increase in inventory levels during the current year quarter and lower operating income.

[0001437749-25-032069:8k_2_02:23]
Business Segment Results

[0001437749-25-032069:8k_2_02:24]
Domestic Segment

[0001437749-25-032069:8k_2_02:25]
Domestic segment total sales (including inter-segment sales) decreased approximately 8% to $938.1 million as compared to $1.02 billion in the prior year, including an approximate 1% benefit from acquisitions. The core total sales decrease was primarily driven by weaker home standby and portable generator sales as a result of the significantly lower power outage environment in the current year quarter together with a strong prior year comparison which included multiple major landed hurricanes. This was partially offset by robust growth in residential energy technology shipments and an increase in C&I product sales to the telecom and industrial distributor channels.

[0001437749-25-032069:8k_2_02:26]
Adjusted EBITDA for the segment was $165.8 million, or 17.7% of domestic segment total sales, as compared to $211.6 million, or 20.7% of total sales, in the prior year. This decline was primarily driven by unfavorable sales mix together with the impact of incremental tariffs and operating deleverage on lower sales volumes, partially offset by increased price realization.

[0001437749-25-032069:8k_2_02:27]
International Segment

[0001437749-25-032069:8k_2_02:28]
International segment total sales (including inter-segment sales) increased approximately 11% to $185.5 million from $166.7 million in the prior year quarter, including an approximate 3% favorable impact from foreign currency. The core total sales growth for the segment was primarily driven by strength in C&I product shipments to European markets as well as initial shipments of large-megawatt generators to data center customers.

[0001437749-25-032069:8k_2_02:29]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $27.4 million, or 14.8% of international segment total sales, as compared to $20.3 million, or 12.2% of total sales, in the prior year. This margin increase was primarily driven by favorable sales mix.

[0001437749-25-032069:8k_2_02:30]
2025 Outlook

[0001437749-25-032069:8k_2_02:31]
As a result of the significantly weaker power outage environment in recent months impacting seasonal demand for home standby and portable generators, the Company is lowering its full-year net sales growth guidance to be approximately flat as compared to the prior year. This compares to the previous guidance range of an increase between 2 to 5%.

[0001437749-25-032069:8k_2_02:32]
Additionally, net income margin, before deducting for non-controlling interests, is now projected to be approximately 6.0% for the full-year 2025 compared to the previous guidance range of 7.5 to 8.5%. The corresponding adjusted EBITDA margin is now expected to be approximately 17.0% compared to the previous guidance range of 18.0 to 19.0%.

[0001437749-25-032069:8k_2_02:33]
Free cash flow conversion from adjusted net income is now expected to be approximately 80% as compared to the previous guidance range of 90 to 100%.

[0001437749-25-032069:8k_2_02:34]
Conference Call and Webcast

[0001437749-25-032069:8k_2_02:35]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, October 29, 2025 to discuss third quarter 2025 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/kmbm6pxu

[0001437749-25-032069:8k_2_02:36]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-25-032069:8k_2_02:37]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-25-032069:8k_2_02:38]
About Generac

[0001437749-25-032069:8k_2_02:39]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, data & telecom, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-032069:8k_2_02:40]
Forward-looking Information

[0001437749-25-032069:8k_2_02:41]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-25-032069:8k_2_02:42]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-25-032069:8k_2_02:43]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |

[0001437749-25-032069:8k_2_02:44]
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | our ability to develop and enhance products and gain customer acceptance, including our offerings that serve the data center and energy technology markets; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-032069:8k_2_02:45]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-25-032069:8k_2_02:46]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-25-032069:8k_2_02:47]
Non-GAAP Financial Metrics

[0001437749-25-032069:8k_2_02:48]
Core Sales

[0001437749-25-032069:8k_2_02:49]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-25-032069:8k_2_02:50]
4

[0001437749-25-032069:8k_2_02:51]
Adjusted EBITDA

[0001437749-25-032069:8k_2_02:52]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, including but not limited to class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-25-032069:8k_2_02:53]
Adjusted Net Income

[0001437749-25-032069:8k_2_02:54]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-25-032069:8k_2_02:55]
Free Cash Flow

[0001437749-25-032069:8k_2_02:56]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-25-032069:8k_2_02:57]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-25-032069:8k_2_02:58]
SOURCE: Generac Holdings Inc.

[0001437749-25-032069:8k_2_02:59]
CONTACT:

[0001437749-25-032069:8k_2_02:60]
Kris Rosemann

[0001437749-25-032069:8k_2_02:61]
Director – Corporate Finance & Investor Relations

[0001437749-25-032069:8k_2_02:62]
(262) 506-6064

[0001437749-25-032069:8k_2_02:63]
InvestorRelations@generac.com

[0001437749-25-032069:8k_2_02:64]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-032069:8k_2_02:65]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 300,009 |  |  | $ | 281,277 |  |
| Accounts receivable, less allowance for credit losses of $34,543 and $35,465 as of September 30, 2025 and December 31, 2024, respectively |  |  | 680,082 |  |  |  | 612,107 |  |
| Inventories |  |  | 1,329,687 |  |  |  | 1,031,647 |  |
| Prepaid expenses and other current assets |  |  | 192,335 |  |  |  | 107,139 |  |
| Total current assets |  |  | 2,502,113 |  |  |  | 2,032,170 |  |
| Property and equipment, net |  |  | 778,590 |  |  |  | 690,023 |  |
| Customer lists, net |  |  | 135,982 |  |  |  | 152,737 |  |
| Patents and technology, net |  |  | 350,132 |  |  |  | 379,095 |  |
| Other intangible assets, net |  |  | 12,714 |  |  |  | 20,026 |  |
| Tradenames, net |  |  | 201,420 |  |  |  | 206,664 |  |
| Goodwill |  |  | 1,465,099 |  |  |  | 1,436,261 |  |
| Deferred income taxes |  |  | 20,111 |  |  |  | 24,132 |  |
| Operating lease and other assets |  |  | 131,941 |  |  |  | 168,223 |  |
| Total assets |  | $ | 5,598,102 |  |  | $ | 5,109,331 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 46,046 |  |  | $ | 55,848 |  |
| Accounts payable |  |  | 620,717 |  |  |  | 458,693 |  |
| Accrued wages and employee benefits |  |  | 68,251 |  |  |  | 81,485 |  |
| Accrued product warranty |  |  | 44,689 |  |  |  | 56,127 |  |
| Other accrued liabilities |  |  | 349,477 |  |  |  | 313,401 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 17,139 |  |  |  | 67,598 |  |
| Total current liabilities |  |  | 1,146,319 |  |  |  | 1,033,152 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,356,971 |  |  |  | 1,210,776 |  |
| Deferred income taxes |  |  | 62,091 |  |  |  | 33,185 |  |
| Deferred revenue |  |  | 208,939 |  |  |  | 193,260 |  |
| Operating lease and other long-term liabilities |  |  | 173,954 |  |  |  | 141,515 |  |
| Total liabilities |  |  | 2,948,274 |  |  |  | 2,611,888 |  |
| Redeemable non-controlling interests |  |  | 930 |  |  |  | - |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 74,050,637 and 73,785,631 shares issued as of September 30, 2025 and December 31, 2024, respectively |  |  | 741 |  |  |  | 738 |  |
| Additional paid-in capital |  |  | 1,176,108 |  |  |  | 1,133,756 |  |
| Treasury stock, at cost, 15,365,404 and 14,173,697 shares at September 30, 2025 and December 31, 2024, respectively |  |  | (1,356,714 | ) |  |  | (1,196,997 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 3,028,020 |  |  |  | 2,844,296 |  |
| Accumulated other comprehensive loss |  |  | (2,291 | ) |  |  | (85,399 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,643,748 |  |  |  | 2,494,278 |  |
| Noncontrolling interests |  |  | 5,150 |  |  |  | 3,165 |  |
| Total stockholders’ equity |  |  | 2,648,898 |  |  |  | 2,497,443 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,598,102 |  |  | $ | 5,109,331 |  |

[0001437749-25-032069:8k_2_02:66]
6

[0001437749-25-032069:8k_2_02:67]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-032069:8k_2_02:68]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net sales |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |
| Costs of goods sold |  |  | 687,431 |  |  |  | 701,294 |  |  |  | 1,901,986 |  |  |  | 1,896,824 |  |
| Gross profit |  |  | 426,922 |  |  |  | 472,269 |  |  |  | 1,215,657 |  |  |  | 1,164,209 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 145,104 |  |  |  | 145,310 |  |  |  | 410,664 |  |  |  | 382,049 |  |
| Research and development |  |  | 60,059 |  |  |  | 56,936 |  |  |  | 182,461 |  |  |  | 160,342 |  |
| General and administrative |  |  | 93,748 |  |  |  | 77,242 |  |  |  | 247,924 |  |  |  | 209,392 |  |
| Amortization of intangibles |  |  | 24,932 |  |  |  | 24,157 |  |  |  | 76,102 |  |  |  | 73,698 |  |
| Total operating expenses |  |  | 323,843 |  |  |  | 303,645 |  |  |  | 917,151 |  |  |  | 825,481 |  |
| Income from operations |  |  | 103,079 |  |  |  | 168,624 |  |  |  | 298,506 |  |  |  | 338,728 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (18,461 | ) |  |  | (22,910 | ) |  |  | (53,813 | ) |  |  | (69,833 | ) |
| Investment income |  |  | 1,646 |  |  |  | 1,757 |  |  |  | 5,618 |  |  |  | 5,286 |  |
| Change in fair value of investments |  |  | (5,667 | ) |  |  | 5,198 |  |  |  | (17,138 | ) |  |  | (2,938 | ) |
| Loss on refinancing of debt |  |  | (1,225 | ) |  |  | (4,861 | ) |  |  | (1,225 | ) |  |  | (4,861 | ) |
| Other, net |  |  | (1,034 | ) |  |  | (577 | ) |  |  | (5,244 | ) |  |  | (1,949 | ) |
| Total other expense, net |  |  | (24,741 | ) |  |  | (21,393 | ) |  |  | (71,802 | ) |  |  | (74,295 | ) |
| Income before provision for income taxes |  |  | 78,338 |  |  |  | 147,231 |  |  |  | 226,704 |  |  |  | 264,433 |  |
| Provision for income taxes |  |  | 11,758 |  |  |  | 33,453 |  |  |  | 41,416 |  |  |  | 65,124 |  |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | 185,288 |  |  |  | 199,309 |  |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 66,161 |  |  |  | 113,742 |  |  |  | 184,017 |  |  |  | 199,089 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.14 |  |  | $ | 1.91 |  |  | $ | 3.14 |  |  | $ | 3.29 |  |
| Weighted average common shares outstanding - basic: |  |  | 58,263,218 |  |  |  | 59,493,640 |  |  |  | 58,604,097 |  |  |  | 59,720,597 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.12 |  |  | $ | 1.89 |  |  | $ | 3.10 |  |  | $ | 3.25 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,122,849 |  |  |  | 60,312,393 |  |  |  | 59,314,618 |  |  |  | 60,475,478 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 60,765 |  |  | $ | 129,284 |  |  | $ | 267,125 |  |  | $ | 186,245 |  |

[0001437749-25-032069:8k_2_02:69]
7

[0001437749-25-032069:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-25-032069:8k_2_02:71]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 185,288 |  |  | $ | 199,309 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 67,571 |  |  |  | 54,236 |  |
| Amortization of intangible assets |  |  | 76,102 |  |  |  | 73,698 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,835 |  |  |  | 2,592 |  |
| Change in fair value of investments |  |  | 17,138 |  |  |  | 2,938 |  |
| Loss on refinancing of debt |  |  | 1,225 |  |  |  | 4,861 |  |
| Deferred income tax expense (benefit) |  |  | 32,416 |  |  |  | (23,546 | ) |
| Share-based compensation expense |  |  | 39,111 |  |  |  | 38,270 |  |
| Loss (gain) on disposal of assets |  |  | 553 |  |  |  | (34 | ) |
| Loss attributable to the disposition of a business |  |  | 3,905 |  |  |  | - |  |
| Other noncash charges |  |  | 2,445 |  |  |  | 2,904 |  |
| Excess tax expense (benefits) from equity awards |  |  | (476 | ) |  |  | (642 | ) |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (31,989 | ) |  |  | (120,137 | ) |
| Inventories |  |  | (273,053 | ) |  |  | 73,390 |  |
| Other assets |  |  | (53,138 | ) |  |  | (4,348 | ) |
| Accounts payable |  |  | 143,645 |  |  |  | 87,343 |  |
| Accrued wages and employee benefits |  |  | (15,064 | ) |  |  | 22,482 |  |
| Other accrued liabilities |  |  | 51,205 |  |  |  | (11,469 | ) |
| Net cash provided by operating activities |  |  | 248,719 |  |  |  | 401,847 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 35 |  |  |  | 144 |  |
| Contribution to tax equity investment |  |  | - |  |  |  | (1,629 | ) |
| Purchase of long-term investments |  |  | (3,035 | ) |  |  | (37,118 | ) |
| Proceeds from sale of long-term investments |  |  | - |  |  |  | 2,000 |  |
| Expenditures for property and equipment |  |  | (110,534 | ) |  |  | (83,399 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (21,784 | ) |
| Other investing activities |  |  | (1,999 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (115,533 | ) |  |  | (141,786 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 30,860 |  |  |  | 29,219 |  |
| Proceeds from long-term borrowings |  |  | 134,715 |  |  |  | 506,465 |  |
| Repayments of short-term borrowings |  |  | (47,290 | ) |  |  | (48,868 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (75,742 | ) |  |  | (560,644 | ) |
| Stock repurchases |  |  | (147,917 | ) |  |  | (152,743 | ) |
| Payment of debt issuance costs |  |  | (5,275 | ) |  |  | (3,616 | ) |
| Payment of contingent acquisition consideration |  |  | (2,700 | ) |  |  | - |  |
| Payment of deferred acquisition consideration |  |  | - |  |  |  | (7,361 | ) |
| Contributions received from noncontrolling interest in subsidiary |  |  | 979 |  |  |  | - |  |
| Dividends paid to noncontrolling interest of subsidiary |  |  | (293 | ) |  |  | - |  |
| Purchase of additional ownership interest |  |  | - |  |  |  | (9,117 | ) |
| Taxes paid related to equity awards |  |  | (12,864 | ) |  |  | (12,268 | ) |
| Proceeds from the exercise of stock options |  |  | 4,233 |  |  |  | 12,366 |  |
| Net cash used in financing activities |  |  | (121,294 | ) |  |  | (246,567 | ) |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 6,840 |  |  |  | (311 | ) |
| Net increase in cash and cash equivalents |  |  | 18,732 |  |  |  | 13,183 |  |
| Cash and cash equivalents at beginning of period |  |  | 281,277 |  |  |  | 200,994 |  |
| Cash and cash equivalents at end of period |  | $ | 300,009 |  |  | $ | 214,177 |  |

[0001437749-25-032069:8k_2_02:72]
8

[0001437749-25-032069:8k_2_02:73]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-25-032069:8k_2_02:74]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2025 |  |  | Three Months Ended September 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 933,646 |  |  | $ | 4,494 |  |  | $ | 938,140 |  |  | $ | 1,011,347 |  |  | $ | 8,853 |  |  | $ | 1,020,200 |  |
| International |  |  | 180,707 |  |  |  | 4,784 |  |  |  | 185,491 |  |  |  | 162,216 |  |  |  | 4,485 |  |  | $ | 166,701 |  |
| Intercompany elimination |  |  | - |  |  |  | (9,278 | ) |  |  | (9,278 | ) |  |  | - |  |  |  | (13,338 | ) |  | $ | (13,338 | ) |
| Total net sales |  | $ | 1,114,353 |  |  | $ | - |  |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | - |  |  | $ | 1,173,563 |  |

[0001437749-25-032069:8k_2_02:75]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2025 |  |  | Nine Months Ended September 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,586,519 |  |  | $ | 18,418 |  |  | $ | 2,604,937 |  |  | $ | 2,541,242 |  |  | $ | 26,571 |  |  | $ | 2,567,813 |  |
| International |  |  | 531,124 |  |  |  | 37,113 |  |  |  | 568,237 |  |  |  | 519,791 |  |  |  | 18,127 |  |  |  | 537,918 |  |
| Intercompany elimination |  |  | - |  |  |  | (55,531 | ) |  |  | (55,531 | ) |  |  | - |  |  |  | (44,698 | ) |  |  | (44,698 | ) |
| Total net sales |  | $ | 3,117,643 |  |  | $ | - |  |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |  | $ | - |  |  | $ | 3,061,033 |  |

[0001437749-25-032069:8k_2_02:76]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Residential products |  | $ | 626,706 |  |  | $ | 722,787 |  |  | $ | 1,695,046 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 358,273 |  |  |  | 327,956 |  |  |  | 1,057,849 |  |  |  | 1,026,095 |  |
| Other |  |  | 129,374 |  |  |  | 122,820 |  |  |  | 364,748 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |

[0001437749-25-032069:8k_2_02:77]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 165,827 |  |  | $ | 211,567 |  |  | $ | 446,456 |  |  | $ | 450,416 |  |
| International |  |  | 27,388 |  |  |  | 20,298 |  |  |  | 83,934 |  |  |  | 73,371 |  |
| Total adjusted EBITDA (1) |  | $ | 193,215 |  |  | $ | 231,865 |  |  | $ | 530,390 |  |  | $ | 523,787 |  |

[0001437749-25-032069:8k_2_02:78]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-25-032069:8k_2_02:79]
9

[0001437749-25-032069:8k_2_02:80]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-032069:8k_2_02:81]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 199,089 |  |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | 185,288 |  |  |  | 199,309 |  |
| Interest expense |  |  | 18,461 |  |  |  | 22,910 |  |  |  | 53,813 |  |  |  | 69,833 |  |
| Depreciation and amortization |  |  | 49,211 |  |  |  | 43,152 |  |  |  | 143,673 |  |  |  | 127,934 |  |
| Provision for income taxes |  |  | 11,758 |  |  |  | 33,453 |  |  |  | 41,416 |  |  |  | 65,124 |  |
| Non-cash write-down and other adjustments (1) |  |  | 2,831 |  |  |  | 468 |  |  |  | 4,973 |  |  |  | 2,863 |  |
| Non-cash share-based compensation expense (2) |  |  | 12,751 |  |  |  | 13,115 |  |  |  | 39,111 |  |  |  | 38,270 |  |
| Transaction costs and credit facility fees (3) |  |  | 827 |  |  |  | 1,337 |  |  |  | 2,591 |  |  |  | 4,029 |  |
| Business optimization and other charges (4) |  |  | 368 |  |  |  | 1,564 |  |  |  | 5,385 |  |  |  | 3,190 |  |
| Provision for legal, regulatory and other costs (5) |  |  | 23,208 |  |  |  | 2,382 |  |  |  | 31,870 |  |  |  | 5,280 |  |
| Change in fair value of investments (6) |  |  | 5,667 |  |  |  | (5,198 | ) |  |  | 17,138 |  |  |  | 2,938 |  |
| Loss on refinancing of debt (7) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Other |  |  | 328 |  |  |  | 43 |  |  |  | 3,907 |  |  |  | 156 |  |
| Adjusted EBITDA |  |  | 193,215 |  |  |  | 231,865 |  |  |  | 530,390 |  |  |  | 523,787 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 655 |  |  |  | 81 |  |  |  | 1,899 |  |  |  | 521 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 192,560 |  |  | $ | 231,784 |  |  | $ | 528,491 |  |  | $ | 523,266 |  |

[0001437749-25-032069:8k_2_02:82]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 199,089 |  |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | 185,288 |  |  |  | 199,309 |  |
| Amortization of intangible assets |  |  | 24,932 |  |  |  | 24,157 |  |  |  | 76,102 |  |  |  | 73,698 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 557 |  |  |  | 644 |  |  |  | 1,835 |  |  |  | 2,592 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 204 |  |  |  | 747 |  |  |  | 656 |  |  |  | 2,272 |  |
| Loss (gain) attributable to business or asset dispositions (9) |  |  | - |  |  |  | - |  |  |  | 4,295 |  |  |  | 65 |  |
| Business optimization and other charges (4) |  |  | 368 |  |  |  | 1,564 |  |  |  | 5,385 |  |  |  | 3,190 |  |
| Provision for legal, regulatory and other costs (5) |  |  | 23,208 |  |  |  | 2,382 |  |  |  | 31,870 |  |  |  | 5,280 |  |
| Change in fair value of investments (6) |  |  | 5,667 |  |  |  | (5,198 | ) |  |  | 17,138 |  |  |  | 2,938 |  |
| Loss on refinancing of debt (7) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Tax effect of add backs |  |  | (13,900 | ) |  |  | (7,317 | ) |  |  | (41,407 | ) |  |  | (23,762 | ) |
| Adjusted net income |  |  | 108,841 |  |  |  | 135,618 |  |  |  | 282,387 |  |  |  | 270,443 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 108,422 |  |  | $ | 135,582 |  |  | $ | 281,116 |  |  | $ | 270,223 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.83 |  |  | $ | 2.25 |  |  | $ | 4.74 |  |  | $ | 4.47 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,122,849 |  |  |  | 60,312,393 |  |  |  | 59,314,618 |  |  |  | 60,475,478 |  |

[0001437749-25-032069:8k_2_02:83]
| (1) Includes (gains) losses on the disposition of assets other than in the ordinary course of business, (gains) losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |

[0001437749-25-032069:8k_2_02:84]
10

[0001437749-25-032069:8k_2_02:85]
| (2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement. |
| (4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
| (5) Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations: |

[0001437749-25-032069:8k_2_02:86]
|  | • | A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $2.7 million and $5.9 million for the three and nine months ended September 30, 2025, respectively, and $2.4 million and $4.9 million for the three and nine months ended September 30, 2024, respectively. |

[0001437749-25-032069:8k_2_02:87]
|  | • | A provision for a $15.0 million multi-district class action settlement related to clean energy products and legal expenses related to certain class action lawsuits - $17.8 million and $21.6 million for the three and nine months ended September 30, 2025, respectively. |

[0001437749-25-032069:8k_2_02:88]
|  | • | Legal expenses related to certain government inquiries and other significant matters - $2.7 million and $4.3 million for the three and nine months ended September 30, 2025, respectively. |

[0001437749-25-032069:8k_2_02:89]
|  | • | Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0 and $0.4 million for the three and nine months ended September 30, 2024. |

[0001437749-25-032069:8k_2_02:90]
| (6) Represents non-cash gains or losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities. |
| (7) For the three and nine months ended September 30, 2025, the loss represents third party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Tranche A Term Loan Facility and Revolving Debt Facility. For the three and nine months ended September 30, 2024, the loss represents fees paid to creditors and the write-off of the original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility. |
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (9) The pre-tax loss in the nine months ended September 30, 2025, relates primarily to the sale of our immaterial Tank Utility fleet business during the second quarter of 2025. |

[0001437749-25-032069:8k_2_02:91]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 118,378 |  |  | $ | 212,285 |  |  | $ | 248,719 |  |  | $ | 401,847 |  |
| Expenditures for property and equipment |  |  | (21,881 | ) |  |  | (28,627 | ) |  |  | (110,534 | ) |  |  | (83,399 | ) |
| Free cash flow |  | $ | 96,497 |  |  | $ | 183,658 |  |  | $ | 138,185 |  |  | $ | 318,448 |  |

[0001437749-25-032069:8k_2_02:92]
11
