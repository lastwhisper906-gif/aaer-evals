# GNRC notes — 0001437749-25-033048


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-25-033048:notes:1]
[same as prior period, unchanged from 0001437749-25-024879:notes:1]

[0001437749-25-033048:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, data & telecom, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-25-033048:notes:3]
[same as prior period, unchanged from 0001437749-25-024879:notes:3]

[0001437749-25-033048:notes:4]
[same as prior period, unchanged from 0001437749-25-024879:notes:4]

[0001437749-25-033048:notes:5]
The condensed consolidated balance sheet as of  September 30, 2025, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-25-033048:notes:6]
[same as prior period, unchanged from 0001437749-25-024879:notes:6]

[0001437749-25-033048:notes:7]
[same as prior period, unchanged from 0001437749-25-024879:notes:7]

[0001437749-25-033048:notes:8]
New Accounting Pronouncements

[0001437749-25-033048:notes:9]
[same as prior period, unchanged from 0001437749-25-024879:notes:10]

[0001437749-25-033048:notes:10]
In  September 2025, the FASB issued ASU 2025-06 Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40).  The update is intended to better align internal use software guidance with modern development methods, which have evolved to commonly include incremental and iterative development approaches.  The ASU requires an entity to start capitalizing software costs when management has authorized and committed to funding a software project and when it is probable the project will be completed and used to perform the intended function.  The ASU amendments also supersede previous guidance on website development costs.  The update is effective for fiscal years beginning after  December 15, 2027 and  may be adopted prospectively, retrospectively or with a modified transition approach. Early adoption is permitted. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-25-033048:notes:11]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors with more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-25-033048:notes:12]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-25-033048:notes:13]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update was effective for fiscal year 2024 and is effective for interim periods in fiscal 2025. The required annual disclosures are reflected in Note 7, "Segment Reporting," to the 2024 Annual Report on Form 10-K and the required quarterly disclosures are reflected in Note 7, "Segment Reporting," of this Quarterly Report on Form 10-Q.

[0001437749-25-033048:notes:14]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-033048:notes:15]
[same as prior period, unchanged from 0001437749-25-024879:notes:15]

[0001437749-25-033048:notes:16]
[same as prior period, unchanged from 0001437749-25-024879:notes:16]

[0001437749-25-033048:notes:17]
[same as prior period, unchanged from 0001437749-25-024879:notes:17]

[0001437749-25-033048:notes:18]
[same as prior period, unchanged from 0001437749-25-024879:notes:18]

[0001437749-25-033048:notes:19]
[same as prior period, unchanged from 0001437749-25-024879:notes:19]

[0001437749-25-033048:notes:20]
[same as prior period, unchanged from 0001437749-25-024879:notes:20]

[0001437749-25-033048:notes:21]
The combined preliminary purchase price for these acquisitions was $46,265, net of cash acquired and inclusive of holdbacks and estimated contingent consideration. The Company recorded its preliminary purchase price allocations for all of these acquisitions based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington was finalized during the second quarter of 2025 and purchase accounting for Ageto was finalized during the third quarter of 2025.  The final purchase accounting for those acquisitions resulted in no material adjustments to the Company's preliminary estimates. Purchase accounting for Wolverine will be finalized prior to  December 31, 2025. There have not been any material changes to the preliminary purchase price allocation for Wolverine as of  September 30, 2025.

[0001437749-25-033048:notes:22]
The accompanying condensed consolidated financial statements include the results of Wolverine, Ageto, C&I BESS, and Huntington from their dates of acquisition through  September 30, 2025. Pro forma and other financial information are not presented as the effects of these acquisitions are not material to the Company's results of operations or financial position.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-25-033048:notes:23]
3.   Redeemable Noncontrolling Interests

[0001437749-25-033048:notes:24]
The Company entered into a joint venture with E.A. Juffali & Brothers ("Juffali") on  August 7, 2025, based in Bahrain, aiming to expand its footprint in the Middle East region. The joint venture, operating under the name Generac Juffali Generators WLL, will function as a distinct legal entity with ownership interests divided between the Company and Juffali at 51% and 49%, respectively. As the Company holds a controlling financial interest in the joint venture's operating entity, it will consolidate the entity. During the third quarter of 2025, Juffali funded 49% of the total capital contributed to the new legal entity. The issuance date fair value of the 49% noncontrolling interest was $979 and was recorded in the condensed consolidated balance sheets as a redeemable noncontrolling interest. This classification is based on Juffali’s right to require redemption of its interest in Generac Juffali Generators under specific triggering circumstances outlined in the joint venture agreement. The redeemable noncontrolling interest is initially recognized at its issuance date fair value and is adjusted each reporting period to reflect the noncontrolling interests’ share of comprehensive income (loss).  If the redeemable noncontrolling interest becomes currently redeemable or is probable of becoming currently redeemable, it is then adjusted to the greater of the redemption value or the carrying value, with any redemption value adjustments being recorded directly to retained earnings in the consolidated balance sheets.

[0001437749-25-033048:notes:25]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder had a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company had a call option that  may be redeemed any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price was based on a multiple of earnings, subject to the terms of the acquisition agreement. In  May 2022, the Company purchased an additional 15% ownership interest in Captiva for $375, which was paid with cash on hand, bringing the Company's total ownership interest in Captiva to 66%. On  April 5, 2024, the Company acquired the remaining 34% ownership interest in Captiva for $9,117.

[0001437749-25-033048:notes:26]
The following table presents the changes in the redeemable noncontrolling interests for Generac Jufalli Generators and Captiva:

[0001437749-25-033048:notes:27]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 6,549 |  |
| Contribution received from noncontrolling interest holder |  |  | 979 |  |  |  | - |  |  |  | 979 |  |  |  | - |  |
| Net income (loss) |  |  | (49 | ) |  |  | - |  |  |  | (49 | ) |  |  | 58 |  |
| Foreign currency translation |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (176 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (9,117 | ) |
| Redemption Value Adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 2,686 |  |
| Balance at end of period |  | $ | 930 |  |  | $ | - |  |  | $ | 930 |  |  | $ | - |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-25-033048:notes:28]
4.   Derivative Instruments and Hedging Activities

[0001437749-25-033048:notes:29]
[same as prior period, unchanged from 0001437749-25-024879:notes:24]

[0001437749-25-033048:notes:30]
[same as prior period, unchanged from 0001437749-25-024879:notes:25]

[0001437749-25-033048:notes:31]
[same as prior period, unchanged from 0001437749-25-024879:notes:26]

[0001437749-25-033048:notes:32]
[same as prior period, unchanged from 0001437749-25-024879:notes:27]

[0001437749-25-033048:notes:33]
In  March 2020, the Company entered into three interest rate swap agreements, which were still outstanding as of  September 30, 2025. In  July 2025, in conjunction with the amendments to the Company’s credit agreements discussed further in Note 11, “Credit Agreements”, the Company modified its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness.  The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive income (loss) in the condensed consolidated balance sheets.

[0001437749-25-033048:notes:34]
The amount of after-tax unrealized losses recognized in accumulated other comprehensive loss for the three and nine months ended  September 30, 2025 was $(2,824) and $(10,227), respectively, and for the three and nine months ended  September 30, 2024 was $(10,177) and $(9,925), respectively.  The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-25-033048:notes:35]
[same as prior period, unchanged from 0001437749-25-024879:notes:30]

[0001437749-25-033048:notes:36]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. (Wallbox) to purchase 5% of its Class A common stock (Wallbox Shares) and acquire stock warrants, the latter of which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024 and the first and second quarters of 2025, the Company received additional warrants in connection with additional rounds of funding performed by Wallbox through the Company's anti-dilution protection rights. In accordance with GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the condensed consolidated statements of comprehensive income.

[0001437749-25-033048:notes:37]
The gain (loss) attributable to the stock warrants was $(1,910) and $(6,482) for the three and nine months ended  September 30, 2025, respectively, and $6,606 and $339 for the three and nine months ended  September 30, 2024, respectively.

[0001437749-25-033048:notes:38]
[same as prior period, unchanged from 0001437749-25-024879:notes:33]

[0001437749-25-033048:notes:39]
[same as prior period, unchanged from 0001437749-25-024879:notes:34]

[0001437749-25-033048:notes:40]
|  |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Interest rate swaps |  | $ | 14,775 |  |  | $ | 28,367 |  |
| Stock warrants |  |  | 1,437 |  |  |  | 7,919 |  |

[0001437749-25-033048:notes:41]
The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the condensed consolidated balance sheets as of  September 30, 2025, and  December 31, 2024. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  September 30, 2025, and  December 31, 2024, is an asset of $15,218 and $29,254, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-033048:notes:42]
5.   Fair Value Measurements

[0001437749-25-033048:notes:43]
[same as prior period, unchanged from 0001437749-25-024879:notes:38]

[0001437749-25-033048:notes:44]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility (Revolving Facility) borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the New Tranche A Term Loan Facility borrowing, which has a net carrying value of $696,610, was approximately $693,000 (Level 2) as of  September 30, 2025. The fair value of the Term Loan B Facility borrowing, which has a net carrying value of $492,457, was approximately $496,856 (Level 2) as of  September 30, 2025. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-25-033048:notes:45]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements of this Quarterly Report on Form 10-Q. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-25-033048:notes:46]
[same as prior period, unchanged from 0001437749-25-024879:notes:41]

[0001437749-25-033048:notes:47]
[same as prior period, unchanged from 0001437749-25-024879:notes:42]

[0001437749-25-033048:notes:48]
Equity securities primarily consist of Wallbox Shares. During the third quarter of 2024, the Company invested an incremental $35,000 in additional Wallbox Shares. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $8,515 and $19,075 as of  September 30, 2025, and  December 31, 2024, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the condensed consolidated statements of comprehensive income. The loss recognized on the Wallbox Shares was $(3,676) and $(10,560) for the three and nine months ended  September 30, 2025, respectively, and $(1,408) and $(3,277) for the three and nine months ended  September 30, 2024, respectively.

[0001437749-25-033048:notes:49]
[same as prior period, unchanged from 0001437749-25-024879:notes:45]

[0001437749-25-033048:notes:50]
[same as prior period, unchanged from 0001437749-25-024879:notes:46]

[0001437749-25-033048:notes:51]
The combined fair value of contingent consideration for the Chilicon Power LLC (Chilicon), Ageto, and PR Industrial S.r.l. (Pramac) acquisitions as of  September 30, 2025, and  December 31, 2024, was $32,406 and $34,114, respectively. The contingent consideration period for Chilicon extends through  December 31, 2028, while the contingent consideration period for Pramac extends through  December 31, 2025. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration earned as of  August 1, 2025, and the remaining two increments capable of being earned on  August 1, 2026 and  August 1, 2027. The current portion of contingent consideration totals $6,337 and is reported in other accrued liabilities, and the non-current portion totals $26,069 and is reported in operating lease and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-25-033048:notes:52]
The following table provides a reconciliation of the activity for contingent consideration during 2025:

[0001437749-25-033048:notes:53]
| Beginning balance, January 1, 2025 |  | $ | 34,114 |  |
| Payment of contingent consideration (1) |  |  | (2,700 | ) |
| Present value interest accretion |  |  | 992 |  |
| Ending balance, September 30, 2025 |  | $ | 32,406 |  |

[0001437749-25-033048:notes:54]
(1) Includes payments of $2,700 in cash for the Ageto acquisition.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-25-033048:notes:55]
6.   Accumulated Other Comprehensive Income (Loss)

[0001437749-25-033048:notes:56]
The following table presents a disclosure of changes in Accumulated Other Comprehensive Income (Loss) during the three and nine months ended  September 30, 2025 and 2024, net of tax:

[0001437749-25-033048:notes:57]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2025 |  | $ | (10,259 | ) |  |  | $ | 13,364 |  |  |  | $ | 3,105 |  |
| Other comprehensive income (loss) |  |  | (2,572 | ) | (1) |  |  | (2,824 | ) | (2) |  |  | (5,396 | ) |
| Ending Balance – September 30, 2025 |  | $ | (12,831 | ) |  |  | $ | 10,540 |  |  |  | $ | (2,291 | ) |

[0001437749-25-033048:notes:58]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |
| Other comprehensive income (loss) |  |  | 25,719 |  | (3) |  |  | (10,177 | ) | (4) |  |  | 15,542 |  |
| Ending Balance – September 30, 2024 |  | $ | (46,501 | ) |  |  | $ | 18,514 |  |  |  | $ | (27,987 | ) |

[0001437749-25-033048:notes:59]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2025 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |
| Other comprehensive income (loss) |  |  | 93,335 |  | (5) |  |  | (10,227 | ) | (6) |  |  | 83,108 |  |
| Ending Balance – September 30, 2025 |  | $ | (12,831 | ) |  |  | $ | 10,540 |  |  |  | $ | (2,291 | ) |

[0001437749-25-033048:notes:60]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  |  | (2,919 | ) | (7) |  |  | (9,925 | ) | (8) |  |  | (12,844 | ) |
| Ending Balance – September 30, 2024 |  | $ | (46,501 | ) |  |  | $ | 18,514 |  |  |  | $ | (27,987 | ) |

[0001437749-25-033048:notes:61]
|  | (1) | Represents a slightly unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2025, particularly the British Pound. |
|  | (2) | Represents unrealized losses of $3,753 on the interest rate swaps, net of tax effect of $929, for the three months ended September 30, 2025. |
|  | (3) | Represents favorable impact from the weakening of the U.S dollar against foreign currencies during the three months ended September 30, 2024, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized losses of $13,577 on the interest rate swaps, net of tax effect of $3,400, for the three months ended September 30, 2024. |
|  | (5) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2025, particularly the Euro and British Pound. |
|  | (6) | Represents unrealized losses of $13,591 on the interest rate swaps, net of tax effect of $3,364, for the nine months ended September 30, 2025. |
|  | (7) | Represents a slightly unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2024, particularly the Euro. |
|  | (8) | Represents unrealized losses of $13,241 on the interest rate swaps, net of tax effect of $3,316, for the nine months ended September 30, 2024. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-033048:notes:62]
7.   Segment Reporting

[0001437749-25-033048:notes:63]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and all historical acquisitions based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes all historical acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products and solutions, production processes, classes of customers and markets served, distribution methods, organizational structure, and regional considerations. Intersegment sales are at an appropriate transfer price.

[0001437749-25-033048:notes:64]
[same as prior period, unchanged from 0001437749-25-024879:notes:59]

[0001437749-25-033048:notes:65]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 605,444 |  |  | $ | 21,262 |  |  | $ | 626,706 |  |
| Commercial & industrial products |  |  | 212,875 |  |  |  | 145,398 |  |  |  | 358,273 |  |
| Other |  |  | 115,327 |  |  |  | 14,047 |  |  |  | 129,374 |  |
| Total net sales |  | $ | 933,646 |  |  | $ | 180,707 |  |  | $ | 1,114,353 |  |

[0001437749-25-033048:notes:66]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

[0001437749-25-033048:notes:67]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,632,048 |  |  | $ | 62,998 |  |  | $ | 1,695,046 |  |
| Commercial & industrial products |  |  | 635,356 |  |  |  | 422,493 |  |  |  | 1,057,849 |  |
| Other |  |  | 319,115 |  |  |  | 45,633 |  |  |  | 364,748 |  |
| Total net sales |  | $ | 2,586,519 |  |  | $ | 531,124 |  |  | $ | 3,117,643 |  |

[0001437749-25-033048:notes:68]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |

[0001437749-25-033048:notes:69]
[same as prior period, unchanged from 0001437749-25-024879:notes:64]

[0001437749-25-033048:notes:70]
[same as prior period, unchanged from 0001437749-25-024879:notes:65]

[0001437749-25-033048:notes:71]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain design, build, installation, and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time when control is transferred to the customer, while the extended warranty and subscription revenues are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes after certain milestones are met.

[0001437749-25-033048:notes:72]
[same as prior period, unchanged from 0001437749-25-024879:notes:67]

[0001437749-25-033048:notes:73]
[same as prior period, unchanged from 0001437749-25-024879:notes:68]

[0001437749-25-033048:notes:74]
[same as prior period, unchanged from 0001437749-25-024879:notes:69]

[0001437749-25-033048:notes:75]
|  |  | Three Months Ended September 30, 2025 |  |  | Three Months Ended September 30, 2024 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 933,646 |  |  | $ | 180,707 |  |  | $ | 1,114,353 |  |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |
| Intersegment sales |  |  | 4,494 |  |  |  | 4,784 |  |  |  | 9,278 |  |  |  | 8,853 |  |  |  | 4,485 |  |  |  | 13,338 |  |
| Total sales |  |  | 938,140 |  |  |  | 185,491 |  |  |  | 1,123,631 |  |  |  | 1,020,200 |  |  |  | 166,701 |  |  |  | 1,186,901 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (9,278 | ) |  |  |  |  |  |  |  |  |  |  | (13,338 | ) |
| Costs of goods sold |  |  | 562,434 |  |  |  | 134,275 |  |  |  | 696,709 |  |  |  | 589,694 |  |  |  | 124,938 |  |  |  | 714,632 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (9,278 | ) |  |  |  |  |  |  |  |  |  |  | (13,338 | ) |
| Operating expenses |  |  | 287,901 |  |  |  | 35,942 |  |  |  | 323,843 |  |  |  | 270,194 |  |  |  | 33,451 |  |  |  | 303,645 |  |
| Other segment items (1) |  |  | (78,022 | ) |  |  | (12,114 | ) |  |  | (90,136 | ) |  |  | (51,255 | ) |  |  | (11,986 | ) |  |  | (63,241 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 165,827 |  |  | $ | 27,388 |  |  | $ | 193,215 |  |  | $ | 211,567 |  |  | $ | 20,298 |  |  | $ | 231,865 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (18,461 | ) |  |  |  |  |  |  |  |  |  |  | (22,910 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (49,211 | ) |  |  |  |  |  |  |  |  |  |  | (43,152 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (2,831 | ) |  |  |  |  |  |  |  |  |  |  | (468 | ) |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (12,751 | ) |  |  |  |  |  |  |  |  |  |  | (13,115 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (827 | ) |  |  |  |  |  |  |  |  |  |  | (1,337 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (368 | ) |  |  |  |  |  |  |  |  |  |  | (1,564 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  | (23,208 | ) |  |  |  |  |  |  |  |  |  |  | (2,382 | ) |
| Change in fair value of investment (7) |  |  |  |  |  |  |  |  |  |  | (5,667 | ) |  |  |  |  |  |  |  |  |  |  | 5,198 |  |
| Loss on refinancing of debt (8) |  |  |  |  |  |  |  |  |  |  | (1,225 | ) |  |  |  |  |  |  |  |  |  |  | (4,861 | ) |
| Other |  |  |  |  |  |  |  |  |  |  | (328 | ) |  |  |  |  |  |  |  |  |  |  | (43 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 78,338 |  |  |  |  |  |  |  |  |  |  | $ | 147,231 |  |

[0001437749-25-033048:notes:76]
|  |  | Nine Months Ended September 30, 2025 |  |  | Nine Months Ended September 30, 2024 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 2,586,519 |  |  | $ | 531,124 |  |  | $ | 3,117,643 |  |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |
| Intersegment sales |  |  | 18,418 |  |  |  | 37,113 |  |  |  | 55,531 |  |  |  | 26,571 |  |  |  | 18,127 |  |  |  | 44,698 |  |
| Total sales |  |  | 2,604,937 |  |  |  | 568,237 |  |  |  | 3,173,174 |  |  |  | 2,567,813 |  |  |  | 537,918 |  |  |  | 3,105,731 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (55,531 | ) |  |  |  |  |  |  |  |  |  |  | (44,698 | ) |
| Costs of goods sold |  |  | 1,543,601 |  |  |  | 413,916 |  |  |  | 1,957,517 |  |  |  | 1,543,911 |  |  |  | 397,611 |  |  |  | 1,941,522 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (55,531 | ) |  |  |  |  |  |  |  |  |  |  | (44,698 | ) |
| Operating expenses |  |  | 809,056 |  |  |  | 108,095 |  |  |  | 917,151 |  |  |  | 722,082 |  |  |  | 103,399 |  |  |  | 825,481 |  |
| Other segment items (1) |  |  | (194,176 | ) |  |  | (37,708 | ) |  |  | (231,884 | ) |  |  | (148,596 | ) |  |  | (36,463 | ) |  |  | (185,059 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 446,456 |  |  | $ | 83,934 |  |  | $ | 530,390 |  |  | $ | 450,416 |  |  | $ | 73,371 |  |  | $ | 523,787 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (53,813 | ) |  |  |  |  |  |  |  |  |  |  | (69,833 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (143,673 | ) |  |  |  |  |  |  |  |  |  |  | (127,934 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (4,973 | ) |  |  |  |  |  |  |  |  |  |  | (2,863 | ) |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (39,111 | ) |  |  |  |  |  |  |  |  |  |  | (38,270 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (2,591 | ) |  |  |  |  |  |  |  |  |  |  | (4,029 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (5,385 | ) |  |  |  |  |  |  |  |  |  |  | (3,190 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  | (31,870 | ) |  |  |  |  |  |  |  |  |  |  | (5,280 | ) |
| Change in fair value of investments (7) |  |  |  |  |  |  |  |  |  |  | (17,138 | ) |  |  |  |  |  |  |  |  |  |  | (2,938 | ) |
| Loss on refinancing of debt (8) |  |  |  |  |  |  |  |  |  |  | (1,225 | ) |  |  |  |  |  |  |  |  |  |  | (4,861 | ) |
| Other (9) |  |  |  |  |  |  |  |  |  |  | (3,907 | ) |  |  |  |  |  |  |  |  |  |  | (156 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 226,704 |  |  |  |  |  |  |  |  |  |  | $ | 264,433 |  |

[0001437749-25-033048:notes:77]
|  | (1) | Other segment items primarily represent depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; and Provision for legal, regulatory, and other costs. |

[0001437749-25-033048:notes:78]
[same as prior period, unchanged from 0001437749-25-024879:notes:73]

[0001437749-25-033048:notes:79]
[same as prior period, unchanged from 0001437749-25-024879:notes:74]

[0001437749-25-033048:notes:80]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's credit agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (6) | Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $2,736 and $5,923 for the three and nine months ended September 30, 2025, respectively, and $2,382 and $4,915 for the three and nine months ended September 30, 2024, respectively. • A provision for a $15,000 multi-district class action settlement related to clean energy products and legal expenses related to certain class action lawsuits - $17,759 and $21,643 for the three and nine months ended September 30, 2025, respectively. • Legal expenses related to certain government inquiries and other significant matters - $2,713 and $4,304 for the three and nine months ended September 30, 2025, respectively. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0 and $365 for the three and nine months ended September 30, 2024, respectively. |
|  | (7) | Represents non-cash gains (losses) primarily from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (8) | For the three and nine months ended September 30, 2025, the loss represents third party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Original Tranche A Term Loan Facility and Original Revolving Facility. For the three and nine months ended September 30, 2024, the loss represents fees paid to creditors and the write-off of the original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility. |
|  | (9) | The pre-tax loss in the nine months ended September 30, 2025 relates primarily to the sale of the Company's immaterial Tank Utility fleet business during the second quarter of 2025. |

[0001437749-25-033048:notes:81]
[same as prior period, unchanged from 0001437749-25-024879:notes:76]

[0001437749-25-033048:notes:82]
|  |  | Assets by Reportable Segment |  |
|  |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Domestic |  | $ | 4,207,328 |  |  | $ | 3,873,904 |  |
| International |  |  | 1,390,774 |  |  |  | 1,235,427 |  |
| Total |  | $ | 5,598,102 |  |  | $ | 5,109,331 |  |

[0001437749-25-033048:notes:83]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Three Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 40,018 |  |  | $ | 34,122 |  |
| International |  |  | 9,193 |  |  |  | 9,030 |  |
| Total |  | $ | 49,211 |  |  | $ | 43,152 |  |

[0001437749-25-033048:notes:84]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 117,209 |  |  | $ | 100,379 |  |
| International |  |  | 26,464 |  |  |  | 27,555 |  |
| Total |  | $ | 143,673 |  |  | $ | 127,934 |  |

[0001437749-25-033048:notes:85]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Three Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 17,007 |  |  | $ | 25,716 |  |
| International |  |  | 4,874 |  |  |  | 2,911 |  |
| Total |  | $ | 21,881 |  |  | $ | 28,627 |  |

[0001437749-25-033048:notes:86]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 93,048 |  |  | $ | 73,983 |  |
| International |  |  | 17,486 |  |  |  | 9,416 |  |
| Total |  | $ | 110,534 |  |  | $ | 83,399 |  |

[0001437749-25-033048:notes:87]
The Company’s sales in the U.S. represented approximately 80% and 83% of total sales for the three months ended  September 30, 2025 and 2024, respectively, and 79% for both the nine months ended  September 30, 2025 and 2024, respectively. Approximately 74% and 76% of the Company's identifiable long-lived assets were located in the U.S. as of  September 30, 2025 and  December 31, 2024, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-25-033048:notes:88]
8.   Balance Sheet Details

[0001437749-25-033048:notes:89]
[same as prior period, unchanged from 0001437749-25-024879:notes:84]

[0001437749-25-033048:notes:90]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Raw material |  | $ | 766,330 |  |  | $ | 611,735 |  |
| Work-in-process |  |  | 11,823 |  |  |  | 6,814 |  |
| Finished goods |  |  | 551,534 |  |  |  | 413,098 |  |
| Total |  | $ | 1,329,687 |  |  | $ | 1,031,647 |  |

[0001437749-25-033048:notes:91]
[same as prior period, unchanged from 0001437749-25-024879:notes:86]

[0001437749-25-033048:notes:92]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Land and improvements |  | $ | 32,006 |  |  | $ | 30,220 |  |
| Buildings and improvements |  |  | 473,844 |  |  |  | 358,055 |  |
| Machinery and equipment |  |  | 324,388 |  |  |  | 296,409 |  |
| Dies and tools |  |  | 59,783 |  |  |  | 48,681 |  |
| Vehicles |  |  | 18,995 |  |  |  | 13,887 |  |
| Office & information technology equipment and internal use software |  |  | 238,181 |  |  |  | 213,003 |  |
| Leasehold improvements |  |  | 10,497 |  |  |  | 9,776 |  |
| Construction in progress |  |  | 69,287 |  |  |  | 110,651 |  |
| Gross property and equipment |  |  | 1,226,981 |  |  |  | 1,080,682 |  |
| Accumulated depreciation |  |  | (448,391 | ) |  |  | (390,659 | ) |
| Total |  | $ | 778,590 |  |  | $ | 690,023 |  |

[0001437749-25-033048:notes:93]
Total property and equipment includes finance leases of $85,794 and $61,214 on  September 30, 2025, and  December 31, 2024, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-25-033048:notes:94]
9.   Product Warranty Obligations

[0001437749-25-033048:notes:95]
[same as prior period, unchanged from 0001437749-25-024879:notes:90]

[0001437749-25-033048:notes:96]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 119,944 |  |  | $ | 106,279 |  |  | $ | 110,987 |  |  | $ | 116,408 |  |
| Payments |  |  | (23,934 | ) |  |  | (23,050 | ) |  |  | (63,689 | ) |  |  | (65,130 | ) |
| Provision for warranty issued |  |  | 28,147 |  |  |  | 22,755 |  |  |  | 72,091 |  |  |  | 54,804 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,144 |  |  |  | 1,458 |  |  |  | 5,912 |  |  |  | 1,360 |  |
| Balance at end of period |  | $ | 125,301 |  |  | $ | 107,442 |  |  | $ | 125,301 |  |  | $ | 107,442 |  |

[0001437749-25-033048:notes:97]
[same as prior period, unchanged from 0001437749-25-024879:notes:92]

[0001437749-25-033048:notes:98]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 202,650 |  |  | $ | 171,702 |  |  | $ | 186,922 |  |  | $ | 155,870 |  |
| Deferred revenue contracts issued |  |  | 17,567 |  |  |  | 15,169 |  |  |  | 50,299 |  |  |  | 45,042 |  |
| Amortization of deferred revenue contracts |  |  | (8,787 | ) |  |  | (7,577 | ) |  |  | (25,791 | ) |  |  | (21,618 | ) |
| Balance at end of period |  | $ | 211,430 |  |  | $ | 179,294 |  |  | $ | 211,430 |  |  | $ | 179,294 |  |

[0001437749-25-033048:notes:99]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  September 30, 2025 is as follows:

[0001437749-25-033048:notes:100]
| Remainder of 2025 |  | $ | 9,199 |  |
| 2026 |  |  | 38,423 |  |
| 2027 |  |  | 39,785 |  |
| 2028 |  |  | 34,718 |  |
| 2029 |  |  | 28,153 |  |
| After 2029 |  |  | 61,152 |  |
| Total |  | $ | 211,430 |  |

[0001437749-25-033048:notes:101]
[same as prior period, unchanged from 0001437749-25-024879:notes:96]

[0001437749-25-033048:notes:102]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 44,689 |  |  | $ | 56,127 |  |
| Long-term portion - other long-term liabilities |  |  | 80,612 |  |  |  | 54,860 |  |
| Total |  | $ | 125,301 |  |  | $ | 110,987 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - Other accrued liabilities |  | $ | 37,746 |  |  | $ | 34,069 |  |
| Long-term portion - Deferred Revenue |  |  | 173,684 |  |  |  | 152,853 |  |
| Total |  | $ | 211,430 |  |  | $ | 186,922 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-033048:notes:103]
10.   Contract Balances

[0001437749-25-033048:notes:104]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits and other contract liabilities was $58,901 and $26,858 on  September 30, 2025, and  December 31, 2024, respectively. During the nine months ended  September 30, 2025, the Company recognized revenue of $23,020 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-033048:notes:105]
11.   Credit Agreements

[0001437749-25-033048:notes:106]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $46,046 and $55,848, respectively. As of  September 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 6.33% and 5.44%, respectively.

[0001437749-25-033048:notes:107]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-25-033048:notes:108]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 495,000 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,938 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 91,914 |  |  |  | 66,355 |  |
| Other |  |  | 3,134 |  |  |  | 8,972 |  |
| Total |  |  | 1,374,110 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 8,064 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,075 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,356,971 |  |  | $ | 1,210,776 |  |

[0001437749-25-033048:notes:109]
As of  September 30, 2025, there were $5,267 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the condensed consolidated balance sheets, and $5,938 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the condensed consolidated balance sheets.

[0001437749-25-033048:notes:110]
The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030.  The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on  September 30, 2025, before considering original issue discount and deferred financing costs, were as follows:

[0001437749-25-033048:notes:111]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2025 |  | $ | - |  |  | $ | 1,250 |  |  | $ | - |  |  | $ | 1,250 |  |
| 2026 |  |  | 4,375 |  |  |  | 5,000 |  |  |  | - |  |  |  | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 690,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 495,000 |  |  | $ | 90,000 |  |  | $ | 1,285,000 |  |

[0001437749-25-033048:notes:112]
The Company’s credit agreements originally provided for a
    $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a
    $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of
    0.75% or adjusted SOFR rate plus an applicable margin of
    1.75%, subject to a SOFR floor of
    0.0%, and was scheduled to mature on
     December 13, 2026.

[0001437749-25-033048:notes:113]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.03% combined rate as of  September 30, 2025.

[0001437749-25-033048:notes:114]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2025, the Company’s net secured leverage ratio was 1.35 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

[0001437749-25-033048:notes:115]
The Company’s original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-25-033048:notes:116]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%.  The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.  Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements.  As of  September 30, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 5.78%.

[0001437749-25-033048:notes:117]
In accordance with ASC
      470-
      50, the Company capitalized
      $5,275 of debt issuance costs related to this transaction.  Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of
      $443 and expensed
      $782 of
      third-party fees as a loss on refinancing of debt.

[0001437749-25-033048:notes:118]
Both the Original and New Tranche A Term Loan Facility and the Original and New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2025, the Company’s total leverage ratio was 1.41 to 1.00, and the Company's interest coverage ratio was 12.54 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of  September 30, 2025.

[0001437749-25-033048:notes:119]
The New Term Loan B Facility, New Tranche A Term Loan Facility and New Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-25-033048:notes:120]
As of  September 30, 2025, there was $90,000 outstanding under the New Revolving Facility, leaving $909,250 of unused capacity, net of outstanding letters of credit.

[0001437749-25-033048:notes:121]
See Item 7A of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:TreasuryStockTextBlock

[0001437749-25-033048:notes:122]
12.   Stock Repurchase Program

[0001437749-25-033048:notes:123]
[same as prior period, unchanged from 0001437749-25-024879:notes:116]

[0001437749-25-033048:notes:124]
During the three and nine months ended  September 30, 2025, the Company repurchased 0 and 1,109,206 shares of common stock for $0 and $147,917, respectively. During the three and nine months ended  September 30, 2024, the Company repurchased 690,711 and 1,046,351 shares of common stock for $102,134 and $152,743, respectively. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-033048:notes:125]
13. Earnings Per Share

[0001437749-25-033048:notes:126]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested in the money restricted stock and the exercise of outstanding in the money stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interests,” of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-25-033048:notes:127]
[same as prior period, unchanged from 0001437749-25-024879:notes:120]

[0001437749-25-033048:notes:128]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 199,089 |  |
| Redemption value adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,686 | ) |
| Net income attributable to common shareholders |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 196,403 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 58,263,218 |  |  |  | 59,493,640 |  |  |  | 58,604,097 |  |  |  | 59,720,597 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 859,631 |  |  |  | 818,753 |  |  |  | 710,521 |  |  |  | 754,881 |  |
| Weighted average shares, diluted |  |  | 59,122,849 |  |  |  | 60,312,393 |  |  |  | 59,314,618 |  |  |  | 60,475,478 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.14 |  |  | $ | 1.91 |  |  | $ | 3.14 |  |  | $ | 3.29 |  |
| Diluted |  | $ | 1.12 |  |  | $ | 1.89 |  |  | $ | 3.10 |  |  | $ | 3.25 |  |

[0001437749-25-033048:notes:129]
(1) Excludes approximately 177,000 and 316,000 stock options and restricted stock awards for the three and nine months ended  September 30, 2025, respectively, and 430,000 and 440,000 stock options and restricted stock awards for the three and nine months ended  September 30, 2024, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-033048:notes:130]
14. Income Taxes

[0001437749-25-033048:notes:131]
The effective income tax rates for the nine months ended  September 30, 2025 and 2024 were 18.3% and 24.6%, respectively. The decrease in the effective tax rate for the current period was primarily attributable to discrete tax benefits related to a business disposition and certain favorable return-to-provision adjustments in the current year.

[0001437749-25-033048:notes:132]
On  July 4, 2025, the United States signed the “One Big Beautiful Bill Act” (OBBBA) into law. This legislation makes permanent several key provisions of the Tax Cuts and Jobs Act, including 100% bonus depreciation and the immediate expensing of domestic research and development costs. Under ASC 740, “Income Taxes,” the effects of changes in tax laws are reflected in the Company’s financial statements in the quarter in which the legislation was passed.

[0001437749-25-033048:notes:133]
The Company expects to realize cash tax savings during 2025 as a result of provisions related to bonus depreciation and domestic research and development expensing. These changes did not have a material impact on the Company’s effective income tax rate for the third quarter or the estimated annual effective tax rate for 2025 as the changes relate to temporary differences in basis.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-033048:notes:134]
15. Commitments and Contingencies

[0001437749-25-033048:notes:135]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  September 30, 2025, and  December 31, 2024, was $165,200 and $165,432, respectively.

[0001437749-25-033048:notes:136]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-25-033048:notes:137]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis.  The parties will seek court approval for the classwide settlement and Generac Power has reserved for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.

[0001437749-25-033048:notes:138]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025 and the Company has filed a motion to dismiss.

[0001437749-25-033048:notes:139]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-25-033048:notes:140]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020.  On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.

[0001437749-25-033048:notes:141]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-25-033048:notes:142]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest and continues to accrue for post-judgment interest thereafter. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-25-033048:notes:143]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims and Generac filed a counterclaim. On  August 18, 2025, Generac Power prevailed in the defense of Spartronics’ arbitration claims and substantially prevailed on its counterclaim seeking possession of pre-paid raw materials and owned tooling.  Generac Power also received an award of its legal fees in connection with the action.  The award is binding and not subject of an appeal.

[0001437749-25-033048:notes:144]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-25-033048:notes:145]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-25-033048:notes:146]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing. Generac Power intends to participate in a mediation in  January 2026 along with other parties and plaintiffs, in advance of a trial that is likely to occur on or after  April 2026.  Plaintiffs have not fully quantified their damages but will be seeking damages in excess of Generac Power’s available insurance. The Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.

[0001437749-25-033048:notes:147]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies.  Champion in turn filed new patent infringement claims relating to its own carbon monoxide detection and shutoff technology.  Generac Power denies the infringement allegations and intends to vigorously defend the matter.

[0001437749-25-033048:notes:148]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

[0001437749-25-033048:notes:149]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-25-033048:notes:150]
[same as prior period, unchanged from 0001437749-25-024879:notes:141]

[0001437749-25-033048:notes:151]
During the three months ended  September 30, 2025, no director or officer of the Company adopted, modified or terminated a "Rule 10b5-1 trading arrangement" or "non-Rule 10b5-1 trading arrangement," as each term is defined in Item 408(a) of Regulation S-K.
