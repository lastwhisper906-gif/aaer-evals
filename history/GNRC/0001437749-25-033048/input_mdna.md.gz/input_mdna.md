# GNRC MD&A — 0001437749-25-033048


## mdna

[0001437749-25-033048:mdna:1]
[same as prior period, unchanged from 0001437749-25-024879:mdna:1]

[0001437749-25-033048:mdna:2]
[same as prior period, unchanged from 0001437749-25-024879:mdna:2]

[0001437749-25-033048:mdna:3]
[same as prior period, unchanged from 0001437749-25-024879:mdna:3]

[0001437749-25-033048:mdna:4]
[same as prior period, unchanged from 0001437749-25-024879:mdna:4]

[0001437749-25-033048:mdna:5]
[same as prior period, unchanged from 0001437749-25-024879:mdna:5]

[0001437749-25-033048:mdna:6]
[same as prior period, unchanged from 0001437749-25-024879:mdna:6]

[0001437749-25-033048:mdna:7]
[same as prior period, unchanged from 0001437749-25-024879:mdna:7]

[0001437749-25-033048:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | our ability to develop and enhance products and gain customer acceptance, including our offerings that serve the data center and energy technology markets; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | scrutiny regarding our sustainability practices |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinance our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-033048:mdna:9]
[same as prior period, unchanged from 0001437749-25-024879:mdna:9]

[0001437749-25-033048:mdna:10]
[same as prior period, unchanged from 0001437749-25-024879:mdna:10]

[0001437749-25-033048:mdna:11]
As disclosed in Part I, Item 1A: Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, our business is subject to risks related to, among other factors, tariffs and other changes in U.S. trade policy and international trade relations. Starting in the first quarter of 2025, the United States government enacted additional tariffs on goods imported into the U.S. from numerous countries (such as China, Vietnam, and India) and certain countries announced tariffs on U.S. goods. Some of these tariffs have been subsequently modified or delayed, and the U.S. government has also stated it is willing to negotiate with respect to the tariffs it has enacted.

[0001437749-25-033048:mdna:12]
We have implemented price increases across many of our product offerings and are currently executing a number of supply chain initiatives to attempt to mitigate the impact of these tariffs on our profitability. Despite our efforts, these tariff actions may negatively impact demand due to higher prices and also result in lower margins for some of our products. As U.S. trade policy continues to evolve, Generac will continue to analyze the impact of future tariffs and actions that can be taken to mitigate and/or minimize their effects.

[0001437749-25-033048:mdna:13]
[same as prior period, unchanged from 0001437749-25-024879:mdna:14]

[0001437749-25-033048:mdna:14]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. Generac provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, data & telecom, and industrial markets. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-033048:mdna:15]
[same as prior period, unchanged from 0001437749-25-024879:mdna:16]

[0001437749-25-033048:mdna:16]
[same as prior period, unchanged from 0001437749-25-024879:mdna:17]

[0001437749-25-033048:mdna:17]
[same as prior period, unchanged from 0001437749-25-024879:mdna:18]

[0001437749-25-033048:mdna:18]
[same as prior period, unchanged from 0001437749-25-024879:mdna:19]

[0001437749-25-033048:mdna:19]
[same as prior period, unchanged from 0001437749-25-024879:mdna:20]

[0001437749-25-033048:mdna:20]
|  | ● | Lower power quality continuing to drive demand for backup power solutions: |
|  |  | o | More frequent severe and volatile weather impacting an aging grid, causing increased power outage activity. |
|  |  | o | Increasing deployment of intermittent generation sources coupled with accelerating electricity demand trends driving supply/demand imbalances for utilities and grid operators. |
|  | ● | Higher power prices driving the need for energy management solutions: |
|  |  | o | Electrification trends causing power demand to exceed supply, driving up power prices. |
|  |  | o | Investment required to upgrade grid infrastructure and transition to renewable power sources, pushing prices higher. |
|  | ● | Artificial intelligence adoption accelerating, creating a large market opportunity for backup power: |
|  |  | o | Significant power requirements for the buildout of data centers to enable AI adoption could drive further grid instability and higher power prices. |
|  |  | o | Acceleration in the number of hyperscale and edge data centers that require significant backup power, creates a significant growth opportunity for our C&I products. |
|  | ● | Growing demand for cleaner burning fuels: |
|  |  | o | Natural gas and other alternative fuels are vital to the energy transition. |
|  |  | o | Demand for natural gas-fueled backup generators growing as homes and businesses desire cleaner-burning fuel sources of generation. |
|  | ● | Required investment in global infrastructure, driving demand for our products: |
|  |  | o | Upgrading of aging and underinvested legacy infrastructure systems, such as power, telecommunications, transportation, and water. |
|  |  | o | Expanding investment for increasingly critical technology infrastructure as we transition to a more "connected" society. |
|  | ● | Home as a Sanctuary, driving increased demand for resiliency solutions that provide peace of mind: |
|  |  | o | Increasing importance of the home with more people working from home and aging in place. |
|  |  | o | Growing market for intelligent and connected homes that can provide improved energy efficiency. |

[0001437749-25-033048:mdna:21]
[same as prior period, unchanged from 0001437749-25-024879:mdna:22]

[0001437749-25-033048:mdna:22]
[same as prior period, unchanged from 0001437749-25-024879:mdna:23]

[0001437749-25-033048:mdna:23]
[same as prior period, unchanged from 0001437749-25-024879:mdna:24]

[0001437749-25-033048:mdna:24]
Solar, storage, and energy management market opportunities. We believe the electric utility landscape will undergo significant changes in the decade ahead due to accelerating demand growth, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. Importantly, we expect that a confluence of factors will continue to drive meaningful increases in power prices for end users in the future. As a result, on-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity as utility customers seek alternative solutions to combat rising power prices. In addition, battery storage provides customers another source of power resiliency for shorter duration outages. These markets have historically been supported by subsidies and investment tax credits for consumers and businesses to help advance the adoption of clean energy technologies. Further, production tax credits are being offered to businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. On July 4, 2025, the United States signed into law the OBBBA.  The OBBBA accelerates the phase-out of tax incentives for the solar market and includes certain supply chain requirements to qualify for these incentives. While the change in the availability and duration of tax incentives will negatively impact the solar and storage markets in the near term, we believe the overall mega-trends that are driving the solar, storage, and energy management markets currently provide sufficient incentive for long-term, value-creating investments for market participants in this space. Given the significant long-term market opportunity, we expect to further improve our capabilities in energy technology product development, sourcing, distribution, and marketing. In addition, we plan to leverage our significant competencies in the residential standby generator market to increase our market position in the residential solar, storage, and energy management markets as we continue to build out our residential ecosystem of products and solutions.

[0001437749-25-033048:mdna:25]
Natural gas generators, a continuing growth opportunity. We believe natural gas will continue to be an important and cleaner transition fuel of the future, compared to diesel, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, as the benefits of natural gas power generation are very compelling relative to traditional diesel fueled generators. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids, and overall use as DERs in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having the capability to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators. As a leader in natural gas power generation, we believe we are well positioned to capitalize on this strategic growth theme.

[0001437749-25-033048:mdna:26]
[same as prior period, unchanged from 0001437749-25-024879:mdna:27]

[0001437749-25-033048:mdna:27]
Substantial investment in new data centers and accelerating adoption of artificial intelligence. As a result of the development of artificial intelligence and the expected benefits of this technology, there is significant capital expenditure investment going into the build out of data center infrastructure, which should enable the accelerated adoption of artificial intelligence capabilities. Backup power solutions are a necessary part of the substantial investment in data centers. Given the significant power requirements of increasingly large data center campuses, and the mission critical nature of these applications that require complete resiliency coverage, demand for large backup power generators is expected to continue to grow at a dramatic rate for the foreseeable future. This ongoing rapid demand growth for large generators has resulted in market supply constraints. As a result of our recently introduced high output diesel generator offering, this large and growing data centers market represents a significant incremental opportunity for our global C&I product category. As we continue to ramp our capabilities for large megawatt generators, we believe that we are well positioned to take share in this market over time given our historical focus on backup power generation which allows us to provide customized sales, engineering, and aftermarket support while also providing data center customers with a robust service network to ensure uptime for these critical applications. Additionally, we believe this significant growth in data center power consumption will drive demand for backup power and intelligent energy management solutions for the broader electrical grid and other grid participants as these large power loads contribute to the growing power supply/demand imbalance.

[0001437749-25-033048:mdna:28]
[same as prior period, unchanged from 0001437749-25-024879:mdna:29]

[0001437749-25-033048:mdna:29]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators, energy storage systems, and energy management devices. Trends in interest rates and the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. The existence, or lack thereof, of renewable energy mandates, investment tax credits, and other subsidies can also have an impact on the demand for solar and energy storage systems.

[0001437749-25-033048:mdna:30]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the build out of data centers, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our C&I products. The capital investment cycle may differ for the various C&I end markets that we serve, including light commercial, retail, office, telecommunications, rental, industrial, data centers, healthcare, construction, oil & gas, and municipal infrastructure, among others. The market for these products is also affected by general economic conditions, fluctuations in interest rates, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-25-033048:mdna:31]
[same as prior period, unchanged from 0001437749-25-024879:mdna:32]

[0001437749-25-033048:mdna:32]
[same as prior period, unchanged from 0001437749-25-024879:mdna:33]

[0001437749-25-033048:mdna:33]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions over the years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-25-033048:mdna:34]
[same as prior period, unchanged from 0001437749-25-024879:mdna:35]

[0001437749-25-033048:mdna:35]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter, and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-25-033048:mdna:36]
[same as prior period, unchanged from 0001437749-25-024879:mdna:37]

[0001437749-25-033048:mdna:37]
[same as prior period, unchanged from 0001437749-25-024879:mdna:38]

[0001437749-25-033048:mdna:38]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for further information. The year-over-year decrease in interest expense in the current period was primarily driven by lower borrowings and lower interest rates compared to the prior year period.

[0001437749-25-033048:mdna:39]
[same as prior period, unchanged from 0001437749-25-024879:mdna:40]

[0001437749-25-033048:mdna:40]
The effective income tax rates for the nine months ended September 30, 2025 and 2024 were 18.3% and 24.6%, respectively. The decrease in the effective tax rate for the current period was primarily attributable to discrete tax benefits, including those related to a business disposition, as well as certain return-to-provision adjustments in the current year.

[0001437749-25-033048:mdna:41]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to implement the Pillar Two rules and evaluate their potential impact on future periods. There was no impact to our financial results for the three or nine months ended September 30, 2025, and we do not expect the rules to have a material impact on our effective tax rate for the remainder of the year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-25-033048:mdna:42]
On July 4, 2025, the United States signed the “One Big Beautiful Bill Act” (OBBBA) into law. This legislation makes permanent several key provisions of the Tax Cuts and Jobs Act, including 100% bonus depreciation and the immediate expensing of domestic research and development costs. Under ASC 740, “Income Taxes,” the effects of changes in tax laws are reflected in the Company’s financial statements in the quarter in which the legislation was passed.  We expect to realize cash tax savings during 2025 as a result of provisions related to bonus depreciation and domestic research and development expensing. These changes did not have a material impact on our effective income tax rate for the third quarter or the estimated annual effective tax rate for 2025 as the changes relate to temporary differences in basis.

[0001437749-25-033048:mdna:43]
[same as prior period, unchanged from 0001437749-25-024879:mdna:44]

[0001437749-25-033048:mdna:44]
Three months ended September 30, 2025, compared to the three months ended September 30, 2024

[0001437749-25-033048:mdna:45]
[same as prior period, unchanged from 0001437749-25-024879:mdna:46]

[0001437749-25-033048:mdna:46]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | (59,210 | ) |  |  | -5.0 | % |
| Costs of goods sold |  |  | 687,431 |  |  |  | 701,294 |  |  |  | (13,863 | ) |  |  | -2.0 | % |
| Gross profit |  |  | 426,922 |  |  |  | 472,269 |  |  |  | (45,347 | ) |  |  | -9.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 145,104 |  |  |  | 145,310 |  |  |  | (206 | ) |  |  | -0.1 | % |
| Research and development |  |  | 60,059 |  |  |  | 56,936 |  |  |  | 3,123 |  |  |  | 5.5 | % |
| General and administrative |  |  | 93,748 |  |  |  | 77,242 |  |  |  | 16,506 |  |  |  | 21.4 | % |
| Amortization of intangible assets |  |  | 24,932 |  |  |  | 24,157 |  |  |  | 775 |  |  |  | 3.2 | % |
| Total operating expenses |  |  | 323,843 |  |  |  | 303,645 |  |  |  | 20,198 |  |  |  | 6.7 | % |
| Income from operations |  |  | 103,079 |  |  |  | 168,624 |  |  |  | (65,545 | ) |  |  | -38.9 | % |
| Total other expense, net |  |  | (24,741 | ) |  |  | (21,393 | ) |  |  | (3,348 | ) |  |  | -15.6 | % |
| Income before provision for income taxes |  |  | 78,338 |  |  |  | 147,231 |  |  |  | (68,893 | ) |  |  | -46.8 | % |
| Provision for income taxes |  |  | 11,758 |  |  |  | 33,453 |  |  |  | (21,695 | ) |  |  | -64.9 | % |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | (47,198 | ) |  |  | -41.5 | % |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 383 |  |  |  | 1063.9 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | (47,581 | ) |  |  | -41.8 | % |

[0001437749-25-033048:mdna:47]
[same as prior period, unchanged from 0001437749-25-024879:mdna:48]

[0001437749-25-033048:mdna:48]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 933,646 |  |  | $ | 1,011,347 |  |  | $ | (77,701 | ) |  |  | -7.7 | % |
| International |  |  | 180,707 |  |  |  | 162,216 |  |  |  | 18,491 |  |  |  | 11.4 | % |
| Total net sales |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | (59,210 | ) |  |  | -5.0 | % |

[0001437749-25-033048:mdna:49]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2025 |  |  | Three Months Ended September 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 933,646 |  |  | $ | 4,494 |  |  | $ | 938,140 |  |  | $ | 1,011,347 |  |  | $ | 8,853 |  |  | $ | 1,020,200 |  |
| International |  |  | 180,707 |  |  |  | 4,784 |  |  |  | 185,491 |  |  |  | 162,216 |  |  |  | 4,485 |  |  |  | 166,701 |  |
| Intercompany elimination |  |  | - |  |  |  | (9,278 | ) |  |  | (9,278 | ) |  |  | - |  |  |  | (13,338 | ) |  |  | (13,338 | ) |
| Total net sales |  | $ | 1,114,353 |  |  | $ | - |  |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | - |  |  | $ | 1,173,563 |  |

[0001437749-25-033048:mdna:50]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 165,827 |  |  | $ | 211,567 |  |  | $ | (45,740 | ) |  |  | -21.6 | % |
| International |  |  | 27,388 |  |  |  | 20,298 |  |  |  | 7,090 |  |  |  | 34.9 | % |
| Total Adjusted EBITDA |  | $ | 193,215 |  |  | $ | 231,865 |  |  | $ | (38,650 | ) |  |  | -16.7 | % |

[0001437749-25-033048:mdna:51]
[same as prior period, unchanged from 0001437749-25-024879:mdna:52]

[0001437749-25-033048:mdna:52]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 626,706 |  |  | $ | 722,787 |  |  | $ | (96,081 | ) |  |  | -13.3 | % |
| Commercial & industrial products |  |  | 358,273 |  |  |  | 327,956 |  |  |  | 30,317 |  |  |  | 9.2 | % |
| Other |  |  | 129,374 |  |  |  | 122,820 |  |  |  | 6,554 |  |  |  | 5.3 | % |
| Total net sales |  | $ | 1,114,353 |  |  | $ | 1,173,563 |  |  | $ | (59,210 | ) |  |  | -5.0 | % |

[0001437749-25-033048:mdna:53]
Net sales.   Domestic segment total sales (including inter-segment sales) decreased approximately 8% to $938.1 million as compared to $1.02 billion in the prior year, including an approximate 1% benefit from acquisitions. The total sales decrease was primarily driven by weaker home standby and portable generator sales as a result of the significantly lower power outage environment in the current year quarter together with a strong prior year comparison which included multiple major landed hurricanes. This was partially offset by robust growth in residential energy technology shipments and an increase in C&I product sales to the telecom and industrial distributor channels.

[0001437749-25-033048:mdna:54]
In addition, total contribution from non-annualized acquisitions for the third quarter of 2025 was $10.7 million for the domestic segment.

[0001437749-25-033048:mdna:55]
International segment total sales (including inter-segment sales) increased approximately 11% to $185.5 million from $166.7 million in the prior year quarter, including an approximate 3% favorable impact from foreign currency. Sales growth for the segment was primarily driven by strength in C&I product shipments to European markets as well as initial shipments of large-megawatt generators to data center customers.

[0001437749-25-033048:mdna:56]
Gross profit.   Gross profit margin was 38.3% as compared to 40.2% in the prior-year third quarter. The decrease in gross margin was primarily due to unfavorable sales mix together with the impact of higher tariffs and lower manufacturing absorption, partially offset by increased price realization.

[0001437749-25-033048:mdna:57]
Operating Expenses.   Operating expenses increased $20.2 million, or 6.7%, as compared to the third quarter of 2024 primarily due to a $20.8 million increase in legal and regulatory charges and settlements, as disclosed in the accompanying non-GAAP measures reconciliation schedules.

[0001437749-25-033048:mdna:58]
Other Expense.   The increase in other expense, net was driven primarily by a $5.7 million loss on the change in fair value of our investment in warrants and equity securities of Wallbox N.V. and a $1.2 million loss on the modification of our Original Tranche A Term Loan Facility and Original Revolving Facility.  This was partially offset by a decrease in interest expense compared to the prior year.

[0001437749-25-033048:mdna:59]
Provision for income taxes.   Provision for income taxes for the current year quarter was $11.8 million, or an effective tax rate of 15.0%, as compared to $33.5 million, or a 22.7% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by favorable discrete tax items in the current-year quarter related to certain return-to-provision adjustments that did not occur in the prior year.

[0001437749-25-033048:mdna:60]
Net income attributable to Generac Holdings Inc.   Net income attributable to the Company during the third quarter was $66 million, as compared to $114 million for the same period of 2024.  This decrease was primarily driven by the factors outlined above.

[0001437749-25-033048:mdna:61]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment was $165.8 million, or 17.7% of domestic segment total sales, as compared to $211.6 million, or 20.7% of total sales, in the prior year. This decline was primarily driven by unfavorable sales mix together with the impact of incremental tariffs and operating deleverage on lower sales volumes, partially offset by increased price realization.

[0001437749-25-033048:mdna:62]
Adjusted EBITDA for the international segment, before deducting for noncontrolling interests, was $27.4 million, or 14.8% of international segment total sales, as compared to $20.3 million, or 12.2% of total sales, in the prior year. This margin increase was primarily driven by favorable sales mix.

[0001437749-25-033048:mdna:63]
Adjusted Net Income.   Adjusted net income attributable to the Company, as defined in the accompanying non-GAAP measures reconciliation schedules, was $108 million in the current year third quarter as compared to $136 million in the prior-year. This decrease was primarily driven by lower net income in the current period as outlined above together with changes in certain add-back items.

[0001437749-25-033048:mdna:64]
[same as prior period, unchanged from 0001437749-25-024879:mdna:65]

[0001437749-25-033048:mdna:65]
[same as prior period, unchanged from 0001437749-25-024879:mdna:66]

[0001437749-25-033048:mdna:66]
Nine months ended September 30, 2025, compared to the nine months ended September 30, 2024

[0001437749-25-033048:mdna:67]
[same as prior period, unchanged from 0001437749-25-024879:mdna:68]

[0001437749-25-033048:mdna:68]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |  | $ | 56,610 |  |  |  | 1.8 | % |
| Costs of goods sold |  |  | 1,901,986 |  |  |  | 1,896,824 |  |  |  | 5,162 |  |  |  | 0.3 | % |
| Gross profit |  |  | 1,215,657 |  |  |  | 1,164,209 |  |  |  | 51,448 |  |  |  | 4.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 410,664 |  |  |  | 382,049 |  |  |  | 28,615 |  |  |  | 7.5 | % |
| Research and development |  |  | 182,461 |  |  |  | 160,342 |  |  |  | 22,119 |  |  |  | 13.8 | % |
| General and administrative |  |  | 247,924 |  |  |  | 209,392 |  |  |  | 38,532 |  |  |  | 18.4 | % |
| Amortization of intangible assets |  |  | 76,102 |  |  |  | 73,698 |  |  |  | 2,404 |  |  |  | 3.3 | % |
| Total operating expenses |  |  | 917,151 |  |  |  | 825,481 |  |  |  | 91,670 |  |  |  | 11.1 | % |
| Income from operations |  |  | 298,506 |  |  |  | 338,728 |  |  |  | (40,222 | ) |  |  | -11.9 | % |
| Total other expense, net |  |  | (71,802 | ) |  |  | (74,295 | ) |  |  | 2,493 |  |  |  | 3.4 | % |
| Income before provision for income taxes |  |  | 226,704 |  |  |  | 264,433 |  |  |  | (37,729 | ) |  |  | -14.3 | % |
| Provision for income taxes |  |  | 41,416 |  |  |  | 65,124 |  |  |  | (23,708 | ) |  |  | -36.4 | % |
| Net income |  |  | 185,288 |  |  |  | 199,309 |  |  |  | (14,021 | ) |  |  | -7.0 | % |
| Net income attributable to noncontrolling interests |  |  | 1,271 |  |  |  | 220 |  |  |  | 1,051 |  |  |  | 477.7 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 184,017 |  |  | $ | 199,089 |  |  | $ | (15,072 | ) |  |  | -7.6 | % |

[0001437749-25-033048:mdna:69]
[same as prior period, unchanged from 0001437749-25-024879:mdna:70]

[0001437749-25-033048:mdna:70]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,586,519 |  |  | $ | 2,541,242 |  |  | $ | 45,277 |  |  |  | 1.8 | % |
| International |  |  | 531,124 |  |  |  | 519,791 |  |  |  | 11,333 |  |  |  | 2.2 | % |
| Total net sales |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |  | $ | 56,610 |  |  |  | 1.8 | % |

[0001437749-25-033048:mdna:71]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2025 |  |  | Nine Months Ended September 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,586,519 |  |  | $ | 18,418 |  |  | $ | 2,604,937 |  |  | $ | 2,541,242 |  |  | $ | 26,571 |  |  | $ | 2,567,813 |  |
| International |  |  | 531,124 |  |  |  | 37,113 |  |  |  | 568,237 |  |  |  | 519,791 |  |  |  | 18,127 |  |  |  | 537,918 |  |
| Intercompany elimination |  |  | - |  |  |  | (55,531 | ) |  |  | (55,531 | ) |  |  | - |  |  |  | (44,698 | ) |  |  | (44,698 | ) |
| Total net sales |  | $ | 3,117,643 |  |  | $ | - |  |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |  | $ | - |  |  | $ | 3,061,033 |  |

[0001437749-25-033048:mdna:72]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 446,456 |  |  | $ | 450,416 |  |  | $ | (3,960 | ) |  |  | -0.9 | % |
| International |  |  | 83,934 |  |  |  | 73,371 |  |  |  | 10,563 |  |  |  | 14.4 | % |
| Total Adjusted EBITDA |  | $ | 530,390 |  |  | $ | 523,787 |  |  | $ | 6,603 |  |  |  | 1.3 | % |

[0001437749-25-033048:mdna:73]
[same as prior period, unchanged from 0001437749-25-024879:mdna:74]

[0001437749-25-033048:mdna:74]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,695,046 |  |  | $ | 1,690,136 |  |  | $ | 4,910 |  |  |  | 0.3 | % |
| Commercial & industrial products |  |  | 1,057,849 |  |  |  | 1,026,095 |  |  |  | 31,754 |  |  |  | 3.1 | % |
| Other |  |  | 364,748 |  |  |  | 344,802 |  |  |  | 19,946 |  |  |  | 5.8 | % |
| Total net sales |  | $ | 3,117,643 |  |  | $ | 3,061,033 |  |  | $ | 56,610 |  |  |  | 1.8 | % |

[0001437749-25-033048:mdna:75]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 1.4% to $2,604.9 million in the nine months ended September 30, 2025, as compared to $2,567.8 million in the prior-year comparable period, including an approximately 1% benefit from acquisitions. This slight increase was primarily driven by higher sales of energy technology solutions, as well as growth in C&I product shipments to national telecom customers and industrial distributors. This growth was partially offset by lower home standby and portable generator sales as a result of a significantly lower power outage environment as well as lower C&I product sales to national rental accounts.

[0001437749-25-033048:mdna:76]
In addition, total contribution from non-annualized acquisitions for the nine months ended September 30, 2025 was $28.1 million for the domestic segment.

[0001437749-25-033048:mdna:77]
International segment total sales (including inter-segment sales) increased to $568.2 million in the nine months ended September 30, 2025, as compared to $537.9 million in the prior-year comparable period, including an approximate 1% unfavorable impact from foreign currency. Excluding the impact of foreign currency, the total sales growth for the segment was primarily driven by higher inter-segment sales to the U.S. market, stronger product sales in Europe, and initial shipments of large-megawatt generators to data center customers, partially offset by softer C&I shipments in other regions.

[0001437749-25-033048:mdna:78]
Gross profit.   Gross profit margin for the nine months ended September 30, 2025 was 39.0%, as compared to 38.0% in the prior-year comparable period. The increase in gross margin was primarily driven by favorable price realization partially offset by unfavorable sales mix and the impact of higher tariffs.

[0001437749-25-033048:mdna:79]
Operating Expenses.   Operating expenses for the nine months ended September 30, 2025 increased $91.7 million, or 11.1%, as compared to the prior-year comparable period. The growth in operating expenses was primarily driven by increased employee costs to support future growth across the business, higher variable costs, increased marketing spend, and certain legal and regulatory charges and settlements in the current year, as disclosed in the accompanying non-GAAP measures reconciliation schedules.

[0001437749-25-033048:mdna:80]
Other Expense.   The decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings and lower interest rates compared to the prior-year comparable period. This was partially offset by a larger loss on the change in the fair value of the Company's investment in Wallbox N.V. shares and warrants, along with a pre-tax loss attributable to the sale of our immaterial Tank Utility fleet business during the second quarter of 2025.

[0001437749-25-033048:mdna:81]
Provision for income taxes.   Provision for income taxes for the nine months ended September 30, 2025 was $41.4 million, or an effective tax rate of 18.3%, as compared to $65.1 million, or a 24.6% effective tax rate, for the prior-year comparable period.  The decrease in effective tax rate was primarily due to favorable discrete tax benefits related to the sale of our immaterial Tank Utility fleet business and certain favorable return-to-provision adjustments in the current year period that did not occur in the previous year.

[0001437749-25-033048:mdna:82]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the nine months ended September 30, 2025 was $184.0 million compared to $199.1 million in the prior-year comparable period. This decrease was primarily driven by the factors outlined above.

[0001437749-25-033048:mdna:83]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the nine months ended September 30, 2025 was $446.5 million, or 17.1% of domestic segment total sales, as compared to $450.4 million, or 17.5% of total sales, in the prior-year comparable period. This decline was primarily driven by unfavorable sales mix together with the impact of incremental tariffs and higher operating expenses, partially offset by increased price realization.

[0001437749-25-033048:mdna:84]
Adjusted EBITDA for the international segment in the nine months ended September 30, 2025, before deducting for non-controlling interests, was $83.9 million, or 14.8% of international segment total sales, as compared to $73.4 million, or 13.6% of total sales, in the prior-year comparable period. This margin increase was primarily driven by favorable price and cost impacts during the current year period.

[0001437749-25-033048:mdna:85]
Adjusted Net Income.   Adjusted Net Income in the nine months ended September 30, 2025 was $281.1 million compared to $270.2 million in the prior-year comparable period. This increase was primarily driven by changes in certain add-back items, including certain items for legal, regulatory, and other charges, and changes in fair value of investments, partially offset by lower net income in the current period as outlined above.

[0001437749-25-033048:mdna:86]
[same as prior period, unchanged from 0001437749-25-024879:mdna:87]

[0001437749-25-033048:mdna:87]
[same as prior period, unchanged from 0001437749-25-024879:mdna:88]

[0001437749-25-033048:mdna:88]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-25-033048:mdna:89]
On July 1, 2025, we amended our Original Tranche A Term Loan Facility and Original Revolving Facility, extending the maturity of both to July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700 million, reducing the Original Revolving Facility borrowing capacity to $1 billion and redefining the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit agreement), resulting in an interest rate reduction of 0.10%.  The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on October 1, 2026.   The New Tranche A Term Loan Facility and the New Revolving Facility bear interest at a rate based on SOFR plus an applicable margin between 1.25% and 1.75%, both based on our total leverage ratio and subject to a SOFR floor of 0.0%.  As of September 30, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 5.78%.

[0001437749-25-033048:mdna:90]
In accordance with ASC 470-50, we capitalized $5.3 million of debt issuance costs related to this refinancing transaction. Additionally, we wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of $0.4 million and expensed $0.8 million of third-party fees as a loss on refinancing of debt.

[0001437749-25-033048:mdna:91]
As of September 30, 2025, there was $495 million outstanding under the Term Loan B Facility, $700 million outstanding under the New Tranche A Term Loan Facility, and $90.0 million of borrowings on the New Revolving Facility, leaving $909.3 million of unused capacity, net of outstanding letters of credit.

[0001437749-25-033048:mdna:92]
The Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of September 30, 2025, the interest rate for the Term Loan B Facility is 6.03%. The Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the Term Loan B Facility credit agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of September 30, 2025, our net secured leverage ratio was 1.35 to 1.00, and we were in compliance with all covenants of the Facility. There are no financial maintenance covenants on the Term Loan B Facility. The New Tranche A Term Loan Facility and the New Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of September 30, 2025, our total leverage ratio was 1.41 to 1.00, and our interest coverage ratio was 12.54 to 1.00. We were also in compliance with all other covenants of the New Credit Agreements as of September 30, 2025.

[0001437749-25-033048:mdna:93]
In July 2022, our Board of Directors approved a stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaced the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. As of September 30, 2025, the remaining unused buyback authorization under the current program was $199.3 million.

[0001437749-25-033048:mdna:94]
During the three and nine months ended September 30, 2025, we repurchased 0 and 1,109,206 shares of common stock for $0 and $147.9 million, respectively. During the three and nine months ended September 30, 2024, we repurchased 690,711 and 1,046,351 shares of common stock for $102.1 million and $152.7 million, respectively. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-25-033048:mdna:95]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-25-033048:mdna:96]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 13% and 12% of net sales for the nine months ended September 30, 2025, and 2024, respectively. The amount financed by dealers which remained outstanding under this arrangement was $165.2 million and $165.4 million as of September 30, 2025, and December 31, 2024, respectively.

[0001437749-25-033048:mdna:97]
[same as prior period, unchanged from 0001437749-25-024879:mdna:98]

[0001437749-25-033048:mdna:98]
As of September 30, 2025, we had total liquidity of $1,209.3 million which consists of $300.0 million of cash and cash equivalents and $909.3 million of availability under our New Revolving Facility.

[0001437749-25-033048:mdna:99]
We believe our cash and cash equivalents, cash flow from operations, and availability under our New Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other activities that could potentially drive incremental shareholder value.

[0001437749-25-033048:mdna:100]
[same as prior period, unchanged from 0001437749-25-024879:mdna:100]

[0001437749-25-033048:mdna:101]
Nine months ended September 30, 2025, compared to the nine months ended September 30, 2024

[0001437749-25-033048:mdna:102]
[same as prior period, unchanged from 0001437749-25-024879:mdna:102]

[0001437749-25-033048:mdna:103]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 248,719 |  |  | $ | 401,847 |  |  | $ | (153,128 | ) |  |  | -38.1 | % |
| Net cash used in investing activities |  |  | (115,533 | ) |  |  | (141,786 | ) |  |  | 26,253 |  |  |  | 18.5 | % |
| Net cash used in financing activities |  |  | (121,294 | ) |  |  | (246,567 | ) |  |  | 125,273 |  |  |  | 50.8 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 6,840 |  |  |  | (311 | ) |  |  | 7,151 |  |  |  | 2299.4 | % |
| Net increase in cash and cash equivalents |  | $ | 18,732 |  |  | $ | 13,183 |  |  | $ | 5,549 |  |  |  | 42.1 | % |

[0001437749-25-033048:mdna:104]
The decrease in operating cash flows for the nine months ended September 30, 2025 was primarily driven by an increase in inventory levels during the current year and lower operating income, which was compounded by a decline in inventory levels during the prior year period.

[0001437749-25-033048:mdna:105]
The $115.5 million net cash used in investing activities for the nine months ended September 30, 2025 primarily represents cash payments of $110.5 million related to the purchase of property and equipment, $3.0 million for the purchase of long-term investments, and $2.0 million related to other investing activities.

[0001437749-25-033048:mdna:106]
The $141.8 million net cash used in investing activities for the nine months ended September 30, 2024 primarily represents cash payments of $83.4 million related to the purchase of property and equipment, $21.8 million for the acquisitions of Huntington, C&I BESS, and Ageto, $1.6 million for a tax equity investment, and $35 million for an incremental minority investment in Wallbox.

[0001437749-25-033048:mdna:107]
The $121.3 million net cash used in financing activities for the nine months ended September 30, 2025 primarily represents proceeds of $30.9 million from short-term borrowings, $134.7 million from long-term borrowings, $1.0 million of contributions received from the noncontrolling interest holder of a subsidiary, and $4.2 million from the exercise of stock options. These cash proceeds were more than offset by $123.0 million of debt repayments ($47.3 million of short-term borrowings and $75.7 million of long-term borrowings and finance lease obligations), $147.9 million of share repurchases, $5.3 million of debt issuance costs, $2.7 million payment of contingent acquisition consideration, and $12.9 million for taxes paid related to equity awards.

[0001437749-25-033048:mdna:108]
The $246.6 million net cash used in financing activities for the nine months ended September 30, 2024 primarily represents proceeds of $29.2 million from short-term borrowings, $506.5 million from long-term borrowings, and $12.3 million from the exercise of stock options. These cash proceeds were more than offset by $609.5 million of debt repayments ($48.9 million of short-term borrowings and $560.6 million of long-term borrowings and finance lease obligations), $152.7 million of share repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment and $1.4 million payment of deferred acquisition consideration related to our Chilicon and Blue Pillar acquisitions, respectively, $12.3 million for taxes paid related to equity awards, and $3.6 million of payments for debt issuance costs related to our Tranche B Term Loan Facility refinancing.

[0001437749-25-033048:mdna:109]
[same as prior period, unchanged from 0001437749-25-024879:mdna:109]

[0001437749-25-033048:mdna:110]
There have been no material changes to our contractual obligations between the February 19, 2025, filing of our Annual Report on Form 10-K for the year ended December 31, 2024, and September 30, 2025, except for the changes in outstanding borrowings and interest rates as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-25-033048:mdna:111]
[same as prior period, unchanged from 0001437749-25-024879:mdna:111]

[0001437749-25-033048:mdna:112]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2024, in preparing the financial statements in accordance with GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes.

[0001437749-25-033048:mdna:113]
[same as prior period, unchanged from 0001437749-25-024879:mdna:113]

[0001437749-25-033048:mdna:114]
[same as prior period, unchanged from 0001437749-25-024879:mdna:114]

[0001437749-25-033048:mdna:115]
[same as prior period, unchanged from 0001437749-25-024879:mdna:115]

[0001437749-25-033048:mdna:116]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are not part of the ordinary routine litigation or regulatory matters incidental to the Company's business, including but not limited to class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our New and Prior Credit Agreements.

[0001437749-25-033048:mdna:117]
[same as prior period, unchanged from 0001437749-25-024879:mdna:117]

[0001437749-25-033048:mdna:118]
[same as prior period, unchanged from 0001437749-25-024879:mdna:118]

[0001437749-25-033048:mdna:119]
[same as prior period, unchanged from 0001437749-25-024879:mdna:119]

[0001437749-25-033048:mdna:120]
[same as prior period, unchanged from 0001437749-25-024879:mdna:120]

[0001437749-25-033048:mdna:121]
[same as prior period, unchanged from 0001437749-25-024879:mdna:121]

[0001437749-25-033048:mdna:122]
[same as prior period, unchanged from 0001437749-25-024879:mdna:122]

[0001437749-25-033048:mdna:123]
[same as prior period, unchanged from 0001437749-25-024879:mdna:123]

[0001437749-25-033048:mdna:124]
[same as prior period, unchanged from 0001437749-25-024879:mdna:124]

[0001437749-25-033048:mdna:125]
[same as prior period, unchanged from 0001437749-25-024879:mdna:125]

[0001437749-25-033048:mdna:126]
[same as prior period, unchanged from 0001437749-25-024879:mdna:126]

[0001437749-25-033048:mdna:127]
[same as prior period, unchanged from 0001437749-25-024879:mdna:127]

[0001437749-25-033048:mdna:128]
[same as prior period, unchanged from 0001437749-25-024879:mdna:128]

[0001437749-25-033048:mdna:129]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; |

[0001437749-25-033048:mdna:130]
|  | • | are non-cash in nature, such as share-based compensation; or |
|  | • | the provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, including but not limited to large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. |

[0001437749-25-033048:mdna:131]
We explain in more detail in the footnotes to the table below, why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-25-033048:mdna:132]
[same as prior period, unchanged from 0001437749-25-024879:mdna:132]

[0001437749-25-033048:mdna:133]
[same as prior period, unchanged from 0001437749-25-024879:mdna:133]

[0001437749-25-033048:mdna:134]
[same as prior period, unchanged from 0001437749-25-024879:mdna:134]

[0001437749-25-033048:mdna:135]
[same as prior period, unchanged from 0001437749-25-024879:mdna:135]

[0001437749-25-033048:mdna:136]
[same as prior period, unchanged from 0001437749-25-024879:mdna:136]

[0001437749-25-033048:mdna:137]
[same as prior period, unchanged from 0001437749-25-024879:mdna:137]

[0001437749-25-033048:mdna:138]
[same as prior period, unchanged from 0001437749-25-024879:mdna:138]

[0001437749-25-033048:mdna:139]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our New and Prior Credit Agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-25-033048:mdna:140]
[same as prior period, unchanged from 0001437749-25-024879:mdna:141]

[0001437749-25-033048:mdna:141]
[same as prior period, unchanged from 0001437749-25-024879:mdna:142]

[0001437749-25-033048:mdna:142]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 199,089 |  |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | 185,288 |  |  |  | 199,309 |  |
| Interest expense |  |  | 18,461 |  |  |  | 22,910 |  |  |  | 53,813 |  |  |  | 69,833 |  |
| Depreciation and amortization |  |  | 49,211 |  |  |  | 43,152 |  |  |  | 143,673 |  |  |  | 127,934 |  |
| Provision for income taxes |  |  | 11,758 |  |  |  | 33,453 |  |  |  | 41,416 |  |  |  | 65,124 |  |
| Non-cash write-down and other adjustments (a) |  |  | 2,831 |  |  |  | 468 |  |  |  | 4,973 |  |  |  | 2,863 |  |
| Non-cash share-based compensation expense (b) |  |  | 12,751 |  |  |  | 13,115 |  |  |  | 39,111 |  |  |  | 38,270 |  |
| Transaction costs and credit facility fees (c) |  |  | 827 |  |  |  | 1,337 |  |  |  | 2,591 |  |  |  | 4,029 |  |
| Business optimization and other charges (d) |  |  | 368 |  |  |  | 1,564 |  |  |  | 5,385 |  |  |  | 3,190 |  |
| Provision for legal, regulatory, and other costs (e) |  |  | 23,208 |  |  |  | 2,382 |  |  |  | 31,870 |  |  |  | 5,280 |  |
| Change in fair value of investments (f) |  |  | 5,667 |  |  |  | (5,198 | ) |  |  | 17,138 |  |  |  | 2,938 |  |
| Loss on refinancing of debt (g) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Other (h) |  |  | 328 |  |  |  | 43 |  |  |  | 3,907 |  |  |  | 156 |  |
| Adjusted EBITDA |  |  | 193,215 |  |  |  | 231,865 |  |  |  | 530,390 |  |  |  | 523,787 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 655 |  |  |  | 81 |  |  |  | 1,899 |  |  |  | 521 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 192,560 |  |  | $ | 231,784 |  |  | $ | 528,491 |  |  | $ | 523,266 |  |

[0001437749-25-033048:mdna:143]
[same as prior period, unchanged from 0001437749-25-024879:mdna:144]

[0001437749-25-033048:mdna:144]
[same as prior period, unchanged from 0001437749-25-024879:mdna:145]

[0001437749-25-033048:mdna:145]
[same as prior period, unchanged from 0001437749-25-024879:mdna:146]

[0001437749-25-033048:mdna:146]
[same as prior period, unchanged from 0001437749-25-024879:mdna:147]

[0001437749-25-033048:mdna:147]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Prior and New Credit Agreement.

[0001437749-25-033048:mdna:148]
[same as prior period, unchanged from 0001437749-25-024879:mdna:149]

[0001437749-25-033048:mdna:149]
(e)  Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-033048:mdna:150]
•  A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $2.7 million and $5.9 million for the three and nine months ended September 30, 2025, respectively, and $2.4 million and $4.9 million for the three and nine months ended September 30, 2024, respectively.
 •  A provision for a $15.0 million multi-district class action settlement related to clean energy products and legal expenses related to certain class action lawsuits - $17.8 million and $21.6 million for the three and nine months ended September 30, 2025, respectively.
 •  Legal expenses related to certain government inquiries and other significant matters - $2.7 million and $4.3 million for the three and nine months ended September 30, 2025, respectively.
 •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 –$0 and $0.4 million for the three and nine months ended September 30, 2024, respectively.

[0001437749-25-033048:mdna:151]
(f)  Represents non-cash gains and losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-033048:mdna:152]
(g)  For the three and nine months ended September 20, 2025, the loss represents third-party costs and the write-off of certain deferred financing costs in connection with the refinancing of the Original Tranche A Term Loan Facility and Original Revolving Facility. For the three and nine months ended September 30, 2024, the loss represents fees paid to creditors and the write-off of the original issue discount and deferred financing costs in connection with the refinancing of the Tranche B Term Loan Facility.

[0001437749-25-033048:mdna:153]
(h)  The pre-tax loss in the nine months ended September 30, 2025, relates primarily to the sale of our immaterial Tank Utility fleet business during the second quarter of 2025.

[0001437749-25-033048:mdna:154]
[same as prior period, unchanged from 0001437749-25-024879:mdna:154]

[0001437749-25-033048:mdna:155]
[same as prior period, unchanged from 0001437749-25-024879:mdna:155]

[0001437749-25-033048:mdna:156]
[same as prior period, unchanged from 0001437749-25-024879:mdna:156]

[0001437749-25-033048:mdna:157]
[same as prior period, unchanged from 0001437749-25-024879:mdna:157]

[0001437749-25-033048:mdna:158]
[same as prior period, unchanged from 0001437749-25-024879:mdna:158]

[0001437749-25-033048:mdna:159]
[same as prior period, unchanged from 0001437749-25-024879:mdna:159]

[0001437749-25-033048:mdna:160]
[same as prior period, unchanged from 0001437749-25-024879:mdna:160]

[0001437749-25-033048:mdna:161]
[same as prior period, unchanged from 0001437749-25-024879:mdna:161]

[0001437749-25-033048:mdna:162]
[same as prior period, unchanged from 0001437749-25-024879:mdna:162]

[0001437749-25-033048:mdna:163]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,161 |  |  | $ | 113,742 |  |  | $ | 184,017 |  |  | $ | 199,089 |  |
| Net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Net income |  |  | 66,580 |  |  |  | 113,778 |  |  |  | 185,288 |  |  |  | 199,309 |  |
| Amortization of intangible assets |  |  | 24,932 |  |  |  | 24,157 |  |  |  | 76,102 |  |  |  | 73,698 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 557 |  |  |  | 644 |  |  |  | 1,835 |  |  |  | 2,592 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 204 |  |  |  | 747 |  |  |  | 656 |  |  |  | 2,272 |  |
| Loss (gain) attributable to business or asset dispositions (c) |  |  | - |  |  |  | - |  |  |  | 4,295 |  |  |  | 65 |  |
| Business optimization and other charges (b) |  |  | 368 |  |  |  | 1,564 |  |  |  | 5,385 |  |  |  | 3,190 |  |
| Provision for legal, regulatory, and other costs (b) |  |  | 23,208 |  |  |  | 2,382 |  |  |  | 31,870 |  |  |  | 5,280 |  |
| Change in fair value of investments (b) |  |  | 5,667 |  |  |  | (5,198 | ) |  |  | 17,138 |  |  |  | 2,938 |  |
| Loss on refinancing of debt (b) |  |  | 1,225 |  |  |  | 4,861 |  |  |  | 1,225 |  |  |  | 4,861 |  |
| Tax effect of add backs |  |  | (13,900 | ) |  |  | (7,317 | ) |  |  | (41,407 | ) |  |  | (23,762 | ) |
| Adjusted net income |  |  | 108,841 |  |  |  | 135,618 |  |  |  | 282,387 |  |  |  | 270,443 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 419 |  |  |  | 36 |  |  |  | 1,271 |  |  |  | 220 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 108,422 |  |  | $ | 135,582 |  |  | $ | 281,116 |  |  | $ | 270,223 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.83 |  |  | $ | 2.25 |  |  | $ | 4.74 |  |  | $ | 4.47 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,122,849 |  |  |  | 60,312,393 |  |  |  | 59,314,618 |  |  |  | 60,475,478 |  |

[0001437749-25-033048:mdna:164]
[same as prior period, unchanged from 0001437749-25-024879:mdna:164]

[0001437749-25-033048:mdna:165]
[same as prior period, unchanged from 0001437749-25-024879:mdna:165]

[0001437749-25-033048:mdna:166]
(c) The pre-tax loss in the nine months ended September 30, 2025, relates primarily to the sale of our immaterial Tank Utility fleet business during the second quarter of 2025.

[0001437749-25-033048:mdna:167]
[same as prior period, unchanged from 0001437749-25-024879:mdna:167]

[0001437749-25-033048:mdna:168]
[same as prior period, unchanged from 0001437749-25-024879:mdna:168]
