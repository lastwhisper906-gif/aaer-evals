# GNRC note change history — 0001437749-25-024879 → 0001437749-25-033048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001437749-25-033048:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase Generac products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  September 30, 2025, and  December 31, 2024, was $165,200 and $165,432, respectively.
  (was, 2025-08-05, similarity 0.6251):
[0001437749-25-024879:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  June 30, 2025, and  December 31, 2024, was $167,176 and $165,432, respectively.

- changed (2025-11-04):
[0001437749-25-033048:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.
  (was, 2025-08-05, similarity 0.9992):
[0001437749-25-024879:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

- changed (2025-11-04):
[0001437749-25-033048:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and plaintiffs participated in a mediation through which the parties agreed to certain monetary and non-monetary terms to resolve the matter on a classwide basis.  The parties will seek court approval for the classwide settlement and Generac Power has reserved for the contemplated $15,000 settlement fund. Generac Power does not concede liability or any charges of wrongdoing in connection with the proposed settlement.
  (was, 2025-08-05, similarity 0.7295):
[0001437749-25-024879:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- changed (2025-11-04):
[0001437749-25-033048:note_history:4]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020.  On  October 3, 2025, the Company received notice from the EPA that it would seek to void certain emissions certifications for 2020, affecting approximately 4,850 (not in thousands) additional portable generators as the Company previously disclosed in Note 18, “Commitments and Contingencies,” to its 2024 Annual Report on Form 10-K. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.
  (was, 2025-08-05, similarity 0.7491):
[0001437749-25-024879:note_history:4]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.

- changed (2025-11-04):
[0001437749-25-033048:note_history:5]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest and continues to accrue for post-judgment interest thereafter. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.
  (was, 2025-08-05, similarity 0.8367):
[0001437749-25-024879:note_history:5]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023, jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

- changed (2025-11-04):
[0001437749-25-033048:note_history:6]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims and Generac filed a counterclaim. On  August 18, 2025, Generac Power prevailed in the defense of Spartronics’ arbitration claims and substantially prevailed on its counterclaim seeking possession of pre-paid raw materials and owned tooling.  Generac Power also received an award of its legal fees in connection with the action.  The award is binding and not subject of an appeal.
  (was, 2025-08-05, similarity 0.7069):
[0001437749-25-024879:note_history:6]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics' purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

- changed (2025-11-04):
[0001437749-25-033048:note_history:7]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing. Generac Power intends to participate in a mediation in  January 2026 along with other parties and plaintiffs, in advance of a trial that is likely to occur on or after  April 2026.  Plaintiffs have not fully quantified their damages but will be seeking damages in excess of Generac Power’s available insurance. The Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.
  (was, 2025-08-05, similarity 0.6643):
[0001437749-25-024879:note_history:7]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing as the Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.

- changed (2025-11-04):
[0001437749-25-033048:note_history:8]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies.  Champion in turn filed new patent infringement claims relating to its own carbon monoxide detection and shutoff technology.  Generac Power denies the infringement allegations and intends to vigorously defend the matter.
  (was, 2025-08-05, similarity 0.9097):
[0001437749-25-024879:note_history:8]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies.  Champion intends to file new patent infringement claims against Generac Power pertaining to its own carbon monoxide detection and shutoff technology in response to Generac’s claims.  Generac Power denies the infringement allegations and intends to vigorously defend the matter.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001437749-25-033048:note_history:9]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, data & telecom, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2025-08-05, similarity 0.9871):
[0001437749-25-024879:note_history:9]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2025-11-04):
[0001437749-25-033048:note_history:10]
The condensed consolidated balance sheet as of  September 30, 2025, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2025-08-05, similarity 0.9033):
[0001437749-25-024879:note_history:10]
The condensed consolidated balance sheet as of  June 30, 2025, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2025-11-04):
[0001437749-25-033048:note_history:11]
New Accounting Pronouncements
  (was, 2025-08-05, similarity 0.7838):
[0001437749-25-024879:note_history:11]
New Accounting Pronouncements and Regulations

- added (2025-11-04):
[0001437749-25-033048:note_history:12]
In  September 2025, the FASB issued ASU 2025-06 Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40).  The update is intended to better align internal use software guidance with modern development methods, which have evolved to commonly include incremental and iterative development approaches.  The ASU requires an entity to start capitalizing software costs when management has authorized and committed to funding a software project and when it is probable the project will be completed and used to perform the intended function.  The ASU amendments also supersede previous guidance on website development costs.  The update is effective for fiscal years beginning after  December 15, 2027 and  may be adopted prospectively, retrospectively or with a modified transition approach. Early adoption is permitted. The Company is currently assessing the impact and timing of adopting the updated standard.

- added (2025-11-04):
[0001437749-25-033048:note_history:13]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors with more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

- changed (2025-11-04):
[0001437749-25-033048:note_history:14]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.
  (was, 2025-08-05, similarity 0.958):
[0001437749-25-024879:note_history:14]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

- changed (2025-11-04):
[0001437749-25-033048:note_history:15]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2025-08-05, similarity 0.9184):
[0001437749-25-024879:note_history:15]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the six months ended  June 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2025-11-04):
[0001437749-25-024879:note_history:16]
On  July 4, 2025, President Trump signed into law the "One Big Beautiful Bill Act" (OBBBA).  The OBBBA makes permanent key elements of the Tax Cuts and Jobs Act, including 100% bonus depreciation and domestic research cost expensing.  In addition, the OBBBA accelerates the phase-out of incentives for the solar market and includes certain supply chain requirements to qualify for these incentives.  ASC 740, “Income Taxes”, requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. The Company is in the process of evaluating the impact of the OBBBA to our business and the consolidated financial statements.

- removed (2025-11-04):
[0001437749-25-024879:note_history:17]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001437749-25-033048:note_history:18]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $46,046 and $55,848, respectively. As of  September 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 6.33% and 5.44%, respectively.
  (was, 2025-08-05, similarity 0.9638):
[0001437749-25-024879:note_history:18]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $54,264 and $55,848, respectively. As of  June 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.29% and 5.44%, respectively.

- added (2025-11-04):
[0001437749-25-033048:note_history:19]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 495,000 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,938 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 91,914 |  |  |  | 66,355 |  |
| Other |  |  | 3,134 |  |  |  | 8,972 |  |
| Total |  |  | 1,374,110 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 8,064 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,075 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,356,971 |  |  | $ | 1,210,776 |  |

- added (2025-11-04):
[0001437749-25-033048:note_history:20]
As of  September 30, 2025, there were $5,267 of unamortized deferred financing costs associated with the New Revolving Facility (as defined below) included in operating lease and other assets in the condensed consolidated balance sheets, and $5,938 of unamortized original issue discount and deferred financing costs linked to the New Tranche A Term Loan Facility and Term Loan B Facility (as defined collectively below) included in long-term borrowings and finance lease obligations in the condensed consolidated balance sheets.

- added (2025-11-04):
[0001437749-25-033048:note_history:21]
The New Tranche A Term Loan Facility and New Revolving Facility mature on  July 1, 2030.  The New Tranche A Term Loan Facility is repayable in quarterly installments commencing  October 1, 2026, with a balloon payment due at maturity. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due at maturity. Maturities of the Company's New Tranche A Term Loan Facility, Term Loan B Facility and New Revolving Facility outstanding on  September 30, 2025, before considering original issue discount and deferred financing costs, were as follows:

- added (2025-11-04):
[0001437749-25-033048:note_history:22]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2025 |  | $ | - |  |  | $ | 1,250 |  |  | $ | - |  |  | $ | 1,250 |  |
| 2026 |  |  | 4,375 |  |  |  | 5,000 |  |  |  | - |  |  |  | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 690,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 495,000 |  |  | $ | 90,000 |  |  | $ | 1,285,000 |  |

- changed (2025-11-04):
[0001437749-25-033048:note_history:23]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility and, together with the Original Term Loan B Facility, the Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on refinancing of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.03% combined rate as of  September 30, 2025.
  (was, 2025-08-05, similarity 0.9254):
[0001437749-25-024879:note_history:23]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.07% combined rate as of  June 30, 2025.

- added (2025-11-04):
[0001437749-25-033048:note_history:24]
The New Term Loan B Facility does not require an Excess Cash Flow payment (as defined in the New Term Loan B Facility credit agreement) if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2025, the Company’s net secured leverage ratio was 1.35 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

- added (2025-11-04):
[0001437749-25-033048:note_history:25]
The Company’s original Tranche A Term Loan Facility provided an aggregate principal amount of $750,000 (Original Tranche A Term Loan Facility), along with a $1,250,000 revolving facility (Original Revolving Facility) with all LIBOR provisions replaced with SOFR provisions. The Original Tranche A Term Loan Facility and the Original Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

- added (2025-11-04):
[0001437749-25-033048:note_history:26]
On  July 1, 2025, the Company amended the Original Tranche A Term Loan Facility and Original Revolving Facility (Prior Amended Credit Agreement), extending the maturity of both to  July 1, 2030, revising the Original Tranche A Term Loan Facility outstanding principal balance to $700,000 (New Tranche A Term Loan Facility), reducing the Revolving Facility borrowing capacity to $1,000,000 (New Revolving Facility) (collectively the New Credit Agreements), and redefined the Term Benchmark (as defined in the Prior Amended Credit Agreement) to replace the Adjusted Term SOFR Rate (as defined in the Prior Amended Credit Agreement) with the Term SOFR Rate (as defined in the New Credit Agreement), resulting in an interest rate reduction of 0.10%.  The New Tranche A Term Loan Facility is repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.  Except for redefining the Term Benchmark, interest rates for the New Credit Agreements remain unchanged from the original credit agreements.  As of  September 30, 2025, the interest rate for the New Tranche A Term Loan Facility and the New Revolving Facility is 5.78%.

- added (2025-11-04):
[0001437749-25-033048:note_history:27]
In accordance with ASC
      470-
      50, the Company capitalized
      $5,275 of debt issuance costs related to this transaction.  Additionally, the Company wrote-off certain unamortized deferred financing costs related to the Original Revolving Facility of
      $443 and expensed
      $782 of
      third-party fees as a loss on refinancing of debt.

- added (2025-11-04):
[0001437749-25-033048:note_history:28]
Both the Original and New Tranche A Term Loan Facility and the Original and New Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2025, the Company’s total leverage ratio was 1.41 to 1.00, and the Company's interest coverage ratio was 12.54 to 1.00. The Company was also in compliance with all other covenants of the New Credit Agreements as of  September 30, 2025.

- added (2025-11-04):
[0001437749-25-033048:note_history:29]
The New Term Loan B Facility, New Tranche A Term Loan Facility and New Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

- changed (2025-11-04):
[0001437749-25-033048:note_history:30]
As of  September 30, 2025, there was $90,000 outstanding under the New Revolving Facility, leaving $909,250 of unused capacity, net of outstanding letters of credit.
  (was, 2025-08-05, similarity 0.9474):
[0001437749-25-024879:note_history:30]
As of  June 30, 2025, there was $90,000 outstanding under the Revolving Facility, leaving $1,159,250 of unused capacity, net of outstanding letters of credit.

- removed (2025-11-04):
[0001437749-25-024879:note_history:31]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 693,750 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 496,250 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (6,925 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 89,064 |  |  |  | 66,355 |  |
| Other |  |  | 6,262 |  |  |  | 8,972 |  |
| Total |  |  | 1,368,401 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 67,424 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 8,164 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,292,813 |  |  | $ | 1,210,776 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:32]
Prior to the Tranche A Term Loan Facility and Revolving Facility amendments discussed below, as of  June 30, 2025, the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027.  The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 29, 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Term Loan B Facility and Revolving Facility outstanding on  June 30, 2025, before considering original issue discount and deferred financing costs, are as follows:

- removed (2025-11-04):
[0001437749-25-024879:note_history:33]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 28,125 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 30,625 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 695,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 693,750 |  |  | $ | 496,250 |  |  | $ | 90,000 |  |  | $ | 1,280,000 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:34]
The New Term Loan B Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2025, the Company’s net secured leverage ratio was 1.37 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

- removed (2025-11-04):
[0001437749-25-024879:note_history:35]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2025, the interest rate for the Tranche A Term Loan Facility and the Revolving Facility is 5.92%.

- removed (2025-11-04):
[0001437749-25-024879:note_history:36]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2025, the Company’s total leverage ratio was 1.44 to 1.00, and the Company's interest coverage ratio was 12.34 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2025.

- removed (2025-11-04):
[0001437749-25-024879:note_history:37]
The New Term Loan B Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

- removed (2025-11-04):
[0001437749-25-024879:note_history:38]
On  July 1, 2025, the Company amended its existing Tranche A Term Loan Facility and $1,250,000 Revolving Facility, extending the maturity of both to  July 1, 2030, revising the Tranche A Term Loan Facility outstanding principal balance to $700,000, reducing the Revolving Facility borrowing capacity to $1,000,000, and removing the Credit Adjustment Spread (as defined in the Amended Credit Agreement) from each.  The revised Tranche A Term Loan Facility is now repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.   The revised Tranche A Term Loan Facility and Revolving Facility will continue to bear interest at either a base rate plus an applicable margin between 0.25% and 0.75% or SOFR rate plus an applicable margin between 1.25% and 1.75%, both based on the Company’s total leverage ratio and subject to a SOFR floor of 0.0%.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001437749-25-033048:note_history:39]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 700,000 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 495,000 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (5,938 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 91,914 |  |  |  | 66,355 |  |
| Other |  |  | 3,134 |  |  |  | 8,972 |  |
| Total |  |  | 1,374,110 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 8,064 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 9,075 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,356,971 |  |  | $ | 1,210,776 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:40]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 693,750 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 496,250 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (6,925 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 89,064 |  |  |  | 66,355 |  |
| Other |  |  | 6,262 |  |  |  | 8,972 |  |
| Total |  |  | 1,368,401 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 67,424 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 8,164 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,292,813 |  |  | $ | 1,210,776 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001437749-25-033048:note_history:41]
|  |  | New Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | New Revolving Facility |  |  | Total |  |
| 2025 |  | $ | - |  |  | $ | 1,250 |  |  | $ | - |  |  | $ | 1,250 |  |
| 2026 |  |  | 4,375 |  |  |  | 5,000 |  |  |  | - |  |  |  | 9,375 |  |
| 2027 |  |  | 21,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 26,875 |  |
| 2028 |  |  | 35,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 40,000 |  |
| 2029 |  |  | 43,750 |  |  |  | 5,000 |  |  |  | - |  |  |  | 48,750 |  |
| 2030 |  |  | 595,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 690,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 700,000 |  |  | $ | 495,000 |  |  | $ | 90,000 |  |  | $ | 1,285,000 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:42]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 28,125 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 30,625 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 695,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 693,750 |  |  | $ | 496,250 |  |  | $ | 90,000 |  |  | $ | 1,280,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001437749-25-033048:note_history:43]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 605,444 |  |  | $ | 21,262 |  |  | $ | 626,706 |  |
| Commercial & industrial products |  |  | 212,875 |  |  |  | 145,398 |  |  |  | 358,273 |  |
| Other |  |  | 115,327 |  |  |  | 14,047 |  |  |  | 129,374 |  |
| Total net sales |  | $ | 933,646 |  |  | $ | 180,707 |  |  | $ | 1,114,353 |  |

- added (2025-11-04):
[0001437749-25-033048:note_history:44]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

- added (2025-11-04):
[0001437749-25-033048:note_history:45]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,632,048 |  |  | $ | 62,998 |  |  | $ | 1,695,046 |  |
| Commercial & industrial products |  |  | 635,356 |  |  |  | 422,493 |  |  |  | 1,057,849 |  |
| Other |  |  | 319,115 |  |  |  | 45,633 |  |  |  | 364,748 |  |
| Total net sales |  | $ | 2,586,519 |  |  | $ | 531,124 |  |  | $ | 3,117,643 |  |

- added (2025-11-04):
[0001437749-25-033048:note_history:46]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:47]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 553,314 |  |  | $ | 20,875 |  |  | $ | 574,189 |  |
| Commercial & industrial products |  |  | 216,335 |  |  |  | 145,868 |  |  |  | 362,203 |  |
| Other |  |  | 108,582 |  |  |  | 16,195 |  |  |  | 124,777 |  |
| Total net sales |  | $ | 878,231 |  |  | $ | 182,938 |  |  | $ | 1,061,169 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:48]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:49]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,026,604 |  |  | $ | 41,736 |  |  | $ | 1,068,340 |  |
| Commercial & industrial products |  |  | 422,481 |  |  |  | 277,095 |  |  |  | 699,576 |  |
| Other |  |  | 203,788 |  |  |  | 31,586 |  |  |  | 235,374 |  |
| Total net sales |  | $ | 1,652,873 |  |  | $ | 350,417 |  |  | $ | 2,003,290 |  |

- removed (2025-11-04):
[0001437749-25-024879:note_history:50]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001437749-25-033048:note_history:51]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits and other contract liabilities was $58,901 and $26,858 on  September 30, 2025, and  December 31, 2024, respectively. During the nine months ended  September 30, 2025, the Company recognized revenue of $23,020 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

- removed (2025-11-04):
[0001437749-25-024879:note_history:52]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $23,779 and $26,858 on  June 30, 2025, and  December 31, 2024, respectively. During the six months ended  June 30, 2025, the Company recognized revenue of $17,392 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
