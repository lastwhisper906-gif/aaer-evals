# GNRC note change history — 0001437749-20-016520 → 0001437749-20-022373


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001437749-20-022373:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2020 and  December 31, 2019 was approximately $45,700 and $49,600, respectively.
  (was, 2020-08-04, similarity 0.9889):
[0001437749-20-016520:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2020 and  December 31, 2019 was approximately $54,600 and $49,600, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-11-03):
[0001437749-20-022373:note_history:2]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses, and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC. (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC. (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |

- changed (2020-11-03):
[0001437749-20-022373:note_history:3]
The condensed consolidated balance sheet as of  September 30, 2020, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2020-08-04, similarity 0.9031):
[0001437749-20-016520:note_history:3]
The condensed consolidated balance sheet as of  June 30, 2020, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2020-11-03):
[0001437749-20-022373:note_history:4]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and other indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.
  (was, 2020-08-04, similarity 0.9944):
[0001437749-20-016520:note_history:4]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

- changed (2020-11-03):
[0001437749-20-022373:note_history:5]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020 and the three months ended  September 30, 2020.
  (was, 2020-08-04, similarity 0.861):
[0001437749-20-016520:note_history:5]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020.

- changed (2020-11-03):
[0001437749-20-022373:note_history:6]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9 to the condensed consolidated financial statements, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.
  (was, 2020-08-04, similarity 0.9793):
[0001437749-20-016520:note_history:6]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

- removed (2020-11-03):
[0001437749-20-016520:note_history:7]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001437749-20-022373:note_history:8]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL Facility |  | $ | 5,269 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,531 |  |  |  | 27,753 |  |
| Total |  | $ | 44,800 |  |  | $ | 58,714 |  |
  (was, 2020-08-04, similarity 0.9688):
[0001437749-20-016520:note_history:8]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 7,279 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 45,064 |  |  |  | 27,753 |  |
| Total |  | $ | 52,343 |  |  | $ | 58,714 |  |

- added (2020-11-03):
[0001437749-20-022373:note_history:9]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,107 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,021 |  |  |  | 25,962 |  |
| Other |  |  | 3,848 |  |  |  | 2,236 |  |
| Total |  |  | 844,762 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,313 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,108 |  |  |  | 1,830 |  |
| Total |  | $ | 841,341 |  |  | $ | 837,767 |  |

- changed (2020-11-03):
[0001437749-20-022373:note_history:10]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take effect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the Term Loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2020-08-04, similarity 0.9989):
[0001437749-20-016520:note_history:10]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the term loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2020-11-03):
[0001437749-20-022373:note_history:11]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2020, the Company’s net secured leverage ratio was 1.26 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2020-08-04, similarity 0.981):
[0001437749-20-016520:note_history:11]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2020, the Company’s net secured leverage ratio was 1.41 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2020-11-03):
[0001437749-20-022373:note_history:12]
As of  September 30, 2020, there was $5,269 outstanding under the ABL Facility, leaving $294,338 of availability, net of outstanding letters of credit.
  (was, 2020-08-04, similarity 0.9582):
[0001437749-20-016520:note_history:12]
As of  June 30, 2020, there was $7,279 outstanding under the ABL Facility, leaving $292,281 of availability, net of outstanding letters of credit.

- changed (2020-11-03):
[0001437749-20-022373:note_history:13]
As of  September 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $44,800 and $58,714, respectively.
  (was, 2020-08-04, similarity 0.9679):
[0001437749-20-016520:note_history:13]
As of  June 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $52,343 and $58,714, respectively.

- removed (2020-11-03):
[0001437749-20-016520:note_history:14]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,762 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,157 |  |  |  | 25,962 |  |
| Other |  |  | 3,753 |  |  |  | 2,236 |  |
| Total |  |  | 844,148 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,010 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,022 |  |  |  | 1,830 |  |
| Total |  | $ | 841,116 |  |  | $ | 837,767 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-11-03):
[0001437749-20-022373:note_history:15]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,107 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,021 |  |  |  | 25,962 |  |
| Other |  |  | 3,848 |  |  |  | 2,236 |  |
| Total |  |  | 844,762 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,313 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,108 |  |  |  | 1,830 |  |
| Total |  | $ | 841,341 |  |  | $ | 837,767 |  |

- removed (2020-11-03):
[0001437749-20-016520:note_history:16]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,762 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,157 |  |  |  | 25,962 |  |
| Other |  |  | 3,753 |  |  |  | 2,236 |  |
| Total |  |  | 844,148 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,010 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,022 |  |  |  | 1,830 |  |
| Total |  | $ | 841,116 |  |  | $ | 837,767 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001437749-20-022373:note_history:17]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL Facility |  | $ | 5,269 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,531 |  |  |  | 27,753 |  |
| Total |  | $ | 44,800 |  |  | $ | 58,714 |  |
  (was, 2020-08-04, similarity 0.9688):
[0001437749-20-016520:note_history:17]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 7,279 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 45,064 |  |  |  | 27,753 |  |
| Total |  | $ | 52,343 |  |  | $ | 58,714 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001437749-20-022373:note_history:18]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 441,532 |  |  | $ | 17,345 |  |  | $ | 458,877 |  |
| Commercial & industrial products |  |  | 108,774 |  |  |  | 67,426 |  |  |  | 176,200 |  |
| Other |  |  | 56,569 |  |  |  | 9,709 |  |  |  | 66,278 |  |
| Total net sales |  | $ | 606,875 |  |  | $ | 94,480 |  |  | $ | 701,355 |  |
  (was, 2020-08-04, similarity 0.8928):
[0001437749-20-016520:note_history:18]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 456,599 |  |  | $ | 29,605 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 258,022 |  |  |  | 181,530 |  |  |  | 439,552 |  |
| Other |  |  | 63,409 |  |  |  | 23,104 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 778,030 |  |  | $ | 234,239 |  |  | $ | 1,012,269 |  |

- changed (2020-11-03):
[0001437749-20-022373:note_history:19]
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 322,134 |  |  | $ | 12,895 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 132,491 |  |  |  | 82,414 |  |  |  | 214,905 |  |
| Other |  |  | 40,185 |  |  |  | 11,016 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 494,810 |  |  | $ | 106,325 |  |  | $ | 601,135 |  |
  (was, 2020-08-04, similarity 0.9803):
[0001437749-20-016520:note_history:19]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 252,340 |  |  | $ | 16,034 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 137,197 |  |  |  | 93,231 |  |  |  | 230,428 |  |
| Other |  |  | 31,995 |  |  |  | 11,119 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 421,532 |  |  | $ | 120,384 |  |  | $ | 541,916 |  |

- added (2020-11-03):
[0001437749-20-022373:note_history:20]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,013,219 |  |  | $ | 44,629 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 294,940 |  |  |  | 208,216 |  |  |  | 503,156 |  |
| Other |  |  | 135,521 |  |  |  | 27,593 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 1,443,680 |  |  | $ | 280,438 |  |  | $ | 1,724,118 |  |

- added (2020-11-03):
[0001437749-20-022373:note_history:21]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 778,733 |  |  | $ | 42,500 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 390,514 |  |  |  | 263,944 |  |  |  | 654,458 |  |
| Other |  |  | 103,593 |  |  |  | 34,120 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,272,840 |  |  | $ | 340,564 |  |  | $ | 1,613,404 |  |

- removed (2020-11-03):
[0001437749-20-016520:note_history:22]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

- removed (2020-11-03):
[0001437749-20-016520:note_history:23]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001437749-20-022373:note_history:24]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,637 and $9,952 at  September 30, 2020 and  December 31, 2019, respectively. During the nine months ended  September 30, 2020, the Company recognized revenue of $7,991 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2020-08-04, similarity 0.9473):
[0001437749-20-016520:note_history:24]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,205 and $9,952 at  June 30, 2020 and  December 31, 2019, respectively. During the six months ended  June 30, 2020, the Company recognized revenue of $6,748 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-11-03):
[0001437749-20-022373:note_history:25]
17. Subsequent Event

- added (2020-11-03):
[0001437749-20-022373:note_history:26]
On  October 7, 2020, the Company acquired Enbala Power Networks Inc. (Enbala), one of the leading providers of distributed energy optimization and control software needed to ensure the operational stability of the world’s power grids. Enbala was founded in 2003 and is headquartered in Denver, Colorado.
