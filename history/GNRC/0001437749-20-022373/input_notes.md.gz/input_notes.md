# GNRC notes — 0001437749-20-022373


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-20-022373:notes:1]
[same as prior period, unchanged from 0001437749-20-016520:notes:1]

[0001437749-20-022373:notes:2]
[same as prior period, unchanged from 0001437749-20-016520:notes:2]

[0001437749-20-022373:notes:3]
[same as prior period, unchanged from 0001437749-20-016520:notes:3]

[0001437749-20-022373:notes:4]
[same as prior period, unchanged from 0001437749-20-016520:notes:4]

[0001437749-20-022373:notes:5]
[same as prior period, unchanged from 0001437749-20-016520:notes:5]

[0001437749-20-022373:notes:6]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses, and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC. (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC. (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |

[0001437749-20-022373:notes:7]
[same as prior period, unchanged from 0001437749-20-016520:notes:7]

[0001437749-20-022373:notes:8]
The condensed consolidated balance sheet as of  September 30, 2020, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-20-022373:notes:9]
[same as prior period, unchanged from 0001437749-20-016520:notes:9]

[0001437749-20-022373:notes:10]
[same as prior period, unchanged from 0001437749-20-016520:notes:10]

[0001437749-20-022373:notes:11]
[same as prior period, unchanged from 0001437749-20-016520:notes:11]

[0001437749-20-022373:notes:12]
[same as prior period, unchanged from 0001437749-20-016520:notes:12]

[0001437749-20-022373:notes:13]
[same as prior period, unchanged from 0001437749-20-016520:notes:13]

[0001437749-20-022373:notes:14]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and other indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

[0001437749-20-022373:notes:15]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020 and the three months ended  September 30, 2020.

[0001437749-20-022373:notes:16]
[same as prior period, unchanged from 0001437749-20-016520:notes:16]

[0001437749-20-022373:notes:17]
[same as prior period, unchanged from 0001437749-20-016520:notes:17]

[0001437749-20-022373:notes:18]
Recently Adopted Accounting Standards

[0001437749-20-022373:notes:19]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9 to the condensed consolidated financial statements, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

[0001437749-20-022373:notes:20]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-20-022373:notes:21]
[same as prior period, unchanged from 0001437749-20-016520:notes:21]

[0001437749-20-022373:notes:22]
[same as prior period, unchanged from 0001437749-20-016520:notes:22]

[0001437749-20-022373:notes:23]
[same as prior period, unchanged from 0001437749-20-016520:notes:23]

[0001437749-20-022373:notes:24]
The Company finalized the Pika purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pika from the date of acquisition. Pro forma financial information is not presented as the effects of this acquisition or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-20-022373:notes:25]
[same as prior period, unchanged from 0001437749-20-016520:notes:25]

[0001437749-20-022373:notes:26]
[same as prior period, unchanged from 0001437749-20-016520:notes:26]

[0001437749-20-022373:notes:27]
The Company finalized the Neurio purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition. Pro forma financial information is not presented as the effects of this acquisition or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-20-022373:notes:28]
Other Acquisitions

[0001437749-20-022373:notes:29]
In  February 2019, the Company acquired a majority share of Captiva, a manufacturer of customized industrial generators in Kolkata, India.

[0001437749-20-022373:notes:30]
In  July 2020, the Company acquired Energy Systems, its industrial distributor in northern California.

[0001437749-20-022373:notes:31]
In  September 2020, the Company acquired Mean Green, a designer and manufacturer of commercial grade, battery-powered turf care products.

[0001437749-20-022373:notes:32]
The combined purchase price for these acquisitions was $24,070 and was funded solely through cash on hand. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition. Pro forma financial information and allocation of the purchase price are not presented for these other acquisitions as the effects of the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-20-022373:notes:33]
[same as prior period, unchanged from 0001437749-20-016520:notes:28]

[0001437749-20-022373:notes:34]
[same as prior period, unchanged from 0001437749-20-016520:notes:29]

[0001437749-20-022373:notes:35]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva. The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition.

[0001437749-20-022373:notes:36]
[same as prior period, unchanged from 0001437749-20-016520:notes:31]

[0001437749-20-022373:notes:37]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 61,019 |  |  | $ | 59,117 |  |  | $ | 61,227 |  |  | $ | 61,004 |  |
| Net income (loss) |  |  | 80 |  |  |  | (563 | ) |  |  | (2,601 | ) |  |  | (388 | ) |
| Foreign currency translation |  |  | 3,257 |  |  |  | (3,475 | ) |  |  | 2,638 |  |  |  | (3,861 | ) |
| Redemption value adjustment |  |  | (811 | ) |  |  | 1,485 |  |  |  | 2,281 |  |  |  | (191 | ) |
| Balance at end of period |  | $ | 63,545 |  |  | $ | 56,564 |  |  | $ | 63,545 |  |  | $ | 56,564 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-022373:notes:38]
[same as prior period, unchanged from 0001437749-20-016520:notes:33]

[0001437749-20-022373:notes:39]
[same as prior period, unchanged from 0001437749-20-016520:notes:34]

[0001437749-20-022373:notes:40]
[same as prior period, unchanged from 0001437749-20-016520:notes:35]

[0001437749-20-022373:notes:41]
[same as prior period, unchanged from 0001437749-20-016520:notes:36]

[0001437749-20-022373:notes:42]
In 2017, the Company entered into twenty interest rate swap agreements, twelve of which were still outstanding as of  September 30, 2020. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to fifteen as of  September 30, 2020. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains and losses, net of tax, recognized for the three and nine months ended  September 30, 2020 were $1,003 and $(18,406), respectively. The amount of losses, net of tax, recognized for the three and nine months ended  September 30, 2019 were $(2,721) and $(14,898), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-20-022373:notes:43]
[same as prior period, unchanged from 0001437749-20-016520:notes:38]

[0001437749-20-022373:notes:44]
[same as prior period, unchanged from 0001437749-20-016520:notes:39]

[0001437749-20-022373:notes:45]
|  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Commodity contracts |  | $ | 1,522 |  |  | $ | 6 |  |
| Foreign currency contracts |  |  | (3 | ) |  |  | 31 |  |
| Interest rate swaps |  |  | (35,049 | ) |  |  | (10,425 | ) |

[0001437749-20-022373:notes:46]
The fair value of the commodity contracts is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  September 30, 2020. The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  December 31, 2019. Excluding the impact of credit risk, the fair value of the derivative contracts as of  September 30, 2020 and  December 31, 2019 is a liability of $34,134 and $10,588, respectively, which represents the amount the Company would pay upon exit of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-022373:notes:47]
[same as prior period, unchanged from 0001437749-20-016520:notes:42]

[0001437749-20-022373:notes:48]
[same as prior period, unchanged from 0001437749-20-016520:notes:43]

[0001437749-20-022373:notes:49]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $814,675, was approximately $828,963 (Level 2) at  September 30, 2020, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-20-022373:notes:50]
[same as prior period, unchanged from 0001437749-20-016520:notes:45]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-20-022373:notes:51]
[same as prior period, unchanged from 0001437749-20-016520:notes:46]

[0001437749-20-022373:notes:52]
The following presents a tabular disclosure of changes in AOCL during the three and nine months ended  September 30, 2020 and 2019, net of tax:

[0001437749-20-022373:notes:53]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July, 1 2020 |  | $ | (44,822 | ) |  | $ | - |  |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 9,484 |  |  |  | - |  |  |  | 1,003 |  | (1) |  |  | 10,487 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 9,484 |  |  |  | - |  |  |  | 1,003 |  |  |  |  | 10,487 |  |
| Ending Balance – September 30, 2020 |  | $ | (35,338 | ) |  | $ | - |  |  | $ | (26,701 | ) |  |  | $ | (62,039 | ) |

[0001437749-20-022373:notes:54]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July, 1 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  |  | $ | (33,831 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (9,811 | ) |  |  | - |  |  |  | (2,721 | ) | (2) |  |  | (12,532 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (9,811 | ) |  |  | - |  |  |  | (2,721 | ) |  |  |  | (12,532 | ) |
| Ending Balance – September 30, 2019 |  | $ | (26,484 | ) |  | $ | (10,541 | ) |  | $ | (9,338 | ) |  |  | $ | (46,363 | ) |

[0001437749-20-022373:notes:55]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  |  | $ | - |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (18,716 | ) | (3) |  |  | - |  |  |  | (18,406 | ) | (4) |  |  | (37,122 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (18,716 | ) |  |  |  | - |  |  |  | (18,406 | ) |  |  |  | (37,122 | ) |
| Ending Balance – September 30, 2020 |  | $ | (35,338 | ) |  |  | $ | - |  |  | $ | (26,701 | ) |  |  | $ | (62,039 | ) |

[0001437749-20-022373:notes:56]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  |  | $ | (23,813 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (7,652 | ) |  |  | - |  |  |  | (14,898 | ) | (5) |  |  | (22,550 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (7,652 | ) |  |  | - |  |  |  | (14,898 | ) |  |  |  | (22,550 | ) |
| Ending Balance – September 30, 2019 |  | $ | (26,484 | ) |  | $ | (10,541 | ) |  | $ | (9,338 | ) |  |  | $ | (46,363 | ) |

[0001437749-20-022373:notes:57]
|  | (1) | Represents unrealized gains of $1,342, net of tax effect of $(339) for the three months ended September 30, 2020. |

[0001437749-20-022373:notes:58]
|  | (2) | Represents unrealized losses of $(3,677), net of tax effect of $956 for the three months ended September 30, 2019. |

[0001437749-20-022373:notes:59]
|  | (3) | Represents the unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |

[0001437749-20-022373:notes:60]
|  | (4) | Represents unrealized losses of $(24,623), net of tax effect of $6,217 for the nine months ended September 30, 2020. |
|  | (5) | Represents unrealized losses of $(20,132), net of tax effect of $5,234 for the nine months ended September 30, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-022373:notes:61]
[same as prior period, unchanged from 0001437749-20-016520:notes:56]

[0001437749-20-022373:notes:62]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues that are substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment, energy technology solutions, and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, and regional considerations.

[0001437749-20-022373:notes:63]
The Company's product offerings consist primarily of power generation equipment, energy technology solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-20-022373:notes:64]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 441,532 |  |  | $ | 17,345 |  |  | $ | 458,877 |  |
| Commercial & industrial products |  |  | 108,774 |  |  |  | 67,426 |  |  |  | 176,200 |  |
| Other |  |  | 56,569 |  |  |  | 9,709 |  |  |  | 66,278 |  |
| Total net sales |  | $ | 606,875 |  |  | $ | 94,480 |  |  | $ | 701,355 |  |

[0001437749-20-022373:notes:65]
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 322,134 |  |  | $ | 12,895 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 132,491 |  |  |  | 82,414 |  |  |  | 214,905 |  |
| Other |  |  | 40,185 |  |  |  | 11,016 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 494,810 |  |  | $ | 106,325 |  |  | $ | 601,135 |  |

[0001437749-20-022373:notes:66]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,013,219 |  |  | $ | 44,629 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 294,940 |  |  |  | 208,216 |  |  |  | 503,156 |  |
| Other |  |  | 135,521 |  |  |  | 27,593 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 1,443,680 |  |  | $ | 280,438 |  |  | $ | 1,724,118 |  |

[0001437749-20-022373:notes:67]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 778,733 |  |  | $ | 42,500 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 390,514 |  |  |  | 263,944 |  |  |  | 654,458 |  |
| Other |  |  | 103,593 |  |  |  | 34,120 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,272,840 |  |  | $ | 340,564 |  |  | $ | 1,613,404 |  |

[0001437749-20-022373:notes:68]
[same as prior period, unchanged from 0001437749-20-016520:notes:63]

[0001437749-20-022373:notes:69]
[same as prior period, unchanged from 0001437749-20-016520:notes:64]

[0001437749-20-022373:notes:70]
[same as prior period, unchanged from 0001437749-20-016520:notes:65]

[0001437749-20-022373:notes:71]
[same as prior period, unchanged from 0001437749-20-016520:notes:66]

[0001437749-20-022373:notes:72]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 171,359 |  |  | $ | 120,833 |  |  | $ | 374,065 |  |  | $ | 305,747 |  |
| International |  |  | 7,419 |  |  |  | 5,120 |  |  |  | 13,877 |  |  |  | 19,220 |  |
| Total adjusted EBITDA |  | $ | 178,778 |  |  | $ | 125,953 |  |  | $ | 387,942 |  |  | $ | 324,967 |  |
| Interest expense |  |  | (8,096 | ) |  |  | (10,704 | ) |  |  | (25,081 | ) |  |  | (31,428 | ) |
| Depreciation and amortization |  |  | (17,168 | ) |  |  | (15,494 | ) |  |  | (50,087 | ) |  |  | (42,841 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (477 | ) |  |  | (347 | ) |  |  | (1,868 | ) |  |  | (673 | ) |
| Non-cash share-based compensation expense (2) |  |  | (4,353 | ) |  |  | (3,549 | ) |  |  | (14,327 | ) |  |  | (11,477 | ) |
| Transaction costs and credit facility fees (3) |  |  | (568 | ) |  |  | (358 | ) |  |  | (1,160 | ) |  |  | (2,047 | ) |
| Business optimization and other charges (4) |  |  | (531 | ) |  |  | (567 | ) |  |  | (12,503 | ) |  |  | (809 | ) |
| Other |  |  | (300 | ) |  |  | 27 |  |  |  | (711 | ) |  |  | 556 |  |
| Income before provision for income taxes |  | $ | 147,285 |  |  | $ | 94,961 |  |  | $ | 282,205 |  |  | $ | 236,248 |  |

[0001437749-20-022373:notes:73]
[same as prior period, unchanged from 0001437749-20-016520:notes:68]

[0001437749-20-022373:notes:74]
[same as prior period, unchanged from 0001437749-20-016520:notes:69]

[0001437749-20-022373:notes:75]
[same as prior period, unchanged from 0001437749-20-016520:notes:70]

[0001437749-20-022373:notes:76]
|  | (4) | For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products. For the three and nine months ended September 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities. |

[0001437749-20-022373:notes:77]
In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment beginning in 2018. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the three and nine months ended  September 30, 2019, net sales of $3,353 and $10,509, and adjusted EBITDA of $384 and $976, respectively, were moved from the Domestic segment to the International segment.

[0001437749-20-022373:notes:78]
The Company’s sales in the U.S. represented approximately 84% and 78% of total sales for the three months ended  September 30, 2020 and 2019, respectively. The Company's sales in the U.S. represented approximately 82% and 75% of total sales for the nine months ended  September 30, 2020 and 2019, respectively. Approximately 82% and 80% of the Company’s identifiable long-lived assets were located in the U.S. at  September 30, 2020 and  December 31, 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-20-022373:notes:79]
[same as prior period, unchanged from 0001437749-20-016520:notes:74]

[0001437749-20-022373:notes:80]
[same as prior period, unchanged from 0001437749-20-016520:notes:75]

[0001437749-20-022373:notes:81]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 340,275 |  |  | $ | 328,021 |  |
| Work-in-process |  |  | 8,817 |  |  |  | 10,387 |  |
| Finished goods |  |  | 183,860 |  |  |  | 183,616 |  |
| Total |  | $ | 532,952 |  |  | $ | 522,024 |  |

[0001437749-20-022373:notes:82]
[same as prior period, unchanged from 0001437749-20-016520:notes:77]

[0001437749-20-022373:notes:83]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Land and improvements |  | $ | 17,464 |  |  | $ | 18,252 |  |
| Buildings and improvements |  |  | 194,994 |  |  |  | 177,079 |  |
| Machinery and equipment |  |  | 147,590 |  |  |  | 117,114 |  |
| Dies and tools |  |  | 23,677 |  |  |  | 22,040 |  |
| Vehicles |  |  | 5,258 |  |  |  | 3,955 |  |
| Office equipment and systems |  |  | 104,363 |  |  |  | 99,124 |  |
| Leasehold improvements |  |  | 4,914 |  |  |  | 4,293 |  |
| Construction in progress |  |  | 11,913 |  |  |  | 36,299 |  |
| Gross property and equipment |  |  | 510,173 |  |  |  | 478,156 |  |
| Accumulated depreciation |  |  | (188,813 | ) |  |  | (161,180 | ) |
| Total |  | $ | 321,360 |  |  | $ | 316,976 |  |

[0001437749-20-022373:notes:84]
Total property and equipment included finance leases of $26,976 and $26,063 at  September 30, 2020 and  December 31, 2019, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:AllowanceForCreditLossesTextBlock

[0001437749-20-022373:notes:85]
[same as prior period, unchanged from 0001437749-20-016520:notes:80]

[0001437749-20-022373:notes:86]
The Company's trade and other receivables primarily arise from the sale of our products to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, and certain end users with payment terms generally ranging from 30 to 60 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-20-022373:notes:87]
The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity by entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-20-022373:notes:88]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds a credit insurance plan that covers the risk of loss up to specified amounts on certain trade receivables. As of  September 30, 2020, the Company had gross receivables of $409,423 and an allowance for credit losses of $11,183.

[0001437749-20-022373:notes:89]
[same as prior period, unchanged from 0001437749-20-016520:notes:84]

[0001437749-20-022373:notes:90]
|  |  | Three Months Ended September 30, 2020 |  |  | Nine Months Ended September 30, 2020 |  |
| Balance at beginning of period |  | $ | 11,097 |  |  | $ | 6,968 |  |
| Adoption of ASU 2016-13 |  |  | - |  |  |  | 1,147 |  |
| Provision for credit losses |  |  | 152 |  |  |  | 3,982 |  |
| Charge-offs |  |  | (336 | ) |  |  | (615 | ) |
| Currency translation |  |  | 270 |  |  |  | (299 | ) |
| Balance at end of period |  | $ | 11,183 |  |  | $ | 11,183 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-20-022373:notes:91]
[same as prior period, unchanged from 0001437749-20-016520:notes:86]

[0001437749-20-022373:notes:92]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the product to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-20-022373:notes:93]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 50,324 |  |  | $ | 45,324 |  |  | $ | 49,316 |  |  | $ | 41,785 |  |
| Product warranty reserve assumed in acquisition |  |  | 124 |  |  |  | - |  |  |  | 124 |  |  |  | 407 |  |
| Payments |  |  | (8,667 | ) |  |  | (7,576 | ) |  |  | (24,136 | ) |  |  | (18,867 | ) |
| Provision for warranty issued |  |  | 10,949 |  |  |  | 8,518 |  |  |  | 27,691 |  |  |  | 23,656 |  |
| Changes in estimates for pre-existing warranties |  |  | (575 | ) |  |  | 230 |  |  |  | (840 | ) |  |  | (485 | ) |
| Balance at end of period |  | $ | 52,155 |  |  | $ | 46,496 |  |  | $ | 52,155 |  |  | $ | 46,496 |  |

[0001437749-20-022373:notes:94]
[same as prior period, unchanged from 0001437749-20-016520:notes:89]

[0001437749-20-022373:notes:95]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 83,153 |  |  | $ | 74,517 |  |  | $ | 78,738 |  |  | $ | 68,340 |  |
| Deferred revenue contracts issued |  |  | 6,802 |  |  |  | 5,918 |  |  |  | 18,966 |  |  |  | 18,832 |  |
| Amortization of deferred revenue contracts |  |  | (4,241 | ) |  |  | (3,573 | ) |  |  | (11,990 | ) |  |  | (10,310 | ) |
| Balance at end of period |  | $ | 85,714 |  |  | $ | 76,862 |  |  | $ | 85,714 |  |  | $ | 76,862 |  |

[0001437749-20-022373:notes:96]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  September 30, 2020 is as follows:

[0001437749-20-022373:notes:97]
| Remainder of 2020 |  | $ | 4,382 |  |
| 2021 |  |  | 19,630 |  |
| 2022 |  |  | 18,567 |  |
| 2023 |  |  | 14,058 |  |
| 2024 |  |  | 9,801 |  |
| After 2024 |  |  | 19,276 |  |
| Total |  | $ | 85,714 |  |

[0001437749-20-022373:notes:98]
[same as prior period, unchanged from 0001437749-20-016520:notes:93]

[0001437749-20-022373:notes:99]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 29,962 |  |  | $ | 27,885 |  |
| Long-term portion - other long-term liabilities |  |  | 22,193 |  |  |  | 21,431 |  |
| Total |  | $ | 52,155 |  |  | $ | 49,316 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,846 |  |  | $ | 15,519 |  |
| Long-term portion - other long-term liabilities |  |  | 63,868 |  |  |  | 63,219 |  |
| Total |  | $ | 85,714 |  |  | $ | 78,738 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-022373:notes:100]
[same as prior period, unchanged from 0001437749-20-016520:notes:95]

[0001437749-20-022373:notes:101]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,637 and $9,952 at  September 30, 2020 and  December 31, 2019, respectively. During the nine months ended  September 30, 2020, the Company recognized revenue of $7,991 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-20-022373:notes:102]
12.   Credit Agreements

[0001437749-20-022373:notes:103]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-022373:notes:104]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL Facility |  | $ | 5,269 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,531 |  |  |  | 27,753 |  |
| Total |  | $ | 44,800 |  |  | $ | 58,714 |  |

[0001437749-20-022373:notes:105]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-022373:notes:106]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,107 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,021 |  |  |  | 25,962 |  |
| Other |  |  | 3,848 |  |  |  | 2,236 |  |
| Total |  |  | 844,762 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,313 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,108 |  |  |  | 1,830 |  |
| Total |  | $ | 841,341 |  |  | $ | 837,767 |  |

[0001437749-20-022373:notes:107]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan agreement has been amended a number of times since inception.

[0001437749-20-022373:notes:108]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take effect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the Term Loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-20-022373:notes:109]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2020, the Company’s net secured leverage ratio was 1.26 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-022373:notes:110]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-20-022373:notes:111]
As of  September 30, 2020, there was $5,269 outstanding under the ABL Facility, leaving $294,338 of availability, net of outstanding letters of credit.

[0001437749-20-022373:notes:112]
As of  September 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $44,800 and $58,714, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-20-022373:notes:113]
[same as prior period, unchanged from 0001437749-20-016520:notes:108]

[0001437749-20-022373:notes:114]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program that is due to expire in the fourth quarter of 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which will commence upon the expiration of the previous stock repurchase program, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases during the three and nine months ended  September 30, 2020. Since the inception of all programs starting in  August 2015, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-022373:notes:115]
[same as prior period, unchanged from 0001437749-20-016520:notes:110]

[0001437749-20-022373:notes:116]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 3 to the condensed consolidated financial statements, “Redeemable Noncontrolling Interest” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-20-022373:notes:117]
[same as prior period, unchanged from 0001437749-20-016520:notes:112]

[0001437749-20-022373:notes:118]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 811 |  |  |  | (1,485 | ) |  |  | (2,281 | ) |  |  | 191 |  |
| Net income attributable to common shareholders |  | $ | 115,781 |  |  | $ | 74,089 |  |  | $ | 223,294 |  |  | $ | 182,584 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,353,473 |  |  |  | 61,973,447 |  |  |  | 62,244,872 |  |  |  | 61,878,500 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,407,907 |  |  |  | 797,145 |  |  |  | 1,301,260 |  |  |  | 640,705 |  |
| Diluted shares |  |  | 63,761,380 |  |  |  | 62,770,592 |  |  |  | 63,546,132 |  |  |  | 62,519,205 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.86 |  |  | $ | 1.20 |  |  | $ | 3.59 |  |  | $ | 2.95 |  |
| Diluted |  | $ | 1.82 |  |  | $ | 1.18 |  |  | $ | 3.51 |  |  | $ | 2.92 |  |

[0001437749-20-022373:notes:119]
(1) There were no awards with an anti-dilutive impact for the three and nine months ended  September 30, 2020 and  September 30, 2019.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-022373:notes:120]
[same as prior period, unchanged from 0001437749-20-016520:notes:115]

[0001437749-20-022373:notes:121]
The effective income tax rates for the nine months ended  September 30, 2020 and 2019 were 21.3% and 22.8%, respectively. The decrease in the effective tax rate in the current year is primarily the result of a discrete tax benefit related to equity compensation as well as the favorable mix of earnings in the jurisdictions where the Company operates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-022373:notes:122]
16. Commitments and Contingencies

[0001437749-20-022373:notes:123]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2020 and  December 31, 2019 was approximately $45,700 and $49,600, respectively.

[0001437749-20-022373:notes:124]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-022373:notes:125]
17. Subsequent Event

[0001437749-20-022373:notes:126]
On  October 7, 2020, the Company acquired Enbala Power Networks Inc. (Enbala), one of the leading providers of distributed energy optimization and control software needed to ensure the operational stability of the world’s power grids. Enbala was founded in 2003 and is headquartered in Denver, Colorado.
