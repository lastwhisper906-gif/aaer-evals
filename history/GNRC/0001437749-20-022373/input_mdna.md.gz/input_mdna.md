# GNRC MD&A — 0001437749-20-022373


## mdna

[0001437749-20-022373:mdna:1]
[same as prior period, unchanged from 0001437749-20-016520:mdna:1]

[0001437749-20-022373:mdna:2]
[same as prior period, unchanged from 0001437749-20-016520:mdna:2]

[0001437749-20-022373:mdna:3]
[same as prior period, unchanged from 0001437749-20-016520:mdna:3]

[0001437749-20-022373:mdna:4]
[same as prior period, unchanged from 0001437749-20-016520:mdna:4]

[0001437749-20-022373:mdna:5]
[same as prior period, unchanged from 0001437749-20-016520:mdna:5]

[0001437749-20-022373:mdna:6]
[same as prior period, unchanged from 0001437749-20-016520:mdna:6]

[0001437749-20-022373:mdna:7]
[same as prior period, unchanged from 0001437749-20-016520:mdna:7]

[0001437749-20-022373:mdna:8]
[same as prior period, unchanged from 0001437749-20-016520:mdna:8]

[0001437749-20-022373:mdna:9]
[same as prior period, unchanged from 0001437749-20-016520:mdna:9]

[0001437749-20-022373:mdna:10]
[same as prior period, unchanged from 0001437749-20-016520:mdna:10]

[0001437749-20-022373:mdna:11]
[same as prior period, unchanged from 0001437749-20-016520:mdna:11]

[0001437749-20-022373:mdna:12]
[same as prior period, unchanged from 0001437749-20-016520:mdna:12]

[0001437749-20-022373:mdna:13]
[same as prior period, unchanged from 0001437749-20-016520:mdna:13]

[0001437749-20-022373:mdna:14]
[same as prior period, unchanged from 0001437749-20-016520:mdna:14]

[0001437749-20-022373:mdna:15]
[same as prior period, unchanged from 0001437749-20-016520:mdna:15]

[0001437749-20-022373:mdna:16]
[same as prior period, unchanged from 0001437749-20-016520:mdna:16]

[0001437749-20-022373:mdna:17]
[same as prior period, unchanged from 0001437749-20-016520:mdna:17]

[0001437749-20-022373:mdna:18]
[same as prior period, unchanged from 0001437749-20-016520:mdna:18]

[0001437749-20-022373:mdna:19]
[same as prior period, unchanged from 0001437749-20-016520:mdna:19]

[0001437749-20-022373:mdna:20]
[same as prior period, unchanged from 0001437749-20-016520:mdna:20]

[0001437749-20-022373:mdna:21]
[same as prior period, unchanged from 0001437749-20-016520:mdna:21]

[0001437749-20-022373:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Power generation and energy storage are our key focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment markets. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost effective natural gas-fueled generators to expand into applications beyond standby power. We have also been focused on “connecting” the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product lifecycle. Other power products that we design and manufacture include light towers that provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use. During 2019, we began providing energy storage systems as a clean energy solution for residential use that captures and stores electricity from solar panels or other power sources and helps reduce home energy costs while also protecting homes from brief power outages.

[0001437749-20-022373:mdna:23]
[same as prior period, unchanged from 0001437749-20-016520:mdna:23]

[0001437749-20-022373:mdna:24]
[same as prior period, unchanged from 0001437749-20-016520:mdna:24]

[0001437749-20-022373:mdna:25]
The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers.

[0001437749-20-022373:mdna:26]
[same as prior period, unchanged from 0001437749-20-016520:mdna:26]

[0001437749-20-022373:mdna:27]
The COVID-19 pandemic has created significant uncertainty within various global markets that we serve. Several areas of our business have been and may continue to be negatively impacted, in particular our Commercial and Industrial (C&I) products around the world. The decline in oil prices is impacting our C&I mobile products demand significantly as national rental customers are deferring their capital spending. C&I stationary product shipments through our North American distributor channel and our Telecom customers have slowed due to declines in quoting activity. Additionally, the COVID-19 pandemic has caused a broad-based sharp drop in global demand for our C&I products in our International segment, which magnified the slower economic growth and geopolitical headwinds already being experienced by our international business. Given the magnitude of the downturn in demand for C&I products, we initiated a number of meaningful cost-cutting actions for this part of our business during the second quarter to better align our cost structure with customer demand. We are continuing to monitor these negative impacts on our C&I product demand closely and may implement additional measures in response.

[0001437749-20-022373:mdna:28]
With regard to our Residential products, historical experience and our current year results have shown that demand for Residential products can be defensive in nature, and tends to decouple from broader economic trends as these products are largely driven by power outages. The aging and underinvested electrical grid in the U.S. continues to be more vulnerable to elevated power outages across the country. As the vast majority of U.S. citizens are spending much more time at home due to the pandemic, it is becoming more essential to have a backup power strategy, especially as homeowners are doing more critical activities like working and learning from home. In addition, with California emerging as a major market for back-up power and our entrance into clean energy, these incremental growth drivers have helped to more than offset the impact of lower consumer spending due to COVID-19.

[0001437749-20-022373:mdna:29]
[same as prior period, unchanged from 0001437749-20-016520:mdna:29]

[0001437749-20-022373:mdna:30]
As a result of the COVID-19 pandemic, governmental authorities have implemented and are continuing to implement numerous and constantly evolving measures to try to contain the virus, such as travel bans and restrictions, limits on gatherings, quarantines, and business shutdowns. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience increased employee absences at several of our production facilities. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time.

[0001437749-20-022373:mdna:31]
The COVID-19 pandemic has disrupted the global supply chain and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant impacts or interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies. The COVID-19 pandemic has also impacted the global logistics network. Although we have experienced inbound and outbound logistics delays in moving shipments across several regions, the impact to our business thus far has not been significant. This could change if freight carriers are delayed or not able to operate.

[0001437749-20-022373:mdna:32]
[same as prior period, unchanged from 0001437749-20-016520:mdna:32]

[0001437749-20-022373:mdna:33]
Although the COVID-19 outbreak has created uncertain market conditions, we believe our business model, current cash balance, projected cash flow generation, and availability under our ABL credit facility provide us a strong balance sheet and liquidity position. This financial strength allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-20-022373:mdna:34]
[same as prior period, unchanged from 0001437749-20-016520:mdna:34]

[0001437749-20-022373:mdna:35]
[same as prior period, unchanged from 0001437749-20-016520:mdna:35]

[0001437749-20-022373:mdna:36]
[same as prior period, unchanged from 0001437749-20-016520:mdna:36]

[0001437749-20-022373:mdna:37]
[same as prior period, unchanged from 0001437749-20-016520:mdna:37]

[0001437749-20-022373:mdna:38]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 5% of the addressable market of homes in the United States. As such, a significant penetration opportunity exists for residential back-up generators. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven, and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to a variety of factors including the impending rollout of next-generation 5G wireless networks enabling new technologies and the growing importance for critical communications and other uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-20-022373:mdna:39]
[same as prior period, unchanged from 0001437749-20-016520:mdna:39]

[0001437749-20-022373:mdna:40]
[same as prior period, unchanged from 0001437749-20-016520:mdna:40]

[0001437749-20-022373:mdna:41]
California market for backup power increasing.    During 2019, the largest utility in the state of California, along with other utilities, executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were proactive measures to prevent their equipment from potentially causing catastrophic wildfires during the dry and windy season of the year. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, has resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators stand at approximately 1%. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity is among the highest in the U.S., and California regulators began mandating renewable energy on new construction starting in 2020.

[0001437749-20-022373:mdna:42]
[same as prior period, unchanged from 0001437749-20-016520:mdna:42]

[0001437749-20-022373:mdna:43]
Impact of business capital investment and other economic cycles.    The global markets for our commercial and industrial products are affected by different capital investment cycles, which can vary across the numerous regions around the world in which we operate. These markets include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-20-022373:mdna:44]
[same as prior period, unchanged from 0001437749-20-016520:mdna:44]

[0001437749-20-022373:mdna:45]
[same as prior period, unchanged from 0001437749-20-016520:mdna:45]

[0001437749-20-022373:mdna:46]
[same as prior period, unchanged from 0001437749-20-016520:mdna:46]

[0001437749-20-022373:mdna:47]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices on our freight rates, which in some cases are accepted by our customers and in other cases are absorbed by us.

[0001437749-20-022373:mdna:48]
[same as prior period, unchanged from 0001437749-20-016520:mdna:48]

[0001437749-20-022373:mdna:49]
Factors influencing interest expense and cash interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease. During the nine months ended September 30, 2020, interest expense decreased compared to the nine months ended September 30, 2019, primarily due to lower LIBOR rates and lower outstanding borrowings. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-20-022373:mdna:50]
Factors influencing provision for income taxes and cash income taxes paid.   On March 27, 2020, the U.S. government enacted the Coronavirus Aid, Relief and Economic Security Act (CARES Act) providing relief to taxpayers due to the COVID-19 pandemic. We have reviewed and implemented elements of the CARES Act based on guidance provided by the U.S. Treasury Department. However, the benefits were not material to our financial results. Despite this, we will continue to review the CARES Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-20-022373:mdna:51]
As of December 31, 2019, we had approximately $225 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $57 million through 2021, assuming continued profitability of our U.S. business and a combined federal and state tax rate of 25.3%. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million in 2020 and $102 million in 2021, which is expected to generate annual cash tax savings of $31 million in 2020 and $26 million in 2021. Based on current business plans, we believe that our cash tax obligations through 2021 will be significantly reduced by these tax attributes, after which our cash tax obligation will increase. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to our condensed consolidated financial statements.

[0001437749-20-022373:mdna:52]
[same as prior period, unchanged from 0001437749-20-016520:mdna:52]

[0001437749-20-022373:mdna:53]
[same as prior period, unchanged from 0001437749-20-016520:mdna:56]

[0001437749-20-022373:mdna:54]
Three months ended September 30, 2020 compared to the three months ended September 30, 2019

[0001437749-20-022373:mdna:55]
[same as prior period, unchanged from 0001437749-20-016520:mdna:58]

[0001437749-20-022373:mdna:56]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 100,220 |  |  |  | 16.7 | % |
| Costs of goods sold |  |  | 425,206 |  |  |  | 383,618 |  |  |  | 41,588 |  |  |  | 10.8 | % |
| Gross profit |  |  | 276,149 |  |  |  | 217,517 |  |  |  | 58,632 |  |  |  | 27.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 60,901 |  |  |  | 59,356 |  |  |  | 1,545 |  |  |  | 2.6 | % |
| Research and development |  |  | 20,658 |  |  |  | 17,603 |  |  |  | 3,055 |  |  |  | 17.4 | % |
| General and administrative |  |  | 31,061 |  |  |  | 27,596 |  |  |  | 3,465 |  |  |  | 12.6 | % |
| Amortization of intangible assets |  |  | 7,892 |  |  |  | 7,406 |  |  |  | 486 |  |  |  | 6.6 | % |
| Total operating expenses |  |  | 120,512 |  |  |  | 111,961 |  |  |  | 8,551 |  |  |  | 7.6 | % |
| Income from operations |  |  | 155,637 |  |  |  | 105,556 |  |  |  | 50,081 |  |  |  | 47.4 | % |
| Total other expense, net |  |  | (8,352 | ) |  |  | (10,595 | ) |  |  | 2,243 |  |  |  | -21.2 | % |
| Income before provision for income taxes |  |  | 147,285 |  |  |  | 94,961 |  |  |  | 52,324 |  |  |  | 55.1 | % |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 11,986 |  |  |  | 59.7 | % |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 40,338 |  |  |  | 53.9 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | 942 |  |  |  | -139.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 39,396 |  |  |  | 52.1 | % |

[0001437749-20-022373:mdna:57]
[same as prior period, unchanged from 0001437749-20-016520:mdna:60]

[0001437749-20-022373:mdna:58]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 606,875 |  |  | $ | 494,810 |  |  | $ | 112,065 |  |  |  | 22.6 | % |
| International |  |  | 94,480 |  |  |  | 106,325 |  |  |  | (11,845 | ) |  |  | -11.1 | % |
| Total net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 100,220 |  |  |  | 16.7 | % |

[0001437749-20-022373:mdna:59]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 171,359 |  |  | $ | 120,833 |  |  | $ | 50,526 |  |  |  | 41.8 | % |
| International |  |  | 7,419 |  |  |  | 5,120 |  |  |  | 2,299 |  |  |  | 44.9 | % |
| Total Adjusted EBITDA |  | $ | 178,778 |  |  | $ | 125,953 |  |  | $ | 52,825 |  |  |  | 41.9 | % |

[0001437749-20-022373:mdna:60]
[same as prior period, unchanged from 0001437749-20-016520:mdna:63]

[0001437749-20-022373:mdna:61]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 458,877 |  |  | $ | 335,029 |  |  | $ | 123,848 |  |  |  | 37.0 | % |
| Commercial & industrial products |  |  | 176,200 |  |  |  | 214,905 |  |  |  | (38,705 | ) |  |  | -18.0 | % |
| Other |  |  | 66,278 |  |  |  | 51,201 |  |  |  | 15,077 |  |  |  | 29.4 | % |
| Total net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 100,220 |  |  |  | 16.7 | % |

[0001437749-20-022373:mdna:62]
Net sales.    Domestic segment sales increased 22.6% to $606.9 million as compared to $494.8 million in the prior year quarter. As a result of heightened awareness of the need for backup power, shipments of home standby generators experienced strong growth during the quarter. In addition, significant power outage activity also drove elevated shipments of portable generators and aftermarket service parts. Shipments of the recently launched PWRcell energy storage system also had a strong impact on growth following the expected recovery in the solar market during the third quarter. This residential products growth was partially offset by continued weakness in sales of C&I mobile products following the onset of the COVID-19 pandemic and lower oil prices.

[0001437749-20-022373:mdna:63]
International segment sales decreased 11.1% to $94.5 million as compared to $106.3 million in the prior year quarter. The decline was driven by continued broad-based weakness in global C&I product demand caused by the COVID-19 pandemic.

[0001437749-20-022373:mdna:64]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $115.0 million as compared to $75.6 million in the prior year third quarter. The increase was primarily driven by increased sales volumes and related favorable sales mix.

[0001437749-20-022373:mdna:65]
Gross profit.    Gross profit margin for the third quarter of 2020 was 39.4% compared to 36.2% in the prior year third quarter. The gross profit margin increase was primarily driven by favorable sales mix from significantly higher shipments of residential products and lower mix of C&I products.

[0001437749-20-022373:mdna:66]
Operating expenses.   Operating expenses increased $8.6 million, or 7.6%, as compared to the prior year third quarter. The increase was primarily driven by incremental spend related to clean energy products and higher incentive compensation. These increases were partially offset by lower advertising and promotional costs, along with a reduction in operating expenses for the International segment as a result of restructuring actions initiated in the second quarter of 2020.

[0001437749-20-022373:mdna:67]
Other expense.    The decrease in Other expense, net was primarily driven by a reduction in interest expense due to lower LIBOR rates and lower outstanding borrowings.

[0001437749-20-022373:mdna:68]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2020 and 2019 were 21.8% and 21.1%, respectively. The increase in the effective tax rate was primarily due to the prior year having more favorable discrete tax items compared to the current year quarter, which was partially offset by an overall more favorable mix of pretax income in the current year quarter.

[0001437749-20-022373:mdna:69]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the third quarter of 2020 was $171.4 million, or 28.2% of net sales, as compared to $120.8 million, or 24.4% of net sales, in the prior year quarter. This margin increase was driven by favorable sales mix and higher operating leverage from the significant revenue growth.

[0001437749-20-022373:mdna:70]
Adjusted EBITDA for the International segment in the third quarter of 2020, before deducting for non-controlling interests, was $7.4 million, or 7.9% of net sales, as compared to $5.1 million, or 4.8% of net sales, in the prior year quarter. Decreased operating leverage on the lower sales volumes was more than offset by lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020.

[0001437749-20-022373:mdna:71]
Adjusted Net Income.    Adjusted Net Income of $132.9 million for the three months ended September 30, 2020 increased 47.7% from $90.0 million for the three months ended September 30, 2019, due to the factors outlined above.

[0001437749-20-022373:mdna:72]
[same as prior period, unchanged from 0001437749-20-016520:mdna:75]

[0001437749-20-022373:mdna:73]
Nine months ended September 30, 2020 compared to the nine months ended September 30, 2019

[0001437749-20-022373:mdna:74]
[same as prior period, unchanged from 0001437749-20-016520:mdna:77]

[0001437749-20-022373:mdna:75]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |  | $ | 110,714 |  |  |  | 6.9 | % |
| Costs of goods sold |  |  | 1,066,666 |  |  |  | 1,037,874 |  |  |  | 28,792 |  |  |  | 2.8 | % |
| Gross profit |  |  | 657,452 |  |  |  | 575,530 |  |  |  | 81,922 |  |  |  | 14.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 178,566 |  |  |  | 158,954 |  |  |  | 19,612 |  |  |  | 12.3 | % |
| Research and development |  |  | 58,762 |  |  |  | 48,906 |  |  |  | 9,856 |  |  |  | 20.2 | % |
| General and administrative |  |  | 88,732 |  |  |  | 80,016 |  |  |  | 8,716 |  |  |  | 10.9 | % |
| Amortization of intangible assets |  |  | 23,340 |  |  |  | 19,999 |  |  |  | 3,341 |  |  |  | 16.7 | % |
| Total operating expenses |  |  | 349,400 |  |  |  | 307,875 |  |  |  | 41,525 |  |  |  | 13.5 | % |
| Income from operations |  |  | 308,052 |  |  |  | 267,655 |  |  |  | 40,397 |  |  |  | 15.1 | % |
| Total other expense, net |  |  | (25,847 | ) |  |  | (31,407 | ) |  |  | 5,560 |  |  |  | -17.7 | % |
| Income before provision for income taxes |  |  | 282,205 |  |  |  | 236,248 |  |  |  | 45,957 |  |  |  | 19.5 | % |
| Provision for income taxes |  |  | 59,967 |  |  |  | 53,876 |  |  |  | 6,091 |  |  |  | 11.3 | % |
| Net income |  |  | 222,238 |  |  |  | 182,372 |  |  |  | 39,866 |  |  |  | 21.9 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | (3,337 | ) |  |  | (21 | ) |  |  | (3,316 | ) |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 225,575 |  |  | $ | 182,393 |  |  | $ | 43,182 |  |  |  | 23.7 | % |

[0001437749-20-022373:mdna:76]
[same as prior period, unchanged from 0001437749-20-016520:mdna:79]

[0001437749-20-022373:mdna:77]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,443,680 |  |  | $ | 1,272,840 |  |  | $ | 170,840 |  |  |  | 13.4 | % |
| International |  |  | 280,438 |  |  |  | 340,564 |  |  |  | (60,126 | ) |  |  | -17.7 | % |
| Total net sales |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |  | $ | 110,714 |  |  |  | 6.9 | % |

[0001437749-20-022373:mdna:78]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 374,065 |  |  | $ | 305,747 |  |  | $ | 68,318 |  |  |  | 22.3 | % |
| International |  |  | 13,877 |  |  |  | 19,220 |  |  |  | (5,343 | ) |  |  | -27.8 | % |
| Total Adjusted EBITDA |  | $ | 387,942 |  |  | $ | 324,967 |  |  | $ | 62,975 |  |  |  | 19.4 | % |

[0001437749-20-022373:mdna:79]
[same as prior period, unchanged from 0001437749-20-016520:mdna:82]

[0001437749-20-022373:mdna:80]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,057,848 |  |  | $ | 821,233 |  |  | $ | 236,615 |  |  |  | 28.8 | % |
| Commercial & industrial products |  |  | 503,156 |  |  |  | 654,458 |  |  |  | (151,302 | ) |  |  | -23.1 | % |
| Other |  |  | 163,114 |  |  |  | 137,713 |  |  |  | 25,401 |  |  |  | 18.4 | % |
| Total net sales |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |  | $ | 110,714 |  |  |  | 6.9 | % |

[0001437749-20-022373:mdna:81]
Net sales.    Domestic segment sales increased 13.4% to $1,443.7 million from $1,272.8 million in the prior year. The current year experienced strong growth in shipments of home standby and portable generators as elevated outage activity and nationwide stay-at-home orders heightened consumer awareness of power reliability concerns. Chore products sold directly to consumers were also strong during the current year as homeowners increased outdoor project activity while spending more time at home. In addition, shipments of the recently launched PWRcell energy storage system had a strong impact on growth. This residential products growth was partially offset by weakness in C&I mobile products sales following the onset of the COVID-19 pandemic and lower oil prices, as well as lower shipments of C&I products to national telecom customers as compared to a strong prior year comparison.

[0001437749-20-022373:mdna:82]
International sales for the nine months ended September 30, 2020 decreased 17.7% compared to the prior year period. The decline was primarily driven by a broad-based sharp drop in global demand caused by the COVID-19 pandemic and its impact on certain key regions of the world, which magnified the slower economic growth and geopolitical headwinds already being experienced prior to the pandemic.

[0001437749-20-022373:mdna:83]
[same as prior period, unchanged from 0001437749-20-016520:mdna:86]

[0001437749-20-022373:mdna:84]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $225.6 million as compared to $182.4 million in the prior year period. The current year net income includes $12.5 million of pre-tax charges relating to business optimization, restructuring, and other costs to address the impact of the COVID-19 pandemic and decline in oil prices. The cost actions taken include certain headcount reductions, non-cash asset write-downs, and other charges. The charges, which primarily relate to C&I products, consist of $6.6 million classified within costs of goods sold and $5.9 million classified within operating expenses.

[0001437749-20-022373:mdna:85]
Gross profit.    Gross profit margin for the nine months ended September 30, 2020 was 38.1% compared to 35.7% in the prior year period. The current year period includes the impact of the aforementioned $6.6 million of charges classified within costs of goods sold. The increase was primarily driven by favorable sales mix from significantly higher shipments of home standby generators, along with lower mix of C&I products.

[0001437749-20-022373:mdna:86]
Operating expenses.   Operating expenses increased $41.5 million, or 13.5%, as compared to the prior year period. The current year period includes the impact of the aforementioned $5.9 million of charges classified within operating expenses. In addition to the COVID-19 charges, the increase in operating expenses was primarily driven by incremental spend related to Clean Energy products, incentive compensation and other employee costs, higher marketing spend, and additional intangible amortization.

[0001437749-20-022373:mdna:87]
Other expense.    The decrease in Other expense, net was primarily driven by a reduction in interest expense due to lower LIBOR rates and lower outstanding borrowings.

[0001437749-20-022373:mdna:88]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2020 and 2019 were 21.3% and 22.8%, respectively. The decrease in the effective tax rate in the current year is primarily the result of a discrete tax benefit related to equity compensation as well as the mix of earnings in the jurisdictions in which we operate.

[0001437749-20-022373:mdna:89]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $374.1 million, or 25.9% of net sales, as compared to $305.7 million in the prior year period, or 24.0% of net sales. This margin increase was driven by favorable sales mix, partially offset by the aforementioned higher operating expense investments.

[0001437749-20-022373:mdna:90]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $13.9 million, or 4.9% of net sales, as compared to $19.2 million in the prior year, or 5.6% of net sales. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline, partially offset by lower operating expenses as a result of restructuring activities initiated in the current year.

[0001437749-20-022373:mdna:91]
Adjusted Net Income.    Adjusted Net Income of $276.5 million for the nine months ended September 30, 2020 increased 24.9% from $221.4 million for the nine months ended September 30, 2019, due to the factors outlined above.

[0001437749-20-022373:mdna:92]
[same as prior period, unchanged from 0001437749-20-016520:mdna:95]

[0001437749-20-022373:mdna:93]
[same as prior period, unchanged from 0001437749-20-016520:mdna:96]

[0001437749-20-022373:mdna:94]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-20-022373:mdna:95]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. Following several amendments, the Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of September 30, 2020, our secured leverage ratio was 1.26 to 1.00 times, and we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-022373:mdna:96]
Our credit agreements also provide for the $300.0 million ABL Facility. The ABL Facility matures June 12, 2023 and bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of September 30, 2020, there were $5.3 million of borrowings outstanding and $294.3 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of September 30, 2020.

[0001437749-20-022373:mdna:97]
As of September 30, 2020, we had $808.2 million of liquidity comprised of $513.9 million of cash and equivalents and $294.3 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan until December 2026. We believe we have a strong liquidity position that allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-20-022373:mdna:98]
In September 2018, the Company’s Board of Directors approved a $250 million stock repurchase program that is due to expire in the fourth quarter of 2020. In September 2020, the Company’s Board of Directors approved another stock repurchase program, which will commence upon the expiration of the previous stock repurchase program, and allows for the repurchase of up to $250 million of its common stock over a 24 month period from time to time; in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. During the nine months ended September 30, 2020 and 2019, no share repurchases were made. Since the inception of all stock repurchase programs starting in August 2015, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-20-022373:mdna:99]
See Note 12, “Credit Agreements,” and Note 13, "Stock Repurchase Program" to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-20-022373:mdna:100]
[same as prior period, unchanged from 0001437749-20-016520:mdna:103]

[0001437749-20-022373:mdna:101]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our cash on hand, provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay down principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-20-022373:mdna:102]
[same as prior period, unchanged from 0001437749-20-016520:mdna:105]

[0001437749-20-022373:mdna:103]
Nine months ended September 30, 2020 compared to the nine months ended September 30, 2019

[0001437749-20-022373:mdna:104]
[same as prior period, unchanged from 0001437749-20-016520:mdna:107]

[0001437749-20-022373:mdna:105]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 268,310 |  |  | $ | 133,802 |  |  | $ | 134,508 |  |  |  | 100.5 | % |
| Net cash used in investing activities |  |  | (54,731 | ) |  |  | (164,191 | ) |  |  | 109,460 |  |  |  | 66.7 | % |
| Net cash (used in) provided by financing activities |  |  | (21,596 | ) |  |  | 22,178 |  |  |  | (43,774 | ) |  |  | 197.4 | % |

[0001437749-20-022373:mdna:106]
The increase in net cash provided by operating activities was primarily due to higher sales volumes and resulting higher operating earnings in the current year, as well as a significant working capital investment that was made in the prior year which did not repeat in the current year.

[0001437749-20-022373:mdna:107]
Net cash used in investing activities for the nine months ended September 30, 2020 primarily represents cash payments of $33.9 million related to the purchase of property and equipment and $22.8 million related to the acquisition of businesses. Net cash used in investing activities for the nine months ended September 30, 2019 primarily represents cash payments of $120.9 million related to the acquisition of businesses and $45.4 million related to the purchase of property and equipment.

[0001437749-20-022373:mdna:108]
Net cash used in financing activities for the nine months ended September 30, 2020 primarily represents $214.4 million of debt repayments ($210.8 million of short-term borrowings and $3.6 million of long-term borrowings and finance lease obligations), $13.5 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $198.1 million from short-term borrowings and $12 million from the exercise of stock options.

[0001437749-20-022373:mdna:109]
Net cash provided by financing activities for the nine months ended September 30, 2019 primarily represents $68.8 million of cash proceeds from short-term borrowings partially offset by $48.5 million of debt repayments ($45.4 million of short-term borrowings and $3.1 million of long-term borrowings and finance lease obligations).

[0001437749-20-022373:mdna:110]
[same as prior period, unchanged from 0001437749-20-016520:mdna:113]

[0001437749-20-022373:mdna:111]
[same as prior period, unchanged from 0001437749-20-016520:mdna:114]

[0001437749-20-022373:mdna:112]
[same as prior period, unchanged from 0001437749-20-016520:mdna:115]

[0001437749-20-022373:mdna:113]
[same as prior period, unchanged from 0001437749-20-016520:mdna:116]

[0001437749-20-022373:mdna:114]
[same as prior period, unchanged from 0001437749-20-016520:mdna:117]

[0001437749-20-022373:mdna:115]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2019, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-20-022373:mdna:116]
[same as prior period, unchanged from 0001437749-20-016520:mdna:119]

[0001437749-20-022373:mdna:117]
[same as prior period, unchanged from 0001437749-20-016520:mdna:120]

[0001437749-20-022373:mdna:118]
[same as prior period, unchanged from 0001437749-20-016520:mdna:121]

[0001437749-20-022373:mdna:119]
[same as prior period, unchanged from 0001437749-20-016520:mdna:122]

[0001437749-20-022373:mdna:120]
As previously disclosed in our May 5, 2020 filing on Form 10-Q in the critical accounting policies section of Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations," we determined that the goodwill for our Latin America and Generac Mobile Products reporting units was at risk for impairment should there be deterioration of current projections or changes to discount rates used.  While we have concluded there to be no indicators of impairment during the second and third quarters of 2020 and do not anticipate any material impairments, any business deterioration or market pressures could cause our sales, earnings, and cash flows to decline below our current projections and cause goodwill to be impaired for these reporting units.

[0001437749-20-022373:mdna:121]
[same as prior period, unchanged from 0001437749-20-016520:mdna:124]

[0001437749-20-022373:mdna:122]
[same as prior period, unchanged from 0001437749-20-016520:mdna:125]

[0001437749-20-022373:mdna:123]
[same as prior period, unchanged from 0001437749-20-016520:mdna:126]

[0001437749-20-022373:mdna:124]
[same as prior period, unchanged from 0001437749-20-016520:mdna:127]

[0001437749-20-022373:mdna:125]
[same as prior period, unchanged from 0001437749-20-016520:mdna:128]

[0001437749-20-022373:mdna:126]
[same as prior period, unchanged from 0001437749-20-016520:mdna:129]

[0001437749-20-022373:mdna:127]
[same as prior period, unchanged from 0001437749-20-016520:mdna:130]

[0001437749-20-022373:mdna:128]
[same as prior period, unchanged from 0001437749-20-016520:mdna:131]

[0001437749-20-022373:mdna:129]
[same as prior period, unchanged from 0001437749-20-016520:mdna:132]

[0001437749-20-022373:mdna:130]
[same as prior period, unchanged from 0001437749-20-016520:mdna:133]

[0001437749-20-022373:mdna:131]
[same as prior period, unchanged from 0001437749-20-016520:mdna:134]

[0001437749-20-022373:mdna:132]
[same as prior period, unchanged from 0001437749-20-016520:mdna:135]

[0001437749-20-022373:mdna:133]
[same as prior period, unchanged from 0001437749-20-016520:mdna:136]

[0001437749-20-022373:mdna:134]
[same as prior period, unchanged from 0001437749-20-016520:mdna:137]

[0001437749-20-022373:mdna:135]
[same as prior period, unchanged from 0001437749-20-016520:mdna:138]

[0001437749-20-022373:mdna:136]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-20-022373:mdna:137]
[same as prior period, unchanged from 0001437749-20-016520:mdna:140]

[0001437749-20-022373:mdna:138]
[same as prior period, unchanged from 0001437749-20-016520:mdna:141]

[0001437749-20-022373:mdna:139]
[same as prior period, unchanged from 0001437749-20-016520:mdna:142]

[0001437749-20-022373:mdna:140]
[same as prior period, unchanged from 0001437749-20-016520:mdna:143]

[0001437749-20-022373:mdna:141]
[same as prior period, unchanged from 0001437749-20-016520:mdna:144]

[0001437749-20-022373:mdna:142]
[same as prior period, unchanged from 0001437749-20-016520:mdna:145]

[0001437749-20-022373:mdna:143]
[same as prior period, unchanged from 0001437749-20-016520:mdna:146]

[0001437749-20-022373:mdna:144]
[same as prior period, unchanged from 0001437749-20-016520:mdna:147]

[0001437749-20-022373:mdna:145]
[same as prior period, unchanged from 0001437749-20-016520:mdna:148]

[0001437749-20-022373:mdna:146]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-20-022373:mdna:147]
[same as prior period, unchanged from 0001437749-20-016520:mdna:150]

[0001437749-20-022373:mdna:148]
[same as prior period, unchanged from 0001437749-20-016520:mdna:151]

[0001437749-20-022373:mdna:149]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | (3,337 | ) |  |  | (21 | ) |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 222,238 |  |  |  | 182,372 |  |
| Interest expense |  |  | 8,096 |  |  |  | 10,704 |  |  |  | 25,081 |  |  |  | 31,428 |  |
| Depreciation and amortization |  |  | 17,168 |  |  |  | 15,494 |  |  |  | 50,087 |  |  |  | 42,841 |  |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 59,967 |  |  |  | 53,876 |  |
| Non-cash write-down and other adjustments (a) |  |  | 477 |  |  |  | 347 |  |  |  | 1,868 |  |  |  | 673 |  |
| Non-cash share-based compensation expense (b) |  |  | 4,353 |  |  |  | 3,549 |  |  |  | 14,327 |  |  |  | 11,477 |  |
| Transaction costs and credit facility fees (c) |  |  | 568 |  |  |  | 358 |  |  |  | 1,160 |  |  |  | 2,047 |  |
| Business optimization and other charges (d) |  |  | 531 |  |  |  | 567 |  |  |  | 12,503 |  |  |  | 809 |  |
| Other |  |  | 300 |  |  |  | (27 | ) |  |  | 711 |  |  |  | (556 | ) |
| Adjusted EBITDA |  |  | 178,778 |  |  |  | 125,953 |  |  |  | 387,942 |  |  |  | 324,967 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 920 |  |  |  | 909 |  |  |  | 950 |  |  |  | 3,722 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 177,858 |  |  | $ | 125,044 |  |  | $ | 386,992 |  |  | $ | 321,245 |  |

[0001437749-20-022373:mdna:150]
[same as prior period, unchanged from 0001437749-20-016520:mdna:153]

[0001437749-20-022373:mdna:151]
[same as prior period, unchanged from 0001437749-20-016520:mdna:154]

[0001437749-20-022373:mdna:152]
[same as prior period, unchanged from 0001437749-20-016520:mdna:155]

[0001437749-20-022373:mdna:153]
[same as prior period, unchanged from 0001437749-20-016520:mdna:156]

[0001437749-20-022373:mdna:154]
[same as prior period, unchanged from 0001437749-20-016520:mdna:157]

[0001437749-20-022373:mdna:155]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-20-022373:mdna:156]
(d)  For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products. For the three and nine months ended September 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities.

[0001437749-20-022373:mdna:157]
[same as prior period, unchanged from 0001437749-20-016520:mdna:160]

[0001437749-20-022373:mdna:158]
[same as prior period, unchanged from 0001437749-20-016520:mdna:161]

[0001437749-20-022373:mdna:159]
[same as prior period, unchanged from 0001437749-20-016520:mdna:162]

[0001437749-20-022373:mdna:160]
[same as prior period, unchanged from 0001437749-20-016520:mdna:163]

[0001437749-20-022373:mdna:161]
[same as prior period, unchanged from 0001437749-20-016520:mdna:164]

[0001437749-20-022373:mdna:162]
[same as prior period, unchanged from 0001437749-20-016520:mdna:165]

[0001437749-20-022373:mdna:163]
[same as prior period, unchanged from 0001437749-20-016520:mdna:166]

[0001437749-20-022373:mdna:164]
[same as prior period, unchanged from 0001437749-20-016520:mdna:167]

[0001437749-20-022373:mdna:165]
[same as prior period, unchanged from 0001437749-20-016520:mdna:168]

[0001437749-20-022373:mdna:166]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | (3,337 | ) |  |  | (21 | ) |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 222,238 |  |  |  | 182,372 |  |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 59,967 |  |  |  | 53,876 |  |
| Income before provision for income taxes |  |  | 147,285 |  |  |  | 94,961 |  |  |  | 282,205 |  |  |  | 236,248 |  |
| Amortization of intangible assets |  |  | 7,892 |  |  |  | 7,406 |  |  |  | 23,340 |  |  |  | 19,999 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 654 |  |  |  | 1,221 |  |  |  | 1,940 |  |  |  | 3,597 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 381 |  |  |  | 165 |  |  |  | 612 |  |  |  | 1,373 |  |
| Business optimization and other charges |  |  | 531 |  |  |  | 567 |  |  |  | 12,503 |  |  |  | 809 |  |
| Adjusted net income before provision for income taxes |  |  | 156,743 |  |  |  | 104,320 |  |  |  | 320,600 |  |  |  | 262,026 |  |
| Cash income tax expense (b) |  |  | (23,620 | ) |  |  | (15,083 | ) |  |  | (44,842 | ) |  |  | (39,698 | ) |
| Adjusted net income |  |  | 133,123 |  |  |  | 89,237 |  |  |  | 275,758 |  |  |  | 222,328 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 198 |  |  |  | (738 | ) |  |  | (725 | ) |  |  | 958 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 132,925 |  |  | $ | 89,975 |  |  | $ | 276,483 |  |  | $ | 221,370 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.08 |  |  | $ | 1.43 |  |  | $ | 4.35 |  |  | $ | 3.54 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,761,380 |  |  |  | 62,770,592 |  |  |  | 63,546,132 |  |  |  | 62,519,205 |  |

[0001437749-20-022373:mdna:167]
[same as prior period, unchanged from 0001437749-20-016520:mdna:170]

[0001437749-20-022373:mdna:168]
(b) Amounts for the three and nine months ended September 30, 2020 are now based on an anticipated cash income tax rate of approximately 16% for the year ending December 31, 2020. Amounts for the three and nine months ended September 30, 2019 were based on an anticipated cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-20-022373:mdna:169]
[same as prior period, unchanged from 0001437749-20-016520:mdna:172]

[0001437749-20-022373:mdna:170]
[same as prior period, unchanged from 0001437749-20-016520:mdna:173]
