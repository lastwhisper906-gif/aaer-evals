# GNRC 8-K — 0001437749-20-021729 filed 2020-10-28

## item codes, every 8-K on or before 2020-11-03

- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2020-11-03

- none on or before 2020-11-03

## item 2.02 — earnings release, exhibit 99.1

[0001437749-20-021729:8k_2_02:1]
EX-99.1
2
ex_208968.htm
EXHIBIT 99.1

[0001437749-20-021729:8k_2_02:2]
ex_208968.htm

[0001437749-20-021729:8k_2_02:3]
Exhibit 99.1

[0001437749-20-021729:8k_2_02:4]
Generac Reports Record Third Quarter 2020 Results

[0001437749-20-021729:8k_2_02:5]
All-time record results driven by unprecedented residential product demand; 2020 outlook further increased due to continued strength from key mega-trends

[0001437749-20-021729:8k_2_02:6]
WAUKESHA, WISCONSIN (October 28, 2020) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2020 and provided an update on its outlook for the full year 2020.

[0001437749-20-021729:8k_2_02:7]
Third Quarter 2020 Highlights

[0001437749-20-021729:8k_2_02:8]
| ● | Net sales increased approximately 17% to $701 million during the third quarter of 2020 as compared to $601 million in the prior-year third quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 16%. |

[0001437749-20-021729:8k_2_02:9]
|  | - | Residential product sales increased 37% to $459 million as compared to $335 million last year. |

[0001437749-20-021729:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased 18% to $176 million as compared to $215 million in the prior year. |

[0001437749-20-021729:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $115 million, or $1.82 per share, as compared to $76 million, or $1.18 per share, for the same period of 2019. |

[0001437749-20-021729:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $133 million, or $2.08 per share, as compared to $90 million, or $1.43 per share, in the third quarter of 2019. |

[0001437749-20-021729:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $179 million, or 25.5% of net sales, as compared to $126 million, or 21.0% of net sales, in the prior year. |

[0001437749-20-021729:8k_2_02:14]
| ● | Cash flow from operations was $155 million as compared to $111 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $148 million as compared to $101 million for 2019. The increase was primarily due to higher sales volumes and resulting net income. |

[0001437749-20-021729:8k_2_02:15]
| ● | The Company is increasing its full-year 2020 sales growth guidance to now be approximately 10 to 12% of year-over-year growth, which is an increase from the baseline growth guidance of 5 to 8% previously expected. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be approximately 22.5 to 23.0%, which is an increase from the 21.5 to 22.0% previously expected. |

[0001437749-20-021729:8k_2_02:16]
| ● | On July 1st, 2020, the Company closed on the acquisition of Energy Systems, its industrial distributor located in Northern California. |

[0001437749-20-021729:8k_2_02:17]
| ● | As previously announced on September 1st, 2020, the Company acquired the assets of Mean Green Products, LLC. Headquartered in Ross, Ohio, Mean Green is a leading manufacturer of an innovative commercial line of battery powered turf care products. |

[0001437749-20-021729:8k_2_02:18]
| ● | On October 7th, we closed on the acquisition of Enbala Power Networks Inc. (“Enbala”). Based in Denver, Colorado, Enbala is one of the leading providers of distributed energy optimization and control software needed to ensure the operational stability of the world’s power grids. |

[0001437749-20-021729:8k_2_02:19]
“Third quarter revenue and adjusted EBITDA far exceeded all-time records led by dramatic growth in sales of home standby and portable generators,” said Aaron Jagdfeld, President and Chief Executive Officer. “Power outage activity was much higher during the quarter driven by more extreme and severe weather. When combined with the “Home as a Sanctuary” trend that we began seeing at the onset of the COVID-19 pandemic, demand for home standby generators reached unprecedented levels during the quarter. Shipments of our PWRcell energy storage systems recovered during the third quarter and increased significantly from lower levels in the second quarter, which were impacted by a slowdown in solar installations due to the pandemic. As expected, our C&I products were also negatively impacted, however, we realized some meaningful benefits from our recent cost-reduction efforts that were initiated in the second quarter.”

[0001437749-20-021729:8k_2_02:20]
Jagdfeld continued, “We announced several strategic acquisitions in recent months that enable us to enter exciting new markets. In July, we closed on the acquisition of our industrial distributor in Northern California, Energy Systems, to enhance our ability to serve this very large, rapidly growing power generation market. In September, we entered the battery-powered commercial mower market with Mean Green Products, which will help accelerate the electrification of our chore products. In October, we entered the emerging market for “grid services” through the acquisition of Enbala Power Networks, which plays into another secular trend involving the evolution of the traditional electric utility model and further advances our capabilities as an energy technology solutions company.”

[0001437749-20-021729:8k_2_02:21]
Additional Third Quarter 2020 Consolidated Highlights

[0001437749-20-021729:8k_2_02:22]
Gross profit margin improved 320 basis points to 39.4% compared to 36.2% in the prior-year third quarter. The increase was primarily driven by favorable sales mix from significantly higher shipments of residential products and a lower mix of C&I products.

[0001437749-20-021729:8k_2_02:23]
Operating expenses increased $8.6 million, or 7.6%, as compared to the third quarter of 2019. The increase was primarily driven by incremental spend related to clean energy products and higher incentive compensation. These increases were partially offset by lower advertising and promotional costs, along with a reduction in operating expenses for the International segment as a result of restructuring actions initiated in the second quarter of 2020.

[0001437749-20-021729:8k_2_02:24]
Provision for income taxes for the current year quarter was $32.1 million, or an effective tax rate of 21.8%, as compared to $20.1 million, or a 21.1% effective tax rate, for the prior year. The increase in effective tax rate was primarily due to the prior year having more favorable discrete tax items compared to the current year quarter, which was partially offset by an overall more favorable mix of pretax income in the current year quarter.

[0001437749-20-021729:8k_2_02:25]
Business Segment Results

[0001437749-20-021729:8k_2_02:26]
Domestic Segment

[0001437749-20-021729:8k_2_02:27]
Domestic segment sales increased 22.6% to $606.9 million as compared to $494.8 million in the prior year quarter. As a result of the heightened awareness of the need for backup power, shipments of home standby generators experienced very strong growth during the quarter. In addition, significant power outage activity also drove elevated shipments of portable generators and aftermarket service parts. Shipments of the recently launched PWRcell energy storage system also had a strong impact on growth following the expected recovery in the solar market during the third quarter. This residential products growth was partially offset by continued weakness in sales of C&I mobile products following the onset of the COVID-19 pandemic and lower oil prices.

[0001437749-20-021729:8k_2_02:28]
Adjusted EBITDA for the segment was $171.4 million, or 28.2% of net sales, as compared to $120.8 million in the prior year, or 24.4% of net sales. This margin increase was driven by favorable sales mix and higher operating leverage from the significant revenue growth.

[0001437749-20-021729:8k_2_02:29]
International Segment

[0001437749-20-021729:8k_2_02:30]
International segment sales decreased 11.1% to $94.5 million as compared to $106.3 million in the prior year quarter. The decline was driven by continued broad-based weakness in global C&I product demand caused by the COVID-19 pandemic.

[0001437749-20-021729:8k_2_02:31]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $7.4 million, or 7.9% of net sales, as compared to $5.1 million, or 4.8% of net sales, in the prior year. Decreased operating leverage on the lower sales volumes was more than offset by lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020.

[0001437749-20-021729:8k_2_02:32]
Updated 2020 Outlook

[0001437749-20-021729:8k_2_02:33]
Given the higher power outage environment thus far in second half of 2020, along with increased production rates in the fourth quarter for home standby generators, the Company is raising its prior guidance for revenue growth for full-year 2020, and now expects an increase of approximately 10 to 12% compared to the prior year. This compares to the previous baseline guidance of 5 to 8% revenue growth.

[0001437749-20-021729:8k_2_02:34]
As a result of the higher revenue expectations, net income margin, before deducting for non-controlling interests, is now expected to be approximately 13.0 to 13.5% for the full-year 2020, which is an increase from the prior expectation of between 12.0% to 12.5%. The corresponding adjusted EBITDA margin is now expected to be approximately 22.5 to 23.0%, which is an increase from the 21.5% to 22.0% previously expected.

[0001437749-20-021729:8k_2_02:35]
Conference Call and Webcast

[0001437749-20-021729:8k_2_02:36]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, October 28, 2020 to discuss third quarter 2020 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 2669599.

[0001437749-20-021729:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-20-021729:8k_2_02:38]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 2669599. The telephonic replay will be available for 7 days.

[0001437749-20-021729:8k_2_02:39]
About Generac

[0001437749-20-021729:8k_2_02:40]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-20-021729:8k_2_02:41]
Forward-looking Information

[0001437749-20-021729:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-20-021729:8k_2_02:43]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-20-021729:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-20-021729:8k_2_02:45]
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |

[0001437749-20-021729:8k_2_02:46]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-20-021729:8k_2_02:47]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-20-021729:8k_2_02:48]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-20-021729:8k_2_02:49]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-20-021729:8k_2_02:50]
|  | ● | our dependence on our distribution network; |

[0001437749-20-021729:8k_2_02:51]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-20-021729:8k_2_02:52]
|  | ● | loss of our key management and employees; |

[0001437749-20-021729:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-20-021729:8k_2_02:54]
|  | ● | failures or security breaches of our networks or information technology systems; |

[0001437749-20-021729:8k_2_02:55]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations; and |

[0001437749-20-021729:8k_2_02:56]
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and may or will continue to adversely affect our operations, supply chain, distribution, and demand for certain of our products and services. |

[0001437749-20-021729:8k_2_02:57]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2019 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-20-021729:8k_2_02:58]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-20-021729:8k_2_02:59]
Non-GAAP Financial Metrics

[0001437749-20-021729:8k_2_02:60]
Core Sales

[0001437749-20-021729:8k_2_02:61]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-20-021729:8k_2_02:62]
Adjusted EBITDA

[0001437749-20-021729:8k_2_02:63]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-20-021729:8k_2_02:64]
Adjusted Net Income

[0001437749-20-021729:8k_2_02:65]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-20-021729:8k_2_02:66]
Free Cash Flow

[0001437749-20-021729:8k_2_02:67]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-20-021729:8k_2_02:68]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-20-021729:8k_2_02:69]
SOURCE: Generac Holdings Inc.

[0001437749-20-021729:8k_2_02:70]
CONTACT:

[0001437749-20-021729:8k_2_02:71]
Michael W. Harris

[0001437749-20-021729:8k_2_02:72]
Vice President – Corporate Development & Investor Relations

[0001437749-20-021729:8k_2_02:73]
(262) 506-6064

[0001437749-20-021729:8k_2_02:74]
InvestorRelations@generac.com

[0001437749-20-021729:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-021729:8k_2_02:76]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |
| Costs of goods sold |  |  | 425,206 |  |  |  | 383,618 |  |  |  | 1,066,666 |  |  |  | 1,037,874 |  |
| Gross profit |  |  | 276,149 |  |  |  | 217,517 |  |  |  | 657,452 |  |  |  | 575,530 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 60,901 |  |  |  | 59,356 |  |  |  | 178,566 |  |  |  | 158,954 |  |
| Research and development |  |  | 20,658 |  |  |  | 17,603 |  |  |  | 58,762 |  |  |  | 48,906 |  |
| General and administrative |  |  | 31,061 |  |  |  | 27,596 |  |  |  | 88,732 |  |  |  | 80,016 |  |
| Amortization of intangibles |  |  | 7,892 |  |  |  | 7,406 |  |  |  | 23,340 |  |  |  | 19,999 |  |
| Total operating expenses |  |  | 120,512 |  |  |  | 111,961 |  |  |  | 349,400 |  |  |  | 307,875 |  |
| Income from operations |  |  | 155,637 |  |  |  | 105,556 |  |  |  | 308,052 |  |  |  | 267,655 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (8,096 | ) |  |  | (10,704 | ) |  |  | (25,081 | ) |  |  | (31,428 | ) |
| Investment income |  |  | 301 |  |  |  | 523 |  |  |  | 1,921 |  |  |  | 1,889 |  |
| Other, net |  |  | (557 | ) |  |  | (414 | ) |  |  | (2,687 | ) |  |  | (1,868 | ) |
| Total other expense, net |  |  | (8,352 | ) |  |  | (10,595 | ) |  |  | (25,847 | ) |  |  | (31,407 | ) |
| Income before provision for income taxes |  |  | 147,285 |  |  |  | 94,961 |  |  |  | 282,205 |  |  |  | 236,248 |  |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 59,967 |  |  |  | 53,876 |  |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 222,238 |  |  |  | 182,372 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | (3,337 | ) |  |  | (21 | ) |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 1.86 |  |  | $ | 1.20 |  |  | $ | 3.59 |  |  | $ | 2.95 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,353,473 |  |  |  | 61,973,447 |  |  |  | 62,244,872 |  |  |  | 61,878,500 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.82 |  |  | $ | 1.18 |  |  | $ | 3.51 |  |  | $ | 2.92 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,761,380 |  |  |  | 62,770,592 |  |  |  | 63,546,132 |  |  |  | 62,519,205 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 123,887 |  |  | $ | 64,904 |  |  | $ | 187,548 |  |  | $ | 161,828 |  |

[0001437749-20-021729:8k_2_02:77]
6

[0001437749-20-021729:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-021729:8k_2_02:79]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 513,944 |  |  | $ | 322,883 |  |
| Accounts receivable, less allowance for credit losses |  |  | 398,240 |  |  |  | 319,538 |  |
| Inventories |  |  | 532,952 |  |  |  | 522,024 |  |
| Prepaid expenses and other assets |  |  | 35,200 |  |  |  | 31,384 |  |
| Total current assets |  |  | 1,480,336 |  |  |  | 1,195,829 |  |
| Property and equipment, net |  |  | 321,360 |  |  |  | 316,976 |  |
| Customer lists, net |  |  | 47,702 |  |  |  | 55,552 |  |
| Patents and technology, net |  |  | 73,260 |  |  |  | 85,546 |  |
| Other intangible assets, net |  |  | 9,216 |  |  |  | 8,259 |  |
| Tradenames, net |  |  | 145,977 |  |  |  | 148,377 |  |
| Goodwill |  |  | 815,624 |  |  |  | 805,284 |  |
| Deferred income taxes |  |  | 3,596 |  |  |  | 2,933 |  |
| Operating lease and other assets |  |  | 77,004 |  |  |  | 46,913 |  |
| Total assets |  | $ | 2,974,075 |  |  | $ | 2,665,669 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 44,800 |  |  | $ | 58,714 |  |
| Accounts payable |  |  | 272,745 |  |  |  | 261,977 |  |
| Accrued wages and employee benefits |  |  | 52,915 |  |  |  | 41,361 |  |
| Other accrued liabilities |  |  | 182,377 |  |  |  | 132,629 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 3,421 |  |  |  | 2,383 |  |
| Total current liabilities |  |  | 556,258 |  |  |  | 497,064 |  |
| Long-term borrowings and finance lease obligations |  |  | 841,341 |  |  |  | 837,767 |  |
| Deferred income taxes |  |  | 105,520 |  |  |  | 96,328 |  |
| Operating lease and other long-term liabilities |  |  | 177,515 |  |  |  | 140,432 |  |
| Total liabilities |  |  | 1,680,634 |  |  |  | 1,571,591 |  |
| Redeemable noncontrolling interest |  |  | 63,545 |  |  |  | 61,227 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,011,902 and 71,667,726 shares issued at September 30, 2020 and December 31, 2019, respectively |  |  | 720 |  |  |  | 717 |  |
| Additional paid-in capital |  |  | 518,610 |  |  |  | 498,866 |  |
| Treasury stock, at cost |  |  | (331,513 | ) |  |  | (324,551 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,306,530 |  |  |  | 1,084,383 |  |
| Accumulated other comprehensive loss |  |  | (62,039 | ) |  |  | (24,917 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,230,192 |  |  |  | 1,032,382 |  |
| Noncontrolling interests |  |  | (296 | ) |  |  | 469 |  |
| Total stockholders’ equity |  |  | 1,229,896 |  |  |  | 1,032,851 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,974,075 |  |  | $ | 2,665,669 |  |

[0001437749-20-021729:8k_2_02:80]
7

[0001437749-20-021729:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-021729:8k_2_02:82]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 222,238 |  |  | $ | 182,372 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 26,747 |  |  |  | 22,842 |  |
| Amortization of intangible assets |  |  | 23,340 |  |  |  | 19,999 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,940 |  |  |  | 3,597 |  |
| Deferred income taxes |  |  | 15,433 |  |  |  | 19,514 |  |
| Share-based compensation expense |  |  | 14,327 |  |  |  | 11,477 |  |
| Other non-cash charges |  |  | 6,414 |  |  |  | 557 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (85,474 | ) |  |  | (45,543 | ) |
| Inventories |  |  | (14,604 | ) |  |  | 27,190 |  |
| Other assets |  |  | 2,543 |  |  |  | 1,488 |  |
| Accounts payable |  |  | 11,624 |  |  |  | (83,174 | ) |
| Accrued wages and employee benefits |  |  | 11,793 |  |  |  | (7,517 | ) |
| Other accrued liabilities |  |  | 38,211 |  |  |  | (17,092 | ) |
| Excess tax benefits from equity awards |  |  | (6,222 | ) |  |  | (1,908 | ) |
| Net cash provided by operating activities |  |  | 268,310 |  |  |  | 133,802 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 26 |  |  |  | 83 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,998 |  |  |  | 2,036 |  |
| Expenditures for property and equipment |  |  | (33,940 | ) |  |  | (45,447 | ) |
| Acquisition of business, net of cash acquired |  |  | (22,815 | ) |  |  | (120,863 | ) |
| Net cash used in investing activities |  |  | (54,731 | ) |  |  | (164,191 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 198,087 |  |  |  | 68,802 |  |
| Proceeds from long-term borrowings |  |  | 297 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (210,854 | ) |  |  | (45,437 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (3,584 | ) |  |  | (3,110 | ) |
| Payment of contingent acquisition consideration |  |  | (4,000 | ) |  |  | – |  |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | – |  |  |  | (285 | ) |
| Taxes paid related to equity awards |  |  | (13,533 | ) |  |  | (5,749 | ) |
| Proceeds from the exercise of stock options |  |  | 11,991 |  |  |  | 7,957 |  |
| Net cash (used in) provided by financing activities |  |  | (21,596 | ) |  |  | 22,178 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (922 | ) |  |  | (233 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 191,061 |  |  |  | (8,444 | ) |
| Cash and cash equivalents at beginning of period |  |  | 322,883 |  |  |  | 224,482 |  |
| Cash and cash equivalents at end of period |  | $ | 513,944 |  |  | $ | 216,038 |  |

[0001437749-20-021729:8k_2_02:83]
8

[0001437749-20-021729:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-021729:8k_2_02:85]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic (1) |  | $ | 606,875 |  |  | $ | 494,810 |  |  | $ | 1,443,680 |  |  | $ | 1,272,840 |  |
| International (1) |  |  | 94,480 |  |  |  | 106,325 |  |  |  | 280,438 |  |  |  | 340,564 |  |
| Total net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 458,877 |  |  | $ | 335,029 |  |  | $ | 1,057,848 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 176,200 |  |  |  | 214,905 |  |  |  | 503,156 |  |  |  | 654,458 |  |
| Other |  |  | 66,278 |  |  |  | 51,201 |  |  |  | 163,114 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 701,355 |  |  | $ | 601,135 |  |  | $ | 1,724,118 |  |  | $ | 1,613,404 |  |
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic (1) |  | $ | 171,359 |  |  | $ | 120,833 |  |  | $ | 374,065 |  |  | $ | 305,747 |  |
| International (1) |  |  | 7,419 |  |  |  | 5,120 |  |  |  | 13,877 |  |  |  | 19,220 |  |
| Total adjusted EBITDA (2) |  | $ | 178,778 |  |  | $ | 125,953 |  |  | $ | 387,942 |  |  | $ | 324,967 |  |

[0001437749-20-021729:8k_2_02:86]
| (1) In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the three and nine months ended September 30, 2019, net sales of $3,353 and $10,509, and adjusted EBITDA of $384 and $976, respectively, were moved from the Domestic segment to the International segment. |
| (2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-20-021729:8k_2_02:87]
9

[0001437749-20-021729:8k_2_02:88]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-021729:8k_2_02:89]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | (3,337 | ) |  |  | (21 | ) |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 222,238 |  |  |  | 182,372 |  |
| Interest expense |  |  | 8,096 |  |  |  | 10,704 |  |  |  | 25,081 |  |  |  | 31,428 |  |
| Depreciation and amortization |  |  | 17,168 |  |  |  | 15,494 |  |  |  | 50,087 |  |  |  | 42,841 |  |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 59,967 |  |  |  | 53,876 |  |
| Non-cash write-down and other adjustments (1) |  |  | 477 |  |  |  | 347 |  |  |  | 1,868 |  |  |  | 673 |  |
| Non-cash share-based compensation expense (2) |  |  | 4,353 |  |  |  | 3,549 |  |  |  | 14,327 |  |  |  | 11,477 |  |
| Transaction costs and credit facility fees (3) |  |  | 568 |  |  |  | 358 |  |  |  | 1,160 |  |  |  | 2,047 |  |
| Business optimization and other charges (4) |  |  | 531 |  |  |  | 567 |  |  |  | 12,503 |  |  |  | 809 |  |
| Other |  |  | 300 |  |  |  | (27 | ) |  |  | 711 |  |  |  | (556 | ) |
| Adjusted EBITDA |  |  | 178,778 |  |  |  | 125,953 |  |  |  | 387,942 |  |  |  | 324,967 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 920 |  |  |  | 909 |  |  |  | 950 |  |  |  | 3,722 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 177,858 |  |  | $ | 125,044 |  |  | $ | 386,992 |  |  | $ | 321,245 |  |

[0001437749-20-021729:8k_2_02:90]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (4) For the three and nine months ended September 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. For the three and nine months ended September 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities. |

[0001437749-20-021729:8k_2_02:91]
10

[0001437749-20-021729:8k_2_02:92]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | 265 |  |  |  | (677 | ) |  |  | (3,337 | ) |  |  | (21 | ) |
| Net income |  |  | 115,235 |  |  |  | 74,897 |  |  |  | 222,238 |  |  |  | 182,372 |  |
| Provision for income taxes |  |  | 32,050 |  |  |  | 20,064 |  |  |  | 59,967 |  |  |  | 53,876 |  |
| Income before provision for income taxes |  |  | 147,285 |  |  |  | 94,961 |  |  |  | 282,205 |  |  |  | 236,248 |  |
| Amortization of intangible assets |  |  | 7,892 |  |  |  | 7,406 |  |  |  | 23,340 |  |  |  | 19,999 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 654 |  |  |  | 1,221 |  |  |  | 1,940 |  |  |  | 3,597 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 381 |  |  |  | 165 |  |  |  | 612 |  |  |  | 1,373 |  |
| Business optimization and other charges (4) |  |  | 531 |  |  |  | 567 |  |  |  | 12,503 |  |  |  | 809 |  |
| Adjusted net income before provision for income taxes |  |  | 156,743 |  |  |  | 104,320 |  |  |  | 320,600 |  |  |  | 262,026 |  |
| Cash income tax expense (6) |  |  | (23,620 | ) |  |  | (15,083 | ) |  |  | (44,842 | ) |  |  | (39,698 | ) |
| Adjusted net income |  |  | 133,123 |  |  |  | 89,237 |  |  |  | 275,758 |  |  |  | 222,328 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 198 |  |  |  | (738 | ) |  |  | (725 | ) |  |  | 958 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 132,925 |  |  | $ | 89,975 |  |  | $ | 276,483 |  |  | $ | 221,370 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.08 |  |  | $ | 1.43 |  |  | $ | 4.35 |  |  | $ | 3.54 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,761,380 |  |  |  | 62,770,592 |  |  |  | 63,546,132 |  |  |  | 62,519,205 |  |

[0001437749-20-021729:8k_2_02:93]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (6) Amounts for the three and nine months ended September 30, 2020 are now based on an anticipated cash income tax rate of approximately 16% for the year ending December 31, 2020. Amounts for the three and nine months ended September 30, 2019 were based on an anticipated cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income. |

[0001437749-20-021729:8k_2_02:94]
11

[0001437749-20-021729:8k_2_02:95]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net cash provided by operating activities |  | $ | 155,196 |  |  | $ | 111,188 |  |  | $ | 268,310 |  |  | $ | 133,802 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 674 |  |  |  | 640 |  |  |  | 1,998 |  |  |  | 2,036 |  |
| Expenditures for property and equipment |  |  | (7,608 | ) |  |  | (11,071 | ) |  |  | (33,940 | ) |  |  | (45,447 | ) |
| Free cash flow |  | $ | 148,262 |  |  | $ | 100,757 |  |  | $ | 236,368 |  |  | $ | 90,391 |  |
| GAAP Earnings Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 114,970 |  |  | $ | 75,574 |  |  | $ | 225,575 |  |  | $ | 182,393 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 811 |  |  |  | (1,485 | ) |  |  | (2,281 | ) |  |  | 191 |  |
| Net income attributable to common shareholders |  | $ | 115,781 |  |  | $ | 74,089 |  |  | $ | 223,294 |  |  | $ | 182,584 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,353,473 |  |  |  | 61,973,447 |  |  |  | 62,244,872 |  |  |  | 61,878,500 |  |
| Dilutive effect of stock compensation awards |  |  | 1,407,907 |  |  |  | 797,145 |  |  |  | 1,301,260 |  |  |  | 640,705 |  |
| Diluted shares |  |  | 63,761,380 |  |  |  | 62,770,592 |  |  |  | 63,546,132 |  |  |  | 62,519,205 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.86 |  |  | $ | 1.20 |  |  | $ | 3.59 |  |  | $ | 2.95 |  |
| Diluted |  | $ | 1.82 |  |  | $ | 1.18 |  |  | $ | 3.51 |  |  | $ | 2.92 |  |

[0001437749-20-021729:8k_2_02:96]
12
