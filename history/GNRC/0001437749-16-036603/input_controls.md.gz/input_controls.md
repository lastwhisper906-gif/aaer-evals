# GNRC 10-Q controls and the auditor's report


## item_4_controls

[0001437749-16-036603:item_4_controls:1]
Item 4.           Controls and Procedures

[0001437749-16-036603:item_4_controls:2]
Disclosure Controls and Procedures

[0001437749-16-036603:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) or 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended, or the Exchange Act. Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0001437749-16-036603:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001437749-16-036603:item_4_controls:5]
In January 2016, the Company implemented a new global enterprise resource planning (ERP) system for a majority of our business. In connection with this ERP system implementation, we have updated our internal controls over financial reporting, as necessary, to accommodate modifications to our business processes and accounting procedures. Additional implementations will occur at the Company’s remaining locations over a multi-year period.

[0001437749-16-036603:item_4_controls:6]
26

[0001437749-16-036603:item_4_controls:7]
On March 1, 2016, the Company acquired a 65% ownership interest in Pramac. As a result of the acquisition, we are in the process of reviewing the internal control structure of Pramac and, if necessary, will make appropriate changes as we incorporate our controls and procedures into the acquired business. We intend to exclude the operations of Pramac from the scope of our Management Report on Internal Control Over Financial Reporting for the year ended December 31, 2016.

[0001437749-16-036603:item_4_controls:8]
Other than the continuing assessment of controls for the ERP system implementation and Pramac acquisition noted above, there have been no changes during the three months ended June 30, 2016 in our internal control over financial reporting (as defined in Exchange Act Rule 13a-15(f)) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
