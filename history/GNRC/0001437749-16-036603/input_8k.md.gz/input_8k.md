# GNRC 8-K — 0001437749-16-036128 filed 2016-08-02

## item codes, every 8-K on or before 2016-08-05

- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2016-08-05

- none on or before 2016-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-036128:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-036128:8k_2_02:2]
ex99-1.htm

[0001437749-16-036128:8k_2_02:3]
Exhibit 99.1

[0001437749-16-036128:8k_2_02:4]
Generac Reports Second Quarter 2016 Results

[0001437749-16-036128:8k_2_02:5]
WAUKESHA, WISCONSIN, (August 2, 2016) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its second quarter ended June 30, 2016.

[0001437749-16-036128:8k_2_02:6]
Second Quarter 2016 Highlights

[0001437749-16-036128:8k_2_02:7]
| ● | Net sales increased 27.4% to $367.4 million during the second quarter of 2016 as compared to $288.4 million in the prior-year second quarter, including $88.1 million of contribution from recent acquisitions. |

[0001437749-16-036128:8k_2_02:8]
|  | - | Effective with the second quarter of 2016 results, the Company changed its segment reporting and, as a result, going forward will present results under two reporting segments – Domestic (U.S. and Canada) and International. This change is primarily the result of the recent Pramac acquisition and the ongoing strategic plan to expand the business internationally. |

[0001437749-16-036128:8k_2_02:9]
|  | - | Domestic segment sales increased 11.1% to $286.7 million as compared to $258.1 million in the prior-year quarter, which was primarily due to the contribution from the Country Home Products acquisition and increased shipments of residential products, partially offset by a continued decline in shipments of mobile products into oil & gas and general rental markets. |

[0001437749-16-036128:8k_2_02:10]
|  | - | International segment sales increased to $80.7 million as compared to $30.2 million in the prior-year quarter, which was due to the contribution from the Pramac acquisition. |

[0001437749-16-036128:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter of 2016 was $20.9 million, or $0.31 per share, as compared to $14.8 million, or $0.21 per share, for the same period of 2015. |

[0001437749-16-036128:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $42.7 million, or $0.64 per share, as compared to $35.3 million, or $0.50 per share, in the second quarter of 2015. |

[0001437749-16-036128:8k_2_02:13]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $62.3 million as compared to $52.4 million in the second quarter last year. |

[0001437749-16-036128:8k_2_02:14]
| ● | Cash flow from operations was $59.1 million as compared to $16.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $52.2 million as compared to $8.6 million in the second quarter of 2015. |

[0001437749-16-036128:8k_2_02:15]
| ● | The Company repurchased 935,000 shares of its common stock during the second quarter for $34.6 million under its previously announced share repurchase program. |

[0001437749-16-036128:8k_2_02:16]
“We are pleased with our overall financial results for the quarter as residential product organic sales grew solidly over the prior year,” said Aaron Jagdfeld, President and Chief Executive Officer. “This performance helped to offset weaker sales of mobile products within domestic and international markets. We have made encouraging progress on the integration of our recent Country Home Products and Pramac acquisitions, as the addition of these companies are an important element to diversifying the business and expanding internationally. We also generated a strong level of operating and free cash flow during the quarter and resumed activity on our share repurchase program.”

[0001437749-16-036128:8k_2_02:17]
Additional Second Quarter 2016 Consolidated Highlights

[0001437749-16-036128:8k_2_02:18]
Net sales increased 27.4% to $367.4 million during the second quarter of 2016 as compared to $288.4 million in the prior-year second quarter. Residential product sales increased 36.2% to $181.7 million as compared to $133.5 million in the prior year. Commercial & Industrial (C&I) product sales increased 16.5% to $156.7 million as compared to $134.6 million in the prior year.

[0001437749-16-036128:8k_2_02:19]
Gross profit margin improved 50 basis points to 33.8% compared to 33.3% in the prior-year second quarter, despite the current year including $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of this adjustment, gross profit margin was 34.7%, an improvement of 140 basis points as compared to the prior year. The increase was primarily driven by the impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar in recent quarters, along with favorable overall product mix, partially offset by the net mix impact from recent acquisitions.

[0001437749-16-036128:8k_2_02:20]
Operating expenses increased $23.6 million, or 41.9%, as compared to the second quarter of 2015. The increase was primarily driven by the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-16-036128:8k_2_02:21]
Cash flow from operations was $59.1 million as compared to $16.3 million in the prior year, and free cash flow was $52.2 million as compared to $8.6 million in the same period last year. The increases in cash flow were primarily driven by a large reduction in working capital during the current-year quarter as compared to a large increase in the prior year, along with an overall improvement in operating earnings.

[0001437749-16-036128:8k_2_02:22]
The Company repurchased 935,000 shares of its common stock during the second quarter of 2016 for $34.6 million under its share repurchase program which was announced in August 2015. The program authorizes the Company to repurchase up to $200 million of its common stock over a 24 month period, and to date, a total of 4.2 million shares of common stock have been repurchased for approximately $135 million.

[0001437749-16-036128:8k_2_02:23]
Business Segment Results

[0001437749-16-036128:8k_2_02:24]
Effective with the second quarter of 2016 results, the Company changed its segment reporting and, as a result, going forward will present results under two reporting segments – Domestic and International. This change is primarily the result of the recent Pramac acquisition and the ongoing strategy to expand the business internationally. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light and Pramac acquisitions, all of which have revenues that are substantially derived from outside the U.S. and Canada.

[0001437749-16-036128:8k_2_02:25]
Domestic Segment

[0001437749-16-036128:8k_2_02:26]
Domestic segment sales increased 11.1% to $286.7 million as compared to $258.1 million in the prior-year quarter. The increase was primarily due to the contribution from the Country Home Products acquisition, which closed in August 2015, and an increase in shipments of home standby generators. These increases were partially offset by the ongoing significant declines in shipments of mobile products into oil & gas and general rental markets.

[0001437749-16-036128:8k_2_02:27]
Adjusted EBITDA for the segment increased 18.4% to $57.4 million, or 20.0% of net sales, as compared to $48.5 million in the prior year, or 18.8% of net sales. The increase in adjusted EBITDA margin as compared to the prior year was primarily due to favorable product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar in recent quarters, partially offset by higher operating expenses.

[0001437749-16-036128:8k_2_02:28]
International Segment

[0001437749-16-036128:8k_2_02:29]
International segment sales, primarily consisting of C&I products, increased to $80.7 million as compared to $30.2 million in the prior-year quarter. The increase was due to the contribution from the Pramac acquisition, which closed in March 2016, partially offset by declines in organic shipments into the United Kingdom and Latin American markets.

[0001437749-16-036128:8k_2_02:30]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, increased to $6.6 million, or 8.2% of net sales, as compared to $4.0 million, or 13.1% of net sales, in the prior year. The decline in adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable product and customer mix along with lower absorption of fixed manufacturing overhead costs and reduced leverage of operating expenses on the lower organic sales volumes.

[0001437749-16-036128:8k_2_02:31]
2016 Outlook Update

[0001437749-16-036128:8k_2_02:32]
As a result of current end market conditions, the Company is revising its prior guidance for revenue growth and adjusted EBITDA margins for the full year 2016. Net sales are now expected to increase between 6 to 8% over the prior year.  Total organic sales on a constant currency basis are now anticipated to be down between 10 and 13%. This sales guidance assumes no material changes in the current macroeconomic environment and also assumes power outage severity during the second half is similar to the levels experienced during the first half of 2016, which remains well below the longer-term baseline average. Should the baseline power outage environment normalize or if there is a “major” power outage event in 2016, it is likely the Company could exceed these expectations.

[0001437749-16-036128:8k_2_02:33]
Net income margins, before deducting for non-controlling interests, are expected to be approximately 7.0% and adjusted EBITDA margins, also before deducting for non-controlling interests, are now expected to be approximately 19.5% for the full-year 2016. Operating and free cash flow generation is expected to increase over the prior year, benefitting from the strong conversion of adjusted net income.

[0001437749-16-036128:8k_2_02:34]
“As we head into the second half of 2016, we’ve seen some additional weakening of end market demand primarily as a result of the ongoing very low power outage environment, continued weakness in oil & gas markets and Brexit-related uncertainty within Europe,” continued Mr. Jagdfeld. “As a result, we remain focused on executing expense-reduction actions, including those announced last quarter, while also continuing to drive initiatives to advance our strategic plan forward. As we think about the future, we remain optimistic regarding the long-term growth opportunities for our business, and we intend to further evaluate our priority uses of capital to increase shareholder value.”

[0001437749-16-036128:8k_2_02:35]
Conference Call and Webcast

[0001437749-16-036128:8k_2_02:36]
Generac management will hold a conference call at 9:00 a.m. EDT on Tuesday, August 2, 2016 to discuss highlights of the second quarter of 2016 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 48931715.

[0001437749-16-036128:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-16-036128:8k_2_02:38]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 48931715. The telephonic replay will be available for 30 days.

[0001437749-16-036128:8k_2_02:39]
About Generac

[0001437749-16-036128:8k_2_02:40]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-036128:8k_2_02:41]
Forward-looking Information

[0001437749-16-036128:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-16-036128:8k_2_02:43]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-16-036128:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-16-036128:8k_2_02:45]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-16-036128:8k_2_02:46]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-16-036128:8k_2_02:47]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-16-036128:8k_2_02:48]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-16-036128:8k_2_02:49]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-16-036128:8k_2_02:50]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-16-036128:8k_2_02:51]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-16-036128:8k_2_02:52]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-16-036128:8k_2_02:53]
|  | ● | loss of key management and employees; |

[0001437749-16-036128:8k_2_02:54]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-16-036128:8k_2_02:55]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-036128:8k_2_02:56]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2015 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-036128:8k_2_02:57]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-16-036128:8k_2_02:58]
Reconciliations to GAAP Financial Metrics

[0001437749-16-036128:8k_2_02:59]
Adjusted EBITDA

[0001437749-16-036128:8k_2_02:60]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-036128:8k_2_02:61]
Adjusted Net Income

[0001437749-16-036128:8k_2_02:62]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controllable interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses and adjusted net income attributable to non-controlling interests.

[0001437749-16-036128:8k_2_02:63]
4

[0001437749-16-036128:8k_2_02:64]
Free Cash Flow

[0001437749-16-036128:8k_2_02:65]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-16-036128:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-16-036128:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-16-036128:8k_2_02:68]
CONTACT:

[0001437749-16-036128:8k_2_02:69]
Michael W. Harris

[0001437749-16-036128:8k_2_02:70]
Vice President – Finance 
(262) 544-4811 x2675

[0001437749-16-036128:8k_2_02:71]
Michael.Harris@Generac.com

[0001437749-16-036128:8k_2_02:72]
Generac Holdings Inc.

[0001437749-16-036128:8k_2_02:73]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-16-036128:8k_2_02:74]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-036128:8k_2_02:75]
(Unaudited)

[0001437749-16-036128:8k_2_02:76]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |
| Costs of goods sold |  |  | 243,229 |  |  |  | 192,463 |  |  |  | 431,704 |  |  |  | 401,678 |  |
| Gross profit |  |  | 124,147 |  |  |  | 95,897 |  |  |  | 222,207 |  |  |  | 198,500 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 42,366 |  |  |  | 28,474 |  |  |  | 79,635 |  |  |  | 58,602 |  |
| Research and development |  |  | 9,889 |  |  |  | 8,412 |  |  |  | 18,086 |  |  |  | 16,575 |  |
| General and administrative |  |  | 19,593 |  |  |  | 13,564 |  |  |  | 37,426 |  |  |  | 27,770 |  |
| Amortization of intangibles |  |  | 8,217 |  |  |  | 5,980 |  |  |  | 16,014 |  |  |  | 11,175 |  |
| Total operating expenses |  |  | 80,065 |  |  |  | 56,430 |  |  |  | 151,161 |  |  |  | 114,122 |  |
| Income from operations |  |  | 44,082 |  |  |  | 39,467 |  |  |  | 71,046 |  |  |  | 84,378 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,380 | ) |  |  | (10,763 | ) |  |  | (22,415 | ) |  |  | (22,031 | ) |
| Investment income |  |  | 4 |  |  |  | 35 |  |  |  | 36 |  |  |  | 72 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (3,427 | ) |  |  | – |  |  |  | (4,795 | ) |
| Costs related to acquisition |  |  | – |  |  |  | - |  |  |  | (417 | ) |  |  | – |  |
| Other, net |  |  | 158 |  |  |  | (1,840 | ) |  |  | 545 |  |  |  | (3,449 | ) |
| Total other expense, net |  |  | (11,218 | ) |  |  | (15,995 | ) |  |  | (22,251 | ) |  |  | (30,203 | ) |
| Income before provision for income taxes |  |  | 32,864 |  |  |  | 23,472 |  |  |  | 48,795 |  |  |  | 54,175 |  |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 17,640 |  |  |  | 19,646 |  |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 31,155 |  |  |  | 34,529 |  |
| Income attributable to noncontrolling interests |  |  | 55 |  |  |  | - |  |  |  | 59 |  |  |  | - |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 0.32 |  |  | $ | 0.22 |  |  | $ | 0.47 |  |  | $ | 0.50 |  |
| Weighted average common shares outstanding - basic: |  |  | 65,870,714 |  |  |  | 68,961,877 |  |  |  | 65,955,455 |  |  |  | 68,886,672 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.49 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,388,581 |  |  |  | 70,063,063 |  |  |  | 66,465,770 |  |  |  | 70,099,940 |  |
| Comprehensive income |  | $ | 7,622 |  |  | $ | 15,173 |  |  | $ | 19,076 |  |  | $ | 28,040 |  |

[0001437749-16-036128:8k_2_02:77]
6

[0001437749-16-036128:8k_2_02:78]
Generac Holdings Inc.

[0001437749-16-036128:8k_2_02:79]
Condensed Consolidated Balance Sheets

[0001437749-16-036128:8k_2_02:80]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-036128:8k_2_02:81]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 75,641 |  |  | $ | 115,857 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 243,087 |  |  |  | 182,185 |  |
| Inventories |  |  | 366,745 |  |  |  | 325,375 |  |
| Prepaid expenses and other assets |  |  | 13,125 |  |  |  | 8,600 |  |
| Total current assets |  |  | 698,598 |  |  |  | 632,017 |  |
| Property and equipment, net |  |  | 206,700 |  |  |  | 184,213 |  |
| Customer lists, net |  |  | 49,883 |  |  |  | 39,313 |  |
| Patents, net |  |  | 54,009 |  |  |  | 53,772 |  |
| Other intangible assets, net |  |  | 3,179 |  |  |  | 2,768 |  |
| Tradenames, net |  |  | 159,952 |  |  |  | 161,057 |  |
| Goodwill |  |  | 716,845 |  |  |  | 669,719 |  |
| Deferred income taxes |  |  | 24,421 |  |  |  | 34,812 |  |
| Other assets |  |  | 2,948 |  |  |  | 964 |  |
| Total assets |  | $ | 1,916,535 |  |  | $ | 1,778,635 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 33,649 |  |  | $ | 8,594 |  |
| Accounts payable |  |  | 166,693 |  |  |  | 108,332 |  |
| Accrued wages and employee benefits |  |  | 22,193 |  |  |  | 13,101 |  |
| Other accrued liabilities |  |  | 88,609 |  |  |  | 82,540 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 12,897 |  |  |  | 657 |  |
| Total current liabilities |  |  | 324,041 |  |  |  | 213,224 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,034,836 |  |  |  | 1,037,132 |  |
| Deferred income taxes |  |  | 8,745 |  |  |  | 4,950 |  |
| Other long-term liabilities |  |  | 62,890 |  |  |  | 57,458 |  |
| Total liabilities |  |  | 1,430,512 |  |  |  | 1,312,764 |  |
| Redeemable noncontrolling interests |  |  | 35,685 |  |  |  | – |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,142,664 and 69,582,669 shares issued at June 30, 2016 and December 31, 2015, respectively |  |  | 701 |  |  |  | 696 |  |
| Additional paid-in capital |  |  | 443,833 |  |  |  | 443,109 |  |
| Treasury stock, at cost |  |  | (146,801 | ) |  |  | (111,516 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 389,269 |  |  |  | 358,173 |  |
| Accumulated other comprehensive loss |  |  | (34,495 | ) |  |  | (22,475 | ) |
| Stockholders’ equity attributable to Generac Holdings, Inc. |  |  | 450,391 |  |  |  | 465,871 |  |
| Noncontrolling interests |  |  | (53 | ) |  |  | – |  |
| Total stockholders' equity |  |  | 450,338 |  |  |  | 465,871 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,916,535 |  |  | $ | 1,778,635 |  |

[0001437749-16-036128:8k_2_02:82]
Generac Holdings Inc.

[0001437749-16-036128:8k_2_02:83]
Condensed Consolidated Statements of Cash Flows

[0001437749-16-036128:8k_2_02:84]
(U.S. Dollars in Thousands)

[0001437749-16-036128:8k_2_02:85]
(Unaudited)

[0001437749-16-036128:8k_2_02:86]
|  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 31,155 |  |  | $ | 34,529 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 10,429 |  |  |  | 7,988 |  |
| Amortization of intangible assets |  |  | 16,014 |  |  |  | 11,175 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,122 |  |  |  | 3,344 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 4,795 |  |
| Deferred income taxes |  |  | 9,072 |  |  |  | 8,935 |  |
| Share-based compensation expense |  |  | 5,386 |  |  |  | 5,090 |  |
| Other |  |  | 46 |  |  |  | 285 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (9,389 | ) |  |  | 29,944 |  |
| Inventories |  |  | (1,046 | ) |  |  | (66,312 | ) |
| Other assets |  |  | 2,297 |  |  |  | (3,198 | ) |
| Accounts payable |  |  | 17,537 |  |  |  | 17,377 |  |
| Accrued wages and employee benefits |  |  | 6,166 |  |  |  | (1,735 | ) |
| Other accrued liabilities |  |  | (1,825 | ) |  |  | (1,744 | ) |
| Excess tax benefits from equity awards |  |  | (6,729 | ) |  |  | (8,894 | ) |
| Net cash provided by operating activities |  |  | 81,235 |  |  |  | 41,579 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 47 |  |  |  | 88 |  |
| Expenditures for property and equipment |  |  | (14,004 | ) |  |  | (14,258 | ) |
| Acquisition of business, net of cash acquired |  |  | (60,886 | ) |  |  | 233 |  |
| Net cash used in investing activities |  |  | (74,843 | ) |  |  | (13,937 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 10,278 |  |  |  | 9,000 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 100,000 |  |
| Repayments of short-term borrowings |  |  | (6,327 | ) |  |  | (11,366 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (10,652 | ) |  |  | (150,453 | ) |
| Stock repurchases |  |  | (34,576 | ) |  |  | – |  |
| Payment of debt issuance costs |  |  | – |  |  |  | (2,060 | ) |
| Cash dividends paid |  |  | (76 | ) |  |  | (1,427 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,099 | ) |  |  | (12,347 | ) |
| Excess tax benefits from equity awards |  |  | 6,729 |  |  |  | 8,901 |  |
| Net cash used in financing activities |  |  | (46,723 | ) |  |  | (59,752 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 115 |  |  |  | (2,076 | ) |
| Net decrease in cash and cash equivalents |  |  | (40,216 | ) |  |  | (34,186 | ) |
| Cash and cash equivalents at beginning of period |  |  | 115,857 |  |  |  | 189,761 |  |
| Cash and cash equivalents at end of period |  | $ | 75,641 |  |  | $ | 155,575 |  |

[0001437749-16-036128:8k_2_02:87]
8

[0001437749-16-036128:8k_2_02:88]
Generac Holdings Inc.

[0001437749-16-036128:8k_2_02:89]
Segment Reporting Information

[0001437749-16-036128:8k_2_02:90]
(U.S. Dollars in Thousands)

[0001437749-16-036128:8k_2_02:91]
(Unaudited)

[0001437749-16-036128:8k_2_02:92]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 286,720 |  |  | $ | 258,117 |  |  | $ | 534,736 |  |  | $ | 545,729 |  |
| International |  |  | 80,656 |  |  |  | 30,243 |  |  |  | 119,175 |  |  |  | 54,449 |  |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 181,735 |  |  | $ | 133,466 |  |  | $ | 340,716 |  |  | $ | 290,300 |  |
| Commercial & industrial products |  |  | 156,730 |  |  |  | 134,580 |  |  |  | 259,720 |  |  |  | 268,343 |  |
| Other |  |  | 28,911 |  |  |  | 20,314 |  |  |  | 53,475 |  |  |  | 41,535 |  |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |

[0001437749-16-036128:8k_2_02:93]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 57,352 |  |  | $ | 48,457 |  |  | $ | 104,212 |  |  | $ | 102,901 |  |
| International |  |  | 6,574 |  |  |  | 3,965 |  |  |  | 9,523 |  |  |  | 6,659 |  |
| Total adjusted EBITDA (1) |  | $ | 63,926 |  |  | $ | 52,422 |  |  | $ | 113,735 |  |  | $ | 109,560 |  |

[0001437749-16-036128:8k_2_02:94]
(1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-16-036128:8k_2_02:95]
Generac Holdings, Inc.

[0001437749-16-036128:8k_2_02:96]
Reconciliation Schedules

[0001437749-16-036128:8k_2_02:97]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-16-036128:8k_2_02:98]
Net income to Adjusted EBITDA reconciliation

[0001437749-16-036128:8k_2_02:99]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 55 |  |  |  | - |  |  |  | 59 |  |  |  | - |  |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 31,155 |  |  |  | 34,529 |  |
| Interest expense |  |  | 11,380 |  |  |  | 10,763 |  |  |  | 22,415 |  |  |  | 22,031 |  |
| Depreciation and amortization |  |  | 13,650 |  |  |  | 10,129 |  |  |  | 26,443 |  |  |  | 19,163 |  |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 17,640 |  |  |  | 19,646 |  |
| Non-cash write-down and other adjustments (2) |  |  | 2,909 |  |  |  | 404 |  |  |  | 2,782 |  |  |  | 1,976 |  |
| Non-cash share-based compensation expense (3) |  |  | 2,901 |  |  |  | 2,582 |  |  |  | 5,386 |  |  |  | 5,090 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |
| Transaction costs and credit facility fees (5) |  |  | 237 |  |  |  | 481 |  |  |  | 760 |  |  |  | 682 |  |
| Business optimization expenses (6) |  |  | - |  |  |  | 1,444 |  |  |  | 7,106 |  |  |  | 1,738 |  |
| Other |  |  | (15 | ) |  |  | (280 | ) |  |  | 48 |  |  |  | (90 | ) |
| Adjusted EBITDA |  |  | 63,926 |  |  |  | 52,422 |  |  |  | 113,735 |  |  |  | 109,560 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,623 |  |  |  | - |  |  |  | 2,307 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 62,303 |  |  | $ | 52,422 |  |  | $ | 111,428 |  |  | $ | 109,560 |  |

[0001437749-16-036128:8k_2_02:100]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting adjustments, including the step-up in value of inventories and intangible amortization, totaling $4.3 million and $5.5 million for the three and six months ended June 30, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (6) For the six months ended June 30, 2016, represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. For the three and six months ended June 30, 2015, represents severance and other non-recurring restructuring charges. |

[0001437749-16-036128:8k_2_02:101]
10

[0001437749-16-036128:8k_2_02:102]
Net income to Adjusted net income reconciliation

[0001437749-16-036128:8k_2_02:103]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 55 |  |  |  | - |  |  |  | 59 |  |  |  | - |  |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 31,155 |  |  |  | 34,529 |  |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 17,640 |  |  |  | 19,646 |  |
| Income before provision for income taxes |  |  | 32,864 |  |  |  | 23,472 |  |  |  | 48,795 |  |  |  | 54,175 |  |
| Amortization of intangible assets |  |  | 8,217 |  |  |  | 5,980 |  |  |  | 16,014 |  |  |  | 11,175 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,066 |  |  |  | 1,639 |  |  |  | 2,122 |  |  |  | 3,344 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 3,443 |  |  |  | 240 |  |  |  | 4,690 |  |  |  | 503 |  |
| Business optimization expenses (6) |  |  | - |  |  |  | 1,444 |  |  |  | 7,106 |  |  |  | 1,738 |  |
| Adjusted net income before provision for income taxes |  |  | 45,590 |  |  |  | 36,202 |  |  |  | 78,727 |  |  |  | 75,730 |  |
| Cash income tax expense (8) |  |  | (1,450 | ) |  |  | (920 | ) |  |  | (3,270 | ) |  |  | (6,035 | ) |
| Adjusted net income |  |  | 44,140 |  |  |  | 35,282 |  |  |  | 75,457 |  |  |  | 69,695 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,451 |  |  |  | - |  |  |  | 1,881 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 42,689 |  |  | $ | 35,282 |  |  | $ | 73,576 |  |  | $ | 69,695 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.64 |  |  | $ | 0.50 |  |  | $ | 1.11 |  |  | $ | 0.99 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,388,581 |  |  |  | 70,063,063 |  |  |  | 66,465,770 |  |  |  | 70,099,940 |  |

[0001437749-16-036128:8k_2_02:104]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (8)Amount for the three and six months ended June 30, 2016 is based on an anticipated cash income tax rate of approximately 5% for the full year ended 2016. Amount for the three and six months ended June 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year ended 2015. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-16-036128:8k_2_02:105]
| Free Cash Flow Reconciliation |

[0001437749-16-036128:8k_2_02:106]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 59,084 |  |  | $ | 16,322 |  |  | $ | 81,235 |  |  | $ | 41,579 |  |
| Expenditures for property and equipment |  |  | (6,911 | ) |  |  | (7,730 | ) |  |  | (14,004 | ) |  |  | (14,258 | ) |
| Free cash flow |  | $ | 52,173 |  |  | $ | 8,592 |  |  | $ | 67,231 |  |  | $ | 27,321 |  |

[0001437749-16-036128:8k_2_02:107]
11
