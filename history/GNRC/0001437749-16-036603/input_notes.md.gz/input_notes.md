# GNRC notes — 0001437749-16-036603


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-16-036603:notes:1]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,071 |  |  | $ | 21,726 |  |
| Long-term portion - other long-term liabilities |  |  | 9,664 |  |  |  | 8,471 |  |
| Total |  | $ | 30,735 |  |  | $ | 30,197 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 5,034 |  |  | $ | 6,026 |  |
| Long-term portion - other long-term liabilities |  |  | 24,048 |  |  |  | 22,935 |  |
| Total |  | $ | 29,082 |  |  | $ | 28,961 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-16-036603:notes:2]
|  |  | June 30,2016 |  |  | December 31,2015 |  |
| Commodity contracts |  | $ | 82 |  |  | $ | (400 | ) |
| Foreign currency contracts |  |  | 87 |  |  |  | (171 | ) |
| Interest rate swaps |  |  | (4,733 | ) |  |  | (2,618 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-16-036603:notes:3]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |
| Pro forma |  |  | 367,376 |  |  |  | 369,815 |  |  |  | 683,258 |  |  |  | 744,326 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Pro forma |  |  | 21,683 |  |  |  | 18,454 |  |  |  | 32,168 |  |  |  | 35,847 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.49 |  |
| Pro forma |  |  | 0.33 |  |  |  | 0.26 |  |  |  | 0.48 |  |  |  | 0.51 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-16-036603:notes:4]
[same as prior period, unchanged from 0001437749-16-031130:notes:3]

[0001437749-16-036603:notes:5]
[same as prior period, unchanged from 0001437749-16-031130:notes:4]

[0001437749-16-036603:notes:6]
On March 1, 2016, the Company acquired a 65% ownership interest in Pramac for a purchase price, net of cash acquired, of $60,886. Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-16-036603:notes:7]
The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest party has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell their interests to the Company any time within five years from the acquisition. The put option price is either (i) a fixed amount if voluntarily exercised within the first two years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it may redeem commencing five years from the acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with no partial transfers of interest permitted.

[0001437749-16-036603:notes:8]
The Company recorded a preliminary purchase price allocation during the second quarter of 2016 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The preliminary purchase price allocation was as follows:

[0001437749-16-036603:notes:9]
|  |  | March 1, 2016 |  |
| Accounts receivable |  | $ | 51,108 |  |
| Inventories |  |  | 40,180 |  |
| Property and equipment |  |  | 19,020 |  |
| Intangible assets |  |  | 27,620 |  |
| Goodwill |  |  | 53,665 |  |
| Other assets |  |  | 8,153 |  |
| Total assets acquired |  |  | 199,746 |  |
| Short-term borrowings |  |  | 21,105 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 24,580 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,886 |  |

[0001437749-16-036603:notes:10]
The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through June 30, 2016.

[0001437749-16-036603:notes:11]
[same as prior period, unchanged from 0001437749-16-031130:notes:9]

[0001437749-16-036603:notes:12]
On August 1, 2015, a subsidiary of the Company acquired CHP for a purchase price, net of cash acquired, of $74,570. Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition was funded solely through cash on hand.

[0001437749-16-036603:notes:13]
The Company recorded a preliminary purchase price allocation during the third quarter of 2015 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $81,726 of intangible assets, including approximately $30,076 of goodwill, as of the acquisition date. The purchase price allocation was finalized in the fourth quarter of 2015, resulting in a $6,552 decrease to total intangible assets, including an increase of $6,208 in goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. In addition, the Company assumed $12,000 of CHP’s debt in conjunction with this acquisition. The accompanying condensed consolidated financial statements include the results of CHP from the date of acquisition through June 30, 2016.

[0001437749-16-036603:notes:14]
Pro Forma Information

[0001437749-16-036603:notes:15]
The following unaudited pro forma information of the Company gives effect to these acquisitions as though the transactions had occurred on January 1, 2015:

[0001437749-16-036603:notes:16]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on January 1, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-16-036603:notes:17]
[same as prior period, unchanged from 0001437749-16-031130:notes:13]

[0001437749-16-036603:notes:18]
[same as prior period, unchanged from 0001437749-16-031130:notes:14]

[0001437749-16-036603:notes:19]
[same as prior period, unchanged from 0001437749-16-031130:notes:15]

[0001437749-16-036603:notes:20]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-036603:notes:21]
[same as prior period, unchanged from 0001437749-16-031130:notes:17]

[0001437749-16-036603:notes:22]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |
|  | ● | On March 1, 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-16-036603:notes:23]
[same as prior period, unchanged from 0001437749-16-031130:notes:26]

[0001437749-16-036603:notes:24]
The condensed consolidated balance sheet as of June 30, 2016, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2016 and 2015, and the condensed consolidated statements of cash flows for the six months ended June 30, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-16-036603:notes:25]
[same as prior period, unchanged from 0001437749-16-031130:notes:28]

[0001437749-16-036603:notes:26]
[same as prior period, unchanged from 0001437749-16-031130:notes:29]

[0001437749-16-036603:notes:27]
[same as prior period, unchanged from 0001437749-16-031130:notes:30]

[0001437749-16-036603:notes:28]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. ASU 2014-09, as amended by ASU 2015-14, 
Revenue from Contracts with Customers (Topic

[0001437749-16-036603:notes:29]
606): D

[0001437749-16-036603:notes:30]
eferral of the Effective Date
, ASU 2016-08, 
Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations
, ASU 2016-10, 
Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing

[0001437749-16-036603:notes:31]
,
 and ASU 2016-12, 
Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients
, becomes effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-16-036603:notes:32]
In February 2016, the FASB issued ASU 2016-02, 
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 2019, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-16-036603:notes:33]
In March 2016, the FASB issued ASU 2016-09, 
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits and forfeitures. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classification on the statements of cash flow.

[0001437749-16-036603:notes:34]
In the first quarter of 2016, the Company adopted ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965. Also in the first quarter of 2016, the Company adopted ASU 2015-17, 
Income Taxes: Balance Sheet Classification of Deferred Taxes
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.

[0001437749-16-036603:notes:35]
There are several other new accounting pronouncements issued by the FASB. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-16-036603:notes:36]
1

[0001437749-16-036603:notes:37]
3

[0001437749-16-036603:notes:38]
. Commitments and Contingencies

[0001437749-16-036603:notes:39]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2016 and December 31, 2015 was approximately $36,200 and $32,400, respectively.

[0001437749-16-036603:notes:40]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-036603:notes:41]
[same as prior period, unchanged from 0001437749-16-031130:notes:47]

[0001437749-16-036603:notes:42]
[same as prior period, unchanged from 0001437749-16-031130:notes:48]

[0001437749-16-036603:notes:43]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended June 30, 2016 and 2015, net of tax:

[0001437749-16-036603:notes:44]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2016 |  | $ | (7,102 | ) |  | $ | (11,362 | ) |  | $ | (2,765 | ) |  | $ | (21,229 | ) |
| Other comprehensive loss before reclassifications |  |  | (13,132 | ) |  |  | - |  |  |  | (134 | ) | (1) |  | (13,266 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (13,132 | ) |  |  | - |  |  |  | (134 | ) |  |  | (13,266 | ) |
| Ending Balance – June 30, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  | $ | (34,495 | ) |

[0001437749-16-036603:notes:45]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2015 |  | $ | (7,424 | ) |  | $ | (13,243 | ) |  | $ | (1,918 | ) |  | $ | (22,585 | ) |
| Other comprehensive income before reclassifications |  |  | 63 |  |  |  | - |  |  |  | 266 |  | (2) |  | 329 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 63 |  |  |  | - |  |  |  | 266 |  |  |  | 329 |  |
| Ending Balance – June 30, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |

[0001437749-16-036603:notes:46]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive loss before reclassifications |  |  | (10,732 | ) |  |  | - |  |  |  | (1,288 | ) | (3) |  | (12,020 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (10,732 | ) |  |  | - |  |  |  | (1,288 | ) |  |  | (12,020 | ) |
| Ending Balance – June 30, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  | $ | (34,495 | ) |

[0001437749-16-036603:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (5,483 | ) |  |  | - |  |  |  | (1,006 | ) | (4) |  | (6,489 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (5,483 | ) |  |  | - |  |  |  | (1,006 | ) |  |  | (6,489 | ) |
| Ending Balance – June 30, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |

[0001437749-16-036603:notes:48]
|  | (1) | Represents unrealized losses of $(219), net of tax benefit of $85 for the three months ended June 30, 2016. |
|  | (2) | Represents unrealized gains of $431, net of tax effect of $(165) for the three months ended June 30, 2015. |
|  | (3) | Represents unrealized losses of $(2,115), net of tax benefit of $827 for the six months ended June 30, 2016. |
|  | (4) | Represents unrealized losses of $(1,643), net of tax benefit of $637 for the six months ended June 30, 2015. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-036603:notes:49]
9

[0001437749-16-036603:notes:50]
. Credit Agreements

[0001437749-16-036603:notes:51]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-16-036603:notes:52]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 33,649 |  |  |  | 8,594 |  |
| Total |  | $ | 33,649 |  |  | $ | 8,594 |  |

[0001437749-16-036603:notes:53]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-16-036603:notes:54]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (27,783 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,973 |  |  |  | 1,694 |  |
| Other |  |  | 16,543 |  |  |  | 12,000 |  |
| Total |  |  | 1,047,733 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 12,374 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 523 |  |  |  | 157 |  |
| Total |  | $ | 1,034,836 |  |  | $ | 1,037,132 |  |

[0001437749-16-036603:notes:55]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

[0001437749-16-036603:notes:56]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of June 30, 2016 was above 3.00 to 1.00.

[0001437749-16-036603:notes:57]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of June 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-036603:notes:58]
The Company’s credit agreements also originally provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-16-036603:notes:59]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $483 of new debt issuance costs in 2015.

[0001437749-16-036603:notes:60]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of June 30, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $142,123 of availability, net of outstanding letters of credit.

[0001437749-16-036603:notes:61]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-16-036603:notes:62]
As of June 30, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $33,649 and $8,594, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-16-036603:notes:63]
[same as prior period, unchanged from 0001437749-16-031130:notes:68]

[0001437749-16-036603:notes:64]
[same as prior period, unchanged from 0001437749-16-031130:notes:69]

[0001437749-16-036603:notes:65]
[same as prior period, unchanged from 0001437749-16-031130:notes:70]

[0001437749-16-036603:notes:66]
The Company is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than eighteen months. At June 30, 2016, December 31, 2015 and June 30, 2015, the Company had one, one and three commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-16-036603:notes:67]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net gains recognized for the three and six months ended June 30, 2016 were $82 and $76, respectively. Net losses recognized for the three and six months ended June 30, 2015 were $315 and $1,041, respectively.

[0001437749-16-036603:notes:68]
[same as prior period, unchanged from 0001437749-16-031130:notes:73]

[0001437749-16-036603:notes:69]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of June 30, 2016, December 31, 2015 and June 30, 2015, the Company had twelve, six and two foreign currency contracts outstanding, respectively.

[0001437749-16-036603:notes:70]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net gains (losses) recognized for the three and six months ended June 30, 2016 were $1 and $(178), respectively. Net losses recognized for the three and six months ended June 30, 2015 were $37 and $358, respectively.

[0001437749-16-036603:notes:71]
[same as prior period, unchanged from 0001437749-16-031130:notes:76]

[0001437749-16-036603:notes:72]
In October 2013, the Company entered into two interest rate swap agreements, and in May 2014, the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-16-036603:notes:73]
[same as prior period, unchanged from 0001437749-16-031130:notes:78]

[0001437749-16-036603:notes:74]
[same as prior period, unchanged from 0001437749-16-031130:notes:79]

[0001437749-16-036603:notes:75]
The fair value of the commodity and foreign currency contracts are included in other assets, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of June 30, 2016 and December 31, 2015. Excluding the impact of credit risk, the fair value of the derivative contracts as of June 30, 2016 and December 31, 2015 is a liability of $4,672 and $3,248, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-16-036603:notes:76]
The amount of losses recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three and six months ended June 30, 2016 were $134 and $1,288, respectively. The amount of gains (losses) for the three and six months ended June 30, 2015 were $266 and $(1,006), respectively.

[0001437749-16-036603:notes:77]
The amount of gains (losses) recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three and six months ended June 30, 2016 were $83 and $(102), respectively. The amount of losses for the three and six months ended June 30, 2015 were $352 and $1,399, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-036603:notes:78]
11

[0001437749-16-036603:notes:79]
[same as prior period, unchanged from 0001437749-16-031130:notes:83]

[0001437749-16-036603:notes:80]
Basic earnings per share is calculated by dividing net income attributable to the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-16-036603:notes:81]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. (numerator) |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 65,870,714 |  |  |  | 68,961,877 |  |  |  | 65,955,455 |  |  |  | 68,886,672 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 517,867 |  |  |  | 1,101,186 |  |  |  | 510,315 |  |  |  | 1,213,268 |  |
| Diluted |  |  | 66,388,581 |  |  |  | 70,063,063 |  |  |  | 66,465,770 |  |  |  | 70,099,940 |  |
| Net income attributable to Generac Holdings Inc. per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.32 |  |  | $ | 0.22 |  |  | $ | 0.47 |  |  | $ | 0.50 |  |
| Diluted |  | $ | 0.31 |  |  | $ | 0.21 |  |  | $ | 0.47 |  |  | $ | 0.49 |  |

[0001437749-16-036603:notes:82]
(1) Excludes approximately 189,500 stock options and 3,000 shares of restricted stock for the three month period ended June 30, 2016, and 215,800 stock options and 3,400 shares of restricted stock for the six month period ended June 30, 2016, as the impact of such awards was anti-dilutive. Excludes approximately 142,900 stock options and 2,300 shares of restricted stock for the three month period ended June 30, 2015 and 104,400 stock options for the six month period ended June 30, 2015, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-036603:notes:83]
[same as prior period, unchanged from 0001437749-16-031130:notes:88]

[0001437749-16-036603:notes:84]
[same as prior period, unchanged from 0001437749-16-031130:notes:89]

[0001437749-16-036603:notes:85]
[same as prior period, unchanged from 0001437749-16-031130:notes:90]

[0001437749-16-036603:notes:86]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $926,390, was approximately $914,810 (Level 2) at June 30, 2016, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-16-036603:notes:87]
[same as prior period, unchanged from 0001437749-16-031130:notes:92]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-036603:notes:88]
12

[0001437749-16-036603:notes:89]
[same as prior period, unchanged from 0001437749-16-031130:notes:94]

[0001437749-16-036603:notes:90]
The effective income tax rates for the six months ended June 30, 2016 and 2015 were 36.2% and 36.3%, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-16-036603:notes:91]
[same as prior period, unchanged from 0001437749-16-031130:notes:96]

[0001437749-16-036603:notes:92]
[same as prior period, unchanged from 0001437749-16-031130:notes:97]

[0001437749-16-036603:notes:93]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts.

[0001437749-16-036603:notes:94]
[same as prior period, unchanged from 0001437749-16-031130:notes:99]

[0001437749-16-036603:notes:95]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 31,904 |  |  | $ | 29,277 |  |  | $ | 30,197 |  |  | $ | 30,909 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 840 |  |  |  | - |  |
| Payments |  |  | (4,900 | ) |  |  | (5,100 | ) |  |  | (8,552 | ) |  |  | (10,533 | ) |
| Provision for warranties issued |  |  | 4,220 |  |  |  | 4,480 |  |  |  | 7,702 |  |  |  | 9,029 |  |
| Changes in estimates for pre-existing warranties |  |  | (489 | ) |  |  | (472 | ) |  |  | 548 |  |  |  | (1,220 | ) |
| Balance at end of period |  | $ | 30,735 |  |  | $ | 28,185 |  |  | $ | 30,735 |  |  | $ | 28,185 |  |

[0001437749-16-036603:notes:96]
[same as prior period, unchanged from 0001437749-16-031130:notes:101]

[0001437749-16-036603:notes:97]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 28,830 |  |  | $ | 27,531 |  |  | $ | 28,961 |  |  | $ | 27,193 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,619 |  |  |  | 810 |  |  |  | 2,763 |  |  |  | 2,190 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,367 | ) |  |  | (1,100 | ) |  |  | (2,642 | ) |  |  | (2,142 | ) |
| Balance at end of period |  | $ | 29,082 |  |  | $ | 27,241 |  |  | $ | 29,082 |  |  | $ | 27,241 |  |

[0001437749-16-036603:notes:98]
[same as prior period, unchanged from 0001437749-16-031130:notes:103]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-16-036603:notes:99]
|  |  | June 30, 2016 |  |  | December 31, 2015 |  |
| Land and improvements |  | $ | 12,354 |  |  | $ | 8,553 |  |
| Buildings and improvements |  |  | 115,544 |  |  |  | 104,774 |  |
| Machinery and equipment |  |  | 78,434 |  |  |  | 72,280 |  |
| Dies and tools |  |  | 21,779 |  |  |  | 20,066 |  |
| Vehicles |  |  | 1,575 |  |  |  | 1,244 |  |
| Office equipment and systems |  |  | 58,440 |  |  |  | 29,395 |  |
| Leasehold improvements |  |  | 4,322 |  |  |  | 3,338 |  |
| Construction in progress |  |  | 10,507 |  |  |  | 30,482 |  |
| Gross property and equipment |  |  | 302,955 |  |  |  | 270,132 |  |
| Accumulated depreciation |  |  | (96,255 | ) |  |  | (85,919 | ) |
| Total |  | $ | 206,700 |  |  | $ | 184,213 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-16-036603:notes:100]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Product Classes |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Residential products |  | $ | 181,735 |  |  | $ | 133,466 |  |  | $ | 340,716 |  |  | $ | 290,300 |  |
| Commercial & industrial products |  |  | 156,730 |  |  |  | 134,580 |  |  |  | 259,720 |  |  |  | 268,343 |  |
| Other |  |  | 28,911 |  |  |  | 20,314 |  |  |  | 53,475 |  |  |  | 41,535 |  |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-16-036603:notes:101]
|  |  | June 30, 2016 |  |  | December 31, 2015 |  |
| Raw material |  | $ | 226,110 |  |  | $ | 188,354 |  |
| Work-in-process |  |  | 4,347 |  |  |  | 2,856 |  |
| Finished goods |  |  | 150,032 |  |  |  | 144,747 |  |
| Reserves for excess and obsolete |  |  | (13,744 | ) |  |  | (10,582 | ) |
| Total |  | $ | 366,745 |  |  | $ | 325,375 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-036603:notes:102]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 286,720 |  |  | $ | 258,117 |  |  | $ | 534,736 |  |  | $ | 545,729 |  |
| International |  |  | 80,656 |  |  |  | 30,243 |  |  |  | 119,175 |  |  |  | 54,449 |  |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  | $ | 653,911 |  |  | $ | 600,178 |  |

[0001437749-16-036603:notes:103]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 57,352 |  |  | $ | 48,457 |  |  | $ | 104,212 |  |  | $ | 102,901 |  |
| International |  |  | 6,574 |  |  |  | 3,965 |  |  |  | 9,523 |  |  |  | 6,659 |  |
| Total adjusted EBITDA |  | $ | 63,926 |  |  | $ | 52,422 |  |  | $ | 113,735 |  |  | $ | 109,560 |  |
| Interest expense |  |  | (11,380 | ) |  |  | (10,763 | ) |  |  | (22,415 | ) |  |  | (22,031 | ) |
| Depreciation and amortization |  |  | (13,650 | ) |  |  | (10,129 | ) |  |  | (26,443 | ) |  |  | (19,163 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (2,909 | ) |  |  | (404 | ) |  |  | (2,782 | ) |  |  | (1,976 | ) |
| Non-cash share-based compensation expense (2) |  |  | (2,901 | ) |  |  | (2,582 | ) |  |  | (5,386 | ) |  |  | (5,090 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | (3,427 | ) |  |  | - |  |  |  | (4,795 | ) |
| Transaction costs and credit facility fees (4) |  |  | (237 | ) |  |  | (481 | ) |  |  | (760 | ) |  |  | (682 | ) |
| Business optimization expenses (5) |  |  | - |  |  |  | (1,444 | ) |  |  | (7,106 | ) |  |  | (1,738 | ) |
| Other |  |  | 15 |  |  |  | 280 |  |  |  | (48 | ) |  |  | 90 |  |
| Income before provision for income taxes |  | $ | 32,864 |  |  | $ | 23,472 |  |  | $ | 48,795 |  |  | $ | 54,175 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-036603:notes:104]
6. Segment Reporting

[0001437749-16-036603:notes:105]
Effective in the second quarter of 2016, the Company changed its segment reporting from one reportable segment to two reportable segments - Domestic and International - as a result of the recent Pramac acquisition and the ongoing strategy to expand the business internationally. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light and Pramac acquisitions, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of engine powered products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-16-036603:notes:106]
The Company's product offerings consist primarily of power products with a range of power output geared for varying end customer uses. Residential products and commercial & industrial products are each a class of products based on similar power output and end customer usage. The breakout of net sales between residential, commercial & industrial, and other products by product class is as follows:

[0001437749-16-036603:notes:107]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is a non-GAAP measure, and therefore reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-16-036603:notes:108]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments. |
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
|  | (3) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |
|  | (5) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-16-036603:notes:109]
The Company’s sales in the United States represented approximately 74% and 84% of total sales for the three months ended June 30, 2016 and 2015, respectively, and represented approximately 78% and 85% of total sales for the six months ended June 30, 2016 and 2015, respectively. Approximately 86% and 93% of the Company’s identifiable long-lived assets are located in the United States at June 30, 2016 and December 31, 2015, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-16-036603:notes:110]
[same as prior period, unchanged from 0001437749-16-031130:notes:111]

[0001437749-16-036603:notes:111]
[same as prior period, unchanged from 0001437749-16-031130:notes:112]

[0001437749-16-036603:notes:112]
[same as prior period, unchanged from 0001437749-16-031130:notes:113]

[0001437749-16-036603:notes:113]
[same as prior period, unchanged from 0001437749-16-031130:notes:114]


## us-gaap:TreasuryStockTextBlock

[0001437749-16-036603:notes:114]
10. Stock Repurchase Program

[0001437749-16-036603:notes:115]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the program, the Company may repurchase up to $200,000 of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The stock repurchase program may be suspended or discontinued at any time without prior notice. For the three months ended June 30, 2016, the Company repurchased 935,000 shares of its common stock for $34,576, funded with cash on hand. Since the inception of the program, the Company has repurchased 4,238,500 shares of its common stock for $134,518, funded with cash on hand.
