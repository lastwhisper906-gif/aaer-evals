# GNRC MD&A — 0001437749-16-036603


## mdna

[0001437749-16-036603:mdna:1]
[same as prior period, unchanged from 0001437749-16-031130:mdna:1]

[0001437749-16-036603:mdna:2]
[same as prior period, unchanged from 0001437749-16-031130:mdna:2]

[0001437749-16-036603:mdna:3]
[same as prior period, unchanged from 0001437749-16-031130:mdna:3]

[0001437749-16-036603:mdna:4]
|  | ● | our business, financial and operating results, and future economic performance; |
|  | ● | proposed new product and service offerings; and |
|  | ● | management's goals, expectations and objectives and other similar expressions concerning matters that are not historical facts. |

[0001437749-16-036603:mdna:5]
[same as prior period, unchanged from 0001437749-16-031130:mdna:7]

[0001437749-16-036603:mdna:6]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | availability, cost and quality of raw materials and key components used in producing our products; |
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |
|  | ● | the risk that our acquisitions will not be integrated successfully; |
|  | ● | difficulties we may encounter as our business expands globally; |
|  | ● | competitive factors in the industry in which we operate; |
|  | ● | our dependence on our distribution network; |
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |
|  | ● | loss of our key management and employees; |
|  | ● | increase in product and other liability claims or recalls; and |
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-036603:mdna:7]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2015 and in our Quarterly Reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-036603:mdna:8]
[same as prior period, unchanged from 0001437749-16-031130:mdna:21]

[0001437749-16-036603:mdna:9]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas and construction markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-16-036603:mdna:10]
[same as prior period, unchanged from 0001437749-16-031130:mdna:23]

[0001437749-16-036603:mdna:11]
[same as prior period, unchanged from 0001437749-16-031130:mdna:24]

[0001437749-16-036603:mdna:12]
[same as prior period, unchanged from 0001437749-16-031130:mdna:25]

[0001437749-16-036603:mdna:13]
[same as prior period, unchanged from 0001437749-16-031130:mdna:26]

[0001437749-16-036603:mdna:14]
[same as prior period, unchanged from 0001437749-16-031130:mdna:27]

[0001437749-16-036603:mdna:15]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2013 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment (ROI) driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. In addition, the importance of backup power for telecommunications infrastructure is increasing due to the growing importance of uninterrupted voice and data services. Also, in recent years, a more stringent regulatory environment around the flaring of natural gas at oil & gas drilling and production sites has been a catalyst for increased demand for natural gas fueled generators, including mobile solutions. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-16-036603:mdna:16]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the multiple major outage events that occurred during the second half of both 2011 and 2012 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to substantial organic revenue growth in 2012 with strong growth continuing during 2013. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-16-036603:mdna:17]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-16-036603:mdna:18]
Impact of business capital investment cycle.   The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions and credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-16-036603:mdna:19]
[same as prior period, unchanged from 0001437749-16-031130:mdna:32]

[0001437749-16-036603:mdna:20]
[same as prior period, unchanged from 0001437749-16-031130:mdna:33]

[0001437749-16-036603:mdna:21]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper, aluminum and other components we use in our products, together with foreign currency fluctuations, can have a material impact on our results of operations. We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-16-036603:mdna:22]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 23% to 27% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 28% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period, and for the subsequent quarters following the time period, varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-16-036603:mdna:23]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense increased during the six months ended June 30, 2016 compared to the six months ended June 30, 2015, primarily due to additional debt assumed in recent acquisitions and increased borrowings at other foreign subsidiaries. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q for further information.

[0001437749-16-036603:mdna:24]
[same as prior period, unchanged from 0001437749-16-031130:mdna:37]

[0001437749-16-036603:mdna:25]
[same as prior period, unchanged from 0001437749-16-031130:mdna:38]

[0001437749-16-036603:mdna:26]
Three months ended June 30, 2016 compared to the three months ended June 30, 2015

[0001437749-16-036603:mdna:27]
[same as prior period, unchanged from 0001437749-16-031130:mdna:40]

[0001437749-16-036603:mdna:28]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  |  | 79,016 |  |  |  | 27.4 | % |
| Cost of goods sold |  |  | 243,229 |  |  |  | 192,463 |  |  |  | 50,766 |  |  |  | 26.4 | % |
| Gross profit |  |  | 124,147 |  |  |  | 95,897 |  |  |  | 28,250 |  |  |  | 29.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 42,366 |  |  |  | 28,474 |  |  |  | 13,892 |  |  |  | 48.8 | % |
| Research and development |  |  | 9,889 |  |  |  | 8,412 |  |  |  | 1,477 |  |  |  | 17.6 | % |
| General and administrative |  |  | 19,593 |  |  |  | 13,564 |  |  |  | 6,029 |  |  |  | 44.4 | % |
| Amortization of intangible assets |  |  | 8,217 |  |  |  | 5,980 |  |  |  | 2,237 |  |  |  | 37.4 | % |
| Total operating expenses |  |  | 80,065 |  |  |  | 56,430 |  |  |  | 23,635 |  |  |  | 41.9 | % |
| Income from operations |  |  | 44,082 |  |  |  | 39,467 |  |  |  | 4,615 |  |  |  | 11.7 | % |
| Total other income (expense), net |  |  | (11,218 | ) |  |  | (15,995 | ) |  |  | 4,777 |  |  |  | -29.9 | % |
| Income before provision for income taxes |  |  | 32,864 |  |  |  | 23,472 |  |  |  | 9,392 |  |  |  | 40.0 | % |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 3,293 |  |  |  | 38.2 | % |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 6,099 |  |  |  | 41.1 | % |
| Net income attributable to noncontrolling interests |  |  | 55 |  |  |  | - |  |  |  | 55 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  |  | 6,044 |  |  |  | 40.7 | % |

[0001437749-16-036603:mdna:29]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-16-036603:mdna:30]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 286,720 |  |  | $ | 258,117 |  |  |  | 28,603 |  |  |  | 11.1 | % |
| International |  |  | 80,656 |  |  |  | 30,243 |  |  |  | 50,413 |  |  |  | 166.7 | % |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  |  | 79,016 |  |  |  | 27.4 | % |

[0001437749-16-036603:mdna:31]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 57,364 |  |  | $ | 48,838 |  |  |  | 8,526 |  |  |  | 17.5 | % |
| International |  |  | 6,562 |  |  |  | 3,584 |  |  |  | 2,978 |  |  |  | 83.1 | % |
| Total Adjusted EBITDA |  | $ | 63,926 |  |  | $ | 52,422 |  |  |  | 11,504 |  |  |  | 21.9 | % |

[0001437749-16-036603:mdna:32]
17

[0001437749-16-036603:mdna:33]
The following table sets forth our product class information for the periods indicated:

[0001437749-16-036603:mdna:34]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 181,735 |  |  | $ | 133,466 |  |  |  | 48,269 |  |  |  | 36.2 | % |
| Commercial & industrial products |  |  | 156,730 |  |  |  | 134,580 |  |  |  | 22,150 |  |  |  | 16.5 | % |
| Other |  |  | 28,911 |  |  |  | 20,314 |  |  |  | 8,597 |  |  |  | 42.3 | % |
| Total net sales |  | $ | 367,376 |  |  | $ | 288,360 |  |  |  | 79,016 |  |  |  | 27.4 | % |

[0001437749-16-036603:mdna:35]
Net sales.    The increase in Domestic sales for the three months ended June 30, 2016 was primarily due to the contribution from the CHP acquisition, which closed in August 2015, and an increase in shipments of home standby generators. These increases were partially offset by the ongoing significant declines in shipments of mobile products into oil & gas and general rental markets.

[0001437749-16-036603:mdna:36]
The increase in International sales for the three months ended June 30, 2016 was largely due to the contribution from the Pramac acquisition, which closed in March 2016, partially offset by declines in organic shipments into the United Kingdom and Latin American markets.

[0001437749-16-036603:mdna:37]
The total contribution from non-annualized recent acquisitions to the three months ended June 30, 2016 was $88.1 million.

[0001437749-16-036603:mdna:38]
Gross profit.    Gross profit margin for the second quarter of 2016 was 33.8% compared to 33.3% in the prior-year second quarter. The current year quarter includes $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of this adjustment, gross profit margin was 34.7%, an improvement of 140 basis points as compared to the prior year. The increase was primarily driven by the impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar in recent quarters, along with favorable overall product mix, partially offset by the net mix impact from recent acquisitions.

[0001437749-16-036603:mdna:39]
Operating expenses.    The increase in operating expenses was primarily due to the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-16-036603:mdna:40]
Other expense.    The decrease in other expense was primarily due to a prior year non-cash $3.4 million loss on extinguishment of debt resulting from a voluntary $100.0 million prepayment of term loan debt.

[0001437749-16-036603:mdna:41]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2016 and 2015 were 36.4% and 36.8%, respectively.

[0001437749-16-036603:mdna:42]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, as adjusted for net income attributable to noncontrolling interests.

[0001437749-16-036603:mdna:43]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the three months ended June 30, 2016 were 20.0% of net sales as compared to 18.8% of net sales for the three months ended June 30, 2015. This increase was primarily due to favorable product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar in recent quarters, partially offset by higher operating expenses.

[0001437749-16-036603:mdna:44]
Adjusted EBITDA margins for the International segment for the three months ended June 30, 2016 were 8.2% of net sales as compared to 13.1% of net sales for the three months ended June 30, 2015. This decrease was primarily due to unfavorable product and customer mix along with lower absorption of fixed manufacturing overhead costs and reduced leverage of operating expenses on the lower organic sales volumes.

[0001437749-16-036603:mdna:45]
Adjusted Net Income.    Adjusted Net Income of $42.7 million for the three months ended June 30, 2016 increased 21.0% from $35.3 million for the three months ended June 30, 2015, due to the factors outlined above, partially offset by the adjusted net income attributable to noncontrolling interests and an increase in cash income tax expense.

[0001437749-16-036603:mdna:46]
[same as prior period, unchanged from 0001437749-16-031130:mdna:50]

[0001437749-16-036603:mdna:47]
Six months ended June 30, 2016 compared to the six months ended June 30, 2015

[0001437749-16-036603:mdna:48]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-16-036603:mdna:49]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 653,911 |  |  | $ | 600,178 |  |  |  | 53,733 |  |  |  | 9.0 | % |
| Cost of goods sold |  |  | 431,704 |  |  |  | 401,678 |  |  |  | 30,026 |  |  |  | 7.5 | % |
| Gross profit |  |  | 222,207 |  |  |  | 198,500 |  |  |  | 23,707 |  |  |  | 11.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 79,635 |  |  |  | 58,602 |  |  |  | 21,033 |  |  |  | 35.9 | % |
| Research and development |  |  | 18,086 |  |  |  | 16,575 |  |  |  | 1,511 |  |  |  | 9.1 | % |
| General and administrative |  |  | 37,426 |  |  |  | 27,770 |  |  |  | 9,656 |  |  |  | 34.8 | % |
| Amortization of intangible assets |  |  | 16,014 |  |  |  | 11,175 |  |  |  | 4,839 |  |  |  | 43.3 | % |
| Total operating expenses |  |  | 151,161 |  |  |  | 114,122 |  |  |  | 37,039 |  |  |  | 32.5 | % |
| Income from operations |  |  | 71,046 |  |  |  | 84,378 |  |  |  | (13,332 | ) |  |  | -15.8 | % |
| Total other income (expense), net |  |  | (22,251 | ) |  |  | (30,203 | ) |  |  | 7,952 |  |  |  | -26.3 | % |
| Income before provision for income taxes |  |  | 48,795 |  |  |  | 54,175 |  |  |  | (5,380 | ) |  |  | -9.9 | % |
| Provision for income taxes |  |  | 17,640 |  |  |  | 19,646 |  |  |  | (2,006 | ) |  |  | -10.2 | % |
| Net income |  |  | 31,155 |  |  |  | 34,529 |  |  |  | (3,374 | ) |  |  | -9.8 | % |
| Net income attributable to noncontrolling interests |  |  | 59 |  |  |  | - |  |  |  | 59 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 31,096 |  |  | $ | 34,529 |  |  |  | (3,433 | ) |  |  | -9.9 | % |

[0001437749-16-036603:mdna:50]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-16-036603:mdna:51]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 534,736 |  |  | $ | 545,729 |  |  |  | (10,993 | ) |  |  | -2.0 | % |
| International |  |  | 119,175 |  |  |  | 54,449 |  |  |  | 64,726 |  |  |  | 118.9 | % |
| Total net sales |  | $ | 653,911 |  |  | $ | 600,178 |  |  |  | 53,733 |  |  |  | 9.0 | % |

[0001437749-16-036603:mdna:52]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 104,183 |  |  | $ | 103,283 |  |  |  | 900 |  |  |  | 0.9 | % |
| International |  |  | 9,552 |  |  |  | 6,277 |  |  |  | 3,275 |  |  |  | 52.2 | % |
| Total Adjusted EBITDA |  | $ | 113,735 |  |  | $ | 109,560 |  |  |  | 4,175 |  |  |  | 3.8 | % |

[0001437749-16-036603:mdna:53]
The following table sets forth our product class information for the periods indicated:

[0001437749-16-036603:mdna:54]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 340,716 |  |  | $ | 290,300 |  |  |  | 50,416 |  |  |  | 17.4 | % |
| Commercial & industrial products |  |  | 259,720 |  |  |  | 268,343 |  |  |  | (8,623 | ) |  |  | -3.2 | % |
| Other |  |  | 53,475 |  |  |  | 41,535 |  |  |  | 11,940 |  |  |  | 28.7 | % |
| Total net sales |  | $ | 653,911 |  |  | $ | 600,178 |  |  |  | 53,733 |  |  |  | 9.0 | % |

[0001437749-16-036603:mdna:55]
Net sales.    The decrease in Domestic sales for the six months ended June 30, 2016 was primarily due to a significant reduction in shipments of mobile products into oil & gas and general rental markets, partially offset by the contribution from the CHP acquisition.

[0001437749-16-036603:mdna:56]
The increase in International sales for the six months ended June 30, 2016 was largely due to the contribution from the Pramac acquisition, partially offset by declines in organic shipments into the United Kingdom and Latin American markets.

[0001437749-16-036603:mdna:57]
The total contribution from non-annualized recent acquisitions to the six months ended June 30, 2016 was $125.3 million.

[0001437749-16-036603:mdna:58]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the six months ended June 30, 2016 includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write-downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. The decrease in net income attributable to Generac Holdings Inc. was primarily due to these charges and the adjustment for net income attributable to noncontrolling interests, partially offset by the other factors outlined in this section.

[0001437749-16-036603:mdna:59]
Gross profit.    Gross profit margin for the first half of 2016 was 34.0% compared to 33.1% in the prior-year first half, which includes the impact of the aforementioned $2.7 million of business optimization charges classified within cost of goods sold, as well as $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these adjustments, gross profit margin was 34.9%, an improvement of 180 basis points over the prior year. The increase was primarily due to favorable overall product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar in recent quarters. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current year. These factors were partially offset by the net mix impact from recent acquisitions.

[0001437749-16-036603:mdna:60]
Operating expenses.    Excluding the impact of the aforementioned $4.4 million of business optimization charges classified within operating expenses, operating expenses increased $32.6 million, or 28.6%, to $146.7 million for the six months ended June 30, 2016 from $114.1 million for the six months ended June 30, 2015. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-16-036603:mdna:61]
Other expense.    The decrease in other expense was primarily due to a prior year non-cash $4.8 million loss on extinguishment of debt resulting from $150.0 million of voluntary prepayments of term loan debt.

[0001437749-16-036603:mdna:62]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2016 and 2015 were 36.2% and 36.3%, respectively.

[0001437749-16-036603:mdna:63]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the six months ended June 30, 2016 were 19.5% of net sales as compared to 18.9% of net sales for the six months ended June 30, 2015. This increase was primarily due to favorable product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar in recent quarters, partially offset by higher operating expenses.

[0001437749-16-036603:mdna:64]
Adjusted EBITDA margins for the International segment for the six months ended June 30, 2016 were 8.0% of net sales as compared to 12.2% of net sales for the six months ended June 30, 2015. This decrease was primarily due to unfavorable product and customer mix along with lower absorption of fixed manufacturing overhead costs and reduced leverage of operating expenses on the lower organic sales volumes.

[0001437749-16-036603:mdna:65]
Adjusted Net Income.    Adjusted Net Income of $73.6 million for the six months ended June 30, 2016 increased 5.6% from $69.7 million for the six months ended June 30, 2015, due to a decrease in cash income tax expense and the factors outlined above, partially offset by the adjusted net income attributable to noncontrolling interests.

[0001437749-16-036603:mdna:66]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-16-036603:mdna:67]
[same as prior period, unchanged from 0001437749-16-031130:mdna:51]

[0001437749-16-036603:mdna:68]
[same as prior period, unchanged from 0001437749-16-031130:mdna:52]

[0001437749-16-036603:mdna:69]
The Company’s credit agreements provide for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of June 30, 2016 was above 3.00 to 1.00. As of June 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-036603:mdna:70]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, which was used as a voluntary prepayment of Term Loan borrowings. As of June 30, 2016, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all covenants of the Amended ABL Facility.

[0001437749-16-036603:mdna:71]
[same as prior period, unchanged from 0001437749-16-031130:mdna:55]

[0001437749-16-036603:mdna:72]
At June 30, 2016, we had cash and cash equivalents on hand of $75.6 million and $142.1 million of availability under our Amended ABL Facility, net of outstanding letters of credit.

[0001437749-16-036603:mdna:73]
In August 2015, the Company’s Board of Directors approved a $200.0 million stock repurchase program. Under the program, the Company may repurchase up to $200.0 million of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand or available borrowings. The stock repurchase program may be suspended or discontinued at any time without prior notice. For the three months ended June 30, 2016, the Company repurchased 935,000 shares of its common stock for $34.6 million, funded with cash on hand. Since the inception of the program, the Company has repurchased 4,238,500 shares of its common stock for $134.5 million, funded with cash on hand.

[0001437749-16-036603:mdna:74]
[same as prior period, unchanged from 0001437749-16-031130:mdna:58]

[0001437749-16-036603:mdna:75]
[same as prior period, unchanged from 0001437749-16-031130:mdna:59]

[0001437749-16-036603:mdna:76]
[same as prior period, unchanged from 0001437749-16-031130:mdna:60]

[0001437749-16-036603:mdna:77]
Six months ended June 30, 2016 compared to the six months ended June 30, 2015

[0001437749-16-036603:mdna:78]
[same as prior period, unchanged from 0001437749-16-031130:mdna:62]

[0001437749-16-036603:mdna:79]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 81,235 |  |  | $ | 41,579 |  |  |  | 39,656 |  |  |  | 95.4 | % |
| Net cash used in investing activities |  |  | (74,843 | ) |  |  | (13,937 | ) |  |  | (60,906 | ) |  |  | 437.0 | % |
| Net cash used in financing activities |  |  | (46,723 | ) |  |  | (59,752 | ) |  |  | 13,029 |  |  |  | -21.8 | % |

[0001437749-16-036603:mdna:80]
The 95.4% increase in net cash provided by operating activities was primarily driven by a large reduction in working capital during the current year as compared to a large increase in the prior year.

[0001437749-16-036603:mdna:81]
The increase in net cash used in investing activities for the six months ended June 30, 2016 was primarily due to cash payments of $60.9 million related to the acquisition of Pramac in the first quarter of 2016.

[0001437749-16-036603:mdna:82]
Net cash used in financing activities for the six months ended June 30, 2016 primarily represents $34.6 million of payments for the repurchase of the Company’s common stock, $17.0 million of debt repayments ($10.7 million of long-term borrowings and $6.3 million of short-term borrowings) and $12.1 million related to the net share settlement of equity awards. These payments were partially offset by $10.3 million cash proceeds from short-term borrowings and a $6.7 million cash inflow related to excess tax benefits of equity awards.

[0001437749-16-036603:mdna:83]
Net cash used in financing activities for the six months ended June 30, 2015 primarily represents $161.8 million of debt repayments ($150.4 million of long-term borrowings and $11.4 million of short-term borrowings) partially offset by $109.0 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the ABL facility and $9.0 million from short-term borrowings). In addition, the Company paid $12.3 million related to the net share settlement of equity awards, which was partially offset by $8.9 million of cash inflow related to the excess tax benefits of equity awards.

[0001437749-16-036603:mdna:84]
[same as prior period, unchanged from 0001437749-16-031130:mdna:68]

[0001437749-16-036603:mdna:85]
In connection with the Pramac acquisition on March 1, 2016, the Company assumed $21.1 million of short-term borrowings and $18.6 million of long-term debt and capital lease obligations. Refer to Note 2, “Acquisitions,” to the condensed consolidated financial statements for further information. Other than the assumption of the Pramac debt, there have been no material changes to our contractual obligations since the February 26, 2016 filing of our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-036603:mdna:86]
[same as prior period, unchanged from 0001437749-16-031130:mdna:70]

[0001437749-16-036603:mdna:87]
[same as prior period, unchanged from 0001437749-16-031130:mdna:71]

[0001437749-16-036603:mdna:88]
[same as prior period, unchanged from 0001437749-16-031130:mdna:72]

[0001437749-16-036603:mdna:89]
[same as prior period, unchanged from 0001437749-16-031130:mdna:73]

[0001437749-16-036603:mdna:90]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2015, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; derivative accounting; income taxes and share based compensation.

[0001437749-16-036603:mdna:91]
[same as prior period, unchanged from 0001437749-16-031130:mdna:75]

[0001437749-16-036603:mdna:92]
[same as prior period, unchanged from 0001437749-16-031130:mdna:76]

[0001437749-16-036603:mdna:93]
The computation of Adjusted EBITDA attributable to the Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement dated as of May 31, 2013, as amended. To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-036603:mdna:94]
[same as prior period, unchanged from 0001437749-16-031130:mdna:78]

[0001437749-16-036603:mdna:95]
|  | • | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |
|  | • | to allocate resources to enhance the financial performance of our business; |
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2016 proxy statement; |
|  | • | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |
|  | • | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-16-036603:mdna:96]
[same as prior period, unchanged from 0001437749-16-031130:mdna:84]

[0001437749-16-036603:mdna:97]
|  | • | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |
|  | • | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our company, including our ability to service our debt and other cash needs; and |
|  | • | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-16-036603:mdna:98]
[same as prior period, unchanged from 0001437749-16-031130:mdna:88]

[0001437749-16-036603:mdna:99]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains and write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |
|  | • | are non-cash in nature, such as share-based compensation. |

[0001437749-16-036603:mdna:100]
[same as prior period, unchanged from 0001437749-16-031130:mdna:92]

[0001437749-16-036603:mdna:101]
[same as prior period, unchanged from 0001437749-16-031130:mdna:93]

[0001437749-16-036603:mdna:102]
|  | • | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |
|  | • | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |
|  | • | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |
|  | • | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |
|  | • | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-16-036603:mdna:103]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-16-036603:mdna:104]
[same as prior period, unchanged from 0001437749-16-031130:mdna:101]

[0001437749-16-036603:mdna:105]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-16-036603:mdna:106]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Net income attributable to noncontrolling interests (a) |  |  | 55 |  |  |  | - |  |  |  | 59 |  |  |  | - |  |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 31,155 |  |  |  | 34,529 |  |
| Interest expense |  |  | 11,380 |  |  |  | 10,763 |  |  |  | 22,415 |  |  |  | 22,031 |  |
| Depreciation and amortization |  |  | 13,650 |  |  |  | 10,129 |  |  |  | 26,443 |  |  |  | 19,163 |  |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 17,640 |  |  |  | 19,646 |  |
| Non-cash write-down and other adjustments (b) |  |  | 2,909 |  |  |  | 404 |  |  |  | 2,782 |  |  |  | 1,976 |  |
| Non-cash share-based compensation expense (c) |  |  | 2,901 |  |  |  | 2,582 |  |  |  | 5,386 |  |  |  | 5,090 |  |
| Loss on extinguishment of debt (d) |  |  | - |  |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |
| Transaction costs and credit facility fees (e) |  |  | 237 |  |  |  | 481 |  |  |  | 760 |  |  |  | 682 |  |
| Business optimization expenses (f) |  |  | - |  |  |  | 1,444 |  |  |  | 7,106 |  |  |  | 1,738 |  |
| Other |  |  | (15 | ) |  |  | (280 | ) |  |  | 48 |  |  |  | (90 | ) |
| Adjusted EBITDA |  |  | 63,926 |  |  |  | 52,422 |  |  |  | 113,735 |  |  |  | 109,560 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,623 |  |  |  | - |  |  |  | 2,307 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 62,303 |  |  | $ | 52,422 |  |  | $ | 111,428 |  |  | $ | 109,560 |  |

[0001437749-16-036603:mdna:107]
(a)   Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting adjustments, including the step-up in value of inventories and intangible amortization, of $4.3 million and $5.5 million for the three and six months ended June 30, 2016, respectively.

[0001437749-16-036603:mdna:108]
(b)   Represents the following non-cash charges for the three and six months ended June 30, 2016 and 2015: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments.

[0001437749-16-036603:mdna:109]
[same as prior period, unchanged from 0001437749-16-031130:mdna:106]

[0001437749-16-036603:mdna:110]
|  | ● | The gains/losses on disposals of assets result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and |
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. |

[0001437749-16-036603:mdna:111]
(c)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their vesting period.

[0001437749-16-036603:mdna:112]
(d)  Represents the non-cash write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-16-036603:mdna:113]
(e) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and revolving credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-16-036603:mdna:114]
(f) For the six months ended June 30, 2016, represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry. For the three and six months ended June 30, 2015, represents severance and other non-recurring restructuring charges related to the integration of our facilities, which represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-16-036603:mdna:115]
[same as prior period, unchanged from 0001437749-16-031130:mdna:114]

[0001437749-16-036603:mdna:116]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-16-036603:mdna:117]
[same as prior period, unchanged from 0001437749-16-031130:mdna:116]

[0001437749-16-036603:mdna:118]
[same as prior period, unchanged from 0001437749-16-031130:mdna:117]

[0001437749-16-036603:mdna:119]
[same as prior period, unchanged from 0001437749-16-031130:mdna:118]

[0001437749-16-036603:mdna:120]
|  | • | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |
|  | • | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |
|  | • | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-16-036603:mdna:121]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-16-036603:mdna:122]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 20,888 |  |  | $ | 14,844 |  |  | $ | 31,096 |  |  | $ | 34,529 |  |
| Net income attributable to noncontrolling interests |  |  | 55 |  |  |  | - |  |  |  | 59 |  |  |  | - |  |
| Net income |  |  | 20,943 |  |  |  | 14,844 |  |  |  | 31,155 |  |  |  | 34,529 |  |
| Provision for income taxes |  |  | 11,921 |  |  |  | 8,628 |  |  |  | 17,640 |  |  |  | 19,646 |  |
| Income before provision for income taxes |  |  | 32,864 |  |  |  | 23,472 |  |  |  | 48,795 |  |  |  | 54,175 |  |
| Amortization of intangible assets |  |  | 8,217 |  |  |  | 5,980 |  |  |  | 16,014 |  |  |  | 11,175 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,066 |  |  |  | 1,639 |  |  |  | 2,122 |  |  |  | 3,344 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 3,443 |  |  |  | 240 |  |  |  | 4,690 |  |  |  | 503 |  |
| Business optimization expenses |  |  | - |  |  |  | 1,444 |  |  |  | 7,106 |  |  |  | 1,738 |  |
| Adjusted net income before provision for income taxes |  |  | 45,590 |  |  |  | 36,202 |  |  |  | 78,727 |  |  |  | 75,730 |  |
| Cash income tax expense (b) |  |  | (1,450 | ) |  |  | (920 | ) |  |  | (3,270 | ) |  |  | (6,035 | ) |
| Adjusted net income |  |  | 44,140 |  |  |  | 35,282 |  |  |  | 75,457 |  |  |  | 69,695 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,451 |  |  |  | - |  |  |  | 1,881 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 42,689 |  |  | $ | 35,282 |  |  | $ | 73,576 |  |  | $ | 69,695 |  |
| Adjusted net income per common share attributable to Generac Holdings, Inc. - diluted: |  | $ | 0.64 |  |  | $ | 0.50 |  |  | $ | 1.11 |  |  | $ | 0.99 |  |
| Weighted average common shares outstanding - diluted: |  |  | 66,388,581 |  |  |  | 70,063,063 |  |  |  | 66,465,770 |  |  |  | 70,099,940 |  |

[0001437749-16-036603:mdna:123]
[same as prior period, unchanged from 0001437749-16-031130:mdna:124]

[0001437749-16-036603:mdna:124]
(b) Amount for the three and six months ended June 30, 2016 is based on an anticipated cash income tax rate of approximately 5% for the full year-ended 2016. Amount for the three and six months ended June 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2015. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-16-036603:mdna:125]
[same as prior period, unchanged from 0001437749-16-031130:mdna:126]

[0001437749-16-036603:mdna:126]
[same as prior period, unchanged from 0001437749-16-031130:mdna:127]
