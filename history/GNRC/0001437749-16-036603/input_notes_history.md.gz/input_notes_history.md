# GNRC note change history — 0001437749-16-031130 → 0001437749-16-036603


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036603:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2016 and December 31, 2015 was approximately $36,200 and $32,400, respectively.
  (was, 2016-05-06, similarity 0.9923):
[0001437749-16-031130:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2016 and December 31, 2015 was approximately $30,900 and $32,400, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036603:note_history:2]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2016-05-06, similarity 0.9989):
[0001437749-16-031130:note_history:2]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- added (2016-08-05):
[0001437749-16-036603:note_history:3]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |
|  | ● | On March 1, 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

- added (2016-08-05):
[0001437749-16-036603:note_history:4]
The condensed consolidated balance sheet as of June 30, 2016, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2016 and 2015, and the condensed consolidated statements of cash flows for the six months ended June 30, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2016-08-05):
[0001437749-16-036603:note_history:5]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. ASU 2014-09, as amended by ASU 2015-14, 
Revenue from Contracts with Customers (Topic
  (was, 2016-05-06, similarity 0.658):
[0001437749-16-031130:note_history:5]
2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- added (2016-08-05):
[0001437749-16-036603:note_history:6]
606): D

- added (2016-08-05):
[0001437749-16-036603:note_history:7]
eferral of the Effective Date
, ASU 2016-08, 
Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations
, ASU 2016-10, 
Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing

- added (2016-08-05):
[0001437749-16-036603:note_history:8]
,
 and ASU 2016-12, 
Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients
, becomes effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- changed (2016-08-05):
[0001437749-16-036603:note_history:9]
In March 2016, the FASB issued ASU 2016-09, 
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits and forfeitures. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classification on the statements of cash flow.
  (was, 2016-05-06, similarity 0.9993):
[0001437749-16-031130:note_history:9]
In March 2016, the FASB issued ASU 2016-09, 
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits and forfeitures. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classifications on the statements of cash flow.

- added (2016-08-05):
[0001437749-16-036603:note_history:10]
In the first quarter of 2016, the Company adopted ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965. Also in the first quarter of 2016, the Company adopted ASU 2015-17, 
Income Taxes: Balance Sheet Classification of Deferred Taxes
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.

- changed (2016-08-05):
[0001437749-16-036603:note_history:11]
There are several other new accounting pronouncements issued by the FASB. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.
  (was, 2016-05-06, similarity 0.8419):
[0001437749-16-031130:note_history:11]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

- removed (2016-08-05):
[0001437749-16-031130:note_history:12]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:13]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:14]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East, Africa and Asia Pacific. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:15]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:16]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:17]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:18]
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:19]
|  | ● | On March 1, 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

- removed (2016-08-05):
[0001437749-16-031130:note_history:20]
The condensed consolidated balance sheet as of March 31, 2016, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2016 and 2015, and the condensed consolidated statements of cash flows for the three months ended March 31, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2016-08-05):
[0001437749-16-031130:note_history:21]
In May 2014, the Financial Accounting Standards Board (

- removed (2016-08-05):
[0001437749-16-031130:note_history:22]
FASB)

- removed (2016-08-05):
[0001437749-16-031130:note_history:23]
issued Accounting Standards Update (

- removed (2016-08-05):
[0001437749-16-031130:note_history:24]
ASU)

- removed (2016-08-05):
[0001437749-16-031130:note_history:25]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965.

- removed (2016-08-05):
[0001437749-16-031130:note_history:26]
In November 2015, the FASB issued ASU 2015-17, 
I

- removed (2016-08-05):
[0001437749-16-031130:note_history:27]
ncome Taxes: Balance Sheet Classification of Deferred Taxes
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated balance sheets. The guidance was adopted by the Company in the first quarter of 2016 and was applied on a retrospective basis. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036603:note_history:28]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 33,649 |  |  |  | 8,594 |  |
| Total |  | $ | 33,649 |  |  | $ | 8,594 |  |
  (was, 2016-05-06, similarity 0.9742):
[0001437749-16-031130:note_history:28]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 34,055 |  |  |  | 8,594 |  |
| Total |  | $ | 34,055 |  |  | $ | 8,594 |  |

- changed (2016-08-05):
[0001437749-16-036603:note_history:29]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (27,783 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,973 |  |  |  | 1,694 |  |
| Other |  |  | 16,543 |  |  |  | 12,000 |  |
| Total |  |  | 1,047,733 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 12,374 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 523 |  |  |  | 157 |  |
| Total |  | $ | 1,034,836 |  |  | $ | 1,037,132 |  |
  (was, 2016-05-06, similarity 0.9896):
[0001437749-16-031130:note_history:29]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (28,848 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligations |  |  | 5,402 |  |  |  | 1,694 |  |
| Other |  |  | 27,567 |  |  |  | 12,000 |  |
| Total |  |  | 1,058,121 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 10,405 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 570 |  |  |  | 157 |  |
| Total |  | $ | 1,047,146 |  |  | $ | 1,037,132 |  |

- changed (2016-08-05):
[0001437749-16-036603:note_history:30]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of June 30, 2016 was above 3.00 to 1.00.
  (was, 2016-05-06, similarity 0.8892):
[0001437749-16-031130:note_history:30]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of March 31, 2016 was above 3.00 to 1.00. As of March 31, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- added (2016-08-05):
[0001437749-16-036603:note_history:31]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of June 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2016-08-05):
[0001437749-16-036603:note_history:32]
The Company’s credit agreements also originally provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.
  (was, 2016-05-06, similarity 0.9876):
[0001437749-16-031130:note_history:32]
The Company’s credit agreements also provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- changed (2016-08-05):
[0001437749-16-036603:note_history:33]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $483 of new debt issuance costs in 2015.
  (was, 2016-05-06, similarity 0.9164):
[0001437749-16-031130:note_history:33]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxed certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt).

- changed (2016-08-05):
[0001437749-16-036603:note_history:34]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of June 30, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $142,123 of availability, net of outstanding letters of credit.
  (was, 2016-05-06, similarity 0.9842):
[0001437749-16-031130:note_history:34]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of March 31, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

- added (2016-08-05):
[0001437749-16-036603:note_history:35]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2016-08-05):
[0001437749-16-036603:note_history:36]
As of June 30, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $33,649 and $8,594, respectively.
  (was, 2016-05-06, similarity 0.9735):
[0001437749-16-031130:note_history:36]
As of March 31, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $34,055 and $8,594, respectively.

- removed (2016-08-05):
[0001437749-16-031130:note_history:37]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000, which was applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036603:note_history:38]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (27,783 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,973 |  |  |  | 1,694 |  |
| Other |  |  | 16,543 |  |  |  | 12,000 |  |
| Total |  |  | 1,047,733 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 12,374 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 523 |  |  |  | 157 |  |
| Total |  | $ | 1,034,836 |  |  | $ | 1,037,132 |  |
  (was, 2016-05-06, similarity 0.9896):
[0001437749-16-031130:note_history:38]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (28,848 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligations |  |  | 5,402 |  |  |  | 1,694 |  |
| Other |  |  | 27,567 |  |  |  | 12,000 |  |
| Total |  |  | 1,058,121 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 10,405 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 570 |  |  |  | 157 |  |
| Total |  | $ | 1,047,146 |  |  | $ | 1,037,132 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036603:note_history:39]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 33,649 |  |  |  | 8,594 |  |
| Total |  | $ | 33,649 |  |  | $ | 8,594 |  |
  (was, 2016-05-06, similarity 0.9742):
[0001437749-16-031130:note_history:39]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 34,055 |  |  |  | 8,594 |  |
| Total |  | $ | 34,055 |  |  | $ | 8,594 |  |
