# GNRC note change history — 0001437749-24-024883 → 0001437749-24-033337


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001437749-24-033337:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2024, and  December 31, 2023, was $146,366 and $158,028, respectively.
  (was, 2024-08-06, similarity 0.9558):
[0001437749-24-024883:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2024, and  December 31, 2023, was approximately $157,772 and $158,028, respectively.

- changed (2024-11-05):
[0001437749-24-033337:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy ("PHS") filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.
  (was, 2024-08-06, similarity 0.9969):
[0001437749-24-024883:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

- changed (2024-11-05):
[0001437749-24-033337:note_history:3]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.
  (was, 2024-08-06, similarity 0.7506):
[0001437749-24-024883:note_history:3]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

- added (2024-11-05):
[0001437749-24-033337:note_history:4]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

- changed (2024-11-05):
[0001437749-24-033337:note_history:5]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronic's purchasing practices, and is pursuing a counterclaim in connection with the arbitration.
  (was, 2024-08-06, similarity 0.9994):
[0001437749-24-024883:note_history:5]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

- added (2024-11-05):
[0001437749-24-033337:note_history:6]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida. Case No. 24-cv-02412. The complaint alleges that home standby generators manufactured or sold to consumers from 2021-2024 contain a latent defect that  may cause the generator to malfunction. Plaintiffs assert breaches of warranty, tort-based, statutory, and unjust enrichment claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

- removed (2024-11-05):
[0001437749-24-024883:note_history:7]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest that will also be part of the appeal.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001437749-24-033337:note_history:8]
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |
  (was, 2024-08-06, similarity 0.8689):
[0001437749-24-024883:note_history:8]
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |

- changed (2024-11-05):
[0001437749-24-033337:note_history:9]
The condensed consolidated balance sheet as of  September 30, 2024, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2024-08-06, similarity 0.9033):
[0001437749-24-024883:note_history:9]
The condensed consolidated balance sheet as of  June 30, 2024, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2024-11-05):
[0001437749-24-033337:note_history:10]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements or disclosures.
  (was, 2024-08-06, similarity 0.9935):
[0001437749-24-024883:note_history:10]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements.

- changed (2024-11-05):
[0001437749-24-033337:note_history:11]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2024-08-06, similarity 0.9165):
[0001437749-24-024883:note_history:11]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the six months ended  June 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001437749-24-033337:note_history:12]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $65,540 and $81,769, respectively.
  (was, 2024-08-06, similarity 0.9717):
[0001437749-24-024883:note_history:12]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $66,407 and $81,769, respectively.

- added (2024-11-05):
[0001437749-24-033337:note_history:13]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan Facility |  | $ | 721,875 |  |  | $ | 745,313 |  |
| Tranche B Term Loan Facility |  |  | 500,000 |  |  |  | 530,000 |  |
| Original issue discount and capitalized debt fees |  |  | (8,853 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 90,622 |  |  |  | 71,308 |  |
| Other |  |  | 6,169 |  |  |  | 9,512 |  |
| Total |  |  | 1,459,813 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 53,193 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 45,983 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,360,637 |  |  | $ | 1,447,553 |  |

- added (2024-11-05):
[0001437749-24-033337:note_history:14]
The Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments maturing at the end of each quarter commencing  September 2023, with a balloon payment due  June 2027. The Tranche B Term Loan Facility matures on  July 3, 2031, and is repayable in installments maturing at the end of each quarter commencing  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  September 30, 2024, are as follows:

- added (2024-11-05):
[0001437749-24-033337:note_history:15]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 9,375 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 11,875 |  |
| 2025 |  |  | 46,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 150,000 |  |  |  | 755,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 467,500 |  |  |  | - |  |  |  | 467,500 |  |
| Total |  | $ | 721,875 |  |  | $ | 500,000 |  |  | $ | 150,000 |  |  | $ | 1,371,875 |  |

- added (2024-11-05):
[0001437749-24-033337:note_history:16]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (“original Term Loan B Facility”) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.

- added (2024-11-05):
[0001437749-24-033337:note_history:17]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the former Tranche B Term Loan Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031. The new Tranche B Term Loan Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the former Tranche B Term Loan Facility of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The new Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.95% combined rate as of  September 30, 2024.

- added (2024-11-05):
[0001437749-24-033337:note_history:18]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2024, the Company’s net secured leverage ratio was 1.70 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2024-11-05):
[0001437749-24-033337:note_history:19]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan A facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%, resulting in a 6.93% combined interest rate for the Tranche A Term Loan Facility and Revolving Facility as of  September 30, 2024.
  (was, 2024-08-06, similarity 0.633):
[0001437749-24-024883:note_history:19]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.90%.

- added (2024-11-05):
[0001437749-24-033337:note_history:20]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2024, the Company’s total leverage ratio was 1.79 to 1.00, and the Company's interest coverage ratio was 8.69 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2024.

- changed (2024-11-05):
[0001437749-24-033337:note_history:21]
As of  September 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.
  (was, 2024-08-06, similarity 0.9609):
[0001437749-24-024883:note_history:21]
As of  June 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

- removed (2024-11-05):
[0001437749-24-024883:note_history:22]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 735,938 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (10,735 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 87,041 |  |  |  | 71,308 |  |
| Other |  |  | 2,880 |  |  |  | 9,512 |  |
| Total |  |  | 1,495,124 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 44,889 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 5,539 |  |  |  | 3,785 |  |
| Total |  | $ | 1,444,696 |  |  | $ | 1,447,553 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:23]
Prior to the Tranche B Term Loan Facility extension discussed in Note 16, "Subsequent Events", as of  June 30, 2024, the Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  June 30, 2024, are as follows:

- removed (2024-11-05):
[0001437749-24-024883:note_history:24]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 23,438 |  |  | $ | - |  |  | $ | - |  |  | $ | 23,438 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 735,938 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,415,938 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:25]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility is now repayable in quarterly installments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity

- removed (2024-11-05):
[0001437749-24-024883:note_history:26]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments and as of  June 30, 2024, the Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2024, was 7.18%.

- removed (2024-11-05):
[0001437749-24-024883:note_history:27]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2024, the Company’s net secured leverage ratio was 1.86 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- removed (2024-11-05):
[0001437749-24-024883:note_history:28]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") that resulted in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.

- removed (2024-11-05):
[0001437749-24-024883:note_history:29]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2024, the Company’s total leverage ratio was 1.95 to 1.00, and the Company's interest coverage ratio was 7.97 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2024.

- removed (2024-11-05):
[0001437749-24-024883:note_history:30]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-05):
[0001437749-24-033337:note_history:31]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan Facility |  | $ | 721,875 |  |  | $ | 745,313 |  |
| Tranche B Term Loan Facility |  |  | 500,000 |  |  |  | 530,000 |  |
| Original issue discount and capitalized debt fees |  |  | (8,853 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 90,622 |  |  |  | 71,308 |  |
| Other |  |  | 6,169 |  |  |  | 9,512 |  |
| Total |  |  | 1,459,813 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 53,193 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 45,983 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,360,637 |  |  | $ | 1,447,553 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:32]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 735,938 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (10,735 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 87,041 |  |  |  | 71,308 |  |
| Other |  |  | 2,880 |  |  |  | 9,512 |  |
| Total |  |  | 1,495,124 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 44,889 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 5,539 |  |  |  | 3,785 |  |
| Total |  | $ | 1,444,696 |  |  | $ | 1,447,553 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-05):
[0001437749-24-033337:note_history:33]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 9,375 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 11,875 |  |
| 2025 |  |  | 46,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 150,000 |  |  |  | 755,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 467,500 |  |  |  | - |  |  |  | 467,500 |  |
| Total |  | $ | 721,875 |  |  | $ | 500,000 |  |  | $ | 150,000 |  |  | $ | 1,371,875 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:34]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 23,438 |  |  | $ | - |  |  | $ | - |  |  | $ | 23,438 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 735,938 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,415,938 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-11-05):
[0001437749-24-033337:note_history:35]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

- added (2024-11-05):
[0001437749-24-033337:note_history:36]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

- added (2024-11-05):
[0001437749-24-033337:note_history:37]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |

- added (2024-11-05):
[0001437749-24-033337:note_history:38]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:39]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:40]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:41]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |

- removed (2024-11-05):
[0001437749-24-024883:note_history:42]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001437749-24-033337:note_history:43]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $19,881 and $19,173 on  September 30, 2024 and  December 31, 2023, respectively. During the nine months ended  September 30, 2024 the Company recognized revenue of $16,104 related to amounts included in the  December 31, 2023, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2024-08-06, similarity 0.6441):
[0001437749-24-024883:note_history:43]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $20,004 and $19,173 on  June 30, 2024, and  December 31, 2023, respectively. During the six months ended  June 30, 2024, the Company recognized revenue of $13,148 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-11-05):
[0001437749-24-033337:note_history:44]
On  October 1, 2024, the Company purchased legal entities that primarily owned manufacturing and office buildings in Casole d’Elsa, Italy as their main operation for approximately 35,000 Euro. Prior to the purchase, these buildings were leased to the Company. The lease was remeasured in the third quarter of 2024 to reflect the purchase price.

- removed (2024-11-05):
[0001437749-24-024883:note_history:45]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility now requires quarterly installment payments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity.

- removed (2024-11-05):
[0001437749-24-024883:note_history:46]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado.

- removed (2024-11-05):
[0001437749-24-024883:note_history:47]
On  August 5, 2024, the Company invested an incremental $35,000 in Wallbox N.V. to purchase an approximate additional 12% of its Class A common stock. Additionally, the Company maintains the rights to additional equity through warrants for an incremental approximate 5% ownership in Wallbox’s Class A common stock upon exercise at a fixed price with anti-dilution protections for a period of time.
