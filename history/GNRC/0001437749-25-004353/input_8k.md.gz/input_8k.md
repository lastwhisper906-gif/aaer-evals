# GNRC 8-K — 0001437749-25-003476 filed 2025-02-12

## item codes, every 8-K on or before 2025-02-19

- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2025-02-19

- none on or before 2025-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-003476:8k_2_02:1]
EX-99.1
2
ex_776960.htm
EXHIBIT 99.1

[0001437749-25-003476:8k_2_02:2]
ex_776960.htm

[0001437749-25-003476:8k_2_02:3]
Exhibit 99.1

[0001437749-25-003476:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2024 Results

[0001437749-25-003476:8k_2_02:5]
Strong execution drives record fourth quarter net sales, significant margin expansion, and all-time record free cash flow generation; 2025 outlook anticipates continued net sales growth

[0001437749-25-003476:8k_2_02:6]
WAUKESHA, WISCONSIN (February 12, 2025) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2024 and initiated its outlook for the full-year 2025.

[0001437749-25-003476:8k_2_02:7]
Fourth Quarter 2024 Highlights

[0001437749-25-003476:8k_2_02:8]
| ● | Net sales increased 16% to $1.23 billion during the fourth quarter of 2024 as compared to $1.06 billion in the prior-year fourth quarter. The net effect of acquisitions and foreign currency had a slight favorable impact during the quarter. |

[0001437749-25-003476:8k_2_02:9]
|  | - | Residential product sales increased 28% to $743 million as compared to $580 million last year. |

[0001437749-25-003476:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales were approximately flat as compared to the prior year at $363 million. |

[0001437749-25-003476:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter was $117 million, or $2.15 per share, as compared to $97 million, or $1.57 per share, for the same period of 2023. |

[0001437749-25-003476:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was a fourth quarter record $168 million, or $2.80 per share, as compared to $126 million, or $2.07 per share, in the fourth quarter of 2023. |

[0001437749-25-003476:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was a fourth quarter record $265 million, or 21.5% of net sales, as compared to $213 million, or 20.0% of net sales, in the prior year. |

[0001437749-25-003476:8k_2_02:14]
| ● | Cash flow from operations was an all-time record $339 million as compared to $317 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was an all-time record $286 million as compared to $266 million in the fourth quarter of 2023. |

[0001437749-25-003476:8k_2_02:15]
Full-Year 2024 Highlights

[0001437749-25-003476:8k_2_02:16]
| ● | Net sales increased 7% to $4.30 billion during 2024 as compared to $4.02 billion in 2023. Core sales, which excludes both the impact of acquisitions and foreign currency, increased approximately 6%. |

[0001437749-25-003476:8k_2_02:17]
|  | - | Residential product sales increased 18% to $2.43 billion as compared to $2.06 billion last year. |

[0001437749-25-003476:8k_2_02:18]
|  | - | C&I product sales decreased 7% to $1.39 billion as compared to $1.49 billion in the prior year. |

[0001437749-25-003476:8k_2_02:19]
| ● | Net income attributable to the Company during 2024 was $316 million, or $5.39 per share, as compared to $215 million, or $3.27 per share for 2023. |

[0001437749-25-003476:8k_2_02:20]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $438 million, or $7.27 per share, as compared to $335 million, or $5.40 per share, in 2023. |

[0001437749-25-003476:8k_2_02:21]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, for 2024 was $789 million, or 18.4% of net sales, as compared to $638 million, or 15.9% of net sales, in the prior year. |

[0001437749-25-003476:8k_2_02:22]
| ● | Cash flow from operations was a record $741 million as compared to $522 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was a record $605 million as compared to $396 million for 2023. |

[0001437749-25-003476:8k_2_02:23]
| ● | The Company repurchased approximately 1.05 million shares of its common stock during 2024 for $153 million. There is approximately $347 million remaining under the current repurchase program as of December 31, 2024. In addition, the Company repaid approximately $278 million of debt on a net basis during the year. |

[0001437749-25-003476:8k_2_02:24]
| ● | The Company is initiating its full-year 2025 net sales growth guidance to be approximately 3 to 7% as compared to the prior year, which includes a slight unfavorable impact from the net effect of foreign currency and completed acquisitions. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 18.0 to 19.0%. |

[0001437749-25-003476:8k_2_02:25]
“Our fourth quarter results highlight our ability to rapidly increase production and execute on the strong demand for home standby and portable generators resulting from elevated outage activity in the second half of the year,” said Aaron Jagdfeld, President and Chief Executive Officer. “The mega-trends that support our long-term expectations were on full display in 2024 as power quality continued to deteriorate and power prices continued to increase. Power outage hours in the U.S. during the year were the highest since we began tracking the measure in 2010, while power demand expectations accelerated and efforts to decarbonize the power grid with intermittent generation sources continued. We believe the strategic investments we have made position Generac for sustained success as we provide innovative energy resiliency and efficiency solutions for homes, businesses, and critical infrastructure.”

[0001437749-25-003476:8k_2_02:26]
Additional Fourth Quarter 2024 Consolidated Highlights

[0001437749-25-003476:8k_2_02:27]
Gross profit margin was 40.6% as compared to 36.5% in the prior-year fourth quarter. The increase in gross margin was primarily driven by favorable sales mix and lower input costs.

[0001437749-25-003476:8k_2_02:28]
Operating expenses increased $65.6 million, or 27.6%, as compared to the fourth quarter of 2023. The increase in operating expenses was primarily driven by increased employee costs to support future growth across the business, additional marketing spend to drive incremental awareness for our products, and increased incentive compensation and variable expenses given higher shipment volumes and profitability.

[0001437749-25-003476:8k_2_02:29]
Provision for income taxes for the current year quarter was $27.3 million, or an effective tax rate of 18.9%, as compared to $30.0 million, or a 23.7% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by the positive impact from earnings mix with higher earnings in lower tax jurisdictions, as well as certain unfavorable discrete tax items in the prior year that did not repeat.

[0001437749-25-003476:8k_2_02:30]
Cash flow from operations was very strong at $339.5 million during the fourth quarter, as compared to $316.9 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $286.1 million as compared to $266.4 million in the fourth quarter of 2023. This significant free cash flow generation was primarily driven by record fourth quarter operating earnings as well as a meaningful reduction in working capital during the quarter.

[0001437749-25-003476:8k_2_02:31]
Fourth Quarter Business Segment Results

[0001437749-25-003476:8k_2_02:32]
Domestic Segment

[0001437749-25-003476:8k_2_02:33]
Domestic segment total sales (including inter-segment sales) increased 20% to $1.07 billion as compared to $891.0 million in the prior year, including approximately 1% sales growth contribution from acquisitions. The strong increase in core domestic sales was driven primarily by significant growth in shipments of home standby and portable generators as we executed on the demand resulting from the elevated power outage activity in the second half of the year. In addition, higher shipments of residential energy storage systems and ecobee products also contributed to the domestic sales increase.

[0001437749-25-003476:8k_2_02:34]
Adjusted EBITDA for the segment was an all-time record $242.8 million, or 22.7% of domestic segment total sales, as compared to $192.2 million in the prior year, or 21.6% of total sales. This margin improvement was primarily driven by favorable sales mix and lower input costs, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-25-003476:8k_2_02:35]
International Segment

[0001437749-25-003476:8k_2_02:36]
International segment total sales (including inter-segment sales) decreased 1% to $187.5 million as compared to $190.1 million in the prior year quarter, including an approximate 2% unfavorable impact from foreign currency. Core total sales growth for the segment was primarily driven by strength in Latin America, mostly offset by softness in certain European markets.

[0001437749-25-003476:8k_2_02:37]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $22.5 million, or 12.0% of international segment total sales, as compared to $20.4 million, or 10.7% of total sales, in the prior year. This margin improvement was primarily driven by favorable sales mix and lower input costs.

[0001437749-25-003476:8k_2_02:38]
2025 Outlook

[0001437749-25-003476:8k_2_02:39]
The Company is initiating guidance for full-year 2025 that anticipates continued net sales growth as compared to the prior year. This is expected to be driven primarily by residential product sales growth in the mid-to-high single digit range, primarily led by shipments of home standby generators and residential energy technology solutions. C&I product sales are expected to be approximately flat as compared to the prior year. As a result of these factors, full-year net sales are expected to increase between 3 to 7% as compared to the prior year, which includes a slight unfavorable impact from the net effect of foreign currency and completed acquisitions.

[0001437749-25-003476:8k_2_02:40]
Additionally, the Company expects net income margin, before deducting for non-controlling interests, to be approximately 8.0 to 9.0% for the full-year 2025. The corresponding adjusted EBITDA margin is expected to be approximately 18.0 to 19.0%.

[0001437749-25-003476:8k_2_02:41]
The Company expects to generate strong levels of operating and free cash flow for the full year, with free cash flow conversion from adjusted net income between 80 to 90%.

[0001437749-25-003476:8k_2_02:42]
Conference Call and Webcast

[0001437749-25-003476:8k_2_02:43]
Generac management will hold a conference call at 10:00 a.m. EST on Wednesday, February 12, 2025 to discuss fourth quarter and full-year 2024 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/axz3e8r5.

[0001437749-25-003476:8k_2_02:44]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-25-003476:8k_2_02:45]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-25-003476:8k_2_02:46]
About Generac

[0001437749-25-003476:8k_2_02:47]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-003476:8k_2_02:48]
Forward-looking Information

[0001437749-25-003476:8k_2_02:49]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-25-003476:8k_2_02:50]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-25-003476:8k_2_02:51]
| ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
| ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
| ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
| ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
| ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
| ● | changes in U.S. trade policy, including the imposition of new or increased tariffs; |
| ● | our ability to consummate our share repurchase programs; |
| ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
| ● | scrutiny regarding our sustainability practices; |
| ● | our ability to develop and enhance products and gain customer acceptance for our products; |
| ● | frequency and duration of power outages impacting demand for our products; |
| ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
| ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
| ● | our ability to remain competitive; |
| ● | our dependence on our dealer and distribution network; |
| ● | market reaction to changes in selling prices or mix of products; |
| ● | loss of our key management and employees; |
| ● | disruptions from labor disputes or organized labor activities; |
| ● | our ability to attract and retain employees; |
| ● | disruptions in our manufacturing operations; |
| ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
| ● | risks related to sourcing components in foreign countries; |
| ● | compliance with environmental, health and safety laws and regulations; |
| ● | government regulation of our products; |
| ● | failures or security breaches of our networks, information technology systems, or connected products; |
| ● | our ability to make payments on our indebtedness; |
| ● | terms of our credit facilities that may restrict our operations; |
| ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
| ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
| ● | volatility of our stock price; and |
| ● | potential tax liabilities. |

[0001437749-25-003476:8k_2_02:52]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-25-003476:8k_2_02:53]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-25-003476:8k_2_02:54]
Non-GAAP Financial Metrics

[0001437749-25-003476:8k_2_02:55]
Core Sales

[0001437749-25-003476:8k_2_02:56]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-25-003476:8k_2_02:57]
Adjusted EBITDA

[0001437749-25-003476:8k_2_02:58]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-25-003476:8k_2_02:59]
Adjusted Net Income

[0001437749-25-003476:8k_2_02:60]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-25-003476:8k_2_02:61]
Free Cash Flow

[0001437749-25-003476:8k_2_02:62]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-25-003476:8k_2_02:63]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-25-003476:8k_2_02:64]
SOURCE: Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:65]
CONTACT:

[0001437749-25-003476:8k_2_02:66]
Kris Rosemann

[0001437749-25-003476:8k_2_02:67]
Director – Corporate Development & Investor Relations

[0001437749-25-003476:8k_2_02:68]
(262) 506-6064

[0001437749-25-003476:8k_2_02:69]
InvestorRelations@generac.com

[0001437749-25-003476:8k_2_02:70]
Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:71]
Condensed Consolidated Balance Sheets

[0001437749-25-003476:8k_2_02:72]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-003476:8k_2_02:73]
(Unaudited)

[0001437749-25-003476:8k_2_02:74]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 281,277 |  |  | $ | 200,994 |  |
| Accounts receivable, less allowance for credit losses of $35,465 and $33,925 as of December 31, 2024 and December 31, 2023, respectively |  |  | 612,107 |  |  |  | 537,316 |  |
| Inventories |  |  | 1,031,647 |  |  |  | 1,167,484 |  |
| Prepaid expenses and other current assets |  |  | 107,139 |  |  |  | 91,898 |  |
| Total current assets |  |  | 2,032,170 |  |  |  | 1,997,692 |  |
| Property and equipment, net |  |  | 690,023 |  |  |  | 598,577 |  |
| Customer lists, net |  |  | 152,737 |  |  |  | 184,513 |  |
| Patents and technology, net |  |  | 379,095 |  |  |  | 417,441 |  |
| Other intangible assets, net |  |  | 20,026 |  |  |  | 27,127 |  |
| Tradenames, net |  |  | 206,664 |  |  |  | 216,995 |  |
| Goodwill |  |  | 1,436,261 |  |  |  | 1,432,384 |  |
| Deferred income taxes |  |  | 24,132 |  |  |  | 15,532 |  |
| Operating lease and other assets |  |  | 168,223 |  |  |  | 203,051 |  |
| Total assets |  | $ | 5,109,331 |  |  | $ | 5,093,312 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 55,848 |  |  | $ | 81,769 |  |
| Accounts payable |  |  | 458,693 |  |  |  | 340,719 |  |
| Accrued wages and employee benefits |  |  | 81,485 |  |  |  | 54,970 |  |
| Accrued product warranty |  |  | 56,127 |  |  |  | 65,298 |  |
| Other accrued liabilities |  |  | 313,401 |  |  |  | 292,120 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 67,598 |  |  |  | 45,895 |  |
| Total current liabilities |  |  | 1,033,152 |  |  |  | 880,771 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,210,776 |  |  |  | 1,447,553 |  |
| Deferred income taxes |  |  | 33,185 |  |  |  | 90,012 |  |
| Deferred revenue |  |  | 193,260 |  |  |  | 167,008 |  |
| Operating lease and other long-term liabilities |  |  | 141,515 |  |  |  | 158,349 |  |
| Total liabilities |  |  | 2,611,888 |  |  |  | 2,743,693 |  |
| Redeemable noncontrolling interest |  |  | - |  |  |  | 6,549 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,785,631 and 73,195,055 shares issued as of December 31, 2024 and December 31, 2023, respectively |  |  | 738 |  |  |  | 733 |  |
| Additional paid-in capital |  |  | 1,133,756 |  |  |  | 1,070,386 |  |
| Treasury stock, at cost, 14,173,697 and 13,057,298 shares at December 31, 2024 and December 31, 2023, respectively |  |  | (1,196,997 | ) |  |  | (1,032,921 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,844,296 |  |  |  | 2,519,313 |  |
| Accumulated other comprehensive loss |  |  | (85,399 | ) |  |  | (15,143 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,494,278 |  |  |  | 2,340,252 |  |
| Noncontrolling interests |  |  | 3,165 |  |  |  | 2,818 |  |
| Total stockholders’ equity |  |  | 2,497,443 |  |  |  | 2,343,070 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,109,331 |  |  | $ | 5,093,312 |  |

[0001437749-25-003476:8k_2_02:75]
5

[0001437749-25-003476:8k_2_02:76]
Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:77]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-25-003476:8k_2_02:78]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-003476:8k_2_02:79]
(Unaudited)

[0001437749-25-003476:8k_2_02:80]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 1,234,801 |  |  | $ | 1,063,670 |  |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |
| Costs of goods sold |  |  | 733,384 |  |  |  | 674,946 |  |  |  | 2,630,208 |  |  |  | 2,657,236 |  |
| Gross profit |  |  | 501,417 |  |  |  | 388,724 |  |  |  | 1,665,626 |  |  |  | 1,365,431 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 144,397 |  |  |  | 113,839 |  |  |  | 526,446 |  |  |  | 448,199 |  |
| Research and development |  |  | 59,258 |  |  |  | 44,369 |  |  |  | 219,600 |  |  |  | 173,443 |  |
| General and administrative |  |  | 75,703 |  |  |  | 54,288 |  |  |  | 285,095 |  |  |  | 253,396 |  |
| Amortization of intangibles |  |  | 24,045 |  |  |  | 25,260 |  |  |  | 97,743 |  |  |  | 104,194 |  |
| Total operating expenses |  |  | 303,403 |  |  |  | 237,756 |  |  |  | 1,128,884 |  |  |  | 979,232 |  |
| Income from operations |  |  | 198,014 |  |  |  | 150,968 |  |  |  | 536,742 |  |  |  | 386,199 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (19,880 | ) |  |  | (24,765 | ) |  |  | (89,713 | ) |  |  | (97,627 | ) |
| Investment income |  |  | 2,319 |  |  |  | 1,483 |  |  |  | 7,605 |  |  |  | 4,272 |  |
| Change in fair value of investment |  |  | (35,068 | ) |  |  | - |  |  |  | (38,006 | ) |  |  | - |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | (4,861 | ) |  |  | - |  |
| Other, net |  |  | (380 | ) |  |  | (880 | ) |  |  | (2,329 | ) |  |  | (2,544 | ) |
| Total other expense, net |  |  | (53,009 | ) |  |  | (24,162 | ) |  |  | (127,304 | ) |  |  | (95,899 | ) |
| Income before provision for income taxes |  |  | 145,005 |  |  |  | 126,806 |  |  |  | 409,438 |  |  |  | 290,300 |  |
| Provision for income taxes |  |  | 27,336 |  |  |  | 29,996 |  |  |  | 92,460 |  |  |  | 73,180 |  |
| Net income |  |  | 117,669 |  |  |  | 96,810 |  |  |  | 316,978 |  |  |  | 217,120 |  |
| Net income attributable to noncontrolling interests |  |  | 443 |  |  |  | 209 |  |  |  | 663 |  |  |  | 2,514 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 117,226 |  |  |  | 96,601 |  |  |  | 316,315 |  |  |  | 214,606 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  |  | (59,923 | ) |  |  | 36,784 |  |  |  | (62,842 | ) |  |  | 57,963 |  |
| Net unrealized (loss) gain on derivatives |  |  | 2,253 |  |  |  | (10,313 | ) |  |  | (7,672 | ) |  |  | (8,004 | ) |
| Other comprehensive income (loss) |  |  | (57,670 | ) |  |  | 26,471 |  |  |  | (70,514 | ) |  |  | 49,959 |  |
| Total comprehensive income: |  |  | 59,999 |  |  |  | 123,281 |  |  |  | 246,464 |  |  |  | 267,079 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 200 |  |  |  | 246 |  |  |  | 405 |  |  |  | 2,581 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 59,799 |  |  | $ | 123,035 |  |  | $ | 246,059 |  |  | $ | 264,498 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.18 |  |  | $ | 1.59 |  |  | $ | 5.46 |  |  | $ | 3.31 |  |
| Weighted average common shares outstanding - basic: |  |  | 59,122,093 |  |  |  | 60,391,678 |  |  |  | 59,559,797 |  |  |  | 61,265,060 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.15 |  |  | $ | 1.57 |  |  | $ | 5.39 |  |  | $ | 3.27 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,012,948 |  |  |  | 61,038,694 |  |  |  | 60,350,412 |  |  |  | 62,058,387 |  |

[0001437749-25-003476:8k_2_02:81]
Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:82]
Condensed Consolidated Statements of Cash Flows

[0001437749-25-003476:8k_2_02:83]
(U.S. Dollars in Thousands)

[0001437749-25-003476:8k_2_02:84]
(Unaudited)

[0001437749-25-003476:8k_2_02:85]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 316,978 |  |  | $ | 217,120 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 74,025 |  |  |  | 62,408 |  |
| Amortization of intangible assets |  |  | 97,743 |  |  |  | 104,194 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 3,242 |  |  |  | 3,885 |  |
| Change in fair value of investment |  |  | 38,006 |  |  |  | - |  |
| Loss on extinguishment of debt |  |  | 4,861 |  |  |  | - |  |
| Deferred income taxes |  |  | (60,615 | ) |  |  | (34,478 | ) |
| Share-based compensation expense |  |  | 49,248 |  |  |  | 35,492 |  |
| Loss (gain) on disposal of assets |  |  | 138 |  |  |  | (285 | ) |
| Other noncash charges |  |  | 5,780 |  |  |  | 5,922 |  |
| Excess tax benefits from equity awards |  |  | (5,069 | ) |  |  | (977 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (82,816 | ) |  |  | (18,272 | ) |
| Inventories |  |  | 122,952 |  |  |  | 262,670 |  |
| Other assets |  |  | 546 |  |  |  | 24,266 |  |
| Accounts payable |  |  | 123,571 |  |  |  | (120,900 | ) |
| Accrued wages and employee benefits |  |  | 26,870 |  |  |  | 7,962 |  |
| Other accrued liabilities |  |  | 25,841 |  |  |  | (27,337 | ) |
| Net cash provided by operating activities |  |  | 741,301 |  |  |  | 521,670 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 211 |  |  |  | 2,896 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 3,294 |  |
| Contribution to tax equity investment |  |  | (1,629 | ) |  |  | (6,627 | ) |
| Purchase of long-term investments |  |  | (37,821 | ) |  |  | (32,592 | ) |
| Proceeds from sale of long-term investments |  |  | 2,000 |  |  |  | - |  |
| Expenditures for property and equipment |  |  | (136,733 | ) |  |  | (129,060 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (34,740 | ) |  |  | (15,974 | ) |
| Net cash used in investing activities |  |  | (208,712 | ) |  |  | (178,063 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 29,219 |  |  |  | 64,257 |  |
| Proceeds from long-term borrowings |  |  | 541,475 |  |  |  | 348,827 |  |
| Repayments of short-term borrowings |  |  | (54,548 | ) |  |  | (37,104 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (794,600 | ) |  |  | (288,699 | ) |
| Stock repurchases |  |  | (152,743 | ) |  |  | (251,513 | ) |
| Payment of debt issuance costs |  |  | (3,616 | ) |  |  | - |  |
| Payment of contingent acquisition consideration |  |  | - |  |  |  | (4,979 | ) |
| Payment of deferred acquisition consideration |  |  | (7,421 | ) |  |  | - |  |
| Purchase of additional ownership interest |  |  | (9,117 | ) |  |  | (104,844 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (273 | ) |  |  | - |  |
| Taxes paid related to equity awards |  |  | (24,769 | ) |  |  | (10,897 | ) |
| Proceeds from the exercise of stock options |  |  | 27,558 |  |  |  | 7,815 |  |
| Net cash used in financing activities |  |  | (448,835 | ) |  |  | (277,137 | ) |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | (3,471 | ) |  |  | 1,801 |  |
| Net increase in cash and cash equivalents |  |  | 80,283 |  |  |  | 68,271 |  |
| Cash and cash equivalents at beginning of period |  |  | 200,994 |  |  |  | 132,723 |  |
| Cash and cash equivalents at end of period |  | $ | 281,277 |  |  | $ | 200,994 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 89,420 |  |  | $ | 84,027 |  |
| Income taxes |  |  | 148,828 |  |  |  | 100,082 |  |

[0001437749-25-003476:8k_2_02:86]
7

[0001437749-25-003476:8k_2_02:87]
Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:88]
Segment Reporting and Product Class Information

[0001437749-25-003476:8k_2_02:89]
(U.S. Dollars in Thousands)

[0001437749-25-003476:8k_2_02:90]
(Unaudited)

[0001437749-25-003476:8k_2_02:91]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended December 31, 2024 |  |  | Three Months Ended December 31, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,057,907 |  |  | $ | 9,361 |  |  | $ | 1,067,268 |  |  | $ | 881,033 |  |  | $ | 9,977 |  |  | $ | 891,010 |  |
| International |  |  | 176,894 |  |  |  | 10,572 |  |  |  | 187,466 |  |  |  | 182,637 |  |  |  | 7,474 |  |  |  | 190,111 |  |
| Intercompany elimination |  |  | - |  |  |  | (19,933 | ) |  |  | (19,933 | ) |  |  | - |  |  |  | (17,451 | ) |  |  | (17,451 | ) |
| Total net sales |  | $ | 1,234,801 |  |  | $ | - |  |  | $ | 1,234,801 |  |  | $ | 1,063,670 |  |  | $ | - |  |  | $ | 1,063,670 |  |

[0001437749-25-003476:8k_2_02:92]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2024 |  |  | Year Ended December 31, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,599,149 |  |  | $ | 35,932 |  |  | $ | 3,635,081 |  |  | $ | 3,276,324 |  |  | $ | 43,937 |  |  | $ | 3,320,261 |  |
| International |  |  | 696,685 |  |  |  | 28,700 |  |  |  | 725,385 |  |  |  | 746,343 |  |  |  | 91,552 |  |  |  | 837,895 |  |
| Intercompany elimination |  |  | - |  |  |  | (64,632 | ) |  |  | (64,632 | ) |  |  | - |  |  |  | (135,489 | ) |  |  | (135,489 | ) |
| Total net sales |  | $ | 4,295,834 |  |  | $ | - |  |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |  | $ | - |  |  | $ | 4,022,667 |  |

[0001437749-25-003476:8k_2_02:93]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Residential products |  | $ | 743,336 |  |  | $ | 580,391 |  |  | $ | 2,433,474 |  |  | $ | 2,062,929 |  |
| Commercial & industrial products |  |  | 363,376 |  |  |  | 362,923 |  |  |  | 1,389,469 |  |  |  | 1,494,799 |  |
| Other |  |  | 128,089 |  |  |  | 120,356 |  |  |  | 472,891 |  |  |  | 464,939 |  |
| Total net sales |  | $ | 1,234,801 |  |  | $ | 1,063,670 |  |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |

[0001437749-25-003476:8k_2_02:94]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 242,787 |  |  | $ | 192,203 |  |  | $ | 693,203 |  |  | $ | 523,337 |  |
| International |  |  | 22,527 |  |  |  | 20,434 |  |  |  | 95,898 |  |  |  | 114,522 |  |
| Total adjusted EBITDA (1) |  | $ | 265,314 |  |  | $ | 212,637 |  |  | $ | 789,101 |  |  | $ | 637,859 |  |

[0001437749-25-003476:8k_2_02:95]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-25-003476:8k_2_02:96]
Generac Holdings Inc.

[0001437749-25-003476:8k_2_02:97]
Reconciliation Schedules

[0001437749-25-003476:8k_2_02:98]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-25-003476:8k_2_02:99]
(Unaudited)

[0001437749-25-003476:8k_2_02:100]
Net income to Adjusted EBITDA reconciliation

[0001437749-25-003476:8k_2_02:101]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 117,226 |  |  | $ | 96,601 |  |  | $ | 316,315 |  |  | $ | 214,606 |  |
| Net income attributable to noncontrolling interests |  |  | 443 |  |  |  | 209 |  |  |  | 663 |  |  |  | 2,514 |  |
| Net income |  |  | 117,669 |  |  |  | 96,810 |  |  |  | 316,978 |  |  |  | 217,120 |  |
| Interest expense |  |  | 19,880 |  |  |  | 24,765 |  |  |  | 89,713 |  |  |  | 97,627 |  |
| Depreciation and amortization |  |  | 43,834 |  |  |  | 42,453 |  |  |  | 171,768 |  |  |  | 166,602 |  |
| Provision for income taxes |  |  | 27,336 |  |  |  | 29,996 |  |  |  | 92,460 |  |  |  | 73,180 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,894 |  |  |  | (696 | ) |  |  | 4,757 |  |  |  | (5,953 | ) |
| Non-cash share-based compensation expense (2) |  |  | 10,978 |  |  |  | 5,186 |  |  |  | 49,248 |  |  |  | 35,492 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,068 |  |  |  | 893 |  |  |  | 5,097 |  |  |  | 4,054 |  |
| Business optimization and other charges (4) |  |  | 1,562 |  |  |  | 2,400 |  |  |  | 4,752 |  |  |  | 10,551 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 5,651 |  |  |  | 10,577 |  |  |  | 10,931 |  |  |  | 38,490 |  |
| Change in fair value of investment (6) |  |  | 35,068 |  |  |  | - |  |  |  | 38,006 |  |  |  | - |  |
| Loss on extinguishment of debt (7) |  |  | - |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Other |  |  | 374 |  |  |  | 253 |  |  |  | 530 |  |  |  | 696 |  |
| Adjusted EBITDA |  |  | 265,314 |  |  |  | 212,637 |  |  |  | 789,101 |  |  |  | 637,859 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 654 |  |  |  | 541 |  |  |  | 1,175 |  |  |  | 4,687 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 264,660 |  |  | $ | 212,096 |  |  | $ | 787,926 |  |  | $ | 633,172 |  |

[0001437749-25-003476:8k_2_02:102]
Net income to Adjusted net income reconciliation

[0001437749-25-003476:8k_2_02:103]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 117,226 |  |  | $ | 96,601 |  |  | $ | 316,315 |  |  | $ | 214,606 |  |
| Net income attributable to noncontrolling interests |  |  | 443 |  |  |  | 209 |  |  |  | 663 |  |  |  | 2,514 |  |
| Net income |  |  | 117,669 |  |  |  | 96,810 |  |  |  | 316,978 |  |  |  | 217,120 |  |
| Amortization of intangible assets |  |  | 24,045 |  |  |  | 25,260 |  |  |  | 97,743 |  |  |  | 104,194 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 650 |  |  |  | 983 |  |  |  | 3,242 |  |  |  | 3,885 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 445 |  |  |  | 346 |  |  |  | 2,717 |  |  |  | 2,089 |  |
| Loss/(gain) attributable to business or asset dispositions (9) |  |  | - |  |  |  | - |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (4) |  |  | 1,562 |  |  |  | 2,400 |  |  |  | 4,752 |  |  |  | 10,551 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 5,651 |  |  |  | 10,577 |  |  |  | 10,931 |  |  |  | 38,490 |  |
| Change in fair value of investment (6) |  |  | 35,068 |  |  |  | - |  |  |  | 38,006 |  |  |  | - |  |
| Loss on extinguishment of debt (7) |  |  | - |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Tax effect of add backs |  |  | (16,411 | ) |  |  | (9,908 | ) |  |  | (40,173 | ) |  |  | (38,384 | ) |
| Adjusted net income |  |  | 168,679 |  |  |  | 126,468 |  |  |  | 439,122 |  |  |  | 337,826 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 443 |  |  |  | 209 |  |  |  | 663 |  |  |  | 2,514 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 168,236 |  |  | $ | 126,259 |  |  | $ | 438,459 |  |  | $ | 335,312 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.80 |  |  | $ | 2.07 |  |  | $ | 7.27 |  |  | $ | 5.40 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,012,948 |  |  |  | 61,038,694 |  |  |  | 60,350,412 |  |  |  | 62,058,387 |  |

[0001437749-25-003476:8k_2_02:104]
(1) Includes (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-25-003476:8k_2_02:105]
(2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods.

[0001437749-25-003476:8k_2_02:106]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-25-003476:8k_2_02:107]
(4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-25-003476:8k_2_02:108]
(5) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-003476:8k_2_02:109]
|  | • | A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $5.4 million in the fourth quarter of 2024; $9.2 million for the full year 2024; $5.2 million in the fourth quarter of 2023; and $27.3 million for the full year 2023. |

[0001437749-25-003476:8k_2_02:110]
|  | • | Legal expenses related to certain class action lawsuits - $0.3 million in the fourth quarter of 2024; $1.3 million for the full year 2024; $1.0 million in the fourth quarter of 2023 and for the full year 2023; |

[0001437749-25-003476:8k_2_02:111]
|  | • | Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million for the full year 2024; and $4.4 million in the fourth quarter and for the full year 2023. |

[0001437749-25-003476:8k_2_02:112]
|  | • | A provision for a matter with the Consumer Product Safety Commission (CPSC) concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million for the full year 2023. |

[0001437749-25-003476:8k_2_02:113]
(6) Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-003476:8k_2_02:114]
(7) Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of the Company's Tranche B Term Loan Facility.

[0001437749-25-003476:8k_2_02:115]
(8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-25-003476:8k_2_02:116]
(9) Represents losses/(gains) attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-25-003476:8k_2_02:117]
Free Cash Flow Reconciliation

[0001437749-25-003476:8k_2_02:118]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net cash provided by operating activities |  | $ | 339,454 |  |  | $ | 316,946 |  |  | $ | 741,301 |  |  | $ | 521,670 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 761 |  |  |  | - |  |  |  | 3,294 |  |
| Expenditures for property and equipment |  |  | (53,334 | ) |  |  | (51,342 | ) |  |  | (136,733 | ) |  |  | (129,060 | ) |
| Free cash flow |  | $ | 286,120 |  |  | $ | 266,365 |  |  | $ | 604,568 |  |  | $ | 395,904 |  |

[0001437749-25-003476:8k_2_02:119]
10
