# GNRC MD&A — 0001437749-25-004353


## mdna

[0001437749-25-004353:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-25-004353:mdna:2]
Overview

[0001437749-25-004353:mdna:3]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-004353:mdna:4]
Further information regarding our business is provided in “Part I, Item 1. Business” of this Annual Report on Form 10-K.

[0001437749-25-004353:mdna:5]
Business Drivers and Operational Factors

[0001437749-25-004353:mdna:6]
“Part I, Item 1. Business” of this Annual Report on Form 10-K contains information regarding business drivers, including key mega-trends and strategic growth themes under the subheading “Mega-Trends, Strategic Growth Themes, and Additional Business Drivers.”

[0001437749-25-004353:mdna:7]
Factors Affecting Results of Operations

[0001437749-25-004353:mdna:8]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control, and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-25-004353:mdna:9]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-25-004353:mdna:10]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-25-004353:mdna:11]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-25-004353:mdna:12]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business" to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K.

[0001437749-25-004353:mdna:13]
Factors Influencing Interest Expense

[0001437749-25-004353:mdna:14]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for further information. The decrease in interest expense in the current year was primarily driven by lower borrowings and lower SOFR interest rates during the year.

[0001437749-25-004353:mdna:15]
Factors Influencing Provision for Income Taxes and Cash Income Taxes Paid

[0001437749-25-004353:mdna:16]
The effective income tax rates for the years ended December 31, 2024 and 2023 were 22.6% and 25.2%, respectively. The decrease in our 2024 effective tax rate was primarily due to unfavorable discrete tax items in the prior year that did not repeat in the current year, as well as favorable earnings mix with higher earnings in lower tax jurisdictions in the current year.

[0001437749-25-004353:mdna:17]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not have a material impact on the financial results of the current period, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will also monitor any changes to the Act under the new policy environment.

[0001437749-25-004353:mdna:18]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to evaluate the Pillar Two rules and their potential impact on future periods. There was no impact to the financial results of the year ended December 31, 2024, and we do not expect the rules to have a material impact on our effective tax rate for the following year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-25-004353:mdna:19]
Components of Net Sales and Expenses

[0001437749-25-004353:mdna:20]
Net Sales

[0001437749-25-004353:mdna:21]
Our net sales primarily consist of the sale of products to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, installation, maintenance, data center and telecom facility design and build, remote monitoring, and grid services to utilities in certain circumstances. These services accounted for less than 4% of our net sales for the year ended December 31, 2024. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-25-004353:mdna:22]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 5% of our net sales, and our top ten customers representing less than 16% of our net sales in aggregate for the year ended December 31, 2024.

[0001437749-25-004353:mdna:23]
Costs of Goods Sold

[0001437749-25-004353:mdna:24]
The principal elements of costs of goods sold are component parts, raw materials, inbound and outbound freight, factory overhead and labor. The principal component parts are engines, alternators, batteries, electronic controls, and steel enclosures. We design and manufacture air-cooled engines for certain of our generators up to 26kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our generators. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high-quality suppliers. In some cases, these relationships are proprietary. For certain energy technology products, we source these products complete from certain contract manufacturers using our designs.

[0001437749-25-004353:mdna:25]
The principal sourced raw materials used in the manufacturing process are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity price changes on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-25-004353:mdna:26]
Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-25-004353:mdna:27]
The balance of cost of goods sold include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted if we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-25-004353:mdna:28]
Operating Expenses

[0001437749-25-004353:mdna:29]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, warranty, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include, among others, personnel costs such as salaries, bonuses, employee benefit costs, payroll taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-25-004353:mdna:30]
Selling and service.    Our selling and service expenses consist primarily of personnel costs, marketing expense, standard assurance warranty expense, bad debt provisions, and other sales expenses. Our personnel costs recorded in selling and services expenses include the expense of our sales force, customer support teams, outbound shipping and distribution functions, and other personnel involved in the marketing, sales and service of our products. Standard warranty expense is estimated based on historical trends or based on specific warranty matters as they become known and reasonably estimable. Our marketing expenses include media advertising, promotional expenses, co-op advertising costs, direct mail costs, printed material costs, product display costs, market research expenses, and trade show expenses. Marketing expenses are generally related to the launch of new product offerings, opportunities to create market awareness for our products, and general brand awareness marketing efforts. Our marketing campaigns are an important source for lead generation.

[0001437749-25-004353:mdna:31]
Research and development.    Our research and development expenses include mechanical engineering, electronics engineering, and software development costs and support numerous projects covering all of our product lines. They also support our connectivity, grid services, remote monitoring, and energy management initiatives. We operate engineering facilities with extensive capabilities at many locations around the world with a focus on new product development, existing product improvement and cost containment. We are committed to innovation, research and development and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-25-004353:mdna:32]
General and administrative.    Our general and administrative expenses include personnel costs for accounting, information technology, human resources, legal, general and administrative employees; legal and professional services fees; information technology costs; insurance; travel and entertainment expense; adjustments to contingent acquisition consideration; share-based compensation costs; and other corporate expenses.

[0001437749-25-004353:mdna:33]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-25-004353:mdna:34]
Other (Expense) Income

[0001437749-25-004353:mdna:35]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of deferred financing costs and original issue discount, credit facility commitment fees, and interest accretion on contingent acquisition consideration. Other (expense) income also includes other financial items such as losses on extinguishment of debt, investment income earned on our cash and cash equivalents, gains/losses on the sale of certain investments, and changes in the fair value of our investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-004353:mdna:36]
Results of Operations

[0001437749-25-004353:mdna:37]
A detailed discussion of the year-over-year changes from the Company's fiscal 2022 results of operations to fiscal 2023 results of operations can be found in the Management's Discussion and Analysis section of the Company's fiscal 2023 Annual Report on Form 10-K filed February 21, 2024.

[0001437749-25-004353:mdna:38]
Year ended December 31, 2024 compared to year ended December 31, 2023

[0001437749-25-004353:mdna:39]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-25-004353:mdna:40]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |  | $ | 273,167 |  |  |  | 6.8 | % |
| Cost of goods sold |  |  | 2,630,208 |  |  |  | 2,657,236 |  |  |  | (27,028 | ) |  |  | -1.0 | % |
| Gross profit |  |  | 1,665,626 |  |  |  | 1,365,431 |  |  |  | 300,195 |  |  |  | 22.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 526,446 |  |  |  | 448,199 |  |  |  | 78,247 |  |  |  | 17.5 | % |
| Research and development |  |  | 219,600 |  |  |  | 173,443 |  |  |  | 46,157 |  |  |  | 26.6 | % |
| General and administrative |  |  | 285,095 |  |  |  | 253,396 |  |  |  | 31,699 |  |  |  | 12.5 | % |
| Amortization of intangible assets |  |  | 97,743 |  |  |  | 104,194 |  |  |  | (6,451 | ) |  |  | -6.2 | % |
| Total operating expenses |  |  | 1,128,884 |  |  |  | 979,232 |  |  |  | 149,652 |  |  |  | 15.3 | % |
| Income from operations |  |  | 536,742 |  |  |  | 386,199 |  |  |  | 150,543 |  |  |  | 39.0 | % |
| Total other expense, net |  |  | (127,304 | ) |  |  | (95,899 | ) |  |  | (31,405 | ) |  |  | -32.7 | % |
| Income before provision for income taxes |  |  | 409,438 |  |  |  | 290,300 |  |  |  | 119,138 |  |  |  | 41.0 | % |
| Provision for income taxes |  |  | 92,460 |  |  |  | 73,180 |  |  |  | 19,280 |  |  |  | 26.3 | % |
| Net income |  |  | 316,978 |  |  |  | 217,120 |  |  |  | 99,858 |  |  |  | 46.0 | % |
| Net income attributable to noncontrolling interests |  |  | 663 |  |  |  | 2,514 |  |  |  | (1,851 | ) |  |  | -73.6 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 316,315 |  |  | $ | 214,606 |  |  | $ | 101,709 |  |  |  | 47.4 | % |

[0001437749-25-004353:mdna:41]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-25-004353:mdna:42]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,599,149 |  |  | $ | 3,276,324 |  |  | $ | 322,825 |  |  |  | 9.9 | % |
| International |  |  | 696,685 |  |  |  | 746,343 |  |  |  | (49,658 | ) |  |  | -6.7 | % |
| Total net sales |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |  | $ | 273,167 |  |  |  | 6.8 | % |

[0001437749-25-004353:mdna:43]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2024 |  |  | Year Ended December 31, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,599,149 |  |  | $ | 35,932 |  |  | $ | 3,635,081 |  |  | $ | 3,276,324 |  |  | $ | 43,937 |  |  | $ | 3,320,261 |  |
| International |  |  | 696,685 |  |  |  | 28,700 |  |  |  | 725,385 |  |  |  | 746,343 |  |  |  | 91,552 |  |  |  | 837,895 |  |
| Intercompany elimination |  |  | - |  |  |  | (64,632 | ) |  |  | (64,632 | ) |  |  | - |  |  |  | (135,489 | ) |  |  | (135,489 | ) |
| Total net sales |  | $ | 4,295,834 |  |  | $ | - |  |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |  | $ | - |  |  | $ | 4,022,667 |  |

[0001437749-25-004353:mdna:44]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 693,203 |  |  | $ | 523,337 |  |  | $ | 169,866 |  |  |  | 32.5 | % |
| International |  |  | 95,898 |  |  |  | 114,522 |  |  |  | (18,624 | ) |  |  | -16.3 | % |
| Total Adjusted EBITDA |  | $ | 789,101 |  |  | $ | 637,859 |  |  | $ | 151,242 |  |  |  | 23.7 | % |

[0001437749-25-004353:mdna:45]
The following table sets forth our net sales by product class for the periods indicated:

[0001437749-25-004353:mdna:46]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,433,474 |  |  | $ | 2,062,929 |  |  | $ | 370,545 |  |  |  | 18.0 | % |
| Commercial & Industrial products |  |  | 1,389,469 |  |  |  | 1,494,799 |  |  |  | (105,330 | ) |  |  | -7.0 | % |
| Other |  |  | 472,891 |  |  |  | 464,939 |  |  |  | 7,952 |  |  |  | 1.7 | % |
| Total net sales |  | $ | 4,295,834 |  |  | $ | 4,022,667 |  |  | $ | 273,167 |  |  |  | 6.8 | % |

[0001437749-25-004353:mdna:47]
Net sales.    The increase in domestic segment sales for the year ended December 31, 2024, was primarily driven by an increase in residential product sales, most notably in home standby and portable generators following the elevated power outage activity in the second half of the year. This was partially offset by a decline in C&I product sales for telecom, rental, and "beyond standby" applications.

[0001437749-25-004353:mdna:48]
The decrease in international segment sales for the year ended December 31, 2024, was primarily driven by lower intersegment sales related to softness in the telecom market and a decline in portable generator and C&I product sales in Europe, partially offset by growth in Latin America.

[0001437749-25-004353:mdna:49]
In addition, total net sales from non-annualized acquisitions for the year ended December 31, 2024, were $16.5 million, mostly in the domestic segment.

[0001437749-25-004353:mdna:50]
Gross profit.    Gross profit margin for the year ended December 31, 2024, was 38.8% compared to 33.9% for the year ended December 31, 2023. The increase in gross profit margin was primarily driven by favorable sales mix, including higher home standby generator sales, the realization of lower input costs, and plant efficiencies.

[0001437749-25-004353:mdna:51]
Operating expenses.    Operating expenses increased $149.7 million, or 15.3%, as compared to the prior year. The increase in operating expenses was primarily driven by higher employee and marketing costs, and increased incentive compensation and variable expenses related to higher shipment volumes and profitability. 2024 operating expenses also include $10.5 million of legal provisions and other costs related to patent and other litigation (see Note 18, “Commitments and Contingencies” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information). 2023 operating expenses included a $5.8 million provision for a regulatory matter with the CPSC, $28.3 million of legal charges related to patent and other litigation (see Note 18, “Commitments and Contingencies” for additional information), $4.4 million of additional customer support costs related to a clean energy product customer that filed for bankruptcy.

[0001437749-25-004353:mdna:52]
Other expense.    The increase in other expense, net in 2024 was driven primarily by a $38.0 million expense for the change in fair value of our investment in warrants and equity securities of Wallbox N.V., and a $4.9 million loss on extinguishment of debt. This was partially offset by a $3.3 million increase in investment income driven by higher cash on hand and a $7.9 million decrease in interest expense driven by decreased borrowings and interest rates compared to the prior year comparable period.

[0001437749-25-004353:mdna:53]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2024 and 2023 were 22.6% and 25.2%, respectively. The decrease in the effective tax rate was primarily due to unfavorable discrete tax items in 2023 that did not repeat in the current year, as well as favorable 2024 earnings mix with higher earnings in lower tax jurisdictions.

[0001437749-25-004353:mdna:54]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $316.3 million as compared to $214.6 million in the prior year period. The increase was primarily driven by higher sales and gross margin, as noted above.

[0001437749-25-004353:mdna:55]
Adjusted EBITDA.    Adjusted EBITDA is defined and reconciled to net income in, “Non-GAAP Measures – Adjusted EBITDA” included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the domestic segment for the year ended December 31, 2024, were 19.1% of domestic segment total sales compared to 15.8% for the year ended December 31, 2023. This margin improvement was primarily driven by favorable sales mix and lower input costs, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-25-004353:mdna:56]
Adjusted EBITDA margins for the international segment, before deducting for non-controlling interests, for the year ended December 31, 2024, were 13.2% of international segment total sales compared to 13.7% in the prior year. This margin decrease was primarily due to reduced operating leverage on lower shipments during the year.

[0001437749-25-004353:mdna:57]
Adjusted net income.    Adjusted Net Income is defined and reconciled to net income in, “Non-GAAP Measures – Adjusted Net Income” included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income was $438.5 million for the year ended December 31, 2024, compared to $335.3 million for the year ended December 31, 2023, with the increase primarily due to higher net income in the current year as outlined above, together with the impact of various add-backs in the current and prior years.

[0001437749-25-004353:mdna:58]
Liquidity and Financial Position

[0001437749-25-004353:mdna:59]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-25-004353:mdna:60]
As of December 31, 2024, there was $498.8 million outstanding under the Tranche B Term Loan Facility, $712.5 million outstanding under the Tranche A Term Loan Facility, and no borrowings on the Revolving Facility, leaving $1,249.2 million of unused capacity, net of outstanding letters of credit. The Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of December 31, 2024, the interest rate for the Tranche B Term Loan Facility is 6.34%. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of December 31, 2024, the interest rates for the Tranche A Term Loan Facility and Revolving Facility are 6.15% and 6.19%, respectively. See Note 5, "Derivative Instruments and Hedging Activities" to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K and Item 7A "Quantitative and Qualitative Disclosures About Market Risk" for further information on interest rate swaps, which help to reduce our borrowing costs.

[0001437749-25-004353:mdna:61]
The Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility is repayable in installments maturing at the end of each quarter commencing September 2023, with a balloon payment due June 2027. The Tranche B Term Loan Facility matures on July 3, 2031, and is repayable in installments maturing at the end of each quarter commencing September 2024, with a balloon payment due July 2031.

[0001437749-25-004353:mdna:62]
As of December 31, 2024, we had total liquidity of $1,530.5 million, which consists of $281.3 million of cash and cash equivalents and $1,249.2 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides flexibility to continue to invest in future growth opportunities.

[0001437749-25-004353:mdna:63]
In July 2022, our Board approved a stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaced the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. As of December 31, 2024, the remaining unused buyback authorization was $347,257.

[0001437749-25-004353:mdna:64]
During the years ended December 31, 2024 and 2023, we repurchased 1,046,351 shares of our common stock for $152.7 million, and 2,188,475 shares for $251.5 million, respectively. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments and some equity grants.

[0001437749-25-004353:mdna:65]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 13% and 12% of net sales for the years ended December 31, 2024 and 2023, respectively. The amount financed by dealers which remained outstanding was $165.4 million and $158.0 million as of December 31, 2024 and 2023, respectively.

[0001437749-25-004353:mdna:66]
See Note 12, “Credit Agreements,” and Note 13, “Stock Repurchase Program,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for more information on our credit agreements and stock repurchase programs. See Note 10, “Leases,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for the maturity schedule of our lease liabilities.

[0001437749-25-004353:mdna:67]
Long-term Liquidity

[0001437749-25-004353:mdna:68]
We believe our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other shareholder value enhancing activities.

[0001437749-25-004353:mdna:69]
Cash Flow

[0001437749-25-004353:mdna:70]
Year ended December 31, 2024 compared to year ended December 31, 2023

[0001437749-25-004353:mdna:71]
The following table summarizes our cash flows by source (use) for the periods presented:

[0001437749-25-004353:mdna:72]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 741,301 |  |  | $ | 521,670 |  |  | $ | 219,631 |  |  |  | 42.1 | % |
| Net cash used in investing activities |  |  | (208,712 | ) |  |  | (178,063 | ) |  |  | (30,649 | ) |  |  | -17.2 | % |
| Net cash used in financing activities |  |  | (448,835 | ) |  |  | (277,137 | ) |  |  | (171,698 | ) |  |  | -62.0 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | (3,471 | ) |  |  | 1,801 |  |  |  | (5,272 | ) |  |  | -292.7 | % |
| Net increase in cash and cash equivalents |  | $ | 80,283 |  |  | $ | 68,271 |  |  | $ | 12,012 |  |  |  | 17.6 | % |

[0001437749-25-004353:mdna:73]
The increase in net cash provided by operating activities was primarily driven by higher operating earnings coupled with a larger decrease in working capital in the current year period, as compared to the prior year.

[0001437749-25-004353:mdna:74]
The $208.7 million net cash used in investing activities for the year ended
    December 31, 2024 primarily represents cash payments of $136.7 million for the purchase of property and equipment (net of $11.1 million of capital expenditures in accounts payable as of December 31, 2024), $35.0 million for an incremental minority investment in Wallbox N.V., $2.8 million for a minority investment in Earth Foundry Fund, $1.6 million for a tax equity investment, and $34.7 million collectively for the acquisitions of Huntington, C&I BESS, Ageto, and Wolverine. These were partially offset by $2.0 million of cash proceeds from the sale of our minority interest in Rolling Energy Resources.

[0001437749-25-004353:mdna:75]
The $178.1 million net cash used in investing activities for the year ended
    December 31, 2023 primarily represents cash payments of $129.1 million for the purchase of property and equipment (net of $10.9 million of capital expenditures in accounts payable as of December 31, 2023), $30.0 million for a minority investment in Wallbox, $16.0 million for the acquisition of REFU, $6.6 million for a tax equity investment, and a $2.6 million minority investment in Rolling Energy Resources and Earth Foundry Fund.

[0001437749-25-004353:mdna:76]
The $448.8 million net cash used in financing activities for the year ended 
    December 31, 2024 primarily represents $849.1 million of debt repayments ($54.5 million of short-term borrowings and $794.6 million of long-term borrowings and finance lease obligations), $152.7 million of stock repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, $7.4 million of payments for deferred acquisition consideration, $24.8 million for taxes paid related to equity awards, and $3.6 million of payments for debt issuance costs related to our amended Tranche B Term Loan credit agreement refinancing. These uses of cash were partially offset by proceeds of $29.2 million from short-term borrowings, $541.5 million from long-term borrowings, and $27.6 million from the exercise of stock options.

[0001437749-25-004353:mdna:77]
The $277.1 million net cash used in financing activities for the year ended
    December 31, 2023 primarily consisted of $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $251.5 million used for stock repurchases, $325.8 million of debt repayments ($37.1 million of short-term borrowings and $288.7 million of long-term borrowings and finance lease obligations), $10.9 million of taxes paid related to equity awards, and $5.0 million for payment of contingent acquisition consideration. These uses of cash were partially offset by proceeds of $348.8 million from long-term borrowings, $64.3 million from short-term borrowings, and $7.8 million proceeds from the exercise of employee stock options.

[0001437749-25-004353:mdna:78]
Senior Secured Credit Facilities

[0001437749-25-004353:mdna:79]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for information on our senior secured credit facilities.

[0001437749-25-004353:mdna:80]
Covenant Compliance

[0001437749-25-004353:mdna:81]
Our Term Loans restrict the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. Our Term Loans also contain other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness, and modifications of our organizational documents. The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, an interest coverage ratio above 3.00 to 1.00, and may require an excess cash flow payment. As of December 31, 2024, the Company’s total leverage ratio was 1.33 to 1.00, and the Company's interest coverage ratio was 10.03 to 1.00. The Company was not required to make an excess cash flow payment as of December 31, 2024. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of December 31, 2024.

[0001437749-25-004353:mdna:82]
Our Term Loans contain customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Amended Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the Term Loans to automatically become immediately due and payable.

[0001437749-25-004353:mdna:83]
The Revolving Facility also contains covenants and events of default substantially similar to those in the Term Loans, as described above.

[0001437749-25-004353:mdna:84]
Capital Expenditures

[0001437749-25-004353:mdna:85]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, internal use software, IT systems & infrastructure, and upgrades. Capital expenditures were $136.7 million, $129.1 million, and $86.2 million in the years ended December 31, 2024, 2023 and 2022, respectively, and were funded primarily through cash from operations.

[0001437749-25-004353:mdna:86]
Critical Accounting Policies and Estimates

[0001437749-25-004353:mdna:87]
In preparing the financial statements, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes. The following is a discussion of critical accounting estimates in each of these areas.

[0001437749-25-004353:mdna:88]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-25-004353:mdna:89]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-25-004353:mdna:90]
For all reporting units, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-25-004353:mdna:91]
|  | ● | a rising interest rate environment; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-25-004353:mdna:92]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-25-004353:mdna:93]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-25-004353:mdna:94]
|  | ● | a significant adverse change in legal factors, the business climate, or regulatory environment; |

[0001437749-25-004353:mdna:95]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-25-004353:mdna:96]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-25-004353:mdna:97]
|  | ● | disruptions to the Company’s business; |

[0001437749-25-004353:mdna:98]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-25-004353:mdna:99]
|  | ● | loss of key management and employees |
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-25-004353:mdna:100]
|  | ● | business divestitures. |

[0001437749-25-004353:mdna:101]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition. We performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2024, 2023 and 2022, and found no impairment.

[0001437749-25-004353:mdna:102]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other indefinite-lived intangible assets.

[0001437749-25-004353:mdna:103]
Income Taxes

[0001437749-25-004353:mdna:104]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimates of income taxes payable, deferred income taxes and the effective tax rate are based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known. In assessing the net realizable value of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-25-004353:mdna:105]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and income tax positions.

[0001437749-25-004353:mdna:106]
New Accounting Standards

[0001437749-25-004353:mdna:107]
For information on new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-25-004353:mdna:108]
Non-GAAP Measures

[0001437749-25-004353:mdna:109]
Adjusted EBITDA

[0001437749-25-004353:mdna:110]
To supplement our consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Amended Credit Agreement.

[0001437749-25-004353:mdna:111]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes certain items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-25-004353:mdna:112]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-25-004353:mdna:113]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-25-004353:mdna:114]
|  | ● | as a target for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-25-004353:mdna:115]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-25-004353:mdna:116]
|  | ● | in communications with our Board and investors concerning our financial performance. |

[0001437749-25-004353:mdna:117]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-25-004353:mdna:118]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-25-004353:mdna:119]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-25-004353:mdna:120]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-25-004353:mdna:121]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board. These adjustments eliminate the impact of a number of items that:

[0001437749-25-004353:mdna:122]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, and mark-to-market gains and losses on a minority investment; |

[0001437749-25-004353:mdna:123]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-25-004353:mdna:124]
|  | ● | are non-cash in nature, such as share-based compensation expense. |

[0001437749-25-004353:mdna:125]
We explain in more detail in footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-25-004353:mdna:126]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-25-004353:mdna:127]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-25-004353:mdna:128]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-25-004353:mdna:129]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-25-004353:mdna:130]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-25-004353:mdna:131]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-25-004353:mdna:132]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-25-004353:mdna:133]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-25-004353:mdna:134]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-25-004353:mdna:135]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-25-004353:mdna:136]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 316,315 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Net income attributable to noncontrolling interests |  |  | 663 |  |  |  | 2,514 |  |  |  | 9,368 |  |
| Net income |  |  | 316,978 |  |  |  | 217,120 |  |  |  | 408,870 |  |
| Interest expense |  |  | 89,713 |  |  |  | 97,627 |  |  |  | 54,826 |  |
| Depreciation and amortization |  |  | 171,768 |  |  |  | 166,602 |  |  |  | 156,141 |  |
| Provision for income taxes |  |  | 92,460 |  |  |  | 73,180 |  |  |  | 99,596 |  |
| Non-cash write-down and other adjustments (a) |  |  | 4,757 |  |  |  | (5,953 | ) |  |  | (2,091 | ) |
| Non-cash share-based compensation expense (b) |  |  | 49,248 |  |  |  | 35,492 |  |  |  | 29,481 |  |
| Transaction costs and credit facility fees (c) |  |  | 5,097 |  |  |  | 4,054 |  |  |  | 5,026 |  |
| Business optimization and other charges (d) |  |  | 4,752 |  |  |  | 10,551 |  |  |  | 4,371 |  |
| Provision for legal, regulatory, and clean energy product charges (e) |  |  | 10,931 |  |  |  | 38,490 |  |  |  | 65,265 |  |
| Change in fair value of investment (f) |  |  | 38,006 |  |  |  | - |  |  |  | - |  |
| Loss on extinguishment of debt (g) |  |  | 4,861 |  |  |  | - |  |  |  | 3,743 |  |
| Other |  |  | 530 |  |  |  | 696 |  |  |  | 139 |  |
| Adjusted EBITDA |  |  | 789,101 |  |  |  | 637,859 |  |  |  | 825,367 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,175 |  |  |  | 4,687 |  |  |  | 15,087 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 787,926 |  |  | $ | 633,172 |  |  | $ | 810,280 |  |

[0001437749-25-004353:mdna:137]
(a) Represents the following non-cash charges, gains, and other adjustments: (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-25-004353:mdna:138]
|  | ● | The gains/losses on disposition of assets other than in the ordinary course of business and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-25-004353:mdna:139]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-25-004353:mdna:140]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value of certain assets at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price. |

[0001437749-25-004353:mdna:141]
(b) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting period.

[0001437749-25-004353:mdna:142]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-25-004353:mdna:143]
(d) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-25-004353:mdna:144]
(e) Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-004353:mdna:145]
•  A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $9.2 million in 2024; $27.3 million in 2023. 
    •  Legal expenses related to certain class action lawsuits - $1.3 million in 2024; $1.0 million in 2023. 
    •  A bad debt provision and additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million additional customer support costs in 2024; $4.4 million additional customer support costs in 2023; $17.9 million bad debt provision in 2022. 
    •  A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act (CPSA) in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in 2023; $10.0 million in 2022.

[0001437749-25-004353:mdna:146]
•  A warranty provision to address certain clean energy product warranty-related matters - $37.3 million in 2022.

[0001437749-25-004353:mdna:147]
(f) Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-004353:mdna:148]
(g) Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the 2024 and 2022 credit agreement refinancings. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt.

[0001437749-25-004353:mdna:149]
Adjusted Net Income

[0001437749-25-004353:mdna:150]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests, as set forth in the reconciliation table below.

[0001437749-25-004353:mdna:151]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-25-004353:mdna:152]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt.

[0001437749-25-004353:mdna:153]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-25-004353:mdna:154]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-25-004353:mdna:155]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-25-004353:mdna:156]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-25-004353:mdna:157]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-25-004353:mdna:158]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 316,315 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Net income attributable to noncontrolling interests |  |  | 663 |  |  |  | 2,514 |  |  |  | 9,368 |  |
| Net income |  |  | 316,978 |  |  |  | 217,120 |  |  |  | 408,870 |  |
| Amortization of intangible assets |  |  | 97,743 |  |  |  | 104,194 |  |  |  | 103,320 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 3,242 |  |  |  | 3,885 |  |  |  | 3,234 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 2,717 |  |  |  | 2,089 |  |  |  | 3,588 |  |
| Loss/(gain) attributable to business or asset dispositions (b) |  |  | 65 |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (c) |  |  | 4,752 |  |  |  | 10,551 |  |  |  | 4,371 |  |
| Provision for legal, regulatory, and clean energy product charges (c) |  |  | 10,931 |  |  |  | 38,490 |  |  |  | 65,265 |  |
| Change in fair value of investment (c) |  |  | 38,006 |  |  |  | - |  |  |  | - |  |
| Loss on extinguishment of debt (c) |  |  | 4,861 |  |  |  | - |  |  |  | 3,743 |  |
| Tax effect of add backs |  |  | (40,173 | ) |  |  | (38,384 | ) |  |  | (43,638 | ) |
| Adjusted net income |  |  | 439,122 |  |  |  | 337,826 |  |  |  | 548,524 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 663 |  |  |  | 2,514 |  |  |  | 9,675 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 438,459 |  |  | $ | 335,312 |  |  | $ | 538,849 |  |

[0001437749-25-004353:mdna:159]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-25-004353:mdna:160]
(b) Represents losses/(gains) attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-25-004353:mdna:161]
(c) See reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc. above.
