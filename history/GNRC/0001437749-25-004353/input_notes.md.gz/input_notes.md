# GNRC notes — 0001437749-25-004353


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001437749-25-004353:notes:1]
The Company’s management and Board recognize the importance of strong oversight of cybersecurity risk, information security and technology in maintaining the trust and confidence of our customers, partners, employees and stockholders. Our processes for assessing, identifying and managing material risks from cybersecurity threats is incorporated into our Enterprise Risk Management (ERM) program in a similar fashion to other legal, compliance, operational, and financial risk areas. The Company maintains cybersecurity measures aligned with the National Institute of Standards and Technology Cybersecurity Framework (Framework) which organizes cybersecurity risks into six categories: identify, protect, detect, respond, recover and govern, and looks to other standards as well to help identify, assess, and manage cybersecurity risks relevant to our business.

[0001437749-25-004353:notes:2]
Our Chief Information Officer (CIO) oversees our information systems and cybersecurity function and reports to our Chief Executive Officer (CEO). He has over 20 years of experience in leading information systems management, strategy, and operational execution, including incident prevention, management, and response. Our Company’s Chief Information Security Officer (CISO) is responsible for developing and implementing our information security program and reports to our CIO. The CISO has over 25 years of experience supporting cybersecurity and information technology. They are supported by a direct and cross-functional team of professionals with expertise and experience in threat assessment and detection, mitigation strategies, incident response, training, and regulatory compliance.

[0001437749-25-004353:notes:3]
In addition, we have established a Cybersecurity Steering Committee comprised of members of executive leadership. The Steering Committee, in which our CIO and CISO participate, meets regularly and has established Company-wide policies and standards concerning cybersecurity matters. These policies cover areas such as malware protection, remote access, multifactor authentication, containment of confidential information and the use of the internet, email and wireless devices. We have an established incident response plan led by our CIO and CISO and depending on the nature and severity of the incident, requires escalating notifications up to our CEO and Board.

[0001437749-25-004353:notes:4]
Our Board oversees our enterprise risk management activities. The Board receives periodic updates on our cybersecurity risk management program as well as regular updates and education on relevant legislation and trends related to cybersecurity. Our Audit Committee assists the Board in its oversight role and receives regular reports from management on the Company’s information systems and cybersecurity program. Several members of our Board's Audit Committee have expertise and experience in cybersecurity, and one director is the President of a major cybersecurity services provider.

[0001437749-25-004353:notes:5]
The CISO and information technology security team conduct regular risk assessments to assess the overall technology infrastructure and related business processes, identify and address potential security gaps and vulnerabilities, and identify areas requiring additional focus. These risk assessments extend to our supply chain, where cybersecurity health assessments are employed for our critical suppliers. The results are used to calculate a Cybersecurity Risk Score, a key component of our Supply Chain Scorecard used to proactively identify and manage potential risks. Additionally, we require certain third parties that could introduce significant cybersecurity risk to us to agree by contract to manage their cybersecurity risks in specified ways, as appropriate. Risk assessments are also performed on new products and software as part of our new product development process.

[0001437749-25-004353:notes:6]
As part of our risk assessments, we engage third-party services for network penetration testing and security evaluations, conduct annual incident response table-top exercises, and perform regular testing of controls related to our financial information systems by our Internal Audit function.

[0001437749-25-004353:notes:7]
In order to promote a culture of security awareness across our organization, all employees are required to complete an annual cybersecurity awareness training and are provided with periodic information updates on cybersecurity threats. We also maintain cyber insurance policies to help partially mitigate the financial impact of a significant cybersecurity incident.

[0001437749-25-004353:notes:8]
Despite our best efforts, we cannot guarantee that our security measures will prevent all potential cybersecurity incidents or breaches. Our systems are continually subject to sophisticated and evolving cyber threats, such as phishing, ransomware, social engineering, and advanced persistent threats. However, to date, we have not been subject to any incidents or successful cyber-attacks that have materially impacted our operations or financial condition. The Company has invested in developing and acquiring cybersecurity capabilities allowing us to monitor threats and manage incident response. We have also developed internal policies to mitigate cybersecurity incidents, including providing clear guidelines for incident classification, escalation, and response. We recognize the importance of continued monitoring and improvement of our cybersecurity program, and will continue to evolve our security controls, incident response capabilities, and third-party vendor management protocols.

[0001437749-25-004353:notes:9]
For additional information on the cybersecurity risks that we face, also see Item 1A. “Risk Factors” of this Annual Report on Form 10-K.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-25-004353:notes:10]
| 1. | Description of Business |

[0001437749-25-004353:notes:11]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-25-004353:notes:12]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-25-004353:notes:13]
|  | ● |  | In November 2024, the Company acquired Wolverine Power Systems (Wolverine), headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● |  | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC (Ageto). Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado. |
|  | ● |  | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System (C&I BESS) product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● |  | In April 2024, the Company acquired Huntington Power Equipment, Inc. (Huntington), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● |  | In February 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |
|  | ● |  | In October 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network solutions to enable distributed energy generation monitoring and control. |
|  | ● |  | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of design, build, maintenance, and repair services for data center and telecom facilities. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-25-004353:notes:14]
| 2. | Summary of Accounting Policies |

[0001437749-25-004353:notes:15]
Principles of Consolidation

[0001437749-25-004353:notes:16]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-25-004353:notes:17]
Cash and Cash Equivalents

[0001437749-25-004353:notes:18]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-25-004353:notes:19]
Concentration of Credit Risk

[0001437749-25-004353:notes:20]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured. One customer accounted for approximately 10% and 7% of accounts receivable as of  December 31, 2024 and 2023, respectively. No one customer accounted for greater than 5%, 4%, and 4%, of net sales during the years ended  December 31, 2024, 2023, and 2022, respectively.

[0001437749-25-004353:notes:21]
Accounts Receivable and Allowance for Credit Losses

[0001437749-25-004353:notes:22]
The Company's trade and other receivables primarily arise from the sale of its products and services to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, EPC companies, telecommunications customers, and certain end users with payment terms generally ranging from
     30 to
     90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that
      may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-25-004353:notes:23]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity-by-entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-25-004353:notes:24]
The Company holds various credit insurance plans that cover the risk of loss up to specified amounts on certain trade receivables. As of
      December 31, 2024, the Company had gross receivables of
     $647,572 and an allowance for credit losses of
     $35,465.

[0001437749-25-004353:notes:25]
Inventories

[0001437749-25-004353:notes:26]
Inventories are stated at the lower of cost or market, with cost determined using the
     first-in,
     first-out method.

[0001437749-25-004353:notes:27]
Property and Equipment

[0001437749-25-004353:notes:28]
Property and equipment, including internal use software, is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. The Company capitalizes internal use software and significant enhancements when the Company obtains a software license or develops the software internally. The Company capitalizes cloud computing arrangements that qualify as service contracts if the Company has the contractual right to take possession of the software at any time during the contract period, without significant penalty and if it is feasible for the Company to either operate the software internally or contract with a third party to host the software on our behalf. Implementation costs incurred in cloud computing arrangements that are service contracts are recorded in prepaid expenses and other assets and operating lease and other assets in the Consolidated Balance Sheets and are amortized over the expected service period of the cloud computing arrangements. Finance lease right of use assets are included in property and equipment.

[0001437749-25-004353:notes:29]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office & information technology equipment and internal use software |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-25-004353:notes:30]
Total depreciation and finance lease amortization expense was $74,025, $62,408, and $52,821 for the years ended  December 31, 2024, 2023 and 2022, respectively.

[0001437749-25-004353:notes:31]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-25-004353:notes:32]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-25-004353:notes:33]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-25-004353:notes:34]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2024, 2023 and 2022, and found no impairment.

[0001437749-25-004353:notes:35]
Impairment of Long-Lived Assets

[0001437749-25-004353:notes:36]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-25-004353:notes:37]
Debt Issuance Costs

[0001437749-25-004353:notes:38]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements.
     $3,242,
     $3,885, and
     $3,234 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years
     2024,
     2023 and
     2022, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next
     five years is as follows:
     2025 -
     $2,573;
     2026 -
     $2,544;
     2027 -
     $1,434;
     2028 -
     $437;
     2029 -
     $463.

[0001437749-25-004353:notes:39]
Income Taxes

[0001437749-25-004353:notes:40]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax basis of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-25-004353:notes:41]
Revenue Recognition

[0001437749-25-004353:notes:42]
The Company’s revenues primarily consist of the sale of products to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based on historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based on historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add, and other similar taxes assessed by governmental authorities and collected concurrently with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As a substantial portion of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-25-004353:notes:43]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears after shipment of the product to the customer. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $26,858 and $19,173 as of  December 31, 2024, and  December 31, 2023, respectively. During the year ended  December 31, 2024, the Company recognized revenue of $19,173 related to amounts included in the  December 31, 2023, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-25-004353:notes:44]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based on historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the Company’s standard warranties.

[0001437749-25-004353:notes:45]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts, following the standard warranty period. For extended warranty contracts that the Company sells under a
     third-party marketing agreement, it is required to pay fees to the
     third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized as an offset to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note
     11, “Product Warranty Obligations,” to the consolidated financial statements of this Annual Report on Form
     10-K for further information regarding the Company’s extended warranties.

[0001437749-25-004353:notes:46]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation, maintenance, data center and telecom facility design and build, and grid services to utilities in certain circumstances. Total service revenues accounted for less than
     4%,
     4%, and
     3% of net sales during the years ended
      December 31, 2024, 2023 and 2022, respectively.

[0001437749-25-004353:notes:47]
Refer to Note
     7, “Segment Reporting,” to the consolidated financial statements of this Annual Report on Form
     10-K for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-25-004353:notes:48]
Advertising and Co-Op Advertising

[0001437749-25-004353:notes:49]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $116,550, $118,303, and $100,589 for the years ended  December 31, 2024, 2023 and 2022, respectively.

[0001437749-25-004353:notes:50]
Research and Development

[0001437749-25-004353:notes:51]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $219,600, $173,443, and $159,774 for the years ended  December 31, 2024, 2023 and 2022, respectively.

[0001437749-25-004353:notes:52]
Foreign Currency Translation and Transactions

[0001437749-25-004353:notes:53]
Balance sheet amounts for non-U.S. Dollar functional currency subsidiaries are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related balance sheet translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:54]
Fair Value of Financial Instruments

[0001437749-25-004353:notes:55]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-25-004353:notes:56]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility (Revolving Facility) borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Tranche A Term Loan Facility borrowing, which has a net carrying value of $710,715, was approximately $705,375 (Level 2) as of  December 31, 2024. The fair value of the Tranche B Term Loan Facility borrowing, which has a net carrying value of $495,936, was approximately $501,244 (Level 2) as of  December 31, 2024. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-25-004353:notes:57]
For the fair value of the assets and liabilities measured on a recurring basis, excluding the contingent consideration discussed below, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements of this Annual Report on Form 10-K. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-25-004353:notes:58]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these contracts is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in the third quarter of 2024 and fourth quarter of 2023 expire at the earlier of when the price per share equals or exceeds $6.00 or in 2028 and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-25-004353:notes:59]
Equity Securities

[0001437749-25-004353:notes:60]
Equity securities consist of shares of Wallbox N.V's (Wallbox) Class A common stock (Wallbox Shares). The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The investment in Wallbox Shares is included in operating lease and other assets in the consolidated balance sheets. The fair value of the investment in Wallbox Shares was $19,075 and $17,213 as of  December 31, 2024, and  December 31, 2023, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the consolidated statements of comprehensive income. The loss recognized on the investment in Wallbox Shares was $30,679 for the year ended  December 31, 2024. For additional information regarding the Company's investment in Wallbox, see Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements of this Annual Report on Form 10-K

[0001437749-25-004353:notes:61]
Contingent Consideration

[0001437749-25-004353:notes:62]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-25-004353:notes:63]
The combined fair value of contingent consideration for Chilicon and Ageto as of  December 31, 2024, and for Chilicon and Pramac as of  December 31, 2023, was $34,114 and $38,937, respectively. The contingent consideration period for Chilicon extends through  December 31, 2028, while the contingent consideration period for Pramac extends through  December 31, 2025. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration capable of being earned each year as of  August 1, 2025,  August 1, 2026, and  August 1, 2027. The current portion of contingent consideration is reported in other accrued liabilities and the non-current portion is reported in operating lease and other long-term liabilities in the consolidated balance sheets.

[0001437749-25-004353:notes:64]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-25-004353:notes:65]
| Beginning balance, January 1, 2024 |  | $ | 38,937 |  |
| Changes in fair value (1) |  |  | (11,627 | ) |
| Additional contingent consideration (2) |  |  | 5,911 |  |
| Payment of contingent consideration |  |  | - |  |
| Present value interest accretion |  |  | 893 |  |
| Ending balance, December 31, 2024 |  | $ | 34,114 |  |

[0001437749-25-004353:notes:66]
(1) Represents the change in fair value of the contingent deferred consideration for the Pramac buyout. See Note 4, "Redeemable Noncontrolling Interest", to the consolidated financial statements of this Annual Report on Form 10-K.

[0001437749-25-004353:notes:67]
(2) Represents $5,911 of contingent consideration related to the Ageto acquisition.

[0001437749-25-004353:notes:68]
Use of Estimates

[0001437749-25-004353:notes:69]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-25-004353:notes:70]
Derivative Instruments and Hedging Activities

[0001437749-25-004353:notes:71]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or trade derivative financial instruments for trading purposes.

[0001437749-25-004353:notes:72]
Share-Based Compensation

[0001437749-25-004353:notes:73]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements of this Annual Report on Form 10-K for further information on the Company’s share-based compensation plans and accounting.

[0001437749-25-004353:notes:74]
New Accounting Pronouncements

[0001437749-25-004353:notes:75]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification.

[0001437749-25-004353:notes:76]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated provisions.

[0001437749-25-004353:notes:77]
In  March 2024, the Securities and Exchange Commission (SEC) adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with the Company's annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, the Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

[0001437749-25-004353:notes:78]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024. Entities  may apply the new disclosures prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures, but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-25-004353:notes:79]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The required annual disclosures are reflected in Note 7, "Segment Reporting," to this Annual Report on Form 10-K and the Company will disclose the required quarterly information beginning with the Form 10-Q for the three months ending  March 31, 2025.

[0001437749-25-004353:notes:80]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during 2024 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-004353:notes:81]
| 3. | Acquisitions |

[0001437749-25-004353:notes:82]
Fiscal 2024 Acquisitions

[0001437749-25-004353:notes:83]
On  November 1, 2024, the Company acquired Wolverine, headquartered in Zeeland, Michigan. Wolverine is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-25-004353:notes:84]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto. Ageto designs and integrates microgrid control solutions and is headquartered in Fort Collins, Colorado.

[0001437749-25-004353:notes:85]
On  June 26, 2024, the Company closed on the acquisition of the C&I BESS product offering from SunGrid Solutions Inc. located in Cambridge, Canada.

[0001437749-25-004353:notes:86]
On  April 1, 2024, the Company acquired Huntington, headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-25-004353:notes:87]
The combined preliminary purchase price for these acquisitions was $45,825, net of cash acquired and inclusive of holdbacks and estimated contingent consideration. The Company recorded its preliminary purchase price allocations based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington will be finalized prior to  June 30, 2025, while purchase accounting for Ageto will be finalized prior to  September 30, 2025. Purchase accounting for Wolverine will be finalized prior to  December 31, 2025. There have not been any material changes to the preliminary purchase price allocation for Wolverine, Ageto, C&I BESS, or Huntington as of  December 31, 2024. The accompanying consolidated financial statements include the results of these acquisitions from their dates of acquisition.

[0001437749-25-004353:notes:88]
Fiscal 2023 Acquisitions

[0001437749-25-004353:notes:89]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market.

[0001437749-25-004353:notes:90]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for REFUstor was finalized in the first quarter of 2024 and did not result in material adjustments to the Company's preliminary estimates. The final purchase price was $16,127. The accompanying consolidated financial statements include the results of REFUstor since the date of acquisition.

[0001437749-25-004353:notes:91]
Fiscal 2022 Acquisitions

[0001437749-25-004353:notes:92]
On  June 30, 2022, the Company acquired EEC. Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider design, build, maintenance, and repair services for data center and telecom facilities.

[0001437749-25-004353:notes:93]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network solutions to enable distributed energy generation monitoring and control.

[0001437749-25-004353:notes:94]
The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for EEC was finalized in the second quarter of 2023, and purchase accounting for Blue Pillar was finalized in the fourth quarter of 2023, neither of which resulted in material adjustments to the Company's preliminary estimates. The final combined purchase price for EEC and Blue Pillar was $27,658. The accompanying consolidated financial statements include the results of the acquired businesses since their dates of acquisition.

[0001437749-25-004353:notes:95]
Pro forma and other financial information are not presented as the effects of the Company's acquisitions since 2022 are not material to the Company's results of operations or financial position.

[0001437749-25-004353:notes:96]
Summary Purchase Price Allocations

[0001437749-25-004353:notes:97]
The fair values assigned to certain assets acquired and liabilities assumed for all acquisitions completed since  January 1, 2022, are as follows:

[0001437749-25-004353:notes:98]
|  |  | 2024 Acquisitions |  |  | 2023 Acquisitions |  |  | 2022 Acquisitions |  |
| Accounts receivable |  | $ | 9,528 |  |  | $ | 347 |  |  | $ | 11,965 |  |
| Inventories |  |  | 10,150 |  |  |  | 1,239 |  |  |  | 2,955 |  |
| Prepaid expenses and other current assets |  |  | 864 |  |  |  | 166 |  |  |  | 4,456 |  |
| Property and equipment |  |  | 824 |  |  |  | 5,843 |  |  |  | 708 |  |
| Intangible assets |  |  | 14,551 |  |  |  | 6,174 |  |  |  | 10,032 |  |
| Goodwill |  |  | 22,536 |  |  |  | 5,363 |  |  |  | 8,714 |  |
| Other assets |  |  | 2,712 |  |  |  | 837 |  |  |  | 1,954 |  |
| Total assets acquired |  |  | 61,165 |  |  |  | 19,969 |  |  |  | 40,784 |  |
| Accounts payable |  |  | 2,420 |  |  |  | 1,278 |  |  |  | 1,826 |  |
| Accrued wages and employee benefits |  |  | 1,256 |  |  |  | 264 |  |  |  | 1,662 |  |
| Other accrued liabilities |  |  | 9,043 |  |  |  | 236 |  |  |  | 7,917 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 146 |  |  |  | - |  |  |  | - |  |
| Deferred income taxes |  |  | 803 |  |  |  | 2,007 |  |  |  | 564 |  |
| Other long-term liabilities |  |  | 1,490 |  |  |  | 57 |  |  |  | 1,157 |  |
| Long-term debt |  |  | 182 |  |  |  | - |  |  |  |  |  |
| Net assets acquired |  | $ | 45,825 |  |  | $ | 16,127 |  |  | $ | 27,658 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-25-004353:notes:99]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-25-004353:notes:100]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price for the remaining 20% ownership interest included $105,264 of initial consideration, which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023, and $11,490 of contingent deferred consideration of up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025. Accordingly, there was no redeemable noncontrolling interest related to Pramac as of  December 31, 2023. This contingent deferred consideration was reduced to zero in the fourth quarter of 2024. Refer to Note 2, "Summary of Accounting Policies", to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the contingent deferred consideration.

[0001437749-25-004353:notes:101]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder had a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company had a call option that  may be redeemed any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price was based on a multiple of earnings, subject to the terms of the acquisition agreement. In  May 2022, the Company purchased an additional 15% ownership interest in Captiva for $375, which was paid with cash on hand, bringing the Company's total ownership interest in Captiva to 66%. On  April 5, 2024, the Company acquired the remaining 34% ownership interest in Captiva for $9,117 of cash.

[0001437749-25-004353:notes:102]
The redeemable noncontrolling interests were recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements of this Annual Report on Form 10-K. The following table presents the changes in the redeemable noncontrolling interest for both Captiva and Pramac:

[0001437749-25-004353:notes:103]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 6,549 |  |  | $ | 110,471 |  |  | $ | 58,050 |  |
| Share of net income |  |  | 58 |  |  |  | 1,864 |  |  |  | 7,543 |  |
| Foreign currency translation rate changes |  |  | (176 | ) |  |  | (549 | ) |  |  | (3,982 | ) |
| Purchase of additional ownership interest |  |  | (9,117 | ) |  |  | (116,754 | ) |  |  | (375 | ) |
| Redemption value adjustment |  |  | 2,686 |  |  |  | 11,517 |  |  |  | 49,235 |  |
| Balance at end of period |  | $ | - |  |  | $ | 6,549 |  |  | $ | 110,471 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-25-004353:notes:104]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-25-004353:notes:105]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in the Company’s consolidated statements of comprehensive income. The commodity and foreign currency forward contract gains and losses are not material to the Company’s consolidated financial statements for the periods presented.

[0001437749-25-004353:notes:106]
Additionally, the Company maintains interest rate swap agreements and owns stock warrants described in more detail below.

[0001437749-25-004353:notes:107]
Interest Rate Swaps

[0001437749-25-004353:notes:108]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements, which were still outstanding as of  December 31, 2024.

[0001437749-25-004353:notes:109]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 12, “Credit Agreements,” to the consolidated financial statements of this Annual Report on Form 10-K, the Company amended its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets.

[0001437749-25-004353:notes:110]
The amount of after-tax unrealized gains (losses) recognized for the years ended  December 31, 2024, 2023 and 2022 were $(7,672), $(8,004), and $38,494, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-25-004353:notes:111]
See Item 7A “Quantitative and Qualitative Disclosures About Market Risk” of this Annual Report on Form 10-K for additional information on these interest rate swaps.

[0001437749-25-004353:notes:112]
Stock Warrants

[0001437749-25-004353:notes:113]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox to purchase 5% of its Class A common stock and acquire stock warrants, the latter of which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024, the Company received additional warrants in connection with an additional round of funding performed by Wallbox through the Company's anti-dilution protection rights. In accordance with U.S. GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:114]
The loss attributable to the stock warrants was $7,327 for the year ended  December 31, 2024.

[0001437749-25-004353:notes:115]
Fair Value

[0001437749-25-004353:notes:116]
The following table presents the fair value of the Company’s derivatives:

[0001437749-25-004353:notes:117]
|  |  | December 31, |  |
|  |  | 2024 |  | 2023 |  |
| Interest rate swaps |  | $ | 28,367 |  | $ | 38,601 |  |
| Stock warrants |  |  | 7,919 |  |  | 14,862 |  |

[0001437749-25-004353:notes:118]
The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the consolidated balance sheet as of  December 31, 2024 and  December 31, 2023. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  December 31, 2024, and  December 31, 2023, is an asset of $29,254 and $39,796, respectively, which represents the net amount the Company would receive to exit all of the agreements on that date.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-25-004353:notes:119]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-25-004353:notes:120]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2024 and 2023, net of tax:

[0001437749-25-004353:notes:121]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Current-period comprehensive income (loss) |  |  | (62,584 | ) | (1) |  |  | (7,672 | ) | (2) |  |  | (70,256 | ) |
| Ending Balance – December 31, 2024 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |

[0001437749-25-004353:notes:122]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Current-period comprehensive income (loss) |  |  | 57,963 |  | (3) |  |  | (8,004 | ) | (4) |  |  | 49,959 |  |
| Ending Balance – December 31, 2023 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |

[0001437749-25-004353:notes:123]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2024, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized losses of $(10,235) on the interest rate swaps, net of tax effect of $2,563 for the year ended December 31, 2024. |
|  | (3) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the year ended December 31, 2023, particularly the Euro, British Pound, and Mexican Peso. |

[0001437749-25-004353:notes:124]
|  | (4) | Represents unrealized losses of $(10,678) on the interest rate swaps, net of tax effect of $2,674 for the year ended December 31, 2023. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-004353:notes:125]
| 7. | Segment Reporting |

[0001437749-25-004353:notes:126]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and all historical acquisitions based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes all historical acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations. Intersegment sales are at an appropriate transfer price.

[0001437749-25-004353:notes:127]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-25-004353:notes:128]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,352,629 |  |  | $ | 80,845 |  |  | $ | 2,433,474 |  |
| Commercial & Industrial products |  |  | 828,586 |  |  |  | 560,883 |  |  |  | 1,389,469 |  |
| Other |  |  | 417,934 |  |  |  | 54,957 |  |  |  | 472,891 |  |
| Total net sales |  | $ | 3,599,149 |  |  | $ | 696,685 |  |  | $ | 4,295,834 |  |

[0001437749-25-004353:notes:129]
|  |  | Year Ended December 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,945,273 |  |  | $ | 117,656 |  |  | $ | 2,062,929 |  |
| Commercial & Industrial products |  |  | 916,118 |  |  |  | 578,681 |  |  |  | 1,494,799 |  |
| Other |  |  | 414,933 |  |  |  | 50,006 |  |  |  | 464,939 |  |
| Total net sales |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | 4,022,667 |  |

[0001437749-25-004353:notes:130]
|  |  | Year Ended December 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,782,037 |  |  | $ | 129,834 |  |  | $ | 2,911,871 |  |
| Commercial & Industrial products |  |  | 746,172 |  |  |  | 514,565 |  |  |  | 1,260,737 |  |
| Other |  |  | 339,657 |  |  |  | 52,472 |  |  |  | 392,129 |  |
| Total net sales |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | 4,564,737 |  |

[0001437749-25-004353:notes:131]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold directly to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-25-004353:notes:132]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction (EPC) companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold directly to the end customer. Substantially all of the C&I products' revenues are transferred to the customer at a point in time.

[0001437749-25-004353:notes:133]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain design, build, installation, and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes after certain milestones are met.

[0001437749-25-004353:notes:134]
The Company views Adjusted EBITDA as a key measure of the Company's performance. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements. The Company presents Adjusted EBITDA
    not only due to its importance for purposes of the Company's credit agreements, but also because it assists the Company in comparing performance across reporting periods on a consistent basis as it excludes items the Company's management does
    not believe are indicative of the Company's core operating performance. The Company's Chief Operating Decision Maker (CODM) is Aaron Jagdfeld, President and Chief Executive Officer (CEO). He uses Adjusted EBITDA, along with the Company's management:

[0001437749-25-004353:notes:135]
|  | ● | for planning purposes, including the preparation of the Company's annual operating budget and developing and refining internal projections for future periods; |

[0001437749-25-004353:notes:136]
|  | ● | to allocate resources to enhance the financial performance of the Company's business; |

[0001437749-25-004353:notes:137]
|  | ● | as a target for the determination of the bonus component of compensation for the Company's senior executives under the Company's management incentive plan, as described further in the Company's Proxy Statement; |

[0001437749-25-004353:notes:138]
|  | ● | to evaluate the effectiveness of the Company's business strategies and as a supplemental tool in evaluating the Company's performance against the Company's budget for each period; and |

[0001437749-25-004353:notes:139]
|  | ● | in communications with the Company's Board and investors concerning the Company's financial performance. |

[0001437749-25-004353:notes:140]
See "Non-GAAP measures - Adjusted EBITDA" in Item 7 of this Annual Report on Form 10-K for more information on the Company's use of Adjusted EBITDA. The table below presents sales (external and intersegment), significant segment expenses, and Adjusted EBITDA by reportable segment, reconciled to consolidated income before provision for income taxes.

[0001437749-25-004353:notes:141]
|  |  | Year Ended December 31, 2024 |  |  | Year Ended December 31, 2023 |  |  | Year Ended December 31, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 3,599,149 |  |  |  | 696,685 |  |  | $ | 4,295,834 |  |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | 4,022,667 |  |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | 4,564,737 |  |
| Intersegment sales |  |  | 35,932 |  |  |  | 28,700 |  |  |  | 64,632 |  |  |  | 43,937 |  |  |  | 91,552 |  |  |  | 135,489 |  |  |  | 60,731 |  |  |  | 93,699 |  |  |  | 154,430 |  |
| Total sales |  |  | 3,635,081 |  |  |  | 725,385 |  |  |  | 4,360,466 |  |  |  | 3,320,261 |  |  |  | 837,895 |  |  |  | 4,158,156 |  |  |  | 3,928,597 |  |  |  | 790,570 |  |  |  | 4,719,167 |  |
| Elimination of intersegment sales |  |  | - |  |  |  | - |  |  |  | (64,632 | ) |  |  | - |  |  |  | - |  |  |  | (135,489 | ) |  |  | - |  |  |  | - |  |  |  | (154,430 | ) |
| Costs of goods sold |  |  | 2,155,269 |  |  |  | 539,571 |  |  |  | 2,694,840 |  |  |  | 2,168,210 |  |  |  | 624,515 |  |  |  | 2,792,725 |  |  |  | 2,604,124 |  |  |  | 593,039 |  |  |  | 3,197,163 |  |
| Elimination of intersegment cost of goods sold |  |  | - |  |  |  | - |  |  |  | (64,632 | ) |  |  | - |  |  |  | - |  |  |  | (135,489 | ) |  |  | - |  |  |  | - |  |  |  | (154,430 | ) |
| Operating expenses |  |  | 991,042 |  |  |  | 137,842 |  |  |  | 1,128,884 |  |  |  | 839,827 |  |  |  | 139,405 |  |  |  | 979,232 |  |  |  | 833,896 |  |  |  | 121,778 |  |  |  | 955,674 |  |
| Other segment items (1) |  |  | (204,433 | ) |  |  | (47,926 | ) |  |  | (252,359 | ) |  |  | (211,113 | ) |  |  | (40,547 | ) |  |  | (251,660 | ) |  |  | (225,725 | ) |  |  | (33,312 | ) |  |  | (259,037 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 693,203 |  |  | $ | 95,898 |  |  |  | 789,101 |  |  | $ | 523,337 |  |  | $ | 114,522 |  |  |  | 637,859 |  |  | $ | 716,302 |  |  | $ | 109,065 |  |  |  | 825,367 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (89,713 | ) |  |  |  |  |  |  |  |  |  |  | (97,627 | ) |  |  |  |  |  |  |  |  |  |  | (54,826 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (171,768 | ) |  |  |  |  |  |  |  |  |  |  | (166,602 | ) |  |  |  |  |  |  |  |  |  |  | (156,141 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (4,757 | ) |  |  |  |  |  |  |  |  |  |  | 5,953 |  |  |  |  |  |  |  |  |  |  |  | 2,091 |  |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (49,248 | ) |  |  |  |  |  |  |  |  |  |  | (35,492 | ) |  |  |  |  |  |  |  |  |  |  | (29,481 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (5,097 | ) |  |  |  |  |  |  |  |  |  |  | (4,054 | ) |  |  |  |  |  |  |  |  |  |  | (5,026 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (4,752 | ) |  |  |  |  |  |  |  |  |  |  | (10,551 | ) |  |  |  |  |  |  |  |  |  |  | (4,371 | ) |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  |  |  |  |  |  |  |  |  | (10,931 | ) |  |  |  |  |  |  |  |  |  |  | (38,490 | ) |  |  |  |  |  |  |  |  |  |  | (65,265 | ) |
| Change in fair value of investment (7) |  |  |  |  |  |  |  |  |  |  | (38,006 | ) |  |  |  |  |  |  |  |  |  |  | - |  |  |  |  |  |  |  |  |  |  |  | - |  |
| Loss on extinguishment of debt (8) |  |  |  |  |  |  |  |  |  |  | (4,861 | ) |  |  |  |  |  |  |  |  |  |  | - |  |  |  |  |  |  |  |  |  |  |  | (3,743 | ) |
| Other |  |  |  |  |  |  |  |  |  |  | (530 | ) |  |  |  |  |  |  |  |  |  |  | (696 | ) |  |  |  |  |  |  |  |  |  |  | (139 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 409,438 |  |  |  |  |  |  |  |  |  |  | $ | 290,300 |  |  |  |  |  |  |  |  |  |  | $ | 508,466 |  |

[0001437749-25-004353:notes:142]
|  | (1) | Other segment items primarily represent depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; Provision for legal, regulatory, and clean energy product charges. |
|  | (2) | Includes gains/(losses) on dispositions of assets other than in the ordinary course of business, gains/(losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-25-004353:notes:143]
|  | (3) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-25-004353:notes:144]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's Amended Credit Agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |

[0001437749-25-004353:notes:145]
|  | (6) | Represents the following litigation, regulatory, and other matters that are not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $9,299 in 2024; $27,289 in 2023. • Legal expenses related to certain class action lawsuits - $1,267 in 2024; $1,051 in 2023. • A bad debt provision and additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 and $4,350 additional customer support costs in 2024 and 2023, respectively; $17,926 bad debt provision in 2022. • A warranty provision to address clean energy product warranty-related matters - $37,338 in 2022. • A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in 2023 and $10,000 in 2022. |

[0001437749-25-004353:notes:146]
|  | (7) | Represents non-cash losses from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (8) | Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the 2024 and 2022 credit agreement refinancings. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt. |

[0001437749-25-004353:notes:147]
The following tables summarize additional financial information by reportable segment:

[0001437749-25-004353:notes:148]
|  |  | Assets |  |
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 3,873,904 |  |  | $ | 3,770,883 |  |  | $ | 4,032,086 |  |
| International |  |  | 1,235,427 |  |  |  | 1,322,429 |  |  |  | 1,137,376 |  |
| Total |  | $ | 5,109,331 |  |  | $ | 5,093,312 |  |  | $ | 5,169,462 |  |

[0001437749-25-004353:notes:149]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 135,434 |  |  | $ | 129,648 |  |  | $ | 123,768 |  |
| International |  |  | 36,334 |  |  |  | 36,954 |  |  |  | 32,373 |  |
| Total |  | $ | 171,768 |  |  | $ | 166,602 |  |  | $ | 156,141 |  |

[0001437749-25-004353:notes:150]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 117,836 |  |  | $ | 103,036 |  |  | $ | 69,680 |  |
| International |  |  | 18,897 |  |  |  | 26,024 |  |  |  | 16,508 |  |
| Total |  | $ | 136,733 |  |  | $ | 129,060 |  |  | $ | 86,188 |  |

[0001437749-25-004353:notes:151]
The Company’s sales in the United States represent approximately 79%, 77%, and 80% of total sales for the years ended  December 31, 2024, 2023 and 2022, respectively. Approximately 76% and 74% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2024 and 2023, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-25-004353:notes:152]
| 8. | Balance Sheet Details |

[0001437749-25-004353:notes:153]
Inventories consist of the following:

[0001437749-25-004353:notes:154]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Raw material |  | $ | 611,735 |  |  | $ | 677,428 |  |
| Work-in-process |  |  | 6,814 |  |  |  | 10,877 |  |
| Finished goods |  |  | 413,098 |  |  |  | 479,179 |  |
| Total |  | $ | 1,031,647 |  |  | $ | 1,167,484 |  |

[0001437749-25-004353:notes:155]
Property and equipment consists of the following:

[0001437749-25-004353:notes:156]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Land and improvements |  | $ | 30,220 |  |  | $ | 22,556 |  |
| Buildings and improvements |  |  | 358,055 |  |  |  | 298,483 |  |
| Machinery and equipment |  |  | 296,409 |  |  |  | 271,879 |  |
| Dies and tools |  |  | 48,681 |  |  |  | 45,998 |  |
| Vehicles |  |  | 13,887 |  |  |  | 11,411 |  |
| Office & information technology equipment and internal use software |  |  | 213,003 |  |  |  | 185,601 |  |
| Leasehold improvements |  |  | 9,776 |  |  |  | 8,772 |  |
| Construction in progress |  |  | 110,651 |  |  |  | 98,083 |  |
| Gross property and equipment |  |  | 1,080,682 |  |  |  | 942,783 |  |
| Accumulated depreciation |  |  | (390,659 | ) |  |  | (344,206 | ) |
| Total |  | $ | 690,023 |  |  | $ | 598,577 |  |

[0001437749-25-004353:notes:157]
Total property and equipment included finance leases of $61,214 and $68,079 as of  December 31, 2024 and 2023, respectively, primarily comprised of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statements of cash flows. Similarly, the buyout of finance lease obligations is accounted for as a non-cash exchange of the ROU asset for the underlying leased asset. In 2024, the Company purchased the property under lease from a related party previously determined to be an arm’s length transaction. Refer to Note 10, “Leases,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the Company’s accounting for leases under ASC 842, Leases.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-25-004353:notes:158]
| 9. | Goodwill and Intangible Assets |

[0001437749-25-004353:notes:159]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2024 and 2023 are as follows:

[0001437749-25-004353:notes:160]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | 1,016,657 |  |  | $ | 384,223 |  |  | $ | 1,400,880 |  |
| Acquisitions of businesses, net |  |  | 1,376 |  |  |  | 5,363 |  |  |  | 6,739 |  |
| Foreign currency translation rate changes |  |  | 495 |  |  |  | 24,270 |  |  |  | 24,765 |  |
| Balance as of December 31, 2023 |  |  | 1,018,528 |  |  |  | 413,856 |  |  |  | 1,432,384 |  |
| Acquisitions of businesses, net |  |  | 22,641 |  |  |  | - |  |  |  | 22,641 |  |
| Foreign currency translation rate changes |  |  | (22 | ) |  |  | (18,742 | ) |  |  | (18,764 | ) |
| Balance as of December 31, 2024 |  | $ | 1,041,147 |  |  | $ | 395,114 |  |  | $ | 1,436,261 |  |

[0001437749-25-004353:notes:161]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the Company’s acquisitions.

[0001437749-25-004353:notes:162]
Goodwill applicable to each reportable segment as of  December 31, 2024 and 2023 is as follows:

[0001437749-25-004353:notes:163]
|  |  | Year Ended December 31, 2024 |  |  | Year Ended December 31, 2023 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,544,340 |  |  | $ | (503,193 | ) |  | $ | 1,041,147 |  |  | $ | 1,521,721 |  |  | $ | (503,193 | ) |  | $ | 1,018,528 |  |
| International |  |  | 399,725 |  |  |  | (4,611 | ) |  |  | 395,114 |  |  |  | 418,467 |  |  |  | (4,611 | ) |  |  | 413,856 |  |
| Total |  | $ | 1,944,065 |  |  | $ | (507,804 | ) |  | $ | 1,436,261 |  |  | $ | 1,940,188 |  |  | $ | (507,804 | ) |  | $ | 1,432,384 |  |

[0001437749-25-004353:notes:164]
The following table summarizes intangible assets by major category as of  December 31, 2024 and 2023:

[0001437749-25-004353:notes:165]
|  |  |  |  |  |  | December 31, 2024 |  |  | December 31, 2023 |  |
|  |  | Weighted Average Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 15 |  |  | $ | 160,473 |  |  | $ | (81,083 | ) |  | $ | 79,390 |  |  | $ | 159,671 |  |  | $ | (70,997 | ) |  | $ | 88,674 |  |
| Customer lists |  |  | 12 |  |  |  | 591,745 |  |  |  | (439,008 | ) |  |  | 152,737 |  |  |  | 589,318 |  |  |  | (404,805 | ) |  |  | 184,513 |  |
| Patents and technology |  |  | 14 |  |  |  | 673,425 |  |  |  | (294,330 | ) |  |  | 379,095 |  |  |  | 670,099 |  |  |  | (252,658 | ) |  |  | 417,441 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 5 |  |  |  | 76,251 |  |  |  | (56,225 | ) |  |  | 20,026 |  |  |  | 71,570 |  |  |  | (44,443 | ) |  |  | 27,127 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 1,502,940 |  |  | $ | (871,692 | ) |  | $ | 631,248 |  |  | $ | 1,491,704 |  |  | $ | (773,949 | ) |  | $ | 717,755 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 127,274 |  |  |  | - |  |  |  | 127,274 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 1,630,214 |  |  | $ | (871,692 | ) |  | $ | 758,522 |  |  | $ | 1,620,025 |  |  | $ | (773,949 | ) |  | $ | 846,076 |  |

[0001437749-25-004353:notes:166]
Amortization expense of intangible assets was $97,743, $104,194, and $103,320 in 2024, 2023 and 2022, respectively. Excluding the impact of future acquisitions or divestitures, the Company estimates amortization expense for the next five years to be as follows: 2025 - $93,975; 2026 - $87,236; 2027 - $60,387; 2028 - $53,620; 2029 - $50,234.


## gnrc:LesseeOperatingLeasesAndFinanceLeasesTextBlock

[0001437749-25-004353:notes:167]
| 10. | Leases |

[0001437749-25-004353:notes:168]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to approximately 16 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend for up to 10 additional years.

[0001437749-25-004353:notes:169]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (ROU) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit interest rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-25-004353:notes:170]
The Company has lease agreements with both lease and non-lease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-25-004353:notes:171]
The Company is a lessor of certain of its C&I mobile products as part of a rental fleet, as well as three of its buildings that it leases to third parties. The lease income related to these arrangements is not material to the consolidated financial statements.

[0001437749-25-004353:notes:172]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:173]
The components of total lease cost consist of the following:

[0001437749-25-004353:notes:174]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Operating lease cost |  | $ | 46,887 |  |  | $ | 38,980 |  |  | $ | 36,292 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 7,639 |  |  |  | 4,142 |  |  |  | 3,298 |  |
| Interest on lease liabilities |  |  | 5,323 |  |  |  | 2,540 |  |  |  | 1,945 |  |
| Total lease cost |  | $ | 59,849 |  |  | $ | 45,662 |  |  | $ | 41,535 |  |

[0001437749-25-004353:notes:175]
Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-25-004353:notes:176]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating leases: |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 57,999 |  |  | $ | 70,937 |  |
| Operating lease liabilities - current (2) |  |  | 29,316 |  |  |  | 29,388 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 29,173 |  |  |  | 44,760 |  |
| Total operating lease liabilities |  |  | 58,489 |  |  |  | 74,148 |  |
| Finance leases: |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  |  | 78,801 |  |  |  | 82,744 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (17,587 | ) |  |  | (14,665 | ) |
| Finance lease ROU assets, net (4) |  |  | 61,214 |  |  |  | 68,079 |  |
| Finance lease liabilities - current (5) |  |  | 6,845 |  |  |  | 3,785 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 59,510 |  |  |  | 67,523 |  |
| Total finance lease liabilities |  | $ | 66,355 |  |  | $ | 71,308 |  |

[0001437749-25-004353:notes:177]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-25-004353:notes:178]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-25-004353:notes:179]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-25-004353:notes:180]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-25-004353:notes:181]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-25-004353:notes:182]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-25-004353:notes:183]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-25-004353:notes:184]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flows - operating leases |  | $ | 48,089 |  |  | $ | 39,073 |  |  | $ | 36,020 |  |
| Operating cash flows - finance leases |  |  | 4,924 |  |  |  | 2,409 |  |  |  | 1,919 |  |
| Financing cash flows - finance leases |  |  | 45,906 |  |  |  | 3,618 |  |  |  | 4,931 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | $ | 41,389 |  |  | $ | 17,830 |  |  | $ | 28,766 |  |
| Finance leases |  |  | 43,799 |  |  |  | 47,715 |  |  |  | 2,874 |  |

[0001437749-25-004353:notes:185]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2024 and 2023 is as follows:

[0001437749-25-004353:notes:186]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 4.27 |  |  |  | 4.55 |  |
| Finance Leases |  |  | 8.92 |  |  |  | 5.34 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 6.03 | % |  |  | 4.63 | % |
| Finance Leases |  |  | 7.03 | % |  |  | 6.64 | % |

[0001437749-25-004353:notes:187]
The maturities of the Company’s lease liabilities as of  December 31, 2024, are as follows:

[0001437749-25-004353:notes:188]
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2025 |  | $ | 11,118 |  |  | $ | 31,427 |  |
| 2026 |  |  | 10,395 |  |  |  | 7,963 |  |
| 2027 |  |  | 10,156 |  |  |  | 7,205 |  |
| 2028 |  |  | 9,593 |  |  |  | 5,712 |  |
| 2029 |  |  | 8,327 |  |  |  | 4,035 |  |
| After 2029 |  |  | 41,520 |  |  |  | 11,211 |  |
| Total minimum lease payments |  |  | 91,109 |  |  |  | 67,553 |  |
| Interest component |  |  | (24,754 | ) |  |  | (9,064 | ) |
| Present value of minimum lease payments |  | $ | 66,355 |  |  | $ | 58,489 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-25-004353:notes:189]
| 11. | Product Warranty Obligations |

[0001437749-25-004353:notes:190]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the related product to a customer based on historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-25-004353:notes:191]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 116,408 |  |  | $ | 138,011 |  |  | $ | 94,213 |  |
| Payments |  |  | (88,990 | ) |  |  | (92,200 | ) |  |  | (77,476 | ) |
| Provision for warranty issued |  |  | 77,802 |  |  |  | 67,104 |  |  |  | 80,340 |  |
| Changes in estimates for pre-existing warranties (1) |  |  | 5,767 |  |  |  | 3,493 |  |  |  | 40,934 |  |
| Balance at end of period |  | $ | 110,987 |  |  | $ | 116,408 |  |  | $ | 138,011 |  |

[0001437749-25-004353:notes:192]
| (1) | Includes a specific warranty provision of $37,338 recorded during the third quarter of 2022 to address certain clean energy product warranty related matters. |

[0001437749-25-004353:notes:193]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-25-004353:notes:194]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 155,870 |  |  | $ | 132,813 |  |  | $ | 111,647 |  |
| Deferred revenue contracts issued |  |  | 60,651 |  |  |  | 48,107 |  |  |  | 42,869 |  |
| Amortization of deferred revenue contracts |  |  | (29,599 | ) |  |  | (25,050 | ) |  |  | (21,703 | ) |
| Balance at end of period |  | $ | 186,922 |  |  | $ | 155,870 |  |  | $ | 132,813 |  |

[0001437749-25-004353:notes:195]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  December 31, 2024 is as follows:

[0001437749-25-004353:notes:196]
| 2025 |  | $ | 34,069 |  |
| 2026 |  |  | 35,267 |  |
| 2027 |  |  | 32,315 |  |
| 2028 |  |  | 25,822 |  |
| 2029 |  |  | 19,897 |  |
| After 2029 |  |  | 39,552 |  |
| Total |  | $ | 186,922 |  |

[0001437749-25-004353:notes:197]
The Company has a post-sale extended warranty marketing agreement with a third party, pursuant to which the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts the provider sells, which it classifies as costs to obtain a contract. These fees are deferred and recorded as other assets in the consolidated balance sheets, and are then amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. Deferred contract costs as of  December 31, 2024 and 2023 were $17,140 and $10,153, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2024, 2023 and 2022 was $2,958, $2,306, and $1,932, respectively.

[0001437749-25-004353:notes:198]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-25-004353:notes:199]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Product warranty liability: |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 56,127 |  |  | $ | 65,298 |  |
| Long-term portion - other long-term liabilities |  |  | 54,860 |  |  |  | 51,110 |  |
| Total |  | $ | 110,987 |  |  | $ | 116,408 |  |
| Deferred revenue related to extended warranties: |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 34,069 |  |  | $ | 28,203 |  |
| Long-term portion - Deferred revenue |  |  | 152,853 |  |  |  | 127,667 |  |
| Total |  | $ | 186,922 |  |  | $ | 155,870 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-004353:notes:200]
| 12. | Credit Agreements |

[0001437749-25-004353:notes:201]
Short-term borrowings included in the consolidated balance sheets as of  December 31, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $55,848 and $81,769, respectively. As of  December 31, 2024, and  December 31, 2023, the weighted-average interest rates on the short-term borrowings were 5.44% and 6.54%, respectively.

[0001437749-25-004353:notes:202]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-25-004353:notes:203]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 712,500 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 498,750 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (8,203 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | - |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 66,355 |  |  |  | 71,308 |  |
| Other |  |  | 8,972 |  |  |  | 9,512 |  |
| Total |  |  | 1,278,374 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 60,753 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 6,845 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,210,776 |  |  | $ | 1,447,553 |  |

[0001437749-25-004353:notes:204]
Both the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in quarterly installments commencing  September 2023, with a balloon payment due  June 2027. The Tranche B Term Loan Facility matures on  July 3, 2031, and is repayable in quarterly installments commencing  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  December 31, 2024, before considering original issue discount and deferred financing costs, are as follows:

[0001437749-25-004353:notes:205]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 46,875 |  |  | $ | 5,000 |  |  | $ | - |  |  | $ | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | - |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 712,500 |  |  | $ | 498,750 |  |  | $ | - |  |  | $ | 1,211,250 |  |

[0001437749-25-004353:notes:206]
Prior to  June 2022, the Company’s credit agreements provided for a $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026. The Company’s credit agreements also provided for a senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based on either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based on average availability under the ABL Facility.

[0001437749-25-004353:notes:207]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), terminated the former ABL Facility, and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to retire the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the original Term Loan B Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and deferred financing costs during the second quarter of 2022 as a loss on extinguishment of debt. Additionally, in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.

[0001437749-25-004353:notes:208]
During 2022, the Tranche A Term Loan Facility and the Revolving Facility bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  December 31, 2024, the interest rates for the Tranche A Term Loan Facility and Revolving Facility are 6.15% and 6.19%, respectively.

[0001437749-25-004353:notes:209]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the former Tranche B Term Loan Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031. The new Tranche B Term Loan Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs. Additionally, the Company wrote-off $4,236 of unamortized deferred financing costs related to the former Tranche B Term Loan Facility and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The new Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of  December 31, 2024, the interest rate for the Tranche B Term Loan Facility is 6.34%.

[0001437749-25-004353:notes:210]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, an interest coverage ratio above 3.00 to 1.00, and  may require an excess cash flow payment. As of  December 31, 2024, the Company’s total leverage ratio was 1.33 to 1.00, and the Company's interest coverage ratio was 10.03 to 1.00. The Company also was not required to make an excess cash flow payment as of  December 31, 2024. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  December 31, 2024.

[0001437749-25-004353:notes:211]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-25-004353:notes:212]
As of  December 31, 2024, there were no borrowings under the Revolving Facility, leaving $1,249,203 of unused capacity, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-25-004353:notes:213]
| 13. | Stock Repurchase Programs |

[0001437749-25-004353:notes:214]
In  July 2022, the Company's Board approved a stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board approved a new stock repurchase program that authorizes repurchases of up to $500,000 of the Company’s common stock over the following 24 months. The new program replaced the prior share repurchase program, which had $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. As of  December 31, 2024, the remaining unused buyback authorization was $347,257.

[0001437749-25-004353:notes:215]
During the year ended  December 31, 2024, the Company repurchased 1,046,351 shares of its common stock for $152,743. During the year ended  December 31, 2023, the Company repurchased2,188,475 shares of its common stock for $251,513. During the year ended  December 31, 2022, the Company repurchased 2,722,007 shares of its common stock for $345,840. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-004353:notes:216]
| 14. | Earnings Per Share |

[0001437749-25-004353:notes:217]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain conditions related to acquisition contingent consideration as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements of this Annual Report on Form 10-K for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-25-004353:notes:218]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-25-004353:notes:219]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 316,315 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Redemption value adjustment |  |  | 8,941 |  |  |  | (11,517 | ) |  |  | (49,235 | ) |
| Net income attributable to common shareholders |  | $ | 325,256 |  |  | $ | 203,089 |  |  | $ | 350,267 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 59,559,797 |  |  |  | 61,265,060 |  |  |  | 63,117,007 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 790,615 |  |  |  | 793,327 |  |  |  | 1,087,219 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | - |  |  |  | 477,131 |  |
| Diluted shares |  |  | 60,350,412 |  |  |  | 62,058,387 |  |  |  | 64,681,357 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.46 |  |  | $ | 3.31 |  |  | $ | 5.55 |  |
| Diluted |  | $ | 5.39 |  |  | $ | 3.27 |  |  | $ | 5.42 |  |

[0001437749-25-004353:notes:220]
|  | (1) | For the years ended December 31, 2024, December 31, 2023, and December 31, 2022, excludes approximately 428,000, 348,000 and 76,000 stock options and restricted stock awards, respectively, as the impact of such awards was anti-dilutive. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-004353:notes:221]
| 15. | Income Taxes |

[0001437749-25-004353:notes:222]
The Company’s provision for income taxes consists of the following:

[0001437749-25-004353:notes:223]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 117,749 |  |  | $ | 71,741 |  |  | $ | 118,320 |  |
| State |  |  | 20,970 |  |  |  | 13,802 |  |  |  | 25,743 |  |
| Foreign |  |  | 14,356 |  |  |  | 22,115 |  |  |  | 51,055 |  |
|  |  |  | 153,075 |  |  |  | 107,658 |  |  |  | 195,118 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (46,526 | ) |  |  | (26,504 | ) |  |  | (43,475 | ) |
| State |  |  | (8,613 | ) |  |  | (5,254 | ) |  |  | (10,966 | ) |
| Foreign |  |  | (5,565 | ) |  |  | (3,218 | ) |  |  | (40,109 | ) |
|  |  |  | (60,704 | ) |  |  | (34,976 | ) |  |  | (94,550 | ) |
| Change in valuation allowance |  |  | 89 |  |  |  | 498 |  |  |  | (972 | ) |
| Provision for income taxes |  | $ | 92,460 |  |  | $ | 73,180 |  |  | $ | 99,596 |  |

[0001437749-25-004353:notes:224]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2024, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2021. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2007 through 2023 remain open for potential examination. In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2013 through 2023.

[0001437749-25-004353:notes:225]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made and could impact the Company’s financial results.

[0001437749-25-004353:notes:226]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-25-004353:notes:227]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 52,351 |  |  | $ | 48,758 |  |
| Deferred revenue |  |  | 43,261 |  |  |  | 36,927 |  |
| Inventories |  |  | 14,103 |  |  |  | 12,549 |  |
| Stock-based compensation |  |  | 16,959 |  |  |  | 14,143 |  |
| Operating loss and credit carryforwards |  |  | 50,327 |  |  |  | 54,753 |  |
| Bad debt |  |  | 1,803 |  |  |  | 1,380 |  |
| Other |  |  | 13,031 |  |  |  | 8,722 |  |
| Capitalized R&D |  |  | 98,323 |  |  |  | 65,523 |  |
| Valuation allowance |  |  | (5,225 | ) |  |  | (5,136 | ) |
| Total deferred tax assets |  |  | 284,933 |  |  |  | 237,619 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 234,271 |  |  |  | 253,342 |  |
| Depreciation |  |  | 49,935 |  |  |  | 45,964 |  |
| Debt refinancing costs |  |  | - |  |  |  | 828 |  |
| Interest swap and derivative instruments |  |  | 6,496 |  |  |  | 9,521 |  |
| Prepaid expenses |  |  | 3,284 |  |  |  | 2,444 |  |
| Total deferred tax liabilities |  |  | 293,986 |  |  |  | 312,099 |  |
| Net deferred tax liabilities |  | $ | (9,053 | ) |  | $ | (74,480 | ) |

[0001437749-25-004353:notes:228]
As of  December 31, 2024 and 2023, deferred tax assets of $24,132 and $15,532, and deferred tax liabilities of $33,185 and $90,012, respectively, were reflected in the consolidated balance sheets.

[0001437749-25-004353:notes:229]
The Company maintains a $5,225 valuation allowance against the deferred tax assets primarily related to certain tax loss carryforwards which  may not be realized. Realization of the deferred income tax asset related to the tax loss carryforward is dependent upon generating sufficient taxable income in these jurisdictions prior to their expiration. During 2024, the valuation allowance increased by $89 on our deferred tax assets where we believe the tax asset  may not be fully utilized.

[0001437749-25-004353:notes:230]
At  December 31, 2024, the Company had tax loss carryforwards of approximately $182,431, which have varying expiration periods ranging from 2025 to indefinite. For carryforward amounts which the Company believes the losses will expire prior to use, a valuation allowance has been established. For all other carryforwards, the Company believes it will generate sufficient taxable income in these jurisdictions to utilize its loss carryforwards.

[0001437749-25-004353:notes:231]
At  December 31, 2024, the Company had state manufacturing tax credit carryforwards of approximately $27,510, which expire between 2028 and 2040. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-25-004353:notes:232]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-25-004353:notes:233]
|  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 9,703 |  |  | $ | 8,895 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 1,068 |  |  |  | 3,081 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 943 |  |  |  | 1,122 |  |
| Statute of limitation expirations |  |  | (536 | ) |  |  | (3,395 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 11,178 |  |  | $ | 9,703 |  |

[0001437749-25-004353:notes:234]
The unrecognized tax benefit as of  December 31, 2024 and 2023, if recognized, would favorably impact the effective tax rate.

[0001437749-25-004353:notes:235]
As of  December 31, 2024 and 2023, total accrued interest of approximately $1,142 and $532, respectively, and accrued penalties of approximately $954 and $1,275, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-25-004353:notes:236]
The Company does not expect a significant change to the total amount of unrecognized tax benefits during the fiscal year ending  December 31, 2025.

[0001437749-25-004353:notes:237]
A reconciliation of the U.S. federal statutory tax rate to the effective tax rate for the years ended  December 31, 2024, 2023 and 2022 is as follows:

[0001437749-25-004353:notes:238]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 21.0 | % |
| State taxes |  |  | 3.8 |  |  |  | 4.0 |  |  |  | 4.0 |  |
| State tax rate differential |  |  | (0.2 | ) |  |  | 0.0 |  |  |  | (0.3 | ) |
| Research and development credits |  |  | (1.2 | ) |  |  | (2.4 | ) |  |  | (1.1 | ) |
| State credits |  |  | (0.5 | ) |  |  | (0.9 | ) |  |  | (1.5 | ) |
| Share-based compensation benefit |  |  | (1.2 | ) |  |  | (0.4 | ) |  |  | (2.7 | ) |
| Nondeductible U.S. compensation expense |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.6 |  |
| Foreign tax deduction |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.4 | ) |
| Uncertain tax positions reserve |  |  | 0.6 |  |  |  | 0.9 |  |  |  | 0.0 |  |
| Global intangible low tax income |  |  | 0.4 |  |  |  | 1.7 |  |  |  | 0.2 |  |
| Other |  |  | (1.3 | ) |  |  | 0.3 |  |  |  | (1.2 | ) |
| Effective tax rate |  |  | 22.6 | % |  |  | 25.2 | % |  |  | 19.6 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-25-004353:notes:239]
| 16. | Benefit Plans |

[0001437749-25-004353:notes:240]
Medical and Dental Plans

[0001437749-25-004353:notes:241]
The Company maintains medical and dental benefit plans covering its full-time U.S. employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $32,964, $26,090, and $31,180 for the years ended  December 31, 2024, 2023 and 2022, respectively.

[0001437749-25-004353:notes:242]
Employees of the Company’s foreign subsidiaries participate in government sponsored medical benefit plans and other local plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-25-004353:notes:243]
Savings Plan

[0001437749-25-004353:notes:244]
The Company maintains a defined-contribution 401(k) savings plan for eligible U.S. employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 8% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008, that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures of unused company contributions  may be applied against plan expenses and future Company contributions. The Company recognized $7,779, $3,735, and $4,141 of expense related to these plans for the years ended  December 31, 2024, 2023 and 2022, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-25-004353:notes:245]
| 17. | Share Plans |

[0001437749-25-004353:notes:246]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010, in connection with its initial public offering. The 2010 Plan, as amended, allowed for the grant of up to 9.1 million share-based awards to executives, directors, and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. New grants under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the 2010 Plan, net of estimated forfeitures, was $0, $309, and $2,379 for the years ended  December 31, 2024, 2023 and 2022, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:247]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). The 2019 Plan allows for the grant of up to 2.7 million share-based awards to executives, directors, and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. On  June 13, 2024, the stockholders of Generac Holdings Inc. approved an amendment to the 2019 Plan to increase the number of shares available for issuance by 3.9 million. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $49,248, $35,183, and $27,102 for the years ended  December 31, 2024, 2023 and 2022, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:248]
Stock Options - Stock options granted in 2024 have an exercise price between $112.45 and $147.41 per share; stock options granted in 2023 have an exercise price between $110.86 and $119.57 per share; and stock options granted in 2022 have an exercise price between $103.50 and $315.88 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-25-004353:notes:249]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 9,701, 31,030, and 17,376 for the years ended  December 31, 2024, 2023 and 2022, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-25-004353:notes:250]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds to the Company from the cashless for cash exercise of stock options were $27,558, $7,815, and $13,786 for the years ended  December 31, 2024, 2023 and 2022, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-25-004353:notes:251]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $13,672, $4,895, and $14,089 for the years ended  December 31, 2024, 2023 and 2022, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-25-004353:notes:252]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history and are trued up upon vesting based on actual forfeiture activity.

[0001437749-25-004353:notes:253]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2024, 2023 and 2022 are as follows:

[0001437749-25-004353:notes:254]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Weighted average grant date fair value per share |  | $ | 59.30 |  |  | $ | 57.73 |  |  | $ | 129.38 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 49 | % |  |  | 45 | % |  |  | 38 | % |
| Risk free interest rate |  |  | 4.19 | % |  |  | 3.64 | % |  |  | 1.54 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-25-004353:notes:255]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2024, 2023 and 2022 is as follows:

[0001437749-25-004353:notes:256]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2021 |  |  | 1,342,131 |  |  |  | 64.29 |  |  |  | 5.5 |  |  | $ | 386,069 |  |
| Granted |  |  | 109,266 |  |  |  | 282.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (137,305 | ) |  |  | 36.91 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (45,688 | ) |  |  | 194.05 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2022 |  |  | 1,268,404 |  |  |  | 81.35 |  |  |  | 4.9 |  |  | $ | 47,764 |  |
| Granted |  |  | 208,392 |  |  |  | 119.31 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (159,316 | ) |  |  | 42.46 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (33,144 | ) |  |  | 185.81 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2023 |  |  | 1,284,336 |  |  |  | 89.64 |  |  |  | 5.0 |  |  | $ | 75,587 |  |
| Granted |  |  | 118,681 |  |  |  | 112.66 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (310,201 | ) |  |  | 57.20 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (63,265 | ) |  |  | 152.06 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2024 |  |  | 1,029,551 |  |  |  | 96.10 |  |  |  | 4.9 |  |  | $ | 78,310 |  |
| Exercisable as of December 31, 2024 |  |  | 753,487 |  |  |  | 77.67 |  |  |  | 3.6 |  |  | $ | 69,273 |  |

[0001437749-25-004353:notes:257]
As of  December 31, 2024, there was $13,405 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.3 years. Total share-based compensation cost related to stock options for the years ended  December 31, 2024, 2023 and 2022 was $8,122, $8,229, and $6,911, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:258]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2022 awards covers the years 2022 through 2024. The performance period for the 2023 awards covers the years 2023 through 2025. The performance period for the 2024 awards covers the years 2024 through 2026. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's stock on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures and is trued up upon vesting based on actual forfeiture activity.

[0001437749-25-004353:notes:259]
All restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 78,465, 50,577, and 92,008 for the years ended  December 31, 2024, 2023 and 2022, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $11,097, $6,002, and $26,834 for the years ended  December 31, 2024, 2023 and 2022, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-25-004353:notes:260]
A summary of the Company's restricted stock activity for the years ended  December 31, 2024, 2023 and 2022 is as follows:

[0001437749-25-004353:notes:261]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2021 |  |  | 365,965 |  |  | $ | 124.25 |  |
| Granted |  |  | 287,821 |  |  |  | 214.58 |  |
| Vested |  |  | (234,284 | ) |  |  | 83.52 |  |
| Forfeited |  |  | (41,204 | ) |  |  | 263.47 |  |
| Non-vested as of December 31, 2022 |  |  | 378,298 |  |  |  | 203.04 |  |
| Granted |  |  | 425,099 |  |  | $ | 117.62 |  |
| Vested |  |  | (133,222 | ) |  |  | 175.94 |  |
| Forfeited |  |  | (44,789 | ) |  |  | 213.80 |  |
| Non-vested as of December 31, 2023 |  |  | 625,386 |  |  |  | 153.01 |  |
| Granted |  |  | 503,937 |  |  | $ | 120.77 |  |
| Vested |  |  | (206,435 | ) |  |  | 177.28 |  |
| Forfeited |  |  | (115,135 | ) |  |  | 130.89 |  |
| Non-vested as of December 31, 2024 |  |  | 807,753 |  |  |  | 127.07 |  |

[0001437749-25-004353:notes:262]
As of
      December 31, 2024, there was
     $59,177 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of
     1.9 years. Total share-based compensation cost related to the restricted stock for the years ended
      December 31, 
     2024,
     2023 and
     2022, inclusive of performance shares, was
     $41,126,
     $27,263, and
     $22,570, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-25-004353:notes:263]
During
     2024,
     2023 and
     2022,
     14,814,
     16,174, and
     8,572 shares of stock, respectively, were granted to certain members of the Company’s Board as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company, or a triggering event occurs.
     8,484,
     8,832, and
     5,008 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board for the years
     2024,
     2023, and
     2022, respectively. Total share-based compensation cost for shares of stock granted to the Company's Board in 
     2024,
     2023 and
     2022 was
     $1,992,
     $1,846, and
     $1,886, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-004353:notes:264]
| 18. | Commitments and Contingencies |

[0001437749-25-004353:notes:265]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  December 31, 2024 and 2023 was approximately $165,432 and $158,028, respectively.

[0001437749-25-004353:notes:266]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-25-004353:notes:267]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-25-004353:notes:268]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. The court gave plaintiffs until  March 10, 2025, to file an amended complaint if they want to continue the lawsuit.

[0001437749-25-004353:notes:269]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-25-004353:notes:270]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.

[0001437749-25-004353:notes:271]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-25-004353:notes:272]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump-sum payment of $5,400 for past and future damages. On  December 27, 2023, the parties reached a global settlement at an incremental cost of $4,600 to resolve all remaining disputes between the parties, including the two remaining lawsuits. In 2023, the Company recorded a reserve of $10,000 related to this matter.

[0001437749-25-004353:notes:273]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023, jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-25-004353:notes:274]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics' purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

[0001437749-25-004353:notes:275]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-25-004353:notes:276]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-25-004353:notes:277]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies the allegations and intends to vigorously defend the matter.

[0001437749-25-004353:notes:278]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

[0001437749-25-004353:notes:279]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-25-004353:notes:280]
| 19. | Valuation and Qualifying Accounts |

[0001437749-25-004353:notes:281]
For the years ended  December 31, 2024, 2023 and 2022:

[0001437749-25-004353:notes:282]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 33,925 |  |  | $ | 4,524 |  |  | $ | (3,509 | ) |  | $ | 525 |  |  | $ | 35,465 |  |
| Reserves for inventory |  |  | 39,027 |  |  |  | 10,738 |  |  |  | (2,924 | ) |  |  | 1,332 |  |  |  | 48,173 |  |
| Valuation of deferred tax assets |  |  | 5,136 |  |  |  | 447 |  |  |  | (358 | ) |  |  | - |  |  |  | 5,225 |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 27,664 |  |  | $ | 7,443 |  |  | $ | (1,206 | ) |  | $ | 24 |  |  | $ | 33,925 |  |
| Reserves for inventory |  |  | 39,714 |  |  |  | 4,621 |  |  |  | (5,308 | ) |  |  | - |  |  |  | 39,027 |  |
| Valuation of deferred tax assets |  |  | 4,638 |  |  |  | 516 |  |  |  | (18 | ) |  |  | - |  |  |  | 5,136 |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,025 |  |  | $ | 17,966 |  |  | $ | (2,825 | ) |  | $ | 498 |  |  | $ | 27,664 |  |
| Reserves for inventory |  |  | 33,537 |  |  |  | 9,656 |  |  |  | (4,737 | ) |  |  | 1,258 |  |  |  | 39,714 |  |
| Valuation of deferred tax assets |  |  | 7,874 |  |  |  | 649 |  |  |  | (1,501 | ) |  |  | (2,384 | ) |  |  | 4,638 |  |

[0001437749-25-004353:notes:283]
|  | (1) | Deductions from the allowance for credit losses equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |
