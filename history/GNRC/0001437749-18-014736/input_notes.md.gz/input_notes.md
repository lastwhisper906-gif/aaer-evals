# GNRC notes — 0001437749-18-014736


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-18-014736:notes:1]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 22,080 |  |  | $ | 20,576 |  |
| Long-term portion - other long-term liabilities |  |  | 16,580 |  |  |  | 14,846 |  |
| Total |  | $ | 38,660 |  |  | $ | 35,422 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 12,447 |  |  | $ | 11,017 |  |
| Long-term portion - other long-term liabilities |  |  | 50,560 |  |  |  | 46,837 |  |
| Total |  | $ | 63,007 |  |  | $ | 57,854 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-18-014736:notes:2]
4

[0001437749-18-014736:notes:3]
[same as prior period, unchanged from 0001437749-18-008863:notes:3]

[0001437749-18-014736:notes:4]
[same as prior period, unchanged from 0001437749-18-008863:notes:4]

[0001437749-18-014736:notes:5]
[same as prior period, unchanged from 0001437749-18-008863:notes:5]

[0001437749-18-014736:notes:6]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253
 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell his interest to the Company any time within 
five
 years from the date of acquisition. Within the 
first

[0001437749-18-014736:notes:7]
[same as prior period, unchanged from 0001437749-18-008863:notes:7]

[0001437749-18-014736:notes:8]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
13,
 “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-18-014736:notes:9]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 54,404 |  |  | $ | 33,566 |  |  | $ | 43,929 |  |  | $ | 33,138 |  |
| Net income |  |  | 848 |  |  |  | 92 |  |  |  | 822 |  |  |  | 210 |  |
| Foreign currency translation |  |  | (4,522 | ) |  |  | 4,433 |  |  |  | (1,686 | ) |  |  | 5,357 |  |
| Redemption value adjustment |  |  | 2,305 |  |  |  | (295 | ) |  |  | 9,970 |  |  |  | (909 | ) |
| Balance at end of period |  | $ | 53,035 |  |  | $ | 37,796 |  |  | $ | 53,035 |  |  | $ | 37,796 |  |

[0001437749-18-014736:notes:10]
The redemption value adjustments recorded during the 
three
 and 
six
 month periods ended 
 June 30, 2018 
relate to the adjustment required to reflect the redeemable noncontrolling interest value as a multiple of earnings after 
two
 years from the date of acquisition, in accordance with the terms of the acquisition.


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-18-014736:notes:11]
|  |  | June 30, 2018 |  |  | December 31, 2017 |  |
| Commodity contracts |  | $ | (200 | ) |  | $ | 107 |  |
| Foreign currency contracts |  |  | (55 | ) |  |  | 167 |  |
| Interest rate swaps |  |  | 16,217 |  |  |  | 4,356 |  |


## gnrc:ScheduleOfRecognitionOfDeferredRevenueRelatedToExtendedWarrantiesTableTextBlock

[0001437749-18-014736:notes:12]
| Remainder of 2018 |  | $ | 6,125 |  |
| 2019 |  |  | 12,682 |  |
| 2020 |  |  | 11,750 |  |
| 2021 |  |  | 9,849 |  |
| 2022 |  |  | 7,711 |  |
| After 2022 |  |  | 14,890 |  |
| Total |  | $ | 63,007 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-18-014736:notes:13]
3.
 Selmec Acquisition

[0001437749-18-014736:notes:14]
On 
 June 1, 2018, 
the Company acquired Selmec for a purchase price of 
$78,307,
 net of cash acquired and inclusive of estimated earnout payments of 
$6,750.
 Headquartered in Mexico City, Mexico, Selmec is a designer and manufacturer of industrial generators ranging from 
10kW
 to 
2,750kW.
 Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. The acquisition purchase price was funded solely through cash on hand.

[0001437749-18-014736:notes:15]
The Company recorded a preliminary purchase price allocation during the 
second
 quarter of 
2018
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$76,504
 of intangible assets, including approximately 
$38,538
 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is 
not
 deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Selmec from the date of acquisition through 
 June 30, 2018.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-18-014736:notes:16]
[same as prior period, unchanged from 0001437749-18-008863:notes:13]

[0001437749-18-014736:notes:17]
[same as prior period, unchanged from 0001437749-18-008863:notes:14]

[0001437749-18-014736:notes:18]
[same as prior period, unchanged from 0001437749-18-008863:notes:15]

[0001437749-18-014736:notes:19]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-014736:notes:20]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of its Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:

[0001437749-18-014736:notes:21]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |

[0001437749-18-014736:notes:22]
[same as prior period, unchanged from 0001437749-18-008863:notes:18]

[0001437749-18-014736:notes:23]
[same as prior period, unchanged from 0001437749-18-008863:notes:19]

[0001437749-18-014736:notes:24]
The condensed consolidated balance sheets as of 
 June 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-18-014736:notes:25]
[same as prior period, unchanged from 0001437749-18-008863:notes:21]

[0001437749-18-014736:notes:26]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.

[0001437749-18-014736:notes:27]
[same as prior period, unchanged from 0001437749-18-008863:notes:23]

[0001437749-18-014736:notes:28]
[same as prior period, unchanged from 0001437749-18-008863:notes:24]

[0001437749-18-014736:notes:29]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,

[0001437749-18-014736:notes:30]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-014736:notes:31]
[same as prior period, unchanged from 0001437749-18-008863:notes:27]

[0001437749-18-014736:notes:32]
Derivatives and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-014736:notes:33]
[same as prior period, unchanged from 0001437749-18-008863:notes:31]

[0001437749-18-014736:notes:34]
[same as prior period, unchanged from 0001437749-18-008863:notes:32]

[0001437749-18-014736:notes:35]
[same as prior period, unchanged from 0001437749-18-008863:notes:33]

[0001437749-18-014736:notes:36]
[same as prior period, unchanged from 0001437749-18-008863:notes:34]

[0001437749-18-014736:notes:37]
[same as prior period, unchanged from 0001437749-18-008863:notes:35]

[0001437749-18-014736:notes:38]
[same as prior period, unchanged from 0001437749-18-008863:notes:36]

[0001437749-18-014736:notes:39]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The adoption of this new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

[0001437749-18-014736:notes:40]
[same as prior period, unchanged from 0001437749-18-008863:notes:38]

[0001437749-18-014736:notes:41]
[same as prior period, unchanged from 0001437749-18-008863:notes:39]

[0001437749-18-014736:notes:42]
[same as prior period, unchanged from 0001437749-18-008863:notes:40]

[0001437749-18-014736:notes:43]
[same as prior period, unchanged from 0001437749-18-008863:notes:41]

[0001437749-18-014736:notes:44]
[same as prior period, unchanged from 0001437749-18-008863:notes:42]

[0001437749-18-014736:notes:45]
| Condensed Consolidated Balance Sheets |  | June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 243,285 |  |  | $ | (3,143 | ) |  | $ | 240,142 |  |
| Inventories |  |  | 378,110 |  |  |  | 6,081 |  |  |  | 384,191 |  |
| Other accrued liabilities |  |  | 93,343 |  |  |  | 5,253 |  |  |  | 98,596 |  |
| Deferred income taxes |  |  | 37,575 |  |  |  | (3,190 | ) |  |  | 34,385 |  |
| Other long-term liabilities |  |  | 66,633 |  |  |  | 5,844 |  |  |  | 72,477 |  |
| Retained earnings |  | $ | 495,463 |  |  | $ | (4,969 | ) |  | $ | 490,494 |  |

[0001437749-18-014736:notes:46]
|  |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |

[0001437749-18-014736:notes:47]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 395,376 |  |  | $ | (501 | ) |  | $ | 394,875 |  |
| Cost of goods sold |  |  | 260,916 |  |  |  | 1,038 |  |  |  | 261,954 |  |
| Selling and service expenses |  |  | 43,116 |  |  |  | (1,106 | ) |  |  | 42,010 |  |
| Research and development expenses |  |  | 10,567 |  |  |  | (14 | ) |  |  | 10,553 |  |
| General and administrative expenses |  |  | 21,361 |  |  |  | 46 |  |  |  | 21,407 |  |
| Other, net |  |  | 1,437 |  |  |  | 140 |  |  |  | 1,577 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | (236 | ) |  |  | 13,878 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | (369 | ) |  | $ | 25,291 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | (0.01 | ) |  | $ | 0.41 |  |
| Diluted |  | $ | 0.41 |  |  | $ | - |  |  | $ | 0.41 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 32,577 |  |  | $ | (369 | ) |  | $ | 32,208 |  |

[0001437749-18-014736:notes:48]
|  |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 727,190 |  |  | $ | (1,830 | ) |  | $ | 725,360 |  |
| Cost of goods sold |  |  | 482,244 |  |  |  | 1,395 |  |  |  | 483,639 |  |
| Selling and service expenses |  |  | 83,300 |  |  |  | (1,823 | ) |  |  | 81,477 |  |
| Research and development expenses |  |  | 20,868 |  |  |  | (28 | ) |  |  | 20,840 |  |
| General and administrative expenses |  |  | 42,334 |  |  |  | 46 |  |  |  | 42,380 |  |
| Other, net |  |  | 1,214 |  |  |  | 280 |  |  |  | 1,494 |  |
| Provision for income taxes |  |  | 22,365 |  |  |  | (664 | ) |  |  | 21,701 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 38,502 |  |  | $ | (1,036 | ) |  | $ | 37,466 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | (0.01 | ) |  | $ | 0.62 |  |
| Diluted |  | $ | 0.63 |  |  | $ | (0.02 | ) |  | $ | 0.61 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 48,964 |  |  | $ | (1,036 | ) |  | $ | 47,928 |  |

[0001437749-18-014736:notes:49]
| Condensed Consolidated Statement of Cash Flows |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 38,594 |  |  | $ | (1,036 | ) |  | $ | 37,558 |  |
| Deferred income taxes |  |  | 17,164 |  |  |  | (664 | ) |  |  | 16,500 |  |
| Accounts receivable |  |  | 5,362 |  |  |  | (2,858 | ) |  |  | 2,504 |  |
| Inventories |  |  | (13,981 | ) |  |  | 5,745 |  |  |  | (8,236 | ) |
| Other accrued liabilities |  |  | (559 | ) |  |  | (2,585 | ) |  |  | (3,144 | ) |
| Net cash provided by operating activities |  | $ | 55,674 |  |  | $ | (1,398 | ) |  | $ | 54,276 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 1,398 |  |  | $ | 1,398 |  |
| Net cash used in investing activities |  | $ | (8,825 | ) |  | $ | 1,398 |  |  | $ | (7,427 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-18-014736:notes:50]
1

[0001437749-18-014736:notes:51]
5

[0001437749-18-014736:notes:52]
. Commitments and

[0001437749-18-014736:notes:53]
Contingencies

[0001437749-18-014736:notes:54]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2018 
and 
 December 31, 2017 
was approximately 
$36,200
 and 
$36,500,
 respectively.

[0001437749-18-014736:notes:55]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-18-014736:notes:56]
7

[0001437749-18-014736:notes:57]
[same as prior period, unchanged from 0001437749-18-008863:notes:54]

[0001437749-18-014736:notes:58]
[same as prior period, unchanged from 0001437749-18-008863:notes:55]

[0001437749-18-014736:notes:59]
The following presents a tabular disclosure of changes in AOCL during the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
2017,
 net of tax:

[0001437749-18-014736:notes:60]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2018 |  | $ | (6,677 | ) |  | $ | (10,978 | ) |  | $ | 9,283 |  |  | $ | (8,372 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (10,658 | ) |  |  | - |  |  |  | 2,130 | (1) |  |  | (8,528 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (10,658 | ) |  |  | - |  |  |  | 2,130 |  |  |  | (8,528 | ) |
| Ending Balance – June 30, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  | $ | (16,900 | ) |

[0001437749-18-014736:notes:61]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2017 |  | $ | (24,447 | ) |  | $ | (11,040 | ) |  | $ | (636 | ) |  | $ | (36,123 | ) |
| Other comprehensive income before reclassifications |  |  | 8,590 |  |  |  | - |  |  |  | 324 | (2) |  |  | 8,914 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 8,590 |  |  |  | - |  |  |  | 324 |  |  |  | 8,914 |  |
| Ending Balance – June 30, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  | $ | (27,209 | ) |

[0001437749-18-014736:notes:62]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (4,479 | ) |  |  | - |  |  |  | 8,777 | (3) |  |  | 4,298 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (4,479 | ) |  |  | - |  |  |  | 8,777 |  |  |  | 4,298 |  |
| Ending Balance – June 30, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  | $ | (16,900 | ) |

[0001437749-18-014736:notes:63]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 12,190 |  |  |  | - |  |  |  | 764 | (4) |  |  | 12,954 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 12,190 |  |  |  | - |  |  |  | 764 |  |  |  | 12,954 |  |
| Ending Balance – June 30, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  | $ | (27,209 | ) |

[0001437749-18-014736:notes:64]
|  | (1) | Represents unrealized gains of $2,878, net of tax effect of $(748), for the three months ended June 30, 2018. |

[0001437749-18-014736:notes:65]
|  | (2) | Represents unrealized gains of $531, net of tax effect of $(207), for the three months ended June 30, 2017. |

[0001437749-18-014736:notes:66]
|  | (3) | Represents unrealized gains of $11,860, net of tax effect of $(3,083), for the six months ended June 30, 2018. |

[0001437749-18-014736:notes:67]
|  | (4) | Represents unrealized gains of $1,254, net of tax effect of $(490), for the six months ended June 30, 2017. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-014736:notes:68]
11

[0001437749-18-014736:notes:69]
. Credit Agreements

[0001437749-18-014736:notes:70]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-014736:notes:71]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,995 |  |  |  | 20,602 |  |
| Total |  | $ | 23,995 |  |  | $ | 20,602 |  |

[0001437749-18-014736:notes:72]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-014736:notes:73]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (24,682 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,251 |  |  |  | 4,690 |  |
| Other |  |  | 869 |  |  |  | 1,367 |  |
| Total |  |  | 909,438 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 758 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 614 |  |  |  | 636 |  |
| Total |  | $ | 908,066 |  |  | $ | 906,548 |  |

[0001437749-18-014736:notes:74]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023

[0001437749-18-014736:notes:75]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans was reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, fell below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-18-014736:notes:76]
In 
 May 2017, 
the Company amended the Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing, however, is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2017.

[0001437749-18-014736:notes:77]
In 
 December 2017, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminated future related payment requirements if the Company’s secured leverage ratio was maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in the 
fourth
 quarter of 
2017.

[0001437749-18-014736:notes:78]
In 
 June 2018, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$829
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2018.

[0001437749-18-014736:notes:79]
As of 
 June 30, 2018, 
the Company’s secured leverage ratio was 
2.11
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-18-014736:notes:80]
The Company’s credit agreements also originally provided for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility), with a maturity date of 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings originally bore interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-18-014736:notes:81]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$615
 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

[0001437749-18-014736:notes:82]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of 
 June 30, 2018, 
there was 
$50,000
 outstanding under the Amended ABL Facility, leaving 
$192,217
 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-18-014736:notes:83]
As of 
 June 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$23,995
 and 
$20,602,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-18-014736:notes:84]
[same as prior period, unchanged from 0001437749-18-008863:notes:74]

[0001437749-18-014736:notes:85]
[same as prior period, unchanged from 0001437749-18-008863:notes:75]

[0001437749-18-014736:notes:86]
[same as prior period, unchanged from 0001437749-18-008863:notes:76]

[0001437749-18-014736:notes:87]
[same as prior period, unchanged from 0001437749-18-008863:notes:77]

[0001437749-18-014736:notes:88]
[same as prior period, unchanged from 0001437749-18-008863:notes:78]

[0001437749-18-014736:notes:89]
The Company is exposed to price fluctuations in commodities it uses as raw materials, primarily steel, copper and aluminum, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than 
eighteen
 months. At 
 June 30, 2018,

[0001437749-18-014736:notes:90]
December 31, 2017 
and 
 June 30, 2017, 
the Company had five, 
one
 and 
one
 commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-18-014736:notes:91]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax losses recognized for the 
three
 and 
six
 months ended 
 June 30, 2018 
were 
$47
 and 
$203,
 respectively. Net pre-tax gains recognized for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$2
 and 
$185,
 respectively.

[0001437749-18-014736:notes:92]
[same as prior period, unchanged from 0001437749-18-008863:notes:84]

[0001437749-18-014736:notes:93]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 June 30, 2018,

[0001437749-18-014736:notes:94]
December 31, 2017 
and 
 June 30, 2017, 
the Company had 
twenty
-eight, 
twenty-eight
 and 
eighteen
 foreign currency contracts outstanding, respectively.

[0001437749-18-014736:notes:95]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in other, net in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax losses recognized for the 
three
 and 
six
 months ended 
 June 30, 2018 
were 
$545
 and 
$318,
 respectively. Net pre-tax gains recognized for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$380
 and 
$179,
 respectively.

[0001437749-18-014736:notes:96]
[same as prior period, unchanged from 0001437749-18-008863:notes:89]

[0001437749-18-014736:notes:97]
In 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements. In 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement, and in 
2017,
 the Company entered into 
20
 additional interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains, net of tax, recognized for the 
three
 and 
six
 months ended 
 June 30, 2018 
were 
$2,130
 and 
$8,777,
 respectively. The amount of gains, net of tax, recognized for the 
three
 and 
six
 months ended 
 June 30, 2017 
were 
$324
 and 
$764,
 respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-18-014736:notes:98]
[same as prior period, unchanged from 0001437749-18-008863:notes:91]

[0001437749-18-014736:notes:99]
[same as prior period, unchanged from 0001437749-18-008863:notes:92]

[0001437749-18-014736:notes:100]
The fair values of the commodity contracts and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheet as of 
 June 30, 2018. 
The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair value of the interest rate swaps is included in other assets in the consolidated balance sheet as of 
 December 31, 2017. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 June 30, 2018 
and 
 December 31, 2017 
is an asset of 
$16,236
 and 
$4,703,
 respectively, which represents the amount the Company would receive upon exit of the agreements on those dates.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-18-014736:notes:101]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 26,395 |  |  |  | 6,528 |  |  |  | 32,923 |  |
| Total net sales |  | $ | 381,047 |  |  | $ | 113,902 |  |  | $ | 494,949 |  |

[0001437749-18-014736:notes:102]
|  |  | Three Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 185,114 |  |  | $ | 13,354 |  |  | $ | 198,468 |  |
| Commercial & industrial products |  |  | 98,909 |  |  |  | 70,994 |  |  |  | 169,903 |  |
| Other |  |  | 21,383 |  |  |  | 5,121 |  |  |  | 26,504 |  |
| Total net sales |  | $ | 305,406 |  |  | $ | 89,469 |  |  | $ | 394,875 |  |

[0001437749-18-014736:notes:103]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 52,158 |  |  |  | 12,800 |  |  |  | 64,958 |  |
| Total net sales |  | $ | 681,266 |  |  | $ | 211,317 |  |  | $ | 892,583 |  |

[0001437749-18-014736:notes:104]
|  |  | Six Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 326,815 |  |  | $ | 25,870 |  |  | $ | 352,685 |  |
| Commercial & industrial products |  |  | 183,674 |  |  |  | 136,982 |  |  |  | 320,656 |  |
| Other |  |  | 42,085 |  |  |  | 9,934 |  |  |  | 52,019 |  |
| Total net sales |  | $ | 552,574 |  |  | $ | 172,786 |  |  | $ | 725,360 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-014736:notes:105]
3

[0001437749-18-014736:notes:106]
[same as prior period, unchanged from 0001437749-18-008863:notes:95]

[0001437749-18-014736:notes:107]
[same as prior period, unchanged from 0001437749-18-008863:notes:96]

[0001437749-18-014736:notes:108]
[same as prior period, unchanged from 0001437749-18-008863:notes:97]

[0001437749-18-014736:notes:109]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (2,305 | ) |  |  | 295 |  |  |  | (9,970 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 50,956 |  |  | $ | 25,586 |  |  | $ | 76,936 |  |  | $ | 38,375 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,534,423 |  |  |  | 62,146,393 |  |  |  | 61,696,014 |  |  |  | 62,260,170 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 520,024 |  |  |  | 489,044 |  |  |  | 563,698 |  |  |  | 589,707 |  |
| Diluted shares |  |  | 62,054,447 |  |  |  | 62,635,437 |  |  |  | 62,259,712 |  |  |  | 62,849,877 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 1.25 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.82 |  |  | $ | 0.41 |  |  | $ | 1.24 |  |  | $ | 0.61 |  |

[0001437749-18-014736:notes:110]
(
1
) Excludes approximately 
142,600
 and 
279,200
 stock options for the 
three
 months ended 
 June 30, 2018 
and 
2017,
 respectively, as the impact of such awards was anti-dilutive. Excludes approximately 
81,800
 and 
193,200
 stock options for the 
six
 months ended 
 June 30, 2018 
and 
2017,
 respectively, as the impact of such awards was anti-dilutive. Excludes approximately 
7,000
 shares of restricted stock for the 
three
 months ended 
 June 30, 2017, 
as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-014736:notes:111]
6

[0001437749-18-014736:notes:112]
[same as prior period, unchanged from 0001437749-18-008863:notes:101]

[0001437749-18-014736:notes:113]
[same as prior period, unchanged from 0001437749-18-008863:notes:102]

[0001437749-18-014736:notes:114]
[same as prior period, unchanged from 0001437749-18-008863:notes:103]

[0001437749-18-014736:notes:115]
[same as prior period, unchanged from 0001437749-18-008863:notes:104]

[0001437749-18-014736:notes:116]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$855,617,
 was approximately 
$856,130
 (Level 
2
) at 
 June 30, 2018, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-18-014736:notes:117]
For the fair value of the derivatives measured on a recurring basis, see the fair value table in Note 
5,
 “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 
820
-
10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-014736:notes:118]
[same as prior period, unchanged from 0001437749-18-008863:notes:107]

[0001437749-18-014736:notes:119]
The effective income tax rates for the 
six
 months ended 
 June 30, 2018 
and 
2017
 were 
25.3%
 and 
36.7%,
 respectively. The decrease in the effective income tax rate in 
2018
 was primarily due to a reduction of the U.S. federal corporate tax rate as a result of the Tax Cuts and Jobs Act (Tax Act) enacted on 
 December 22, 2017.

[0001437749-18-014736:notes:120]
The SEC staff issued Staff Legal Bulletin 
118
 (SAB 
118
), which provides guidance on accounting for the tax effects of the Tax Act. SAB 
118
 provides a measurement period that should 
not
 extend beyond 
one
 year from the Tax Act enactment date for companies to complete the accounting under ASC 
740.
 In accordance with SAB 
118,
 a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 
740
 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 
740
 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. The Company's accounting for certain elements of the Tax Act is incomplete. However, reasonable estimates of certain effects were able to be made and, therefore, provisional adjustments were recorded in the Company’s financial statements as of, and for the period ended, 
 December 31, 2017. 
There were 
no
 significant adjustments recorded during the 
six
 months ended 
 June 30, 2018 
related to provisional amounts recorded in 
2017
 as a result of the Tax Act. For further discussion on the impact of the Tax Act, see Item 
8
 (Note 
13
 “Income Taxes”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-18-014736:notes:121]
10

[0001437749-18-014736:notes:122]
[same as prior period, unchanged from 0001437749-18-008863:notes:111]

[0001437749-18-014736:notes:123]
[same as prior period, unchanged from 0001437749-18-008863:notes:112]

[0001437749-18-014736:notes:124]
[same as prior period, unchanged from 0001437749-18-008863:notes:113]

[0001437749-18-014736:notes:125]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 36,319 |  |  | $ | 32,008 |  |  | $ | 35,422 |  |  | $ | 31,695 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 43 |  |
| Payments |  |  | (4,907 | ) |  |  | (4,285 | ) |  |  | (9,892 | ) |  |  | (8,845 | ) |
| Provision for warranty issued |  |  | 6,275 |  |  |  | 4,086 |  |  |  | 11,478 |  |  |  | 8,246 |  |
| Changes in estimates for pre-existing warranties |  |  | 973 |  |  |  | 1,004 |  |  |  | 1,652 |  |  |  | 1,674 |  |
| Balance at end of period |  | $ | 38,660 |  |  | $ | 32,813 |  |  | $ | 38,660 |  |  | $ | 32,813 |  |

[0001437749-18-014736:notes:126]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of 
five
 to 
ten
 years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to selling and service expenses on the condensed consolidated statements of comprehensive income as an offset to warranty expense. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-18-014736:notes:127]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 60,113 |  |  | $ | 37,562 |  |  | $ | 57,854 |  |  | $ | 36,139 |  |
| Deferred revenue contracts issued |  |  | 5,526 |  |  |  | 7,442 |  |  |  | 10,242 |  |  |  | 10,463 |  |
| Amortization of deferred revenue contracts |  |  | (2,632 | ) |  |  | (1,648 | ) |  |  | (5,089 | ) |  |  | (3,246 | ) |
| Balance at end of period |  | $ | 63,007 |  |  | $ | 43,356 |  |  | $ | 63,007 |  |  | $ | 43,356 |  |

[0001437749-18-014736:notes:128]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at 
 June 30, 2018 
is as follows:

[0001437749-18-014736:notes:129]
In the 
second
 quarter of 
2017,
 the Company launched a post-sale extended warranty marketing program. In the program’s agreement, the Company is required to pay fees to a 
third
-party service provider based on the number of extended warranty contracts sold, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the condensed consolidated balance sheets. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. The balance of deferred contract costs as of 
 June 30, 2018 
and 
2017
 was 
$4,183
 and 
$798,
 respectively. Amortization of deferred contract costs recorded during the 
six
 months ended 
 June 30, 2018 
was 
$277.

[0001437749-18-014736:notes:130]
[same as prior period, unchanged from 0001437749-18-008863:notes:119]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-18-014736:notes:131]
|  |  | June 30, 2018 |  |  | December 31, 2017 |  |
| Land and improvements |  | $ | 13,274 |  |  | $ | 13,118 |  |
| Buildings and improvements |  |  | 140,663 |  |  |  | 132,072 |  |
| Machinery and equipment |  |  | 94,861 |  |  |  | 90,487 |  |
| Dies and tools |  |  | 26,475 |  |  |  | 24,504 |  |
| Vehicles |  |  | 1,804 |  |  |  | 1,878 |  |
| Office equipment and systems |  |  | 79,316 |  |  |  | 73,254 |  |
| Leasehold improvements |  |  | 2,356 |  |  |  | 2,436 |  |
| Construction in progress |  |  | 10,505 |  |  |  | 18,799 |  |
| Gross property and equipment |  |  | 369,254 |  |  |  | 356,548 |  |
| Accumulated depreciation |  |  | (135,821 | ) |  |  | (126,168 | ) |
| Total |  | $ | 233,433 |  |  | $ | 230,380 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-18-014736:notes:132]
[same as prior period, unchanged from 0001437749-18-008863:notes:121]

[0001437749-18-014736:notes:133]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company’s contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

[0001437749-18-014736:notes:134]
At the request of certain customers, the Company will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-18-014736:notes:135]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$20,643
 and 
$7,034
 at 
 June 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
six
 month period ended 
 June 30, 2018, 
the Company recognized revenue of 
$5,812
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

[0001437749-18-014736:notes:136]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-18-014736:notes:137]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
-party marketing agreement, it is required to pay fees to the 
third
-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheets. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-18-014736:notes:138]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue.

[0001437749-18-014736:notes:139]
Refer to Note 
8,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-18-014736:notes:140]
|  |  | June 30, 2018 |  |  | December 31, 2017 |  |
| Raw material |  | $ | 286,528 |  |  | $ | 242,947 |  |
| Work-in-process |  |  | 6,034 |  |  |  | 2,544 |  |
| Finished goods |  |  | 187,318 |  |  |  | 141,558 |  |
| Total |  | $ | 479,880 |  |  | $ | 387,049 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-014736:notes:141]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 90,602 |  |  | $ | 63,692 |  |  | $ | 156,077 |  |  | $ | 105,583 |  |
| International |  |  | 11,628 |  |  |  | 6,034 |  |  |  | 17,934 |  |  |  | 10,846 |  |
| Total adjusted EBITDA |  | $ | 102,230 |  |  | $ | 69,726 |  |  | $ | 174,011 |  |  | $ | 116,429 |  |
| Interest expense |  |  | (11,002 | ) |  |  | (10,893 | ) |  |  | (21,115 | ) |  |  | (21,681 | ) |
| Depreciation and amortization |  |  | (11,600 | ) |  |  | (12,986 | ) |  |  | (23,283 | ) |  |  | (25,583 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,316 | ) |  |  | (1,710 | ) |  |  | (2,622 | ) |  |  | (1,876 | ) |
| Non-cash share-based compensation expense (2) |  |  | (3,885 | ) |  |  | (3,186 | ) |  |  | (6,991 | ) |  |  | (5,818 | ) |
| Loss on extinguishment of debt (3) |  |  | (1,332 | ) |  |  | - |  |  |  | (1,332 | ) |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | (441 | ) |  |  | (420 | ) |  |  | (703 | ) |  |  | (736 | ) |
| Business optimization expenses (5) |  |  | (29 | ) |  |  | (1,346 | ) |  |  | (167 | ) |  |  | (1,446 | ) |
| Other |  |  | (12 | ) |  |  | 69 |  |  |  | 1 |  |  |  | (30 | ) |
| Income before provision for income taxes |  | $ | 72,613 |  |  | $ | 39,254 |  |  | $ | 117,799 |  |  | $ | 59,259 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-014736:notes:142]
8

[0001437749-18-014736:notes:143]
[same as prior period, unchanged from 0001437749-18-008863:notes:134]

[0001437749-18-014736:notes:144]
The Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-18-014736:notes:145]
The Company's product offerings consist primarily of power generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial (C&I) products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-18-014736:notes:146]
Residential products consist primarily of automatic standby generators ranging in output from 
6kW
 to 
60kW,
 portable generators, power washers and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical and HVAC wholesalers and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-18-014736:notes:147]
C&I products consist of larger output stationary generators fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 
10kW
 up to 
3,250kW.
 Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution channels, which in turn sell the product to the end consumer, including installation and maintenance services. In some cases, C&I products are sold direct to the end consumer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-18-014736:notes:148]
Other products consist primarily of aftermarket service parts sold to our dealers, product accessories and proprietary engines sold to 
third
-party original equipment manufacturers. Substantially all of the Other products revenues are transferred to the customer at a point in time.

[0001437749-18-014736:notes:149]
[same as prior period, unchanged from 0001437749-18-008863:notes:139]

[0001437749-18-014736:notes:150]
[same as prior period, unchanged from 0001437749-18-008863:notes:140]

[0001437749-18-014736:notes:151]
[same as prior period, unchanged from 0001437749-18-008863:notes:141]

[0001437749-18-014736:notes:152]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |

[0001437749-18-014736:notes:153]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-18-014736:notes:154]
|  | (5) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-18-014736:notes:155]
The Company’s sales in the United States represented approximately 
73%
 of total sales for the 
three
 month periods ended 
 June 30, 2018 
and 
2017,
 and represented approximately 
72%
 of total sales for the 
six
 month periods ended 
 June 30, 2018 
and 
2017.
 Approximately 
85%
 of the Company’s identifiable long-lived assets were located in the United States at 
 June 30, 2018 
and 
 December 31, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-18-014736:notes:156]
9

[0001437749-18-014736:notes:157]
[same as prior period, unchanged from 0001437749-18-008863:notes:146]

[0001437749-18-014736:notes:158]
[same as prior period, unchanged from 0001437749-18-008863:notes:147]

[0001437749-18-014736:notes:159]
[same as prior period, unchanged from 0001437749-18-008863:notes:148]

[0001437749-18-014736:notes:160]
[same as prior period, unchanged from 0001437749-18-008863:notes:149]


## us-gaap:TreasuryStockTextBlock

[0001437749-18-014736:notes:161]
12

[0001437749-18-014736:notes:162]
[same as prior period, unchanged from 0001437749-18-008863:notes:151]

[0001437749-18-014736:notes:163]
[same as prior period, unchanged from 0001437749-18-008863:notes:152]

[0001437749-18-014736:notes:164]
In 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the 
second
 program, the Company 
 may 
repurchase up to 
$250,000
 of its common stock over the 
24
 months following the date of approval. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
six
 months ended 
 June 30, 2018 
and 
2017,
 the Company repurchased 
560,000
 and 
844,500
 shares of its common stock, respectively, for 
$25,656
 and 
$30,012,
 respectively, all funded with cash on hand. Since the inception of both programs, the Company has repurchased 
8,676,706
 shares of its common stock for 
$305,547,
 all funded with cash on hand.
