# GNRC 8-K — 0001437749-18-014130 filed 2018-08-01

## item codes, every 8-K on or before 2018-08-07

- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2018-08-07

- none on or before 2018-08-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-014130:8k_2_02:1]
EX-99.1
2
ex_119479.htm
EXHIBIT 99.1

[0001437749-18-014130:8k_2_02:2]
ex_119479.htm

[0001437749-18-014130:8k_2_02:3]
Exhibit 99.1

[0001437749-18-014130:8k_2_02:4]
Generac Reports Second Quarter 2018 Results

[0001437749-18-014130:8k_2_02:5]
Record second quarter results driven by strong, broad-based demand and margin growth; Raising outlook for 2018

[0001437749-18-014130:8k_2_02:6]
WAUKESHA, WISCONSIN (August 1, 2018) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its second quarter ended June 30, 2018.

[0001437749-18-014130:8k_2_02:7]
Second Quarter 2018 Highlights

[0001437749-18-014130:8k_2_02:8]
| ● | Net sales increased 25.3% to $494.9 million during the second quarter of 2018 as compared to $394.9 million in the prior-year second quarter, including $4.0 million of contribution from the Selmec acquisition, which closed on June 1, 2018. Core sales growth, which excludes both the favorable impact of acquisitions and foreign currency, was approximately 23%. |

[0001437749-18-014130:8k_2_02:9]
| ● | Gross profit margin improved 190 basis points to 35.6% as compared to 33.7% in the second quarter of 2017. |

[0001437749-18-014130:8k_2_02:10]
| ● | Net income attributable to the Company during the second quarter was $53.3 million, or $0.82 per share, as compared to $25.3 million, or $0.41 per share, for the same period of 2017. |

[0001437749-18-014130:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $68.9 million, or $1.11 per share, as compared to $42.7 million, or $0.68 per share, in the second quarter of 2017. |

[0001437749-18-014130:8k_2_02:12]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $99.6 million as compared to $68.3 million in the second quarter last year. |

[0001437749-18-014130:8k_2_02:13]
| ● | Cash flow from operations was $50.7 million as compared to $59.5 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $45.9 million as compared to $53.7 million in the second quarter of 2017. |

[0001437749-18-014130:8k_2_02:14]
| ● | As a result of the continued strong demand for both residential and commercial & industrial (“C&I”) products, together with the closing of the Selmec acquisition, the Company is increasing its full-year 2018 sales growth guidance to approximately 13 to 14% with Adjusted EBITDA margins of approximately 20.0%. |

[0001437749-18-014130:8k_2_02:15]
“Our second quarter results further demonstrate the tremendous earnings power of Generac as solid execution across our entire business helped drive a 300 basis point expansion in EBITDA margins over the prior year,” said Aaron Jagdfeld, President and Chief Executive Officer. “We continue to see robust demand across all of our end markets and geographies, with particular strength coming from residential products as power outages over the last twelve months have been well above the long-term average. Global interest for our C&I mobile and stationary products has also been strong primarily driven by an increase in telecom, healthcare and other large projects, as well as the continued investment in fleet equipment by our rental account customers. Lastly, on June 1st, we closed on the acquisition of Selmec, further expanding our presence in the important Latin American backup power market.”

[0001437749-18-014130:8k_2_02:16]
Additional Second Quarter 2018 Consolidated Highlights

[0001437749-18-014130:8k_2_02:17]
Residential product sales increased 24.1% to $246.4 million as compared to $198.5 million in the prior year. C&I product sales increased 26.9% to $215.6 million as compared to $169.9 million in the prior year, with core sales growth of approximately 21%.

[0001437749-18-014130:8k_2_02:18]
Gross profit margin improved 190 basis points to 35.6% as compared to 33.7% in the prior-year second quarter. The increase reflected better leverage of fixed manufacturing costs on the significant increase in sales, a more favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-18-014130:8k_2_02:19]
Operating expenses increased $9.7 million, or 11.9%, as compared to the second quarter of 2017. The increase was primarily driven by higher variable operating expenses given the higher sales volumes, an increase in employee costs including additional incentive compensation, and increased International operating expenses given the stronger Euro. These items were partially offset by lower promotional costs as well as lower intangible amortization expense.

[0001437749-18-014130:8k_2_02:20]
Consolidated Adjusted EBITDA, before deducting for non-controlling interests, improved to $102.2 million, or 20.7% of net sales, as compared to $69.7 million, or 17.7% of net sales, in the prior year.

[0001437749-18-014130:8k_2_02:21]
Cash flow from operations was $50.7 million as compared to $59.5 million in the prior-year second quarter, and free cash flow was $45.9 million as compared to $53.7 million in the same quarter last year. The year-over-year decline in second quarter cash flow reflected increased working capital investment driven by organic sales growth and the replenishment of inventory levels in anticipation of the summer storm season.

[0001437749-18-014130:8k_2_02:22]
The current year earnings per share calculation of $0.82 includes the impact of a $2.3 million adjustment to increase the value of the redeemable noncontrolling interest for the Pramac acquisition, resulting in a $0.04 reduction in earnings per share. Under U.S. GAAP accounting rules, any adjustments to the redemption value are recorded directly to retained earnings. However, the redemption value adjustments are required to be reflected in the earnings per share calculation as detailed in the accompanying reconciliation schedules.

[0001437749-18-014130:8k_2_02:23]
On January 1, 2018, the Company adopted Accounting Standards Update 2014-09, Revenue from Contracts with Customers, and all related amendments, commonly known as the “new revenue recognition standard”. The full retrospective method was elected under this standard, which requires application to all periods presented. As a result, the prior-year 2017 results have been restated accordingly. However, the adoption of this standard did not have a material impact on the Company’s financial statements.

[0001437749-18-014130:8k_2_02:24]
Business Segment Results

[0001437749-18-014130:8k_2_02:25]
Domestic Segment

[0001437749-18-014130:8k_2_02:26]
Domestic segment sales increased 24.8% to $381.0 million as compared to $305.4 million in the prior-year quarter. The current-year quarter continued to experience strong growth in shipments of home standby and portable generators and also benefitted from robust C&I shipments driven by mobile products fleet replacement and strength in stationary generators through national accounts. Increased service part sales also contributed to the year-over-year growth.

[0001437749-18-014130:8k_2_02:27]
Adjusted EBITDA for the segment was $90.6 million, or 23.8% of net sales, as compared to $63.7 million in the prior year, or 20.9% of net sales. Adjusted EBITDA margin in the current year benefitted from improved overall operating leverage on the higher organic sales volumes, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs, including higher incentive compensation, and general inflationary pressures.

[0001437749-18-014130:8k_2_02:28]
International Segment

[0001437749-18-014130:8k_2_02:29]
International segment sales increased 27.3% to $113.9 million as compared to $89.5 million in the prior-year quarter, including $4.0 million of contribution from the Selmec acquisition. Core sales growth was approximately 16%, primarily due to broad-based growth of C&I products across Europe, Asia and Latin America.

[0001437749-18-014130:8k_2_02:30]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, improved to $11.6 million, or 10.2% of net sales, as compared to $6.0 million, or 6.7% of net sales, in the prior year. The improvement was primarily due to increased leverage of fixed operating costs on the higher organic sales and favorable mix. These favorable impacts were partially offset by higher commodity prices, along with the expansion of certain branch operations.

[0001437749-18-014130:8k_2_02:31]
Updated 2018 Outlook

[0001437749-18-014130:8k_2_02:32]
The Company is increasing its prior guidance for revenue growth for full-year 2018 due to improving end-market conditions and the closing of the Selmec acquisition. Full year net sales are now expected to grow between 13 to 14% over the prior year, which is an increase from the 6 to 8% growth previously expected. Core sales growth is expected to be approximately 10%, which is an increase from the 5 to 6% growth previously expected. This top-line guidance assumes no “major” outage events and a baseline power outage severity level similar to the longer-term average for the remainder of the year. Should the baseline power outage environment in 2018 be higher, or if there is a “major” event during the year, the Company could exceed these expectations.

[0001437749-18-014130:8k_2_02:33]
Given the increase in net sales guidance, net income margins, before deducting for non-controlling interests, are now expected to be approximately 10.5% for the full-year 2018, which is an increase from the 9.5 to 10.0% guidance previously expected. Adjusted EBITDA margins, also before deducting for non-controlling interests, are now expected to be approximately 20.0% for the year, up from the prior 19.0 to 19.5% guidance.

[0001437749-18-014130:8k_2_02:34]
Operating and free cash flow generation is expected to remain strong, with the conversion of adjusted net income to free cash flow still forecasted to be over 90%.

[0001437749-18-014130:8k_2_02:35]
Conference Call and Webcast

[0001437749-18-014130:8k_2_02:36]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, August 1, 2018 to discuss highlights of the second quarter of 2018 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 1768097.

[0001437749-18-014130:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-18-014130:8k_2_02:38]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 1768097. The telephonic replay will be available for 7 days.

[0001437749-18-014130:8k_2_02:39]
About Generac

[0001437749-18-014130:8k_2_02:40]
Founded in 1959, Generac is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-014130:8k_2_02:41]
Forward-looking Information

[0001437749-18-014130:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-18-014130:8k_2_02:43]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-18-014130:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-18-014130:8k_2_02:45]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing Generac products; |

[0001437749-18-014130:8k_2_02:46]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, and regulatory tariffs; |

[0001437749-18-014130:8k_2_02:47]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-18-014130:8k_2_02:48]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-18-014130:8k_2_02:49]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-18-014130:8k_2_02:50]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-18-014130:8k_2_02:51]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-18-014130:8k_2_02:52]
|  | ● | loss of key management and employees; |

[0001437749-18-014130:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-18-014130:8k_2_02:54]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-18-014130:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2017 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-18-014130:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-18-014130:8k_2_02:57]
Non-GAAP Financial Metrics

[0001437749-18-014130:8k_2_02:58]
Core Sales

[0001437749-18-014130:8k_2_02:59]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-18-014130:8k_2_02:60]
Adjusted EBITDA

[0001437749-18-014130:8k_2_02:61]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-18-014130:8k_2_02:62]
Adjusted Net Income

[0001437749-18-014130:8k_2_02:63]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-18-014130:8k_2_02:64]
Free Cash Flow

[0001437749-18-014130:8k_2_02:65]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-18-014130:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-18-014130:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-18-014130:8k_2_02:68]
CONTACT:

[0001437749-18-014130:8k_2_02:69]
York Ragen

[0001437749-18-014130:8k_2_02:70]
Chief Financial Officer

[0001437749-18-014130:8k_2_02:71]
(262) 506-6064

[0001437749-18-014130:8k_2_02:72]
InvestorRelations@generac.com

[0001437749-18-014130:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-014130:8k_2_02:74]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 111,714 |  |  | $ | 138,472 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 311,668 |  |  |  | 279,294 |  |
| Inventories |  |  | 479,880 |  |  |  | 387,049 |  |
| Prepaid expenses and other assets |  |  | 27,174 |  |  |  | 19,741 |  |
| Total current assets |  |  | 930,436 |  |  |  | 824,556 |  |
| Property and equipment, net |  |  | 233,433 |  |  |  | 230,380 |  |
| Customer lists, net |  |  | 69,772 |  |  |  | 41,064 |  |
| Patents, net |  |  | 34,770 |  |  |  | 39,617 |  |
| Other intangible assets, net |  |  | 3,370 |  |  |  | 2,401 |  |
| Tradenames, net |  |  | 154,495 |  |  |  | 152,683 |  |
| Goodwill |  |  | 758,072 |  |  |  | 721,523 |  |
| Deferred income taxes |  |  | 1,633 |  |  |  | 3,238 |  |
| Other assets |  |  | 23,294 |  |  |  | 10,502 |  |
| Total assets |  | $ | 2,209,275 |  |  | $ | 2,025,964 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 23,995 |  |  | $ | 20,602 |  |
| Accounts payable |  |  | 274,234 |  |  |  | 233,639 |  |
| Accrued wages and employee benefits |  |  | 32,820 |  |  |  | 27,992 |  |
| Other accrued liabilities |  |  | 147,628 |  |  |  | 112,618 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 1,372 |  |  |  | 1,572 |  |
| Total current liabilities |  |  | 480,049 |  |  |  | 396,423 |  |
| Long-term borrowings and capital lease obligations |  |  | 908,066 |  |  |  | 906,548 |  |
| Deferred income taxes |  |  | 57,506 |  |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 93,364 |  |  |  | 82,893 |  |
| Total liabilities |  |  | 1,538,985 |  |  |  | 1,427,716 |  |
| Redeemable noncontrolling interests |  |  | 53,035 |  |  |  | 43,929 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,030,347 and 70,820,173 shares issued at June 30, 2018 and December 31, 2017, respectively |  |  | 710 |  |  |  | 708 |  |
| Additional paid-in capital |  |  | 468,598 |  |  |  | 459,816 |  |
| Treasury stock, at cost |  |  | (321,052 | ) |  |  | (294,005 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 687,772 |  |  |  | 610,835 |  |
| Accumulated other comprehensive loss |  |  | (16,900 | ) |  |  | (21,198 | ) |
| Stockholders’ equity attributable to Generac Holdings, Inc. |  |  | 617,012 |  |  |  | 554,040 |  |
| Noncontrolling interests |  |  | 243 |  |  |  | 279 |  |
| Total stockholders' equity |  |  | 617,255 |  |  |  | 554,319 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,209,275 |  |  | $ | 2,025,964 |  |

[0001437749-18-014130:8k_2_02:75]
6

[0001437749-18-014130:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-014130:8k_2_02:77]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 892,583 |  |  | $ | 725,360 |  |
| Costs of goods sold |  |  | 318,693 |  |  |  | 261,954 |  |  |  | 576,338 |  |  |  | 483,639 |  |
| Gross profit |  |  | 176,256 |  |  |  | 132,921 |  |  |  | 316,245 |  |  |  | 241,721 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 46,052 |  |  |  | 42,010 |  |  |  | 88,734 |  |  |  | 81,477 |  |
| Research and development |  |  | 12,616 |  |  |  | 10,553 |  |  |  | 24,469 |  |  |  | 20,840 |  |
| General and administrative |  |  | 26,639 |  |  |  | 21,407 |  |  |  | 50,114 |  |  |  | 42,380 |  |
| Amortization of intangibles |  |  | 5,482 |  |  |  | 7,129 |  |  |  | 11,114 |  |  |  | 14,312 |  |
| Total operating expenses |  |  | 90,789 |  |  |  | 81,099 |  |  |  | 174,431 |  |  |  | 159,009 |  |
| Income from operations |  |  | 85,467 |  |  |  | 51,822 |  |  |  | 141,814 |  |  |  | 82,712 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,002 | ) |  |  | (10,893 | ) |  |  | (21,115 | ) |  |  | (21,681 | ) |
| Investment income |  |  | 367 |  |  |  | 38 |  |  |  | 713 |  |  |  | 43 |  |
| Loss on extinguishment of debt |  |  | (1,332 | ) |  |  | – |  |  |  | (1,332 | ) |  |  | – |  |
| Costs related to acquisition |  |  | (26 | ) |  |  | (136 | ) |  |  | (37 | ) |  |  | (321 | ) |
| Other, net |  |  | (861 | ) |  |  | (1,577 | ) |  |  | (2,244 | ) |  |  | (1,494 | ) |
| Total other expense, net |  |  | (12,854 | ) |  |  | (12,568 | ) |  |  | (24,015 | ) |  |  | (23,453 | ) |
| Income before provision for income taxes |  |  | 72,613 |  |  |  | 39,254 |  |  |  | 117,799 |  |  |  | 59,259 |  |
| Provision for income taxes |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 29,798 |  |  |  | 21,701 |  |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 88,001 |  |  |  | 37,558 |  |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 1,095 |  |  |  | 92 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 1.25 |  |  | $ | 0.62 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,534,423 |  |  |  | 62,146,393 |  |  |  | 61,696,014 |  |  |  | 62,260,170 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.82 |  |  | $ | 0.41 |  |  | $ | 1.24 |  |  | $ | 0.61 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,054,447 |  |  |  | 62,635,437 |  |  |  | 62,259,712 |  |  |  | 62,849,877 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 47,884 |  |  | $ | 32,208 |  |  | $ | 92,587 |  |  | $ | 47,928 |  |

[0001437749-18-014130:8k_2_02:78]
7

[0001437749-18-014130:8k_2_02:79]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-014130:8k_2_02:80]
|  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 88,001 |  |  | $ | 37,558 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 12,169 |  |  |  | 11,271 |  |
| Amortization of intangible assets |  |  | 11,114 |  |  |  | 14,312 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,367 |  |  |  | 1,308 |  |
| Loss on extinguishment of debt |  |  | 1,332 |  |  |  | – |  |
| Deferred income taxes |  |  | 6,257 |  |  |  | 16,500 |  |
| Share-based compensation expense |  |  | 6,991 |  |  |  | 5,818 |  |
| Other |  |  | 599 |  |  |  | 377 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (24,876 | ) |  |  | 2,504 |  |
| Inventories |  |  | (85,592 | ) |  |  | (8,236 | ) |
| Other assets |  |  | (13,047 | ) |  |  | 1,069 |  |
| Accounts payable |  |  | 33,442 |  |  |  | (26,560 | ) |
| Accrued wages and employee benefits |  |  | 4,510 |  |  |  | 1,902 |  |
| Other accrued liabilities |  |  | 36,578 |  |  |  | (3,144 | ) |
| Excess tax benefits from equity awards |  |  | (188 | ) |  |  | (403 | ) |
| Net cash provided by operating activities |  |  | 79,657 |  |  |  | 54,276 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 196 |  |  |  | 45 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,929 |  |  |  | 1,398 |  |
| Expenditures for property and equipment |  |  | (12,326 | ) |  |  | (10,030 | ) |
| Acquisition of business, net of cash acquired |  |  | (71,926 | ) |  |  | 1,160 |  |
| Net cash used in investing activities |  |  | (82,127 | ) |  |  | (7,427 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 12,133 |  |  |  | 62,435 |  |
| Proceeds from long-term borrowings |  |  | 50,000 |  |  |  | 3,069 |  |
| Repayments of short-term borrowings |  |  | (8,172 | ) |  |  | (72,971 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (50,797 | ) |  |  | (9,806 | ) |
| Stock repurchases |  |  | (25,656 | ) |  |  | (30,012 | ) |
| Cash dividends paid to noncontrolling interests of subsidiary |  |  | (314 | ) |  |  | – |  |
| Payment of debt issuance costs |  |  | (1,473 | ) |  |  | (1,517 | ) |
| Taxes paid related to equity awards |  |  | (1,725 | ) |  |  | (1,958 | ) |
| Proceeds from exercise of stock options |  |  | 2,124 |  |  |  | 1,254 |  |
| Net cash used in financing activities |  |  | (23,880 | ) |  |  | (49,506 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (408 | ) |  |  | 2,456 |  |
| Net decrease in cash and cash equivalents |  |  | (26,758 | ) |  |  | (201 | ) |
| Cash and cash equivalents at beginning of period |  |  | 138,472 |  |  |  | 67,272 |  |
| Cash and cash equivalents at end of period |  | $ | 111,714 |  |  | $ | 67,071 |  |

[0001437749-18-014130:8k_2_02:81]
8

[0001437749-18-014130:8k_2_02:82]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-014130:8k_2_02:83]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 381,047 |  |  | $ | 305,406 |  |  | $ | 681,266 |  |  | $ | 552,574 |  |
| International |  |  | 113,902 |  |  |  | 89,469 |  |  |  | 211,317 |  |  |  | 172,786 |  |
| Total net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 892,583 |  |  | $ | 725,360 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 246,398 |  |  | $ | 198,468 |  |  | $ | 436,872 |  |  | $ | 352,685 |  |
| Commercial & industrial products |  |  | 215,628 |  |  |  | 169,903 |  |  |  | 390,753 |  |  |  | 320,656 |  |
| Other |  |  | 32,923 |  |  |  | 26,504 |  |  |  | 64,958 |  |  |  | 52,019 |  |
| Total net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 892,583 |  |  | $ | 725,360 |  |

[0001437749-18-014130:8k_2_02:84]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 90,602 |  |  | $ | 63,692 |  |  | $ | 156,077 |  |  | $ | 105,583 |  |
| International |  |  | 11,628 |  |  |  | 6,034 |  |  |  | 17,934 |  |  |  | 10,846 |  |
| Total adjusted EBITDA (1) |  | $ | 102,230 |  |  | $ | 69,726 |  |  | $ | 174,011 |  |  | $ | 116,429 |  |

[0001437749-18-014130:8k_2_02:85]
| (1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-18-014130:8k_2_02:86]
9

[0001437749-18-014130:8k_2_02:87]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-014130:8k_2_02:88]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 1,095 |  |  |  | 92 |  |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 88,001 |  |  |  | 37,558 |  |
| Interest expense |  |  | 11,002 |  |  |  | 10,893 |  |  |  | 21,115 |  |  |  | 21,681 |  |
| Depreciation and amortization |  |  | 11,600 |  |  |  | 12,986 |  |  |  | 23,283 |  |  |  | 25,583 |  |
| Income taxes provision |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 29,798 |  |  |  | 21,701 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,316 |  |  |  | 1,710 |  |  |  | 2,622 |  |  |  | 1,876 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,885 |  |  |  | 3,186 |  |  |  | 6,991 |  |  |  | 5,818 |  |
| Loss on extinguishment of debt (3) |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 441 |  |  |  | 420 |  |  |  | 703 |  |  |  | 736 |  |
| Business optimization expenses (5) |  |  | 29 |  |  |  | 1,346 |  |  |  | 167 |  |  |  | 1,446 |  |
| Other |  |  | 12 |  |  |  | (69 | ) |  |  | (1 | ) |  |  | 30 |  |
| Adjusted EBITDA |  |  | 102,230 |  |  |  | 69,726 |  |  |  | 174,011 |  |  |  | 116,429 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,630 |  |  |  | 1,455 |  |  |  | 4,179 |  |  |  | 2,411 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 99,600 |  |  | $ | 68,271 |  |  | $ | 169,832 |  |  | $ | 114,018 |  |

[0001437749-18-014130:8k_2_02:89]
(1)  Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-18-014130:8k_2_02:90]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-18-014130:8k_2_02:91]
(3) Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt.

[0001437749-18-014130:8k_2_02:92]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-18-014130:8k_2_02:93]
(5) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities.

[0001437749-18-014130:8k_2_02:94]
10

[0001437749-18-014130:8k_2_02:95]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 1,095 |  |  |  | 92 |  |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 88,001 |  |  |  | 37,558 |  |
| Provision for income taxes |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 29,798 |  |  |  | 21,701 |  |
| Income before provision for income taxes |  |  | 72,613 |  |  |  | 39,254 |  |  |  | 117,799 |  |  |  | 59,259 |  |
| Amortization of intangible assets |  |  | 5,482 |  |  |  | 7,129 |  |  |  | 11,114 |  |  |  | 14,312 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,190 |  |  |  | 818 |  |  |  | 2,367 |  |  |  | 1,308 |  |
| Loss on extinguishment of debt (3) |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 794 |  |  |  | 429 |  |  |  | 814 |  |  |  | 1,014 |  |
| Business optimization expenses (5) |  |  | 29 |  |  |  | 1,346 |  |  |  | 167 |  |  |  | 1,446 |  |
| Adjusted net income before provision for income taxes |  |  | 81,440 |  |  |  | 48,976 |  |  |  | 133,593 |  |  |  | 77,339 |  |
| Cash income tax expense (7) |  |  | (11,114 | ) |  |  | (5,642 | ) |  |  | (16,524 | ) |  |  | (8,729 | ) |
| Adjusted net income |  |  | 70,326 |  |  |  | 43,334 |  |  |  | 117,069 |  |  |  | 68,610 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,383 |  |  |  | 633 |  |  |  | 2,044 |  |  |  | 1,215 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 68,943 |  |  | $ | 42,701 |  |  | $ | 115,025 |  |  | $ | 67,395 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.11 |  |  | $ | 0.68 |  |  | $ | 1.85 |  |  | $ | 1.07 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,054,447 |  |  |  | 62,635,437 |  |  |  | 62,259,712 |  |  |  | 62,849,877 |  |

[0001437749-18-014130:8k_2_02:96]
(6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-18-014130:8k_2_02:97]
(7) Amounts for the three and six months ended June 30, 2018 are now based on an anticipated cash income tax rate of approximately 14% to 15% for the full year ended 2018. Amounts for the three and six months ended June 30, 2017 were based on an anticipated cash income tax rate at that time of approximately 14% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-18-014130:8k_2_02:98]
11

[0001437749-18-014130:8k_2_02:99]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 50,689 |  |  | $ | 59,451 |  |  | $ | 79,657 |  |  | $ | 54,276 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,062 |  |  |  | 769 |  |  |  | 1,929 |  |  |  | 1,398 |  |
| Expenditures for property and equipment |  |  | (5,830 | ) |  |  | (6,482 | ) |  |  | (12,326 | ) |  |  | (10,030 | ) |
| Free cash flow |  | $ | 45,921 |  |  | $ | 53,738 |  |  | $ | 69,260 |  |  | $ | 45,644 |  |

[0001437749-18-014130:8k_2_02:100]
| GAAP Earnings Per Share |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (2,305 | ) |  |  | 295 |  |  |  | (9,970 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 50,956 |  |  | $ | 25,586 |  |  | $ | 76,936 |  |  | $ | 38,375 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,534,423 |  |  |  | 62,146,393 |  |  |  | 61,696,014 |  |  |  | 62,260,170 |  |
| Dilutive effect of stock compensation awards |  |  | 520,024 |  |  |  | 489,044 |  |  |  | 563,698 |  |  |  | 589,707 |  |
| Diluted shares |  |  | 62,054,447 |  |  |  | 62,635,437 |  |  |  | 62,259,712 |  |  |  | 62,849,877 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 1.25 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.82 |  |  | $ | 0.41 |  |  | $ | 1.24 |  |  | $ | 0.61 |  |

[0001437749-18-014130:8k_2_02:101]
12
