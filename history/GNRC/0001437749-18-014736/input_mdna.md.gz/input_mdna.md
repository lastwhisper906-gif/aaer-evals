# GNRC MD&A — 0001437749-18-014736


## mdna

[0001437749-18-014736:mdna:1]
[same as prior period, unchanged from 0001437749-18-008863:mdna:1]

[0001437749-18-014736:mdna:2]
[same as prior period, unchanged from 0001437749-18-008863:mdna:2]

[0001437749-18-014736:mdna:3]
[same as prior period, unchanged from 0001437749-18-008863:mdna:3]

[0001437749-18-014736:mdna:4]
[same as prior period, unchanged from 0001437749-18-008863:mdna:4]

[0001437749-18-014736:mdna:5]
[same as prior period, unchanged from 0001437749-18-008863:mdna:5]

[0001437749-18-014736:mdna:6]
[same as prior period, unchanged from 0001437749-18-008863:mdna:6]

[0001437749-18-014736:mdna:7]
[same as prior period, unchanged from 0001437749-18-008863:mdna:7]

[0001437749-18-014736:mdna:8]
[same as prior period, unchanged from 0001437749-18-008863:mdna:8]

[0001437749-18-014736:mdna:9]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing our products; |

[0001437749-18-014736:mdna:10]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-18-014736:mdna:11]
[same as prior period, unchanged from 0001437749-18-008863:mdna:11]

[0001437749-18-014736:mdna:12]
[same as prior period, unchanged from 0001437749-18-008863:mdna:12]

[0001437749-18-014736:mdna:13]
[same as prior period, unchanged from 0001437749-18-008863:mdna:13]

[0001437749-18-014736:mdna:14]
[same as prior period, unchanged from 0001437749-18-008863:mdna:14]

[0001437749-18-014736:mdna:15]
[same as prior period, unchanged from 0001437749-18-008863:mdna:15]

[0001437749-18-014736:mdna:16]
[same as prior period, unchanged from 0001437749-18-008863:mdna:16]

[0001437749-18-014736:mdna:17]
[same as prior period, unchanged from 0001437749-18-008863:mdna:17]

[0001437749-18-014736:mdna:18]
[same as prior period, unchanged from 0001437749-18-008863:mdna:18]

[0001437749-18-014736:mdna:19]
[same as prior period, unchanged from 0001437749-18-008863:mdna:19]

[0001437749-18-014736:mdna:20]
[same as prior period, unchanged from 0001437749-18-008863:mdna:20]

[0001437749-18-014736:mdna:21]
We are a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil and gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-18-014736:mdna:22]
Over the past eight years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Part 1, Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1 “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-014736:mdna:23]
[same as prior period, unchanged from 0001437749-18-008863:mdna:25]

[0001437749-18-014736:mdna:24]
[same as prior period, unchanged from 0001437749-18-008863:mdna:26]

[0001437749-18-014736:mdna:25]
[same as prior period, unchanged from 0001437749-18-008863:mdna:27]

[0001437749-18-014736:mdna:26]
Our performance is affected by the demand for back-up power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-18-014736:mdna:27]
Increasing penetration opportunity. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and, as a result, these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas-fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-18-014736:mdna:28]
Effect of large scale and baseline power disruptions. Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in 2017 and thus far in 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-18-014736:mdna:29]
[same as prior period, unchanged from 0001437749-18-008863:mdna:31]

[0001437749-18-014736:mdna:30]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil and gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve, including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil and gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment. We believe the passage of the Tax Act in late 2017 could have a favorable impact on future demand within many of the end markets that we serve, as the improved cash flow, liquidity and business sentiment may lead to further investments in equipment, facilities and infrastructure in the United States.

[0001437749-18-014736:mdna:31]
[same as prior period, unchanged from 0001437749-18-008863:mdna:33]

[0001437749-18-014736:mdna:32]
[same as prior period, unchanged from 0001437749-18-008863:mdna:34]

[0001437749-18-014736:mdna:33]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, and other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Also, acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can have a material impact on our results of operations.

[0001437749-18-014736:mdna:34]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-18-014736:mdna:35]
[same as prior period, unchanged from 0001437749-18-008863:mdna:37]

[0001437749-18-014736:mdna:36]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Cash interest expense decreased during the six months ended June 30, 2018 compared to the six months ended June 30, 2017, primarily due to lower interest rate spreads resulting from the Term Loan amendments, and the October 2017 repayment of $100 million of ABL Facility borrowings. These factors are partially offset by an increase in the market LIBOR rate. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-18-014736:mdna:37]
[same as prior period, unchanged from 0001437749-18-008863:mdna:39]

[0001437749-18-014736:mdna:38]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. While we continue to assess the full impact of the Tax Act, the preliminary analysis suggests a meaningful benefit from the legislation. Specifically for 2018, our combined federal and state effective tax rate is expected to decline to between 25 to 26%, resulting in lower cash income taxes. As we complete our analysis of the Tax Act, collect and prepare necessary data, and interpret any additional guidance, we may make adjustments to provisional amounts that we have recorded that may materially impact our provision for income taxes in the period in which the adjustments are made. Refer to Note 14, “Income Taxes,” to the consolidated financial statements in Item 8 of the Annual Report on Form 10-K for the year ended December 31, 2017 for further information on the Tax Act and its impact.

[0001437749-18-014736:mdna:39]
Further, we had approximately $470 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2017 related to our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $122 million through 2021, assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $61 million from prior estimates due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The amortization of these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $32 million through 2020 and $26 million in 2021, assuming profitability and a 26% combined federal and state tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $34 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2017. We expect these assets to generate aggregate cash tax savings of $9.0 million through 2026 assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $4.5 million due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.0 million through 2025 and $0.7 million in 2026, assuming profitability and a 26% combined federal and state tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to our consolidated financial statements.

[0001437749-18-014736:mdna:40]
[same as prior period, unchanged from 0001437749-18-008863:mdna:42]

[0001437749-18-014736:mdna:41]
Three months ended June 30, 2018 compared to the three months ended June 30, 2017

[0001437749-18-014736:mdna:42]
The following table sets forth our consolidated statements of operations data for the periods indicated:

[0001437749-18-014736:mdna:43]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 100,074 |  |  |  | 25.3 | % |
| Cost of goods sold |  |  | 318,693 |  |  |  | 261,954 |  |  |  | 56,739 |  |  |  | 21.7 | % |
| Gross profit |  |  | 176,256 |  |  |  | 132,921 |  |  |  | 43,335 |  |  |  | 32.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 46,052 |  |  |  | 42,010 |  |  |  | 4,042 |  |  |  | 9.6 | % |
| Research and development |  |  | 12,616 |  |  |  | 10,553 |  |  |  | 2,063 |  |  |  | 19.5 | % |
| General and administrative |  |  | 26,639 |  |  |  | 21,407 |  |  |  | 5,232 |  |  |  | 24.4 | % |
| Amortization of intangible assets |  |  | 5,482 |  |  |  | 7,129 |  |  |  | (1,647 | ) |  |  | -23.1 | % |
| Total operating expenses |  |  | 90,789 |  |  |  | 81,099 |  |  |  | 9,690 |  |  |  | 11.9 | % |
| Income from operations |  |  | 85,467 |  |  |  | 51,822 |  |  |  | 33,645 |  |  |  | 64.9 | % |
| Total other expense, net |  |  | (12,854 | ) |  |  | (12,568 | ) |  |  | (286 | ) |  |  | 2.3 | % |
| Income before provision for income taxes |  |  | 72,613 |  |  |  | 39,254 |  |  |  | 33,359 |  |  |  | 85.0 | % |
| Provision for income taxes |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 4,504 |  |  |  | 32.5 | % |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 28,855 |  |  |  | 113.7 | % |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 885 |  |  |  | 1041.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 27,970 |  |  |  | 110.6 | % |

[0001437749-18-014736:mdna:44]
[same as prior period, unchanged from 0001437749-18-008863:mdna:46]

[0001437749-18-014736:mdna:45]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 381,047 |  |  | $ | 305,406 |  |  | $ | 75,641 |  |  |  | 24.8 | % |
| International |  |  | 113,902 |  |  |  | 89,469 |  |  |  | 24,433 |  |  |  | 27.3 | % |
| Total net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 100,074 |  |  |  | 25.3 | % |

[0001437749-18-014736:mdna:46]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 90,602 |  |  | $ | 63,692 |  |  | $ | 26,910 |  |  |  | 42.3 | % |
| International |  |  | 11,628 |  |  |  | 6,034 |  |  |  | 5,594 |  |  |  | 92.7 | % |
| Total Adjusted EBITDA |  | $ | 102,230 |  |  | $ | 69,726 |  |  | $ | 32,504 |  |  |  | 46.6 | % |

[0001437749-18-014736:mdna:47]
[same as prior period, unchanged from 0001437749-18-008863:mdna:74]

[0001437749-18-014736:mdna:48]
[same as prior period, unchanged from 0001437749-18-008863:mdna:49]

[0001437749-18-014736:mdna:49]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 246,398 |  |  | $ | 198,468 |  |  | $ | 47,930 |  |  |  | 24.1 | % |
| Commercial & industrial products |  |  | 215,628 |  |  |  | 169,903 |  |  |  | 45,725 |  |  |  | 26.9 | % |
| Other |  |  | 32,923 |  |  |  | 26,504 |  |  |  | 6,419 |  |  |  | 24.2 | % |
| Total net sales |  | $ | 494,949 |  |  | $ | 394,875 |  |  | $ | 100,074 |  |  |  | 25.3 | % |

[0001437749-18-014736:mdna:50]
Net sales.    The increase in Domestic sales for the three months ended June 30, 2018 was primarily due to continued strong growth in shipments of home standby and portable generators, and from robust C&I shipments driven by mobile products fleet replacement and strength in stationary generators through national accounts. Also contributing to the year-over-year sales growth were increases in service parts.

[0001437749-18-014736:mdna:51]
The increase in International sales for the three months ended June 30, 2018 was primarily due to increased organic shipments of C&I products within the European, Asian and Latin America regions, the contribution from the Selmec acquisition and the stronger Euro compared to prior year.

[0001437749-18-014736:mdna:52]
The total net sales contribution from non-annualized recent acquisitions to the three months ended June 30, 2018 was $4.0 million.

[0001437749-18-014736:mdna:53]
Gross profit.    Gross profit margin for the second quarter of 2018 was 35.6% compared to 33.7% in the prior-year second quarter. The increase reflected better leverage of fixed manufacturing costs on the significant increase in sales, a more favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-18-014736:mdna:54]
Operating expenses.   The increase in operating expenses was primarily driven by higher variable operating expenses given the higher sales volumes, an increase in employee costs including additional incentive compensation, and increased International operating expenses given the stronger Euro. These items were partially offset by lower promotional costs and lower intangible asset amortization expense.

[0001437749-18-014736:mdna:55]
Other expense.    The slight increase in other expense, net was primarily due to the $1.3 million loss on extinguishment of debt resulting from a $50.0 million voluntary prepayment of Term Loan debt.

[0001437749-18-014736:mdna:56]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2018 and 2017 were 25.3% and 35.4%, respectively. The decrease in the effective income tax rate in 2018 was primarily due to a reduction in the U.S. federal corporate tax rate as a result of the Tax Act enacted on December 22, 2017.

[0001437749-18-014736:mdna:57]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate during the current year quarter, partially offset by higher income attributable to noncontrolling interests.

[0001437749-18-014736:mdna:58]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $90.6 million, or 23.8% of net sales, as compared to $63.7 million, or 20.9% of net sales in the prior year. Adjusted EBITDA margin in the current year benefitted from improved overall operating leverage on the higher organic sales volumes, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs, including higher incentive compensation, and general inflationary pressures.

[0001437749-18-014736:mdna:59]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, improved to $11.6 million, or 10.2% of net sales, as compared to $6.0 million, or 6.7% of net sales, in the prior year. The improvement in Adjusted EBITDA margin as compared to the prior year was primarily due to increased leverage of fixed operating costs on the higher organic sales and favorable mix. These favorable impacts were partially offset by higher commodity prices, along with the expansion of operating expenses for certain branch operations.

[0001437749-18-014736:mdna:60]
Adjusted Net Income.    Adjusted Net Income of $68.9 million for the three months ended June 30, 2018 increased 61.5% from $42.7 million for the three months ended June 30, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense and higher adjusted net income attributable to noncontrolling interests.

[0001437749-18-014736:mdna:61]
[same as prior period, unchanged from 0001437749-18-008863:mdna:61]

[0001437749-18-014736:mdna:62]
Six months ended June 30, 2018 compared to the six months ended June 30, 2017

[0001437749-18-014736:mdna:63]
The following table sets forth our consolidated statements of operations data for the periods indicated:

[0001437749-18-014736:mdna:64]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 892,583 |  |  | $ | 725,360 |  |  | $ | 167,223 |  |  |  | 23.1 | % |
| Cost of goods sold |  |  | 576,338 |  |  |  | 483,639 |  |  |  | 92,699 |  |  |  | 19.2 | % |
| Gross profit |  |  | 316,245 |  |  |  | 241,721 |  |  |  | 74,524 |  |  |  | 30.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 88,734 |  |  |  | 81,477 |  |  |  | 7,257 |  |  |  | 8.9 | % |
| Research and development |  |  | 24,469 |  |  |  | 20,840 |  |  |  | 3,629 |  |  |  | 17.4 | % |
| General and administrative |  |  | 50,114 |  |  |  | 42,380 |  |  |  | 7,734 |  |  |  | 18.2 | % |
| Amortization of intangible assets |  |  | 11,114 |  |  |  | 14,312 |  |  |  | (3,198 | ) |  |  | -22.3 | % |
| Total operating expenses |  |  | 174,431 |  |  |  | 159,009 |  |  |  | 15,422 |  |  |  | 9.7 | % |
| Income from operations |  |  | 141,814 |  |  |  | 82,712 |  |  |  | 59,102 |  |  |  | 71.5 | % |
| Total other expense, net |  |  | (24,015 | ) |  |  | (23,453 | ) |  |  | (562 | ) |  |  | 2.4 | % |
| Income before provision for income taxes |  |  | 117,799 |  |  |  | 59,259 |  |  |  | 58,540 |  |  |  | 98.8 | % |
| Provision for income taxes |  |  | 29,798 |  |  |  | 21,701 |  |  |  | 8,097 |  |  |  | 37.3 | % |
| Net income |  |  | 88,001 |  |  |  | 37,558 |  |  |  | 50,443 |  |  |  | 134.3 | % |
| Net income attributable to noncontrolling interests |  |  | 1,095 |  |  |  | 92 |  |  |  | 1,003 |  |  |  | 1090.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 86,906 |  |  | $ | 37,466 |  |  | $ | 49,440 |  |  |  | 132.0 | % |

[0001437749-18-014736:mdna:65]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-18-014736:mdna:66]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 681,266 |  |  | $ | 552,574 |  |  | $ | 128,692 |  |  |  | 23.3 | % |
| International |  |  | 211,317 |  |  |  | 172,786 |  |  |  | 38,531 |  |  |  | 22.3 | % |
| Total net sales |  | $ | 892,583 |  |  | $ | 725,360 |  |  | $ | 167,223 |  |  |  | 23.1 | % |

[0001437749-18-014736:mdna:67]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 156,077 |  |  | $ | 105,583 |  |  | $ | 50,494 |  |  |  | 47.8 | % |
| International |  |  | 17,934 |  |  |  | 10,846 |  |  |  | 7,088 |  |  |  | 65.4 | % |
| Total Adjusted EBITDA |  | $ | 174,011 |  |  | $ | 116,429 |  |  | $ | 57,582 |  |  |  | 49.5 | % |

[0001437749-18-014736:mdna:68]
The following table sets forth our product class information for the periods indicated:

[0001437749-18-014736:mdna:69]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 436,872 |  |  | $ | 352,685 |  |  | $ | 84,187 |  |  |  | 23.9 | % |
| Commercial & industrial products |  |  | 390,753 |  |  |  | 320,656 |  |  |  | 70,097 |  |  |  | 21.9 | % |
| Other |  |  | 64,958 |  |  |  | 52,019 |  |  |  | 12,939 |  |  |  | 24.9 | % |
| Total net sales |  | $ | 892,583 |  |  | $ | 725,360 |  |  | $ | 167,223 |  |  |  | 23.1 | % |

[0001437749-18-014736:mdna:70]
Net sales.    The increase in Domestic sales for the six months ended June 30, 2018 was primarily due to continued strong growth in shipments of home standby and portable generators, and from robust C&I shipments driven by mobile products fleet replacement and strength in stationary generators through national accounts. Also contributing to the year-over-year sales growth were increases in service parts.

[0001437749-18-014736:mdna:71]
The increase in International sales for the six months ended June 30, 2018 was primarily due to increased organic shipments of C&I products within the European, Asian and Latin America regions, the contribution from the Selmec acquisition and the stronger Euro compared to prior year.

[0001437749-18-014736:mdna:72]
The total net sales contribution from non-annualized recent acquisitions to the six months ended June 30, 2018 was $4.0 million.

[0001437749-18-014736:mdna:73]
Gross profit.    Gross profit margin for the first half of 2018 was 35.4% compared to 33.3% in the prior-year first half. The increase reflected better leverage of fixed manufacturing costs on the significant increase in sales, a more favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-18-014736:mdna:74]
Operating expenses.   The increase in operating expenses was primarily driven by an increase in employee costs including additional incentive compensation, higher variable operating expenses given the higher sales volumes, and increased International operating expenses given the stronger Euro. These items were partially offset by lower promotional costs and lower intangible asset amortization expense.

[0001437749-18-014736:mdna:75]
Other expense.    The slight increase in other expense, net was primarily due to the $1.3 million loss on extinguishment of debt resulting from a $50.0 million voluntary prepayment of Term Loan debt. This was partially offset by lower interest expense.

[0001437749-18-014736:mdna:76]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2018 and 2017 were 25.3% and 36.7%, respectively. The decrease in the effective income tax rate in 2018 was primarily due to a reduction in the U.S. federal corporate tax rate as a result of the Tax Act enacted on December 22, 2017.

[0001437749-18-014736:mdna:77]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate during the current year quarter, partially offset by higher income attributable to noncontrolling interests.

[0001437749-18-014736:mdna:78]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $156.1 million, or 22.9% of net sales, as compared to $105.6 million, or 19.1% of net sales in the prior year. Adjusted EBITDA margin in the current year benefitted from improved overall operating leverage on the higher organic sales volumes, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs, including higher incentive compensation, and general inflationary pressures.

[0001437749-18-014736:mdna:79]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, improved to $17.9 million, or 8.5% of net sales, as compared to $10.8 million, or 6.3% of net sales, in the prior year. The improvement in Adjusted EBITDA margin as compared to the prior year was primarily due to increased leverage of fixed operating costs on the higher organic sales and favorable mix. These favorable impacts were partially offset by higher commodity prices, along with the expansion of operating expenses for certain branch operations.

[0001437749-18-014736:mdna:80]
Adjusted Net Income.    Adjusted Net Income of $115.0 million for the six months ended June 30, 2018 increased 70.7% from $67.4 million for the six months ended June 30, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense and higher adjusted net income attributable to noncontrolling interests.

[0001437749-18-014736:mdna:81]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-18-014736:mdna:82]
[same as prior period, unchanged from 0001437749-18-008863:mdna:62]

[0001437749-18-014736:mdna:83]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our Amended ABL Facility.

[0001437749-18-014736:mdna:84]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility that could be utilized in the future if needed. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2018, our secured leverage ratio was 2.11 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-18-014736:mdna:85]
Our credit agreements also provide for the $300.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is June 12, 2023. As of June 30, 2018, there were $50.0 million of borrowings outstanding and $192.2 million of availability under the Amended ABL Facility, net of outstanding letters of credit. We were in compliance with all covenants of the Amended ABL Facility as of June 30, 2018.

[0001437749-18-014736:mdna:86]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. Since the inception of both programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand. During the six months ended June 30, 2018 and 2017, we repurchased 560,000 and 844,500 shares of our common stock, respectively, for $25.7 million and $30.0 million, respectively, all funded with cash on hand.

[0001437749-18-014736:mdna:87]
See Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-18-014736:mdna:88]
[same as prior period, unchanged from 0001437749-18-008863:mdna:68]

[0001437749-18-014736:mdna:89]
We believe that our cash flow from operations and availability under our Amended ABL Facility and other short-term lines of credit, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate), provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-18-014736:mdna:90]
[same as prior period, unchanged from 0001437749-18-008863:mdna:70]

[0001437749-18-014736:mdna:91]
Six months ended June 30, 2018 compared to the six months ended June 30, 2017

[0001437749-18-014736:mdna:92]
[same as prior period, unchanged from 0001437749-18-008863:mdna:72]

[0001437749-18-014736:mdna:93]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 79,657 |  |  | $ | 54,276 |  |  | $ | 25,381 |  |  |  | 46.8 | % |
| Net cash used in investing activities |  |  | (82,127 | ) |  |  | (7,427 | ) |  |  | (74,700 | ) |  |  | 1005.8 | % |
| Net cash used in financing activities |  |  | (23,880 | ) |  |  | (49,506 | ) |  |  | 25,626 |  |  |  | -51.8 | % |

[0001437749-18-014736:mdna:94]
The increase in net cash provided by operating activities was primarily due to an increase in operating earnings as compared to the prior year, partially offset by increased working capital investment driven by organic sales growth and the replenishment of inventory levels in anticipation of the summer storm season.

[0001437749-18-014736:mdna:95]
Net cash used in investing activities for the six months ended June 30, 2018 primarily represents cash payments of $71.9 million related to the acquisition of businesses and $12.3 million for the purchase of property and equipment. Net cash used in investing activities for the six months ended June 30, 2017 primarily represents cash payments for the purchase of property and equipment.

[0001437749-18-014736:mdna:96]
Net cash used in financing activities for the six months ended June 30, 2018 primarily represents $59.0 million of debt repayments ($50.8 million of long-term borrowings and $8.2 million of short-term borrowings) and $25.7 million cash used for the repurchase of our common stock. These payments were partially offset by $62.1 million of cash proceeds from borrowings ($50.0 million long-term and $12.1 million short-term).

[0001437749-18-014736:mdna:97]
Net cash used in financing activities for the six months ended June 30, 2017 primarily represents $82.8 million of debt repayments ($73.0 million of short-term borrowings and $9.8 million of long-term borrowings) and $30.0 million for the repurchase of our common stock. These payments were partially offset by $65.5 million cash proceeds from borrowings ($62.4 million short-term and $3.1 million long-term).

[0001437749-18-014736:mdna:98]
[same as prior period, unchanged from 0001437749-18-008863:mdna:79]

[0001437749-18-014736:mdna:99]
In June 2018, the Company amended its Term Loan and ABL Facility, and borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. See Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for further information. Other than these transactions, there have been no material changes to our contractual obligations since the February 26, 2018 filing of our Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-014736:mdna:100]
[same as prior period, unchanged from 0001437749-18-008863:mdna:81]

[0001437749-18-014736:mdna:101]
[same as prior period, unchanged from 0001437749-18-008863:mdna:82]

[0001437749-18-014736:mdna:102]
[same as prior period, unchanged from 0001437749-18-008863:mdna:83]

[0001437749-18-014736:mdna:103]
[same as prior period, unchanged from 0001437749-18-008863:mdna:84]

[0001437749-18-014736:mdna:104]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2017, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; and income taxes.

[0001437749-18-014736:mdna:105]
[same as prior period, unchanged from 0001437749-18-008863:mdna:86]

[0001437749-18-014736:mdna:106]
[same as prior period, unchanged from 0001437749-18-008863:mdna:87]

[0001437749-18-014736:mdna:107]
[same as prior period, unchanged from 0001437749-18-008863:mdna:88]

[0001437749-18-014736:mdna:108]
[same as prior period, unchanged from 0001437749-18-008863:mdna:89]

[0001437749-18-014736:mdna:109]
[same as prior period, unchanged from 0001437749-18-008863:mdna:90]

[0001437749-18-014736:mdna:110]
[same as prior period, unchanged from 0001437749-18-008863:mdna:91]

[0001437749-18-014736:mdna:111]
[same as prior period, unchanged from 0001437749-18-008863:mdna:92]

[0001437749-18-014736:mdna:112]
[same as prior period, unchanged from 0001437749-18-008863:mdna:93]

[0001437749-18-014736:mdna:113]
[same as prior period, unchanged from 0001437749-18-008863:mdna:94]

[0001437749-18-014736:mdna:114]
[same as prior period, unchanged from 0001437749-18-008863:mdna:95]

[0001437749-18-014736:mdna:115]
[same as prior period, unchanged from 0001437749-18-008863:mdna:96]

[0001437749-18-014736:mdna:116]
[same as prior period, unchanged from 0001437749-18-008863:mdna:97]

[0001437749-18-014736:mdna:117]
[same as prior period, unchanged from 0001437749-18-008863:mdna:98]

[0001437749-18-014736:mdna:118]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and Amended ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-18-014736:mdna:119]
[same as prior period, unchanged from 0001437749-18-008863:mdna:100]

[0001437749-18-014736:mdna:120]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-18-014736:mdna:121]
[same as prior period, unchanged from 0001437749-18-008863:mdna:102]

[0001437749-18-014736:mdna:122]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-18-014736:mdna:123]
[same as prior period, unchanged from 0001437749-18-008863:mdna:104]

[0001437749-18-014736:mdna:124]
[same as prior period, unchanged from 0001437749-18-008863:mdna:105]

[0001437749-18-014736:mdna:125]
[same as prior period, unchanged from 0001437749-18-008863:mdna:106]

[0001437749-18-014736:mdna:126]
[same as prior period, unchanged from 0001437749-18-008863:mdna:107]

[0001437749-18-014736:mdna:127]
[same as prior period, unchanged from 0001437749-18-008863:mdna:108]

[0001437749-18-014736:mdna:128]
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheets prepared in accordance with U.S. GAAP; and |

[0001437749-18-014736:mdna:129]
[same as prior period, unchanged from 0001437749-18-008863:mdna:110]

[0001437749-18-014736:mdna:130]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-18-014736:mdna:131]
[same as prior period, unchanged from 0001437749-18-008863:mdna:112]

[0001437749-18-014736:mdna:132]
26

[0001437749-18-014736:mdna:133]
[same as prior period, unchanged from 0001437749-18-008863:mdna:113]

[0001437749-18-014736:mdna:134]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 1,095 |  |  |  | 92 |  |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 88,001 |  |  |  | 37,558 |  |
| Interest expense |  |  | 11,002 |  |  |  | 10,893 |  |  |  | 21,115 |  |  |  | 21,681 |  |
| Depreciation and amortization |  |  | 11,600 |  |  |  | 12,986 |  |  |  | 23,283 |  |  |  | 25,583 |  |
| Provision for income taxes |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 29,798 |  |  |  | 21,701 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,316 |  |  |  | 1,710 |  |  |  | 2,622 |  |  |  | 1,876 |  |
| Non-cash share-based compensation expense (b) |  |  | 3,885 |  |  |  | 3,186 |  |  |  | 6,991 |  |  |  | 5,818 |  |
| Loss on extinguishment of debt (c) |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 441 |  |  |  | 420 |  |  |  | 703 |  |  |  | 736 |  |
| Business optimization expenses (e) |  |  | 29 |  |  |  | 1,346 |  |  |  | 167 |  |  |  | 1,446 |  |
| Other |  |  | 12 |  |  |  | (69 | ) |  |  | (1 | ) |  |  | 30 |  |
| Adjusted EBITDA |  |  | 102,230 |  |  |  | 69,726 |  |  |  | 174,011 |  |  |  | 116,429 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,630 |  |  |  | 1,455 |  |  |  | 4,179 |  |  |  | 2,411 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 99,600 |  |  | $ | 68,271 |  |  | $ | 169,832 |  |  | $ | 114,018 |  |

[0001437749-18-014736:mdna:135]
[same as prior period, unchanged from 0001437749-18-008863:mdna:115]

[0001437749-18-014736:mdna:136]
[same as prior period, unchanged from 0001437749-18-008863:mdna:116]

[0001437749-18-014736:mdna:137]
[same as prior period, unchanged from 0001437749-18-008863:mdna:117]

[0001437749-18-014736:mdna:138]
[same as prior period, unchanged from 0001437749-18-008863:mdna:118]

[0001437749-18-014736:mdna:139]
[same as prior period, unchanged from 0001437749-18-008863:mdna:119]

[0001437749-18-014736:mdna:140]
(c) Represents the non-cash write-off of original issue discount and deferred financing costs due to a $50.0 million voluntary prepayment of Term Loan debt.

[0001437749-18-014736:mdna:141]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-18-014736:mdna:142]
(e) For the three and six months ended June 30, 2018, represents severance and other non-recurring restructuring charges. For the three and six months ended June 30, 2017, represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-18-014736:mdna:143]
[same as prior period, unchanged from 0001437749-18-008863:mdna:122]

[0001437749-18-014736:mdna:144]
[same as prior period, unchanged from 0001437749-18-008863:mdna:123]

[0001437749-18-014736:mdna:145]
[same as prior period, unchanged from 0001437749-18-008863:mdna:124]

[0001437749-18-014736:mdna:146]
[same as prior period, unchanged from 0001437749-18-008863:mdna:125]

[0001437749-18-014736:mdna:147]
[same as prior period, unchanged from 0001437749-18-008863:mdna:126]

[0001437749-18-014736:mdna:148]
[same as prior period, unchanged from 0001437749-18-008863:mdna:127]

[0001437749-18-014736:mdna:149]
[same as prior period, unchanged from 0001437749-18-008863:mdna:128]

[0001437749-18-014736:mdna:150]
[same as prior period, unchanged from 0001437749-18-008863:mdna:129]

[0001437749-18-014736:mdna:151]
[same as prior period, unchanged from 0001437749-18-008863:mdna:130]

[0001437749-18-014736:mdna:152]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 53,261 |  |  | $ | 25,291 |  |  | $ | 86,906 |  |  | $ | 37,466 |  |
| Net income attributable to noncontrolling interests |  |  | 970 |  |  |  | 85 |  |  |  | 1,095 |  |  |  | 92 |  |
| Net income |  |  | 54,231 |  |  |  | 25,376 |  |  |  | 88,001 |  |  |  | 37,558 |  |
| Provision for income taxes |  |  | 18,382 |  |  |  | 13,878 |  |  |  | 29,798 |  |  |  | 21,701 |  |
| Income before provision for income taxes |  |  | 72,613 |  |  |  | 39,254 |  |  |  | 117,799 |  |  |  | 59,259 |  |
| Amortization of intangible assets |  |  | 5,482 |  |  |  | 7,129 |  |  |  | 11,114 |  |  |  | 14,312 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,190 |  |  |  | 818 |  |  |  | 2,367 |  |  |  | 1,308 |  |
| Loss on extinguishment of debt |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 794 |  |  |  | 429 |  |  |  | 814 |  |  |  | 1,014 |  |
| Business optimization expenses |  |  | 29 |  |  |  | 1,346 |  |  |  | 167 |  |  |  | 1,446 |  |
| Adjusted net income before provision for income taxes |  |  | 81,440 |  |  |  | 48,976 |  |  |  | 133,593 |  |  |  | 77,339 |  |
| Cash income tax expense (b) |  |  | (11,114 | ) |  |  | (5,642 | ) |  |  | (16,524 | ) |  |  | (8,729 | ) |
| Adjusted net income |  |  | 70,326 |  |  |  | 43,334 |  |  |  | 117,069 |  |  |  | 68,610 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,383 |  |  |  | 633 |  |  |  | 2,044 |  |  |  | 1,215 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 68,943 |  |  | $ | 42,701 |  |  | $ | 115,025 |  |  | $ | 67,395 |  |
| Adjusted net income per common share attributable to |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Generac Holdings, Inc. - diluted: |  | $ | 1.11 |  |  | $ | 0.68 |  |  | $ | 1.85 |  |  | $ | 1.07 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,054,447 |  |  |  | 62,635,437 |  |  |  | 62,259,712 |  |  |  | 62,849,877 |  |

[0001437749-18-014736:mdna:153]
[same as prior period, unchanged from 0001437749-18-008863:mdna:132]

[0001437749-18-014736:mdna:154]
(b) Amounts for the three and six months ended June 30, 2018 are now based on an anticipated cash income tax rate of approximately 14% to 15% for the full year ended 2018. Amounts for the three and six months ended June 30, 2017 were based on an anticipated cash income tax rate at that time of approximately 14% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-18-014736:mdna:155]
[same as prior period, unchanged from 0001437749-18-008863:mdna:134]

[0001437749-18-014736:mdna:156]
Refer to Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Part 1, Item 1of this Quarterly Report on Form 10-Q for further information on the new accounting standards applicable to the Company.
