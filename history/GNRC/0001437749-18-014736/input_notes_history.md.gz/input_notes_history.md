# GNRC note change history — 0001437749-18-008863 → 0001437749-18-014736


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001437749-18-014736:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2018 
and 
 December 31, 2017 
was approximately 
$36,200
 and 
$36,500,
 respectively.
  (was, 2018-05-07, similarity 0.9923):
[0001437749-18-008863:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2018 
and 
 December 31, 2017 
was approximately 
$34,600
 and 
$36,500,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001437749-18-014736:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2018-05-07, similarity 0.6681):
[0001437749-18-008863:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2018-08-07):
[0001437749-18-014736:note_history:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of its Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:
  (was, 2018-05-07, similarity 0.9887):
[0001437749-18-008863:note_history:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:

- added (2018-08-07):
[0001437749-18-014736:note_history:4]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |

- changed (2018-08-07):
[0001437749-18-014736:note_history:5]
The condensed consolidated balance sheets as of 
 June 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2018-05-07, similarity 0.9033):
[0001437749-18-008863:note_history:5]
The condensed consolidated balance sheet as of 
 March 31, 2018, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- changed (2018-08-07):
[0001437749-18-014736:note_history:6]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.
  (was, 2018-05-07, similarity 0.9871):
[0001437749-18-008863:note_history:6]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.

- added (2018-08-07):
[0001437749-18-014736:note_history:7]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2018-08-07):
[0001437749-18-014736:note_history:8]
Derivatives and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.
  (was, 2018-05-07, similarity 0.9774):
[0001437749-18-008863:note_history:8]
Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2018-08-07):
[0001437749-18-014736:note_history:9]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The adoption of this new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.
  (was, 2018-05-07, similarity 0.9772):
[0001437749-18-008863:note_history:9]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

- changed (2018-08-07):
[0001437749-18-014736:note_history:10]
| Condensed Consolidated Balance Sheets |  | June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 243,285 |  |  | $ | (3,143 | ) |  | $ | 240,142 |  |
| Inventories |  |  | 378,110 |  |  |  | 6,081 |  |  |  | 384,191 |  |
| Other accrued liabilities |  |  | 93,343 |  |  |  | 5,253 |  |  |  | 98,596 |  |
| Deferred income taxes |  |  | 37,575 |  |  |  | (3,190 | ) |  |  | 34,385 |  |
| Other long-term liabilities |  |  | 66,633 |  |  |  | 5,844 |  |  |  | 72,477 |  |
| Retained earnings |  | $ | 495,463 |  |  | $ | (4,969 | ) |  | $ | 490,494 |  |
  (was, 2018-05-07, similarity 0.8453):
[0001437749-18-008863:note_history:10]
| Condensed Consolidated Balance Sheet |  | March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 223,031 |  |  | $ | (2,484 | ) |  | $ | 220,547 |  |
| Inventories |  |  | 390,908 |  |  |  | 6,082 |  |  |  | 396,990 |  |
| Other accrued liabilities |  |  | 91,853 |  |  |  | 5,604 |  |  |  | 97,457 |  |
| Deferred income taxes |  |  | 27,376 |  |  |  | (2,954 | ) |  |  | 24,422 |  |
| Other long-term liabilities |  |  | 62,129 |  |  |  | 5,548 |  |  |  | 67,677 |  |
| Retained earnings |  | $ | 469,508 |  |  | $ | (4,600 | ) |  | $ | 464,908 |  |

- changed (2018-08-07):
[0001437749-18-014736:note_history:11]
|  |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |
  (was, 2018-05-07, similarity 0.9595):
[0001437749-18-008863:note_history:11]
| Condensed Consolidated Balance Sheet |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |

- changed (2018-08-07):
[0001437749-18-014736:note_history:12]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 395,376 |  |  | $ | (501 | ) |  | $ | 394,875 |  |
| Cost of goods sold |  |  | 260,916 |  |  |  | 1,038 |  |  |  | 261,954 |  |
| Selling and service expenses |  |  | 43,116 |  |  |  | (1,106 | ) |  |  | 42,010 |  |
| Research and development expenses |  |  | 10,567 |  |  |  | (14 | ) |  |  | 10,553 |  |
| General and administrative expenses |  |  | 21,361 |  |  |  | 46 |  |  |  | 21,407 |  |
| Other, net |  |  | 1,437 |  |  |  | 140 |  |  |  | 1,577 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | (236 | ) |  |  | 13,878 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | (369 | ) |  | $ | 25,291 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | (0.01 | ) |  | $ | 0.41 |  |
| Diluted |  | $ | 0.41 |  |  | $ | - |  |  | $ | 0.41 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 32,577 |  |  | $ | (369 | ) |  | $ | 32,208 |  |
  (was, 2018-05-07, similarity 0.7746):
[0001437749-18-008863:note_history:12]
| Condensed Consolidated Statement of Comprehensive Income |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 331,814 |  |  | $ | (1,329 | ) |  | $ | 330,485 |  |
| Cost of goods sold |  |  | 221,328 |  |  |  | 357 |  |  |  | 221,685 |  |
| Selling and service expenses |  |  | 40,184 |  |  |  | (717 | ) |  |  | 39,467 |  |
| Research and development expenses |  |  | 10,301 |  |  |  | (14 | ) |  |  | 10,287 |  |
| Other, net |  |  | (223 | ) |  |  | 140 |  |  |  | (83 | ) |
| Provision for income taxes |  |  | 8,251 |  |  |  | (428 | ) |  |  | 7,823 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | (667 | ) |  | $ | 12,175 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  |  | $ | (0.01 | ) |  | $ | 0.21 |  |
| Diluted |  | $ | 0.21 |  |  | $ | (0.01 | ) |  | $ | 0.20 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 16,387 |  |  | $ | (667 | ) |  | $ | 15,720 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:13]
|  |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 727,190 |  |  | $ | (1,830 | ) |  | $ | 725,360 |  |
| Cost of goods sold |  |  | 482,244 |  |  |  | 1,395 |  |  |  | 483,639 |  |
| Selling and service expenses |  |  | 83,300 |  |  |  | (1,823 | ) |  |  | 81,477 |  |
| Research and development expenses |  |  | 20,868 |  |  |  | (28 | ) |  |  | 20,840 |  |
| General and administrative expenses |  |  | 42,334 |  |  |  | 46 |  |  |  | 42,380 |  |
| Other, net |  |  | 1,214 |  |  |  | 280 |  |  |  | 1,494 |  |
| Provision for income taxes |  |  | 22,365 |  |  |  | (664 | ) |  |  | 21,701 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 38,502 |  |  | $ | (1,036 | ) |  | $ | 37,466 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | (0.01 | ) |  | $ | 0.62 |  |
| Diluted |  | $ | 0.63 |  |  | $ | (0.02 | ) |  | $ | 0.61 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 48,964 |  |  | $ | (1,036 | ) |  | $ | 47,928 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:14]
| Condensed Consolidated Statement of Cash Flows |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 38,594 |  |  | $ | (1,036 | ) |  | $ | 37,558 |  |
| Deferred income taxes |  |  | 17,164 |  |  |  | (664 | ) |  |  | 16,500 |  |
| Accounts receivable |  |  | 5,362 |  |  |  | (2,858 | ) |  |  | 2,504 |  |
| Inventories |  |  | (13,981 | ) |  |  | 5,745 |  |  |  | (8,236 | ) |
| Other accrued liabilities |  |  | (559 | ) |  |  | (2,585 | ) |  |  | (3,144 | ) |
| Net cash provided by operating activities |  | $ | 55,674 |  |  | $ | (1,398 | ) |  | $ | 54,276 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 1,398 |  |  | $ | 1,398 |  |
| Net cash used in investing activities |  | $ | (8,825 | ) |  | $ | 1,398 |  |  | $ | (7,427 | ) |

- removed (2018-08-07):
[0001437749-18-008863:note_history:15]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- removed (2018-08-07):
[0001437749-18-008863:note_history:16]
Derivatives and Hedging

- removed (2018-08-07):
[0001437749-18-008863:note_history:17]
–

- removed (2018-08-07):
[0001437749-18-008863:note_history:18]
| Condensed Consolidated Statement of Cash Flows |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 12,849 |  |  | $ | (667 | ) |  | $ | 12,182 |  |
| Deferred income taxes |  |  | 6,958 |  |  |  | (428 | ) |  |  | 6,530 |  |
| Accounts receivable |  |  | 19,973 |  |  |  | 395 |  |  |  | 20,368 |  |
| Inventories |  |  | (35,338 | ) |  |  | (337 | ) |  |  | (35,675 | ) |
| Other accrued liabilities |  |  | (305 | ) |  |  | 408 |  |  |  | 103 |  |
| Net cash used in operating activities |  | $ | (4,546 | ) |  | $ | (629 | ) |  | $ | (5,175 | ) |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 629 |  |  | $ | 629 |  |
| Net cash provided by (used in) investing activities |  | $ | (1,903 | ) |  | $ | 629 |  |  | $ | (1,274 | ) |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001437749-18-014736:note_history:19]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,995 |  |  |  | 20,602 |  |
| Total |  | $ | 23,995 |  |  | $ | 20,602 |  |
  (was, 2018-05-07, similarity 0.9742):
[0001437749-18-008863:note_history:19]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,414 |  |  |  | 20,602 |  |
| Total |  | $ | 31,414 |  |  | $ | 20,602 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:20]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (24,682 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,251 |  |  |  | 4,690 |  |
| Other |  |  | 869 |  |  |  | 1,367 |  |
| Total |  |  | 909,438 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 758 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 614 |  |  |  | 636 |  |
| Total |  | $ | 908,066 |  |  | $ | 906,548 |  |

- changed (2018-08-07):
[0001437749-18-014736:note_history:21]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans was reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, fell below 
3.00
 to 
1.00
 for that measurement period.
  (was, 2018-05-07, similarity 0.9167):
[0001437749-18-008863:note_history:21]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

- changed (2018-08-07):
[0001437749-18-014736:note_history:22]
In 
 December 2017, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminated future related payment requirements if the Company’s secured leverage ratio was maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in the 
fourth
 quarter of 
2017.
  (was, 2018-05-07, similarity 0.6453):
[0001437749-18-008863:note_history:22]
In 
 December 2017, 
the Company once again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminates future related payment requirements if the Company’s secured leverage ratio is maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in 
fourth
 quarter of 
2017.

- added (2018-08-07):
[0001437749-18-014736:note_history:23]
In 
 June 2018, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$829
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2018.

- changed (2018-08-07):
[0001437749-18-014736:note_history:24]
As of 
 June 30, 2018, 
the Company’s secured leverage ratio was 
2.11
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.
  (was, 2018-05-07, similarity 0.9771):
[0001437749-18-008863:note_history:24]
As of 
 March 31, 2018, 
the Company’s secured leverage ratio was 
2.47
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

- added (2018-08-07):
[0001437749-18-014736:note_history:25]
The Company’s credit agreements also originally provided for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility), with a maturity date of 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings originally bore interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

- added (2018-08-07):
[0001437749-18-014736:note_history:26]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$615
 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

- added (2018-08-07):
[0001437749-18-014736:note_history:27]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of 
 June 30, 2018, 
there was 
$50,000
 outstanding under the Amended ABL Facility, leaving 
$192,217
 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2018-08-07):
[0001437749-18-014736:note_history:28]
As of 
 June 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$23,995
 and 
$20,602,
 respectively.
  (was, 2018-05-07, similarity 0.9735):
[0001437749-18-008863:note_history:28]
As of 
 March 31, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$31,414
 and 
$20,602,
 respectively.

- removed (2018-08-07):
[0001437749-18-008863:note_history:29]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,760 | ) |  |  | (26,937 | ) |
| Capital lease obligation |  |  | 4,650 |  |  |  | 4,690 |  |
| Other |  |  | 1,162 |  |  |  | 1,367 |  |
| Total |  |  | 909,052 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 944 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 649 |  |  |  | 636 |  |
| Total |  | $ | 907,459 |  |  | $ | 906,548 |  |

- removed (2018-08-07):
[0001437749-18-008863:note_history:30]
The Company’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility. 
No
 amounts were outstanding under the ABL Facility at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-08-07):
[0001437749-18-014736:note_history:31]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (24,682 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,251 |  |  |  | 4,690 |  |
| Other |  |  | 869 |  |  |  | 1,367 |  |
| Total |  |  | 909,438 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 758 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 614 |  |  |  | 636 |  |
| Total |  | $ | 908,066 |  |  | $ | 906,548 |  |

- removed (2018-08-07):
[0001437749-18-008863:note_history:32]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,760 | ) |  |  | (26,937 | ) |
| Capital lease obligation |  |  | 4,650 |  |  |  | 4,690 |  |
| Other |  |  | 1,162 |  |  |  | 1,367 |  |
| Total |  |  | 909,052 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 944 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 649 |  |  |  | 636 |  |
| Total |  | $ | 907,459 |  |  | $ | 906,548 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001437749-18-014736:note_history:33]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,995 |  |  |  | 20,602 |  |
| Total |  | $ | 23,995 |  |  | $ | 20,602 |  |
  (was, 2018-05-07, similarity 0.9742):
[0001437749-18-008863:note_history:33]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,414 |  |  |  | 20,602 |  |
| Total |  | $ | 31,414 |  |  | $ | 20,602 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-07):
[0001437749-18-014736:note_history:34]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 26,395 |  |  |  | 6,528 |  |  |  | 32,923 |  |
| Total net sales |  | $ | 381,047 |  |  | $ | 113,902 |  |  | $ | 494,949 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:35]
|  |  | Three Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 185,114 |  |  | $ | 13,354 |  |  | $ | 198,468 |  |
| Commercial & industrial products |  |  | 98,909 |  |  |  | 70,994 |  |  |  | 169,903 |  |
| Other |  |  | 21,383 |  |  |  | 5,121 |  |  |  | 26,504 |  |
| Total net sales |  | $ | 305,406 |  |  | $ | 89,469 |  |  | $ | 394,875 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:36]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 52,158 |  |  |  | 12,800 |  |  |  | 64,958 |  |
| Total net sales |  | $ | 681,266 |  |  | $ | 211,317 |  |  | $ | 892,583 |  |

- added (2018-08-07):
[0001437749-18-014736:note_history:37]
|  |  | Six Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 326,815 |  |  | $ | 25,870 |  |  | $ | 352,685 |  |
| Commercial & industrial products |  |  | 183,674 |  |  |  | 136,982 |  |  |  | 320,656 |  |
| Other |  |  | 42,085 |  |  |  | 9,934 |  |  |  | 52,019 |  |
| Total net sales |  | $ | 552,574 |  |  | $ | 172,786 |  |  | $ | 725,360 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001437749-18-014736:note_history:38]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company’s contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.
  (was, 2018-05-07, similarity 0.9332):
[0001437749-18-008863:note_history:38]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers, and therefore are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time, and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment; and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company's contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

- changed (2018-08-07):
[0001437749-18-014736:note_history:39]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$20,643
 and 
$7,034
 at 
 June 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
six
 month period ended 
 June 30, 2018, 
the Company recognized revenue of 
$5,812
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.
  (was, 2018-05-07, similarity 0.7359):
[0001437749-18-008863:note_history:39]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheet as accounts receivable, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheet. The balance of customer deposits (contract liability) was 
$8,028
 and 
$7,034
 at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

- changed (2018-08-07):
[0001437749-18-014736:note_history:40]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.
  (was, 2018-05-07, similarity 0.9991):
[0001437749-18-008863:note_history:40]
The Company offers standard warranty coverage on substantially all products that it sells, and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.

- changed (2018-08-07):
[0001437749-18-014736:note_history:41]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
-party marketing agreement, it is required to pay fees to the 
third
-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheets. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
10,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.
  (was, 2018-05-07, similarity 0.6427):
[0001437749-18-008863:note_history:41]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation and extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets, and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
 party marketing agreement, it is required to pay fees to the 
third
-party service provider, and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheet. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statement of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.

- changed (2018-08-07):
[0001437749-18-014736:note_history:42]
Refer to Note 
8,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.
  (was, 2018-05-07, similarity 0.9956):
[0001437749-18-008863:note_history:42]
Refer to Note 
7,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company's product classes.
