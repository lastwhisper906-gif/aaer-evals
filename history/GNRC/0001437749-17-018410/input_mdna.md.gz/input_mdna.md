# GNRC MD&A — 0001437749-17-018410


## mdna

[0001437749-17-018410:mdna:1]
[same as prior period, unchanged from 0001437749-17-013821:mdna:1]

[0001437749-17-018410:mdna:2]
[same as prior period, unchanged from 0001437749-17-013821:mdna:2]

[0001437749-17-018410:mdna:3]
[same as prior period, unchanged from 0001437749-17-013821:mdna:3]

[0001437749-17-018410:mdna:4]
[same as prior period, unchanged from 0001437749-17-013821:mdna:4]

[0001437749-17-018410:mdna:5]
[same as prior period, unchanged from 0001437749-17-013821:mdna:5]

[0001437749-17-018410:mdna:6]
[same as prior period, unchanged from 0001437749-17-013821:mdna:6]

[0001437749-17-018410:mdna:7]
[same as prior period, unchanged from 0001437749-17-013821:mdna:7]

[0001437749-17-018410:mdna:8]
[same as prior period, unchanged from 0001437749-17-013821:mdna:8]

[0001437749-17-018410:mdna:9]
[same as prior period, unchanged from 0001437749-17-013821:mdna:9]

[0001437749-17-018410:mdna:10]
[same as prior period, unchanged from 0001437749-17-013821:mdna:10]

[0001437749-17-018410:mdna:11]
[same as prior period, unchanged from 0001437749-17-013821:mdna:11]

[0001437749-17-018410:mdna:12]
[same as prior period, unchanged from 0001437749-17-013821:mdna:12]

[0001437749-17-018410:mdna:13]
[same as prior period, unchanged from 0001437749-17-013821:mdna:13]

[0001437749-17-018410:mdna:14]
[same as prior period, unchanged from 0001437749-17-013821:mdna:14]

[0001437749-17-018410:mdna:15]
[same as prior period, unchanged from 0001437749-17-013821:mdna:15]

[0001437749-17-018410:mdna:16]
[same as prior period, unchanged from 0001437749-17-013821:mdna:16]

[0001437749-17-018410:mdna:17]
[same as prior period, unchanged from 0001437749-17-013821:mdna:17]

[0001437749-17-018410:mdna:18]
[same as prior period, unchanged from 0001437749-17-013821:mdna:18]

[0001437749-17-018410:mdna:19]
[same as prior period, unchanged from 0001437749-17-013821:mdna:19]

[0001437749-17-018410:mdna:20]
[same as prior period, unchanged from 0001437749-17-013821:mdna:20]

[0001437749-17-018410:mdna:21]
[same as prior period, unchanged from 0001437749-17-013821:mdna:21]

[0001437749-17-018410:mdna:22]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-17-018410:mdna:23]
Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q, and in Item 8 (Note 1 “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-018410:mdna:24]
[same as prior period, unchanged from 0001437749-17-013821:mdna:24]

[0001437749-17-018410:mdna:25]
[same as prior period, unchanged from 0001437749-17-013821:mdna:25]

[0001437749-17-018410:mdna:26]
[same as prior period, unchanged from 0001437749-17-013821:mdna:26]

[0001437749-17-018410:mdna:27]
[same as prior period, unchanged from 0001437749-17-013821:mdna:27]

[0001437749-17-018410:mdna:28]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-17-018410:mdna:29]
[same as prior period, unchanged from 0001437749-17-013821:mdna:29]

[0001437749-17-018410:mdna:30]
[same as prior period, unchanged from 0001437749-17-013821:mdna:30]

[0001437749-17-018410:mdna:31]
[same as prior period, unchanged from 0001437749-17-013821:mdna:31]

[0001437749-17-018410:mdna:32]
[same as prior period, unchanged from 0001437749-17-013821:mdna:32]

[0001437749-17-018410:mdna:33]
[same as prior period, unchanged from 0001437749-17-013821:mdna:33]

[0001437749-17-018410:mdna:34]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, with the Pramac acquisition in 2016, we have further expanded our commercial and operational presence outside of the United States. This acquisition, along with our other international operations, exposes us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-17-018410:mdna:35]
[same as prior period, unchanged from 0001437749-17-013821:mdna:35]

[0001437749-17-018410:mdna:36]
[same as prior period, unchanged from 0001437749-17-013821:mdna:36]

[0001437749-17-018410:mdna:37]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, and repayments or borrowings of indebtedness. Cash interest expense decreased during the nine months ended September 30, 2017 compared to the nine months ended September 30, 2016, primarily due to the $25 million voluntary prepayment of Term Loan debt in November 2016, the May 2017 Term Loan refinancing and decreased borrowings at other subsidiaries, partially offset by an increase in the LIBOR rate. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-17-018410:mdna:38]
[same as prior period, unchanged from 0001437749-17-013821:mdna:38]

[0001437749-17-018410:mdna:39]
[same as prior period, unchanged from 0001437749-17-013821:mdna:39]

[0001437749-17-018410:mdna:40]
Three months ended September 30, 2017 compared to the three months ended September 30, 2016

[0001437749-17-018410:mdna:41]
[same as prior period, unchanged from 0001437749-17-013821:mdna:41]

[0001437749-17-018410:mdna:42]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 84,132 |  |  |  | 22.5% |  |
| Cost of goods sold |  |  | 299,784 |  |  |  | 235,349 |  |  |  | 64,435 |  |  |  | 27.4% |  |
| Gross profit |  |  | 157,469 |  |  |  | 137,772 |  |  |  | 19,697 |  |  |  | 14.3% |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 44,402 |  |  |  | 44,429 |  |  |  | (27) |  |  |  | -0.1% |  |
| Research and development |  |  | 10,864 |  |  |  | 9,426 |  |  |  | 1,438 |  |  |  | 15.3% |  |
| General and administrative |  |  | 22,102 |  |  |  | 18,066 |  |  |  | 4,036 |  |  |  | 22.3% |  |
| Amortization of intangible assets |  |  | 7,242 |  |  |  | 9,511 |  |  |  | (2,269) |  |  |  | -23.9% |  |
| Total operating expenses |  |  | 84,610 |  |  |  | 81,432 |  |  |  | 3,178 |  |  |  | 3.9% |  |
| Income from operations |  |  | 72,859 |  |  |  | 56,340 |  |  |  | 16,519 |  |  |  | 29.3% |  |
| Total other expense, net |  |  | (12,228) |  |  |  | (14,814) |  |  |  | 2,586 |  |  |  | -17.5% |  |
| Income before provision for income taxes |  |  | 60,631 |  |  |  | 41,526 |  |  |  | 19,105 |  |  |  | 46.0% |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 5,067 |  |  |  | 32.7% |  |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 14,038 |  |  |  | 54.0% |  |
| Net income attributable to noncontrolling interests |  |  | 341 |  |  |  | (171) |  |  |  | 512 |  |  |  | -299.4% |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 13,526 |  |  |  | 51.7% |  |

[0001437749-17-018410:mdna:43]
[same as prior period, unchanged from 0001437749-17-013821:mdna:43]

[0001437749-17-018410:mdna:44]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 364,323 |  |  | $ | 299,095 |  |  | $ | 65,228 |  |  |  | 21.8% |  |
| International |  |  | 92,930 |  |  |  | 74,026 |  |  |  | 18,904 |  |  |  | 25.5% |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 84,132 |  |  |  | 22.5% |  |

[0001437749-17-018410:mdna:45]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 83,128 |  |  | $ | 69,309 |  |  | $ | 13,819 |  |  |  | 19.9% |  |
| International |  |  | 5,625 |  |  |  | 3,527 |  |  |  | 2,098 |  |  |  | 59.5% |  |
| Total Adjusted EBITDA |  | $ | 88,753 |  |  | $ | 72,836 |  |  | $ | 15,917 |  |  |  | 21.9% |  |

[0001437749-17-018410:mdna:46]
17

[0001437749-17-018410:mdna:47]
[same as prior period, unchanged from 0001437749-17-013821:mdna:46]

[0001437749-17-018410:mdna:48]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 251,921 |  |  | $ | 192,856 |  |  | $ | 59,065 |  |  |  | 30.6% |  |
| Commercial & industrial products |  |  | 174,538 |  |  |  | 149,676 |  |  |  | 24,862 |  |  |  | 16.6% |  |
| Other |  |  | 30,794 |  |  |  | 30,589 |  |  |  | 205 |  |  |  | 0.7% |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 84,132 |  |  |  | 22.5% |  |

[0001437749-17-018410:mdna:49]
Net sales.    The increase in Domestic sales for the three months ended September 30, 2017 was primarily due to substantial growth in shipments of portable generators driven by increased outage activity from Hurricanes Harvey, Irma and Maria; along with the continuation of very strong growth for mobile products. Additionally, there were increases in shipments of home standby generators and specialty outdoor power equipment.

[0001437749-17-018410:mdna:50]
The increase in International sales for the three months ended September 30, 2017 was primarily due to the contribution from the recent acquisition of Motortech. The growth was also due to increased organic shipments of both C&I and residential products within the European and Latin America regions, along with the favorable impact of a stronger Euro as compared to the prior year.

[0001437749-17-018410:mdna:51]
The total net sales contribution from non-annualized recent acquisitions to the three months ended September 30, 2017 was $10.1 million.

[0001437749-17-018410:mdna:52]
Gross profit.    Gross profit margin for the third quarter of 2017 was 34.4% compared to 36.9% in the prior-year third quarter. The decrease in gross margin as compared to the prior year was primarily due to unfavorable sales mix attributable to significantly higher sales of portable generators and mobile products relative to the prior year, which carry lower gross margins relative to the consolidated average.

[0001437749-17-018410:mdna:53]
Operating expenses.    The increase in operating expenses was primarily driven by the addition of recurring operating expenses associated with the Motortech acquisition and additional incentive compensation accrued during the current-year quarter. Partially offsetting these impacts was a decline in amortization of intangibles.

[0001437749-17-018410:mdna:54]
Other expense.    The decrease in other expense was primarily due to a prior-year $3.0 million non-cash loss on change in contractual interest rate not repeating; and a decrease in interest expense due to the $25.0 million voluntary prepayment of Term Loan debt in November 2016, the May 2017 Term Loan refinancing and decreased borrowings at other subsidiaries. These impacts were partially offset by an increase in foreign currency transactional losses.

[0001437749-17-018410:mdna:55]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2017 and 2016 were 33.9% and 37.4%, respectively. The decrease in the effective income tax rate is due to non-recurring discrete tax items that favorably impacted the current year and unfavorably impacted the prior year.

[0001437749-17-018410:mdna:56]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-17-018410:mdna:57]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the three months ended September 30, 2017 were 22.8% of net sales compared to 23.2% in the prior-year third quarter. Adjusted EBITDA margin in the current year was impacted by unfavorable sales mix due to significantly higher sales of portable generators and mobile products relative to prior year. These impacts were largely offset by improved overall leverage of fixed operating expenses on the organic increase in sales.

[0001437749-17-018410:mdna:58]
Adjusted EBITDA margins for the International segment, before deducting for noncontrolling interests, for the three months ended September 30, 2017 were 6.1% of net sales compared to 4.8% in the prior-year third quarter. The improvement was primarily due to improved leverage of fixed manufacturing and operating expenses on the organic increase in sales. These impacts were partially offset by unfavorable foreign currency effects.

[0001437749-17-018410:mdna:59]
Adjusted Net Income.    Adjusted Net Income of $57.8 million for the three months ended September 30, 2017 increased 8.6% from $53.2 million for the three months ended September 30, 2016, due to the factors outlined above, partially offset by an increase in cash income tax expense and an increase in adjusted net income attributable to noncontrolling interests.

[0001437749-17-018410:mdna:60]
[same as prior period, unchanged from 0001437749-17-013821:mdna:59]

[0001437749-17-018410:mdna:61]
Nine months ended September 30, 2017 compared to the nine months ended September 30, 2016

[0001437749-17-018410:mdna:62]
[same as prior period, unchanged from 0001437749-17-013821:mdna:61]

[0001437749-17-018410:mdna:63]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |  | $ | 157,411 |  |  |  | 15.3% |  |
| Cost of goods sold |  |  | 782,028 |  |  |  | 667,053 |  |  |  | 114,975 |  |  |  | 17.2% |  |
| Gross profit |  |  | 402,415 |  |  |  | 359,979 |  |  |  | 42,436 |  |  |  | 11.8% |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 127,702 |  |  |  | 124,064 |  |  |  | 3,638 |  |  |  | 2.9% |  |
| Research and development |  |  | 31,732 |  |  |  | 27,512 |  |  |  | 4,220 |  |  |  | 15.3% |  |
| General and administrative |  |  | 64,436 |  |  |  | 55,492 |  |  |  | 8,944 |  |  |  | 16.1% |  |
| Amortization of intangible assets |  |  | 21,554 |  |  |  | 25,525 |  |  |  | (3,971) |  |  |  | -15.6% |  |
| Total operating expenses |  |  | 245,424 |  |  |  | 232,593 |  |  |  | 12,831 |  |  |  | 5.5% |  |
| Income from operations |  |  | 156,991 |  |  |  | 127,386 |  |  |  | 29,605 |  |  |  | 23.2% |  |
| Total other expense, net |  |  | (35,401) |  |  |  | (37,065) |  |  |  | 1,664 |  |  |  | -4.5% |  |
| Income before provision for income taxes |  |  | 121,590 |  |  |  | 90,321 |  |  |  | 31,269 |  |  |  | 34.6% |  |
| Provision for income taxes |  |  | 42,946 |  |  |  | 33,154 |  |  |  | 9,792 |  |  |  | 29.5% |  |
| Net income |  |  | 78,644 |  |  |  | 57,167 |  |  |  | 21,477 |  |  |  | 37.6% |  |
| Net income attributable to noncontrolling interests |  |  | 433 |  |  |  | (112) |  |  |  | 545 |  |  |  | -486.6% |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 78,211 |  |  | $ | 57,279 |  |  | $ | 20,932 |  |  |  | 36.5% |  |

[0001437749-17-018410:mdna:64]
[same as prior period, unchanged from 0001437749-17-013821:mdna:63]

[0001437749-17-018410:mdna:65]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 918,727 |  |  | $ | 833,831 |  |  | $ | 84,896 |  |  |  | 10.2% |  |
| International |  |  | 265,716 |  |  |  | 193,201 |  |  |  | 72,515 |  |  |  | 37.5% |  |
| Total net sales |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |  | $ | 157,411 |  |  |  | 15.3% |  |

[0001437749-17-018410:mdna:66]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 190,131 |  |  | $ | 173,521 |  |  | $ | 16,610 |  |  |  | 9.6% |  |
| International |  |  | 16,471 |  |  |  | 13,050 |  |  |  | 3,421 |  |  |  | 26.2% |  |
| Total Adjusted EBITDA |  | $ | 206,602 |  |  | $ | 186,571 |  |  | $ | 20,031 |  |  |  | 10.7% |  |

[0001437749-17-018410:mdna:67]
[same as prior period, unchanged from 0001437749-17-013821:mdna:66]

[0001437749-17-018410:mdna:68]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 604,894 |  |  | $ | 533,572 |  |  | $ | 71,322 |  |  |  | 13.4% |  |
| Commercial & industrial products |  |  | 496,736 |  |  |  | 409,396 |  |  |  | 87,340 |  |  |  | 21.3% |  |
| Other |  |  | 82,813 |  |  |  | 84,064 |  |  |  | (1,251 | ) |  |  | -1.5% |  |
| Total net sales |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |  | $ | 157,411 |  |  |  | 15.3% |  |

[0001437749-17-018410:mdna:69]
Net sales.    The increase in Domestic sales for the nine months ended September 30, 2017 was primarily due to strong growth in shipments of portable generators driven by increased outage activity, along with strong growth for mobile products. Additionally, there were increases in shipments of home standby generators and specialty outdoor power equipment.

[0001437749-17-018410:mdna:70]
The increase in International sales for the nine months ended September 30, 2017 was primarily due to the contribution from the recent acquisitions of Pramac and Motortech. The growth was also due to increased organic shipments of both C&I and residential products within the European and Latin America regions, along with the favorable impact of a stronger Euro as compared to the prior year.

[0001437749-17-018410:mdna:71]
The total net sales contribution from non-annualized recent acquisitions to the nine months ended September 30, 2017 was $60.1 million.

[0001437749-17-018410:mdna:72]
Gross profit.    Gross profit margin for the first nine months of 2017 was 34.0% compared to 35.1% in the first nine months of 2016. The prior year included $2.7 million of business optimization and restructuring costs classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry, as well as $3.4 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these charges, pro-forma gross margin in the prior-year was 35.7%. This pro-forma decline in gross margin as compared to the prior year was due to the mix impact from the Pramac and Motortech acquisitions, unfavorable sales mix attributable to higher sales of portable generators and mobile products relative to prior year, higher commodity prices seen in prior quarters and certain plant consolidation costs. These impacts were partially offset by improved leverage of fixed manufacturing costs on the higher organic sales and net favorable pricing impacts.

[0001437749-17-018410:mdna:73]
Operating expenses.    Operating expenses increased $12.8 million, or 5.5%, as compared to the first nine months of 2016. The prior-year included $4.4 million of business optimization and restructuring costs classified within operating expenses to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $17.2 million, or 7.6%, as compared to the prior year. This increase was primarily driven by the addition of recurring operating expenses associated with the recent acquisitions of Pramac and Motortech, and additional incentive compensation accrued during the current year, partially offset by a decline in amortization of intangibles.

[0001437749-17-018410:mdna:74]
Other expense.    The decrease in other expense was primarily due to a prior-year $3.0 million non-cash loss on change in contractual interest rate not repeating, and a decrease in interest expense due to the $25.0 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other subsidiaries. These impacts were partially offset by an increase in foreign currency transactional losses.

[0001437749-17-018410:mdna:75]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2017 and 2016 were 35.3% and 36.7%, respectively. The decrease in the effective income tax rate is due to non-recurring discrete tax items.

[0001437749-17-018410:mdna:76]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-17-018410:mdna:77]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the nine months ended September 30, 2017 were 20.7% of net sales compared to 20.8% for the nine months ended September 30, 2016. Adjusted EBITDA margins decreased due to unfavorable sales mix and higher commodity prices seen in prior quarters, mostly offset by improved overall leverage of fixed operating expenses on the organic increase in sales, and the net favorable impact of higher pricing.

[0001437749-17-018410:mdna:78]
Adjusted EBITDA margins for the International segment, before deducting for noncontrolling interests, for the nine months ended September 30, 2017 were 6.2% of net sales compared to 6.8% for the nine months ended September 30, 2016. The decline was primarily due to the Pramac acquisition, unfavorable foreign currency impacts, higher commodity prices and increased overall operating expenses including the expansion of branch operations. These impacts were partially offset by improved leverage of fixed manufacturing and operating expenses on the organic increase in sales along with the addition of the Motortech acquisition.

[0001437749-17-018410:mdna:79]
Adjusted Net Income.    Adjusted Net Income of $126.9 million for the nine months ended September 30, 2017 increased 0.1% from $126.8 million for the nine months ended September 30, 2016, due to the factors outlined, partially offset by an increase in cash income tax expense.

[0001437749-17-018410:mdna:80]
[same as prior period, unchanged from 0001437749-17-013821:mdna:79]

[0001437749-17-018410:mdna:81]
[same as prior period, unchanged from 0001437749-17-013821:mdna:80]

[0001437749-17-018410:mdna:82]
[same as prior period, unchanged from 0001437749-17-013821:mdna:81]

[0001437749-17-018410:mdna:83]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. Following the amendment in May 2017, the Term Loan bears interest at rates based upon either a base rate plus a fixed applicable margin of 1.25% or adjusted LIBOR rate plus a fixed applicable margin of 2.25%, subject to a LIBOR floor of 0.75%. As of September 30, 2017, we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-018410:mdna:84]
Our credit agreements also provide for the $250.0 million ABL Facility. The maturity date of the ABL Facility is May 29, 2020. In May 2015, we borrowed $100.0 million under the ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of September 30, 2017, there was $100.0 million outstanding under the ABL Facility, and we were in compliance with all of its covenants. In October 2017, we repaid $90.0 million of the outstanding ABL Facility balance.

[0001437749-17-018410:mdna:85]
At September 30, 2017, we had cash and cash equivalents on hand of $128.8 million and $142.2 million of availability under our ABL Facility, net of outstanding letters of credit.

[0001437749-17-018410:mdna:86]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. For the nine months ended September 30, 2017, the Company repurchased 844,500 shares of its common stock for $30.0 million. Since the inception of both programs, we have repurchased 8,116,706 shares of our common stock for $279.9 million, all funded with cash on hand.

[0001437749-17-018410:mdna:87]
[same as prior period, unchanged from 0001437749-17-013821:mdna:86]

[0001437749-17-018410:mdna:88]
[same as prior period, unchanged from 0001437749-17-013821:mdna:87]

[0001437749-17-018410:mdna:89]
[same as prior period, unchanged from 0001437749-17-013821:mdna:88]

[0001437749-17-018410:mdna:90]
[same as prior period, unchanged from 0001437749-17-013821:mdna:89]

[0001437749-17-018410:mdna:91]
Nine months ended September 30, 2017 compared to the nine months ended September 30, 2016

[0001437749-17-018410:mdna:92]
[same as prior period, unchanged from 0001437749-17-013821:mdna:91]

[0001437749-17-018410:mdna:93]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 122,719 |  |  | $ | 129,513 |  |  | $ | (6,794) |  |  |  | -5.2% |  |
| Net cash used in investing activities |  |  | (15,324) |  |  |  | (80,884) |  |  |  | 65,560 |  |  |  | -81.1% |  |
| Net cash used in financing activities |  |  | (48,782) |  |  |  | (110,667) |  |  |  | 61,885 |  |  |  | -55.9% |  |

[0001437749-17-018410:mdna:94]
The decrease in net cash from operating activities was primarily driven by more of a working capital investment during the current year as compared to the prior year as we replenished inventory levels in the first quarter of 2017 following Hurricane Matthew, and ramped production in the third quarter of 2017 in response to Hurricanes Harvey, Irma and Maria. This decrease is partially offset by an increase in operating income.

[0001437749-17-018410:mdna:95]
Net cash used in investing activities for the nine months ended September 30, 2017 primarily represents cash payments for the purchase of property and equipment. Net cash used in investing activities for the nine months ended September 30, 2016 primarily represents cash payments of $60.9 million related to the acquisition of Pramac and $20.8 million for the purchase of property and equipment. The Motortech acquisition was completed in the first quarter of 2017, but was funded in the fourth quarter of 2016.

[0001437749-17-018410:mdna:96]
Net cash used in financing activities for the nine months ended September 30, 2017 primarily represents $94.0 million of debt repayments ($80.9 million of short-term borrowings and $13.1 million of long-term borrowings) and $30.0 million of payments for the repurchase of the Company’s common stock. These payments were partially offset by $77.5 million cash proceeds from borrowings ($74.4 million short-term and $3.1 million long-term).

[0001437749-17-018410:mdna:97]
Net cash used in financing activities for the nine months ended September 30, 2016 primarily represents $99.9 million of payments for the repurchase of the Company’s common stock, $19.2 million of debt repayments ($11.0 million of long-term borrowings and $8.2 million of short-term borrowings) and $12.3 million related to the net share settlement of equity awards. These payments were partially offset by $14.1 million cash proceeds from short-term borrowings and a $6.8 million cash inflow related to excess tax benefits of equity awards.

[0001437749-17-018410:mdna:98]
[same as prior period, unchanged from 0001437749-17-013821:mdna:97]

[0001437749-17-018410:mdna:99]
In May 2017, the Company amended its Term Loan, which reduces future interest payments on the Term Loan. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements for further information. In addition, in October 2017, we repaid $90.0 million of the outstanding ABL Facility balance. Other than the Term Loan amendment and ABL principal payment, there have been no material changes to our contractual obligations since the February 24, 2017 filing of our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-018410:mdna:100]
[same as prior period, unchanged from 0001437749-17-013821:mdna:99]

[0001437749-17-018410:mdna:101]
[same as prior period, unchanged from 0001437749-17-013821:mdna:100]

[0001437749-17-018410:mdna:102]
[same as prior period, unchanged from 0001437749-17-013821:mdna:101]

[0001437749-17-018410:mdna:103]
[same as prior period, unchanged from 0001437749-17-013821:mdna:102]

[0001437749-17-018410:mdna:104]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2016, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of product warranty and other contingencies; income taxes and share based compensation.

[0001437749-17-018410:mdna:105]
[same as prior period, unchanged from 0001437749-17-013821:mdna:104]

[0001437749-17-018410:mdna:106]
[same as prior period, unchanged from 0001437749-17-013821:mdna:105]

[0001437749-17-018410:mdna:107]
[same as prior period, unchanged from 0001437749-17-013821:mdna:106]

[0001437749-17-018410:mdna:108]
[same as prior period, unchanged from 0001437749-17-013821:mdna:107]

[0001437749-17-018410:mdna:109]
[same as prior period, unchanged from 0001437749-17-013821:mdna:108]

[0001437749-17-018410:mdna:110]
[same as prior period, unchanged from 0001437749-17-013821:mdna:109]

[0001437749-17-018410:mdna:111]
[same as prior period, unchanged from 0001437749-17-013821:mdna:110]

[0001437749-17-018410:mdna:112]
[same as prior period, unchanged from 0001437749-17-013821:mdna:111]

[0001437749-17-018410:mdna:113]
[same as prior period, unchanged from 0001437749-17-013821:mdna:112]

[0001437749-17-018410:mdna:114]
[same as prior period, unchanged from 0001437749-17-013821:mdna:113]

[0001437749-17-018410:mdna:115]
[same as prior period, unchanged from 0001437749-17-013821:mdna:114]

[0001437749-17-018410:mdna:116]
[same as prior period, unchanged from 0001437749-17-013821:mdna:115]

[0001437749-17-018410:mdna:117]
[same as prior period, unchanged from 0001437749-17-013821:mdna:116]

[0001437749-17-018410:mdna:118]
[same as prior period, unchanged from 0001437749-17-013821:mdna:117]

[0001437749-17-018410:mdna:119]
[same as prior period, unchanged from 0001437749-17-013821:mdna:118]

[0001437749-17-018410:mdna:120]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-17-018410:mdna:121]
[same as prior period, unchanged from 0001437749-17-013821:mdna:120]

[0001437749-17-018410:mdna:122]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-17-018410:mdna:123]
[same as prior period, unchanged from 0001437749-17-013821:mdna:122]

[0001437749-17-018410:mdna:124]
[same as prior period, unchanged from 0001437749-17-013821:mdna:123]

[0001437749-17-018410:mdna:125]
[same as prior period, unchanged from 0001437749-17-013821:mdna:124]

[0001437749-17-018410:mdna:126]
[same as prior period, unchanged from 0001437749-17-013821:mdna:125]

[0001437749-17-018410:mdna:127]
[same as prior period, unchanged from 0001437749-17-013821:mdna:126]

[0001437749-17-018410:mdna:128]
[same as prior period, unchanged from 0001437749-17-013821:mdna:127]

[0001437749-17-018410:mdna:129]
[same as prior period, unchanged from 0001437749-17-013821:mdna:128]

[0001437749-17-018410:mdna:130]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-17-018410:mdna:131]
[same as prior period, unchanged from 0001437749-17-013821:mdna:130]

[0001437749-17-018410:mdna:132]
[same as prior period, unchanged from 0001437749-17-013821:mdna:131]

[0001437749-17-018410:mdna:133]
[same as prior period, unchanged from 0001437749-17-013821:mdna:132]

[0001437749-17-018410:mdna:134]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Net income attributable to noncontrolling interests (a) |  |  | 341 |  |  |  | (171) |  |  |  | 433 |  |  |  | (112) |  |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 78,644 |  |  |  | 57,167 |  |
| Interest expense |  |  | 10,672 |  |  |  | 11,299 |  |  |  | 32,353 |  |  |  | 33,714 |  |
| Depreciation and amortization |  |  | 13,108 |  |  |  | 14,900 |  |  |  | 38,691 |  |  |  | 41,343 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 42,946 |  |  |  | 33,154 |  |
| Non-cash write-down and other adjustments (b) |  |  | 756 |  |  |  | (1,093) |  |  |  | 2,632 |  |  |  | 1,689 |  |
| Non-cash share-based compensation expense (c) |  |  | 2,584 |  |  |  | 2,419 |  |  |  | 8,402 |  |  |  | 7,805 |  |
| Loss on change in contractual interest rate (d) |  |  | - |  |  |  | 2,957 |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and credit facility fees (e) |  |  | 234 |  |  |  | 739 |  |  |  | 970 |  |  |  | 1,499 |  |
| Business optimization expenses (f) |  |  | 487 |  |  |  | 58 |  |  |  | 1,933 |  |  |  | 7,164 |  |
| Other |  |  | 281 |  |  |  | 31 |  |  |  | 31 |  |  |  | 79 |  |
| Adjusted EBITDA |  |  | 88,753 |  |  |  | 72,836 |  |  |  | 206,602 |  |  |  | 186,571 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,178 |  |  |  | 708 |  |  |  | 3,589 |  |  |  | 3,015 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 87,575 |  |  | $ | 72,128 |  |  | $ | 203,013 |  |  | $ | 183,556 |  |

[0001437749-17-018410:mdna:135]
(a)   Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.2 million and $3.4 million for the three and nine months ended September 30, 2017, respectively, and $1.3 million and $6.9 million for the three and nine months ended September 30, 2016, respectively.

[0001437749-17-018410:mdna:136]
[same as prior period, unchanged from 0001437749-17-013821:mdna:135]

[0001437749-17-018410:mdna:137]
[same as prior period, unchanged from 0001437749-17-013821:mdna:136]

[0001437749-17-018410:mdna:138]
[same as prior period, unchanged from 0001437749-17-013821:mdna:137]

[0001437749-17-018410:mdna:139]
[same as prior period, unchanged from 0001437749-17-013821:mdna:138]

[0001437749-17-018410:mdna:140]
[same as prior period, unchanged from 0001437749-17-013821:mdna:139]

[0001437749-17-018410:mdna:141]
(d) For the three and nine months ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time.

[0001437749-17-018410:mdna:142]
(e) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-17-018410:mdna:143]
(f) For the three and nine months ended September 30, 2017, represents severance and other non-recurring plant consolidation costs. For the three and nine months ended September 30, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-17-018410:mdna:144]
[same as prior period, unchanged from 0001437749-17-013821:mdna:142]

[0001437749-17-018410:mdna:145]
[same as prior period, unchanged from 0001437749-17-013821:mdna:143]

[0001437749-17-018410:mdna:146]
[same as prior period, unchanged from 0001437749-17-013821:mdna:144]

[0001437749-17-018410:mdna:147]
[same as prior period, unchanged from 0001437749-17-013821:mdna:145]

[0001437749-17-018410:mdna:148]
[same as prior period, unchanged from 0001437749-17-013821:mdna:146]

[0001437749-17-018410:mdna:149]
[same as prior period, unchanged from 0001437749-17-013821:mdna:147]

[0001437749-17-018410:mdna:150]
[same as prior period, unchanged from 0001437749-17-013821:mdna:148]

[0001437749-17-018410:mdna:151]
[same as prior period, unchanged from 0001437749-17-013821:mdna:149]

[0001437749-17-018410:mdna:152]
[same as prior period, unchanged from 0001437749-17-013821:mdna:150]

[0001437749-17-018410:mdna:153]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Net income attributable to noncontrolling interests |  |  | 341 |  |  |  | (171 | ) |  |  | 433 |  |  |  | (112 | ) |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 78,644 |  |  |  | 57,167 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 42,946 |  |  |  | 33,154 |  |
| Income before provision for income taxes |  |  | 60,631 |  |  |  | 41,526 |  |  |  | 121,590 |  |  |  | 90,321 |  |
| Amortization of intangible assets |  |  | 7,242 |  |  |  | 9,511 |  |  |  | 21,554 |  |  |  | 25,525 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,092 |  |  |  | 1,107 |  |  |  | 2,400 |  |  |  | 3,229 |  |
| Loss on change in contractual interest rate |  |  | - |  |  |  | 2,957 |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | (35 | ) |  |  | 469 |  |  |  | 979 |  |  |  | 5,159 |  |
| Business optimization expenses |  |  | 487 |  |  |  | 58 |  |  |  | 1,933 |  |  |  | 7,164 |  |
| Adjusted net income before provision for income taxes |  |  | 69,417 |  |  |  | 55,628 |  |  |  | 148,456 |  |  |  | 134,355 |  |
| Cash income tax expense (b) |  |  | (10,878 | ) |  |  | (2,325 | ) |  |  | (19,607 | ) |  |  | (5,595 | ) |
| Adjusted net income |  |  | 58,539 |  |  |  | 53,303 |  |  |  | 128,849 |  |  |  | 128,760 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 697 |  |  |  | 58 |  |  |  | 1,912 |  |  |  | 1,939 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 57,842 |  |  | $ | 53,245 |  |  | $ | 126,937 |  |  | $ | 126,821 |  |
| Adjusted net income per common share attributable to Generac Holdings, Inc. - diluted: |  | $ | 0.93 |  |  | $ | 0.82 |  |  | $ | 2.02 |  |  | $ | 1.92 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,316,788 |  |  |  | 65,126,117 |  |  |  | 62,703,269 |  |  |  | 65,992,127 |  |

[0001437749-17-018410:mdna:154]
[same as prior period, unchanged from 0001437749-17-013821:mdna:152]

[0001437749-17-018410:mdna:155]
(b) Amount for the three and nine months ended September 30, 2017 is based on an anticipated cash income tax rate of approximately 17% for the full year ended 2017. Amount for the three and nine months ended September 30, 2016 is based on an anticipated cash income tax rate of approximately 6% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-17-018410:mdna:156]
[same as prior period, unchanged from 0001437749-17-013821:mdna:154]

[0001437749-17-018410:mdna:157]
[same as prior period, unchanged from 0001437749-17-013821:mdna:155]
