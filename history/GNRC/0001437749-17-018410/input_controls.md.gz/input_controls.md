# GNRC 10-Q controls and the auditor's report


## item_4_controls

[0001437749-17-018410:item_4_controls:1]
Item 4.           Controls and Procedures

[0001437749-17-018410:item_4_controls:2]
Disclosure Controls and Procedures

[0001437749-17-018410:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) or 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended, or the Exchange Act. Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0001437749-17-018410:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001437749-17-018410:item_4_controls:5]
In March 2016, the Company acquired a 65% ownership interest in Pramac. As a result of the acquisition, we have reviewed the internal control structure of Pramac and are in the process of making appropriate changes as we incorporate our controls and procedures into the acquired business.

[0001437749-17-018410:item_4_controls:6]
In October 2017, a subsidiary of the Company implemented the new global enterprise resource planning (ERP) system. In connection with that ERP system implementation, we are updating our internal controls over financial reporting for that subsidiary, as necessary, to accommodate modifications to their business processes and accounting procedures. Additional implementations are expected to occur at the Company’s remaining locations over a multi-year period.

[0001437749-17-018410:item_4_controls:7]
Other than the continuing assessment of controls for the Pramac acquisition and ERP implementation noted above, there have been no changes during the three months ended September 30, 2017 in our internal control over financial reporting (as defined in Exchange Act Rule 13a-15(f)) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
