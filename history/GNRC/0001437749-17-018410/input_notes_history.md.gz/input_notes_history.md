# GNRC note change history — 0001437749-17-013821 → 0001437749-17-018410


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-06):
[0001437749-17-018410:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,500
 and 
$33,900,
 respectively.
  (was, 2017-08-04, similarity 0.9889):
[0001437749-17-013821:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,900
 and 
$33,900,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-06):
[0001437749-17-018410:note_history:2]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 and Item 
8
 (Note 
1
 “Description of Business”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:
  (was, 2017-08-04, similarity 0.7332):
[0001437749-17-013821:note_history:2]
and Item 
8
 (Note 
1
 “Description of Business”) 
of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:

- changed (2017-11-06):
[0001437749-17-018410:note_history:3]
The condensed conso
lidated balance sheet as of 
 September 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2017-08-04, similarity 0.9193):
[0001437749-17-013821:note_history:3]
The condensed conso
lidated balance sheet as of 
 June 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- changed (2017-11-06):
[0001437749-17-018410:note_history:4]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company has substantially completed its assessment of the potential impacts the standard 
 may 
have on its financial statements, and believes that the adoption will 
not
 have a material impact. The Company is currently planning to adopt the standard using the full retrospective method.
  (was, 2017-08-04, similarity 0.6496):
[0001437749-17-013821:note_history:4]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may 
have on its financial statements, it believes that the adoption will 
not
 have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company is currently planning to adopt the standard using the full retrospective method.

- added (2017-11-06):
[0001437749-17-018410:note_history:5]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

- added (2017-11-06):
[0001437749-17-018410:note_history:6]
Derivatives and Hedging

- added (2017-11-06):
[0001437749-17-018410:note_history:7]
–

- added (2017-11-06):
[0001437749-17-018410:note_history:8]
Targeted Improvements to Accounting for Hedging Activities
. This guidance is being issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. For existing hedges, this guidance should be applied using a cumulative effect adjustment, while the presentation and disclosure guidance should be adopted on a prospective basis. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2017-11-06):
[0001437749-17-018410:note_history:9]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid in exchange for withheld shares had 
no
 impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.
  (was, 2017-08-04, similarity 0.6751):
[0001437749-17-013821:note_history:9]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid for withheld shares had 
no
 impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.

- removed (2017-11-06):
[0001437749-17-013821:note_history:10]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-06):
[0001437749-17-018410:note_history:11]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,226 |  |  |  | 31,198 |  |
| Total |  | $ | 26,226 |  |  | $ | 31,198 |  |
  (was, 2017-08-04, similarity 0.908):
[0001437749-17-013821:note_history:11]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 22,155 |  |  |  | 31,198 |  |
| Total |  | $ | 22,155 |  |  | $ | 31,198 |  |

- added (2017-11-06):
[0001437749-17-018410:note_history:12]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,708) |  |  |  | (26,677) |  |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,833 |  |  |  | 4,647 |  |
| Other |  |  | 4,658 |  |  |  | 14,753 |  |
| Total |  |  | 1,012,783 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 104,011 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 671 |  |  |  | 566 |  |
| Total |  | $ | 908,101 |  |  | $ | 1,006,758 |  |

- added (2017-11-06):
[0001437749-17-018410:note_history:13]
As the Company
’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July 1, 2016, 
the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represents the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time.

- changed (2017-11-06):
[0001437749-17-018410:note_history:14]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
  (was, 2017-08-04, similarity 0.9395):
[0001437749-17-013821:note_history:14]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing certain applicable margin rates; base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. 
The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. 
In connection with this amendment and in accordance with ASC 
470
-
50,

- changed (2017-11-06):
[0001437749-17-018410:note_history:15]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 September 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.
  (was, 2017-08-04, similarity 0.9807):
[0001437749-17-013821:note_history:15]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 June 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

- changed (2017-11-06):
[0001437749-17-018410:note_history:16]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 September 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$142,220
 of availability, net of outstanding letters of credit. In 
 October 2017, 
the Company repaid 
$90,000
 of the outstanding ABL Facility balance.
  (was, 2017-08-04, similarity 0.8539):
[0001437749-17-013821:note_history:16]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 June 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$145,876
 of availability, net of outstanding letters of credit.

- added (2017-11-06):
[0001437749-17-018410:note_history:17]
As of

- changed (2017-11-06):
[0001437749-17-018410:note_history:18]
September 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$26,226
 and 
$31,198,
 respectively.
  (was, 2017-08-04, similarity 0.9555):
[0001437749-17-013821:note_history:18]
As 
of 
 June 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$22,155
 and 
$31,198,
 respectively.

- removed (2017-11-06):
[0001437749-17-013821:note_history:19]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,800 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,845 |  |  |  | 4,647 |  |
| Other |  |  | 7,890 |  |  |  | 14,753 |  |
| Total |  |  | 1,014,935 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 7,038 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 662 |  |  |  | 566 |  |
| Total |  | $ | 1,007,235 |  |  | $ | 1,006,758 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-06):
[0001437749-17-018410:note_history:20]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,708) |  |  |  | (26,677) |  |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,833 |  |  |  | 4,647 |  |
| Other |  |  | 4,658 |  |  |  | 14,753 |  |
| Total |  |  | 1,012,783 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 104,011 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 671 |  |  |  | 566 |  |
| Total |  | $ | 908,101 |  |  | $ | 1,006,758 |  |

- removed (2017-11-06):
[0001437749-17-013821:note_history:21]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,800 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,845 |  |  |  | 4,647 |  |
| Other |  |  | 7,890 |  |  |  | 14,753 |  |
| Total |  |  | 1,014,935 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 7,038 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 662 |  |  |  | 566 |  |
| Total |  | $ | 1,007,235 |  |  | $ | 1,006,758 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-06):
[0001437749-17-018410:note_history:22]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,226 |  |  |  | 31,198 |  |
| Total |  | $ | 26,226 |  |  | $ | 31,198 |  |
  (was, 2017-08-04, similarity 0.908):
[0001437749-17-013821:note_history:22]
|  |  | June 30, 2017 |  |  | December 31, 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 22,155 |  |  |  | 31,198 |  |
| Total |  | $ | 22,155 |  |  | $ | 31,198 |  |
