# GNRC notes — 0001437749-17-018410


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-17-018410:notes:1]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,445 |  |  | $ | 20,763 |  |
| Long-term portion - other long-term liabilities |  |  | 12,734 |  |  |  | 10,932 |  |
| Total |  | $ | 33,179 |  |  | $ | 31,695 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 10,313 |  |  | $ | 6,728 |  |
| Long-term portion - other long-term liabilities |  |  | 36,932 |  |  |  | 24,352 |  |
| Total |  | $ | 47,245 |  |  | $ | 31,080 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-17-018410:notes:2]
|  |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Commodity contracts |  | $ | 364 |  |  | $ | 623 |  |
| Foreign currency contracts |  |  | 1,257 |  |  |  | (150 | ) |
| Interest rate swaps |  |  | 469 |  |  |  | (1,739 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-17-018410:notes:3]
[same as prior period, unchanged from 0001437749-17-013821:notes:3]

[0001437749-17-018410:notes:4]
[same as prior period, unchanged from 0001437749-17-013821:notes:4]

[0001437749-17-018410:notes:5]
[same as prior period, unchanged from 0001437749-17-013821:notes:5]

[0001437749-17-018410:notes:6]
[same as prior period, unchanged from 0001437749-17-013821:notes:6]

[0001437749-17-018410:notes:7]
[same as prior period, unchanged from 0001437749-17-013821:notes:7]

[0001437749-17-018410:notes:8]
[same as prior period, unchanged from 0001437749-17-013821:notes:8]

[0001437749-17-018410:notes:9]
[same as prior period, unchanged from 0001437749-17-013821:notes:9]

[0001437749-17-018410:notes:10]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 37,796 |  |  | $ | 35,685 |  |  | $ | 33,138 |  |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | 1,540 | (1) |  |  | - |  |  |  | 1,540 | (1) |  |  | 34,253 |  |
| Net income |  |  | 283 |  |  |  | (168 | ) |  |  | 493 |  |  |  | (1 | ) |
| Foreign currency translation |  |  | 2,178 |  |  |  | 752 |  |  |  | 7,535 |  |  |  | 2,017 |  |
| Redemption value adjustment |  |  | - |  |  |  | - |  |  |  | (909) |  |  |  | - |  |
| Balance at end of period |  | $ | 41,797 |  |  | $ | 36,269 |  |  | $ | 41,797 |  |  | $ | 36,269 |  |

[0001437749-17-018410:notes:11]
|  | (1) | Represents the additional noncontrolling interest of Pramac resulting from a common control transaction between the Generac Mobile Products S.r.l. and Pramac UK Limited legal entities. |

[0001437749-17-018410:notes:12]
The Company 
finalized the Pramac purchase price allocation during the 
first
 quarter of 
2017,
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The final purchase price allocation as of the balance sheet date was as follows:

[0001437749-17-018410:notes:13]
[same as prior period, unchanged from 0001437749-17-013821:notes:12]

[0001437749-17-018410:notes:14]
The goodwill ascribed to this acquisition is 
not
 deductible for tax purposes.
 The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through 
 September 30, 2017.

[0001437749-17-018410:notes:15]
The following unaudited pro forma information of t
he Company gives effect to this acquisition as though the transaction had occurred on 
 January 1, 2016. 
Consolidated net sales on a pro forma basis for the 
three
 and 
nine
 month periods ended 
 September 30, 2016 
were 
$373,121
 and 
$1,056,379,
 respectively. The pro forma impact of this acquisition on net income and earnings per share for both the 
three
 and 
nine
 month periods ended 
 September 30, 2016 
is 
not
 significant due to amortization related to acquired intangible assets and the fair value step-up of inventory in purchase accounting. This unaudited pro forma information is presented for informational purposes only and is 
not
 necessarily indicative of the results of operations that actually would have been achieved had the acquisition been consummated on 
 January 1, 2016.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-17-018410:notes:16]
[same as prior period, unchanged from 0001437749-17-013821:notes:15]

[0001437749-17-018410:notes:17]
[same as prior period, unchanged from 0001437749-17-013821:notes:16]

[0001437749-17-018410:notes:18]
[same as prior period, unchanged from 0001437749-17-013821:notes:17]

[0001437749-17-018410:notes:19]
[same as prior period, unchanged from 0001437749-17-013821:notes:18]

[0001437749-17-018410:notes:20]
[same as prior period, unchanged from 0001437749-17-013821:notes:19]

[0001437749-17-018410:notes:21]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 and Item 
8
 (Note 
1
 “Description of Business”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:

[0001437749-17-018410:notes:22]
[same as prior period, unchanged from 0001437749-17-013821:notes:22]

[0001437749-17-018410:notes:23]
[same as prior period, unchanged from 0001437749-17-013821:notes:23]

[0001437749-17-018410:notes:24]
[same as prior period, unchanged from 0001437749-17-013821:notes:24]

[0001437749-17-018410:notes:25]
The condensed conso
lidated balance sheet as of 
 September 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-17-018410:notes:26]
[same as prior period, unchanged from 0001437749-17-013821:notes:26]

[0001437749-17-018410:notes:27]
[same as prior period, unchanged from 0001437749-17-013821:notes:27]

[0001437749-17-018410:notes:28]
[same as prior period, unchanged from 0001437749-17-013821:notes:28]

[0001437749-17-018410:notes:29]
In 
 May 2014, 
the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

[0001437749-17-018410:notes:30]
[same as prior period, unchanged from 0001437749-17-013821:notes:30]

[0001437749-17-018410:notes:31]
[same as prior period, unchanged from 0001437749-17-013821:notes:31]

[0001437749-17-018410:notes:32]
[same as prior period, unchanged from 0001437749-17-013821:notes:32]

[0001437749-17-018410:notes:33]
[same as prior period, unchanged from 0001437749-17-013821:notes:33]

[0001437749-17-018410:notes:34]
[same as prior period, unchanged from 0001437749-17-013821:notes:34]

[0001437749-17-018410:notes:35]
[same as prior period, unchanged from 0001437749-17-013821:notes:35]

[0001437749-17-018410:notes:36]
[same as prior period, unchanged from 0001437749-17-013821:notes:36]

[0001437749-17-018410:notes:37]
[same as prior period, unchanged from 0001437749-17-013821:notes:37]

[0001437749-17-018410:notes:38]
[same as prior period, unchanged from 0001437749-17-013821:notes:38]

[0001437749-17-018410:notes:39]
[same as prior period, unchanged from 0001437749-17-013821:notes:39]

[0001437749-17-018410:notes:40]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company has substantially completed its assessment of the potential impacts the standard 
 may 
have on its financial statements, and believes that the adoption will 
not
 have a material impact. The Company is currently planning to adopt the standard using the full retrospective method.

[0001437749-17-018410:notes:41]
[same as prior period, unchanged from 0001437749-17-013821:notes:41]

[0001437749-17-018410:notes:42]
[same as prior period, unchanged from 0001437749-17-013821:notes:42]

[0001437749-17-018410:notes:43]
[same as prior period, unchanged from 0001437749-17-013821:notes:43]

[0001437749-17-018410:notes:44]
[same as prior period, unchanged from 0001437749-17-013821:notes:44]

[0001437749-17-018410:notes:45]
[same as prior period, unchanged from 0001437749-17-013821:notes:45]

[0001437749-17-018410:notes:46]
[same as prior period, unchanged from 0001437749-17-013821:notes:46]

[0001437749-17-018410:notes:47]
[same as prior period, unchanged from 0001437749-17-013821:notes:47]

[0001437749-17-018410:notes:48]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-17-018410:notes:49]
Derivatives and Hedging

[0001437749-17-018410:notes:50]
–

[0001437749-17-018410:notes:51]
Targeted Improvements to Accounting for Hedging Activities
. This guidance is being issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. For existing hedges, this guidance should be applied using a cumulative effect adjustment, while the presentation and disclosure guidance should be adopted on a prospective basis. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-17-018410:notes:52]
[same as prior period, unchanged from 0001437749-17-013821:notes:48]

[0001437749-17-018410:notes:53]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid in exchange for withheld shares had 
no
 impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.

[0001437749-17-018410:notes:54]
[same as prior period, unchanged from 0001437749-17-013821:notes:50]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-17-018410:notes:55]
1

[0001437749-17-018410:notes:56]
3

[0001437749-17-018410:notes:57]
. Commitments and Contingencies

[0001437749-17-018410:notes:58]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,500
 and 
$33,900,
 respectively.

[0001437749-17-018410:notes:59]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-17-018410:notes:60]
[same as prior period, unchanged from 0001437749-17-013821:notes:56]

[0001437749-17-018410:notes:61]
[same as prior period, unchanged from 0001437749-17-013821:notes:57]

[0001437749-17-018410:notes:62]
The following presents a tabular disclosure of changes in 
AOCL during the 
three
 and 
nine
 months ended 
 September 30, 2017 
and 
2016,
 net of tax:

[0001437749-17-018410:notes:63]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  |  | $ | (27,209 | ) |
| Other comprehensive income before reclassifications |  |  | 3,826 |  |  |  | - |  |  |  | 581 |  | (1) |  |  | 4,407 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 3,826 |  |  |  | - |  |  |  | 581 |  |  |  |  | 4,407 |  |
| Ending Balance – September 30, 2017 |  | $ | (12,031 | ) |  | $ | (11,040 | ) |  | $ | 269 |  |  |  | $ | (22,802 | ) |

[0001437749-17-018410:notes:64]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  |  | $ | (34,495 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (315 | ) |  |  | - |  |  |  | 779 |  | (2) |  |  | 464 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (315 | ) |  |  | - |  |  |  | 779 |  |  |  |  | 464 |  |
| Ending Balance – September 30, 2016 |  | $ | (20,549 | ) |  | $ | (11,362 | ) |  | $ | (2,120 | ) |  |  | $ | (34,031 | ) |

[0001437749-17-018410:notes:65]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 16,016 |  |  |  | - |  |  |  | 1,345 |  | (3) |  |  | 17,361 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 16,016 |  |  |  | - |  |  |  | 1,345 |  |  |  |  | 17,361 |  |
| Ending Balance – September 30, 2017 |  | $ | (12,031 | ) |  | $ | (11,040 | ) |  | $ | 269 |  |  |  | $ | (22,802 | ) |

[0001437749-17-018410:notes:66]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  |  | $ | (22,475 | ) |
| Other comprehensive loss before reclassifications |  |  | (11,047 | ) |  |  | - |  |  |  | (509 | ) | (4) |  |  | (11,556 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (11,047 | ) |  |  | - |  |  |  | (509 | ) |  |  |  | (11,556 | ) |
| Ending Balance – September 30, 2016 |  | $ | (20,549 | ) |  | $ | (11,362 | ) |  | $ | (2,120 | ) |  |  | $ | (34,031 | ) |

[0001437749-17-018410:notes:67]
|  | (1) | Represents unrealized gains of $934, net of tax effect of $(373) for the three months ended September 30, 2017. |

[0001437749-17-018410:notes:68]
|  | (2) | Represents unrealized gains of $1,279, net of tax effect of $(500) for the three months ended September 30, 2016. |

[0001437749-17-018410:notes:69]
|  | (3) | Represents unrealized gains of $2,188, net of tax effect of $(863) for the nine months ended September 30, 2017. |

[0001437749-17-018410:notes:70]
|  | (4) | Represents unrealized losses of $(836), net of tax benefit of $327 for the nine months ended September 30, 2016. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-018410:notes:71]
9

[0001437749-17-018410:notes:72]
. Credit Agreements

[0001437749-17-018410:notes:73]
Short-term borrowings included in the 
condensed consolidated balance sheets consist of the following:

[0001437749-17-018410:notes:74]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,226 |  |  |  | 31,198 |  |
| Total |  | $ | 26,226 |  |  | $ | 31,198 |  |

[0001437749-17-018410:notes:75]
Long-term borrowings in the 
condensed consolidated balance sheets include the following:

[0001437749-17-018410:notes:76]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,708) |  |  |  | (26,677) |  |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,833 |  |  |  | 4,647 |  |
| Other |  |  | 4,658 |  |  |  | 14,753 |  |
| Total |  |  | 1,012,783 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 104,011 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 671 |  |  |  | 566 |  |
| Total |  | $ | 908,101 |  |  | $ | 1,006,758 |  |

[0001437749-17-018410:notes:77]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-17-018410:notes:78]
As the Company
’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July 1, 2016, 
the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represents the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time.

[0001437749-17-018410:notes:79]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,

[0001437749-17-018410:notes:80]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 September 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-17-018410:notes:81]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-17-018410:notes:82]
In

[0001437749-17-018410:notes:83]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 September 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$142,220
 of availability, net of outstanding letters of credit. In 
 October 2017, 
the Company repaid 
$90,000
 of the outstanding ABL Facility balance.

[0001437749-17-018410:notes:84]
As of

[0001437749-17-018410:notes:85]
September 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$26,226
 and 
$31,198,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-17-018410:notes:86]
[same as prior period, unchanged from 0001437749-17-013821:notes:80]

[0001437749-17-018410:notes:87]
[same as prior period, unchanged from 0001437749-17-013821:notes:81]

[0001437749-17-018410:notes:88]
[same as prior period, unchanged from 0001437749-17-013821:notes:82]

[0001437749-17-018410:notes:89]
[same as prior period, unchanged from 0001437749-17-013821:notes:83]

[0001437749-17-018410:notes:90]
The Company 
is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. At 
 September 30, 2017,

[0001437749-17-018410:notes:91]
December 31, 2016 
and 
 September 30, 2016, 
the Company had

[0001437749-17-018410:notes:92]
one

[0001437749-17-018410:notes:93]
commodity contract outstanding, covering the purchases of copper.

[0001437749-17-018410:notes:94]
Because these contracts do 
not
 qualify for hedge 
accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains recognized for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$140
 and 
$325,
 respectively. Net pre-tax gains (losses) recognized for the 
three
 and 
nine
 months ended 
 September 30, 2016 
were $(
10
) and 
$66,
 respectively.

[0001437749-17-018410:notes:95]
[same as prior period, unchanged from 0001437749-17-013821:notes:87]

[0001437749-17-018410:notes:96]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies
 other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 September 30, 2017,

[0001437749-17-018410:notes:97]
December 31, 2016 
and 
 September 30, 2016, 
the Company had 
twenty
-two, 
thirty-eight
 and 
fifteen
 foreign currency contracts outstanding, respectively.

[0001437749-17-018410:notes:98]
Because these contracts do 
not
 qualify for 
hedge accounting, the related gains and losses are recorded in other, net in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains recognized for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$447
 and 
$626,
 respectively. Net pre-tax gains (losses) recognized for the 
three
 and 
nine
 months ended 
 September 30, 2016 
were 
$24
 and $(
154
), respectively.

[0001437749-17-018410:notes:99]
[same as prior period, unchanged from 0001437749-17-013821:notes:91]

[0001437749-17-018410:notes:100]
October 2013, 
the Company entered into 
two
 interest rate swap agreements, and in 
 May 2014, 
the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings. For additional details on these interest rate swaps, refer to Item 
7A
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016.

[0001437749-17-018410:notes:101]
In the 
second
 quarter of 
2017,
 the Company entered into 
ten
 interest rate swap agreements. In 
 August 2017, 
the
 Company entered into

[0001437749-17-018410:notes:102]
ten

[0001437749-17-018410:notes:103]
additional interest rate swap agreements. These interest rate swap agreements also qualify as cash flow hedges. The following table presents the details of the additional interest rate swaps from 
 August 2017:

[0001437749-17-018410:notes:104]
| Hedged Item |  | Contract Date |  | Effective Date |  | Notional Amount |  |  | Fixed LIBOR Rate |  | Expiration Date |
| Interest Rate |  | August 9, 2017 |  | July 1, 2018 |  | $ | 125,000 |  |  |  | 1.6298% |  | July 1, 2019 |
| Interest Rate |  | August 9, 2017 |  | July 1, 2019 |  |  | 125,000 |  |  |  | 1.8598% |  | July 1, 2020 |
| Interest Rate |  | August 9, 2017 |  | July 1, 2020 |  |  | 125,000 |  |  |  | 2.0848% |  | July 1, 2021 |
| Interest Rate |  | August 9, 2017 |  | July 1, 2021 |  |  | 125,000 |  |  |  | 2.3010% |  | July 1, 2022 |
| Interest Rate |  | August 9, 2017 |  | July 1, 2022 |  |  | 125,000 |  |  |  | 2.4848% |  | May 31, 2023 |
| Interest Rate |  | August 30, 2017 |  | July 1, 2018 |  |  | 125,000 |  |  |  | 1.5503% |  | July 1, 2019 |
| Interest Rate |  | August 30, 2017 |  | July 1, 2019 |  |  | 125,000 |  |  |  | 1.7553% |  | July 1, 2020 |
| Interest Rate |  | August 30, 2017 |  | July 1, 2020 |  |  | 125,000 |  |  |  | 1.9803% |  | July 1, 2021 |
| Interest Rate |  | August 30, 2017 |  | July 1, 2021 |  |  | 125,000 |  |  |  | 2.2228% |  | July 1, 2022 |
| Interest Rate |  | August 30, 2017 |  | July 1, 2022 |  |  | 125,000 |  |  |  | 2.4153% |  | May 31, 2023 |

[0001437749-17-018410:notes:105]
[same as prior period, unchanged from 0001437749-17-013821:notes:96]

[0001437749-17-018410:notes:106]
[same as prior period, unchanged from 0001437749-17-013821:notes:97]

[0001437749-17-018410:notes:107]
The fair value
s of the commodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair values of the interest rate swaps are included in other assets in the condensed consolidated balance sheets as of 
 September 30, 2017. 
The fair value of the commodity contract is included in other assets, the fair value of the foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of 
 December 31, 2016. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 September 30, 2017 
and 
 December 31, 2016 
is an asset of 
$2,097
 and a liability of 
$1,295,
 respectively, which represents the amount the Company would either receive or need to pay upon exit of the agreements on those dates.

[0001437749-17-018410:notes:108]
The amount of 
gains recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$581
 and 
$1,345,
 respectively. The amount of gains (losses) for the 
three
 and 
nine
 months ended 
 September 30, 2016 
were 
$779
 and $(
509
), respectively.

[0001437749-17-018410:notes:109]
T
he amount of pre-tax gains recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts 
not
 designated as hedging instruments for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$587
 and 
$951,
 respectively. The amount of pre-tax gains (losses) for the 
three
 and 
nine
 months ended 
 September 30, 2016 
were 
$14
 and $(
88
), respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-018410:notes:110]
[same as prior period, unchanged from 0001437749-17-013821:notes:101]

[0001437749-17-018410:notes:111]
[same as prior period, unchanged from 0001437749-17-013821:notes:102]

[0001437749-17-018410:notes:112]
[same as prior period, unchanged from 0001437749-17-013821:notes:103]

[0001437749-17-018410:notes:113]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | - |  |  |  | - |  |  |  | 909 |  |  |  | - |  |
| Net income attributable to common shareholders |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 79,120 |  |  | $ | 57,279 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,758,190 |  |  |  | 64,615,935 |  |  |  | 62,094,807 |  |  |  | 65,506,469 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 558,598 |  |  |  | 510,182 |  |  |  | 608,462 |  |  |  | 485,658 |  |
| Diluted shares |  |  | 62,316,788 |  |  |  | 65,126,117 |  |  |  | 62,703,269 |  |  |  | 65,992,127 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.64 |  |  | $ | 0.41 |  |  | $ | 1.27 |  |  | $ | 0.87 |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.40 |  |  | $ | 1.26 |  |  | $ | 0.87 |  |

[0001437749-17-018410:notes:114]
(
1
) Excludes 
approximately 
146,000
 stock options for the 
three
-month period ended 
 September 30, 2017, 
and 
188,800
 stock options for the 
nine
-month period ended 
 September 30, 2017, 
as the impact of such awards was anti-dilutive. Excludes approximately 
208,400
 stock options for the 
three
-month period ended 
 September 30, 2016, 
and 
172,900
 stock options for the 
nine
-month period ended 
 September 30, 2016, 
as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-018410:notes:115]
[same as prior period, unchanged from 0001437749-17-013821:notes:106]

[0001437749-17-018410:notes:116]
[same as prior period, unchanged from 0001437749-17-013821:notes:107]

[0001437749-17-018410:notes:117]
[same as prior period, unchanged from 0001437749-17-013821:notes:108]

[0001437749-17-018410:notes:118]
[same as prior period, unchanged from 0001437749-17-013821:notes:109]

[0001437749-17-018410:notes:119]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts 
receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$904,282,
 was approximately 
$907,085
 (Level 
2
) at 
 September 30, 2017, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-17-018410:notes:120]
[same as prior period, unchanged from 0001437749-17-013821:notes:111]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-018410:notes:121]
[same as prior period, unchanged from 0001437749-17-013821:notes:112]

[0001437749-17-018410:notes:122]
[same as prior period, unchanged from 0001437749-17-013821:notes:113]

[0001437749-17-018410:notes:123]
[same as prior period, unchanged from 0001437749-17-013821:notes:114]

[0001437749-17-018410:notes:124]
nine
 months ended 
 September 30, 2017 
and 
2016
 were 
35.3%
 and 
36.7%,
 respectively. The decrease in the effective income tax rate in 
2017
 was primarily due to non-recurring discrete tax items
 that favorably impacted the current year and unfavorably impacted the prior year.

[0001437749-17-018410:notes:125]
The Company files U.S. federal, U.S. state, and foreign
 jurisdiction tax returns that are subject to examination up to the expiration of the statute of limitations. We believe the tax positions taken on our returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded.

[0001437749-17-018410:notes:126]
The Company is currently under examination in multiple jurisdictions
 and is working to address all matters. While the Company does 
not
 believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination 
 may 
result in differences from what was recorded. Such differences 
 may 
affect the provision for income taxes in the period in which the determination is made, and could impact the company’s financial results.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-17-018410:notes:127]
[same as prior period, unchanged from 0001437749-17-013821:notes:118]

[0001437749-17-018410:notes:128]
[same as prior period, unchanged from 0001437749-17-013821:notes:119]

[0001437749-17-018410:notes:129]
[same as prior period, unchanged from 0001437749-17-013821:notes:120]

[0001437749-17-018410:notes:130]
[same as prior period, unchanged from 0001437749-17-013821:notes:121]

[0001437749-17-018410:notes:131]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 32,813 |  |  | $ | 30,735 |  |  | $ | 31,695 |  |  | $ | 30,197 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 43 |  |  |  | 840 |  |
| Payments |  |  | (5,135) |  |  |  | (5,424) |  |  |  | (13,980) |  |  |  | (13,976) |  |
| Provision for warranty issued |  |  | 6,206 |  |  |  | 5,762 |  |  |  | 14,452 |  |  |  | 13,464 |  |
| Changes in estimates for pre-existing warranties |  |  | (705) |  |  |  | 286 |  |  |  | 969 |  |  |  | 834 |  |
| Balance at end of period |  | $ | 33,179 |  |  | $ | 31,359 |  |  | $ | 33,179 |  |  | $ | 31,359 |  |

[0001437749-17-018410:notes:132]
[same as prior period, unchanged from 0001437749-17-013821:notes:123]

[0001437749-17-018410:notes:133]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 36,717 |  |  | $ | 29,082 |  |  | $ | 31,080 |  |  | $ | 28,961 |  |
| Deferred revenue contracts issued |  |  | 12,355 |  |  |  | 2,843 |  |  |  | 21,222 |  |  |  | 5,606 |  |
| Amortization of deferred revenue contracts |  |  | (1,827 | ) |  |  | (1,430 | ) |  |  | (5,057 | ) |  |  | (4,072 | ) |
| Balance at end of period |  | $ | 47,245 |  |  | $ | 30,495 |  |  | $ | 47,245 |  |  | $ | 30,495 |  |

[0001437749-17-018410:notes:134]
[same as prior period, unchanged from 0001437749-17-013821:notes:125]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-17-018410:notes:135]
|  |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Land and improvements |  | $ | 12,708 |  |  | $ | 12,079 |  |
| Buildings and improvements |  |  | 127,344 |  |  |  | 122,747 |  |
| Machinery and equipment |  |  | 88,555 |  |  |  | 81,687 |  |
| Dies and tools |  |  | 24,799 |  |  |  | 23,269 |  |
| Vehicles |  |  | 1,866 |  |  |  | 1,474 |  |
| Office equipment and systems |  |  | 71,152 |  |  |  | 66,929 |  |
| Leasehold improvements |  |  | 2,465 |  |  |  | 2,319 |  |
| Construction in progress |  |  | 10,380 |  |  |  | 8,654 |  |
| Gross property and equipment |  |  | 339,269 |  |  |  | 319,158 |  |
| Accumulated depreciation |  |  | (120,611) |  |  |  | (106,365) |  |
| Total |  | $ | 218,658 |  |  | $ | 212,793 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-17-018410:notes:136]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Product Classes |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Residential products |  | $ | 251,921 |  |  | $ | 192,856 |  |  | $ | 604,894 |  |  | $ | 533,572 |  |
| Commercial & industrial products |  |  | 174,538 |  |  |  | 149,676 |  |  |  | 496,736 |  |  |  | 409,396 |  |
| Other |  |  | 30,794 |  |  |  | 30,589 |  |  |  | 82,813 |  |  |  | 84,064 |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-17-018410:notes:137]
|  |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Raw material |  | $ | 223,184 |  |  | $ | 218,911 |  |
| Work-in-process |  |  | 8,251 |  |  |  | 2,950 |  |
| Finished goods |  |  | 117,588 |  |  |  | 127,870 |  |
| Total |  | $ | 349,023 |  |  | $ | 349,731 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-018410:notes:138]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 364,323 |  |  | $ | 299,095 |  |  | $ | 918,727 |  |  | $ | 833,831 |  |
| International |  |  | 92,930 |  |  |  | 74,026 |  |  |  | 265,716 |  |  |  | 193,201 |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |

[0001437749-17-018410:notes:139]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 83,128 |  |  | $ | 69,309 |  |  | $ | 190,131 |  |  | $ | 173,521 |  |
| International |  |  | 5,625 |  |  |  | 3,527 |  |  |  | 16,471 |  |  |  | 13,050 |  |
| Total adjusted EBITDA |  | $ | 88,753 |  |  | $ | 72,836 |  |  | $ | 206,602 |  |  | $ | 186,571 |  |
| Interest expense |  |  | (10,672) |  |  |  | (11,299) |  |  |  | (32,353) |  |  |  | (33,714) |  |
| Depreciation and amortization |  |  | (13,108) |  |  |  | (14,900) |  |  |  | (38,691) |  |  |  | (41,343) |  |
| Non-cash write-down and other adjustments (1) |  |  | (756) |  |  |  | 1,093 |  |  |  | (2,632) |  |  |  | (1,689) |  |
| Non-cash share-based compensation expense (2) |  |  | (2,584) |  |  |  | (2,419) |  |  |  | (8,402) |  |  |  | (7,805) |  |
| Loss on change in contractual interest rate (3) |  |  | - |  |  |  | (2,957) |  |  |  | - |  |  |  | (2,957) |  |
| Transaction costs and credit facility fees (4) |  |  | (234) |  |  |  | (739) |  |  |  | (970) |  |  |  | (1,499) |  |
| Business optimization expenses (5) |  |  | (487) |  |  |  | (58) |  |  |  | (1,933) |  |  |  | (7,164) |  |
| Other |  |  | (281) |  |  |  | (31) |  |  |  | (31) |  |  |  | (79) |  |
| Income before provision for income taxes |  | $ | 60,631 |  |  | $ | 41,526 |  |  | $ | 121,590 |  |  | $ | 90,321 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-018410:notes:140]
[same as prior period, unchanged from 0001437749-17-013821:notes:131]

[0001437749-17-018410:notes:141]
[same as prior period, unchanged from 0001437749-17-013821:notes:132]

[0001437749-17-018410:notes:142]
T
he Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac and Motortech acquisitions, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. All segment information has been retrospectively adjusted for all periods presented to reflect the current reportable segment structure.

[0001437749-17-018410:notes:143]
[same as prior period, unchanged from 0001437749-17-013821:notes:134]

[0001437749-17-018410:notes:144]
Management 
evaluates the performance of its segments based primarily on Adjusted EBITDA before noncontrolling interests, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-17-018410:notes:145]
[same as prior period, unchanged from 0001437749-17-013821:notes:136]

[0001437749-17-018410:notes:146]
[same as prior period, unchanged from 0001437749-17-013821:notes:137]

[0001437749-17-018410:notes:147]
|  | (3) | For the three and nine month periods ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time. |

[0001437749-17-018410:notes:148]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-17-018410:notes:149]
|  | (5) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-17-018410:notes:150]
T
he Company’s sales in the United States represented approximately 
76%
 and 
77%
 of total sales for the 
three
 months ended 
 September 30, 2017 
and 
2016,
 respectively, and represented approximately 
74%
 and 
78%
 of total sales for the 
nine
 months ended 
 September 30, 2017 
and 
2016,
 respectively. Approximately 
85%
 and 
87%
 of the Company’s identifiable long-lived assets are located in the United States at 
 September 30, 2017 
and 
 December 31, 2016, 
respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-17-018410:notes:151]
[same as prior period, unchanged from 0001437749-17-013821:notes:141]

[0001437749-17-018410:notes:152]
[same as prior period, unchanged from 0001437749-17-013821:notes:142]

[0001437749-17-018410:notes:153]
[same as prior period, unchanged from 0001437749-17-013821:notes:143]

[0001437749-17-018410:notes:154]
[same as prior period, unchanged from 0001437749-17-013821:notes:144]


## us-gaap:TreasuryStockTextBlock

[0001437749-17-018410:notes:155]
[same as prior period, unchanged from 0001437749-17-013821:notes:145]

[0001437749-17-018410:notes:156]
I
n 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the program, the Company 
 may 
repurchase up to 
$250,000
 of its common stock over the following 
24
 months. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
nine
 months ended 
 September 30, 2017, 
the Company repurchased 
844,500
 shares of its common stock for 
$30,012.
 Since the inception of both programs, the Company has repurchased 
8,116,706
 shares of its common stock for 
$279,891,
 all funded with cash on hand.
