# GNRC 8-K — 0001437749-17-017990 filed 2017-11-01

## item codes, every 8-K on or before 2017-11-06

- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2017-11-06

- none on or before 2017-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-017990:8k_2_02:1]
EX-99.1
2
ex_98409.htm
EXHIBIT 99.1

[0001437749-17-017990:8k_2_02:2]
ex_98409.htm

[0001437749-17-017990:8k_2_02:3]
Exhibit 99.1

[0001437749-17-017990:8k_2_02:4]
Generac Reports Third Quarter 2017 Results

[0001437749-17-017990:8k_2_02:5]
Record shipments drive significant organic growth; Outlook raised for full-year 2017

[0001437749-17-017990:8k_2_02:6]
WAUKESHA, WISCONSIN, (November 1, 2017) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its third quarter ended September 30, 2017.

[0001437749-17-017990:8k_2_02:7]
Third Quarter 2017 Highlights

[0001437749-17-017990:8k_2_02:8]
| ● | Net sales increased 22.5% to a record $457.3 million during the third quarter of 2017 as compared to $373.1 million in the prior-year third quarter, including $10.1 million of contribution from the Motortech acquisition. |

[0001437749-17-017990:8k_2_02:9]
| ● | Net income attributable to the Company during the third quarter of 2017 was $39.7 million, or $0.64 per share, as compared to $26.2 million, or $0.40 per share, for the same period of 2016. |

[0001437749-17-017990:8k_2_02:10]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $57.8 million, or $0.93 per share, as compared to $53.2 million, or $0.82 per share, in the third quarter of 2016. |

[0001437749-17-017990:8k_2_02:11]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $87.6 million as compared to $72.1 million in the third quarter last year. |

[0001437749-17-017990:8k_2_02:12]
| ● | Cash flow from operations was $67.0 million as compared to $48.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $60.4 million as compared to $41.4 million in the third quarter of 2016. |

[0001437749-17-017990:8k_2_02:13]
| ● | As a result of the improved demand outlook for residential products, the Company is increasing its full-year 2017 guidance for sales growth to 14 to 15% and Adjusted EBITDA margins to approximately 19.0%. |

[0001437749-17-017990:8k_2_02:14]
“Overall third quarter results were very strong with record quarterly sales resulting in robust organic sales growth of approximately 20% and solid operating and free cash flow compared to the prior year,” said Aaron Jagdfeld, President and Chief Executive Officer. “The active hurricane season drove significant shipments of portable generators during the quarter as our team worked diligently with our channel partners to quickly get these products to customers in the storm affected areas. In-home consultations and end-user activations of home standby generators were also strong, with broad-based growth across all regions. Looking forward, we have ramped up production for home standby generators to meet the current and anticipated increased demand for these products, and we’re also early in the process of replenishing our portable inventories back to more normalized levels. Shipments of commercial and industrial products also experienced solid organic growth during the third quarter, with the continued strong recovery in domestic mobile products and healthy end-market demand in our International segment driving the year-over-year increase.”

[0001437749-17-017990:8k_2_02:15]
Additional Third Quarter 2017 Consolidated Highlights

[0001437749-17-017990:8k_2_02:16]
Residential product sales increased 30.6% to $251.9 million as compared to $192.9 million in the prior year. Commercial & Industrial (C&I) product sales improved 16.6% to $174.5 million as compared to $149.7 million in the prior year.

[0001437749-17-017990:8k_2_02:17]
Gross profit margin was 34.4% compared to 36.9% in the prior-year third quarter. The decline in gross margin as compared to the prior year was primarily due to unfavorable sales mix attributable to significantly higher sales of portable generators and mobile products relative to prior year, which carry lower gross margins relative to the consolidated corporate average.

[0001437749-17-017990:8k_2_02:18]
Operating expenses increased $3.2 million, or 3.9%, as compared to the third quarter of 2016. The increase was primarily driven by the addition of recurring operating expenses associated with the Motortech acquisition and additional incentive compensation accrued during the current-year quarter.

[0001437749-17-017990:8k_2_02:19]
Cash flow from operations was $67.0 million as compared to $48.3 million in the prior year, and free cash flow was $60.4 million as compared to $41.4 million in the same period last year. The increases in cash flow were primarily driven by higher operating earnings in the current-year quarter.

[0001437749-17-017990:8k_2_02:20]
Business Segment Results

[0001437749-17-017990:8k_2_02:21]
Domestic Segment

[0001437749-17-017990:8k_2_02:22]
Domestic segment sales increased 21.8% to $364.3 million as compared to $299.1 million in the prior-year quarter. The current-year third quarter experienced substantial growth in shipments of portable generators driven by increased outage activity, along with the continuation of very strong growth for mobile products. Also contributing to the year-over-year sales growth were increases in home standby generators and specialty outdoor power equipment.

[0001437749-17-017990:8k_2_02:23]
Adjusted EBITDA for the segment was $83.1 million, or 22.8% of net sales, as compared to $69.3 million in the prior year, or 23.2% of net sales. Adjusted EBITDA margin in the current year was impacted by unfavorable sales mix due to significantly higher sales of portable generators and mobile products relative to prior year. These impacts were largely offset by improved overall leverage of fixed operating expenses on the strong organic increase in sales.

[0001437749-17-017990:8k_2_02:24]
International Segment

[0001437749-17-017990:8k_2_02:25]
International segment sales increased 25.5% to $92.9 million as compared to $74.0 million in the prior-year quarter. The increase was primarily due to the contribution from the recent acquisition of Motortech, which closed on January 1, 2017. The growth was also due to increased organic shipments of both C&I and residential products within the European and Latin America regions, along with the favorable impact of the stronger Euro as compared to the prior year.

[0001437749-17-017990:8k_2_02:26]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, was $5.6 million, or 6.1% of net sales, as compared to $3.5 million, or 4.8% of net sales, in the prior year. The improvement in adjusted EBITDA margin as compared to the prior year was primarily due to improved leverage of fixed manufacturing and operating expenses on the organic increase in sales. These impacts were partially offset by unfavorable foreign currency effects.

[0001437749-17-017990:8k_2_02:27]
2017 Outlook Update

[0001437749-17-017990:8k_2_02:28]
The Company is increasing its prior guidance for revenue growth and adjusted EBITDA margins for full-year 2017, which is primarily due to an improved outlook for residential products as a result of the higher power outage activity experienced during the third quarter of 2017. Full year net sales are now expected to increase between 14 to 15% over the prior year, which is an increase from the 6 to 8% growth previously expected. Total core organic sales growth is now anticipated to increase 9 to 10%, which is an improvement from the previous assumption of 2 to 3%.

[0001437749-17-017990:8k_2_02:29]
Net income margins, before deducting for non-controlling interests, are now expected to be approximately 8.0%, an improvement from 7.0 to 7.5% previously expected. Adjusted EBITDA margins, also before deducting for non-controlling interests, are now expected to be approximately 19.0% for the full year 2017, an improvement from the prior guidance of approximately 18.5%.

[0001437749-17-017990:8k_2_02:30]
Operating and free cash flow generation is expected to sequentially increase during the fourth quarter, with the conversion of adjusted net income still expected to be over 90% for the full year.

[0001437749-17-017990:8k_2_02:31]
Conference Call and Webcast

[0001437749-17-017990:8k_2_02:32]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, November 1, 2017 to discuss highlights of the third quarter of 2017 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 5689819.

[0001437749-17-017990:8k_2_02:33]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-17-017990:8k_2_02:34]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 5689819. The telephonic replay will be available for 7 days.

[0001437749-17-017990:8k_2_02:35]
About Generac

[0001437749-17-017990:8k_2_02:36]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-017990:8k_2_02:37]
Forward-looking Information

[0001437749-17-017990:8k_2_02:38]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-17-017990:8k_2_02:39]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-17-017990:8k_2_02:40]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-17-017990:8k_2_02:41]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-17-017990:8k_2_02:42]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-17-017990:8k_2_02:43]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-17-017990:8k_2_02:44]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-17-017990:8k_2_02:45]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-17-017990:8k_2_02:46]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-17-017990:8k_2_02:47]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-17-017990:8k_2_02:48]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-17-017990:8k_2_02:49]
|  | ● | loss of key management and employees; |

[0001437749-17-017990:8k_2_02:50]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-17-017990:8k_2_02:51]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-17-017990:8k_2_02:52]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2016 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-17-017990:8k_2_02:53]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-17-017990:8k_2_02:54]
Reconciliations to GAAP Financial Metrics

[0001437749-17-017990:8k_2_02:55]
Adjusted EBITDA

[0001437749-17-017990:8k_2_02:56]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-17-017990:8k_2_02:57]
Adjusted Net Income

[0001437749-17-017990:8k_2_02:58]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-17-017990:8k_2_02:59]
Free Cash Flow

[0001437749-17-017990:8k_2_02:60]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-17-017990:8k_2_02:61]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-17-017990:8k_2_02:62]
SOURCE: Generac Holdings Inc.

[0001437749-17-017990:8k_2_02:63]
CONTACT:

[0001437749-17-017990:8k_2_02:64]
Michael W. Harris

[0001437749-17-017990:8k_2_02:65]
Vice President – Finance

[0001437749-17-017990:8k_2_02:66]
(262) 544-4811 x2675

[0001437749-17-017990:8k_2_02:67]
Michael.Harris@Generac.com

[0001437749-17-017990:8k_2_02:68]
| Generac Holdings Inc. |  |
| Condensed Consolidated Statements of Comprehensive Income |  |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |  |
| (Unaudited) |  |

[0001437749-17-017990:8k_2_02:69]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |
| Costs of goods sold |  |  | 299,784 |  |  |  | 235,349 |  |  |  | 782,028 |  |  |  | 667,053 |  |
| Gross profit |  |  | 157,469 |  |  |  | 137,772 |  |  |  | 402,415 |  |  |  | 359,979 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 44,402 |  |  |  | 44,429 |  |  |  | 127,702 |  |  |  | 124,064 |  |
| Research and development |  |  | 10,864 |  |  |  | 9,426 |  |  |  | 31,732 |  |  |  | 27,512 |  |
| General and administrative |  |  | 22,102 |  |  |  | 18,066 |  |  |  | 64,436 |  |  |  | 55,492 |  |
| Amortization of intangibles |  |  | 7,242 |  |  |  | 9,511 |  |  |  | 21,554 |  |  |  | 25,525 |  |
| Total operating expenses |  |  | 84,610 |  |  |  | 81,432 |  |  |  | 245,424 |  |  |  | 232,593 |  |
| Income from operations |  |  | 72,859 |  |  |  | 56,340 |  |  |  | 156,991 |  |  |  | 127,386 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,672 | ) |  |  | (11,299 | ) |  |  | (32,353 | ) |  |  | (33,714 | ) |
| Investment income |  |  | 14 |  |  |  | – |  |  |  | 57 |  |  |  | 36 |  |
| Loss on change in contractual interest rate |  |  | – |  |  |  | (2,957 | ) |  |  | – |  |  |  | (2,957 | ) |
| Costs related to acquisition |  |  | (51 | ) |  |  | (577 | ) |  |  | (372 | ) |  |  | (994 | ) |
| Other, net |  |  | (1,519 | ) |  |  | 19 |  |  |  | (2,733 | ) |  |  | 564 |  |
| Total other expense, net |  |  | (12,228 | ) |  |  | (14,814 | ) |  |  | (35,401 | ) |  |  | (37,065 | ) |
| Income before provision for income taxes |  |  | 60,631 |  |  |  | 41,526 |  |  |  | 121,590 |  |  |  | 90,321 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 42,946 |  |  |  | 33,154 |  |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 78,644 |  |  |  | 57,167 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 341 |  |  |  | (171 | ) |  |  | 433 |  |  |  | (112 | ) |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.64 |  |  | $ | 0.41 |  |  | $ | 1.27 |  |  | $ | 0.87 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,758,190 |  |  |  | 64,615,935 |  |  |  | 62,094,807 |  |  |  | 65,505,469 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.64 |  |  | $ | 0.40 |  |  | $ | 1.26 |  |  | $ | 0.87 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,316,788 |  |  |  | 65,126,117 |  |  |  | 62,703,269 |  |  |  | 65,992,127 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 43,213 |  |  | $ | 26,647 |  |  | $ | 92,177 |  |  | $ | 45,723 |  |

[0001437749-17-017990:8k_2_02:70]
5

[0001437749-17-017990:8k_2_02:71]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-017990:8k_2_02:72]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 128,780 |  |  | $ | 67,272 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 320,626 |  |  |  | 241,857 |  |
| Inventories |  |  | 349,023 |  |  |  | 349,731 |  |
| Prepaid expenses and other assets |  |  | 11,720 |  |  |  | 24,649 |  |
| Total current assets |  |  | 810,149 |  |  |  | 683,509 |  |
| Property and equipment, net |  |  | 218,658 |  |  |  | 212,793 |  |
| Customer lists, net |  |  | 43,404 |  |  |  | 45,312 |  |
| Patents, net |  |  | 41,955 |  |  |  | 48,061 |  |
| Other intangible assets, net |  |  | 2,571 |  |  |  | 2,925 |  |
| Tradenames, net |  |  | 154,643 |  |  |  | 158,874 |  |
| Goodwill |  |  | 720,059 |  |  |  | 704,640 |  |
| Deferred income taxes |  |  | 4,310 |  |  |  | 3,337 |  |
| Other assets |  |  | 5,225 |  |  |  | 2,233 |  |
| Total assets |  | $ | 2,000,974 |  |  | $ | 1,861,684 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 26,226 |  |  | $ | 31,198 |  |
| Accounts payable |  |  | 190,207 |  |  |  | 181,519 |  |
| Accrued wages and employee benefits |  |  | 28,266 |  |  |  | 21,189 |  |
| Other accrued liabilities |  |  | 109,362 |  |  |  | 93,068 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 104,682 |  |  |  | 14,965 |  |
| Total current liabilities |  |  | 458,743 |  |  |  | 341,939 |  |
| Long-term borrowings and capital lease obligations |  |  | 908,101 |  |  |  | 1,006,758 |  |
| Deferred income taxes |  |  | 49,528 |  |  |  | 17,278 |  |
| Other long-term liabilities |  |  | 69,556 |  |  |  | 61,459 |  |
| Total liabilities |  |  | 1,485,928 |  |  |  | 1,427,434 |  |
| Redeemable noncontrolling interests |  |  | 41,797 |  |  |  | 33,138 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,611,513 and 70,261,481 shares issued at September 30, 2017 and December 31, 2016, respectively |  |  | 706 |  |  |  | 702 |  |
| Additional paid-in capital |  |  | 456,156 |  |  |  | 449,049 |  |
| Treasury stock, at cost |  |  | (293,969 | ) |  |  | (262,402 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 535,172 |  |  |  | 456,052 |  |
| Accumulated other comprehensive loss |  |  | (22,802 | ) |  |  | (40,163 | ) |
| Stockholders' equity attributable to Generac Holdings, Inc. |  |  | 473,147 |  |  |  | 401,122 |  |
| Noncontrolling interests |  |  | 102 |  |  |  | (10 | ) |
| Total stockholders’ equity |  |  | 473,249 |  |  |  | 401,112 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,000,974 |  |  | $ | 1,861,684 |  |

[0001437749-17-017990:8k_2_02:73]
6

[0001437749-17-017990:8k_2_02:74]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-17-017990:8k_2_02:75]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 78,644 |  |  | $ | 57,167 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 17,137 |  |  |  | 15,818 |  |
| Amortization of intangible assets |  |  | 21,554 |  |  |  | 25,525 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,400 |  |  |  | 3,229 |  |
| Loss on change in contractual interest rate |  |  | – |  |  |  | 2,957 |  |
| Deferred income taxes |  |  | 28,703 |  |  |  | 22,909 |  |
| Share-based compensation expense |  |  | 8,402 |  |  |  | 7,805 |  |
| Other |  |  | 361 |  |  |  | (45 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (70,108 | ) |  |  | (11,642 | ) |
| Inventories |  |  | 16,738 |  |  |  | 6,177 |  |
| Other assets |  |  | (3,852 | ) |  |  | 2,663 |  |
| Accounts payable |  |  | (206 | ) |  |  | (2,618 | ) |
| Accrued wages and employee benefits |  |  | 6,288 |  |  |  | 4,981 |  |
| Other accrued liabilities |  |  | 17,319 |  |  |  | 1,341 |  |
| Excess tax benefits from equity awards |  |  | (661 | ) |  |  | (6,754 | ) |
| Net cash provided by operating activities |  |  | 122,719 |  |  |  | 129,513 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 77 |  |  |  | 1,349 |  |
| Expenditures for property and equipment |  |  | (16,658 | ) |  |  | (20,847 | ) |
| Acquisition of business, net of cash acquired |  |  | 1,257 |  |  |  | (61,386 | ) |
| Net cash used in investing activities |  |  | (15,324 | ) |  |  | (80,884 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 74,443 |  |  |  | 14,117 |  |
| Proceeds from long-term borrowings |  |  | 3,069 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (80,952 | ) |  |  | (8,244 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (13,051 | ) |  |  | (10,976 | ) |
| Stock repurchases |  |  | (30,012 | ) |  |  | (99,934 | ) |
| Payment of debt issuance costs |  |  | (1,517 | ) |  |  | – |  |
| Cash dividends paid |  |  | – |  |  |  | (76 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (2,479 | ) |  |  | (12,308 | ) |
| Proceeds from exercise of stock options |  |  | 1,717 |  |  |  | – |  |
| Excess tax benefits from equity awards |  |  | – |  |  |  | 6,754 |  |
| Net cash used in financing activities |  |  | (48,782 | ) |  |  | (110,667 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,895 |  |  |  | 344 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 61,508 |  |  |  | (61,694 | ) |
| Cash and cash equivalents at beginning of period |  |  | 67,272 |  |  |  | 115,857 |  |
| Cash and cash equivalents at end of period |  | $ | 128,780 |  |  | $ | 54,163 |  |

[0001437749-17-017990:8k_2_02:76]
7

[0001437749-17-017990:8k_2_02:77]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-17-017990:8k_2_02:78]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Reportable Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 364,323 |  |  | $ | 299,095 |  |  | $ | 918,727 |  |  | $ | 833,831 |  |
| International |  |  | 92,930 |  |  |  | 74,026 |  |  |  | 265,716 |  |  |  | 193,201 |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 251,921 |  |  | $ | 192,856 |  |  | $ | 604,894 |  |  | $ | 533,572 |  |
| Commercial & industrial products |  |  | 174,538 |  |  |  | 149,676 |  |  |  | 496,736 |  |  |  | 409,396 |  |
| Other |  |  | 30,794 |  |  |  | 30,589 |  |  |  | 82,813 |  |  |  | 84,064 |  |
| Total net sales |  | $ | 457,253 |  |  | $ | 373,121 |  |  | $ | 1,184,443 |  |  | $ | 1,027,032 |  |

[0001437749-17-017990:8k_2_02:79]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 83,128 |  |  | $ | 69,309 |  |  | $ | 190,131 |  |  | $ | 173,521 |  |
| International |  |  | 5,625 |  |  |  | 3,527 |  |  |  | 16,471 |  |  |  | 13,050 |  |
| Total adjusted EBITDA (1) |  | $ | 88,753 |  |  | $ | 72,836 |  |  | $ | 206,602 |  |  | $ | 186,571 |  |

[0001437749-17-017990:8k_2_02:80]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-17-017990:8k_2_02:81]
8

[0001437749-17-017990:8k_2_02:82]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-017990:8k_2_02:83]
| Net income to Adjusted EBITDA reconciliation |

[0001437749-17-017990:8k_2_02:84]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Net income (loss) attributable to noncontrolling interests (1) |  |  | 341 |  |  |  | (171 | ) |  |  | 433 |  |  |  | (112 | ) |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 78,644 |  |  |  | 57,167 |  |
| Interest expense |  |  | 10,672 |  |  |  | 11,299 |  |  |  | 32,353 |  |  |  | 33,714 |  |
| Depreciation and amortization |  |  | 13,108 |  |  |  | 14,900 |  |  |  | 38,691 |  |  |  | 41,343 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 42,946 |  |  |  | 33,154 |  |
| Non-cash write-down and other adjustments (2) |  |  | 756 |  |  |  | (1,093 | ) |  |  | 2,632 |  |  |  | 1,689 |  |
| Non-cash share-based compensation expense (3) |  |  | 2,584 |  |  |  | 2,419 |  |  |  | 8,402 |  |  |  | 7,805 |  |
| Loss on change in contractual interest rate (4) |  |  | - |  |  |  | 2,957 |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and credit facility fees (5) |  |  | 234 |  |  |  | 739 |  |  |  | 970 |  |  |  | 1,499 |  |
| Business optimization expenses (6) |  |  | 487 |  |  |  | 58 |  |  |  | 1,933 |  |  |  | 7,164 |  |
| Other |  |  | 281 |  |  |  | 31 |  |  |  | 31 |  |  |  | 79 |  |
| Adjusted EBITDA |  |  | 88,753 |  |  |  | 72,836 |  |  |  | 206,602 |  |  |  | 186,571 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,178 |  |  |  | 708 |  |  |  | 3,589 |  |  |  | 3,015 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 87,575 |  |  | $ | 72,128 |  |  | $ | 203,013 |  |  | $ | 183,556 |  |

[0001437749-17-017990:8k_2_02:85]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.2 million and $3.4 million for the three and nine months ended September 30, 2017, respectively, and $1.3 million and $6.9 million for the three and nine months ended September 30, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) For the three and nine months ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time. |
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (6) For the three and nine months ended September 30, 2017, represents severance and other non-recurring plant consolidation costs. For the three and nine months ended September 30, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. |

[0001437749-17-017990:8k_2_02:86]
9

[0001437749-17-017990:8k_2_02:87]
| Net income to Adjusted net income reconciliation |

[0001437749-17-017990:8k_2_02:88]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | 26,183 |  |  | $ | 78,211 |  |  | $ | 57,279 |  |
| Net income (loss) attributable to noncontrolling interests (1) |  |  | 341 |  |  |  | (171 | ) |  |  | 433 |  |  |  | (112 | ) |
| Net income |  |  | 40,050 |  |  |  | 26,012 |  |  |  | 78,644 |  |  |  | 57,167 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | 15,514 |  |  |  | 42,946 |  |  |  | 33,154 |  |
| Income before provision for income taxes |  |  | 60,631 |  |  |  | 41,526 |  |  |  | 121,590 |  |  |  | 90,321 |  |
| Amortization of intangible assets |  |  | 7,242 |  |  |  | 9,511 |  |  |  | 21,554 |  |  |  | 25,525 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,092 |  |  |  | 1,107 |  |  |  | 2,400 |  |  |  | 3,229 |  |
| Loss on change in contractual interest rate (4) |  |  | - |  |  |  | 2,957 |  |  |  | - |  |  |  | 2,957 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | (35 | ) |  |  | 469 |  |  |  | 979 |  |  |  | 5,159 |  |
| Business optimization expenses (6) |  |  | 487 |  |  |  | 58 |  |  |  | 1,933 |  |  |  | 7,164 |  |
| Adjusted net income before provision for income taxes |  |  | 69,417 |  |  |  | 55,628 |  |  |  | 148,456 |  |  |  | 134,355 |  |
| Cash income tax expense (8) |  |  | (10,878 | ) |  |  | (2,325 | ) |  |  | (19,607 | ) |  |  | (5,595 | ) |
| Adjusted net income |  |  | 58,539 |  |  |  | 53,303 |  |  |  | 128,849 |  |  |  | 128,760 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 697 |  |  |  | 58 |  |  |  | 1,912 |  |  |  | 1,939 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 57,842 |  |  | $ | 53,245 |  |  | $ | 126,937 |  |  | $ | 126,821 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.93 |  |  | $ | 0.82 |  |  | $ | 2.02 |  |  | $ | 1.92 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,316,788 |  |  |  | 65,126,117 |  |  |  | 62,703,269 |  |  |  | 65,992,127 |  |

[0001437749-17-017990:8k_2_02:89]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (8) Amount for the three and nine months ended September 30, 2017 is based on an anticipated cash income tax rate of approximately 17% for the full year ended 2017. Amount for the three and nine months ended September 30, 2016 is based on an anticipated cash income tax rate of approximately 6% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-17-017990:8k_2_02:90]
10

[0001437749-17-017990:8k_2_02:91]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 67,045 |  |  | $ | 48,278 |  |  | $ | 122,719 |  |  | $ | 129,513 |  |
| Expenditures for property and equipment |  |  | (6,628 | ) |  |  | (6,843 | ) |  |  | (16,658 | ) |  |  | (20,847 | ) |
| Free cash flow |  | $ | 60,417 |  |  | $ | 41,435 |  |  | $ | 106,061 |  |  | $ | 108,666 |  |

[0001437749-17-017990:8k_2_02:92]
11
