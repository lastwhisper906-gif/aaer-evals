# GNRC MD&A — 0001437749-16-041147


## mdna

[0001437749-16-041147:mdna:1]
[same as prior period, unchanged from 0001437749-16-036603:mdna:1]

[0001437749-16-041147:mdna:2]
[same as prior period, unchanged from 0001437749-16-036603:mdna:2]

[0001437749-16-041147:mdna:3]
[same as prior period, unchanged from 0001437749-16-036603:mdna:3]

[0001437749-16-041147:mdna:4]
|  | ● | our business, financial and operating results, and future economic performance; |

[0001437749-16-041147:mdna:5]
|  | ● | proposed new product and service offerings; and |

[0001437749-16-041147:mdna:6]
|  | ● | management's goals, expectations and objectives and other similar expressions concerning matters that are not historical facts. |

[0001437749-16-041147:mdna:7]
[same as prior period, unchanged from 0001437749-16-036603:mdna:5]

[0001437749-16-041147:mdna:8]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-16-041147:mdna:9]
|  | ● | availability, cost and quality of raw materials and key components used in producing our products; |

[0001437749-16-041147:mdna:10]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-16-041147:mdna:11]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-16-041147:mdna:12]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-16-041147:mdna:13]
|  | ● | difficulties we may encounter as our business expands globally; |

[0001437749-16-041147:mdna:14]
|  | ● | competitive factors in the industry in which we operate; |

[0001437749-16-041147:mdna:15]
|  | ● | our dependence on our distribution network; |

[0001437749-16-041147:mdna:16]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-16-041147:mdna:17]
|  | ● | loss of our key management and employees; |

[0001437749-16-041147:mdna:18]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-16-041147:mdna:19]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-041147:mdna:20]
[same as prior period, unchanged from 0001437749-16-036603:mdna:7]

[0001437749-16-041147:mdna:21]
[same as prior period, unchanged from 0001437749-16-036603:mdna:8]

[0001437749-16-041147:mdna:22]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-16-041147:mdna:23]
[same as prior period, unchanged from 0001437749-16-036603:mdna:10]

[0001437749-16-041147:mdna:24]
[same as prior period, unchanged from 0001437749-16-036603:mdna:11]

[0001437749-16-041147:mdna:25]
[same as prior period, unchanged from 0001437749-16-036603:mdna:12]

[0001437749-16-041147:mdna:26]
[same as prior period, unchanged from 0001437749-16-036603:mdna:13]

[0001437749-16-041147:mdna:27]
[same as prior period, unchanged from 0001437749-16-036603:mdna:14]

[0001437749-16-041147:mdna:28]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2013 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment (ROI) driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. In addition, the importance of backup power for telecommunications infrastructure is increasing due to the growing importance of uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-16-041147:mdna:29]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators, in particular, home standby and portable generators used for residential applications. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for nine to twelve months following a major power outage event for standby generators. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-16-041147:mdna:30]
[same as prior period, unchanged from 0001437749-16-036603:mdna:17]

[0001437749-16-041147:mdna:31]
Impact of business capital investment cycle.   The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-16-041147:mdna:32]
[same as prior period, unchanged from 0001437749-16-036603:mdna:19]

[0001437749-16-041147:mdna:33]
[same as prior period, unchanged from 0001437749-16-036603:mdna:20]

[0001437749-16-041147:mdna:34]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper, aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, with the Pramac acquisition in March 2016, we have further expanded our commercial and operational presence outside of the United States. This acquisition, along with our existing international presence, exposes us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-16-041147:mdna:35]
We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-16-041147:mdna:36]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 16% to 27% of our net sales occurred in the first quarter, 20% to 25% in the second quarter, 24% to 30% in the third quarter and 25% to 34% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-16-041147:mdna:37]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense increased during the nine months ended September 30, 2016 compared to the nine months ended September 30, 2015, primarily due to additional debt assumed in recent acquisitions and increased borrowings at other foreign subsidiaries. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q for further information.

[0001437749-16-041147:mdna:38]
[same as prior period, unchanged from 0001437749-16-036603:mdna:24]

[0001437749-16-041147:mdna:39]
[same as prior period, unchanged from 0001437749-16-036603:mdna:25]

[0001437749-16-041147:mdna:40]
Three months ended September 30, 2016 compared to the three months ended September 30, 2015

[0001437749-16-041147:mdna:41]
[same as prior period, unchanged from 0001437749-16-036603:mdna:27]

[0001437749-16-041147:mdna:42]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  |  | 13,830 |  |  |  | 3.8 | % |
| Cost of goods sold |  |  | 235,349 |  |  |  | 228,965 |  |  |  | 6,384 |  |  |  | 2.8 | % |
| Gross profit |  |  | 137,772 |  |  |  | 130,326 |  |  |  | 7,446 |  |  |  | 5.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 44,429 |  |  |  | 34,715 |  |  |  | 9,714 |  |  |  | 28.0 | % |
| Research and development |  |  | 9,426 |  |  |  | 8,332 |  |  |  | 1,094 |  |  |  | 13.1 | % |
| General and administrative |  |  | 18,066 |  |  |  | 13,127 |  |  |  | 4,939 |  |  |  | 37.6 | % |
| Amortization of intangible assets |  |  | 9,511 |  |  |  | 6,285 |  |  |  | 3,226 |  |  |  | 51.3 | % |
| Total operating expenses |  |  | 81,432 |  |  |  | 62,459 |  |  |  | 18,973 |  |  |  | 30.4 | % |
| Income from operations |  |  | 56,340 |  |  |  | 67,867 |  |  |  | (11,527 | ) |  |  | -17.0 | % |
| Total other expense, net |  |  | (14,814 | ) |  |  | (14,613 | ) |  |  | (201 | ) |  |  | 1.4 | % |
| Income before provision for income taxes |  |  | 41,526 |  |  |  | 53,254 |  |  |  | (11,728 | ) |  |  | -22.0 | % |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | (3,704 | ) |  |  | -19.3 | % |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | (8,024 | ) |  |  | -23.6 | % |
| Net loss attributable to noncontrolling interests |  |  | (171 | ) |  |  | - |  |  |  | (171 | ) |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  |  | (7,853 | ) |  |  | -23.1 | % |

[0001437749-16-041147:mdna:43]
[same as prior period, unchanged from 0001437749-16-036603:mdna:29]

[0001437749-16-041147:mdna:44]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 299,095 |  |  | $ | 332,213 |  |  |  | (33,118 | ) |  |  | -10.0 | % |
| International |  |  | 74,026 |  |  |  | 27,078 |  |  |  | 46,948 |  |  |  | 173.4 | % |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  |  | 13,830 |  |  |  | 3.8 | % |

[0001437749-16-041147:mdna:45]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 69,309 |  |  | $ | 77,117 |  |  |  | (7,808 | ) |  |  | -10.1 | % |
| International |  |  | 3,527 |  |  |  | 4,055 |  |  |  | (528 | ) |  |  | -13.0 | % |
| Total Adjusted EBITDA |  | $ | 72,836 |  |  | $ | 81,172 |  |  |  | (8,336 | ) |  |  | -10.3 | % |

[0001437749-16-041147:mdna:46]
[same as prior period, unchanged from 0001437749-16-036603:mdna:33]

[0001437749-16-041147:mdna:47]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 192,856 |  |  | $ | 184,968 |  |  |  | 7,888 |  |  |  | 4.3 | % |
| Commercial & industrial products |  |  | 149,676 |  |  |  | 148,234 |  |  |  | 1,442 |  |  |  | 1.0 | % |
| Other |  |  | 30,589 |  |  |  | 26,089 |  |  |  | 4,500 |  |  |  | 17.2 | % |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  |  | 13,830 |  |  |  | 3.8 | % |

[0001437749-16-041147:mdna:48]
Net sales.    The decrease in Domestic sales for the three months ended September 30, 2016 was primarily due to the ongoing significant declines in shipments of mobile products into oil & gas and general rental markets. In addition, shipments of home standby generators declined modestly over the prior year. Partially offsetting these impacts was the contribution from the CHP acquisition.

[0001437749-16-041147:mdna:49]
The increase in International sales for the three months ended September 30, 2016 was primarily due to the contribution from the Pramac acquisition.

[0001437749-16-041147:mdna:50]
The total contribution from non-annualized recent acquisitions to the three months ended September 30, 2016 was $60.8 million.

[0001437749-16-041147:mdna:51]
Gross profit.    Gross profit margin for the third quarter of 2016 was 36.9% compared to 36.3% in the prior-year third quarter. Gross margin was positively impacted by the ongoing favorable impacts from lower commodity prices seen in prior quarters and continued overseas sourcing benefits from a stronger U.S. Dollar, along with an overall favorable organic product mix. These benefits were partially offset by the net mix impact from recent acquisitions.

[0001437749-16-041147:mdna:52]
Operating expenses.    The increase in operating expenses was primarily due to the addition of recurring operating expenses associated with recent acquisitions, and to a lesser extent, increased amortization expense.

[0001437749-16-041147:mdna:53]
Other expense.    The increase in other expense was due to an increase in interest expense resulting from additional debt assumed in recent acquisitions and increased borrowings at other foreign subsidiaries. Additionally, the prior year third quarter included a $2.4 million non-cash loss resulting from an increase in our Term Loan interest rate spread of 25 basis points for an anticipated period of four quarters. The current year third quarter included an additional $3.0 million non-cash loss resulting from a continuation of the 25 basis point spread increase for an anticipated period of five additional quarters.

[0001437749-16-041147:mdna:54]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2016 and 2015 were 37.4% and 36.1%, respectively. The increase in the effective income tax rate is due to a non-recurring discrete tax item impacting the current year third quarter.

[0001437749-16-041147:mdna:55]
Net income attributable to Generac Holdings Inc.    The decrease in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, partially offset by the adjustment for net loss attributable to noncontrolling interests.

[0001437749-16-041147:mdna:56]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the three months ended September 30, 2016 were 23.2% of net sales, consistent with the three months ended September 30, 2015. Adjusted EBITDA margin in the current year third quarter benefitted from overall favorable product mix as well as lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar, offset by increased promotional activities and reduced overall leverage of fixed operating expenses.

[0001437749-16-041147:mdna:57]
Adjusted EBITDA margins for the International segment for the three months ended September 30, 2016 were 4.8% of net sales as compared to 15.0% of net sales for the three months ended September 30, 2015. This decrease was primarily due to the Pramac acquisition, unfavorable sales mix and foreign currency impacts, and reduced operating leverage on lower organic sales volume.

[0001437749-16-041147:mdna:58]
Adjusted Net Income.    Adjusted Net Income of $53.2 million for the three months ended September 30, 2016 decreased 16.1% from $63.4 million for the three months ended September 30, 2015, due to the factors outlined above, an increase in cash income tax expense and adjusted net income attributable to noncontrolling interests.

[0001437749-16-041147:mdna:59]
[same as prior period, unchanged from 0001437749-16-036603:mdna:46]

[0001437749-16-041147:mdna:60]
Nine months ended September 30, 2016 compared to the nine months ended September 30, 2015

[0001437749-16-041147:mdna:61]
[same as prior period, unchanged from 0001437749-16-036603:mdna:48]

[0001437749-16-041147:mdna:62]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,027,032 |  |  | $ | 959,469 |  |  |  | 67,563 |  |  |  | 7.0 | % |
| Cost of goods sold |  |  | 667,053 |  |  |  | 630,643 |  |  |  | 36,410 |  |  |  | 5.8 | % |
| Gross profit |  |  | 359,979 |  |  |  | 328,826 |  |  |  | 31,153 |  |  |  | 9.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 124,064 |  |  |  | 93,317 |  |  |  | 30,747 |  |  |  | 32.9 | % |
| Research and development |  |  | 27,512 |  |  |  | 24,907 |  |  |  | 2,605 |  |  |  | 10.5 | % |
| General and administrative |  |  | 55,492 |  |  |  | 40,897 |  |  |  | 14,595 |  |  |  | 35.7 | % |
| Amortization of intangible assets |  |  | 25,525 |  |  |  | 17,460 |  |  |  | 8,065 |  |  |  | 46.2 | % |
| Total operating expenses |  |  | 232,593 |  |  |  | 176,581 |  |  |  | 56,012 |  |  |  | 31.7 | % |
| Income from operations |  |  | 127,386 |  |  |  | 152,245 |  |  |  | (24,859 | ) |  |  | -16.3 | % |
| Total other expense, net |  |  | (37,065 | ) |  |  | (44,816 | ) |  |  | 7,751 |  |  |  | -17.3 | % |
| Income before provision for income taxes |  |  | 90,321 |  |  |  | 107,429 |  |  |  | (17,108 | ) |  |  | -15.9 | % |
| Provision for income taxes |  |  | 33,154 |  |  |  | 38,864 |  |  |  | (5,710 | ) |  |  | -14.7 | % |
| Net income |  |  | 57,167 |  |  |  | 68,565 |  |  |  | (11,398 | ) |  |  | -16.6 | % |
| Net loss attributable to noncontrolling interests |  |  | (112 | ) |  |  | - |  |  |  | (112 | ) |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 57,279 |  |  | $ | 68,565 |  |  |  | (11,286 | ) |  |  | -16.5 | % |

[0001437749-16-041147:mdna:63]
[same as prior period, unchanged from 0001437749-16-036603:mdna:50]

[0001437749-16-041147:mdna:64]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 833,831 |  |  | $ | 877,942 |  |  |  | (44,111 | ) |  |  | -5.0 | % |
| International |  |  | 193,201 |  |  |  | 81,527 |  |  |  | 111,674 |  |  |  | 137.0 | % |
| Total net sales |  | $ | 1,027,032 |  |  | $ | 959,469 |  |  |  | 67,563 |  |  |  | 7.0 | % |

[0001437749-16-041147:mdna:65]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 173,521 |  |  | $ | 180,018 |  |  |  | (6,497 | ) |  |  | -3.6 | % |
| International |  |  | 13,050 |  |  |  | 10,714 |  |  |  | 2,336 |  |  |  | 21.8 | % |
| Total Adjusted EBITDA |  | $ | 186,571 |  |  | $ | 190,732 |  |  |  | (4,161 | ) |  |  | -2.2 | % |

[0001437749-16-041147:mdna:66]
[same as prior period, unchanged from 0001437749-16-036603:mdna:53]

[0001437749-16-041147:mdna:67]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 533,572 |  |  | $ | 475,268 |  |  |  | 58,304 |  |  |  | 12.3 | % |
| Commercial & industrial products |  |  | 409,396 |  |  |  | 416,577 |  |  |  | (7,181 | ) |  |  | -1.7 | % |
| Other |  |  | 84,064 |  |  |  | 67,624 |  |  |  | 16,440 |  |  |  | 24.3 | % |
| Total net sales |  | $ | 1,027,032 |  |  | $ | 959,469 |  |  |  | 67,563 |  |  |  | 7.0 | % |

[0001437749-16-041147:mdna:68]
Net sales.    The decrease in Domestic sales for the nine months ended September 30, 2016 was primarily due to the significant reduction in shipments of mobile products into oil & gas and general rental markets, along with a modest decline in shipments of home standby generators over the prior period. Partially offsetting these impacts was the contribution from the CHP acquisition.

[0001437749-16-041147:mdna:69]
The increase in International sales for the nine months ended September 30, 2016 was largely due to the contribution from the Pramac acquisition, partially offset by declines in organic shipments into the United Kingdom and Latin American markets.

[0001437749-16-041147:mdna:70]
The total contribution from non-annualized recent acquisitions to the nine months ended September 30, 2016 was $186.1 million.

[0001437749-16-041147:mdna:71]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the nine months ended September 30, 2016 includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write-downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. The decrease in net income attributable to Generac Holdings Inc. was primarily due to these charges and the other factors outlined in this section, partially offset by the adjustment for net loss attributable to noncontrolling interests.

[0001437749-16-041147:mdna:72]
Gross profit.    Gross profit margin for the first nine months of 2016 was 35.1% compared to 34.3% in the first nine months of 2015, which includes the impact of the aforementioned $2.7 million of business optimization charges classified within cost of goods sold, as well as $4.2 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these adjustments, gross profit margin was 35.7%, an improvement of 140 basis points over the prior year. The increase was primarily due to the favorable impacts from lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar, along with an overall favorable organic product mix. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current year. These factors were partially offset by the net mix impact from recent acquisitions.

[0001437749-16-041147:mdna:73]
Operating expenses.    Excluding the impact of the aforementioned $4.4 million of business optimization charges classified within operating expenses, operating expenses increased $51.6 million, or 29.2%, to $228.2 million for the nine months ended September 30, 2016 from $176.6 million for the nine months ended September 30, 2015. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions and increased amotization expense.

[0001437749-16-041147:mdna:74]
Other expense.    The decrease in other expense was primarily due to a prior year non-cash $4.8 million loss on extinguishment of debt resulting from $150.0 million of voluntary prepayments of term loan debt, which did not repeat in the current year. Additionally, the prior year included a $2.4 million non-cash loss resulting from an increase in our Term Loan interest rate spread of 25 basis points, while the current year included an additional $3.0 million non-cash loss resulting from a continuation of the 25 basis point spread increase.

[0001437749-16-041147:mdna:75]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2016 and 2015 were 36.7% and 36.2%, respectively.

[0001437749-16-041147:mdna:76]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the nine months ended September 30, 2016 were 20.8% of net sales as compared to 20.5% of net sales for the nine months ended September 30, 2015. This increase was primarily due to overall favorable product mix as well as the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar, partially offset by increased promotional activities and reduced overall leverage of fixed operating expenses.

[0001437749-16-041147:mdna:77]
Adjusted EBITDA margins for the International segment for the nine months ended September 30, 2016 were 6.8% of net sales as compared to 13.1% of net sales for the nine months ended September 30, 2015. This decrease was primarily due to the Pramac acquisition, unfavorable sales mix and foreign currency impacts, lower absorption of fixed manufacturing overhead costs and reduced leverage of operating expenses on lower organic sales volume.

[0001437749-16-041147:mdna:78]
Adjusted Net Income.    Adjusted Net Income of $126.8 million for the nine months ended September 30, 2016 decreased 4.7% from $133.1 million for the nine months ended September 30, 2015, due to the factors outlined above and adjusted net income attributable to noncontrolling interests, partially offset by a decrease in cash income tax expense.

[0001437749-16-041147:mdna:79]
[same as prior period, unchanged from 0001437749-16-036603:mdna:66]

[0001437749-16-041147:mdna:80]
[same as prior period, unchanged from 0001437749-16-036603:mdna:67]

[0001437749-16-041147:mdna:81]
[same as prior period, unchanged from 0001437749-16-036603:mdna:68]

[0001437749-16-041147:mdna:82]
The Company’s credit agreements provide for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. On November 2, 2016, the Term Loan maturity date was extended to May 31, 2023. (See Note 14, “Subsequent Events” to the condensed consolidated financial statements.) The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of September 30, 2016 was above 3.00 to 1.00. As of September 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-041147:mdna:83]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of September 30, 2016, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all covenants of the Amended ABL Facility.

[0001437749-16-041147:mdna:84]
[same as prior period, unchanged from 0001437749-16-036603:mdna:71]

[0001437749-16-041147:mdna:85]
At September 30, 2016, we had cash and cash equivalents on hand of $54.2 million and $144.9 million of availability under our Amended ABL Facility, net of outstanding letters of credit.

[0001437749-16-041147:mdna:86]
In August 2015, the Company’s Board of Directors approved a $200.0 million stock repurchase program. Under the program, the Company may repurchase up to $200.0 million of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. For the three months ended September 30, 2016, the Company repurchased 1,798,206 shares of its common stock for $65.4 million. Since the inception of the program, the Company has repurchased 6,036,706 shares of its common stock for $199.9 million, all funded with cash on hand. The repurchases in the third quarter of 2016 completed the total authorized amount under the program. See Note 14, “Subsequent Events” to the condensed consolidated financial statements for further discussion of our stock repurchase programs.

[0001437749-16-041147:mdna:87]
[same as prior period, unchanged from 0001437749-16-036603:mdna:74]

[0001437749-16-041147:mdna:88]
[same as prior period, unchanged from 0001437749-16-036603:mdna:75]

[0001437749-16-041147:mdna:89]
[same as prior period, unchanged from 0001437749-16-036603:mdna:76]

[0001437749-16-041147:mdna:90]
Nine months ended September 30, 2016 compared to the nine months ended September 30, 2015

[0001437749-16-041147:mdna:91]
[same as prior period, unchanged from 0001437749-16-036603:mdna:78]

[0001437749-16-041147:mdna:92]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 129,513 |  |  | $ | 76,859 |  |  |  | 52,654 |  |  |  | 68.5 | % |
| Net cash used in investing activities |  |  | (80,884 | ) |  |  | (94,480 | ) |  |  | 13,596 |  |  |  | -14.4 | % |
| Net cash used in financing activities |  |  | (110,667 | ) |  |  | (122,754 | ) |  |  | 12,087 |  |  |  | -9.8 | % |

[0001437749-16-041147:mdna:93]
The 68.5% increase in net cash provided by operating activities was primarily driven by a reduction in working capital investment during the current year as compared to the larger investment that was incurred in the prior year, partially offset by an overall decline in operating earnings.

[0001437749-16-041147:mdna:94]
Net cash used in investing activities for the nine months ended September 30, 2016 primarily represents cash payments of $60.9 million related to the acquisition of Pramac and $20.8 million for the purchase of property and equipment. Net cash used in investing activities for the nine months ended September 30, 2015 primarily represents cash payments of $74.5 million related to the acquisition of CHP and $20.1 million for the purchase of property and equipment.

[0001437749-16-041147:mdna:95]
Net cash used in financing activities for the nine months ended September 30, 2016 primarily represents $99.9 million of payments for the repurchase of the Company’s common stock, $19.2 million of debt repayments ($11.0 million of long-term borrowings and $8.2 million of short-term borrowings) and $12.3 million related to the net share settlement of equity awards. These payments were partially offset by $14.1 million cash proceeds from short-term borrowings and a $6.8 million cash inflow related to excess tax benefits of equity awards.

[0001437749-16-041147:mdna:96]
Net cash used in financing activities for the nine months ended September 30, 2015 primarily represents $165.8 million of debt repayments ($150.6 million of long-term borrowings and $15.2 million of short-term borrowings) partially offset by $114.3 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the ABL facility and $14.3 million from short-term borrowings). In addition, the Company paid $64.4 million for the repurchase of its common stock and $12.4 million related to the net share settlement of equity awards, which was partially offset by an $8.9 million cash inflow related to the excess tax benefits of equity awards.

[0001437749-16-041147:mdna:97]
[same as prior period, unchanged from 0001437749-16-036603:mdna:84]

[0001437749-16-041147:mdna:98]
In connection with the Pramac acquisition, the Company assumed $21.1 million of short-term borrowings and $18.6 million of long-term debt and capital lease obligations. Refer to Note 2, “Acquisitions,” to the condensed consolidated financial statements for further information. Other than the assumption of the Pramac debt, there have been no material changes to our contractual obligations since the February 26, 2016 filing of our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-041147:mdna:99]
[same as prior period, unchanged from 0001437749-16-036603:mdna:86]

[0001437749-16-041147:mdna:100]
[same as prior period, unchanged from 0001437749-16-036603:mdna:87]

[0001437749-16-041147:mdna:101]
[same as prior period, unchanged from 0001437749-16-036603:mdna:88]

[0001437749-16-041147:mdna:102]
[same as prior period, unchanged from 0001437749-16-036603:mdna:89]

[0001437749-16-041147:mdna:103]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2015, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; derivative accounting; income taxes and share based compensation.

[0001437749-16-041147:mdna:104]
[same as prior period, unchanged from 0001437749-16-036603:mdna:91]

[0001437749-16-041147:mdna:105]
[same as prior period, unchanged from 0001437749-16-036603:mdna:92]

[0001437749-16-041147:mdna:106]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement dated as of May 31, 2013, as amended. To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-041147:mdna:107]
[same as prior period, unchanged from 0001437749-16-036603:mdna:94]

[0001437749-16-041147:mdna:108]
|  | • | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-16-041147:mdna:109]
|  | • | to allocate resources to enhance the financial performance of our business; |

[0001437749-16-041147:mdna:110]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2016 proxy statement; |

[0001437749-16-041147:mdna:111]
|  | • | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-16-041147:mdna:112]
|  | • | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-16-041147:mdna:113]
[same as prior period, unchanged from 0001437749-16-036603:mdna:96]

[0001437749-16-041147:mdna:114]
|  | • | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-16-041147:mdna:115]
|  | • | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our company, including our ability to service our debt and other cash needs; and |

[0001437749-16-041147:mdna:116]
|  | • | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-16-041147:mdna:117]
[same as prior period, unchanged from 0001437749-16-036603:mdna:98]

[0001437749-16-041147:mdna:118]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains and write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-16-041147:mdna:119]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-16-041147:mdna:120]
|  | • | are non-cash in nature, such as share-based compensation. |

[0001437749-16-041147:mdna:121]
We explain in more detail in footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-16-041147:mdna:122]
[same as prior period, unchanged from 0001437749-16-036603:mdna:101]

[0001437749-16-041147:mdna:123]
|  | • | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-16-041147:mdna:124]
|  | • | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-16-041147:mdna:125]
|  | • | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-16-041147:mdna:126]
|  | • | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-16-041147:mdna:127]
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-16-041147:mdna:128]
|  | • | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-16-041147:mdna:129]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-16-041147:mdna:130]
[same as prior period, unchanged from 0001437749-16-036603:mdna:104]

[0001437749-16-041147:mdna:131]
[same as prior period, unchanged from 0001437749-16-036603:mdna:105]

[0001437749-16-041147:mdna:132]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Net loss attributable to noncontrolling interests (a) |  |  | (171 | ) |  |  | - |  |  |  | (112 | ) |  |  | - |  |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | 57,167 |  |  |  | 68,565 |  |
| Interest expense |  |  | 11,299 |  |  |  | 10,210 |  |  |  | 33,714 |  |  |  | 32,241 |  |
| Depreciation and amortization |  |  | 14,900 |  |  |  | 10,597 |  |  |  | 41,343 |  |  |  | 29,760 |  |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | 33,154 |  |  |  | 38,864 |  |
| Non-cash write-down and other adjustments (b) |  |  | (1,093 | ) |  |  | 2,115 |  |  |  | 1,689 |  |  |  | 4,091 |  |
| Non-cash share-based compensation expense (c) |  |  | 2,419 |  |  |  | 1,799 |  |  |  | 7,805 |  |  |  | 6,889 |  |
| Loss on extinguishment of debt (d) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate (e) |  |  | 2,957 |  |  |  | 2,381 |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and credit facility fees (f) |  |  | 739 |  |  |  | 317 |  |  |  | 1,499 |  |  |  | 999 |  |
| Business optimization expenses (g) |  |  | 58 |  |  |  | 5 |  |  |  | 7,164 |  |  |  | 1,743 |  |
| Other |  |  | 31 |  |  |  | 494 |  |  |  | 79 |  |  |  | 404 |  |
| Adjusted EBITDA |  |  | 72,836 |  |  |  | 81,172 |  |  |  | 186,571 |  |  |  | 190,732 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 708 |  |  |  | - |  |  |  | 3,015 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 72,128 |  |  | $ | 81,172 |  |  | $ | 183,556 |  |  | $ | 190,732 |  |

[0001437749-16-041147:mdna:133]
24

[0001437749-16-041147:mdna:134]
(a)   Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.3 million and $6.9 million for the three and nine months ended September 30, 2016, respectively.

[0001437749-16-041147:mdna:135]
(b)   Represents the following non-cash charges for the three and nine months ended September 30, 2016 and 2015: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments.

[0001437749-16-041147:mdna:136]
[same as prior period, unchanged from 0001437749-16-036603:mdna:109]

[0001437749-16-041147:mdna:137]
|  | ● | The gains/losses on disposals of assets result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-16-041147:mdna:138]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and |

[0001437749-16-041147:mdna:139]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. |

[0001437749-16-041147:mdna:140]
(c)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-16-041147:mdna:141]
[same as prior period, unchanged from 0001437749-16-036603:mdna:112]

[0001437749-16-041147:mdna:142]
(e) For the three and nine months ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on current projections. For the three and nine months ended September 30, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 times effective third quarter 2015 and remaining above 3.0 times based on projections at the time.

[0001437749-16-041147:mdna:143]
(f) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-16-041147:mdna:144]
(g) For the nine months ended September 30, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry. For the three and nine months ended September 30, 2015, represents severance and other non-recurring restructuring charges related to the integration of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-16-041147:mdna:145]
[same as prior period, unchanged from 0001437749-16-036603:mdna:115]

[0001437749-16-041147:mdna:146]
[same as prior period, unchanged from 0001437749-16-036603:mdna:116]

[0001437749-16-041147:mdna:147]
[same as prior period, unchanged from 0001437749-16-036603:mdna:117]

[0001437749-16-041147:mdna:148]
[same as prior period, unchanged from 0001437749-16-036603:mdna:118]

[0001437749-16-041147:mdna:149]
[same as prior period, unchanged from 0001437749-16-036603:mdna:119]

[0001437749-16-041147:mdna:150]
|  | • | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-16-041147:mdna:151]
|  | • | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-16-041147:mdna:152]
|  | • | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-16-041147:mdna:153]
[same as prior period, unchanged from 0001437749-16-036603:mdna:121]

[0001437749-16-041147:mdna:154]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Net loss attributable to noncontrolling interests |  |  | (171 | ) |  |  | - |  |  |  | (112 | ) |  |  | - |  |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | 57,167 |  |  |  | 68,565 |  |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | 33,154 |  |  |  | 38,864 |  |
| Income before provision for income taxes |  |  | 41,526 |  |  |  | 53,254 |  |  |  | 90,321 |  |  |  | 107,429 |  |
| Amortization of intangible assets |  |  | 9,511 |  |  |  | 6,285 |  |  |  | 25,525 |  |  |  | 17,460 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,107 |  |  |  | 1,024 |  |  |  | 3,229 |  |  |  | 4,368 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate |  |  | 2,957 |  |  |  | 2,381 |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 469 |  |  |  | 979 |  |  |  | 5,159 |  |  |  | 1,482 |  |
| Business optimization expenses |  |  | 58 |  |  |  | 5 |  |  |  | 7,164 |  |  |  | 1,743 |  |
| Adjusted net income before provision for income taxes |  |  | 55,628 |  |  |  | 63,928 |  |  |  | 134,355 |  |  |  | 139,658 |  |
| Cash income tax expense (b) |  |  | (2,325 | ) |  |  | (500 | ) |  |  | (5,595 | ) |  |  | (6,535 | ) |
| Adjusted net income |  |  | 53,303 |  |  |  | 63,428 |  |  |  | 128,760 |  |  |  | 133,123 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 58 |  |  |  | - |  |  |  | 1,939 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 53,245 |  |  | $ | 63,428 |  |  | $ | 126,821 |  |  | $ | 133,123 |  |
| Adjusted net income per common share attributable to Generac Holdings, Inc. - diluted: |  | $ | 0.82 |  |  | $ | 0.92 |  |  | $ | 1.92 |  |  | $ | 1.91 |  |
| Weighted average common shares outstanding - diluted: |  |  | 65,126,117 |  |  |  | 69,182,465 |  |  |  | 65,992,127 |  |  |  | 69,781,300 |  |

[0001437749-16-041147:mdna:155]
[same as prior period, unchanged from 0001437749-16-036603:mdna:123]

[0001437749-16-041147:mdna:156]
(b) Amount for the three and nine months ended September 30, 2016 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2016. Amount for the three and nine months ended September 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2015. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-16-041147:mdna:157]
[same as prior period, unchanged from 0001437749-16-036603:mdna:125]

[0001437749-16-041147:mdna:158]
[same as prior period, unchanged from 0001437749-16-036603:mdna:126]
