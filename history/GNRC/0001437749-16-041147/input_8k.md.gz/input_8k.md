# GNRC 8-K — 0001437749-16-040241 filed 2016-10-26

## item codes, every 8-K on or before 2016-11-04

- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2016-11-04

- none on or before 2016-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-040241:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-040241:8k_2_02:2]
Exhibit 99.1

[0001437749-16-040241:8k_2_02:3]
Generac Reports Third Quarter 2016 Results

[0001437749-16-040241:8k_2_02:4]
Residential product shipments exceed expectations; Outlook raised for 2016

[0001437749-16-040241:8k_2_02:5]
WAUKESHA, WISCONSIN, (October 26, 2016) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its third quarter ended September 30, 2016.

[0001437749-16-040241:8k_2_02:6]
Third Quarter 2016 Highlights

[0001437749-16-040241:8k_2_02:7]
| ● | Net sales increased 3.8% to $373.1 million during the third quarter of 2016 as compared to $359.3 million in the prior-year third quarter, including $60.8 million of contribution from recent acquisitions. |

[0001437749-16-040241:8k_2_02:8]
|  | - | Domestic segment sales were $299.1 million as compared to $332.2 million in the prior-year quarter, which was primarily due to a continued decline in shipments of mobile products given ongoing oil & gas weakness, partially offset by the contribution from the Country Home Products acquisition. |

[0001437749-16-040241:8k_2_02:9]
|  | - | International segment sales increased to $74.0 million as compared to $27.1 million in the prior-year quarter, which was due to the contribution from the Pramac acquisition. |

[0001437749-16-040241:8k_2_02:10]
| ● | Net income attributable to the Company during the third quarter of 2016 was $26.2 million, or $0.40 per share, as compared to $34.0 million, or $0.49 per share, for the same period of 2015. |

[0001437749-16-040241:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $53.2 million, or $0.82 per share, as compared to $63.4 million, or $0.92 per share, in the third quarter of 2015. |

[0001437749-16-040241:8k_2_02:12]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $72.1 million as compared to $81.2 million in the third quarter last year. |

[0001437749-16-040241:8k_2_02:13]
| ● | Cash flow from operations was $48.3 million as compared to $35.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $41.4 million as compared to $29.4 million in the third quarter of 2015. |

[0001437749-16-040241:8k_2_02:14]
| ● | The Company repurchased 1.80 million shares of its common stock during the third quarter for $65.4 million, which completes the total authorized amount under its previously announced share repurchase program. On October 24, 2016, the Board of Directors of the Company approved a new share repurchase program, authorizing the repurchase of an additional $250 million of its common stock over the next 24 months. |

[0001437749-16-040241:8k_2_02:15]
“An increase in power outages coupled with successful promotional campaigns led to shipments of residential products that exceeded our expectations during the quarter,” said Aaron Jagdfeld, President and Chief Executive Officer. “This outperformance helped to offset continued weakness for our mobile products both domestically and internationally. We also continued to generate strong free cash flow during the quarter which allowed us to complete our share repurchase program nearly a year ahead of the original two-year timeframe, giving us confidence to authorize a new share repurchase program.”

[0001437749-16-040241:8k_2_02:16]
Additional Third Quarter 2016 Consolidated Highlights

[0001437749-16-040241:8k_2_02:17]
Net sales increased 3.8% to $373.1 million during the third quarter of 2016 as compared to $359.3 million in the prior-year third quarter. Residential product sales increased 4.3% to $192.9 million as compared to $185.0 million in the prior year. Commercial & Industrial (C&I) product sales increased 1.0% to $149.7 million as compared to $148.2 million in the prior year.

[0001437749-16-040241:8k_2_02:18]
Gross profit margin improved 60 basis points to 36.9% compared to 36.3% in the prior-year third quarter. Gross margin was positively impacted by the ongoing favorable impacts from lower commodity prices seen in prior quarters and continued overseas sourcing benefits from a stronger U.S. dollar, along with an overall favorable organic product mix. These benefits were partially offset by the net mix impact from recent acquisitions.

[0001437749-16-040241:8k_2_02:19]
Operating expenses increased $19.0 million, or 30.4%, as compared to the third quarter of 2015. The increase was primarily driven by the addition of recurring operating expenses associated with recent acquisitions, and to a lesser extent, increased amortization expense.

[0001437749-16-040241:8k_2_02:20]
Cash flow from operations was $48.3 million as compared to $35.3 million in the prior year, and free cash flow was $41.4 million as compared to $29.4 million in the same period last year. The increases in cash flow were primarily driven by a reduction in working capital investment during the current-year quarter as compared to the larger investment in the prior year, partially offset by an overall decline in operating earnings.

[0001437749-16-040241:8k_2_02:21]
The Company repurchased 1.80 million shares of its common stock during the third quarter of 2016 for $65.4 million, which completes the total authorized amount under its share repurchase program which was announced in August 2015. Under the program, a total of 6.0 million shares of common stock were repurchased for approximately $200 million. On October 24, 2016, the Board of Directors of the Company approved a new share repurchase program which authorizes the repurchase of an additional $250 million of its common stock over a 24 month period.

[0001437749-16-040241:8k_2_02:22]
Business Segment Results

[0001437749-16-040241:8k_2_02:23]
Domestic Segment

[0001437749-16-040241:8k_2_02:24]
Domestic segment sales were $299.1 million as compared to $332.2 million in the prior-year quarter. The vast majority of the decline was due to the ongoing significant declines in shipments of mobile products into oil & gas and general rental markets. In addition, shipments of home standby generators declined modestly over the prior year, but exceeded expectations. Partially offsetting these impacts was the contribution from the Country Home Products acquisition, which closed on August 1, 2015.

[0001437749-16-040241:8k_2_02:25]
Adjusted EBITDA for the segment was $69.3 million, or 23.2% of net sales, as compared to $77.1 million in the prior year, also 23.2% of net sales. Adjusted EBITDA margin in the current year benefitted from overall favorable product mix as well as lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar, offset by increased promotional activities and reduced overall leverage of fixed operating expenses.

[0001437749-16-040241:8k_2_02:26]
International Segment

[0001437749-16-040241:8k_2_02:27]
International segment sales, primarily consisting of C&I products, increased to $74.0 million as compared to $27.1 million in the prior-year quarter. The increase was primarily due to the contribution from the Pramac acquisition, which closed on March 1, 2016.

[0001437749-16-040241:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, declined to $3.5 million, or 4.8% of net sales, as compared to $4.1 million, or 15.0% of net sales, in the prior year. The decline in adjusted EBITDA margin as compared to the prior year was primarily due to the Pramac acquisition, unfavorable sales mix and foreign currency impacts, and reduced operating leverage on lower organic sales volume.

[0001437749-16-040241:8k_2_02:29]
2016 Outlook Update

[0001437749-16-040241:8k_2_02:30]
The Company is revising upward its guidance for revenue growth for the full year 2016, which is primarily due to an increased outlook for residential products as a result of the higher power outage activity experienced thus far during the second half of 2016. Full-year net sales are now expected to increase between 9 to 10% over the prior year, which is an increase from the 6 to 8% growth previously expected.  Total organic sales on a constant currency basis are now anticipated to decline between 8 to 9%, which is an improvement from the previous assumption of down between 10 and 13%.

[0001437749-16-040241:8k_2_02:31]
Net income margins, before deducting for non-controlling interests, are still expected to be approximately 7% and adjusted EBITDA margins, also before deducting for non-controlling interests, are also still expected to be approximately 19.5% for the full-year 2016. Operating and free cash flow generation is expected to increase significantly over the prior year, benefitting from the strong conversion of adjusted net income.

[0001437749-16-040241:8k_2_02:32]
“Despite a challenging power outage environment over the last few years, our market position for residential products remains strong, retail placement is currently at all-time highs, and the number of active dealers has returned back to peak levels,” continued Mr. Jagdfeld. “The moderate improvement in power outage activity we have experienced recently should provide an opportunity for us to better leverage the innovative sales and marketing programs for home standby generators that we have implemented over the last several years. Although business conditions in several of our other end markets remain soft, we continue to make strategic investments in new products, technologies and infrastructure across the business to support the next leg of growth that we believe will occur as these end markets eventually recover.”

[0001437749-16-040241:8k_2_02:33]
Conference Call and Webcast

[0001437749-16-040241:8k_2_02:34]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, October 26, 2016 to discuss highlights of the third quarter of 2016 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 1156253.

[0001437749-16-040241:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-16-040241:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 1156253. The telephonic replay will be available for 30 days.

[0001437749-16-040241:8k_2_02:37]
About Generac

[0001437749-16-040241:8k_2_02:38]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-040241:8k_2_02:39]
Forward-looking Information

[0001437749-16-040241:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-16-040241:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-16-040241:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-16-040241:8k_2_02:43]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-16-040241:8k_2_02:44]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-16-040241:8k_2_02:45]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-16-040241:8k_2_02:46]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-16-040241:8k_2_02:47]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-16-040241:8k_2_02:48]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-16-040241:8k_2_02:49]
|  | ● | loss of key management and employees; |

[0001437749-16-040241:8k_2_02:50]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-16-040241:8k_2_02:51]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-16-040241:8k_2_02:52]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2015 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-16-040241:8k_2_02:53]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-16-040241:8k_2_02:54]
Reconciliations to GAAP Financial Metrics

[0001437749-16-040241:8k_2_02:55]
Adjusted EBITDA

[0001437749-16-040241:8k_2_02:56]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-16-040241:8k_2_02:57]
Adjusted Net Income

[0001437749-16-040241:8k_2_02:58]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-16-040241:8k_2_02:59]
Free Cash Flow

[0001437749-16-040241:8k_2_02:60]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-16-040241:8k_2_02:61]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-16-040241:8k_2_02:62]
SOURCE: Generac Holdings Inc.

[0001437749-16-040241:8k_2_02:63]
CONTACT:

[0001437749-16-040241:8k_2_02:64]
Michael W. Harris

[0001437749-16-040241:8k_2_02:65]
Vice President – Finance

[0001437749-16-040241:8k_2_02:66]
(262) 544-4811 x2675

[0001437749-16-040241:8k_2_02:67]
Michael.Harris@Generac.com

[0001437749-16-040241:8k_2_02:68]
5

[0001437749-16-040241:8k_2_02:69]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-16-040241:8k_2_02:70]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |
| Costs of goods sold |  |  | 235,349 |  |  |  | 228,965 |  |  |  | 667,053 |  |  |  | 630,643 |  |
| Gross profit |  |  | 137,772 |  |  |  | 130,326 |  |  |  | 359,979 |  |  |  | 328,826 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 44,429 |  |  |  | 34,715 |  |  |  | 124,064 |  |  |  | 93,317 |  |
| Research and development |  |  | 9,426 |  |  |  | 8,332 |  |  |  | 27,512 |  |  |  | 24,907 |  |
| General and administrative |  |  | 18,066 |  |  |  | 13,127 |  |  |  | 55,492 |  |  |  | 40,897 |  |
| Amortization of intangibles |  |  | 9,511 |  |  |  | 6,285 |  |  |  | 25,525 |  |  |  | 17,460 |  |
| Total operating expenses |  |  | 81,432 |  |  |  | 62,459 |  |  |  | 232,593 |  |  |  | 176,581 |  |
| Income from operations |  |  | 56,340 |  |  |  | 67,867 |  |  |  | 127,386 |  |  |  | 152,245 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,299 | ) |  |  | (10,210 | ) |  |  | (33,714 | ) |  |  | (32,241 | ) |
| Investment income |  |  | – |  |  |  | 39 |  |  |  | 36 |  |  |  | 111 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | - |  |  |  | – |  |  |  | (4,795 | ) |
| Loss on change in contractual interest rate |  |  | (2,957 | ) |  |  | (2,381 | ) |  |  | (2,957 | ) |  |  | (2,381 | ) |
| Costs related to acquisition |  |  | (577 | ) |  |  | (153 | ) |  |  | (994 | ) |  |  | (153 | ) |
| Other, net |  |  | 19 |  |  |  | (1,908 | ) |  |  | 564 |  |  |  | (5,357 | ) |
| Total other expense, net |  |  | (14,814 | ) |  |  | (14,613 | ) |  |  | (37,065 | ) |  |  | (44,816 | ) |
| Income before provision for income taxes |  |  | 41,526 |  |  |  | 53,254 |  |  |  | 90,321 |  |  |  | 107,429 |  |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | 33,154 |  |  |  | 38,864 |  |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | 57,167 |  |  |  | 68,565 |  |
| Net loss attributable to noncontrolling interests |  |  | (171 | ) |  |  | - |  |  |  | (112 | ) |  |  | - |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 0.41 |  |  | $ | 0.50 |  |  | $ | 0.87 |  |  | $ | 1.00 |  |
| Weighted average common shares outstanding - basic: |  |  | 64,615,935 |  |  |  | 68,175,466 |  |  |  | 65,506,469 |  |  |  | 68,642,479 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.40 |  |  | $ | 0.49 |  |  | $ | 0.87 |  |  | $ | 0.98 |  |
| Weighted average common shares outstanding - diluted: |  |  | 65,126,117 |  |  |  | 69,182,465 |  |  |  | 65,992,127 |  |  |  | 69,781,300 |  |
| Comprehensive income |  | $ | 26,647 |  |  | $ | 31,899 |  |  | $ | 45,723 |  |  | $ | 59,939 |  |

[0001437749-16-040241:8k_2_02:71]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-16-040241:8k_2_02:72]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 54,163 |  |  | $ | 115,857 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 244,722 |  |  |  | 182,185 |  |
| Inventories |  |  | 359,363 |  |  |  | 325,375 |  |
| Prepaid expenses and other assets |  |  | 13,185 |  |  |  | 8,600 |  |
| Total current assets |  |  | 671,433 |  |  |  | 632,017 |  |
| Property and equipment, net |  |  | 207,504 |  |  |  | 184,213 |  |
| Customer lists, net |  |  | 49,776 |  |  |  | 39,313 |  |
| Patents, net |  |  | 50,640 |  |  |  | 53,772 |  |
| Other intangible assets, net |  |  | 3,111 |  |  |  | 2,768 |  |
| Tradenames, net |  |  | 161,451 |  |  |  | 161,057 |  |
| Goodwill |  |  | 711,794 |  |  |  | 669,719 |  |
| Deferred income taxes |  |  | 7,693 |  |  |  | 34,812 |  |
| Other assets |  |  | 3,506 |  |  |  | 964 |  |
| Total assets |  | $ | 1,866,908 |  |  | $ | 1,778,635 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 35,517 |  |  | $ | 8,594 |  |
| Accounts payable |  |  | 145,894 |  |  |  | 108,332 |  |
| Accrued wages and employee benefits |  |  | 21,041 |  |  |  | 13,101 |  |
| Other accrued liabilities |  |  | 92,415 |  |  |  | 82,540 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 38,712 |  |  |  | 657 |  |
| Total current liabilities |  |  | 333,579 |  |  |  | 213,224 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,013,671 |  |  |  | 1,037,132 |  |
| Deferred income taxes |  |  | 7,201 |  |  |  | 4,950 |  |
| Other long-term liabilities |  |  | 62,330 |  |  |  | 57,458 |  |
| Total liabilities |  |  | 1,416,781 |  |  |  | 1,312,764 |  |
| Redeemable noncontrolling interests |  |  | 36,269 |  |  |  | – |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,144,760 and 69,582,669 shares issued at September 30, 2016 and December 31, 2015, respectively |  |  | 701 |  |  |  | 696 |  |
| Additional paid-in capital |  |  | 446,267 |  |  |  | 443,109 |  |
| Treasury stock, at cost |  |  | (212,358 | ) |  |  | (111,516 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 415,452 |  |  |  | 358,173 |  |
| Accumulated other comprehensive loss |  |  | (34,031 | ) |  |  | (22,475 | ) |
| Stockholders’ equity attributable to Generac Holdings, Inc. |  |  | 413,915 |  |  |  | 465,871 |  |
| Noncontrolling interests |  |  | (57 | ) |  |  | – |  |
| Total stockholders' equity |  |  | 413,858 |  |  |  | 465,871 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,866,908 |  |  | $ | 1,778,635 |  |

[0001437749-16-040241:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-16-040241:8k_2_02:74]
|  |  | Nine Months Ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 57,167 |  |  | $ | 68,565 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 15,818 |  |  |  | 12,300 |  |
| Amortization of intangible assets |  |  | 25,525 |  |  |  | 17,460 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,229 |  |  |  | 4,368 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate |  |  | 2,957 |  |  |  | 2,381 |  |
| Deferred income taxes |  |  | 22,909 |  |  |  | 27,319 |  |
| Share-based compensation expense |  |  | 7,805 |  |  |  | 6,889 |  |
| Other |  |  | (45 | ) |  |  | 377 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (11,642 | ) |  |  | (14,838 | ) |
| Inventories |  |  | 6,177 |  |  |  | (28,319 | ) |
| Other assets |  |  | 2,663 |  |  |  | 572 |  |
| Accounts payable |  |  | (2,618 | ) |  |  | (12,226 | ) |
| Accrued wages and employee benefits |  |  | 4,981 |  |  |  | (1,167 | ) |
| Other accrued liabilities |  |  | 1,341 |  |  |  | (2,644 | ) |
| Excess tax benefits from equity awards |  |  | (6,754 | ) |  |  | (8,973 | ) |
| Net cash provided by operating activities |  |  | 129,513 |  |  |  | 76,859 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,349 |  |  |  | 105 |  |
| Expenditures for property and equipment |  |  | (20,847 | ) |  |  | (20,108 | ) |
| Acquisition of business, net of cash acquired |  |  | (61,386 | ) |  |  | (74,477 | ) |
| Net cash used in investing activities |  |  | (80,884 | ) |  |  | (94,480 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 14,117 |  |  |  | 14,320 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 100,000 |  |
| Repayments of short-term borrowings |  |  | (8,244 | ) |  |  | (15,198 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (10,976 | ) |  |  | (150,595 | ) |
| Stock repurchases |  |  | (99,934 | ) |  |  | (64,378 | ) |
| Payment of debt issuance costs |  |  | – |  |  |  | (2,067 | ) |
| Cash dividends paid |  |  | (76 | ) |  |  | (1,429 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,308 | ) |  |  | (12,380 | ) |
| Excess tax benefits from equity awards |  |  | 6,754 |  |  |  | 8,973 |  |
| Net cash used in financing activities |  |  | (110,667 | ) |  |  | (122,754 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 344 |  |  |  | (2,932 | ) |
| Net decrease in cash and cash equivalents |  |  | (61,694 | ) |  |  | (143,307 | ) |
| Cash and cash equivalents at beginning of period |  |  | 115,857 |  |  |  | 189,761 |  |
| Cash and cash equivalents at end of period |  | $ | 54,163 |  |  | $ | 46,454 |  |

[0001437749-16-040241:8k_2_02:75]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-16-040241:8k_2_02:76]
|  |  | Net Sales |  |
|  |  |  | Three Months Ended September 30, |  |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  |  | 2016 |  |  |  | 2015 |  |  |  | 2016 |  |  |  | 2015 |  |
| Domestic |  | $ | 299,095 |  |  | $ | 332,213 |  |  | $ | 833,831 |  |  | $ | 877,942 |  |
| International |  |  | 74,026 |  |  |  | 27,078 |  |  |  | 193,201 |  |  |  | 81,527 |  |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 192,856 |  |  | $ | 184,968 |  |  | $ | 533,572 |  |  | $ | 475,268 |  |
| Commercial & industrial products |  |  | 149,676 |  |  |  | 148,234 |  |  |  | 409,396 |  |  |  | 416,577 |  |
| Other |  |  | 30,589 |  |  |  | 26,089 |  |  |  | 84,064 |  |  |  | 67,624 |  |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |

[0001437749-16-040241:8k_2_02:77]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 69,309 |  |  | $ | 77,117 |  |  | $ | 173,521 |  |  | $ | 180,018 |  |
| International |  |  | 3,527 |  |  |  | 4,055 |  |  |  | 13,050 |  |  |  | 10,714 |  |
| Total adjusted EBITDA (1) |  | $ | 72,836 |  |  | $ | 81,172 |  |  | $ | 186,571 |  |  | $ | 190,732 |  |

[0001437749-16-040241:8k_2_02:78]
| (1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-16-040241:8k_2_02:79]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |

[0001437749-16-040241:8k_2_02:80]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Net loss attributable to noncontrolling interests (1) |  |  | (171 | ) |  |  | - |  |  |  | (112 | ) |  |  | - |  |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | 57,167 |  |  |  | 68,565 |  |
| Interest expense |  |  | 11,299 |  |  |  | 10,210 |  |  |  | 33,714 |  |  |  | 32,241 |  |
| Depreciation and amortization |  |  | 14,900 |  |  |  | 10,597 |  |  |  | 41,343 |  |  |  | 29,760 |  |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | 33,154 |  |  |  | 38,864 |  |
| Non-cash write-down and other adjustments (2) |  |  | (1,093 | ) |  |  | 2,115 |  |  |  | 1,689 |  |  |  | 4,091 |  |
| Non-cash share-based compensation expense (3) |  |  | 2,419 |  |  |  | 1,799 |  |  |  | 7,805 |  |  |  | 6,889 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | – |  |  |  | - |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate (5) |  |  | 2,957 |  |  |  | 2,381 |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and credit facility fees (6) |  |  | 739 |  |  |  | 317 |  |  |  | 1,499 |  |  |  | 999 |  |
| Business optimization expenses (7) |  |  | 58 |  |  |  | 5 |  |  |  | 7,164 |  |  |  | 1,743 |  |
| Other |  |  | 31 |  |  |  | 494 |  |  |  | 79 |  |  |  | 404 |  |
| Adjusted EBITDA |  |  | 72,836 |  |  |  | 81,172 |  |  |  | 186,571 |  |  |  | 190,732 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 708 |  |  |  | - |  |  |  | 3,015 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 72,128 |  |  | $ | 81,172 |  |  | $ | 183,556 |  |  | $ | 190,732 |  |

[0001437749-16-040241:8k_2_02:81]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.3 million and $6.9 million for the three and nine months ended September 30, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (5) For the three and nine months ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on current projections. For the three and nine months ended September 30, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 times effective third quarter 2015 and remaining above 3.0 times based on projections at the time. |
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (7) For the nine months ended September 30, 2016, represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. For the three and nine months ended September 30, 2015, represents severance and other non-recurring restructuring charges. |

[0001437749-16-040241:8k_2_02:82]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Net loss attributable to noncontrolling interests (1) |  |  | (171 | ) |  |  | - |  |  |  | (112 | ) |  |  | - |  |
| Net income |  |  | 26,012 |  |  |  | 34,036 |  |  |  | 57,167 |  |  |  | 68,565 |  |
| Provision for income taxes |  |  | 15,514 |  |  |  | 19,218 |  |  |  | 33,154 |  |  |  | 38,864 |  |
| Income before provision for income taxes |  |  | 41,526 |  |  |  | 53,254 |  |  |  | 90,321 |  |  |  | 107,429 |  |
| Amortization of intangible assets |  |  | 9,511 |  |  |  | 6,285 |  |  |  | 25,525 |  |  |  | 17,460 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,107 |  |  |  | 1,024 |  |  |  | 3,229 |  |  |  | 4,368 |  |
| Loss on extinguishment of debt (4) |  |  | - |  |  |  | – |  |  |  | - |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate (5) |  |  | 2,957 |  |  |  | 2,381 |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 469 |  |  |  | 979 |  |  |  | 5,159 |  |  |  | 1,482 |  |
| Business optimization expenses (7) |  |  | 58 |  |  |  | 5 |  |  |  | 7,164 |  |  |  | 1,743 |  |
| Adjusted net income before provision for income taxes |  |  | 55,628 |  |  |  | 63,928 |  |  |  | 134,355 |  |  |  | 139,658 |  |
| Cash income tax expense (9) |  |  | (2,325 | ) |  |  | (500 | ) |  |  | (5,595 | ) |  |  | (6,535 | ) |
| Adjusted net income |  |  | 53,303 |  |  |  | 63,428 |  |  |  | 128,760 |  |  |  | 133,123 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 58 |  |  |  | - |  |  |  | 1,939 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 53,245 |  |  | $ | 63,428 |  |  | $ | 126,821 |  |  | $ | 133,123 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.82 |  |  | $ | 0.92 |  |  | $ | 1.92 |  |  | $ | 1.91 |  |
| Weighted average common shares outstanding - diluted: |  |  | 65,126,117 |  |  |  | 69,182,465 |  |  |  | 65,992,127 |  |  |  | 69,781,300 |  |

[0001437749-16-040241:8k_2_02:83]
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (9) Amount for the three and nine months ended September 30, 2016 is based on an anticipated cash income tax rate at that time of approximately 6% for the full year ended 2016 . Amount for the three and nine months ended September 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year ended 2015. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |
| Free Cash Flow Reconciliation |  |  |  |  |

[0001437749-16-040241:8k_2_02:84]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 48,278 |  |  | $ | 35,280 |  |  | $ | 129,513 |  |  | $ | 76,859 |  |
| Expenditures for property and equipment |  |  | (6,843 | ) |  |  | (5,850 | ) |  |  | (20,847 | ) |  |  | (20,108 | ) |
| Free cash flow |  | $ | 41,435 |  |  | $ | 29,430 |  |  | $ | 108,666 |  |  | $ | 56,751 |  |
