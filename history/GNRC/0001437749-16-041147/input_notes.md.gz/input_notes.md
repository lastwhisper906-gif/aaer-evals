# GNRC notes — 0001437749-16-041147


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-16-041147:notes:1]
|  |  |  | September 30, |  |  | December 31, |  |
|  |  |  | 2016 |  |  | 2015 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
|  | Current portion - other accrued liabilities |  | $ | 21,159 |  |  | $ | 21,726 |  |
|  | Long-term portion - other long-term liabilities |  |  | 10,200 |  |  |  | 8,471 |  |
|  | Total |  | $ | 31,359 |  |  | $ | 30,197 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
|  | Current portion - other accrued liabilities |  | $ | 6,131 |  |  | $ | 6,026 |  |
|  | Long-term portion - other long-term liabilities |  |  | 24,364 |  |  |  | 22,935 |  |
|  | Total |  | $ | 30,495 |  |  | $ | 28,961 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-16-041147:notes:2]
|  |  | September 30, 2016 |  |  | December 31, 2015 |  |
| Commodity contracts |  | $ | 48 |  |  | $ | (400 | ) |
| Foreign currency contracts |  |  | 417 |  |  |  | (171 | ) |
| Interest rate swaps |  |  | (3,454 | ) |  |  | (2,618 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-16-041147:notes:3]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |
| Pro forma |  |  | 373,121 |  |  |  | 415,260 |  |  |  | 1,056,379 |  |  |  | 1,159,587 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Pro forma |  |  | 26,257 |  |  |  | 32,675 |  |  |  | 58,989 |  |  |  | 68,380 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.40 |  |  | $ | 0.49 |  |  | $ | 0.87 |  |  | $ | 0.98 |  |
| Pro forma |  |  | 0.40 |  |  |  | 0.47 |  |  |  | 0.89 |  |  |  | 0.98 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-16-041147:notes:4]
[same as prior period, unchanged from 0001437749-16-036603:notes:4]

[0001437749-16-041147:notes:5]
[same as prior period, unchanged from 0001437749-16-036603:notes:5]

[0001437749-16-041147:notes:6]
On March 1, 2016, the Company acquired a 65% ownership interest in Pramac for a purchase price, net of cash 
acquired, of $60,886. Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-16-041147:notes:7]
The 35% noncontrolling interest in
 Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest party has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell their interests to the Company any time within five years from the acquisition. The put option price is either (i) a fixed amount if voluntarily exercised within the first two years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it may redeem commencing five years from the acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with no partial transfers of interest permitted.

[0001437749-16-041147:notes:8]
The Company recorded a preliminary purchase price allocation during the
 first quarter of 2016, and was updated in the third quarter of 2016, based upon its estimates of the fair value of the acquired assets and assumed liabilities. The preliminary purchase price allocation as of September 30, 2016 was as follows:

[0001437749-16-041147:notes:9]
|  |  | March 1, 2016 |  |
| Accounts receivable |  | $ | 51,108 |  |
| Inventories |  |  | 40,070 |  |
| Property and equipment |  |  | 19,129 |  |
| Intangible assets |  |  | 34,471 |  |
| Goodwill |  |  | 47,682 |  |
| Other assets |  |  | 8,153 |  |
| Total assets acquired |  |  | 200,613 |  |
| Short-term borrowings |  |  | 21,105 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 25,447 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,886 |  |

[0001437749-16-041147:notes:10]
The goodwill ascribed to this acquisition is not deductible for tax purposes.
 The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through September 30, 2016.

[0001437749-16-041147:notes:11]
[same as prior period, unchanged from 0001437749-16-036603:notes:11]

[0001437749-16-041147:notes:12]
On August 1, 2015, 
a subsidiary of the Company acquired CHP for a purchase price, net of cash acquired, of $74,570. Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition was funded solely through cash on hand.

[0001437749-16-041147:notes:13]
The Company recorded a preliminary purchase price allocation during the 
third quarter of 2015 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $81,726 of intangible assets, including approximately $30,076 of goodwill, as of the acquisition date. The purchase price allocation was finalized in the fourth quarter of 2015, resulting in a $6,552 decrease to total intangible assets, including an increase of $6,208 in goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. In addition, the Company assumed $12,000 of CHP’s debt in conjunction with this acquisition. The accompanying condensed consolidated financial statements include the results of CHP from the date of acquisition through September 30, 2016.

[0001437749-16-041147:notes:14]
P

[0001437749-16-041147:notes:15]
ro

[0001437749-16-041147:notes:16]
Forma Information

[0001437749-16-041147:notes:17]
The following unaudited pro forma information of t
he Company gives effect to these acquisitions as though the transactions had occurred on January 1, 2015:

[0001437749-16-041147:notes:18]
Th
is unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on January 1, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-16-041147:notes:19]
[same as prior period, unchanged from 0001437749-16-036603:notes:17]

[0001437749-16-041147:notes:20]
[same as prior period, unchanged from 0001437749-16-036603:notes:18]

[0001437749-16-041147:notes:21]
[same as prior period, unchanged from 0001437749-16-036603:notes:19]

[0001437749-16-041147:notes:22]
Generac Holdings Inc. (the Company)
 is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-16-041147:notes:23]
T
he Company has executed a number of acquisitions that support our strategic plan (as discussed in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2015). A summary of these acquisitions include the following:

[0001437749-16-041147:notes:24]
|  | ● | In October 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-16-041147:notes:25]
|  | ● | In December 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-16-041147:notes:26]
|  | ● | In August 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-16-041147:notes:27]
|  | ● | In November 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

[0001437749-16-041147:notes:28]
|  | ● | In September 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

[0001437749-16-041147:notes:29]
|  | ● | In October 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-16-041147:notes:30]
|  | ● | In August 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

[0001437749-16-041147:notes:31]
|  | ● | In March 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-16-041147:notes:32]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries
 that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-16-041147:notes:33]
The condensed conso
lidated balance sheet as of September 30, 2016, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2016 and 2015, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-16-041147:notes:34]
The preparation of the 
condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-16-041147:notes:35]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001437749-16-041147:notes:36]
[same as prior period, unchanged from 0001437749-16-036603:notes:27]

[0001437749-16-041147:notes:37]
In May 2014, the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. ASU 2014-09, as amended by ASU 2015-14, 
Revenue from Contracts with Customers (Topic

[0001437749-16-041147:notes:38]
[same as prior period, unchanged from 0001437749-16-036603:notes:29]

[0001437749-16-041147:notes:39]
eferral of the Effective Date
, ASU 2016-08, 
Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations
, ASU 2016-10, 
Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing

[0001437749-16-041147:notes:40]
,
 and ASU 2016-12, 
Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients
, becomes effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-16-041147:notes:41]
In February 2016, the FASB issued ASU 2016-02,

[0001437749-16-041147:notes:42]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 2019, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-16-041147:notes:43]
In March 2016, the FASB issued ASU 2016-09,

[0001437749-16-041147:notes:44]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classification on the statements of cash flow.

[0001437749-16-041147:notes:45]
In August 2016, the FASB issued ASU 2016-15,

[0001437749-16-041147:notes:46]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 2018, with early adoption permitted. The Company does not believe that this guidance will have a significant impact on the presentation of the statement of cash flows.

[0001437749-16-041147:notes:47]
In the first quarter of 2016, the Company adopted ASU 2015-03,

[0001437749-16-041147:notes:48]
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965. Also in the first quarter of 2016, the Company adopted ASU 2015-17, 
Income Taxes: Balance Sheet Classification of Deferred Taxes
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.

[0001437749-16-041147:notes:49]
There are several other new accounting pronouncements issued by the FASB. 
Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-16-041147:notes:50]
1

[0001437749-16-041147:notes:51]
3

[0001437749-16-041147:notes:52]
. Commitments and Contingencies

[0001437749-16-041147:notes:53]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount 
financed by dealers which remained outstanding under this arrangement at September 30, 2016 and December 31, 2015 was approximately $30,500 and $32,400, respectively.

[0001437749-16-041147:notes:54]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-041147:notes:55]
[same as prior period, unchanged from 0001437749-16-036603:notes:41]

[0001437749-16-041147:notes:56]
[same as prior period, unchanged from 0001437749-16-036603:notes:42]

[0001437749-16-041147:notes:57]
The following presents a tabular disclosure of changes in 
AOCL during the three and nine months ended September 30, 2016 and 2015, net of tax:

[0001437749-16-041147:notes:58]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2016 |  | $ | (20,234 | ) |  | $ | (11,362 | ) |  | $ | (2,899 | ) |  | $ | (34,495 | ) |
| Other comprehensive gain (loss) before reclassifications |  |  | (315 | ) |  |  | - |  |  |  | 779 |  | (1) |  | 464 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (315 | ) |  |  | - |  |  |  | 779 |  |  |  | 464 |  |
| Ending Balance – September 30, 2016 |  | $ | (20,549 | ) |  | $ | (11,362 | ) |  | $ | (2,120 | ) |  | $ | (34,031 | ) |

[0001437749-16-041147:notes:59]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,072 | ) |  |  | - |  |  |  | (1,065 | ) | (2) |  | (2,137 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (1,072 | ) |  |  | - |  |  |  | (1,065 | ) |  |  | (2,137 | ) |
| Ending Balance – September 30, 2015 |  | $ | (8,433 | ) |  | $ | (13,243 | ) |  | $ | (2,717 | ) |  | $ | (24,393 | ) |

[0001437749-16-041147:notes:60]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive loss before reclassifications |  |  | (11,047 | ) |  |  | - |  |  |  | (509 | ) | (3) |  | (11,556 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (11,047 | ) |  |  | - |  |  |  | (509 | ) |  |  | (11,556 | ) |
| Ending Balance – September 30, 2016 |  | $ | (20,549 | ) |  | $ | (11,362 | ) |  | $ | (2,120 | ) |  | $ | (34,031 | ) |

[0001437749-16-041147:notes:61]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (6,555 | ) |  |  | - |  |  |  | (2,071 | ) | (4) |  | (8,626 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (6,555 | ) |  |  | - |  |  |  | (2,071 | ) |  |  | (8,626 | ) |
| Ending Balance – September 30, 2015 |  | $ | (8,433 | ) |  | $ | (13,243 | ) |  | $ | (2,717 | ) |  | $ | (24,393 | ) |

[0001437749-16-041147:notes:62]
|  | (1) | Represents unrealized gains of $1,279, net of tax effect of $(500) for the three months ended September 30, 2016. |

[0001437749-16-041147:notes:63]
|  | (2) | Represents unrealized losses of $(1,727), net of tax benefit of $662 for the three months ended September 30, 2015. |

[0001437749-16-041147:notes:64]
|  | (3) | Represents unrealized losses of $(836), net of tax benefit of $327 for the nine months ended September 30, 2016. |

[0001437749-16-041147:notes:65]
|  | (4) | Represents unrealized losses of $(3,370), net of tax benefit of $1,299 for the nine months ended September 30, 2015. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-041147:notes:66]
9

[0001437749-16-041147:notes:67]
. Credit Agreements

[0001437749-16-041147:notes:68]
Short-term borrowings are included in the 
condensed consolidated balance sheets as follows:

[0001437749-16-041147:notes:69]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 35,517 |  |  |  | 8,594 |  |
| Total |  | $ | 35,517 |  |  | $ | 8,594 |  |

[0001437749-16-041147:notes:70]
Long-term borrowings are included in the 
condensed consolidated balance sheets as follows:

[0001437749-16-041147:notes:71]
|  |  |  | September 30, |  |  | December 31, |  |
|  |  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,719 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 5,431 |  |  |  | 1,694 |  |
| Other |  |  | 16,671 |  |  |  | 12,000 |  |
| Total |  |  | 1,052,383 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 38,122 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 590 |  |  |  | 157 |  |
| Total |  | $ | 1,013,671 |  |  | $ | 1,037,132 |  |

[0001437749-16-041147:notes:72]
The
 Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. 
On November 2, 2016, the Term Loan maturity date was extended to May 31, 2023. (See Note 14, “Subsequent Events” to the condensed consolidated financial statements.) 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

[0001437749-16-041147:notes:73]
The Term Loan
 initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of September 30, 2016 was above 3.00 to 1.00.

[0001437749-16-041147:notes:74]
Because the Company
’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a cumulative catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 3.00 to 1.00 using current forecasts at that time.

[0001437749-16-041147:notes:75]
As the Company
’s net debt leverage ratio continued to be above 3.00 to 1.00 on July 1, 2016, the Company recorded a cumulative catch-up loss of $2,957 in the third quarter of 2016, which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 3.00 to 1.00 using current forecasts at that time.

[0001437749-16-041147:notes:76]
On May 18, 2015, the Company amended 
certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of September 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-16-041147:notes:77]
The Company
’s credit agreements also originally provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-16-041147:notes:78]
On May 29, 2015, the Company amended 
its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxed certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $490 of new debt issuance costs in 2015.

[0001437749-16-041147:notes:79]
On
 May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of September 30, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $144,924 of availability, net of outstanding letters of credit.

[0001437749-16-041147:notes:80]
On March 30 and May 29, 2015
, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-16-041147:notes:81]
As 
of September 30, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $35,517 and $8,594, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-16-041147:notes:82]
[same as prior period, unchanged from 0001437749-16-036603:notes:63]

[0001437749-16-041147:notes:83]
The Company records all derivatives in accordance with 
Accounting Standards Codification (ASC) 815, 
Derivatives and Hedging
, which requires derivative instruments be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-16-041147:notes:84]
[same as prior period, unchanged from 0001437749-16-036603:notes:65]

[0001437749-16-041147:notes:85]
The Company 
is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than eighteen months. At September 30, 2016, December 31, 2015 and September 30, 2015, the Company had one, one and three commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-16-041147:notes:86]
Because these contracts do not qualify for hedge 
accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net gains (losses) recognized for the three and nine months ended September 30, 2016 were $(10) and $66, respectively. Net gains (losses) recognized for the three and nine months ended September 30, 2015 were $(667) and $(1,708), respectively.

[0001437749-16-041147:notes:87]
[same as prior period, unchanged from 0001437749-16-036603:notes:68]

[0001437749-16-041147:notes:88]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies
 other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less. As of September 30, 2016, December 31, 2015 and September 30, 2015, the Company had fifteen, six and three foreign currency contracts outstanding, respectively.

[0001437749-16-041147:notes:89]
Because these contracts do not qualify for hedge accounting,
 the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net gains (losses) recognized for the three and nine months ended September 30, 2016 were $24 and $(154), respectively. Net gains (losses) recognized for the three and nine months ended September 30, 2015 were $(107) and $(465), respectively.

[0001437749-16-041147:notes:90]
[same as prior period, unchanged from 0001437749-16-036603:notes:71]

[0001437749-16-041147:notes:91]
In 
October 2013, the Company entered into two interest rate swap agreements, and in May 2014, the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-16-041147:notes:92]
[same as prior period, unchanged from 0001437749-16-036603:notes:73]

[0001437749-16-041147:notes:93]
The following table presents the fair value of 
all of the Company’s derivatives:

[0001437749-16-041147:notes:94]
The fair 
value of the commodity and foreign currency contracts are included in other assets, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of September 30, 2016
. The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of December 31, 2015.
 Excluding the impact of credit risk, the fair value of the derivative contracts as of September 30, 2016 and December 31, 2015 is a liability of $3,067 and $3,248, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-16-041147:notes:95]
The 
amount of gains (losses) recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three and nine months ended September 30, 2016 were $779 and $(509), respectively. The amount of gains (losses) for the three and nine months ended September 30, 2015 were $(1,065) and $(2,071), respectively.

[0001437749-16-041147:notes:96]
The amount of
 gains (losses) recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three and nine months ended September 30, 2016 were $14 and $(88), respectively. The amount of gains (losses) for the three and nine months ended September 30, 2015 were $(774) and $(2,173), respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-041147:notes:97]
[same as prior period, unchanged from 0001437749-16-036603:notes:78]

[0001437749-16-041147:notes:98]
[same as prior period, unchanged from 0001437749-16-036603:notes:79]

[0001437749-16-041147:notes:99]
Basic earnings per
 share is calculated by dividing net income attributable to the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-16-041147:notes:100]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income attributable to Generac Holdings Inc. (numerator) |  | $ | 26,183 |  |  | $ | 34,036 |  |  | $ | 57,279 |  |  | $ | 68,565 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 64,615,935 |  |  |  | 68,175,466 |  |  |  | 65,506,469 |  |  |  | 68,642,479 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 510,182 |  |  |  | 1,006,999 |  |  |  | 485,658 |  |  |  | 1,138,821 |  |
| Diluted |  |  | 65,126,117 |  |  |  | 69,182,465 |  |  |  | 65,992,127 |  |  |  | 69,781,300 |  |
| Net income attributable to Generac Holdings Inc. per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.41 |  |  | $ | 0.50 |  |  | $ | 0.87 |  |  | $ | 1.00 |  |
| Diluted |  | $ | 0.40 |  |  | $ | 0.49 |  |  | $ | 0.87 |  |  | $ | 0.98 |  |

[0001437749-16-041147:notes:101]
(1) Excludes 
approximately 208,400 stock options for the three month period ended September 30, 2016 and 172,900 stock options for the nine month period ended September 30, 2016, as the impact of such awards was anti-dilutive. Excludes approximately 250,900 stock options and 11,000 shares of restricted stock for the three month period ended September 30, 2015 and 138,900 stock options and 800 shares of restricted stock for the nine month period ended September 30, 2015, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-041147:notes:102]
[same as prior period, unchanged from 0001437749-16-036603:notes:83]

[0001437749-16-041147:notes:103]
[same as prior period, unchanged from 0001437749-16-036603:notes:84]

[0001437749-16-041147:notes:104]
ASC 820-10,

[0001437749-16-041147:notes:105]
Fair Value Measurement
, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-16-041147:notes:106]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts 
receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $930,409, was approximately $933,875 (Level 2) at September 30, 2016, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-16-041147:notes:107]
For the fair value of the assets and liabilities measured on a recurring basis, se
e the fair value table in Note 3, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-041147:notes:108]
[same as prior period, unchanged from 0001437749-16-036603:notes:88]

[0001437749-16-041147:notes:109]
[same as prior period, unchanged from 0001437749-16-036603:notes:89]

[0001437749-16-041147:notes:110]
The effective income tax rates for the
 nine months ended September 30, 2016 and 2015 were 36.7% and 36.2%, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-16-041147:notes:111]
[same as prior period, unchanged from 0001437749-16-036603:notes:91]

[0001437749-16-041147:notes:112]
[same as prior period, unchanged from 0001437749-16-036603:notes:92]

[0001437749-16-041147:notes:113]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable.
 Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts.

[0001437749-16-041147:notes:114]
The following is a tabular reconciliation of the product warranty liability, 
excluding the deferred revenue related to extended warranty coverage:

[0001437749-16-041147:notes:115]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 30,735 |  |  | $ | 28,185 |  |  | $ | 30,197 |  |  | $ | 30,909 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 351 |  |  |  | 840 |  |  |  | 351 |  |
| Payments |  |  | (5,424 | ) |  |  | (5,812 | ) |  |  | (13,976 | ) |  |  | (16,345 | ) |
| Provision for warranties issued |  |  | 5,762 |  |  |  | 6,033 |  |  |  | 13,464 |  |  |  | 15,062 |  |
| Changes in estimates for pre-existing warranties |  |  | 286 |  |  |  | 105 |  |  |  | 834 |  |  |  | (1,115 | ) |
| Balance at end of period |  | $ | 31,359 |  |  | $ | 28,862 |  |  | $ | 31,359 |  |  | $ | 28,862 |  |

[0001437749-16-041147:notes:116]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage
:

[0001437749-16-041147:notes:117]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 29,082 |  |  | $ | 27,241 |  |  | $ | 28,961 |  |  | $ | 27,193 |  |
| Deferred revenue on extended warranty contracts assumed in acquisition |  |  | - |  |  |  | 291 |  |  |  | - |  |  |  | 291 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 2,843 |  |  |  | 1,694 |  |  |  | 5,606 |  |  |  | 3,884 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,430 | ) |  |  | (1,138 | ) |  |  | (4,072 | ) |  |  | (3,280 | ) |
| Balance at end of period |  | $ | 30,495 |  |  | $ | 28,088 |  |  | $ | 30,495 |  |  | $ | 28,088 |  |

[0001437749-16-041147:notes:118]
Product warranty obligations 
and extended warranty related deferred revenues are included in the condensed consolidated balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-16-041147:notes:119]
|  |  | September 30, 2016 |  |  | December 31, 2015 |  |
| Land and improvements |  | $ | 12,124 |  |  | $ | 8,553 |  |
| Buildings and improvements |  |  | 117,795 |  |  |  | 104,774 |  |
| Machinery and equipment |  |  | 79,875 |  |  |  | 72,280 |  |
| Dies and tools |  |  | 22,813 |  |  |  | 20,066 |  |
| Vehicles |  |  | 1,535 |  |  |  | 1,244 |  |
| Office equipment and systems |  |  | 59,866 |  |  |  | 29,395 |  |
| Leasehold improvements |  |  | 4,256 |  |  |  | 3,338 |  |
| Construction in progress |  |  | 10,550 |  |  |  | 30,482 |  |
| Gross property and equipment |  |  | 308,814 |  |  |  | 270,132 |  |
| Accumulated depreciation |  |  | (101,310 | ) |  |  | (85,919 | ) |
| Total |  | $ | 207,504 |  |  | $ | 184,213 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-16-041147:notes:120]
|  |  |  | Net Sales |  |
|  |  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Product Classes |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Residential products |  | $ | 192,856 |  |  | $ | 184,968 |  |  | $ | 533,572 |  |  | $ | 475,268 |  |
| Commercial & industrial products |  |  | 149,676 |  |  |  | 148,234 |  |  |  | 409,396 |  |  |  | 416,577 |  |
| Other |  |  | 30,589 |  |  |  | 26,089 |  |  |  | 84,064 |  |  |  | 67,624 |  |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-16-041147:notes:121]
|  |  | September 30, 2016 |  |  | December 31, 2015 |  |
| Raw material |  | $ | 218,787 |  |  | $ | 179,769 |  |
| Work-in-process |  |  | 3,014 |  |  |  | 2,567 |  |
| Finished goods |  |  | 137,562 |  |  |  | 143,039 |  |
| Total |  | $ | 359,363 |  |  | $ | 325,375 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-041147:notes:122]
|  |  |  | Net Sales |  |
|  |  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 299,095 |  |  | $ | 332,213 |  |  | $ | 833,831 |  |  | $ | 877,942 |  |
| International |  |  | 74,026 |  |  |  | 27,078 |  |  |  | 193,201 |  |  |  | 81,527 |  |
| Total net sales |  | $ | 373,121 |  |  | $ | 359,291 |  |  | $ | 1,027,032 |  |  | $ | 959,469 |  |

[0001437749-16-041147:notes:123]
|  |  |  | Adjusted EBITDA |  |
|  |  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 69,309 |  |  | $ | 77,117 |  |  | $ | 173,521 |  |  | $ | 180,018 |  |
| International |  |  | 3,527 |  |  |  | 4,055 |  |  |  | 13,050 |  |  |  | 10,714 |  |
| Total adjusted EBITDA |  | $ | 72,836 |  |  | $ | 81,172 |  |  | $ | 186,571 |  |  | $ | 190,732 |  |
|  | Interest expense |  |  | (11,299 | ) |  |  | (10,210 | ) |  |  | (33,714 | ) |  |  | (32,241 | ) |
|  | Depreciation and amortization |  |  | (14,900 | ) |  |  | (10,597 | ) |  |  | (41,343 | ) |  |  | (29,760 | ) |
|  | Non-cash write-down and other adjustments (1) |  |  | 1,093 |  |  |  | (2,115 | ) |  |  | (1,689 | ) |  |  | (4,091 | ) |
|  | Non-cash share-based compensation expense (2) |  |  | (2,419 | ) |  |  | (1,799 | ) |  |  | (7,805 | ) |  |  | (6,889 | ) |
|  | Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (4,795 | ) |
|  | Loss on change in contractual interest rate (4) |  |  | (2,957 | ) |  |  | (2,381 | ) |  |  | (2,957 | ) |  |  | (2,381 | ) |
|  | Transaction costs and credit facility fees (5) |  |  | (739 | ) |  |  | (317 | ) |  |  | (1,499 | ) |  |  | (999 | ) |
|  | Business optimization expenses (6) |  |  | (58 | ) |  |  | (5 | ) |  |  | (7,164 | ) |  |  | (1,743 | ) |
|  | Other |  |  | (31 | ) |  |  | (494 | ) |  |  | (79 | ) |  |  | (404 | ) |
| Income before provision for income taxes |  | $ | 41,526 |  |  | $ | 53,254 |  |  | $ | 90,321 |  |  | $ | 107,429 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-041147:notes:124]
6

[0001437749-16-041147:notes:125]
. Segment Reporting

[0001437749-16-041147:notes:126]
Effective i
n the second quarter of 2016, the Company changed its segment reporting from one reportable segment to two reportable segments - Domestic and International - as a result of the recent Pramac acquisition and the ongoing strategy to expand the business internationally. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light and Pramac acquisitions, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of engine powered products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-16-041147:notes:127]
The Company's product offerings consist primarily of power 
generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial products are each a class of products based on similar power output and end customer usage. The breakout of net sales between residential, commercial & industrial, and other products by product class is as follows:

[0001437749-16-041147:notes:128]
Management 
evaluates the performance of its segments based primarily on Adjusted EBITDA, and therefore is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-16-041147:notes:129]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments. |

[0001437749-16-041147:notes:130]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-16-041147:notes:131]
|  | (3) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |

[0001437749-16-041147:notes:132]
|  | (4) | For the three and nine months ended September 30, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on current projections. For the three and nine months ended September 30, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 effective third quarter 2015 and remaining above 3.0 times based on projections at the time. |

[0001437749-16-041147:notes:133]
|  | (5) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-16-041147:notes:134]
|  | (6) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-16-041147:notes:135]
T
he Company’s sales in the United States represented approximately 77% and 88% of total sales for the three months ended September 30, 2016 and 2015, respectively, and represented approximately 78% and 86% of total sales for the nine months ended September 30, 2016 and 2015, respectively. Approximately 86% and 93% of the Company’s identifiable long-lived assets are located in the United States at September 30, 2016 and December 31, 2015, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-041147:notes:136]
. Subsequent Events

[0001437749-16-041147:notes:137]
On October 24
, 2016, the Company’s Board of Directors approved a $250,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase an additional $250,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-16-041147:notes:138]
On November 2, 2016, the Company 
made a $25,000 voluntary prepayment of the Term Loan. Additionally on November 2, 2016, the Company amended its Term Loan to extend the maturity date from May 31, 2020 to May 31, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-16-041147:notes:139]
[same as prior period, unchanged from 0001437749-16-036603:notes:110]

[0001437749-16-041147:notes:140]
[same as prior period, unchanged from 0001437749-16-036603:notes:111]

[0001437749-16-041147:notes:141]
[same as prior period, unchanged from 0001437749-16-036603:notes:112]

[0001437749-16-041147:notes:142]
[same as prior period, unchanged from 0001437749-16-036603:notes:113]


## us-gaap:TreasuryStockTextBlock

[0001437749-16-041147:notes:143]
[same as prior period, unchanged from 0001437749-16-036603:notes:114]

[0001437749-16-041147:notes:144]
I
n August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the program, the Company may repurchase up to $200,000 of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. For the three months ended September 30, 2016, the Company repurchased 1,798,206 shares of its common stock for $65,358. Since the inception of the program, the Company has repurchased 6,036,706 shares of its common stock for $199,876, all funded with cash on hand. The repurchases in the third quarter of 2016 completed the total authorized amount under the program. 
See Note 14, “Subsequent Events” to the condensed consolidated financial statements for further discussion of our stock repurchase programs.
