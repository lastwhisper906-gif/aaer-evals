# GNRC 8-K — 0001437749-20-002505 filed 2020-02-13

## item codes, every 8-K on or before 2020-02-25

- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2020-02-25

- none on or before 2020-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001437749-20-002505:8k_2_02:1]
EX-99.1
2
ex_172356.htm
EXHIBIT 99.1

[0001437749-20-002505:8k_2_02:2]
ex_172356.htm

[0001437749-20-002505:8k_2_02:3]
Exhibit 99.1

[0001437749-20-002505:8k_2_02:4]
Generac Reports Record Quarterly and Full-Year 2019 Results

[0001437749-20-002505:8k_2_02:5]
Fourth quarter results exceed expectations led by strong home standby demand; 2020 outlook anticipates continued strong revenue growth highlighted by expanding Clean Energy and California markets

[0001437749-20-002505:8k_2_02:6]
WAUKESHA, WISCONSIN (February 13, 2020) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2019.

[0001437749-20-002505:8k_2_02:7]
Fourth Quarter 2019 Highlights

[0001437749-20-002505:8k_2_02:8]
| ● | Net sales increased 4.9% to $590.9 million during the fourth quarter of 2019 as compared to $563.4 million in the prior-year fourth quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was approximately 4%. |

[0001437749-20-002505:8k_2_02:9]
|  | - | Residential product sales increased 9.7% to $322.5 million as compared to $293.9 million last year, with core sales growth of approximately 7%. |

[0001437749-20-002505:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased 2.7% to $217.1 million as compared to $223.2 million in the prior year, with core sales also declining approximately 3%. |

[0001437749-20-002505:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter was $69.6 million, or $1.12 per share, as compared to $75.6 million, or $1.20 per share, for the same period of 2018. See accompanying reconciliation schedules for related earnings per share calculations. |

[0001437749-20-002505:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $96.5 million, or $1.53 per share, as compared to $88.1 million, or $1.42 per share, in the fourth quarter of 2018. |

[0001437749-20-002505:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $129.1 million, or 21.9% of net sales, as compared to $126.1 million, or 22.4% of net sales, in the prior year. |

[0001437749-20-002505:8k_2_02:14]
| ● | Cash flow from operations was $175.1 million as compared to $108.2 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $160.3 million as compared to $87.3 million in 2018. The increase was primarily driven by the monetization of previous working capital investments, together with lower capital expenditures compared to the prior year quarter. |

[0001437749-20-002505:8k_2_02:15]
| ● | As previously announced, on December 13, 2019, the Company amended its Term Loan credit agreement, which among other things extended the maturity of the term loan from May 2023 to December 2026. In conjunction with the amendment, the Company paid down $49 million of debt on the term loan. |

[0001437749-20-002505:8k_2_02:16]
Full-Year 2019 Highlights

[0001437749-20-002505:8k_2_02:17]
| ● | Net sales increased 8.9% to $2.20 billion during 2019 as compared to $2.02 billion in 2018, including $41.2 million of contribution from acquisitions. Total core sales growth for the year was approximately 8%. |

[0001437749-20-002505:8k_2_02:18]
|  | - | Residential product sales increased 9.7% to $1.14 billion as compared to $1.04 billion last year, with core sales growth of approximately 9%. |

[0001437749-20-002505:8k_2_02:19]
|  | - | C&I product sales increased 6.3% to $871.6 million as compared to $820.3 million in the prior year, with core sales also increasing approximately 6%. |

[0001437749-20-002505:8k_2_02:20]
| ● | Net income attributable to the Company during 2019 was $252.0 million, or $4.03 per share, as compared to $238.3 million, or $3.54 per share for 2018. |

[0001437749-20-002505:8k_2_02:21]
| ● | Adjusted net income attributable to the Company was $317.8 million, or $5.06 per share, as compared to $292.2 million, or $4.70 per share, in 2018. |

[0001437749-20-002505:8k_2_02:22]
| ● | Adjusted EBITDA before deducting for non-controlling interests for 2019 was $454.1 million, or 20.6% of net sales, as compared to $424.6 million, or 21.0% of net sales, last year. |

[0001437749-20-002505:8k_2_02:23]
| ● | Cash flow from operations was $308.9 million as compared to $247.2 million in the prior year. Free cash flow was $250.7 million as compared to $203.6 million in 2018. |

[0001437749-20-002505:8k_2_02:24]
“The fourth quarter was a great finish to a very strong 2019 with record performance for both the quarter and the full-year for net sales, adjusted EBITDA and free cash flow,” said Aaron Jagdfeld, President and Chief Executive Officer. “Home standby demand was again robust during the quarter driven by California as public utility shut-offs drove a dramatic increase in interest for these products. We also made the first shipments of our new PWRcellTM energy storage system during the quarter, and the outlook for our clean energy products continues to exceed our expectations. Our full-year results for residential products were also exceptionally strong and broad-based, and we experienced similar trends with domestic C&I product shipments through our industrial distributors as the penetration of natural gas generators continues to accelerate. Additionally, shipments to our telecom national account customers for the full year increased significantly as they continue to expand and harden their networks in preparation for the impending rollout of 5G technology. We believe our 2019 performance is further evidence of the tremendous growth opportunities for Generac, and as we enter 2020 we are incredibly excited about the long-term prospects for our business.”

[0001437749-20-002505:8k_2_02:25]
Additional Fourth Quarter 2019 Consolidated Highlights

[0001437749-20-002505:8k_2_02:26]
Gross profit margin improved 130 basis points to 37.6% compared to 36.3% in the prior-year fourth quarter. Pricing actions and favorable sales mix, as well as lower realized commodity and foreign currency input costs, were partially offset by increased regulatory tariffs, and the unfavorable mix impact from acquisitions.

[0001437749-20-002505:8k_2_02:27]
Operating expenses increased $22.3 million, or 23.3%, as compared to the fourth quarter of 2018. The increase was primarily driven by higher employee costs, recurring operating expenses from recent acquisitions, additional intangible amortization and depreciation expense, as well as greater marketing and promotional spend as we continue to invest in a number of initiatives to capitalize on future growth opportunities.

[0001437749-20-002505:8k_2_02:28]
Provision for income taxes for the current year quarter was $13.4 million, or an effective tax rate of 16.1%, as compared to $20.0 million, or a 20.7% effective tax rate, for the prior year. The current year quarter was favorably impacted by a year-end revaluation adjustment related to a reduction in the state income tax rate. For the full year, the effective tax rate for 2019 was 21.1% compared to 22.5% in the prior year.

[0001437749-20-002505:8k_2_02:29]
During the fourth quarter of 2019, the Company completed the termination of its domestic pension plan, which did not result in a reduction of benefits to plan participants. This resulted in pre-tax settlement charges of $10.9 million during the quarter, or $0.17 per share.

[0001437749-20-002505:8k_2_02:30]
Business Segment Results

[0001437749-20-002505:8k_2_02:31]
Domestic Segment

[0001437749-20-002505:8k_2_02:32]
Domestic segment sales increased 7.7% to $470.1 million as compared to $436.3 million in the prior year quarter. Core sales growth, which excludes the impact of the Neurio and Pika acquisitions, was approximately 6%. The current year quarter experienced strong growth in shipments of home standby generators due to increased outage activity across the U.S. and Canada, which included public safety power shut-offs in California. In addition, C&I stationary generator shipments were also strong during the quarter and broad-based through the Company’s North American distributor channel. The overall Domestic segment growth was partially offset by lower shipments of C&I products to national telecom and rental account customers.

[0001437749-20-002505:8k_2_02:33]
Adjusted EBITDA for the segment was $122.9 million, or 26.1% of net sales, as compared to $116.3 million in the prior year, or 26.7% of net sales. Pricing initiatives, favorable sales mix, and improved commodity and currency input costs were more than offset by the aforementioned regulatory tariffs and higher operating expense investments.

[0001437749-20-002505:8k_2_02:34]
International Segment

[0001437749-20-002505:8k_2_02:35]
International segment sales decreased 4.9% to $120.9 million as compared to $127.1 million in the prior year quarter. Core sales, which excludes the unfavorable impact of currency and the impact of the Captiva acquisition, declined approximately 4% compared to the prior year as slower economic growth and geopolitical headwinds caused softness in certain key regions of the world in which we operate.

[0001437749-20-002505:8k_2_02:36]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $6.2 million, or 5.2% of net sales, as compared to $9.7 million, or 7.7% of net sales, in the prior year. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline.

[0001437749-20-002505:8k_2_02:37]
2020 Outlook

[0001437749-20-002505:8k_2_02:38]
The Company is initiating guidance for 2020 with net sales expected to increase between 6 to 8% as compared to the prior year on an as-reported basis, and 5 to 7% on a core basis. This baseline guidance does not assume the benefit of a major power outage event. However, should there be a major event along with additional public safety power shut-offs in California, we could expect approximately 3 to 5% of incremental revenue growth on top of the baseline guidance, resulting in an upside case as-reported sales growth of 9 to 13%.

[0001437749-20-002505:8k_2_02:39]
Net income margin, before deducting for non-controlling interests, is expected to be approximately 11% for the full-year 2020, with corresponding adjusted EBITDA margin expected to be approximately 20.0%. Should there be a more active outage environment during 2020, we would expect margins to increase by approximately 50 basis points above this baseline guidance, resulting in an upside case adjusted EBITDA margin of approximately 20.5%.

[0001437749-20-002505:8k_2_02:40]
Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income to free cash flow expected to be approximately 90%.

[0001437749-20-002505:8k_2_02:41]
Conference Call and Webcast

[0001437749-20-002505:8k_2_02:42]
Generac management will hold a conference call at 9:00 a.m. EST on Thursday, February 13, 2020 to discuss fourth quarter and full year 2019 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 9159339.

[0001437749-20-002505:8k_2_02:43]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-20-002505:8k_2_02:44]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 9159339. The telephonic replay will be available for 7 days.

[0001437749-20-002505:8k_2_02:45]
About Generac

[0001437749-20-002505:8k_2_02:46]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-20-002505:8k_2_02:47]
Forward-looking Information

[0001437749-20-002505:8k_2_02:48]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-20-002505:8k_2_02:49]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-20-002505:8k_2_02:50]
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |
|  | ● | the risk that our acquisitions will not be integrated successfully; |
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |
|  | ● | our dependence on our distribution network; |
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |
|  | ● | loss of our key management and employees; |
|  | ● | increase in product and other liability claims or recalls; |
|  | ● | failures or security breaches of our networks or information technology systems; and |
|  | ● | Changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-20-002505:8k_2_02:51]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2018 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-20-002505:8k_2_02:52]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-20-002505:8k_2_02:53]
Non-GAAP Financial Metrics

[0001437749-20-002505:8k_2_02:54]
Core Sales

[0001437749-20-002505:8k_2_02:55]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-20-002505:8k_2_02:56]
Adjusted EBITDA

[0001437749-20-002505:8k_2_02:57]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-20-002505:8k_2_02:58]
Adjusted Net Income

[0001437749-20-002505:8k_2_02:59]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-20-002505:8k_2_02:60]
Free Cash Flow

[0001437749-20-002505:8k_2_02:61]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-20-002505:8k_2_02:62]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-20-002505:8k_2_02:63]
SOURCE: Generac Holdings Inc.

[0001437749-20-002505:8k_2_02:64]
CONTACT:

[0001437749-20-002505:8k_2_02:65]
Michael W. Harris

[0001437749-20-002505:8k_2_02:66]
Vice President – Corporate Development & Investor Relations

[0001437749-20-002505:8k_2_02:67]
(262) 506-6064

[0001437749-20-002505:8k_2_02:68]
InvestorRelations@generac.com

[0001437749-20-002505:8k_2_02:69]
Generac Holdings Inc.

[0001437749-20-002505:8k_2_02:70]
Consolidated Statements of Comprehensive Income

[0001437749-20-002505:8k_2_02:71]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-20-002505:8k_2_02:72]
(Unaudited)

[0001437749-20-002505:8k_2_02:73]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net sales |  | $ | 590,932 |  |  | $ | 563,404 |  |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |
| Costs of goods sold |  |  | 368,710 |  |  |  | 359,098 |  |  |  | 1,406,584 |  |  |  | 1,298,424 |  |
| Gross profit |  |  | 222,222 |  |  |  | 204,306 |  |  |  | 797,752 |  |  |  | 725,040 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 58,729 |  |  |  | 50,013 |  |  |  | 217,683 |  |  |  | 191,887 |  |
| Research and development |  |  | 19,488 |  |  |  | 11,897 |  |  |  | 68,394 |  |  |  | 50,019 |  |
| General and administrative |  |  | 30,852 |  |  |  | 28,228 |  |  |  | 110,868 |  |  |  | 103,841 |  |
| Amortization of intangibles |  |  | 8,645 |  |  |  | 5,320 |  |  |  | 28,644 |  |  |  | 22,112 |  |
| Total operating expenses |  |  | 117,714 |  |  |  | 95,458 |  |  |  | 425,589 |  |  |  | 367,859 |  |
| Income from operations |  |  | 104,508 |  |  |  | 108,848 |  |  |  | 372,163 |  |  |  | 357,181 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,116 | ) |  |  | (10,017 | ) |  |  | (41,544 | ) |  |  | (40,956 | ) |
| Investment income |  |  | 878 |  |  |  | 798 |  |  |  | 2,767 |  |  |  | 1,893 |  |
| Loss on extinguishment of debt |  |  | (926 | ) |  |  | – |  |  |  | (926 | ) |  |  | (1,332 | ) |
| Loss on pension settlement |  |  | (10,920 | ) |  |  | – |  |  |  | (10,920 | ) |  |  | – |  |
| Other, net |  |  | (65 | ) |  |  | (2,946 | ) |  |  | (1,933 | ) |  |  | (5,710 | ) |
| Total other expense, net |  |  | (21,149 | ) |  |  | (12,165 | ) |  |  | (52,556 | ) |  |  | (46,105 | ) |
| Income before provision for income taxes |  |  | 83,359 |  |  |  | 96,683 |  |  |  | 319,607 |  |  |  | 311,076 |  |
| Provision for income taxes |  |  | 13,423 |  |  |  | 19,986 |  |  |  | 67,299 |  |  |  | 69,856 |  |
| Net income |  |  | 69,936 |  |  |  | 76,697 |  |  |  | 252,308 |  |  |  | 241,220 |  |
| Net income attributable to noncontrolling interests |  |  | 322 |  |  |  | 1,122 |  |  |  | 301 |  |  |  | 2,963 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 69,614 |  |  | $ | 75,575 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | 9,862 |  |  | $ | (7,214 | ) |  | $ | 2,210 |  |  | $ | (5,976 | ) |
| Net unrealized gain (loss) on derivatives |  |  | 1,043 |  |  |  | (7,479 | ) |  |  | (13,855 | ) |  |  | 2,924 |  |
| Pension liability adjustment |  |  | 10,541 |  |  |  | 437 |  |  |  | 10,541 |  |  |  | 437 |  |
| Other comprehensive income (loss) |  |  | 21,446 |  |  |  | (14,256 | ) |  |  | (1,104 | ) |  |  | (2,615 | ) |
| Total comprehensive income |  |  | 91,382 |  |  |  | 62,441 |  |  |  | 251,204 |  |  |  | 238,605 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 1,371 |  |  |  | 679 |  |  |  | (635 | ) |  |  | 1,647 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 90,011 |  |  | $ | 61,762 |  |  | $ | 251,839 |  |  | $ | 236,958 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.14 |  |  | $ | 1.21 |  |  | $ | 4.09 |  |  | $ | 3.57 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,056,624 |  |  |  | 61,669,467 |  |  |  | 61,926,986 |  |  |  | 61,662,031 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.12 |  |  | $ | 1.20 |  |  | $ | 4.03 |  |  | $ | 3.54 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,219,078 |  |  |  | 62,201,066 |  |  |  | 62,865,446 |  |  |  | 62,233,225 |  |

[0001437749-20-002505:8k_2_02:74]
Generac Holdings Inc.

[0001437749-20-002505:8k_2_02:75]
Consolidated Balance Sheets

[0001437749-20-002505:8k_2_02:76]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-20-002505:8k_2_02:77]
(Unaudited)

[0001437749-20-002505:8k_2_02:78]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 322,883 |  |  | $ | 224,482 |  |
| Accounts receivable, less allowance for doubtful accounts of $6,968 and $4,873 at December 31, 2019 and 2018, respectively |  |  | 319,538 |  |  |  | 326,133 |  |
| Inventories |  |  | 522,024 |  |  |  | 544,750 |  |
| Prepaid expenses and other assets |  |  | 31,384 |  |  |  | 25,404 |  |
| Total current assets |  |  | 1,195,829 |  |  |  | 1,120,769 |  |
| Property and equipment, net |  |  | 316,976 |  |  |  | 278,929 |  |
| Customer lists, net |  |  | 55,552 |  |  |  | 61,194 |  |
| Patents and technology, net |  |  | 85,546 |  |  |  | 29,970 |  |
| Other intangible assets, net |  |  | 8,259 |  |  |  | 3,043 |  |
| Tradenames, net |  |  | 148,377 |  |  |  | 152,283 |  |
| Goodwill |  |  | 805,284 |  |  |  | 764,655 |  |
| Deferred income taxes |  |  | 2,933 |  |  |  | 163 |  |
| Operating lease and other assets |  |  | 46,913 |  |  |  | 15,308 |  |
| Total assets |  | $ | 2,665,669 |  |  | $ | 2,426,314 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 58,714 |  |  | $ | 45,583 |  |
| Accounts payable |  |  | 261,977 |  |  |  | 328,091 |  |
| Accrued wages and employee benefits |  |  | 41,361 |  |  |  | 40,819 |  |
| Other accrued liabilities |  |  | 132,629 |  |  |  | 144,236 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 2,383 |  |  |  | 1,977 |  |
| Total current liabilities |  |  | 497,064 |  |  |  | 560,706 |  |
| Long-term borrowings and finance lease obligations |  |  | 837,767 |  |  |  | 876,396 |  |
| Deferred income taxes |  |  | 96,328 |  |  |  | 71,300 |  |
| Operating lease and other long-term liabilities |  |  | 140,432 |  |  |  | 95,647 |  |
| Total liabilities |  |  | 1,571,591 |  |  |  | 1,604,049 |  |
| Redeemable noncontrolling interest |  |  | 61,227 |  |  |  | 61,004 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,667,726 and 71,186,418 shares issued at December 31, 2019 and 2018, respectively |  |  | 717 |  |  |  | 712 |  |
| Additional paid-in capital |  |  | 498,866 |  |  |  | 476,116 |  |
| Treasury stock, at cost, 9,103,013 and 9,047,060 shares at December 31, 2019 and 2018, respectively |  |  | (324,551 | ) |  |  | (321,473 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,084,383 |  |  |  | 831,123 |  |
| Accumulated other comprehensive loss |  |  | (24,917 | ) |  |  | (23,813 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,032,382 |  |  |  | 760,549 |  |
| Noncontrolling interests |  |  | 469 |  |  |  | 712 |  |
| Total stockholders’ equity |  |  | 1,032,851 |  |  |  | 761,261 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,665,669 |  |  | $ | 2,426,314 |  |

[0001437749-20-002505:8k_2_02:79]
Generac Holdings Inc.

[0001437749-20-002505:8k_2_02:80]
Consolidated Statements of Cash Flows

[0001437749-20-002505:8k_2_02:81]
(U.S. Dollars in Thousands)

[0001437749-20-002505:8k_2_02:82]
(Unaudited)

[0001437749-20-002505:8k_2_02:83]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 252,308 |  |  | $ | 241,220 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 32,265 |  |  |  | 25,296 |  |
| Amortization of intangible assets |  |  | 28,644 |  |  |  | 22,112 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 4,712 |  |  |  | 4,749 |  |
| Loss on extinguishment of debt |  |  | 926 |  |  |  | 1,332 |  |
| Loss on pension settlement |  |  | 10,920 |  |  |  | – |  |
| Deferred income taxes |  |  | 18,733 |  |  |  | 23,600 |  |
| Share-based compensation expense |  |  | 16,694 |  |  |  | 14,563 |  |
| Other |  |  | 1,086 |  |  |  | 2,474 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,231 |  |  |  | (43,243 | ) |
| Inventories |  |  | 26,369 |  |  |  | (152,594 | ) |
| Other assets |  |  | (358 | ) |  |  | (6,362 | ) |
| Accounts payable |  |  | (69,404 | ) |  |  | 86,359 |  |
| Accrued wages and employee benefits |  |  | (3,724 | ) |  |  | 12,626 |  |
| Other accrued liabilities |  |  | (16,252 | ) |  |  | 16,972 |  |
| Excess tax benefits from equity awards |  |  | (2,263 | ) |  |  | (1,877 | ) |
| Net cash provided by operating activities |  |  | 308,887 |  |  |  | 247,227 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 95 |  |  |  | 214 |  |
| Proceeds from beneficial interest in securitization transactions |  |  | 2,630 |  |  |  | 3,933 |  |
| Expenditures for property and equipment |  |  | (60,802 | ) |  |  | (47,601 | ) |
| Acquisition of business, net of cash acquired |  |  | (112,001 | ) |  |  | (65,440 | ) |
| Net cash used in investing activities |  |  | (170,078 | ) |  |  | (108,894 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 73,340 |  |  |  | 53,965 |  |
| Proceeds from long-term borrowings |  |  | 1,660 |  |  |  | 51,425 |  |
| Repayments of short-term borrowings |  |  | (59,518 | ) |  |  | (27,880 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (53,049 | ) |  |  | (101,827 | ) |
| Stock repurchases |  |  | – |  |  |  | (25,656 | ) |
| Payment of contingent consideration |  |  | (5,550 | ) |  |  | – |  |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (285 | ) |  |  | (314 | ) |
| Payment of debt issuance costs |  |  | (1,473 | ) |  |  | (1,702 | ) |
| Taxes paid related to equity awards |  |  | (6,438 | ) |  |  | (5,659 | ) |
| Proceeds from the exercise of stock options |  |  | 9,395 |  |  |  | 5,614 |  |
| Net cash used in financing activities |  |  | (41,918 | ) |  |  | (52,034 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,510 |  |  |  | (289 | ) |
| Net increase in cash and cash equivalents |  |  | 98,401 |  |  |  | 86,010 |  |
| Cash and cash equivalents at beginning of period |  |  | 224,482 |  |  |  | 138,472 |  |
| Cash and cash equivalents at end of period |  | $ | 322,883 |  |  | $ | 224,482 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 35,465 |  |  | $ | 41,007 |  |
| Income taxes |  |  | 61,767 |  |  |  | 41,044 |  |

[0001437749-20-002505:8k_2_02:84]
Generac Holdings Inc.

[0001437749-20-002505:8k_2_02:85]
Segment Reporting and Product Class Information

[0001437749-20-002505:8k_2_02:86]
(U.S. Dollars in Thousands)

[0001437749-20-002505:8k_2_02:87]
(Unaudited)

[0001437749-20-002505:8k_2_02:88]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Reportable Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic (1) |  | $ | 470,058 |  |  | $ | 436,339 |  |  | $ | 1,742,898 |  |  | $ | 1,566,520 |  |
| International (1) |  |  | 120,874 |  |  |  | 127,065 |  |  |  | 461,438 |  |  |  | 456,944 |  |
| Total net sales |  | $ | 590,932 |  |  | $ | 563,404 |  |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 322,490 |  |  | $ | 293,949 |  |  | $ | 1,143,723 |  |  | $ | 1,042,739 |  |
| Commercial & industrial products |  |  | 217,137 |  |  |  | 223,151 |  |  |  | 871,595 |  |  |  | 820,270 |  |
| Other |  |  | 51,305 |  |  |  | 46,304 |  |  |  | 189,018 |  |  |  | 160,455 |  |
| Total net sales |  | $ | 590,932 |  |  | $ | 563,404 |  |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |

[0001437749-20-002505:8k_2_02:89]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic (1) |  | $ | 122,920 |  |  | $ | 116,343 |  |  | $ | 428,667 |  |  | $ | 388,495 |  |
| International (1) |  |  | 6,228 |  |  |  | 9,724 |  |  |  | 25,448 |  |  |  | 36,057 |  |
| Total adjusted EBITDA (2) |  | $ | 129,148 |  |  | $ | 126,067 |  |  | $ | 454,115 |  |  | $ | 424,552 |  |

[0001437749-20-002505:8k_2_02:90]
(1) In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the first, second and third quarters ended in 2019, net sales of $2,705, $4,406, and $3,353, respectively, and adjusted EBITDA of $(253), $845, and $384, respectively, were moved from the Domestic segment to the International segment.  For the first, second, third, and fourth quarters ended in 2018, net sales of $3,822, $5,907, $2,577, and $1,499, respectively, and adjusted EBITDA of $312, $815, $(94), and $(843), respectively, were moved from the Domestic segment to the International segment.

[0001437749-20-002505:8k_2_02:91]
(2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-20-002505:8k_2_02:92]
Generac Holdings, Inc.

[0001437749-20-002505:8k_2_02:93]
Reconciliation Schedules

[0001437749-20-002505:8k_2_02:94]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-20-002505:8k_2_02:95]
(Unaudited)

[0001437749-20-002505:8k_2_02:96]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 69,614 |  |  | $ | 75,575 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Net income attributable to noncontrolling interests |  |  | 322 |  |  |  | 1,122 |  |  |  | 301 |  |  |  | 2,963 |  |
| Net income |  |  | 69,936 |  |  |  | 76,697 |  |  |  | 252,308 |  |  |  | 241,220 |  |
| Interest expense |  |  | 10,116 |  |  |  | 10,017 |  |  |  | 41,544 |  |  |  | 40,956 |  |
| Depreciation and amortization |  |  | 17,926 |  |  |  | 12,284 |  |  |  | 60,767 |  |  |  | 47,408 |  |
| Provision for income taxes |  |  | 13,423 |  |  |  | 19,986 |  |  |  | 67,299 |  |  |  | 69,856 |  |
| Non-cash write-down and other adjustments (1) |  |  | (433 | ) |  |  | 10 |  |  |  | 240 |  |  |  | 3,532 |  |
| Non-cash share-based compensation expense (2) |  |  | 5,217 |  |  |  | 4,653 |  |  |  | 16,694 |  |  |  | 14,563 |  |
| Loss on extinguishment of debt (3) |  |  | 926 |  |  |  | – |  |  |  | 926 |  |  |  | 1,332 |  |
| Loss on pension settlement (4) |  |  | 10,920 |  |  |  | – |  |  |  | 10,920 |  |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | 677 |  |  |  | 1,413 |  |  |  | 2,724 |  |  |  | 3,883 |  |
| Business optimization expenses (6) |  |  | 763 |  |  |  | 202 |  |  |  | 1,572 |  |  |  | 952 |  |
| Other |  |  | (323 | ) |  |  | 805 |  |  |  | (879 | ) |  |  | 850 |  |
| Adjusted EBITDA |  |  | 129,148 |  |  |  | 126,067 |  |  |  | 454,115 |  |  |  | 424,552 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,243 |  |  |  | 2,126 |  |  |  | 4,965 |  |  |  | 7,759 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 127,905 |  |  | $ | 123,941 |  |  | $ | 449,150 |  |  | $ | 416,793 |  |

[0001437749-20-002505:8k_2_02:97]
(1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-20-002505:8k_2_02:98]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-20-002505:8k_2_02:99]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-20-002505:8k_2_02:100]
(4) Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019.

[0001437749-20-002505:8k_2_02:101]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-20-002505:8k_2_02:102]
(6) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities.

[0001437749-20-002505:8k_2_02:103]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 69,614 |  |  | $ | 75,575 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Net income attributable to noncontrolling interests |  |  | 322 |  |  |  | 1,122 |  |  |  | 301 |  |  |  | 2,963 |  |
| Net income |  |  | 69,936 |  |  |  | 76,697 |  |  |  | 252,308 |  |  |  | 241,220 |  |
| Provision for income taxes |  |  | 13,423 |  |  |  | 19,986 |  |  |  | 67,299 |  |  |  | 69,856 |  |
| Income before provision for income taxes |  |  | 83,359 |  |  |  | 96,683 |  |  |  | 319,607 |  |  |  | 311,076 |  |
| Amortization of intangible assets |  |  | 8,645 |  |  |  | 5,320 |  |  |  | 28,644 |  |  |  | 22,112 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,115 |  |  |  | 1,195 |  |  |  | 4,712 |  |  |  | 4,749 |  |
| Loss on extinguishment of debt (3) |  |  | 926 |  |  |  | – |  |  |  | 926 |  |  |  | 1,332 |  |
| Loss on pension settlement (4) |  |  | 10,920 |  |  |  | – |  |  |  | 10,920 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | (499 | ) |  |  | 1,062 |  |  |  | 874 |  |  |  | 2,578 |  |
| Business optimization expenses (6) |  |  | 763 |  |  |  | 202 |  |  |  | 1,572 |  |  |  | 952 |  |
| Adjusted net income before provision for income taxes |  |  | 105,229 |  |  |  | 104,462 |  |  |  | 367,255 |  |  |  | 342,799 |  |
| Cash income tax expense (8) |  |  | (8,247 | ) |  |  | (15,355 | ) |  |  | (47,945 | ) |  |  | (47,064 | ) |
| Adjusted net income |  |  | 96,982 |  |  |  | 89,107 |  |  |  | 319,310 |  |  |  | 295,735 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 530 |  |  |  | 1,031 |  |  |  | 1,488 |  |  |  | 3,522 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 96,452 |  |  | $ | 88,076 |  |  | $ | 317,822 |  |  | $ | 292,213 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.53 |  |  | $ | 1.42 |  |  | $ | 5.06 |  |  | $ | 4.70 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,219,078 |  |  |  | 62,201,066 |  |  |  | 62,865,446 |  |  |  | 62,233,225 |  |

[0001437749-20-002505:8k_2_02:104]
(7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-20-002505:8k_2_02:105]
(8) Amount for the three months and year ended December 31, 2019 is based on an anticipated cash income tax rate of 15% for the full year ended 2019. Amount for the three months and year ended December 31, 2018 is based on an anticipated cash income tax rate of 15% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-20-002505:8k_2_02:106]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net cash provided by operating activities |  | $ | 175,085 |  |  | $ | 108,229 |  |  | $ | 308,887 |  |  | $ | 247,227 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 594 |  |  |  | 1,108 |  |  |  | 2,630 |  |  |  | 3,933 |  |
| Expenditures for property and equipment |  |  | (15,355 | ) |  |  | (22,024 | ) |  |  | (60,802 | ) |  |  | (47,601 | ) |
| Free cash flow |  | $ | 160,324 |  |  | $ | 87,313 |  |  | $ | 250,715 |  |  | $ | 203,559 |  |

[0001437749-20-002505:8k_2_02:107]
GAAP Earnings Per Share

[0001437749-20-002505:8k_2_02:108]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 69,614 |  |  | $ | 75,575 |  |  | $ | 252,007 |  |  | $ | 238,257 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 1,054 |  |  |  | (1,088 | ) |  |  | 1,253 |  |  |  | (17,970 | ) |
| Net income attributable to common shareholders |  | $ | 70,668 |  |  | $ | 74,487 |  |  | $ | 253,260 |  |  | $ | 220,287 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,056,624 |  |  |  | 61,669,467 |  |  |  | 61,926,986 |  |  |  | 61,662,031 |  |
| Dilutive effect of stock compensation awards |  |  | 1,162,454 |  |  |  | 531,599 |  |  |  | 938,460 |  |  |  | 571,194 |  |
| Diluted shares |  |  | 63,219,078 |  |  |  | 62,201,066 |  |  |  | 62,865,446 |  |  |  | 62,233,225 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.14 |  |  | $ | 1.21 |  |  | $ | 4.09 |  |  | $ | 3.57 |  |
| Diluted |  | $ | 1.12 |  |  | $ | 1.20 |  |  | $ | 4.03 |  |  | $ | 3.54 |  |
