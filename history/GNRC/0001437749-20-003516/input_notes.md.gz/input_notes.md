# GNRC notes — 0001437749-20-003516


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-20-003516:notes:1]
| 1. | Description of Business |

[0001437749-20-003516:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-20-003516:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of our "Powering Our Future" strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-20-003516:notes:4]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. |

[0001437749-20-003516:notes:5]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |

[0001437749-20-003516:notes:6]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators for the India market. |

[0001437749-20-003516:notes:7]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

[0001437749-20-003516:notes:8]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses, and is also a manufacturer of advanced power electronics, software and controls for smart energy storage and management. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-20-003516:notes:9]
| 2. | Summary of Accounting Policies |

[0001437749-20-003516:notes:10]
Principles of Consolidation

[0001437749-20-003516:notes:11]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-20-003516:notes:12]
Cash and Cash Equivalents

[0001437749-20-003516:notes:13]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-20-003516:notes:14]
Concentration of Credit Risk

[0001437749-20-003516:notes:15]
The Company maintains the majority of its domestic cash in one commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-20-003516:notes:16]
One customer accounted for approximately 9% and 11% of accounts receivable at  December 31, 2019 and 2018, respectively. No one customer accounted for greater than 5%, 6%, and 6%, of net sales during the years ended  December 31, 2019, 2018, or 2017, respectively.

[0001437749-20-003516:notes:17]
Accounts Receivable

[0001437749-20-003516:notes:18]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis, and certain balances are protected by credit insurance.

[0001437749-20-003516:notes:19]
Inventories

[0001437749-20-003516:notes:20]
Inventories are stated at the lower of cost or market, with cost determined generally using the first-in, first-out method.

[0001437749-20-003516:notes:21]
Property and Equipment

[0001437749-20-003516:notes:22]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. Finance lease right of use assets are included in property and equipment. Refer to Note 10, "Leases," to the consolidated financial statements for the Company's lease disclosure.

[0001437749-20-003516:notes:23]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office equipment and systems |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-20-003516:notes:24]
Total depreciation expense was $32,265, $25,296, and $23,127 for the years ended  December 31, 2019, 2018, and 2017, respectively.

[0001437749-20-003516:notes:25]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-20-003516:notes:26]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-20-003516:notes:27]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-20-003516:notes:28]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2019, 2018 and 2017, and found no impairment.

[0001437749-20-003516:notes:29]
Impairment of Long-Lived Assets

[0001437749-20-003516:notes:30]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-20-003516:notes:31]
Debt Issuance Costs

[0001437749-20-003516:notes:32]
Debt discounts and direct costs incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $4,712, $4,749, and $3,516 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2019, 2018 and 2017, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2020 - $2,598; 2021 - $2,640; 2022 - $2,689; 2023 - $2,579; 2024 - $2,508.

[0001437749-20-003516:notes:33]
Income Taxes

[0001437749-20-003516:notes:34]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-20-003516:notes:35]
Revenue Recognition

[0001437749-20-003516:notes:36]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-20-003516:notes:37]
At the request of certain customers, the Company will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-20-003516:notes:38]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $9,952 and $14,174 at  December 31, 2019 and  December 31, 2018, respectively. During the year ended  December 31, 2019, the Company recognized revenue of $9,589 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-20-003516:notes:39]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-20-003516:notes:40]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-20-003516:notes:41]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. Total service revenues account for less than three percent of revenue during the year ended  December 31, 2019.

[0001437749-20-003516:notes:42]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-20-003516:notes:43]
Advertising and Co-Op Advertising

[0001437749-20-003516:notes:44]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Total expenditures for advertising were $44,153, $34,792, and $45,926 for the years ended  December 31, 2019, 2018, and 2017, respectively.

[0001437749-20-003516:notes:45]
Research and Development

[0001437749-20-003516:notes:46]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $68,394, $50,019, and $42,869 for the years ended  December 31, 2019, 2018, and 2017, respectively.

[0001437749-20-003516:notes:47]
Foreign Currency Translation and Transactions

[0001437749-20-003516:notes:48]
Balance sheet amounts for non-U.S. Dollar functional currency businesses are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:49]
Fair Value of Financial Instruments

[0001437749-20-003516:notes:50]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-20-003516:notes:51]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $812,953, was approximately $833,092 (Level 2) at  December 31, 2019, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-20-003516:notes:52]
For the fair value of the assets and liabilities measured on a recurring basis, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-20-003516:notes:53]
Use of Estimates

[0001437749-20-003516:notes:54]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-20-003516:notes:55]
Derivative Instruments and Hedging Activities

[0001437749-20-003516:notes:56]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes. Refer to Item 7A of this Annual Report on Form 10-K for further information on the Company’s derivatives.

[0001437749-20-003516:notes:57]
Share-Based Compensation

[0001437749-20-003516:notes:58]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.

[0001437749-20-003516:notes:59]
New Accounting Pronouncements

[0001437749-20-003516:notes:60]
New Accounting Standards Not Yet Adopted

[0001437749-20-003516:notes:61]
In  June 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company has established a project plan and an implementation team to adopt and apply the new standard. The Company is in the process of implementing necessary changes to accounting policies, processes, and controls to enable compliance with this new standard. The Company continues to evaluate the impact the adoption of this standard will have on its consolidated financial statements, and does not believe this new standard will have a material impact.

[0001437749-20-003516:notes:62]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

[0001437749-20-003516:notes:63]
Recently Adopted Accounting Standards

[0001437749-20-003516:notes:64]
On  January 1, 2019, the Company adopted ASU 2016-02, Leases (Topic 842). This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carry forward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s consolidated balance sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did not have a material impact on the consolidated statement of comprehensive income and statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s leases.

[0001437749-20-003516:notes:65]
On  January 1, 2019, the Company adopted ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to not reclassify the stranded income tax effects from AOCI to retained earnings.

[0001437749-20-003516:notes:66]
On  January 1, 2019, the Company adopted ASU 2017-12, Derivatives and Hedging – Targeted Improvements to Accounting for Hedging Activities. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The adoption of this standard did not have an impact on the Company’s hedging strategies, and did not have a material impact on the Company’s results of operations and financial position.

[0001437749-20-003516:notes:67]
On  April 1, 2019, the Company adopted ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The Company adopted this standard prospectively, impacting all implementation costs incurred after adoption. The adoption did not have a material impact on the Company’s results of operations and financial position.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-20-003516:notes:68]
| 3. | Acquisitions |

[0001437749-20-003516:notes:69]
Acquisition of Pika

[0001437749-20-003516:notes:70]
On  April 26, 2019, the Company acquired Pika for a purchase price, net of cash acquired, of $49,068. The acquisition purchase price was funded solely through cash on hand.

[0001437749-20-003516:notes:71]
The Company recorded a preliminary purchase price allocation during the second quarter of 2019, which was trued-up in the fourth quarter of 2019, based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Pika from the date of acquisition through  December 31, 2019. The preliminary allocation of the purchase price is based on a preliminary valuation performed to determine the fair value of the net assets as of the acquisition date. The purchase price allocation is subject to further analysis and review, primarily around the review and final valuation of acquired intangible assets.

[0001437749-20-003516:notes:72]
Acquisition of Neurio

[0001437749-20-003516:notes:73]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of a deferred payment of $7,922 which was made during the third quarter of 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-20-003516:notes:74]
The Company recorded a preliminary purchase price allocation in the second quarter of 2019, which was trued-up in the fourth quarter of 2019, based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill and other intangible assets ascribed to this acquisition are deductible for tax purposes. The accompanying consolidated financial statements include the results of Neurio from the date of acquisition through  December 31, 2019. The preliminary allocation of the purchase price is based on a preliminary valuation performed to determine the fair value of the net assets as of the acquisition date. The purchase price allocation is subject to further analysis and review, primarily around the review and final valuation of acquired intangible assets.

[0001437749-20-003516:notes:75]
Acquisition of Selmec

[0001437749-20-003516:notes:76]
On  June 1, 2018, the Company acquired Selmec for a purchase price of $79,972, net of cash acquired and inclusive of earnout payments of $14,902. Changes in the fair value of the earnout liability during 2019 of $(977), which included interest accretion of $2,740 and other fair value remeasurement adjustments of $(3,717), were recognized as a component of operating income in the Company’s consolidated statements of comprehensive income for the year ended  December 31, 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-20-003516:notes:77]
The Company finalized the Selmec purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The final purchase price allocation as of the  June 1, 2018 opening balance sheet date was as follows:

[0001437749-20-003516:notes:78]
|  |  | June 1, 2018 |  |
| Accounts receivable |  | $ | 14,302 |  |
| Inventories |  |  | 8,000 |  |
| Prepaid expense and other assets |  |  | 4,323 |  |
| Property and equipment |  |  | 5,572 |  |
| Intangible assets |  |  | 33,631 |  |
| Goodwill |  |  | 46,196 |  |
| Deferred income taxes |  |  | 3,252 |  |
| Other assets |  |  | 597 |  |
| Total assets acquired |  |  | 115,873 |  |
| Accounts payable |  |  | 7,216 |  |
| Accrued wages and employee benefits |  |  | 397 |  |
| Other accrued liabilities |  |  | 13,671 |  |
| Deferred income taxes |  |  | 10,974 |  |
| Other long-term liabilities |  |  | 3,643 |  |
| Net assets acquired |  | $ | 79,972 |  |

[0001437749-20-003516:notes:79]
The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Selmec from the date of acquisition through  December 31, 2019.

[0001437749-20-003516:notes:80]
Pro Forma Information

[0001437749-20-003516:notes:81]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on  January 1, 2017. Refer to Note 1, “Description of Business,” for further information on the acquisitions included in the table.

[0001437749-20-003516:notes:82]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |
| Pro forma |  |  | 2,206,952 |  |  |  | 2,067,737 |  |  |  | 1,755,358 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 252,007 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Pro forma |  |  | 248,335 |  |  |  | 230,379 |  |  |  | 151,764 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 4.03 |  |  | $ | 3.54 |  |  | $ | 2.53 |  |
| Pro forma |  |  | 3.97 |  |  |  | 3.41 |  |  |  | 2.44 |  |

[0001437749-20-003516:notes:83]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on  January 1, 2017.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-20-003516:notes:84]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-20-003516:notes:85]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021.

[0001437749-20-003516:notes:86]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions, Ltd (Captiva). The 49% noncontrolling interest in Captiva has an acquisition date fair value of $3,165, and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put option price is based on a multiple of earnings, subject to the terms of the acquisition. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings, subject to the terms of the acquisition.

[0001437749-20-003516:notes:87]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-20-003516:notes:88]
|  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  |
| Balance at beginning of period |  | $ | 61,004 |  |  | $ | 43,929 |  |  | $ | 33,138 |  |  |
| Noncontrolling interest |  |  | 3,165 |  | (1) |  | - |  |  |  | 1,540 |  | (2) |
| Net income |  |  | 75 |  |  |  | 2,214 |  |  |  | 1,631 |  |  |
| Foreign currency translation |  |  | (1,764 | ) |  |  | (3,109 | ) |  |  | 8,529 |  |  |
| Redemption value adjustment |  |  | (1,253 | ) |  |  | 17,970 |  |  |  | (909 | ) |  |
| Balance at end of period |  | $ | 61,227 |  |  | $ | 61,004 |  |  | $ | 43,929 |  |  |

[0001437749-20-003516:notes:89]
| (1) Represents the noncontrolling interest of Captiva Energy calculated at the date of acquisition, February 1, 2019. |
| (2) Represents the additional noncontrolling interest of Pramac resulting from a common control transaction between Generac Mobile Products S.r.l. and Pramac UK Limited legal entities. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-003516:notes:90]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-20-003516:notes:91]
Commodities

[0001437749-20-003516:notes:92]
The Company is exposed to price fluctuations in commodities including steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than eighteen months. At  December 31, 2019 and 2018, the Company had no commodity contracts outstanding.

[0001437749-20-003516:notes:93]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized were $(174), $(874), and $377 for the years ended  December 31, 2019, 2018, and 2017, respectively.

[0001437749-20-003516:notes:94]
Foreign Currencies

[0001437749-20-003516:notes:95]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less. As of  December 31, 2019 and 2018, the Company had forty-three and forty foreign currency contracts outstanding, respectively.

[0001437749-20-003516:notes:96]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in "other, net" in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended  December 31, 2019, 2018, and 2017 were $(1,195), $(653), and $697, respectively.

[0001437749-20-003516:notes:97]
Interest Rate Swaps

[0001437749-20-003516:notes:98]
In 2017, the Company entered into twenty interest rate swap agreements. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking these hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets. The amount of gains (losses) recognized for the years ended  December 31, 2019, 2018, and 2017 were $(13,855), $2,924, and $3,712, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-20-003516:notes:99]
Fair Value

[0001437749-20-003516:notes:100]
The following table presents the fair value of the Company’s derivatives:

[0001437749-20-003516:notes:101]
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Commodity contracts |  | $ | 6 |  |  | $ | (160 | ) |
| Foreign currency contracts |  |  | 31 |  |  |  | (117 | ) |
| Interest rate swaps |  |  | (10,425 | ) |  |  | 8,307 |  |

[0001437749-20-003516:notes:102]
The fair value of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2019. The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other assets in the consolidated balance sheet as of  December 31, 2018. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2019 and 2018 is a liability of $10,588 and an asset of $8,220, respectively, which represents the amount the Company would pay or receive upon exit of the agreements on those dates.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-20-003516:notes:103]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-20-003516:notes:104]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2019 and 2018, net of tax:

[0001437749-20-003516:notes:105]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  | $ | (23,813 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,210 |  |  |  | 1,474 |  | (1) |  | (13,855 | ) | (2) |  | (10,171 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 9,067 |  | (3) |  | - |  |  |  | 9,067 |  |
| Net current-period other comprehensive income (loss) |  |  | 2,210 |  |  |  | 10,541 |  |  |  | (13,855 | ) |  |  | (1,104 | ) |
| Ending Balance – December 31, 2019 |  | $ | (16,622 | ) |  | $ | - |  |  | $ | (8,295 | ) |  | $ | (24,917 | ) |

[0001437749-20-003516:notes:106]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (5,976 | ) |  |  | (156 | ) | (4) |  | 2,924 |  | (5) |  | (3,208 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 593 |  | (6) |  | - |  |  |  | 593 |  |
| Net current-period other comprehensive income (loss) |  |  | (5,976 | ) |  |  | 437 |  |  |  | 2,924 |  |  |  | (2,615 | ) |
| Ending Balance – December 31, 2018 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  | $ | (23,813 | ) |

[0001437749-20-003516:notes:107]
|  | (1) | Represents unrecognized actuarial gains of $1,992 net of tax effect of $(518), included in the computation of net periodic pension cost for the year ended December 31, 2019. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-20-003516:notes:108]
|  | (2) | Represents unrealized losses of $(18,732), net of tax effect of $4,877 for the year ended December 31, 2019. |

[0001437749-20-003516:notes:109]
|  | (3) | Details of reclassifications from AOCL during 2019 are as follows: |

[0001437749-20-003516:notes:110]
|  |  | Amounts reclassified from AOCL |  |
| Loss on pension settlement |  | $ | 10,920 |  |
| Amortization of net loss |  |  | 843 |  |
| Total before tax |  |  | 11,763 |  |
| Income tax impact |  |  | (2,696 | ) |
| Amounts reclassified from AOCL |  | $ | 9,067 |  |

[0001437749-20-003516:notes:111]
|  | (4) | Represents unrecognized actuarial losses of $(211), net of tax benefit of $55, included in the computation of net periodic pension cost for the year ended December 31, 2018. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-20-003516:notes:112]
|  | (5) | Represents unrealized gains of $3,951, net of tax effect of $(1,027) for the year ended December 31, 2018. |

[0001437749-20-003516:notes:113]
|  | (6) | Represents actuarial losses of $802, net of tax effect of $(209), amortized to net periodic pension cost for the year ended December 31, 2018. Refer to Note 16, “Benefit Plans,” to the consolidated financial statements for additional information. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-003516:notes:114]
| 7. | Segment Reporting |

[0001437749-20-003516:notes:115]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business, (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business's Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues that are substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment, energy technology solutions, and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-20-003516:notes:116]
The Company's product offerings consist primarily of power generation equipment, energy technology solutions, and other power products geared for varying end customer uses. Residential products and commercial & industrial (C&I) products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-20-003516:notes:117]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,086,019 |  |  | $ | 57,704 |  |  | $ | 1,143,723 |  |
| Commercial & industrial products |  |  | 513,482 |  |  |  | 358,113 |  |  |  | 871,595 |  |
| Other |  |  | 143,397 |  |  |  | 45,621 |  |  |  | 189,018 |  |
| Total net sales |  | $ | 1,742,898 |  |  | $ | 461,438 |  |  | $ | 2,204,336 |  |

[0001437749-20-003516:notes:118]
|  |  | Year Ended December 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 980,707 |  |  | $ | 62,032 |  |  | $ | 1,042,739 |  |
| Commercial & industrial products |  |  | 461,415 |  |  |  | 358,855 |  |  |  | 820,270 |  |
| Other |  |  | 124,398 |  |  |  | 36,057 |  |  |  | 160,455 |  |
| Total net sales |  | $ | 1,566,520 |  |  | $ | 456,944 |  |  | $ | 2,023,464 |  |

[0001437749-20-003516:notes:119]
|  |  | Year Ended December 31, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 796,237 |  |  | $ | 74,253 |  |  | $ | 870,490 |  |
| Commercial & industrial products |  |  | 372,635 |  |  |  | 311,718 |  |  |  | 684,353 |  |
| Other |  |  | 102,806 |  |  |  | 21,724 |  |  |  | 124,530 |  |
| Total net sales |  | $ | 1,271,678 |  |  | $ | 407,695 |  |  | $ | 1,679,373 |  |

[0001437749-20-003516:notes:120]
Residential products consist primarily of automatic home standby generators ranging in output from 6kW to 60kW, portable generators, energy storage and monitoring solutions, and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-20-003516:notes:121]
C&I products consist of larger output stationary generators used in C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 10kW up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-20-003516:notes:122]
Other products consist primarily of aftermarket service parts and product accessories sold to our dealers, the amortization of extended warranty deferred revenue, and remote monitoring subscription revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract.

[0001437749-20-003516:notes:123]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-20-003516:notes:124]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 428,667 |  |  | $ | 388,495 |  |  | $ | 282,450 |  |
| International |  |  | 25,448 |  |  |  | 36,057 |  |  |  | 34,850 |  |
| Total adjusted EBITDA |  | $ | 454,115 |  |  | $ | 424,552 |  |  | $ | 317,300 |  |
| Interest expense |  |  | (41,544 | ) |  |  | (40,956 | ) |  |  | (42,667 | ) |
| Depreciation and amortization |  |  | (60,767 | ) |  |  | (47,408 | ) |  |  | (51,988 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (240 | ) |  |  | (3,532 | ) |  |  | (2,923 | ) |
| Non-cash share-based compensation expense (2) |  |  | (16,694 | ) |  |  | (14,563 | ) |  |  | (10,205 | ) |
| Loss on extinguishment of debt (3) |  |  | (926 | ) |  |  | (1,332 | ) |  |  | - |  |
| Loss on pension settlement (4) |  |  | (10,920 | ) |  |  | - |  |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | (2,724 | ) |  |  | (3,883 | ) |  |  | (2,145 | ) |
| Business optimization expenses (6) |  |  | (1,572 | ) |  |  | (952 | ) |  |  | (2,912 | ) |
| Other |  |  | 879 |  |  |  | (850 | ) |  |  | (761 | ) |
| Income before provision for income taxes |  | $ | 319,607 |  |  | $ | 311,076 |  |  | $ | 203,699 |  |

[0001437749-20-003516:notes:125]
|  | (1) | Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposal of assets and unrealized mark-to-market adjustments on commodity contracts. |

[0001437749-20-003516:notes:126]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-20-003516:notes:127]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |

[0001437749-20-003516:notes:128]
|  | (4) | Represents pre-tax settlement charges related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019. |

[0001437749-20-003516:notes:129]
|  | (5) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-20-003516:notes:130]
|  | (6) | Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-20-003516:notes:131]
In the fourth quarter of 2019, management has determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment beginning in 2018. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. This change is to reflect the current leadership structure as well as how the Company makes financial decisions and allocates resources for the overall Latin America reporting unit. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment included in this Form 10-K for the years ended  December 31, 2019, 2018, and 2017. The following table details the amounts adjusted from the Domestic segment to the International segment.

[0001437749-20-003516:notes:132]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Residential Products |  | $ | 7,129 |  |  | $ | 9,924 |  |  | $ | 18,888 |  |
| Commercial & industrial products |  |  | 5,724 |  |  |  | 2,651 |  |  |  | 12,940 |  |
| Other |  |  | 998 |  |  |  | 1,230 |  |  |  | - |  |
| Total Net Sales |  | $ | 13,851 |  |  | $ | 13,805 |  |  | $ | 31,828 |  |
| Adjusted EBITDA |  | $ | 984 |  |  | $ | 190 |  |  | $ | 7,840 |  |

[0001437749-20-003516:notes:133]
There was no impact to the Company’s reporting of total assets, depreciation and amortization, and capital expenditures by segment as a result of this change.

[0001437749-20-003516:notes:134]
The following tables summarize additional financial information by reportable segment:

[0001437749-20-003516:notes:135]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 2,123,251 |  |  | $ | 1,868,554 |  |  | $ | 1,612,607 |  |
| International |  |  | 542,418 |  |  |  | 557,760 |  |  |  | 413,358 |  |
| Total |  | $ | 2,665,669 |  |  | $ | 2,426,314 |  |  | $ | 2,025,965 |  |

[0001437749-20-003516:notes:136]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 46,145 |  |  | $ | 35,586 |  |  | $ | 37,962 |  |
| International |  |  | 14,764 |  |  |  | 11,822 |  |  |  | 14,026 |  |
| Total |  | $ | 60,909 |  |  | $ | 47,408 |  |  | $ | 51,988 |  |

[0001437749-20-003516:notes:137]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 36,007 |  |  | $ | 38,242 |  |  | $ | 29,258 |  |
| International |  |  | 24,795 |  |  |  | 9,359 |  |  |  | 4,003 |  |
| Total |  | $ | 60,802 |  |  | $ | 47,601 |  |  | $ | 33,261 |  |

[0001437749-20-003516:notes:138]
The Company’s sales in the United States represent approximately 75%, 74%, and 74% of total sales for the years ended  December 31, 2019, 2018 and 2017, respectively. Approximately 80% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2019 and 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-20-003516:notes:139]
| 8. | Balance Sheet Details |

[0001437749-20-003516:notes:140]
Inventories consist of the following:

[0001437749-20-003516:notes:141]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Raw material |  | $ | 328,021 |  |  | $ | 348,980 |  |
| Work-in-process |  |  | 10,387 |  |  |  | 6,971 |  |
| Finished goods |  |  | 183,616 |  |  |  | 188,799 |  |
| Total |  | $ | 522,024 |  |  | $ | 544,750 |  |

[0001437749-20-003516:notes:142]
As of  December 31, 2019 and 2018, inventories totaling $18,684 and $8,488, respectively, were on consignment at customer locations.

[0001437749-20-003516:notes:143]
Property and equipment consists of the following:

[0001437749-20-003516:notes:144]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Land and improvements |  | $ | 18,252 |  |  | $ | 15,975 |  |
| Buildings and improvements |  |  | 177,079 |  |  |  | 163,161 |  |
| Machinery and equipment |  |  | 117,114 |  |  |  | 103,726 |  |
| Dies and tools |  |  | 22,040 |  |  |  | 28,198 |  |
| Vehicles |  |  | 3,955 |  |  |  | 2,070 |  |
| Office equipment and systems |  |  | 99,124 |  |  |  | 82,638 |  |
| Leasehold improvements |  |  | 4,293 |  |  |  | 2,137 |  |
| Construction in progress |  |  | 36,299 |  |  |  | 26,543 |  |
| Gross property and equipment |  |  | 478,156 |  |  |  | 424,448 |  |
| Accumulated depreciation |  |  | (161,180 | ) |  |  | (145,519 | ) |
| Total |  | $ | 316,976 |  |  | $ | 278,929 |  |

[0001437749-20-003516:notes:145]
Total property and equipment included finance leases of $20,158 at  December 31, 2018, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases, in 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-20-003516:notes:146]
| 9. | Goodwill and Intangible Assets |

[0001437749-20-003516:notes:147]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2019 and 2018 are as follows:

[0001437749-20-003516:notes:148]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2017 |  | $ | 621,451 |  |  | $ | 100,072 |  |  | $ | 721,523 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 46,788 |  |  |  | 46,788 |  |
| Foreign currency translation |  |  | - |  |  |  | (3,656 | ) |  |  | (3,656 | ) |
| Balance at December 31, 2018 |  |  | 621,451 |  |  |  | 143,204 |  |  |  | 764,655 |  |
| Acquisitions of businesses, net |  |  | 37,758 |  |  |  | 3,078 |  |  |  | 40,836 |  |
| Foreign currency translation |  |  | - |  |  |  | (207 | ) |  |  | (207 | ) |
| Balance at December 31, 2019 |  | $ | 659,209 |  |  | $ | 146,075 |  |  | $ | 805,284 |  |

[0001437749-20-003516:notes:149]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-20-003516:notes:150]
The details of the gross goodwill applicable to each reportable segment at  December 31, 2019 and 2018 are as follows:

[0001437749-20-003516:notes:151]
|  |  | Year Ended December 31, 2019 |  |  | Year Ended December 31, 2018 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,162,402 |  |  | $ | (503,193 | ) |  | $ | 659,209 |  |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |
| International |  |  | 150,686 |  |  |  | (4,611 | ) |  |  | 146,075 |  |  |  | 147,815 |  |  |  | (4,611 | ) |  |  | 143,204 |  |
| Total |  | $ | 1,313,088 |  |  | $ | (507,804 | ) |  | $ | 805,284 |  |  | $ | 1,272,459 |  |  | $ | (507,804 | ) |  | $ | 764,655 |  |

[0001437749-20-003516:notes:152]
The following table summarizes intangible assets by major category as of  December 31, 2019 and 2018:

[0001437749-20-003516:notes:153]
|  |  | Weighted Average |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 9 |  |  | $ | 56,669 |  |  | $ | (36,613 | ) |  | $ | 20,056 |  |  | $ | 56,378 |  |  | $ | (32,416 | ) |  | $ | 23,962 |  |
| Customer lists |  |  | 12 |  |  |  | 369,932 |  |  |  | (314,380 | ) |  |  | 55,552 |  |  |  | 368,343 |  |  |  | (307,149 | ) |  |  | 61,194 |  |
| Patents |  |  | 13 |  |  |  | 131,086 |  |  |  | (110,554 | ) |  |  | 20,532 |  |  |  | 131,030 |  |  |  | (101,060 | ) |  |  | 29,970 |  |
| Developed technology |  |  | 9 |  |  |  | 82,886 |  |  |  | (17,872 | ) |  |  | 65,014 |  |  |  | 13,169 |  |  |  | (12,058 | ) |  |  | 1,111 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 4 |  |  |  | 12,063 |  |  |  | (3,804 | ) |  |  | 8,259 |  |  |  | 3,829 |  |  |  | (1,897 | ) |  |  | 1,932 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 653,682 |  |  | $ | (484,269 | ) |  | $ | 169,413 |  |  | $ | 573,795 |  |  | $ | (455,626 | ) |  | $ | 118,169 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 782,003 |  |  | $ | (484,269 | ) |  | $ | 297,734 |  |  | $ | 702,116 |  |  | $ | (455,626 | ) |  | $ | 246,490 |  |

[0001437749-20-003516:notes:154]
Amortization of intangible assets was $28,644, $22,112 and $28,861 in 2019, 2018 and 2017, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2020 - $31,237; 2021 - $29,473; 2022 - $22,226; 2023 - $18,344; 2024 - $16,156.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001437749-20-003516:notes:155]
| 10. | Leases |

[0001437749-20-003516:notes:156]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (“ROU”) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements.

[0001437749-20-003516:notes:157]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-20-003516:notes:158]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 20 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 10 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arms’ length transactions.

[0001437749-20-003516:notes:159]
The Company is a lessor of one building that it leases to a third party. The lease income related to this arrangement is not material to the consolidated financial statements.

[0001437749-20-003516:notes:160]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:161]
The components of total lease cost consist of the following:

[0001437749-20-003516:notes:162]
|  |  | Twelve Months Ended December 31, 2019 |  |
| Operating lease cost |  | $ | 9,647 |  |
| Finance lease cost: |  |  |  |  |
| Amortization of ROU assets |  |  | 2,531 |  |
| Interest on lease liabilities |  |  | 2,227 |  |
| Total lease cost |  | $ | 14,405 |  |

[0001437749-20-003516:notes:163]
Prior to the adoption of ASC 842, lease expense consisted of payments on operating leases. Total rent expense related to operating leases for the years ended  December 31, 2018 and 2017 was approximately $10,739 and $10,845, respectively.

[0001437749-20-003516:notes:164]
As of  January 1, 2019, the date of the adoption of ASU 2016-02, the Company recognized ROU assets and lease liabilities related to operating leases of $42,024 and $42,056, respectively, and there was no cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-20-003516:notes:165]
|  |  | December 31, 2019 |  |
| Operating Leases |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 35,950 |  |
| Operating lease liabilities - current (2) |  | $ | 7,231 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 29,778 |  |
| Total operating lease liabilities |  | $ | 37,009 |  |
| Finance Leases |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 29,142 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (3,079 | ) |
| Finance lease ROU assets, net (4) |  | $ | 26,063 |  |
| Finance lease liabilities - current (5) |  | $ | 1,830 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 24,132 |  |
| Total finance lease liabilities |  | $ | 25,962 |  |

[0001437749-20-003516:notes:166]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-20-003516:notes:167]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-20-003516:notes:168]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-20-003516:notes:169]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-20-003516:notes:170]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-20-003516:notes:171]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-20-003516:notes:172]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-20-003516:notes:173]
|  |  | Three Months Ended December 31, 2019 |  |  | Twelve Months Ended December 31, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,174 |  |  | $ | 10,125 |  |
| Operating cash flows from finance leases |  |  | 471 |  |  |  | 1,864 |  |
| Financing cash flows from finance leases |  |  | 976 |  |  |  | 3,237 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 239 |  |  |  | 4,021 |  |
| Finance leases |  |  | 632 |  |  |  | 8,797 |  |

[0001437749-20-003516:notes:174]
Weighted average remaining lease term and discount rate information related to the Company’s leases is as follows:

[0001437749-20-003516:notes:175]
|  |  | December 31, 2019 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating Leases |  |  | 6.90 |  |
| Finance Leases |  |  | 13.87 |  |
| Weighted average discount rate |  |  |  |  |
| Operating Leases |  |  | 4.59 | % |
| Finance Leases |  |  | 7.83 | % |

[0001437749-20-003516:notes:176]
The maturities of the Company’s lease liabilities are as follows:

[0001437749-20-003516:notes:177]
|  |  | As of December 31, 2019 |  |
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2020 |  | $ | 3,769 |  |  | $ | 9,086 |  |
| 2021 |  |  | 3,352 |  |  |  | 7,029 |  |
| 2022 |  |  | 3,536 |  |  |  | 5,472 |  |
| 2023 |  |  | 2,659 |  |  |  | 4,629 |  |
| 2024 |  |  | 2,650 |  |  |  | 4,288 |  |
| After 2024 |  |  | 29,371 |  |  |  | 14,232 |  |
| Total minimum lease payments |  |  | 45,337 |  |  |  | 44,736 |  |
| Interest component |  |  | (19,375 | ) |  |  | (7,727 | ) |
| Present value of minimum lease payments |  | $ | 25,962 |  |  | $ | 37,009 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-20-003516:notes:178]
| 11. | Product Warranty Obligations |

[0001437749-20-003516:notes:179]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-20-003516:notes:180]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 41,785 |  |  | $ | 35,422 |  |  | $ | 31,695 |  |
| Product warranty reserve assumed in acquisition |  |  | 1,062 |  |  |  | - |  |  |  | 43 |  |
| Payments |  |  | (26,096 | ) |  |  | (20,029 | ) |  |  | (18,861 | ) |
| Provision for warranty issued |  |  | 32,060 |  |  |  | 26,910 |  |  |  | 21,347 |  |
| Changes in estimates for pre-existing warranties |  |  | 505 |  |  |  | (518 | ) |  |  | 1,198 |  |
| Balance at end of period |  | $ | 49,316 |  |  | $ | 41,785 |  |  | $ | 35,422 |  |

[0001437749-20-003516:notes:181]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-20-003516:notes:182]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 68,340 |  |  | $ | 57,854 |  |  | $ | 36,139 |  |
| Deferred revenue contracts issued |  |  | 24,483 |  |  |  | 21,440 |  |  |  | 29,262 |  |
| Amortization of deferred revenue contracts |  |  | (14,085 | ) |  |  | (10,954 | ) |  |  | (7,547 | ) |
| Balance at end of period |  | $ | 78,738 |  |  | $ | 68,340 |  |  | $ | 57,854 |  |

[0001437749-20-003516:notes:183]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  December 31, 2019 is as follows:

[0001437749-20-003516:notes:184]
| 2020 |  | $ | 15,535 |  |
| 2021 |  |  | 16,798 |  |
| 2022 |  |  | 14,705 |  |
| 2023 |  |  | 11,367 |  |
| After 2023 |  |  | 20,333 |  |
| Total |  | $ | 78,738 |  |

[0001437749-20-003516:notes:185]
In 2017, the Company launched a post-sale extended warranty marketing program with a third party. In the program’s agreement, the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. The balance of deferred contract costs as of  December 31, 2019 and 2018 was $6,190 and $4,782, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2019, 2018 and 2017 was $869, $615 and $193, respectively.

[0001437749-20-003516:notes:186]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-20-003516:notes:187]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 27,885 |  |  | $ | 25,396 |  |
| Long-term portion - other long-term liabilities |  |  | 21,431 |  |  |  | 16,389 |  |
| Total |  | $ | 49,316 |  |  | $ | 41,785 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 15,519 |  |  | $ | 13,646 |  |
| Long-term portion - other long-term liabilities |  |  | 63,219 |  |  |  | 54,694 |  |
| Total |  | $ | 78,738 |  |  | $ | 68,340 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-20-003516:notes:188]
| 12. | Credit Agreements |

[0001437749-20-003516:notes:189]
Short-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-20-003516:notes:190]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 30,961 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 27,753 |  |  |  | 27,124 |  |
| Total |  | $ | 58,714 |  |  | $ | 45,583 |  |

[0001437749-20-003516:notes:191]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-20-003516:notes:192]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,048 | ) |  |  | (22,440 | ) |
| ABL facility |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 25,962 |  |  |  | 20,171 |  |
| Other |  |  | 2,236 |  |  |  | 1,642 |  |
| Total |  |  | 840,150 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 553 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,830 |  |  |  | 902 |  |
| Total |  | $ | 837,767 |  |  | $ | 876,396 |  |

[0001437749-20-003516:notes:193]
Maturities of long-term borrowings outstanding at  December 31, 2019, excluding finance lease obligations as their maturities are disclosed in Note 10, “Leases,” and before considering original issue discount and deferred financing costs, are as follows:

[0001437749-20-003516:notes:194]
| 2020 |  | $ | 553 |  |
| 2021 |  |  | 1,683 |  |
| 2022 |  |  | - |  |
| 2023 |  |  | - |  |
| After 2023 |  |  | 830,000 |  |
| Total |  | $ | 832,236 |  |

[0001437749-20-003516:notes:195]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 1.50% and the applicable margin related to LIBOR rate loans was reduced to 2.50%, in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, fell below 3.00 to 1.00 for that measurement period.

[0001437749-20-003516:notes:196]
In  May 2017, the Company amended its Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 1.25% or adjusted LIBOR rate plus a fixed applicable margin of 2.25%. Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 3.00 to 1.00 was achieved. As a result, the Company does not anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. At the time, the amended Term Loan pricing was still subject to the 0.75% LIBOR floor. In connection with this amendment and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $1,432 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $85 of transaction fees in the second quarter of 2017.

[0001437749-20-003516:notes:197]
In  December 2017, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 1.00% or adjusted LIBOR rate plus a fixed applicable margin of 2.00%. Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 2017, and will eliminate future requirements if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $2,346 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings and expensed $38 of transaction fees in the fourth quarter of 2017.

[0001437749-20-003516:notes:198]
In  June 2018, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 0.75% or adjusted LIBOR rate plus a fixed applicable margin of 1.75%. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $829 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $118 of transaction fees in the second quarter of 2018.

[0001437749-20-003516:notes:199]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as removed the LIBOR floor of 0.75% from the adjusted LIBOR rate. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally, the Company made a voluntary prepayment of $49,000 on the term loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:200]
The Term Loan does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  December 31, 2019, the Company’s net secured leverage ratio was 1.50 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-003516:notes:201]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is currently  June 12, 2023. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-20-003516:notes:202]
In  June 2018, the Company amended the ABL Facility; increasing it from $250,000 to $300,000 and extending the maturity date to  June 12, 2023. In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.375% or an adjusted LIBOR rate plus an applicable margin of 1.375%. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $755 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off $34 of capitalized debt issuance costs as a loss on extinguishment of debt in the second quarter of 2018.

[0001437749-20-003516:notes:203]
In  June 2018, the Company borrowed $50,000 under the ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off $1,298 of original issue discount and capitalized debt issuance costs during the second quarter of 2018 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. In  October 2018, the Company repaid the $50,000 outstanding ABL Facility balance with cash on hand.

[0001437749-20-003516:notes:204]
As of  December 31, 2019, there was $30,961 outstanding under the ABL Facility, leaving $268,608 of availability, net of outstanding letters of credit.

[0001437749-20-003516:notes:205]
As of  December 31, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $58,714 and $45,583, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-20-003516:notes:206]
| 13. | Stock Repurchase Programs |

[0001437749-20-003516:notes:207]
In  August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program, which the Company completed in the third quarter of 2016. In  October 2016, the Company’s Board of Directors approved a new $250,000 stock repurchase program, which expired in the fourth quarter of 2018. In  September 2018, the Company’s Board of Directors approved another stock repurchase program, which commenced in  October 2018, and under which the Company  may repurchase an additional $250,000 of its common stock over the following 24 months. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the year ended  December 31, 2019, the Company did not repurchase any shares of its common stock. During the years ended  December 31, 2018 and 2017, the Company repurchased 560,000 and 844,500 shares of its common stock, respectively, for $25,656 and $30,012, respectively, all funded with cash on hand. Since the inception of the above noted programs, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-003516:notes:208]
| 14. | Earnings Per Share |

[0001437749-20-003516:notes:209]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-20-003516:notes:210]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-20-003516:notes:211]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 252,007 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 1,253 |  |  |  | (17,970 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 253,260 |  |  | $ | 220,287 |  |  | $ | 158,717 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,926,986 |  |  |  | 61,662,031 |  |  |  | 62,040,704 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 938,460 |  |  |  | 571,194 |  |  |  | 602,168 |  |
| Diluted shares |  |  | 62,865,446 |  |  |  | 62,233,225 |  |  |  | 62,642,872 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.09 |  |  | $ | 3.57 |  |  | $ | 2.56 |  |
| Diluted |  | $ | 4.03 |  |  | $ | 3.54 |  |  | $ | 2.53 |  |

[0001437749-20-003516:notes:212]
|  | (1) | Excludes approximately 26,100 and 147,400 stock options for the years ended December 31, 2018 and 2017, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the year ended December 31, 2019. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-003516:notes:213]
| 15. | Income Taxes |

[0001437749-20-003516:notes:214]
The Company’s provision for income taxes consists of the following:

[0001437749-20-003516:notes:215]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 41,686 |  |  | $ | 32,072 |  |  | $ | 15,753 |  |
| State |  |  | 4,211 |  |  |  | 9,639 |  |  |  | 1,775 |  |
| Foreign |  |  | 2,660 |  |  |  | 4,546 |  |  |  | 4,585 |  |
|  |  |  | 48,557 |  |  |  | 46,257 |  |  |  | 22,113 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 19,393 |  |  |  | 22,225 |  |  |  | 18,213 |  |
| State |  |  | 1,390 |  |  |  | 1,910 |  |  |  | 4,139 |  |
| Foreign |  |  | (1,263 | ) |  |  | 479 |  |  |  | (2,777 | ) |
|  |  |  | 19,520 |  |  |  | 24,614 |  |  |  | 19,575 |  |
| Change in valuation allowance |  |  | (778 | ) |  |  | (1,015 | ) |  |  | 2,454 |  |
| Provision for income taxes |  | $ | 67,299 |  |  | $ | 69,856 |  |  | $ | 44,142 |  |

[0001437749-20-003516:notes:216]
The Company files U.S federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2019, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2016. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2009 through 2018 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 2013 through 2018.

[0001437749-20-003516:notes:217]
The Company is regularly under examination in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made, and could impact the Company’s financial results.

[0001437749-20-003516:notes:218]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-20-003516:notes:219]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 21,053 |  |  | $ | 16,745 |  |
| Deferred revenue |  |  | 14,697 |  |  |  | 12,418 |  |
| Inventories |  |  | 9,879 |  |  |  | 8,500 |  |
| Pension obligations |  |  | - |  |  |  | 1,062 |  |
| Stock-based compensation |  |  | 7,490 |  |  |  | 5,960 |  |
| Operating loss and credit carryforwards |  |  | 28,356 |  |  |  | 25,585 |  |
| Bad debt |  |  | 1,094 |  |  |  | 1,363 |  |
| Other |  |  | 4,275 |  |  |  | 2,516 |  |
| Valuation allowance |  |  | (5,024 | ) |  |  | (5,802 | ) |
| Total deferred tax assets |  |  | 81,820 |  |  |  | 68,347 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 142,159 |  |  |  | 108,899 |  |
| Depreciation |  |  | 27,864 |  |  |  | 25,429 |  |
| Debt refinancing costs |  |  | 4,119 |  |  |  | 4,206 |  |
| Prepaid expenses |  |  | 1,073 |  |  |  | 950 |  |
| Total deferred tax liabilities |  |  | 175,215 |  |  |  | 139,484 |  |
| Net deferred tax liabilities |  | $ | (93,395 | ) |  | $ | (71,137 | ) |

[0001437749-20-003516:notes:220]
As of  December 31, 2019 and 2018, deferred tax assets of $2,933 and $163, and deferred tax liabilities of $96,328 and $71,300, respectively, were reflected on the consolidated balance sheets.

[0001437749-20-003516:notes:221]
The Company maintains a valuation allowance against the deferred tax assets of an entity when it is uncertain the entity will generate sufficient taxable income to utilize the asset. During 2019, the valuation allowance decreased by $778 primarily due to an increase in income allowing for a utilization of tax credits, partially offset by current losses in certain foreign subsidiaries.

[0001437749-20-003516:notes:222]
At  December 31, 2019, the Company had various state research & development and state manufacturing tax credit carryforwards of approximately $8,291 and $12,747, respectively, which expire between 2020 and 2034. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-20-003516:notes:223]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-20-003516:notes:224]
|  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 5,635 |  |  | $ | 7,122 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 633 |  |  |  | - |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 495 |  |  |  | 580 |  |
| Statute of limitation expirations |  |  | (43 | ) |  |  | (1,818 | ) |
| Settlements |  |  | - |  |  |  | (249 | ) |
| Unrecognized tax benefit, end of period |  | $ | 6,720 |  |  | $ | 5,635 |  |

[0001437749-20-003516:notes:225]
The unrecognized tax benefit as of  December 31, 2019 and 2018, if recognized, would favorably impact the effective tax rate.

[0001437749-20-003516:notes:226]
As of  December 31, 2019 and 2018, total accrued interest of approximately $71 and $37, respectively, and accrued penalties of approximately $195 and $136, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-20-003516:notes:227]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending  December 31, 2020.

[0001437749-20-003516:notes:228]
On  December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act includes a mandatory one-time tax on accumulated earnings of foreign subsidiaries, and as a result, all previously unremitted earnings for which no U.S. deferred tax liability had been accrued have now been subject to U.S. tax. Notwithstanding the U.S. taxation of these amounts, the Company intends to continue to invest these earnings, as well as the capital in these subsidiaries, indefinitely outside of the U.S. and do not expect to incur any significant additional taxes related to such amounts.

[0001437749-20-003516:notes:229]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended  December 31, 2019, 2018 and 2017 are as follows:

[0001437749-20-003516:notes:230]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 4.3 |  |  |  | 4.7 |  |  |  | 4.1 |  |
| State tax rate differential |  |  | (1.0 | ) |  |  | - |  |  |  | - |  |
| Research and development credits |  |  | (0.8 | ) |  |  | (1.3 | ) |  |  | (1.4 | ) |
| State credits |  |  | (1.0 | ) |  |  | (1.0 | ) |  |  | (0.2 | ) |
| Share-based compensation (1) |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (1.4 | ) |
| Tax Act impact (2) |  |  | - |  |  |  | (0.2 | ) |  |  | (13.9 | ) |
| Other |  |  | (0.8 | ) |  |  | (0.2 | ) |  |  | (0.9 | ) |
| Effective tax rate |  |  | 21.1 | % |  |  | 22.5 | % |  |  | 21.3 | % |

[0001437749-20-003516:notes:231]
|  | (1) | With the adoption of ASU 2016-09 in 2017, excess tax benefits from equity awards are reflected within the provision for income taxes rather than within the consolidated balance sheet. |
|  | (2) | As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. This non-cash benefit resulted primarily from the Federal rate reduction from 35% to 21%. |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-20-003516:notes:232]
| 16. | Benefit Plans |

[0001437749-20-003516:notes:233]
Medical and Dental Plan

[0001437749-20-003516:notes:234]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. Certain plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $18,290, $14,660, and $14,992 for the years ended  December 31, 2019, 2018, and 2017, respectively.

[0001437749-20-003516:notes:235]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-20-003516:notes:236]
Savings Plan

[0001437749-20-003516:notes:237]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008 that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures  may be applied against plan expenses and company contributions. The Company recognized $4,791, $4,193 and $3,600 of expense related to these plans in 2019, 2018 and 2017, respectively.

[0001437749-20-003516:notes:238]
Pension Plans

[0001437749-20-003516:notes:239]
Historically, the Company maintained frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The Pension Plans were frozen effective  December 31, 2008. Effective  December 31, 2018, the Pension Plans were merged into the same plan (Pension Plan), resulting in no change to benefits for participants. The benefits under the salaried plan were based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan were based on a unit amount at the date of termination multiplied by the participant’s years of credited service.

[0001437749-20-003516:notes:240]
In 2019, the Company completed the termination of its Pension Plan.  In connection with the Company’s activities to terminate the plan, lump sum distributions were made in the fourth quarter of 2019 to individuals who elected lump sum distributions, including rolling over their accounts to the Company’s 401(k) savings plan. Also in the fourth quarter of 2019, annuity contracts were purchased to settle obligations for the remaining participants. Upon settlement of the pension liability, the Company reclassified related unrecognized pension losses recorded in AOCL to the consolidated statements of comprehensive income. As a result, the Company recorded pre-tax settlement charges of $10,920 in the fourth quarter of 2019.

[0001437749-20-003516:notes:241]
The Company’s historical funding policy for the Pension Plans was to contribute amounts at least equal to the minimum annual amount required by applicable regulations. In the year ended  December 31, 2018, the Company made a voluntary pension prepayment of $9,400. In the year ended  December 31, 2019, the Company made required contributions of $1,017 in connection with the plan termination. No additional contributions will be required in future years as the pension plan termination was finalized in 2019.

[0001437749-20-003516:notes:242]
The following table provides a reconciliation of benefit obligations, plan assets and funded status of the Pension Plan based on a  December 31 measurement date:

[0001437749-20-003516:notes:243]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Accumulated benefit obligation at end of period |  | $ | - |  |  | $ | 65,978 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 65,978 |  |  | $ | 72,631 |  |
| Interest cost |  |  | 2,401 |  |  |  | 2,575 |  |
| Net actuarial (gain) loss |  |  | 3,452 |  |  |  | (6,820 | ) |
| Benefits paid |  |  | (31,321 | ) |  |  | (2,408 | ) |
| Annuities purchased |  |  | (40,510 | ) |  |  | - |  |
| Projected benefit obligation at end of period |  | $ | - |  |  | $ | 65,978 |  |
| Change in plan assets |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 61,870 |  |  | $ | 58,014 |  |
| Actual return on plan assets |  |  | 8,944 |  |  |  | (3,507 | ) |
| Company contributions |  |  | 1,017 |  |  |  | 9,771 |  |
| Benefits paid |  |  | (31,321 | ) |  |  | (2,408 | ) |
| Annuities purchased |  |  | (40,510 | ) |  |  | - |  |
| Fair value of plan assets at end of period |  | $ | - |  |  | $ | 61,870 |  |
| Funded status: accrued pension liability included in other long-term liabilities |  | $ | - |  |  | $ | (4,108 | ) |
| Amounts recognized in accumulated other comprehensive loss |  |  |  |  |  |  |  |  |
| Net actuarial loss, net of tax |  | $ | - |  |  | $ | (10,541 | ) |

[0001437749-20-003516:notes:244]
The actuarial loss for the Pension Plan that was amortized from AOCL into net periodic pension cost during 2019 prior to the pension plan termination was $843.

[0001437749-20-003516:notes:245]
The actuarial assumption used in the determination of the benefit obligation of the above data is:

[0001437749-20-003516:notes:246]
|  |  | 2019 |  |  | 2018 |  |
| Weighted average discount rate |  |  | N/A |  |  |  | 4.24% |  |

[0001437749-20-003516:notes:247]
The following table sets forth the components of net periodic pension cost (benefit) for the years ended  December 31, 2019, 2018 and 2017:

[0001437749-20-003516:notes:248]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Interest cost |  | $ | 2,401 |  |  | $ | 2,575 |  |  | $ | 2,688 |  |
| Expected return on plan assets |  |  | (3,500 | ) |  |  | (3,525 | ) |  |  | (3,011 | ) |
| Amortization of net loss |  |  | 843 |  |  |  | 802 |  |  |  | 883 |  |
| Loss on pension settlement |  |  | 10,920 |  |  |  | - |  |  |  | - |  |
| Net periodic pension cost (benefit) |  | $ | 10,664 |  |  | $ | (148 | ) |  | $ | 560 |  |

[0001437749-20-003516:notes:249]
Weighted-average assumptions used to determine net periodic pension cost (benefit) are as follows:

[0001437749-20-003516:notes:250]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Discount Rate |  |  | 4.24% |  |  |  | 3.60% |  |  |  | 4.14% |  |
| Expected long-term rate of return on plan assets |  |  | 6.60% |  |  |  | 6.19% |  |  |  | 6.58% |  |
| Rate of compensation increase (1) |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |

[0001437749-20-003516:notes:251]
| (1) No compensation increase was assumed as the Pension Plan was frozen effective December 31, 2008. |

[0001437749-20-003516:notes:252]
To determine the long-term rate of return assumption for the plans’ assets, the Company studied historical markets and preserved the long-term historical relationship between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluated current market factors such as inflation and interest rates before it determined long-term capital market assumptions and reviewed peer data and historical returns to check for reasonableness and appropriateness.

[0001437749-20-003516:notes:253]
The fair value of the qualified pension plan assets was $0 at  December 31, 2019 and $61,870 at  December 31, 2018. The Pension Plan’s weighted-average asset allocation at  December 31, 2018, by asset category, is as follows:

[0001437749-20-003516:notes:254]
|  |  | Target Allocation |  |  | December 31, 2018 |  |
| Asset Category |  | Minimum |  |  | Maximum |  |  | Dollars |  |  | % |  |
| Fixed income |  |  | 15.0 | % |  |  | 25.0 | % |  | $ | 12,257 |  |  |  | 20 | % |
| Domestic equity |  |  | 36.5 | % |  |  | 61.5 | % |  |  | 30,731 |  |  |  | 50 | % |
| International equity |  |  | 17.0 | % |  |  | 25.0 | % |  |  | 12,380 |  |  |  | 20 | % |
| Real estate |  |  | 7.0 | % |  |  | 15.0 | % |  |  | 6,502 |  |  |  | 10 | % |
| Total |  |  |  |  |  |  |  |  |  |  | 61,870 |  |  |  | 100 | % |

[0001437749-20-003516:notes:255]
The fair values of the Pension Plans’ assets at  December 31, 2018 were as follows:

[0001437749-20-003516:notes:256]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 51,736 |  |  | $ | 51,736 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 10,134 |  |  |  | – |  |  |  | – |  |  |  | 10,134 |  |
| Total |  | $ | 61,870 |  |  | $ | 51,736 |  |  | $ | – |  |  | $ | 10,134 |  |

[0001437749-20-003516:notes:257]
A reconciliation of beginning and ending balances for Level 3 assets for the year ended  December 31, 2018 is as follows:

[0001437749-20-003516:notes:258]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |
| Balance at beginning of period |  | $ | 9,700 |  |
| Purchases |  |  | 3,805 |  |
| Redemptions |  |  | (3,795 | ) |
| Realized gains |  |  | 424 |  |
| Balance at end of period |  | $ | 10,134 |  |

[0001437749-20-003516:notes:259]
Mutual Funds – This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plans’ mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 1 of the fair value hierarchy.

[0001437749-20-003516:notes:260]
Other Investments – This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment, and therefore is classified within Level 3 of the fair value hierarchy.

[0001437749-20-003516:notes:261]
The Company’s historical target allocation for equity securities and real estate was generally between 75% to 85%, with the remainder allocated primarily to fixed income (bonds). The Company regularly reviewed its actual asset allocation and periodically rebalanced its investments to the targeted allocation when considered appropriate.

[0001437749-20-003516:notes:262]
Certain of the Company’s foreign subsidiaries participate in local statutory defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in other long-term liabilities in the Company’s consolidated balance sheets and are not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-20-003516:notes:263]
| 17. | Share Plans |

[0001437749-20-003516:notes:264]
The Company adopted an equity incentive plan (Plan) on  February 10, 2010 in connection with its initial public offering. The Plan, as amended, allows for granting of up to 9.1 million share-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the Plan, net of estimated forfeitures, was $15,738, $14,563 and $10,205 for the years ended  December 31, 2019, 2018 and 2017, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:265]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (2019 Plan). The 2019 Plan allows for granting of up to 2.7 million share-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $956 for the year ended  December 31, 2019, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:266]
Stock Options - Stock options granted in 2019 have an exercise price of $52.07 per share; stock options granted in 2018 have an exercise price between $43.88 per share and $45.29 per share; and stock options granted in 2017 have an exercise price between $40.12 per share and $48.98 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-20-003516:notes:267]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 32,211, 63,817 and 9,033 in 2019, 2018 and 2017, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-20-003516:notes:268]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds from the cashless for cash exercise of stock options were $9,395, $5,614 and $6,951 in 2019, 2018 and 2017, respectively, and are reflected as a financing activity in the consolidated statement of cash flows.

[0001437749-20-003516:notes:269]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $3,360, $3,846 and $4,301 in 2019, 2018 and 2017, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-20-003516:notes:270]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history.

[0001437749-20-003516:notes:271]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2019, 2018 and 2017 are as follows:

[0001437749-20-003516:notes:272]
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Weighted average grant date fair value |  | $ | 19.33 |  |  | $ | 17.86 |  |  | $ | 16.84 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 33 | % |  |  | 37 | % |  |  | 40 | % |
| Risk free interest rate |  |  | 2.52 | % |  |  | 2.60 | % |  |  | 1.92 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-20-003516:notes:273]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2019, 2018 and 2017 is as follows:

[0001437749-20-003516:notes:274]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2016 |  |  | 1,482,964 |  |  | $ | 27.49 |  |  |  | 7.5 |  |  | $ | 23,840 |  |
| Granted |  |  | 346,421 |  |  |  | 40.13 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (287,375 | ) |  |  | 10.58 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (69,880 | ) |  |  | 41.12 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2017 |  |  | 1,472,130 |  |  |  | 33.11 |  |  |  | 7.3 |  |  | $ | 25,281 |  |
| Granted |  |  | 366,231 |  |  |  | 43.88 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (267,909 | ) |  |  | 19.90 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (49,285 | ) |  |  | 43.34 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2018 |  |  | 1,521,167 |  |  |  | 37.70 |  |  |  | 7.0 |  |  | $ | 19,212 |  |
| Granted |  |  | 369,779 |  |  |  | 52.07 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (263,250 | ) |  |  | 30.75 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (35,010 | ) |  |  | 43.79 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2019 |  |  | 1,592,686 |  |  |  | 42.04 |  |  |  | 6.9 |  |  | $ | 93,242 |  |
| Exercisable as of December 31, 2019 |  |  | 726,817 |  |  |  | 37.78 |  |  |  | 5.3 |  |  | $ | 45,649 |  |

[0001437749-20-003516:notes:275]
As of  December 31, 2019, there was $10,649 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.5 years. Total share-based compensation cost related to the stock options for 2019, 2018 and 2017 was $5,597, $4,998 and $4,503, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:276]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, which were awarded in the years 2014 through 2019. The number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2017 awards covers the years 2017 through 2019, the performance period for the 2018 awards covers the years 2018 through 2020, and the performance period for the 2019 awards covers the years 2019 through 2021. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-20-003516:notes:277]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 55,953, 38,186 and 39,500 in 2019, 2018 and 2017, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $3,078, $1,812 and $1,591 in 2019, 2018 and 2017, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-20-003516:notes:278]
A summary of the Company's restricted stock activity for the years ended  December 31, 2019, 2018 and 2017 is as follows:

[0001437749-20-003516:notes:279]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2016 |  |  | 361,403 |  |  | $ | 38.18 |  |
| Granted |  |  | 211,769 |  |  |  | 39.91 |  |
| Vested |  |  | (133,796 | ) |  |  | 40.60 |  |
| Forfeited |  |  | (47,100 | ) |  |  | 42.48 |  |
| Non-vested as of December 31, 2017 |  |  | 392,276 |  |  |  | 37.77 |  |
| Granted |  |  | 208,803 |  |  |  | 44.49 |  |
| Vested |  |  | (128,433 | ) |  |  | 39.03 |  |
| Forfeited |  |  | (46,650 | ) |  |  | 39.43 |  |
| Non-vested as of December 31, 2018 |  |  | 425,996 |  |  |  | 40.50 |  |
| Granted |  |  | 265,255 |  |  |  | 62.38 |  |
| Vested |  |  | (184,628 | ) |  |  | 38.78 |  |
| Forfeited |  |  | (14,986 | ) |  |  | 44.23 |  |
| Non-vested as of December 31, 2019 |  |  | 491,637 |  |  |  | 52.84 |  |

[0001437749-20-003516:notes:280]
As of  December 31, 2019, there was $16,165 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 1.9 years. Total share-based compensation cost related to the restricted stock for 2019, 2018 and 2017, inclusive of performance shares, was $11,097, $9,565 and $5,702, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-20-003516:notes:281]
During 2019, 2018 and 2017, 22,544, 33,419 and 34,095 shares of stock, respectively, were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, of which 22,544, 33,419 and 22,762 shares, respectively, were fully vested at time of grant. Non-employee directors can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company or a triggering event occurs. 16,604, 22,675, and 11,333 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board of Directors for the years 2019, 2018, and 2017, respectively. Total share-based compensation cost for these share grants in 2019, 2018 and 2017 was $1,391, $1,718 and $1,133, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-003516:notes:282]
| 18. | Commitments and Contingencies |

[0001437749-20-003516:notes:283]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  December 31, 2019 and 2018 was approximately $49,600 and $47,200, respectively.

[0001437749-20-003516:notes:284]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-20-003516:notes:285]
| 19. | Quarterly Financial Information (Unaudited) |

[0001437749-20-003516:notes:286]
|  |  | Quarters Ended 2019 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 470,353 |  |  | $ | 541,916 |  |  | $ | 601,135 |  |  | $ | 590,932 |  |
| Gross profit |  |  | 162,175 |  |  |  | 195,838 |  |  |  | 217,517 |  |  |  | 222,222 |  |
| Operating income |  |  | 71,173 |  |  |  | 90,926 |  |  |  | 105,556 |  |  |  | 104,508 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 44,861 |  |  |  | 61,958 |  |  |  | 75,574 |  |  |  | 69,614 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.77 |  |  | $ | 0.99 |  |  | $ | 1.20 |  |  | $ | 1.14 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.76 |  |  | $ | 0.98 |  |  | $ | 1.18 |  |  | $ | 1.12 |  |

[0001437749-20-003516:notes:287]
|  |  | Quarters Ended 2018 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 400,091 |  |  | $ | 497,581 |  |  | $ | 562,388 |  |  | $ | 563,404 |  |
| Gross profit |  |  | 141,927 |  |  |  | 178,473 |  |  |  | 200,334 |  |  |  | 204,306 |  |
| Operating income |  |  | 56,347 |  |  |  | 85,467 |  |  |  | 106,519 |  |  |  | 108,848 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 33,645 |  |  |  | 53,261 |  |  |  | 75,776 |  |  |  | 75,575 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.42 |  |  | $ | 0.83 |  |  | $ | 1.12 |  |  | $ | 1.21 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.42 |  |  | $ | 0.82 |  |  | $ | 1.11 |  |  | $ | 1.20 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-20-003516:notes:288]
| 20. | Valuation and Qualifying Accounts |

[0001437749-20-003516:notes:289]
For the years ended  December 31, 2019, 2018 and 2017:

[0001437749-20-003516:notes:290]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4,873 |  |  | $ | 3,086 |  |  | $ | (1,033 | ) |  | $ | 42 |  |  | $ | 6,968 |  |
| Reserves for inventory |  |  | 23,140 |  |  |  | 4,821 |  |  |  | (3,867 | ) |  |  | 199 |  |  | $ | 24,293 |  |
| Valuation of deferred tax assets |  |  | 5,802 |  |  |  | - |  |  |  | - |  |  |  | (778 | ) |  | $ | 5,024 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4,805 |  |  | $ | 1,941 |  |  | $ | (2,123 | ) |  | $ | 250 |  |  | $ | 4,873 |  |
| Reserves for inventory |  |  | 15,987 |  |  |  | 10,004 |  |  |  | (3,720 | ) |  |  | 869 |  |  |  | 23,140 |  |
| Valuation of deferred tax assets |  |  | 6,817 |  |  |  | 478 |  |  |  | - |  |  |  | (1,493 | ) |  |  | 5,802 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 5,642 |  |  | $ | 346 |  |  | $ | (1,842 | ) |  | $ | 659 |  |  | $ | 4,805 |  |
| Reserves for inventory |  |  | 13,031 |  |  |  | 6,164 |  |  |  | (4,036 | ) |  |  | 828 |  |  |  | 15,987 |  |
| Valuation of deferred tax assets |  |  | 4,362 |  |  |  | 2,455 |  |  |  | - |  |  |  | - |  |  |  | 6,817 |  |

[0001437749-20-003516:notes:291]
|  | (1) | Deductions from the allowance for doubtful accounts equal accounts receivable written off against the allowance, less recoveries. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of. |


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-003516:notes:292]
| 21. | Subsequent Events |

[0001437749-20-003516:notes:293]
The Company performed an evaluation of subsequent events through the date these financial statements were issued and no such events were identified.
