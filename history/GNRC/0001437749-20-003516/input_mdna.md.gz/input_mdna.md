# GNRC MD&A — 0001437749-20-003516


## mdna

[0001437749-20-003516:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-20-003516:mdna:2]
Overview

[0001437749-20-003516:mdna:3]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Power generation is a key focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost effective natural gas fueled generators to expand into applications beyond standby power. We have also been focused on “connecting” the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product lifecycle. Other power products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use. During 2019, we began providing energy storage systems as a clean energy solution for residential use that capture and store electricity from solar panels or other power sources and help reduce home energy costs while also protecting homes from brief power outages.

[0001437749-20-003516:mdna:4]
Business Drivers and Operational Factors

[0001437749-20-003516:mdna:5]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-20-003516:mdna:6]
Business Drivers and Trends

[0001437749-20-003516:mdna:7]
Our performance is affected by the demand for reliable power generation products, energy storage systems, and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-20-003516:mdna:8]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.75% of the addressable market of homes in the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to a variety of factors including the impending rollout of next-generation 5G wireless networks enabling new technologies and the growing importance for critical communications and other uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-20-003516:mdna:9]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both 2017 and 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-20-003516:mdna:10]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage and monitoring markets with the acquisitions of Pika Energy and Neurio Technologies. We believe the electric power landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power utility quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to manage, monitor and store this power – potentially developing into a significant market opportunity annually. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets which we believe will position Generac as a key participant going forward. Although very different from the emergency backup power space we serve today, we believe this market will develop similarly as the home standby generator market has over the past two decades. Our efforts to develop a cost-effective global supply chain, omni-channel distribution, targeted consumer-based marketing content, and proprietary in-home sales tools have played a critical role in creating the market for home standby generators, and we intend to leverage our expertise and capabilities in these areas as we work to grow the energy storage and monitoring markets.

[0001437749-20-003516:mdna:11]
California market for backup power increasing.    During 2019, the largest utility in the state of California along with other utilities announced their intention and ultimately executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were pro-active measures to prevent their equipment from potentially causing catastrophic wildfires during the dry and windy season of the year. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, have resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators stand at approximately 1%. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity are some of the highest in the U.S., and the regulatory environment is mandating renewable energy on new construction starting in 2020.

[0001437749-20-003516:mdna:12]
Impact of residential investment cycle.    The market for residential generators and energy storage systems is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market highlighted by residential housing starts can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns. Finally, the existence of renewable energy mandates and investment tax credits and other subsidies can also have an impact on the demand for energy storage systems.

[0001437749-20-003516:mdna:13]
Impact of business capital investment and other economic cycles.    The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-20-003516:mdna:14]
Factors Affecting Results of Operations

[0001437749-20-003516:mdna:15]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-20-003516:mdna:16]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-20-003516:mdna:17]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-20-003516:mdna:18]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 20% to 24% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 26% to 28% in the third quarter and 27% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-20-003516:mdna:19]
Factors influencing interest expense and cash interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease. Interest expense increased slightly during 2019 compared to 2018, primarily due to increased borrowings by our foreign subsidiaries. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-20-003516:mdna:20]
Factors influencing provision for income taxes and cash income taxes paid.    On December 22, 2017, the U.S. government enacted the Tax Act, which significantly changed how the U.S. taxes corporations. During 2018, the U.S. Treasury Department (Treasury) issued several new regulations and other guidance which we have incorporated into our final tax calculations. At December 31, 2019, we consider the tax expense recorded for the impact of Tax Reform to be complete. It is possible additional regulations or guidance could be issued by Treasury or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-20-003516:mdna:21]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. This non-cash benefit resulted primarily from the Federal rate reduction from 35% to 21%.

[0001437749-20-003516:mdna:22]
As of December 31, 2019, we had approximately $225 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $57 million through 2021, assuming continued profitability of our U.S. business and a combined federal and state tax rate of 25.3%. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million in 2020 and $102 million in 2021, which generates annual cash tax savings of $31 million in 2020 and $26 million in 2021. Based on current business plans, we believe that our cash tax obligations through 2021 will be significantly reduced by these tax attributes, after which our cash tax obligation will increase. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to our consolidated financial statements.

[0001437749-20-003516:mdna:23]
Components of Net Sales and Expenses

[0001437749-20-003516:mdna:24]
Net Sales

[0001437749-20-003516:mdna:25]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, light commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, remote monitoring, installation and maintenance services. However, these services accounted for less than three percent of our net sales for the year ended December 31, 2019. Refer to Note 2, “Significant Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-20-003516:mdna:26]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 5% of our sales, and our top ten customers representing less than 19% of our net sales for the year ended December 31, 2019.

[0001437749-20-003516:mdna:27]
Costs of Goods Sold

[0001437749-20-003516:mdna:28]
The principal elements of costs of goods sold are component parts, raw materials, factory overhead and labor. Component parts and raw materials comprised approximately 75% of costs of goods sold for the year ended December 31, 2019. The principal component parts are engines, alternators, and batteries. We design and manufacture air-cooled engines for certain of our generators up to 22kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the OEM of those engines. We design and manufacture many of the alternators for our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-20-003516:mdna:29]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-20-003516:mdna:30]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-20-003516:mdna:31]
Operating Expenses

[0001437749-20-003516:mdna:32]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs, taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-20-003516:mdna:33]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard assurance warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Standard warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising, promotional expenses and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, opportunities to create market awareness for our products, and general brand awareness marketing efforts.

[0001437749-20-003516:mdna:34]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. They also support our connectivity, remote monitoring, and energy monitoring initiatives. We operate engineering facilities with extensive capabilities at many locations globally and employ over 500 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-20-003516:mdna:35]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-20-003516:mdna:36]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-20-003516:mdna:37]
Other (Expense) Income

[0001437749-20-003516:mdna:38]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and cash flows related to interest rate swap agreements. Other (expense) income also includes other financial items such as losses on extinguishment of debt, gains (losses) on changes in contractual interest rate, loss on pension settlement, and investment income earned on our cash and cash equivalents.

[0001437749-20-003516:mdna:39]
Results of Operations

[0001437749-20-003516:mdna:40]
Year ended December 31, 2019 compared to year ended December 31, 2018

[0001437749-20-003516:mdna:41]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-20-003516:mdna:42]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |  | $ | 180,872 |  |  |  | 8.9 | % |
| Cost of goods sold |  |  | 1,406,584 |  |  |  | 1,298,424 |  |  |  | 108,160 |  |  |  | 8.3 | % |
| Gross profit |  |  | 797,752 |  |  |  | 725,040 |  |  |  | 72,712 |  |  |  | 10.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 217,683 |  |  |  | 191,887 |  |  |  | 25,796 |  |  |  | 13.4 | % |
| Research and development |  |  | 68,394 |  |  |  | 50,019 |  |  |  | 18,375 |  |  |  | 36.7 | % |
| General and administrative |  |  | 110,868 |  |  |  | 103,841 |  |  |  | 7,027 |  |  |  | 6.8 | % |
| Amortization of intangible assets |  |  | 28,644 |  |  |  | 22,112 |  |  |  | 6,532 |  |  |  | 29.5 | % |
| Total operating expenses |  |  | 425,589 |  |  |  | 367,859 |  |  |  | 57,730 |  |  |  | 15.7 | % |
| Income from operations |  |  | 372,163 |  |  |  | 357,181 |  |  |  | 14,982 |  |  |  | 4.2 | % |
| Total other expense, net |  |  | (52,556 | ) |  |  | (46,105 | ) |  |  | (6,451 | ) |  |  | 14.0 | % |
| Income before provision for income taxes |  |  | 319,607 |  |  |  | 311,076 |  |  |  | 8,531 |  |  |  | 2.7 | % |
| Provision for income taxes |  |  | 67,299 |  |  |  | 69,856 |  |  |  | (2,557 | ) |  |  | -3.7 | % |
| Net income |  |  | 252,308 |  |  |  | 241,220 |  |  |  | 11,088 |  |  |  | 4.6 | % |
| Net income attributable to noncontrolling interests |  |  | 301 |  |  |  | 2,963 |  |  |  | (2,662 | ) |  |  | -89.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 252,007 |  |  | $ | 238,257 |  |  | $ | 13,750 |  |  |  | 5.8 | % |

[0001437749-20-003516:mdna:43]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-20-003516:mdna:44]
|  |  | Net Sales by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,742,898 |  |  | $ | 1,566,520 |  |  | $ | 176,378 |  |  |  | 11.3 | % |
| International |  |  | 461,438 |  |  |  | 456,944 |  |  |  | 4,494 |  |  |  | 1.0 | % |
| Total net sales |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |  | $ | 180,872 |  |  |  | 8.9 | % |

[0001437749-20-003516:mdna:45]
|  |  | Adjusted EBITDA by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 428,667 |  |  | $ | 388,495 |  |  | $ | 40,172 |  |  |  | 10.3 | % |
| International |  |  | 25,448 |  |  |  | 36,057 |  |  |  | (10,609 | ) |  |  | -29.4 | % |
| Total Adjusted EBITDA |  | $ | 454,115 |  |  | $ | 424,552 |  |  | $ | 29,563 |  |  |  | 7.0 | % |

[0001437749-20-003516:mdna:46]
The following table sets forth our product class information for the periods indicated:

[0001437749-20-003516:mdna:47]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,143,723 |  |  | $ | 1,042,739 |  |  | $ | 100,984 |  |  |  | 9.7 | % |
| Commercial & industrial products |  |  | 871,595 |  |  |  | 820,270 |  |  |  | 51,325 |  |  |  | 6.3 | % |
| Other |  |  | 189,018 |  |  |  | 160,455 |  |  |  | 28,563 |  |  |  | 17.8 | % |
| Total net sales |  | $ | 2,204,336 |  |  | $ | 2,023,464 |  |  | $ | 180,872 |  |  |  | 8.9 | % |

[0001437749-20-003516:mdna:48]
Net sales.    The increase in Domestic segment sales for the year ended December 31, 2019 was primarily due to strong shipments of home standby generators due to increased trends of power outage activity across the U.S. and Canada, inclusive of public utility power shut-offs in California. In addition, C&I stationary generator shipments were also strong, particularly for natural gas and telecom applications. The Pika and Neurio acquisitions provided a modest contribution of sales in 2019 given their start-up nature. The overall Domestic segment sales growth was partially offset by lower shipments of portable generators and C&I mobile products.

[0001437749-20-003516:mdna:49]
The slight increase in International segment sales for the year ended December 31, 2019 was primarily due to contributions from the Selmec and Captiva acquisitions. International segment sales in 2019 were impacted by the unfavorable results of foreign currency and geopolitical headwinds that caused economic softness in certain key regions of the world in which we operate.

[0001437749-20-003516:mdna:50]
Total contribution from non-annualized recent acquisitions for the year ended December 31, 2019 was $36.1 million.

[0001437749-20-003516:mdna:51]
Gross profit.    Gross profit margin for the year ended December 31, 2019 was 36.2% compared to 35.8% for the year ended December 31, 2018. The increase reflected a favorable sales mix towards higher margin home standby generators and price increases implemented since the prior period. These items were partially offset by the impact of recent acquisitions and the realization of higher input costs, including regulatory tariffs, logistics costs, and labor rates.

[0001437749-20-003516:mdna:52]
Operating expenses.    The increase in operating expenses was primarily driven by incremental variable operating expense on the strong sales growth, recurring operating expenses from recent acquisitions, an increase in employee headcount related to strategic initiatives, higher marketing and promotional spend, and higher intangible amortization expenses.

[0001437749-20-003516:mdna:53]
Other expense.   The increase in other expense, net was primarily due to a $10.9 million pre-tax settlement charge related to the termination of the Company’s domestic pension plan in the fourth quarter of 2019, partially off-set by more favorable foreign currency adjustments compared to the prior year.

[0001437749-20-003516:mdna:54]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2019 and 2018 were 21.1% and 22.5%, respectively. The decrease in the effective tax rate is primarily due to a reduction in the U.S. state income tax expense and lower foreign earnings, which are subject to higher jurisdictional tax rates.

[0001437749-20-003516:mdna:55]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above.

[0001437749-20-003516:mdna:56]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2019 were 24.6% of net sales as compared to 24.8% of net sales for the year ended December 31, 2018. Adjusted EBITDA margin in the current year benefited from favorable sales mix, pricing initiatives, and fixed operating cost leverage on the higher sales volumes. These favorable impacts were more than offset by higher input costs, including regulatory tariffs, increased employee headcount, higher marketing and promotional spend, and recurring operating expenses from recent acquisitions.

[0001437749-20-003516:mdna:57]
Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2019 were 5.5% of net sales as compared to 7.9% of net sales for the year ended December 31, 2018. The decrease in Adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable sales mix, higher input costs, and incremental operating expense investments.

[0001437749-20-003516:mdna:58]
Adjusted net income.    Adjusted Net Income of $317.8 million for the year ended December 31, 2019 increased 8.8% from $292.2 million for the year ended December 31, 2018, due to the factors outlined above.

[0001437749-20-003516:mdna:59]
In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business should have been included in the International reportable segment beginning in 2018. Previously, this was reported in the Domestic segment, in amounts that were not material. Refer to Note 7, “Segment Reporting,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information regarding this correction.

[0001437749-20-003516:mdna:60]
Year ended December 31, 2018 compared to year ended December 31, 2017

[0001437749-20-003516:mdna:61]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-20-003516:mdna:62]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  | $ | 344,091 |  |  |  | 20.5 | % |
| Cost of goods sold |  |  | 1,298,424 |  |  |  | 1,094,587 |  |  |  | 203,837 |  |  |  | 18.6 | % |
| Gross profit |  |  | 725,040 |  |  |  | 584,786 |  |  |  | 140,254 |  |  |  | 24.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 191,887 |  |  |  | 174,841 |  |  |  | 17,046 |  |  |  | 9.7 | % |
| Research and development |  |  | 50,019 |  |  |  | 42,869 |  |  |  | 7,150 |  |  |  | 16.7 | % |
| General and administrative |  |  | 103,841 |  |  |  | 87,581 |  |  |  | 16,260 |  |  |  | 18.6 | % |
| Amortization of intangible assets |  |  | 22,112 |  |  |  | 28,861 |  |  |  | (6,749 | ) |  |  | -23.4 | % |
| Total operating expenses |  |  | 367,859 |  |  |  | 334,152 |  |  |  | 33,707 |  |  |  | 10.1 | % |
| Income from operations |  |  | 357,181 |  |  |  | 250,634 |  |  |  | 106,547 |  |  |  | 42.5 | % |
| Total other expense, net |  |  | (46,105 | ) |  |  | (46,935 | ) |  |  | 830 |  |  |  | -1.8 | % |
| Income before provision for income taxes |  |  | 311,076 |  |  |  | 203,699 |  |  |  | 107,377 |  |  |  | 52.7 | % |
| Provision for income taxes |  |  | 69,856 |  |  |  | 44,142 |  |  |  | 25,714 |  |  |  | 58.3 | % |
| Net income |  |  | 241,220 |  |  |  | 159,557 |  |  |  | 81,663 |  |  |  | 51.2 | % |
| Net income attributable to noncontrolling interests |  |  | 2,963 |  |  |  | 1,749 |  |  |  | 1,214 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 238,257 |  |  | $ | 157,808 |  |  | $ | 80,449 |  |  |  | 51.0 | % |

[0001437749-20-003516:mdna:63]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-20-003516:mdna:64]
|  |  | Net Sales by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,566,520 |  |  | $ | 1,271,678 |  |  | $ | 294,842 |  |  |  | 23.2 | % |
| International |  |  | 456,944 |  |  |  | 407,695 |  |  |  | 49,249 |  |  |  | 12.1 | % |
| Total net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  | $ | 344,091 |  |  |  | 20.5 | % |

[0001437749-20-003516:mdna:65]
|  |  | Adjusted EBITDA by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 388,495 |  |  | $ | 282,450 |  |  | $ | 106,045 |  |  |  | 37.5 | % |
| International |  |  | 36,057 |  |  |  | 34,850 |  |  |  | 1,207 |  |  |  | 3.5 | % |
| Total Adjusted EBITDA |  | $ | 424,552 |  |  | $ | 317,300 |  |  | $ | 107,252 |  |  |  | 33.8 | % |

[0001437749-20-003516:mdna:66]
The following table sets forth our product class information for the periods indicated:

[0001437749-20-003516:mdna:67]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,042,739 |  |  | $ | 870,491 |  |  | $ | 172,248 |  |  |  | 19.8 | % |
| Commercial & industrial products |  |  | 820,270 |  |  |  | 684,352 |  |  |  | 135,918 |  |  |  | 19.9 | % |
| Other |  |  | 160,455 |  |  |  | 124,530 |  |  |  | 35,925 |  |  |  | 28.8 | % |
| Total net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  | $ | 344,091 |  |  |  | 20.5 | % |

[0001437749-20-003516:mdna:68]
Net sales. The increase in Domestic sales for the year ended December 31, 2018 was primarily due to strong broad-based growth in shipments of home standby generators, portable generators, outdoor power equipment and service parts. Shipments of residential products were particularly strong with demand climbing from the elevated outage environment which continued to drive awareness around the home standby category and the need for homeowners to have back-up power. Sales of our C&I mobile and stationary products were also strong during the year with rental, telecom, and healthcare market verticals experiencing growth.

[0001437749-20-003516:mdna:69]
The increase in International sales for the year ended December 31, 2018 was primarily due to the $30.7 million contribution from the Selmec acquisition, and broad-based core growth from the Pramac, Ottomotores and Motortech businesses as we continue to drive market penetration across the globe.

[0001437749-20-003516:mdna:70]
Gross profit. Gross profit margin for the year ended December 31, 2018 was 35.8% compared to 34.8% for the year ended December 31, 2017. The increase reflected a favorable mix of home standby generators, improved leverage of fixed manufacturing costs on the increase in sales, favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-20-003516:mdna:71]
Operating expenses. The increase in operating expenses was primarily driven by an increase in employee and incentive compensation costs, higher selling-related variable operating expenses given the higher sales volumes, and the recurring operating expenses from the Selmec acquisition. These items were partially offset by lower promotion, marketing and intangible amortization expenses.

[0001437749-20-003516:mdna:72]
Other expense. The decrease in other expense, net was primarily due to lower interest expense and higher investment income, partially offset by the $1.3 million loss on extinguishment of debt resulting from a $50.0 million voluntary prepayment of Term Loan debt.

[0001437749-20-003516:mdna:73]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2018 and 2017 were 22.5% and 21.3%, respectively. The reduction of the U.S. federal statutory tax rate from 35% to 21% as a result of the Tax Act was more than offset by the 2017 one-time, non-cash $28.4 million benefit from revaluing our net deferred tax liabilities in accordance with the Tax Act.

[0001437749-20-003516:mdna:74]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-20-003516:mdna:75]
Adjusted EBITDA. Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2018 were 24.8% of net sales as compared to 22.2% of net sales for the year ended December 31, 2017. Adjusted EBITDA margin in 2018 benefitted from improved operating leverage, favorable sales mix from higher shipments of home standby generators, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs and general inflationary pressures.

[0001437749-20-003516:mdna:76]
Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2018 were 7.9% of net sales as compared to 8.5% of net sales for the year ended December 31, 2017. The slight decrease in EBITDA margin is due to an unfavorable sales mix as 2017 included higher shipments of portable generators following large-scale outages from Hurricane Maria. This unfavorable sales mix was partially offset by increased leverage of fixed operating costs in 2018.

[0001437749-20-003516:mdna:77]
Adjusted net income. Adjusted Net Income of $292.2 million for the year ended December 31, 2018 increased 37.9% from $211.9 million for the year ended December 31, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-20-003516:mdna:78]
Liquidity and Financial Position

[0001437749-20-003516:mdna:79]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-20-003516:mdna:80]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan currently matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of December 31, 2019, our secured leverage ratio was 1.50 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-003516:mdna:81]
Our credit agreements also provide for the $300.0 million ABL Facility, which matures on June 12, 2023. As of December 31, 2019, there were $31.0 million of borrowings outstanding and $268.6 million of availability under the ABL Facility, net of outstanding letters of credit. We were in compliance with all covenants of the ABL Facility as of December 31, 2019.

[0001437749-20-003516:mdna:82]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the year ended December 31, 2019, no repurchases were made. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-20-003516:mdna:83]
Long-term Liquidity

[0001437749-20-003516:mdna:84]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-20-003516:mdna:85]
Cash Flow

[0001437749-20-003516:mdna:86]
Year ended December 31, 2019 compared to year ended December 31, 2018

[0001437749-20-003516:mdna:87]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-20-003516:mdna:88]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 308,887 |  |  | $ | 247,227 |  |  | $ | 61,660 |  |  |  | 24.9 | % |
| Net cash used in investing activities |  |  | (170,078 | ) |  |  | (108,894 | ) |  |  | (61,184 | ) |  |  | 56.2 | % |
| Net cash used in financing activities |  |  | (41,918 | ) |  |  | (52,034 | ) |  |  | 10,116 |  |  |  | -19.4 | % |

[0001437749-20-003516:mdna:89]
The increase in net cash provided by operating activities was primarily driven by the monetization of previous working capital investments and an increase in operating earnings compared to prior year.

[0001437749-20-003516:mdna:90]
Net cash used in investing activities for the year ended December 31, 2019 primarily represented cash payments of $112.0 million related to the acquisition of businesses and $60.8 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2018 primarily consisted of cash payments of $65.4 million related to the acquisition of businesses and $47.6 million for the purchase of property and equipment.

[0001437749-20-003516:mdna:91]
Net cash used in financing activities for the year ended December 31, 2019 primarily consisted of $112.6 million of debt repayments ($53.1 million of long-term borrowings and $59.5 million of short-term borrowings), $6.4 million of taxes paid related to equity awards, and $5.5 million of contingent consideration for acquired businesses. These payments were partially offset by $75.0 million cash proceeds from borrowings ($73.3 million for short-term borrowings and $1.7 million for long-term borrowings) and $9.4 million of proceeds from the exercise of stock options.

[0001437749-20-003516:mdna:92]
Net cash used in financing activities for the year ended December 31, 2018 primarily consisted of $129.7 million of debt repayments ($101.8 million of long-term borrowings and $27.9 million of short-term borrowings), $25.7 million for the repurchase of our common stock, and $5.7 million of taxes paid related to equity awards. These payments were partially offset by $105.4 million of cash proceeds from borrowings ($54.0 million for short-term borrowings and $51.4 million for long-term borrowings) and $5.6 million of proceeds from the exercise of stock options.

[0001437749-20-003516:mdna:93]
Year ended December 31, 2018 compared to year ended December 31, 2017

[0001437749-20-003516:mdna:94]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-20-003516:mdna:95]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 247,227 |  |  | $ | 257,322 |  |  | $ | (10,095 | ) |  |  | -3.9 | % |
| Net cash used in investing activities |  |  | (108,894 | ) |  |  | (28,128 | ) |  |  | (80,766 | ) |  |  | 287.1 | % |
| Net cash used in financing activities |  |  | (52,034 | ) |  |  | (160,143 | ) |  |  | 108,109 |  |  |  | -67.5 | % |

[0001437749-20-003516:mdna:96]
The decrease in net cash provided by operating activities was primarily driven by increased working capital investment due to strong organic growth and incremental inventory purchases ahead of expected tariff changes, which was partially offset by an increase in operating earnings.

[0001437749-20-003516:mdna:97]
Net cash used in investing activities for the year ended December 31, 2018 primarily represented cash payments of $65.4 million related to the acquisition of businesses and $47.6 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2017 primarily consisted of cash payments for the purchase of property and equipment.

[0001437749-20-003516:mdna:98]
Net cash used in financing activities for the year ended December 31, 2018 primarily consisted of $129.7 million of debt repayments ($101.8 million of long-term borrowings and $27.9 million of short-term borrowings), $25.7 million for the repurchase of our common stock, and $5.7 million of taxes paid related to equity awards. These payments were partially offset by $105.4 million of cash proceeds from borrowings ($54.0 million for short-term borrowings and $51.4 million for long-term borrowings) and $5.6 million of proceeds from the exercise of stock options.

[0001437749-20-003516:mdna:99]
Net cash used in financing activities for the year ended December 31, 2017 primarily consisted of $232.4 million of debt repayments ($117.5 million of long-term borrowings and $114.9 million of short-term borrowings), $30.0 million for the repurchase of our common stock, $5.9 million of taxes paid related to equity awards and $3.9 million of payments for debt issuance costs. These payments were partially offset by $105.1 million cash proceeds from borrowings ($102.0 million for short-term borrowings and $3.1 million for long-term borrowings) and $7.0 million of proceeds from the exercise of stock options.

[0001437749-20-003516:mdna:100]
Senior Secured Credit Facilities

[0001437749-20-003516:mdna:101]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-20-003516:mdna:102]
Covenant Compliance

[0001437749-20-003516:mdna:103]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-20-003516:mdna:104]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-20-003516:mdna:105]
The ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-20-003516:mdna:106]
Contractual Obligations

[0001437749-20-003516:mdna:107]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2019, using the interest rates in effect as of that date:

[0001437749-20-003516:mdna:108]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including current portion (1) |  | $ | 832,236 |  |  | $ | 553 |  |  | $ | 1,683 |  |  | $ | - |  |  | $ | 830,000 |  |
| Finance lease obligations, including current portion |  |  | 25,962 |  |  |  | 1,830 |  |  |  | 3,479 |  |  |  | 2,174 |  |  |  | 18,479 |  |
| Interest on long-term debt and finance lease obligations |  |  | 218,085 |  |  |  | 30,479 |  |  |  | 60,539 |  |  |  | 60,336 |  |  |  | 66,731 |  |
| Operating leases (2) |  |  | 50,542 |  |  |  | 9,511 |  |  |  | 14,302 |  |  |  | 10,755 |  |  |  | 15,974 |  |
| Total contractual cash obligations |  | $ | 1,126,825 |  |  | $ | 42,373 |  |  | $ | 80,003 |  |  | $ | 73,265 |  |  | $ | 931,184 |  |

[0001437749-20-003516:mdna:109]
(1) The Term Loan matures on December 13, 2026. The ABL Facility provides for a $300.0 million senior secured ABL revolving credit facility, which matures on June 12, 2023. There was no outstanding balance on the ABL Facility classified as long-term as of December 31, 2019.

[0001437749-20-003516:mdna:110]
(2) Includes future cash disbursements for three leases entered into in December 2019 for which there is not a corresponding right of use asset or lease liability recorded in the Consolidated Balance Sheets for the year ended December 31, 2019, due to the leases having a commencement date in 2020. Total payments to be made over the lease term for these three leases total $5.8 million.

[0001437749-20-003516:mdna:111]
In 2019, the Company terminated its domestic Pension Plan. In connection with the termination, all obligations were settled in the fourth quarter of 2019 through the purchase of annuities and lump sum distributions.

[0001437749-20-003516:mdna:112]
Capital Expenditures

[0001437749-20-003516:mdna:113]
Our operations require capital expenditures for technology, research & development, tooling, equipment, capacity expansion, IT systems & infrastructure and upgrades. Capital expenditures were $60.8 million, $47.6 million and $33.3 million for the years ended December 31, 2019, 2018 and 2017, respectively, and were funded through cash from operations.

[0001437749-20-003516:mdna:114]
Off-Balance Sheet Arrangements

[0001437749-20-003516:mdna:115]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-20-003516:mdna:116]
Total inventory financed under this arrangement accounted for approximately 11% and 10% of net sales for the years ended December 31, 2019 and 2018, respectively. The amount financed by dealers which remained outstanding was $49.6 million and $47.2 million as of December 31, 2019 and 2018, respectively.

[0001437749-20-003516:mdna:117]
Critical Accounting Policies

[0001437749-20-003516:mdna:118]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-20-003516:mdna:119]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-20-003516:mdna:120]
Refer to Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets. The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2019, 2018 and 2017, and found no impairment.

[0001437749-20-003516:mdna:121]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-20-003516:mdna:122]
In our October 31, 2019 impairment test calculation, the Latin America reporting unit had an estimated fair value that exceeded its carrying value by approximately 10%. The carrying value of the Latin America goodwill was $48.1 million. Key financial assumptions utilized to determine the fair value of the reporting unit includes revenue growth levels that reflect recovering end markets, an expanding customer and project pipeline, increased sales of service parts and service contracts, improving profit margins, a 3% terminal growth rate and an 11.1% discount rate. The reporting unit’s fair value would approximate its carrying value with a 100 basis point increase in the discount rate or a 100 basis point reduction in the sales continuous annual growth rate and terminal growth rate. As of the October 31, 2019 impairment test date, there was no other reporting unit with a carrying value that was at risk of exceeding its fair value.

[0001437749-20-003516:mdna:123]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-20-003516:mdna:124]
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-20-003516:mdna:125]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-20-003516:mdna:126]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-20-003516:mdna:127]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-20-003516:mdna:128]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-20-003516:mdna:129]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-20-003516:mdna:130]
|  | ● | disruptions to the Company’s business; |

[0001437749-20-003516:mdna:131]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-20-003516:mdna:132]
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-20-003516:mdna:133]
|  | ● | business divestitures. |

[0001437749-20-003516:mdna:134]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-20-003516:mdna:135]
Business Combinations and Purchase Accounting

[0001437749-20-003516:mdna:136]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, profit margins, and forecasted cash flows based on the discount rate and terminal growth rate. Refer to Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-20-003516:mdna:137]
Income Taxes

[0001437749-20-003516:mdna:138]
We account for income taxes in accordance with ASC 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-20-003516:mdna:139]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-20-003516:mdna:140]
Refer to Note 15, “Income Taxes” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes.

[0001437749-20-003516:mdna:141]
New Accounting Standards

[0001437749-20-003516:mdna:142]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Significant Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.
