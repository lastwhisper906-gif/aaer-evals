# GNRC note change history — 0001437749-19-015628 → 0001437749-19-021621


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2019 and  December 31, 2018 was approximately $52,217 and $47,200, respectively.
  (was, 2019-08-06, similarity 0.9889):
[0001437749-19-015628:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2019 and  December 31, 2018 was approximately $53,304 and $47,200, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products. As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2019-08-06, similarity 0.9989):
[0001437749-19-015628:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products.  As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2019-11-05):
[0001437749-19-021621:note_history:3]
The condensed consolidated balance sheet as of  September 30, 2019, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2019-08-06, similarity 0.9003):
[0001437749-19-015628:note_history:3]
The condensed consolidated balance sheet as of  June 30, 2019, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2019-11-05):
[0001437749-19-021621:note_history:4]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company's consolidated financial statements.
  (was, 2019-08-06, similarity 0.9991):
[0001437749-19-015628:note_history:4]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:5]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 28,479 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 38,506 |  |  |  | 27,124 |  |
| Total |  | $ | 66,985 |  |  | $ | 45,583 |  |
  (was, 2019-08-06, similarity 0.9688):
[0001437749-19-015628:note_history:5]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 26,405 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,626 |  |  |  | 27,124 |  |
| Total |  | $ | 57,031 |  |  | $ | 45,583 |  |

- added (2019-11-05):
[0001437749-19-021621:note_history:6]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,843 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,971 |  |  |  | 20,171 |  |
| Other |  |  | 741 |  |  |  | 1,642 |  |
| Total |  |  | 886,869 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 741 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,813 |  |  |  | 902 |  |
| Total |  | $ | 884,315 |  |  | $ | 876,396 |  |

- changed (2019-11-05):
[0001437749-19-021621:note_history:7]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2019, the Company’s net secured leverage ratio was 1.61 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2019-08-06, similarity 0.981):
[0001437749-19-015628:note_history:7]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2019, the Company’s net secured leverage ratio was 1.81 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2019-11-05):
[0001437749-19-021621:note_history:8]
As of  September 30, 2019, there was $28,479 outstanding under the ABL Facility, leaving $271,171 of availability, net of outstanding letters of credit.
  (was, 2019-08-06, similarity 0.9582):
[0001437749-19-015628:note_history:8]
As of  June 30, 2019, there was $26,405 outstanding under the ABL Facility, leaving $273,191 of availability, net of outstanding letters of credit.

- changed (2019-11-05):
[0001437749-19-021621:note_history:9]
As of  September 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $66,985 and $45,583, respectively.
  (was, 2019-08-06, similarity 0.9679):
[0001437749-19-015628:note_history:9]
As of  June 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $57,031 and $45,583, respectively.

- removed (2019-11-05):
[0001437749-19-015628:note_history:10]
|  |  | June 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (20,064 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 26,011 |  |  |  | 20,171 |  |
| Other |  |  | 985 |  |  |  | 1,642 |  |
| Total |  |  | 885,932 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,648 |  |  |  | 902 |  |
| Total |  | $ | 883,476 |  |  | $ | 876,396 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001437749-19-021621:note_history:11]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,843 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,971 |  |  |  | 20,171 |  |
| Other |  |  | 741 |  |  |  | 1,642 |  |
| Total |  |  | 886,869 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 741 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,813 |  |  |  | 902 |  |
| Total |  | $ | 884,315 |  |  | $ | 876,396 |  |

- removed (2019-11-05):
[0001437749-19-015628:note_history:12]
|  |  | June 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (20,064 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 26,011 |  |  |  | 20,171 |  |
| Other |  |  | 985 |  |  |  | 1,642 |  |
| Total |  |  | 885,932 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,648 |  |  |  | 902 |  |
| Total |  | $ | 883,476 |  |  | $ | 876,396 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:13]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 28,479 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 38,506 |  |  |  | 27,124 |  |
| Total |  | $ | 66,985 |  |  | $ | 45,583 |  |
  (was, 2019-08-06, similarity 0.9688):
[0001437749-19-015628:note_history:13]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 26,405 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,626 |  |  |  | 27,124 |  |
| Total |  | $ | 57,031 |  |  | $ | 45,583 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:14]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 324,096 |  |  | $ | 10,933 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 133,559 |  |  |  | 81,346 |  |  |  | 214,905 |  |
| Other |  |  | 40,508 |  |  |  | 10,693 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 498,163 |  |  | $ | 102,972 |  |  | $ | 601,135 |  |
  (was, 2019-08-06, similarity 0.8928):
[0001437749-19-015628:note_history:14]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 460,363 |  |  | $ | 25,841 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 260,986 |  |  |  | 178,566 |  |  |  | 439,552 |  |
| Other |  |  | 63,837 |  |  |  | 22,675 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 785,186 |  |  | $ | 227,083 |  |  | $ | 1,012,269 |  |

- changed (2019-11-05):
[0001437749-19-021621:note_history:15]
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 33,793 |  |  |  | 10,311 |  |  |  | 44,104 |  |
| Total net sales |  | $ | 456,132 |  |  | $ | 106,256 |  |  | $ | 562,388 |  |
  (was, 2019-08-06, similarity 0.9803):
[0001437749-19-015628:note_history:15]
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 29,027 |  |  |  | 6,528 |  |  |  | 35,555 |  |
| Total net sales |  | $ | 383,679 |  |  | $ | 113,902 |  |  | $ | 497,581 |  |

- changed (2019-11-05):
[0001437749-19-021621:note_history:16]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 784,459 |  |  | $ | 36,774 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 394,545 |  |  |  | 259,913 |  |  |  | 654,458 |  |
| Other |  |  | 104,344 |  |  |  | 33,369 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,283,348 |  |  | $ | 330,056 |  |  | $ | 1,613,404 |  |
  (was, 2019-08-06, similarity 0.9696):
[0001437749-19-015628:note_history:16]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 57,247 |  |  |  | 12,800 |  |  |  | 70,047 |  |
| Total net sales |  | $ | 686,355 |  |  | $ | 211,317 |  |  | $ | 897,672 |  |

- added (2019-11-05):
[0001437749-19-021621:note_history:17]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 91,040 |  |  |  | 23,111 |  |  |  | 114,151 |  |
| Total net sales |  | $ | 1,142,487 |  |  | $ | 317,573 |  |  | $ | 1,460,060 |  |

- removed (2019-11-05):
[0001437749-19-015628:note_history:18]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 255,182 |  |  | $ | 13,192 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 138,540 |  |  |  | 91,889 |  |  |  | 230,428 |  |
| Other |  |  | 32,216 |  |  |  | 10,897 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 425,938 |  |  | $ | 115,978 |  |  | $ | 541,916 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001437749-19-021621:note_history:19]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $7,814 and $14,174 at  September 30, 2019 and  December 31, 2018, respectively. During the nine months ended  September 30, 2019, the Company recognized revenue of $9,166 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2019-08-06, similarity 0.9473):
[0001437749-19-015628:note_history:19]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $8,577 and $14,174 at  June 30, 2019 and  December 31, 2018, respectively. During the six months ended  June 30, 2019, the Company recognized revenue of $8,177 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
