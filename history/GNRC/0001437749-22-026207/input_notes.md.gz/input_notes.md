# GNRC notes — 0001437749-22-026207


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-22-026207:notes:1]
[same as prior period, unchanged from 0001437749-22-019367:notes:1]

[0001437749-22-026207:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-22-026207:notes:3]
[same as prior period, unchanged from 0001437749-22-019367:notes:3]

[0001437749-22-026207:notes:4]
[same as prior period, unchanged from 0001437749-22-019367:notes:4]

[0001437749-22-026207:notes:5]
[same as prior period, unchanged from 0001437749-22-019367:notes:5]

[0001437749-22-026207:notes:6]
The condensed consolidated balance sheet as of  September 30, 2022, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-22-026207:notes:7]
[same as prior period, unchanged from 0001437749-22-019367:notes:7]

[0001437749-22-026207:notes:8]
[same as prior period, unchanged from 0001437749-22-019367:notes:8]

[0001437749-22-026207:notes:9]
Summary of Accounting Policies

[0001437749-22-026207:notes:10]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-22-026207:notes:11]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis.  As disclosed in Note 2, "Significant Accounting Policies - Goodwill and Other Indefinite-Lived Intangible Assets," to the consolidated financial statements in Item 8 of its 2021 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2021.

[0001437749-22-026207:notes:12]
During the three months ended  September 30, 2022, the Company identified a triggering event for its clean energy reporting unit requiring an interim impairment assessment to be performed due to the loss of a key customer as well as certain clean energy product warranty-related matters. Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test were based on updated projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows as well as the current discount rate based on the estimated weighted average cost of capital for the business.

[0001437749-22-026207:notes:13]
Based on the interim impairment assessment as of  September 30, 2022, the Company determined that the goodwill and indefinite-lived intangible assets ascribed to the clean energy reporting unit are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

[0001437749-22-026207:notes:14]
[same as prior period, unchanged from 0001437749-22-019367:notes:9]

[0001437749-22-026207:notes:15]
[same as prior period, unchanged from 0001437749-22-019367:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-026207:notes:16]
[same as prior period, unchanged from 0001437749-22-019367:notes:11]

[0001437749-22-026207:notes:17]
[same as prior period, unchanged from 0001437749-22-019367:notes:12]

[0001437749-22-026207:notes:18]
[same as prior period, unchanged from 0001437749-22-019367:notes:13]

[0001437749-22-026207:notes:19]
The accompanying condensed consolidated financial statements include the results of EEC from the date of acquisition through  September 30, 2022. Pro forma and other financial information is not presented as the effects of the EEC acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-22-026207:notes:20]
[same as prior period, unchanged from 0001437749-22-019367:notes:14]

[0001437749-22-026207:notes:21]
[same as prior period, unchanged from 0001437749-22-019367:notes:15]

[0001437749-22-026207:notes:22]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is a designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. The acquisition purchase price was funded solely through cash on hand.

[0001437749-22-026207:notes:23]
The Company finalized the Deep Sea purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $437,874 of intangible assets, including $263,604 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Deep Sea from the date of acquisition through  September 30, 2022.

[0001437749-22-026207:notes:24]
[same as prior period, unchanged from 0001437749-22-019367:notes:18]

[0001437749-22-026207:notes:25]
On  July 2, 2021, the Company acquired Chilicon for a purchase price, net of cash acquired, of $61,129. Based in Los Angeles, California, Chilicon is a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. Total consideration consisted of the following:

[0001437749-22-026207:notes:26]
[same as prior period, unchanged from 0001437749-22-019367:notes:20]

[0001437749-22-026207:notes:27]
| (1) | Payable on the third business day after December 31, 2023. |
| (2) | Payable in common stock issued upon achievement of certain performance targets within 45 calendar days following the conclusion of the earnout period, December 31, 2025. |

[0001437749-22-026207:notes:28]
The Company finalized the Chilicon purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $70,174 of intangible assets, including $36,974 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Chilicon from the date of acquisition through  September 30, 2022.

[0001437749-22-026207:notes:29]
[same as prior period, unchanged from 0001437749-22-019367:notes:23]

[0001437749-22-026207:notes:30]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $56,949, net of cash acquired and inclusive of the then estimated contingent consideration of $29,054 payable in cash based on earnout period performance. The contingent consideration was paid during the third quarter of 2022 in the amount of $16,135. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-22-026207:notes:31]
The Company finalized the Off Grid Energy purchase price allocation during the third quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $56,076 of intangible assets, including $21,531 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  September 30, 2022.

[0001437749-22-026207:notes:32]
[same as prior period, unchanged from 0001437749-22-019367:notes:27]

[0001437749-22-026207:notes:33]
On  December 1, 2021, the Company acquired ecobee for a purchase price, net of cash acquired, of $735,632. Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. The purchase price consisted of the following:

[0001437749-22-026207:notes:34]
[same as prior period, unchanged from 0001437749-22-019367:notes:29]

[0001437749-22-026207:notes:35]
| (1) | To be paid in the form of common stock issued upon achievement of certain performance targets following the end of two earnout periods, one ended June 30, 2022, and one ending June 30, 2023. |

[0001437749-22-026207:notes:36]
The Company recorded its preliminary ecobee purchase price allocation during the fourth quarter of 2021, which has been updated subsequently based on its estimates of the fair value of the acquired assets and assumed liabilities at the time of each update. The updates did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $799,228 of intangible assets, including $241,328 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of ecobee from the date of acquisition through  September 30, 2022.

[0001437749-22-026207:notes:37]
[same as prior period, unchanged from 0001437749-22-019367:notes:26]

[0001437749-22-026207:notes:38]
[same as prior period, unchanged from 0001437749-22-019367:notes:32]

[0001437749-22-026207:notes:39]
[same as prior period, unchanged from 0001437749-22-019367:notes:33]

[0001437749-22-026207:notes:40]
[same as prior period, unchanged from 0001437749-22-019367:notes:34]

[0001437749-22-026207:notes:41]
The combined purchase price for these two acquisitions was $29,945, net of cash acquired, and was funded solely through cash on hand. The Company finalized its purchase price allocation during the third quarter of 2022 based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying condensed consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  September 30, 2022.

[0001437749-22-026207:notes:42]
Pro forma financial information is not presented for the 2021 acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-22-026207:notes:43]
[same as prior period, unchanged from 0001437749-22-019367:notes:37]

[0001437749-22-026207:notes:44]
[same as prior period, unchanged from 0001437749-22-019367:notes:38]

[0001437749-22-026207:notes:45]
|  |  | Deep Sea |  |  | ecobee |  |  | All Other |  |  | Total |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,852 |  |  | $ | 46,763 |  |
| Inventories |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |
| Prepaid expenses and other current assets |  |  | 1,181 |  |  |  | 5,689 |  |  |  | 6,594 |  |  |  | 13,464 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 3,588 |  |  |  | 480 |  |  |  | 12,906 |  |
| Intangible assets |  |  | 174,270 |  |  |  | 557,900 |  |  |  | 81,171 |  |  |  | 813,341 |  |
| Goodwill |  |  | 263,604 |  |  |  | 241,328 |  |  |  | 83,859 |  |  |  | 588,791 |  |
| Deferred income taxes |  |  | - |  |  |  | 46,721 |  |  |  | 5,694 |  |  |  | 52,415 |  |
| Other assets |  |  | 151 |  |  |  | 11,722 |  |  |  | 8,526 |  |  |  | 20,399 |  |
| Total assets acquired |  |  | 467,588 |  |  |  | 897,543 |  |  |  | 207,210 |  |  |  | 1,572,341 |  |
| Accounts payable |  |  | 8,998 |  |  |  | 25,968 |  |  |  | 7,473 |  |  |  | 42,439 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 872 |  |  |  | 4,332 |  |
| Other accrued liabilities |  |  | 1,737 |  |  |  | 19,898 |  |  |  | 18,258 |  |  |  | 39,893 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |
| Current portion of long-term debt |  |  | - |  |  |  | - |  |  |  | 233 |  |  |  | 233 |  |
| Deferred income taxes |  |  | 33,957 |  |  |  | 80,929 |  |  |  | 19,930 |  |  |  | 134,816 |  |
| Other long-term liabilities |  |  | 90 |  |  |  | 33,762 |  |  |  | 9,997 |  |  |  | 43,849 |  |
| Long-term borrowings and finance lease obligations |  |  | - |  |  |  | - |  |  |  | 1,624 |  |  |  | 1,624 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 735,632 |  |  | $ | 148,023 |  |  | $ | 1,304,355 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-22-026207:notes:46]
[same as prior period, unchanged from 0001437749-22-019367:notes:40]

[0001437749-22-026207:notes:47]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five-year period, and providing that the noncontrolling interest holder no longer held the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next 3 years.

[0001437749-22-026207:notes:48]
[same as prior period, unchanged from 0001437749-22-019367:notes:42]

[0001437749-22-026207:notes:49]
[same as prior period, unchanged from 0001437749-22-019367:notes:43]

[0001437749-22-026207:notes:50]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 82,830 |  |  | $ | 37,245 |  |  | $ | 58,050 |  |  | $ | 66,207 |  |
| Net income |  |  | 1,589 |  |  |  | 1,007 |  |  |  | 5,261 |  |  |  | 2,700 |  |
| Foreign currency translation |  |  | (2,708 | ) |  |  | (1,105 | ) |  |  | (6,817 | ) |  |  | (2,726 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | - |  |  |  | (375 | ) |  |  | (27,164 | ) |
| Redemption value adjustment |  |  | 5,225 |  |  |  | 7,557 |  |  |  | 30,817 |  |  |  | 5,687 |  |
| Balance at end of period |  | $ | 86,936 |  |  | $ | 44,704 |  |  | $ | 86,936 |  |  | $ | 44,704 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-22-026207:notes:51]
[same as prior period, unchanged from 0001437749-22-019367:notes:45]

[0001437749-22-026207:notes:52]
[same as prior period, unchanged from 0001437749-22-019367:notes:46]

[0001437749-22-026207:notes:53]
[same as prior period, unchanged from 0001437749-22-019367:notes:47]

[0001437749-22-026207:notes:54]
[same as prior period, unchanged from 0001437749-22-019367:notes:48]

[0001437749-22-026207:notes:55]
In 2017, the Company entered into twenty interest rate swap agreements, four of which were still outstanding as of  September 30, 2022. In  December 2019, in conjunction with an amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to seven as of  September 30, 2022.

[0001437749-22-026207:notes:56]
[same as prior period, unchanged from 0001437749-22-019367:notes:50]

[0001437749-22-026207:notes:57]
The amount of gains, net of tax, recognized for the three and nine months ended  September 30, 2022 were $13,757 and $39,614, respectively. The amount of gains, net of tax, recognized for the three and nine months ended  September 30, 2021 were $2,941 and $15,184, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-22-026207:notes:58]
[same as prior period, unchanged from 0001437749-22-019367:notes:52]

[0001437749-22-026207:notes:59]
[same as prior period, unchanged from 0001437749-22-019367:notes:53]

[0001437749-22-026207:notes:60]
|  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Commodity contracts |  | $ | (267 | ) |  | $ | - |  |
| Foreign currency contracts |  |  | 212 |  |  |  | (36 | ) |
| Interest rate swaps |  |  | 50,922 |  |  |  | (2,074 | ) |

[0001437749-22-026207:notes:61]
In the condensed consolidated balance sheets as of  September 30, 2022, the fair value of the commodity contracts is included in other accrued liabilities, the fair value of the foreign currency contracts is included in prepaid expenses & other current assets, and the fair value of the interest rate swaps is included in prepaid expenses & other current assets and operating lease & other assets in the amounts of $5,516 and $45,406, respectively. The fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  December 31, 2021. Excluding the impact of credit risk, the fair value of the derivative contracts as of  September 30, 2022 and  December 31, 2021 is an asset of $52,911 and a liability of $2,148, respectively, which represents the amount the Company would receive or pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-22-026207:notes:62]
[same as prior period, unchanged from 0001437749-22-019367:notes:56]

[0001437749-22-026207:notes:63]
[same as prior period, unchanged from 0001437749-22-019367:notes:57]

[0001437749-22-026207:notes:64]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, revolving facility borrowings, and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $1,269,325, was approximately $1,280,331 (Level 2) at  September 30, 2022, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-22-026207:notes:65]
[same as prior period, unchanged from 0001437749-22-019367:notes:59]

[0001437749-22-026207:notes:66]
[same as prior period, unchanged from 0001437749-22-019367:notes:60]

[0001437749-22-026207:notes:67]
[same as prior period, unchanged from 0001437749-22-019367:notes:61]

[0001437749-22-026207:notes:68]
The  September 30, 2022 fair value is reported as $86,283 in other accrued liabilities and $32,033 in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2021, the Company's contingent consideration balance included $68,665 in other accrued liabilities and $78,094 in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-22-026207:notes:69]
[same as prior period, unchanged from 0001437749-22-019367:notes:63]

[0001437749-22-026207:notes:70]
| Beginning balance, January 1, 2022 |  | $ | 146,759 |  |
| Changes in fair value |  |  | (10,974 | ) |
| Payment of contingent consideration |  |  | (16,135 | ) |
| Present value interest accretion |  |  | 1,835 |  |
| Currency translation |  |  | (3,169 | ) |
| Ending balance, September 30, 2022 |  | $ | 118,316 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-22-026207:notes:71]
[same as prior period, unchanged from 0001437749-22-019367:notes:65]

[0001437749-22-026207:notes:72]
The following presents a tabular disclosure of changes in AOCL during the three and nine months ended  September 30, 2022 and 2021, net of tax:

[0001437749-22-026207:notes:73]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2022 |  | $ | (106,645 | ) |  |  | $ | 23,806 |  |  |  | $ | (82,839 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (51,324 | ) | (1) |  |  | 13,757 |  | (2) |  |  | (37,567 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (51,324 | ) |  |  |  | 13,757 |  |  |  |  | (37,567 | ) |
| Ending Balance – September 30, 2022 |  | $ | (157,969 | ) |  |  | $ | 37,563 |  |  |  | $ | (120,406 | ) |

[0001437749-22-026207:notes:74]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2021 |  | $ | (27,246 | ) |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (20,899 | ) | (3) |  | 2,941 |  | (4) |  |  | (17,958 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (20,899 | ) |  |  | 2,941 |  |  |  |  | (17,958 | ) |
| Ending Balance – September 30, 2021 |  | $ | (48,145 | ) |  | $ | (7,396 | ) |  |  | $ | (55,541 | ) |

[0001437749-22-026207:notes:75]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (105,265 | ) | (5) |  |  | 39,614 |  | (6) |  |  | (65,651 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (105,265 | ) |  |  |  | 39,614 |  |  |  |  | (65,651 | ) |
| Ending Balance – September 30, 2022 |  | $ | (157,969 | ) |  |  | $ | 37,563 |  |  |  | $ | (120,406 | ) |

[0001437749-22-026207:notes:76]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (36,471 | ) | (7) |  |  | 15,184 |  | (8) |  |  | (21,287 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (36,471 | ) |  |  |  | 15,184 |  |  |  |  | (21,287 | ) |
| Ending Balance – September 30, 2021 |  | $ | (48,145 | ) |  |  | $ | (7,396 | ) |  |  | $ | (55,541 | ) |

[0001437749-22-026207:notes:77]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2022, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $18,404 on the interest rate swaps, net of tax effect of $(4,647) for the three months ended September 30, 2022. |

[0001437749-22-026207:notes:78]
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2021, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized gains of $3,934 on the interest rate swaps, net of tax effect of $(993) for the three months ended September 30, 2021. |
|  | (5) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2022, particularly the Euro and British Pound. |
|  | (6) | Represents unrealized gains of $52,995 on the interest rate swaps, net of tax effect of $(13,381) for the nine months ended September 30, 2022. |
|  | (7) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2021, particularly the Euro and British Pound. |
|  | (8) | Represents unrealized gains of $20,312 on the interest rate swaps, net of tax effect of $(5,128) for the nine months ended September 30, 2021. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-026207:notes:79]
[same as prior period, unchanged from 0001437749-22-019367:notes:73]

[0001437749-22-026207:notes:80]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, Deep Sea, and Off Grid Energy acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-22-026207:notes:81]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-22-026207:notes:82]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

[0001437749-22-026207:notes:83]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 585,150 |  |  | $ | 23,666 |  |  | $ | 608,816 |  |
| Commercial & industrial products |  |  | 140,824 |  |  |  | 117,485 |  |  |  | 258,309 |  |
| Other |  |  | 64,790 |  |  |  | 10,783 |  |  |  | 75,573 |  |
| Total net sales |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | 942,698 |  |

[0001437749-22-026207:notes:84]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |

[0001437749-22-026207:notes:85]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,690,707 |  |  | $ | 60,250 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 402,357 |  |  |  | 312,637 |  |  |  | 714,994 |  |
| Other |  |  | 174,584 |  |  |  | 29,578 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | 2,670,113 |  |

[0001437749-22-026207:notes:86]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn they sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-22-026207:notes:87]
C&I products consist of larger output stationary generators used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn they sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-22-026207:notes:88]
[same as prior period, unchanged from 0001437749-22-019367:notes:82]

[0001437749-22-026207:notes:89]
[same as prior period, unchanged from 0001437749-22-019367:notes:83]

[0001437749-22-026207:notes:90]
|  |  | Three Months Ended September 30, 2022 |  |  | Three Months Ended September 30, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | - |  |  | $ | 1,088,258 |  |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | - |  |  | $ | 942,698 |  |
| Intersegment sales |  |  | 15,485 |  |  |  | 25,416 |  |  |  | (40,901 | ) |  |  | - |  |  |  | 11,470 |  |  |  | 7,826 |  |  |  | (19,296 | ) |  |  | - |  |
| Total sales |  | $ | 946,617 |  |  | $ | 182,542 |  |  | $ | (40,901 | ) |  | $ | 1,088,258 |  |  | $ | 802,234 |  |  | $ | 159,760 |  |  | $ | (19,296 | ) |  | $ | 942,698 |  |

[0001437749-22-026207:notes:91]
|  |  | Nine Months Ended September 30, 2022 |  |  | Nine Months Ended September 30, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | - |  |  | $ | 3,515,505 |  |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | - |  |  | $ | 2,670,113 |  |
| Intersegment sales |  |  | 44,742 |  |  |  | 59,075 |  |  |  | (103,817 | ) |  |  | - |  |  |  | 26,949 |  |  |  | 16,378 |  |  |  | (43,327 | ) |  |  | - |  |
| Total sales |  | $ | 3,047,979 |  |  | $ | 571,343 |  |  | $ | (103,817 | ) |  | $ | 3,515,505 |  |  | $ | 2,294,597 |  |  | $ | 418,843 |  |  | $ | (43,327 | ) |  | $ | 2,670,113 |  |

[0001437749-22-026207:notes:92]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to income before provision for income taxes below. The computation of Adjusted EBITDA is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests.

[0001437749-22-026207:notes:93]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 159,810 |  |  | $ | 187,726 |  |  | $ | 572,159 |  |  | $ | 598,730 |  |
| International |  |  | 24,006 |  |  |  | 21,475 |  |  |  | 79,532 |  |  |  | 42,344 |  |
| Total adjusted EBITDA |  | $ | 183,816 |  |  | $ | 209,201 |  |  | $ | 651,691 |  |  | $ | 641,074 |  |
| Interest expense |  |  | (15,514 | ) |  |  | (7,980 | ) |  |  | (35,303 | ) |  |  | (23,424 | ) |
| Depreciation and amortization |  |  | (39,165 | ) |  |  | (23,216 | ) |  |  | (116,724 | ) |  |  | (62,682 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 6,840 |  |  |  | (3,333 | ) |  |  | 10,025 |  |  |  | (638 | ) |
| Non-cash share-based compensation expense (2) |  |  | (6,861 | ) |  |  | (5,783 | ) |  |  | (23,423 | ) |  |  | (18,204 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | (3,743 | ) |  |  | (831 | ) |
| Transaction costs and credit facility fees (4) |  |  | (1,250 | ) |  |  | (3,385 | ) |  |  | (3,831 | ) |  |  | (9,471 | ) |
| Business optimization and other charges (5) |  |  | (622 | ) |  |  | - |  |  |  | (3,371 | ) |  |  | (159 | ) |
| Provision for clean energy product charges (6) |  |  | (55,265 | ) |  |  | - |  |  |  | (55,265 | ) |  |  | - |  |
| Other |  |  | 61 |  |  |  | (140 | ) |  |  | 951 |  |  |  | (717 | ) |
| Income before provision for income taxes |  | $ | 72,040 |  |  | $ | 165,364 |  |  | $ | 421,007 |  |  | $ | 524,948 |  |

[0001437749-22-026207:notes:94]
[same as prior period, unchanged from 0001437749-22-019367:notes:88]

[0001437749-22-026207:notes:95]
[same as prior period, unchanged from 0001437749-22-019367:notes:89]

[0001437749-22-026207:notes:96]
[same as prior period, unchanged from 0001437749-22-019367:notes:90]

[0001437749-22-026207:notes:97]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance, or refinancing, together with certain fees relating to our senior secured credit facilities. |
|  | (5) | The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities. |
|  | (6) | Represents a specific credit loss provision of $17,926 for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37,338 to address certain clean energy product warranty-related matters. |

[0001437749-22-026207:notes:98]
The Company’s sales in the U.S. represented approximately 82% of total sales for the three months ended  September 30, 2022 and 2021. The Company’s sales in the U.S. represented approximately 82% of total sales for the nine months ended  September 30, 2022 and 2021. Approximately 78% and 75% of the Company’s identifiable long-lived assets were located in the U.S. at  September 30, 2022 and  December 31, 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-22-026207:notes:99]
[same as prior period, unchanged from 0001437749-22-019367:notes:93]

[0001437749-22-026207:notes:100]
As of  September 30, 2022, the Company had gross receivables of $569,470 and an allowance for credit losses of $26,942. The following is a tabular reconciliation of the Company's allowance for credit losses:

[0001437749-22-026207:notes:101]
|  |  | Nine Months Ended September 30, 2022 |  |
| Balance at beginning of period |  | $ | 12,025 |  |
| Established for acquisitions |  |  | 515 |  |
| Provision for credit losses (1) |  |  | 18,012 |  |
| Charge-offs |  |  | (3,172 | ) |
| Currency translation |  |  | (438 | ) |
| Balance at end of period |  | $ | 26,942 |  |

[0001437749-22-026207:notes:102]
|  | (1) | Includes a specific credit loss provision of $17,926 recorded during the third quarter of 2022 for a clean energy product customer that filed for bankruptcy. |

[0001437749-22-026207:notes:103]
[same as prior period, unchanged from 0001437749-22-019367:notes:94]

[0001437749-22-026207:notes:104]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Raw material |  | $ | 819,612 |  |  | $ | 727,162 |  |
| Work-in-process |  |  | 17,358 |  |  |  | 10,756 |  |
| Finished goods |  |  | 587,721 |  |  |  | 351,787 |  |
| Total |  | $ | 1,424,691 |  |  | $ | 1,089,705 |  |

[0001437749-22-026207:notes:105]
[same as prior period, unchanged from 0001437749-22-019367:notes:96]

[0001437749-22-026207:notes:106]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Land and improvements |  | $ | 21,841 |  |  | $ | 26,137 |  |
| Buildings and improvements |  |  | 239,231 |  |  |  | 244,273 |  |
| Machinery and equipment |  |  | 220,756 |  |  |  | 186,611 |  |
| Dies and tools |  |  | 36,088 |  |  |  | 31,581 |  |
| Vehicles |  |  | 9,063 |  |  |  | 7,621 |  |
| Office equipment and systems |  |  | 144,437 |  |  |  | 125,048 |  |
| Leasehold improvements |  |  | 6,625 |  |  |  | 5,679 |  |
| Construction in progress |  |  | 39,494 |  |  |  | 47,601 |  |
| Gross property and equipment |  |  | 717,535 |  |  |  | 674,551 |  |
| Accumulated depreciation |  |  | (267,402 | ) |  |  | (233,699 | ) |
| Total |  | $ | 450,133 |  |  | $ | 440,852 |  |

[0001437749-22-026207:notes:107]
Total property and equipment included finance leases of $26,267 and $36,776 on  September 30, 2022 and  December 31, 2021, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-22-026207:notes:108]
[same as prior period, unchanged from 0001437749-22-019367:notes:99]

[0001437749-22-026207:notes:109]
[same as prior period, unchanged from 0001437749-22-019367:notes:100]

[0001437749-22-026207:notes:110]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 110,338 |  |  | $ | 74,758 |  |  | $ | 94,213 |  |  | $ | 59,218 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 1,085 |  |  |  | - |  |  |  | 1,085 |  |
| Payments |  |  | (22,677 | ) |  |  | (10,475 | ) |  |  | (54,135 | ) |  |  | (29,536 | ) |
| Provision for warranty issued |  |  | 19,076 |  |  |  | 16,527 |  |  |  | 62,169 |  |  |  | 48,521 |  |
| Changes in estimates for pre-existing warranties (1) |  |  | 38,571 |  |  |  | 1,089 |  |  |  | 43,061 |  |  |  | 3,696 |  |
| Balance at end of period |  | $ | 145,308 |  |  | $ | 82,984 |  |  | $ | 145,308 |  |  | $ | 82,984 |  |

[0001437749-22-026207:notes:111]
|  | (1) | Includes a specific warranty provision recorded during the third quarter of 2022 in the amount of $37,338 to address certain clean energy product warranty-related matters. |

[0001437749-22-026207:notes:112]
[same as prior period, unchanged from 0001437749-22-019367:notes:102]

[0001437749-22-026207:notes:113]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 121,898 |  |  | $ | 100,484 |  |  | $ | 111,647 |  |  | $ | 89,788 |  |
| Deferred revenue contracts issued |  |  | 10,324 |  |  |  | 11,105 |  |  |  | 31,202 |  |  |  | 31,304 |  |
| Amortization of deferred revenue contracts |  |  | (5,470 | ) |  |  | (5,014 | ) |  |  | (16,097 | ) |  |  | (14,517 | ) |
| Balance at end of period |  | $ | 126,752 |  |  | $ | 106,575 |  |  | $ | 126,752 |  |  | $ | 106,575 |  |

[0001437749-22-026207:notes:114]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  September 30, 2022 is as follows:

[0001437749-22-026207:notes:115]
| Remainder of 2022 |  | $ | 5,657 |  |
| 2023 |  |  | 24,119 |  |
| 2024 |  |  | 24,276 |  |
| 2025 |  |  | 21,395 |  |
| 2026 |  |  | 17,028 |  |
| After 2026 |  |  | 34,277 |  |
| Total |  | $ | 126,752 |  |

[0001437749-22-026207:notes:116]
[same as prior period, unchanged from 0001437749-22-019367:notes:106]

[0001437749-22-026207:notes:117]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 100,451 |  |  | $ | 59,052 |  |
| Long-term portion - other long-term liabilities |  |  | 44,857 |  |  |  | 35,161 |  |
| Total |  | $ | 145,308 |  |  | $ | 94,213 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 23,237 |  |  | $ | 20,556 |  |
| Long-term portion - other long-term liabilities |  |  | 103,515 |  |  |  | 91,091 |  |
| Total |  | $ | 126,752 |  |  | $ | 111,647 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-22-026207:notes:118]
[same as prior period, unchanged from 0001437749-22-019367:notes:108]

[0001437749-22-026207:notes:119]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $34,257 and $27,388 on  September 30, 2022 and  December 31, 2021, respectively. During the nine months ended  September 30, 2022, the Company recognized revenue of $24,160 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-026207:notes:120]
11.   Credit Agreements

[0001437749-22-026207:notes:121]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-026207:notes:122]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 64,588 |  |  |  | 72,035 |  |
| Total |  | $ | 64,588 |  |  | $ | 72,035 |  |

[0001437749-22-026207:notes:123]
As of  September 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-22-026207:notes:124]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-026207:notes:125]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,541 | ) |  |  | (13,214 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,842 |  |  |  | 39,175 |  |
| Other |  |  | 611 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,912 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 5,057 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,999 |  |  |  | 4,209 |  |
| Total |  | $ | 1,282,856 |  |  | $ | 902,091 |  |

[0001437749-22-026207:notes:126]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75%, or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.

[0001437749-22-026207:notes:127]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date.

[0001437749-22-026207:notes:128]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2022, the Company’s net secured leverage ratio was 1.25 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-22-026207:notes:129]
The Company’s credit agreements also originally provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-22-026207:notes:130]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

[0001437749-22-026207:notes:131]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of the prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-22-026207:notes:132]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-22-026207:notes:133]
The Tranche A Term Loan Facility is repayable in quarterly installments in total for the twelve months ended 0.0% of the original principal amount during the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, in total for the twelve months ended 2.5% of the original principal amount during the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, in total for the twelve months ended 5.0% of the original principal amount during the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, in total for the twelve months ended 7.5% of the original principal amount during the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and in total for the twelve months ended 10.0% of the original principal amount during the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.

[0001437749-22-026207:notes:134]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-22-026207:notes:135]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2022, the Company’s total leverage ratio was 1.33 to 1.00 times, and the Company's interest coverage ratio was 20.81 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2022.

[0001437749-22-026207:notes:136]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-22-026207:notes:137]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender by lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-22-026207:notes:138]
As of  September 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,248,580 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-22-026207:notes:139]
[same as prior period, unchanged from 0001437749-22-019367:notes:129]

[0001437749-22-026207:notes:140]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allowed for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the third quarter of 2022, the Company repurchased 536,633 shares of its common stock for $123,900. There were no share repurchases under the program during the first and second quarters of 2022. Additionally, there were no share repurchases under the program during the three and nine months ended  September 30, 2021. Since the inception of all stock repurchase programs (starting in  August 2015), we have repurchased 9,563,339 shares of our common stock for $555,439 (at an average cost per share of $58.08).


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-026207:notes:141]
[same as prior period, unchanged from 0001437749-22-019367:notes:131]

[0001437749-22-026207:notes:142]
[same as prior period, unchanged from 0001437749-22-019367:notes:132]

[0001437749-22-026207:notes:143]
[same as prior period, unchanged from 0001437749-22-019367:notes:133]

[0001437749-22-026207:notes:144]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (5,225 | ) |  |  | (7,557 | ) |  |  | (30,817 | ) |  |  | (5,687 | ) |
| Net income attributable to common shareholders |  | $ | 53,045 |  |  | $ | 124,013 |  |  | $ | 297,670 |  |  | $ | 401,912 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 63,249,881 |  |  |  | 62,690,437 |  |  |  | 63,480,161 |  |  |  | 62,583,957 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,006,814 |  |  |  | 1,517,679 |  |  |  | 1,139,242 |  |  |  | 1,562,324 |  |
| Dilutive effect of contingently issued shares |  |  | 10,943 |  |  |  | - |  |  |  | 10,943 |  |  |  | - |  |
| Diluted shares |  |  | 64,267,638 |  |  |  | 64,208,116 |  |  |  | 64,630,346 |  |  |  | 64,146,281 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.84 |  |  | $ | 1.98 |  |  | $ | 4.69 |  |  | $ | 6.42 |  |
| Diluted |  | $ | 0.83 |  |  | $ | 1.93 |  |  | $ | 4.61 |  |  | $ | 6.27 |  |

[0001437749-22-026207:notes:145]
(1) Excludes approximately 85,000 and 44,000 stock options and restricted stock awards for the three and nine months ended  September 30, 2022, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three and nine months ended  September 30, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-026207:notes:146]
[same as prior period, unchanged from 0001437749-22-019367:notes:136]

[0001437749-22-026207:notes:147]
The effective income tax rates for the nine months ended  September 30, 2022 and 2021 were 20.4% and 21.8%, respectively. The decrease in the effective tax rate was driven by discrete tax items including the unfavorable tax rate adjustment in a foreign jurisdiction increasing the tax expense in the prior year, and a nontaxable adjustment to contingent consideration in the current year quarter. These were partially offset by a lower tax benefit from equity compensation in the current year compared to the prior year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-026207:notes:148]
15. Commitments and Contingencies

[0001437749-22-026207:notes:149]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2022 and  December 31, 2021 was approximately $222,400 and $115,900, respectively.

[0001437749-22-026207:notes:150]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”).  The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred.  The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement.  On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors.  The petition listed a $17,700 liability to Generac Power, which Power Home Solar characterized as disputed.  The $17,700 claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for.  The parties agreed to toll Power Home Solar’s deadline to respond to the motion to dismiss after Power Home Solar filed the petition for bankruptcy to allow the bankruptcy trustee to evaluate the complaint.  The Company intends to vigorously defend against the claims in the complaint, whichever forum it  may proceed in.

[0001437749-22-026207:notes:151]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida.  The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred.  The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

[0001437749-22-026207:notes:152]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”).  The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-22-026207:notes:153]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserve
      may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-026207:notes:154]
16. Subsequent Events

[0001437749-22-026207:notes:155]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial internet of things (IoT) platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control.
