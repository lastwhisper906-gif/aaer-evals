# GNRC note change history — 0001437749-22-019367 → 0001437749-22-026207


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-07):
[0001437749-22-026207:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2022 and  December 31, 2021 was approximately $222,400 and $115,900, respectively.
  (was, 2022-08-08, similarity 0.9889):
[0001437749-22-019367:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2022 and  December 31, 2021 was approximately $238,643 and $115,900, respectively.

- added (2022-11-07):
[0001437749-22-026207:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”).  The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred.  The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement.  On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors.  The petition listed a $17,700 liability to Generac Power, which Power Home Solar characterized as disputed.  The $17,700 claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for.  The parties agreed to toll Power Home Solar’s deadline to respond to the motion to dismiss after Power Home Solar filed the petition for bankruptcy to allow the bankruptcy trustee to evaluate the complaint.  The Company intends to vigorously defend against the claims in the complaint, whichever forum it  may proceed in.

- added (2022-11-07):
[0001437749-22-026207:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida.  The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred.  The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

- added (2022-11-07):
[0001437749-22-026207:note_history:4]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”).  The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

- added (2022-11-07):
[0001437749-22-026207:note_history:5]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserve
      may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.

- removed (2022-11-07):
[0001437749-22-019367:note_history:6]
From time to time, the Company is involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      June 
     30,
     2022, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-07):
[0001437749-22-026207:note_history:7]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2022-08-08, similarity 0.9708):
[0001437749-22-019367:note_history:7]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2022-11-07):
[0001437749-22-026207:note_history:8]
The condensed consolidated balance sheet as of  September 30, 2022, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2022-08-08, similarity 0.9033):
[0001437749-22-019367:note_history:8]
The condensed consolidated balance sheet as of  June 30, 2022, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2022 and 2021, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- added (2022-11-07):
[0001437749-22-026207:note_history:9]
Summary of Accounting Policies

- added (2022-11-07):
[0001437749-22-026207:note_history:10]
Goodwill and Other Indefinite-Lived Intangible Assets

- added (2022-11-07):
[0001437749-22-026207:note_history:11]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis.  As disclosed in Note 2, "Significant Accounting Policies - Goodwill and Other Indefinite-Lived Intangible Assets," to the consolidated financial statements in Item 8 of its 2021 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2021.

- added (2022-11-07):
[0001437749-22-026207:note_history:12]
During the three months ended  September 30, 2022, the Company identified a triggering event for its clean energy reporting unit requiring an interim impairment assessment to be performed due to the loss of a key customer as well as certain clean energy product warranty-related matters. Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test were based on updated projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows as well as the current discount rate based on the estimated weighted average cost of capital for the business.

- added (2022-11-07):
[0001437749-22-026207:note_history:13]
Based on the interim impairment assessment as of  September 30, 2022, the Company determined that the goodwill and indefinite-lived intangible assets ascribed to the clean energy reporting unit are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-07):
[0001437749-22-026207:note_history:14]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 64,588 |  |  |  | 72,035 |  |
| Total |  | $ | 64,588 |  |  | $ | 72,035 |  |
  (was, 2022-08-08, similarity 0.9688):
[0001437749-22-019367:note_history:14]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 77,514 |  |  |  | 72,035 |  |
| Total |  | $ | 77,514 |  |  | $ | 72,035 |  |

- changed (2022-11-07):
[0001437749-22-026207:note_history:15]
As of  September 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.
  (was, 2022-08-08, similarity 0.9617):
[0001437749-22-019367:note_history:15]
As of  June 30, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

- added (2022-11-07):
[0001437749-22-026207:note_history:16]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,541 | ) |  |  | (13,214 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,842 |  |  |  | 39,175 |  |
| Other |  |  | 611 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,912 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 5,057 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,999 |  |  |  | 4,209 |  |
| Total |  | $ | 1,282,856 |  |  | $ | 902,091 |  |

- changed (2022-11-07):
[0001437749-22-026207:note_history:17]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75%, or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.
  (was, 2022-08-08, similarity 0.9928):
[0001437749-22-019367:note_history:17]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and include a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is currently  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based upon either a Base Rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%.

- added (2022-11-07):
[0001437749-22-026207:note_history:18]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2022, the Company’s net secured leverage ratio was 1.25 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2022-11-07):
[0001437749-22-026207:note_history:19]
The Company’s credit agreements also originally provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.
  (was, 2022-08-08, similarity 0.9858):
[0001437749-22-019367:note_history:19]
The Company’s credit agreements also provided for a $500,000 senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- changed (2022-11-07):
[0001437749-22-026207:note_history:20]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.
  (was, 2022-08-08, similarity 0.9976):
[0001437749-22-019367:note_history:20]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

- changed (2022-11-07):
[0001437749-22-026207:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.
  (was, 2022-08-08, similarity 0.9824):
[0001437749-22-019367:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements by entering into a new credit agreement (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayment, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

- added (2022-11-07):
[0001437749-22-026207:note_history:22]
The Tranche A Term Loan Facility is repayable in quarterly installments in total for the twelve months ended 0.0% of the original principal amount during the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, in total for the twelve months ended 2.5% of the original principal amount during the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, in total for the twelve months ended 5.0% of the original principal amount during the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, in total for the twelve months ended 7.5% of the original principal amount during the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and in total for the twelve months ended 10.0% of the original principal amount during the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.

- changed (2022-11-07):
[0001437749-22-026207:note_history:23]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.
  (was, 2022-08-08, similarity 0.9979):
[0001437749-22-019367:note_history:23]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based upon adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

- added (2022-11-07):
[0001437749-22-026207:note_history:24]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2022, the Company’s total leverage ratio was 1.33 to 1.00 times, and the Company's interest coverage ratio was 20.81 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2022.

- changed (2022-11-07):
[0001437749-22-026207:note_history:25]
As of  September 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,248,580 of availability, net of outstanding letters of credit.
  (was, 2022-08-08, similarity 0.96):
[0001437749-22-019367:note_history:25]
As of  June 30, 2022, there was $0 outstanding under the Revolving Facility, leaving $1,249,480 of availability, net of outstanding letters of credit.

- removed (2022-11-07):
[0001437749-22-019367:note_history:26]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,515 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,600 |  |  |  | 39,175 |  |
| Other |  |  | 1,088 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,173 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,866 |  |  |  | 4,208 |  |
| Total |  | $ | 1,286,499 |  |  | $ | 902,091 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:27]
The Tranche B Term Loan Facility does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2022, the Company’s net secured leverage ratio was 1.09 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- removed (2022-11-07):
[0001437749-22-019367:note_history:28]
The Tranche A Term Loan Facility is repayable in quarterly installments of 0.0% of the original principal amount for each of the fiscal quarters ending  June 30, 2022 through and including  June 30, 2023, 2.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2023 through and including  June 30, 2024, 5.0% of the original principal amount for each of the fiscal quarters ending  September 30, 2024 through and including  June 30, 2025, 7.5% of the original principal amount for each of the fiscal quarters ending  September 30, 2025 through and including  June 30, 2026, and 10% of the original principal amount for each of the fiscal quarters ending  September 30, 2026 through and including  March 31, 2027, with the remaining principal balance due and payable on the maturity date.

- removed (2022-11-07):
[0001437749-22-019367:note_history:29]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2022, the Company’s total leverage ratio was 1.18 to 1.00 times, and the Company's interest coverage ratio was 25.56 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-11-07):
[0001437749-22-026207:note_history:30]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,541 | ) |  |  | (13,214 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,842 |  |  |  | 39,175 |  |
| Other |  |  | 611 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,912 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 5,057 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,999 |  |  |  | 4,209 |  |
| Total |  | $ | 1,282,856 |  |  | $ | 902,091 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:31]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,515 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | - |  |  |  | - |  |
| Finance lease obligation |  |  | 27,600 |  |  |  | 39,175 |  |
| Other |  |  | 1,088 |  |  |  | 2,060 |  |
| Total |  |  | 1,290,173 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,866 |  |  |  | 4,208 |  |
| Total |  | $ | 1,286,499 |  |  | $ | 902,091 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-07):
[0001437749-22-026207:note_history:32]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 64,588 |  |  |  | 72,035 |  |
| Total |  | $ | 64,588 |  |  | $ | 72,035 |  |
  (was, 2022-08-08, similarity 0.9688):
[0001437749-22-019367:note_history:32]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 77,514 |  |  |  | 72,035 |  |
| Total |  | $ | 77,514 |  |  | $ | 72,035 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-07):
[0001437749-22-026207:note_history:33]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

- added (2022-11-07):
[0001437749-22-026207:note_history:34]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 585,150 |  |  | $ | 23,666 |  |  | $ | 608,816 |  |
| Commercial & industrial products |  |  | 140,824 |  |  |  | 117,485 |  |  |  | 258,309 |  |
| Other |  |  | 64,790 |  |  |  | 10,783 |  |  |  | 75,573 |  |
| Total net sales |  | $ | 790,764 |  |  | $ | 151,934 |  |  | $ | 942,698 |  |

- added (2022-11-07):
[0001437749-22-026207:note_history:35]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |

- added (2022-11-07):
[0001437749-22-026207:note_history:36]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,690,707 |  |  | $ | 60,250 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 402,357 |  |  |  | 312,637 |  |  |  | 714,994 |  |
| Other |  |  | 174,584 |  |  |  | 29,578 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 2,267,648 |  |  | $ | 402,465 |  |  | $ | 2,670,113 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:37]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:38]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:39]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |

- removed (2022-11-07):
[0001437749-22-019367:note_history:40]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-07):
[0001437749-22-026207:note_history:41]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $34,257 and $27,388 on  September 30, 2022 and  December 31, 2021, respectively. During the nine months ended  September 30, 2022, the Company recognized revenue of $24,160 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2022-08-08, similarity 0.9473):
[0001437749-22-019367:note_history:41]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $28,933 and $27,388 on  June 30, 2022 and  December 31, 2021, respectively. During the six months ended  June 30, 2022, the Company recognized revenue of $21,470 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-11-07):
[0001437749-22-026207:note_history:42]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial internet of things (IoT) platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control.

- removed (2022-11-07):
[0001437749-22-019367:note_history:43]
Subsequent to  June 30, 2022, the Company repurchased 536,633 shares of its common stock for $123,900, all funded with cash on hand. Additionally, on  July 29, 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period.
