# GNRC 8-K — 0001437749-22-025447 filed 2022-11-02

## item codes, every 8-K on or before 2022-11-07

- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2022-11-07

- none on or before 2022-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-22-025447:8k_2_02:1]
EX-99.1
2
ex_440215.htm
EXHIBIT 99.1

[0001437749-22-025447:8k_2_02:2]
ex_440215.htm

[0001437749-22-025447:8k_2_02:3]
Exhibit 99.1

[0001437749-22-025447:8k_2_02:4]
Generac Reports Third Quarter 2022 Results

[0001437749-22-025447:8k_2_02:5]
Third quarter results and full year 2022 outlook in-line with preliminary announcement

[0001437749-22-025447:8k_2_02:6]
WAUKESHA, WISCONSIN (November 2, 2022) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2022 and provided its outlook for the full year 2022.

[0001437749-22-025447:8k_2_02:7]
Third Quarter 2022 Highlights

[0001437749-22-025447:8k_2_02:8]
| ● | Net sales increased 15% to $1.09 billion during the third quarter of 2022 as compared to $943 million in the prior-year third quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 10%. |

[0001437749-22-025447:8k_2_02:9]
|  | - | Residential product sales grew 9% to $664 million as compared to $609 million last year. |

[0001437749-22-025447:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 20% to $311 million as compared to $258 million in the prior year. |

[0001437749-22-025447:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $58 million, or $0.83 per share, as compared to $132 million, or $1.93 per share, for the same period of 2021. The current year net income includes pre-tax charges totaling $55.3 million, including $17.9 million of bad debt expense related to a clean energy product customer that has filed for bankruptcy and $37.3 million of clean energy product warranty-related matters. |

[0001437749-22-025447:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $112 million, or $1.75 per share, as compared to $151 million, or $2.35 per share, in the third quarter of 2021. |

[0001437749-22-025447:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $184 million, or 16.9% of net sales, as compared to $209 million, or 22.2% of net sales, in the prior year. |

[0001437749-22-025447:8k_2_02:14]
| ● | On October 3rd, the Company closed on the acquisition of Blue Pillar, an industrial internet of things platform (IoT) developer headquartered in Indianapolis, Indiana that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |

[0001437749-22-025447:8k_2_02:15]
“As disclosed in our preliminary announcement, despite net sales growing at a strong mid-teens rate, third quarter results fell short of our prior expectations,” said Aaron Jagdfeld, President and Chief Executive Officer. “Commercial & Industrial product sales continued to experience strong growth during the quarter, but Residential product sales began to slow as installation capacity constraints in our distribution network led to higher field inventory levels for home standby generators. This has resulted in lower orders than expected from our channel partners even as we’ve seen sequential improvements in several key metrics for the home standby category. Additionally in the quarter, shipments of clean energy products were negatively impacted by a large clean energy product customer which ceased operations during the quarter.”

[0001437749-22-025447:8k_2_02:16]
Jagdfeld continued, “While home standby order headwinds from our channel partners are expected to persist through the first half of 2023, the secular growth themes and mega-trends supporting the Company’s ‘Powering A Smarter World’ enterprise strategy are still very much intact. As reliance on electricity grows and supply & demand imbalances increase further, Generac will continue to invest in technologies and solutions to lead the evolution to the next generation grid.”

[0001437749-22-025447:8k_2_02:17]
Additional Third Quarter 2022 Consolidated Highlights

[0001437749-22-025447:8k_2_02:18]
Gross profit margin was 33.2% as compared to 35.6% in the prior-year third quarter. Continued higher input costs were partially offset by realization of previously implemented pricing actions, resulting in a modest price/cost headwind compared to the prior year. In addition, recent acquisitions and less favorable sales mix negatively impacted margins during the current year.

[0001437749-22-025447:8k_2_02:19]
Operating expenses increased $111.2 million, or 68.4%, as compared to the third quarter of 2021, which includes $55.3 million of pre-tax charges comprised of $17.9 million of bad debt expense related to a clean energy product customer that has filed for bankruptcy and $37.3 million of clean energy product warranty-related matters. The quarter also includes a $13.5 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and higher marketing spend most notably in the home standby category.

[0001437749-22-025447:8k_2_02:20]
Provision for income taxes for the current year quarter was $11.6 million, or an effective tax rate of 16.1%, as compared to $32.6 million, or a 19.7% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by certain discrete tax items that decreased the tax expense in the current year quarter on a net basis.

[0001437749-22-025447:8k_2_02:21]
Cash flow from operations was $(56.0) million during the third quarter, as compared to $74.4 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $(73.5) million as compared to $42.1 million in the third quarter of 2021. The decline in free cash flow was due to lower operating earnings, increased tax payments and higher working capital levels in the current year quarter, partially offset by lower capital expenditures.

[0001437749-22-025447:8k_2_02:22]
During the third quarter of 2022, the Company repurchased 536,633 shares of its common stock for $123.9 million, which exhausted the Company's previously existing stock repurchase program. In July 2022, the Company's Board of Directors approved another stock repurchase program which allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period.

[0001437749-22-025447:8k_2_02:23]
Business Segment Results

[0001437749-22-025447:8k_2_02:24]
Domestic Segment

[0001437749-22-025447:8k_2_02:25]
Domestic segment total sales (including inter-segment sales) increased 18% to $946.6 million as compared to $802.2 million in the prior year quarter, with the impact of acquisitions contributing approximately 8% of the revenue growth for the quarter. Core sales growth was led by C&I product shipments experiencing strong growth across all channels, highlighted by national rental equipment, telecom and industrial distributor customers, with home standby generators also experiencing year-over-year growth in the quarter. This growth was partially offset by lower clean energy product sales.

[0001437749-22-025447:8k_2_02:26]
Adjusted EBITDA for the segment was $159.8 million, or 16.9% of domestic segment total sales, as compared to $187.7 million in the prior year, or 23.4% of total sales. This margin performance was impacted by higher input costs, partially offset by pricing benefits. In addition, continued operating expense investments for future growth and the impact of acquisitions had an unfavorable effect on margins during the quarter, as operating expenses as a percentage of sales came in higher than expected on the lower shipment volumes relative to expectations.

[0001437749-22-025447:8k_2_02:27]
International Segment

[0001437749-22-025447:8k_2_02:28]
International segment total sales (including inter-segment sales) increased 14% to $182.5 million as compared to $159.8 million in the prior year quarter, with the impact of acquisitions and foreign currency providing an approximately 8% net headwind to revenue growth for the quarter. The 22% core total sales growth for the segment was driven by strong growth across all major regions as compared to the prior year, most notably in Europe.

[0001437749-22-025447:8k_2_02:29]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $24.0 million, or 13.2% of international segment total sales, as compared to $21.5 million, or 13.4% of total sales, in the prior year. This margin performance was impacted by less favorable sales mix, mostly offset by improved operating leverage on higher volumes.

[0001437749-22-025447:8k_2_02:30]
2022 Outlook Update

[0001437749-22-025447:8k_2_02:31]
Consistent with the update provided in the Company’s preliminary third quarter earnings announcement on October 19th, Generac expects its full-year 2022 net sales growth to be approximately 22 to 24% as compared to the prior year, which includes approximately 5 to 7% net impact from acquisitions and foreign currency.

[0001437749-22-025447:8k_2_02:32]
Additionally, the Company expects net income margin, before deducting for non-controlling interests, to be approximately 9.0 to 10.0% for the full-year 2022. This net income guidance includes the impact of the aforementioned $55.3 million of third quarter pre-tax charges. The corresponding adjusted EBITDA margin is expected to be approximately 18.0 to 19.0%.

[0001437749-22-025447:8k_2_02:33]
Conference Call and Webcast

[0001437749-22-025447:8k_2_02:34]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, November 2, 2022 to discuss third quarter 2022 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BI3d00d0fc061b4e438a6aee644a56a692. Individuals that wish to listen via telephone will be given dial-in information.

[0001437749-22-025447:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-22-025447:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's website.

[0001437749-22-025447:8k_2_02:37]
About Generac

[0001437749-22-025447:8k_2_02:38]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-22-025447:8k_2_02:39]
Forward-looking Information

[0001437749-22-025447:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-22-025447:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-22-025447:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-22-025447:8k_2_02:43]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-22-025447:8k_2_02:44]
|  | ● | availability of both labor and key components from our global supply chain, including single-sourced components, needed in producing our products; |

[0001437749-22-025447:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-22-025447:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-22-025447:8k_2_02:47]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-22-025447:8k_2_02:48]
|  | ● | the duration and impact of the COVID-19 pandemic; |

[0001437749-22-025447:8k_2_02:49]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-22-025447:8k_2_02:50]
|  | ● | our dependence on our distribution network; |

[0001437749-22-025447:8k_2_02:51]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-22-025447:8k_2_02:52]
|  | ● | loss of our key management and employees; |

[0001437749-22-025447:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-22-025447:8k_2_02:54]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-22-025447:8k_2_02:55]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; |

[0001437749-22-025447:8k_2_02:56]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations. |

[0001437749-22-025447:8k_2_02:57]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2021 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-22-025447:8k_2_02:58]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-22-025447:8k_2_02:59]
Non-GAAP Financial Metrics

[0001437749-22-025447:8k_2_02:60]
Core Sales

[0001437749-22-025447:8k_2_02:61]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-22-025447:8k_2_02:62]
Adjusted EBITDA

[0001437749-22-025447:8k_2_02:63]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-22-025447:8k_2_02:64]
Adjusted Net Income

[0001437749-22-025447:8k_2_02:65]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-22-025447:8k_2_02:66]
Free Cash Flow

[0001437749-22-025447:8k_2_02:67]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-22-025447:8k_2_02:68]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-22-025447:8k_2_02:69]
SOURCE: Generac Holdings Inc.

[0001437749-22-025447:8k_2_02:70]
CONTACT:

[0001437749-22-025447:8k_2_02:71]
Michael W. Harris

[0001437749-22-025447:8k_2_02:72]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-22-025447:8k_2_02:73]
(262) 506-6064

[0001437749-22-025447:8k_2_02:74]
InvestorRelations@generac.com

[0001437749-22-025447:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-025447:8k_2_02:76]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |
| Costs of goods sold |  |  | 727,154 |  |  |  | 606,704 |  |  |  | 2,336,668 |  |  |  | 1,672,570 |  |
| Gross profit |  |  | 361,104 |  |  |  | 335,994 |  |  |  | 1,178,837 |  |  |  | 997,543 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 170,381 |  |  |  | 82,242 |  |  |  | 388,690 |  |  |  | 229,443 |  |
| Research and development |  |  | 39,985 |  |  |  | 27,165 |  |  |  | 121,328 |  |  |  | 74,897 |  |
| General and administrative |  |  | 37,464 |  |  |  | 40,802 |  |  |  | 132,036 |  |  |  | 115,311 |  |
| Amortization of intangibles |  |  | 25,751 |  |  |  | 12,206 |  |  |  | 77,681 |  |  |  | 32,237 |  |
| Total operating expenses |  |  | 273,581 |  |  |  | 162,415 |  |  |  | 719,735 |  |  |  | 451,888 |  |
| Income from operations |  |  | 87,523 |  |  |  | 173,579 |  |  |  | 459,102 |  |  |  | 545,655 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (15,514 | ) |  |  | (7,980 | ) |  |  | (35,303 | ) |  |  | (23,424 | ) |
| Investment income |  |  | 451 |  |  |  | 165 |  |  |  | 620 |  |  |  | 1,012 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (3,743 | ) |  |  | (831 | ) |
| Other, net |  |  | (420 | ) |  |  | (400 | ) |  |  | 331 |  |  |  | 2,536 |  |
| Total other expense, net |  |  | (15,483 | ) |  |  | (8,215 | ) |  |  | (38,095 | ) |  |  | (20,707 | ) |
| Income before provision for income taxes |  |  | 72,040 |  |  |  | 165,364 |  |  |  | 421,007 |  |  |  | 524,948 |  |
| Provision for income taxes |  |  | 11,594 |  |  |  | 32,611 |  |  |  | 86,028 |  |  |  | 114,341 |  |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | 334,979 |  |  |  | 410,607 |  |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 6,492 |  |  |  | 3,008 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.84 |  |  | $ | 1.98 |  |  | $ | 4.69 |  |  | $ | 6.42 |  |
| Weighted average common shares outstanding - basic: |  |  | 63,249,881 |  |  |  | 62,690,437 |  |  |  | 63,480,161 |  |  |  | 62,583,957 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.83 |  |  | $ | 1.93 |  |  | $ | 4.61 |  |  | $ | 6.27 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,267,638 |  |  |  | 64,208,116 |  |  |  | 64,630,346 |  |  |  | 64,146,281 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 21,683 |  |  | $ | 113,727 |  |  | $ | 264,912 |  |  | $ | 386,789 |  |

[0001437749-22-025447:8k_2_02:77]
6

[0001437749-22-025447:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-025447:8k_2_02:79]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 229,911 |  |  | $ | 147,339 |  |
| Accounts receivable, less allowance for credit losses |  |  | 542,528 |  |  |  | 546,466 |  |
| Inventories |  |  | 1,424,691 |  |  |  | 1,089,705 |  |
| Prepaid expenses and other current assets |  |  | 116,139 |  |  |  | 64,954 |  |
| Total current assets |  |  | 2,313,269 |  |  |  | 1,848,464 |  |
| Property and equipment, net |  |  | 450,133 |  |  |  | 440,852 |  |
| Customer lists, net |  |  | 205,016 |  |  |  | 238,722 |  |
| Patents and technology, net |  |  | 455,845 |  |  |  | 492,473 |  |
| Other intangible assets, net |  |  | 44,207 |  |  |  | 66,436 |  |
| Tradenames, net |  |  | 228,170 |  |  |  | 243,531 |  |
| Goodwill |  |  | 1,359,588 |  |  |  | 1,409,674 |  |
| Deferred income taxes |  |  | 16,273 |  |  |  | 15,740 |  |
| Operating lease and other assets |  |  | 173,792 |  |  |  | 121,888 |  |
| Total assets |  | $ | 5,246,293 |  |  | $ | 4,877,780 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 64,588 |  |  | $ | 72,035 |  |
| Accounts payable |  |  | 523,552 |  |  |  | 674,208 |  |
| Accrued wages and employee benefits |  |  | 54,430 |  |  |  | 72,060 |  |
| Accrued product liability |  |  | 100,451 |  |  |  | 59,052 |  |
| Other accrued liabilities |  |  | 354,053 |  |  |  | 272,622 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 8,056 |  |  |  | 5,930 |  |
| Total current liabilities |  |  | 1,105,130 |  |  |  | 1,155,907 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,282,856 |  |  |  | 902,091 |  |
| Deferred income taxes |  |  | 131,978 |  |  |  | 205,964 |  |
| Operating lease and other long-term liabilities |  |  | 319,788 |  |  |  | 341,681 |  |
| Total liabilities |  |  | 2,839,752 |  |  |  | 2,605,643 |  |
| Redeemable noncontrolling interest |  |  | 86,936 |  |  |  | 58,050 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,640,001 and 72,386,017 shares issued at September 30, 2022 and December 31, 2021, respectively |  |  | 728 |  |  |  | 725 |  |
| Additional paid-in capital |  |  | 976,001 |  |  |  | 952,939 |  |
| Treasury stock, at cost |  |  | (599,304 | ) |  |  | (448,976 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,263,627 |  |  |  | 1,965,957 |  |
| Accumulated other comprehensive loss |  |  | (120,406 | ) |  |  | (54,755 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,318,530 |  |  |  | 2,213,774 |  |
| Noncontrolling interests |  |  | 1,075 |  |  |  | 313 |  |
| Total stockholders’ equity |  |  | 2,319,605 |  |  |  | 2,214,087 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,246,293 |  |  | $ | 4,877,780 |  |

[0001437749-22-025447:8k_2_02:80]
7

[0001437749-22-025447:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-025447:8k_2_02:82]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 334,979 |  |  | $ | 410,607 |  |
| Adjustment to reconcile net income to net cash (used in) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 39,043 |  |  |  | 30,445 |  |
| Amortization of intangible assets |  |  | 77,681 |  |  |  | 32,237 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,261 |  |  |  | 1,941 |  |
| Loss on extinguishment of debt |  |  | 3,743 |  |  |  | 831 |  |
| Deferred income taxes |  |  | (83,272 | ) |  |  | 8,210 |  |
| Share-based compensation expense |  |  | 23,423 |  |  |  | 18,204 |  |
| Gain on disposal of assets |  |  | (555 | ) |  |  | (4,018 | ) |
| Other noncash (gains) charges |  |  | 7,037 |  |  |  | (12 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (20,810 | ) |  |  | (116,768 | ) |
| Inventories |  |  | (353,618 | ) |  |  | (322,954 | ) |
| Other assets |  |  | (7,033 | ) |  |  | (6,874 | ) |
| Accounts payable |  |  | (136,289 | ) |  |  | 269,951 |  |
| Accrued wages and employee benefits |  |  | (17,418 | ) |  |  | 4,497 |  |
| Other accrued liabilities |  |  | 105,544 |  |  |  | 49,987 |  |
| Excess tax benefits from equity awards |  |  | (17,068 | ) |  |  | (26,880 | ) |
| Net cash (used in) provided by operating activities |  |  | (42,352 | ) |  |  | 349,404 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 2,049 |  |  |  | 182 |  |
| Proceeds from sale of investment |  |  | 1,308 |  |  |  | 4,968 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,745 |  |  |  | 2,240 |  |
| Contribution to equity method investment |  |  | (14,930 | ) |  |  | (781 | ) |
| Expenditures for property and equipment |  |  | (64,833 | ) |  |  | (87,456 | ) |
| Acquisition of business, net of cash acquired |  |  | (11,421 | ) |  |  | (465,926 | ) |
| Net cash used in investing activities |  |  | (85,082 | ) |  |  | (546,773 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 237,182 |  |  |  | 127,816 |  |
| Proceeds from long-term borrowings |  |  | 935,614 |  |  |  | 50,000 |  |
| Repayments of short-term borrowings |  |  | (239,550 | ) |  |  | (105,206 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (540,481 | ) |  |  | (54,889 | ) |
| Stock repurchases |  |  | (123,900 | ) |  |  | – |  |
| Payment of contingent acquisition consideration |  |  | (16,135 | ) |  |  | (3,750 | ) |
| Payment of debt issuance costs |  |  | (10,330 | ) |  |  | (1,185 | ) |
| Purchase of additional ownership interest |  |  | (375 | ) |  |  | (27,164 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (309 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (40,472 | ) |  |  | (49,569 | ) |
| Proceeds from the exercise of stock options |  |  | 13,627 |  |  |  | 30,502 |  |
| Net cash provided by (used in) financing activities |  |  | 214,871 |  |  |  | (33,445 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4,865 | ) |  |  | (588 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 82,572 |  |  |  | (231,402 | ) |
| Cash and cash equivalents at beginning of period |  |  | 147,339 |  |  |  | 655,128 |  |
| Cash and cash equivalents at end of period |  | $ | 229,911 |  |  | $ | 423,726 |  |

[0001437749-22-025447:8k_2_02:83]
8

[0001437749-22-025447:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-025447:8k_2_02:85]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |  | Three Months Ended September 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 931,132 |  |  | $ | 15,485 |  |  | $ | 946,617 |  |  | $ | 790,764 |  |  | $ | 11,470 |  |  | $ | 802,234 |  |
| International |  |  | 157,126 |  |  |  | 25,416 |  |  |  | 182,542 |  |  |  | 151,934 |  |  |  | 7,826 |  |  |  | 159,760 |  |
| Intercompany elimination |  |  | - |  |  |  | (40,901 | ) |  |  | (40,901 | ) |  |  | - |  |  |  | (19,296 | ) |  |  | (19,296 | ) |
| Total net sales |  | $ | 1,088,258 |  |  | $ | - |  |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | - |  |  | $ | 942,698 |  |

[0001437749-22-025447:8k_2_02:86]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |  | Nine Months Ended September 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,003,237 |  |  | $ | 44,742 |  |  | $ | 3,047,979 |  |  | $ | 2,267,648 |  |  | $ | 26,949 |  |  | $ | 2,294,597 |  |
| International |  |  | 512,268 |  |  |  | 59,075 |  |  |  | 571,343 |  |  |  | 402,465 |  |  |  | 16,378 |  |  |  | 418,843 |  |
| Intercompany elimination |  |  | - |  |  |  | (103,817 | ) |  |  | (103,817 | ) |  |  | - |  |  |  | (43,327 | ) |  |  | (43,327 | ) |
| Total net sales |  | $ | 3,515,505 |  |  | $ | - |  |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |  | $ | - |  |  | $ | 2,670,113 |  |

[0001437749-22-025447:8k_2_02:87]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Residential products |  | $ | 664,115 |  |  | $ | 608,816 |  |  | $ | 2,337,072 |  |  | $ | 1,750,957 |  |
| Commercial & industrial products |  |  | 311,186 |  |  |  | 258,309 |  |  |  | 899,263 |  |  |  | 714,994 |  |
| Other |  |  | 112,957 |  |  |  | 75,573 |  |  |  | 279,170 |  |  |  | 204,162 |  |
| Total net sales |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |

[0001437749-22-025447:8k_2_02:88]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 159,810 |  |  | $ | 187,726 |  |  | $ | 572,159 |  |  | $ | 598,730 |  |
| International |  |  | 24,006 |  |  |  | 21,475 |  |  |  | 79,532 |  |  |  | 42,344 |  |
| Total adjusted EBITDA (1) |  | $ | 183,816 |  |  | $ | 209,201 |  |  | $ | 651,691 |  |  | $ | 641,074 |  |

[0001437749-22-025447:8k_2_02:89]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |  |  |  |  |  |  |  |  |

[0001437749-22-025447:8k_2_02:90]
9

[0001437749-22-025447:8k_2_02:91]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-025447:8k_2_02:92]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 6,492 |  |  |  | 3,008 |  |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | 334,979 |  |  |  | 410,607 |  |
| Interest expense |  |  | 15,514 |  |  |  | 7,980 |  |  |  | 35,303 |  |  |  | 23,424 |  |
| Depreciation and amortization |  |  | 39,165 |  |  |  | 23,216 |  |  |  | 116,724 |  |  |  | 62,682 |  |
| Provision for income taxes |  |  | 11,594 |  |  |  | 32,611 |  |  |  | 86,028 |  |  |  | 114,341 |  |
| Non-cash write-down and other adjustments (1) |  |  | (6,840 | ) |  |  | 3,333 |  |  |  | (10,025 | ) |  |  | 638 |  |
| Non-cash share-based compensation expense (2) |  |  | 6,861 |  |  |  | 5,783 |  |  |  | 23,423 |  |  |  | 18,204 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (4) |  |  | 1,250 |  |  |  | 3,385 |  |  |  | 3,831 |  |  |  | 9,471 |  |
| Business optimization and other charges (5) |  |  | 622 |  |  |  | - |  |  |  | 3,371 |  |  |  | 159 |  |
| Provision for clean energy product charges (6) |  |  | 55,265 |  |  |  | - |  |  |  | 55,265 |  |  |  | - |  |
| Other |  |  | (61 | ) |  |  | 140 |  |  |  | (951 | ) |  |  | 717 |  |
| Adjusted EBITDA |  |  | 183,816 |  |  |  | 209,201 |  |  |  | 651,691 |  |  |  | 641,074 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,632 |  |  |  | 2,247 |  |  |  | 10,799 |  |  |  | 6,454 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 180,184 |  |  | $ | 206,954 |  |  | $ | 640,892 |  |  | $ | 634,620 |  |

[0001437749-22-025447:8k_2_02:93]
| (1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) The current year periods predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities. |
| (6) Represents a specific credit loss provision of $17.9 million for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters |

[0001437749-22-025447:8k_2_02:94]
10

[0001437749-22-025447:8k_2_02:95]
| Net income to Adjusted net income reconciliation |

[0001437749-22-025447:8k_2_02:96]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 6,492 |  |  |  | 3,008 |  |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | 334,979 |  |  |  | 410,607 |  |
| Provision for income taxes (7) |  |  | - |  |  |  | 32,611 |  |  |  | - |  |  |  | 114,341 |  |
| Amortization of intangible assets |  |  | 25,751 |  |  |  | 12,206 |  |  |  | 77,681 |  |  |  | 32,237 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 974 |  |  |  | 646 |  |  |  | 2,261 |  |  |  | 1,941 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | – |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | (7,605 | ) |  |  | 5,487 |  |  |  | (7,651 | ) |  |  | 11,130 |  |
| (Gain)/loss attributable to business or asset dispositions (9) |  |  | - |  |  |  | – |  |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges (5) |  |  | 622 |  |  |  | – |  |  |  | 3,371 |  |  |  | 159 |  |
| Provision for clean energy product charges (6) |  |  | 55,265 |  |  |  | – |  |  |  | 55,265 |  |  |  | – |  |
| Tax effect of add backs (10) |  |  | (21,233 | ) |  |  | – |  |  |  | (36,907 | ) |  |  | – |  |
| Cash income tax expense (7) |  |  | - |  |  |  | (31,290 | ) |  |  | - |  |  |  | (106,564 | ) |
| Adjusted net income |  |  | 114,220 |  |  |  | 152,413 |  |  |  | 432,513 |  |  |  | 460,691 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 2,031 |  |  |  | 1,272 |  |  |  | 7,199 |  |  |  | 3,616 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 112,189 |  |  | $ | 151,141 |  |  | $ | 425,314 |  |  | $ | 457,075 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.75 |  |  | $ | 2.35 |  |  | $ | 6.58 |  |  | $ | 7.13 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,267,638 |  |  |  | 64,208,116 |  |  |  | 64,630,346 |  |  |  | 64,146,281 |  |

[0001437749-22-025447:8k_2_02:97]
| (7) Amount for the three and nine months ended September 30, 2021 is based on an anticipated cash income tax rate at the time of approximately 20.0% to 20.5% for the full year ended 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP tax expense for the three and nine months ended September 30, 2021 would result in adjusted net income per diluted share of $2.25 and $6.83, respectively, on a pro forma basis. |
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (9) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |
| (10) In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the first and second quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the first and second quarters ended 2022 of $135,271 or $2.09 and $193,528 or $2.99, respectively. Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the first and second quarters ended 2022 is $128,150 or $1.98 and $185,270 or $2.86, respectively. |

[0001437749-22-025447:8k_2_02:98]
| Free Cash Flow Reconciliation |

[0001437749-22-025447:8k_2_02:99]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash (used in) provided by operating activities |  | $ | (56,045 | ) |  | $ | 74,411 |  |  | $ | (42,352 | ) |  | $ | 349,404 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 902 |  |  |  | 877 |  |  |  | 2,745 |  |  |  | 2,240 |  |
| Expenditures for property and equipment |  |  | (18,330 | ) |  |  | (33,234 | ) |  |  | (64,833 | ) |  |  | (87,456 | ) |
| Free cash flow |  | $ | (73,473 | ) |  | $ | 42,054 |  |  | $ | (104,440 | ) |  | $ | 264,188 |  |

[0001437749-22-025447:8k_2_02:100]
11
