# GNRC MD&A — 0001437749-22-026207


## mdna

[0001437749-22-026207:mdna:1]
[same as prior period, unchanged from 0001437749-22-019367:mdna:1]

[0001437749-22-026207:mdna:2]
[same as prior period, unchanged from 0001437749-22-019367:mdna:2]

[0001437749-22-026207:mdna:3]
[same as prior period, unchanged from 0001437749-22-019367:mdna:3]

[0001437749-22-026207:mdna:4]
[same as prior period, unchanged from 0001437749-22-019367:mdna:4]

[0001437749-22-026207:mdna:5]
[same as prior period, unchanged from 0001437749-22-019367:mdna:5]

[0001437749-22-026207:mdna:6]
[same as prior period, unchanged from 0001437749-22-019367:mdna:6]

[0001437749-22-026207:mdna:7]
[same as prior period, unchanged from 0001437749-22-019367:mdna:7]

[0001437749-22-026207:mdna:8]
[same as prior period, unchanged from 0001437749-22-019367:mdna:8]

[0001437749-22-026207:mdna:9]
[same as prior period, unchanged from 0001437749-22-019367:mdna:9]

[0001437749-22-026207:mdna:10]
[same as prior period, unchanged from 0001437749-22-019367:mdna:10]

[0001437749-22-026207:mdna:11]
[same as prior period, unchanged from 0001437749-22-019367:mdna:11]

[0001437749-22-026207:mdna:12]
[same as prior period, unchanged from 0001437749-22-019367:mdna:12]

[0001437749-22-026207:mdna:13]
[same as prior period, unchanged from 0001437749-22-019367:mdna:13]

[0001437749-22-026207:mdna:14]
[same as prior period, unchanged from 0001437749-22-019367:mdna:14]

[0001437749-22-026207:mdna:15]
[same as prior period, unchanged from 0001437749-22-019367:mdna:15]

[0001437749-22-026207:mdna:16]
[same as prior period, unchanged from 0001437749-22-019367:mdna:16]

[0001437749-22-026207:mdna:17]
[same as prior period, unchanged from 0001437749-22-019367:mdna:17]

[0001437749-22-026207:mdna:18]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; and |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations. |

[0001437749-22-026207:mdna:19]
[same as prior period, unchanged from 0001437749-22-019367:mdna:19]

[0001437749-22-026207:mdna:20]
[same as prior period, unchanged from 0001437749-22-019367:mdna:20]

[0001437749-22-026207:mdna:21]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, energy management devices and controls, advanced power grid software platforms and services, and engine- & battery-powered tools and equipment.  We are committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid. As an energy technology company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-22-026207:mdna:22]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential and C&I standby generators; as well as portable and mobile generators used in a variety of applications.  In recent years, the Company has been evolving its business model to focus on building out a residential and C&I ecosystem of energy technology products, solutions, and services.  As part of this evolution, we have made significant investments into rapidly growing new markets such as residential clean energy storage, solar microinverters, and energy monitoring and management devices, all of which are distributed energy resources (DERs) that can be aggregated into virtual power plants (VPPs) within grid services programs. In addition, a key strategic focus has been leveraging our leading position in the growing market for cleaner burning natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I applications.

[0001437749-22-026207:mdna:23]
[same as prior period, unchanged from 0001437749-22-019367:mdna:23]

[0001437749-22-026207:mdna:24]
[same as prior period, unchanged from 0001437749-22-019367:mdna:24]

[0001437749-22-026207:mdna:25]
[same as prior period, unchanged from 0001437749-22-019367:mdna:25]

[0001437749-22-026207:mdna:26]
[same as prior period, unchanged from 0001437749-22-019367:mdna:26]

[0001437749-22-026207:mdna:27]
[same as prior period, unchanged from 0001437749-22-019367:mdna:27]

[0001437749-22-026207:mdna:28]
|  | ● | "Grid 2.0": which is the evolution of the traditional electrical utility model as supply/demand imbalances are created due to the adoption of renewable energy and the electrification of everything as a society. It includes the decarbonization, digitization, and decentralization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward. |

[0001437749-22-026207:mdna:29]
[same as prior period, unchanged from 0001437749-22-019367:mdna:29]

[0001437749-22-026207:mdna:30]
[same as prior period, unchanged from 0001437749-22-019367:mdna:30]

[0001437749-22-026207:mdna:31]
[same as prior period, unchanged from 0001437749-22-019367:mdna:31]

[0001437749-22-026207:mdna:32]
[same as prior period, unchanged from 0001437749-22-019367:mdna:32]

[0001437749-22-026207:mdna:33]
Solar, storage, energy monitoring and energy management markets developing quickly.  During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the introduction of PWRcell™ and PWRview™. In 2021, we expanded our capabilities in the residential solar market with the introduction of the PWRmicro, a grid-interactive microinverter which is expected to be available in 2023.  In addition, in 2021, we acquired ecobee, a leader in sustainable home technology solutions. We believe ecobee’s technologies combined with Generac’s product offering will allow us to create a clean, efficient, and reliable home energy ecosystem and platform that will save homeowners money and help grid operators meet the challenges of an electrical grid under increasing stress by providing solutions to better balance supply and demand. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, regulation, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from renewable sources and cleaner-burning natural gas generators is projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. We expect to further advance our growing capabilities in clean energy by increasing our product development, sourcing, distribution, and marketing efforts, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential solar, storage, monitoring and management markets.

[0001437749-22-026207:mdna:34]
[same as prior period, unchanged from 0001437749-22-019367:mdna:34]

[0001437749-22-026207:mdna:35]
[same as prior period, unchanged from 0001437749-22-019367:mdna:35]

[0001437749-22-026207:mdna:36]
Rollout of 5G will require improved network quality.  As the number of “connected” devices continues to rapidly increase and wireless networks are now being considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States, where approximately half of all existing tower sites have yet to be hardened with backup power. As more mission-critical data is transmitted over wireless networks, we believe this penetration rate must increase considerably to maintain a higher level of reliability across the network. Increased adoption of high-speed wireless networks around the globe may lead to similar demand trends internationally as growing cell tower density and the need for onsite backup power expand the market opportunity for our international telecom operations. We have relationships with key Tier 1 carriers and tower companies globally in addition to having the distribution partners to support the global market from a service standpoint. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-22-026207:mdna:37]
[same as prior period, unchanged from 0001437749-22-019367:mdna:37]

[0001437749-22-026207:mdna:38]
Impact of residential investment cycle.  The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment.  When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns.  Finally, the existence of renewable energy mandates, investment tax credits and other subsidies can also have an impact on the demand for solar and energy storage systems, in particular with the Inflation Reduction Act.

[0001437749-22-026207:mdna:39]
[same as prior period, unchanged from 0001437749-22-019367:mdna:39]

[0001437749-22-026207:mdna:40]
[same as prior period, unchanged from 0001437749-22-019367:mdna:40]

[0001437749-22-026207:mdna:41]
[same as prior period, unchanged from 0001437749-22-019367:mdna:41]

[0001437749-22-026207:mdna:42]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, there continues to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs and delays for certain of our products that are reducing our margins.

[0001437749-22-026207:mdna:43]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in the third quarter. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-22-026207:mdna:44]
Impact of the COVID-19 pandemic.    We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have been operational during the pandemic. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-22-026207:mdna:45]
The COVID-19 pandemic has influenced various trends we are currently experiencing today involving supply chain and operations constraints. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. To date, we have experienced various interruptions to our supply chain as a result of the COVID pandemic. We have experienced inbound and outbound logistics delays and increased costs; however, we continue to monitor scheduled material receipts to mitigate these delays. This could change if freight carriers are delayed or not able to operate.  The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to continue to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers. Refer to the COVID-19 related risk factor disclosed in Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 31, 2021.

[0001437749-22-026207:mdna:46]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 22% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 25% to 28% in the third quarter and 27% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. For Residential products, we are currently experiencing higher field inventories for home standby generators given installation capacity constraints in our distribution network that has resulted in lower orders from our channel partners in the third quarter of 2022 and this headwind is expected to persist into the first half of 2023.

[0001437749-22-026207:mdna:47]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia.  Our sales to customers in Russia and Ukraine represented less than 1% of our total revenue for the year ended December 31, 2021, and therefore the impact on our financial results is not expected to be material. However, the situation remains uncertain and it is difficult to predict the impact that the conflict and actions taken in response to the conflict will have on our business. In particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-22-026207:mdna:48]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions to the existing Tranche B Term Loan Facility were replaced with SOFR provisions. During the nine months ended September 30, 2022, interest expense increased compared to the nine months ended September 30, 2021, primarily due to increased borrowings, higher interest rates, and interest accretion on contingent acquisition consideration. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-22-026207:mdna:49]
[same as prior period, unchanged from 0001437749-22-019367:mdna:51]

[0001437749-22-026207:mdna:50]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not impact the current quarter results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-22-026207:mdna:51]
[same as prior period, unchanged from 0001437749-22-019367:mdna:52]

[0001437749-22-026207:mdna:52]
[same as prior period, unchanged from 0001437749-22-019367:mdna:53]

[0001437749-22-026207:mdna:53]
Three months ended September 30, 2022 compared to the three months ended September 30, 2021

[0001437749-22-026207:mdna:54]
[same as prior period, unchanged from 0001437749-22-019367:mdna:55]

[0001437749-22-026207:mdna:55]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | 145,560 |  |  |  | 15.4 | % |
| Costs of goods sold |  |  | 727,154 |  |  |  | 606,704 |  |  |  | 120,450 |  |  |  | 19.9 | % |
| Gross profit |  |  | 361,104 |  |  |  | 335,994 |  |  |  | 25,110 |  |  |  | 7.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 170,381 |  |  |  | 82,242 |  |  |  | 88,139 |  |  |  | 107.2 | % |
| Research and development |  |  | 39,985 |  |  |  | 27,165 |  |  |  | 12,820 |  |  |  | 47.2 | % |
| General and administrative |  |  | 37,464 |  |  |  | 40,802 |  |  |  | (3,338 | ) |  |  | -8.2 | % |
| Amortization of intangible assets |  |  | 25,751 |  |  |  | 12,206 |  |  |  | 13,545 |  |  |  | 111.0 | % |
| Total operating expenses |  |  | 273,581 |  |  |  | 162,415 |  |  |  | 111,166 |  |  |  | 68.4 | % |
| Income from operations |  |  | 87,523 |  |  |  | 173,579 |  |  |  | (86,056 | ) |  |  | -49.6 | % |
| Total other expense, net |  |  | (15,483 | ) |  |  | (8,215 | ) |  |  | (7,268 | ) |  |  | 88.5 | % |
| Income before provision for income taxes |  |  | 72,040 |  |  |  | 165,364 |  |  |  | (93,324 | ) |  |  | -56.4 | % |
| Provision for income taxes |  |  | 11,594 |  |  |  | 32,611 |  |  |  | (21,017 | ) |  |  | -64.4 | % |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | (72,307 | ) |  |  | -54.5 | % |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 993 |  |  |  | 83.9 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | (73,300 | ) |  |  | -55.7 | % |

[0001437749-22-026207:mdna:56]
[same as prior period, unchanged from 0001437749-22-019367:mdna:57]

[0001437749-22-026207:mdna:57]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 931,132 |  |  | $ | 790,764 |  |  | $ | 140,368 |  |  |  | 17.8 | % |
| International |  |  | 157,126 |  |  |  | 151,934 |  |  |  | 5,192 |  |  |  | 3.4 | % |
| Total net sales |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | 145,560 |  |  |  | 15.4 | % |

[0001437749-22-026207:mdna:58]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |  | Three Months Ended September 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 931,132 |  |  | $ | 15,485 |  |  | $ | 946,617 |  |  | $ | 790,764 |  |  | $ | 11,470 |  |  | $ | 802,234 |  |
| International |  |  | 157,126 |  |  |  | 25,416 |  |  |  | 182,542 |  |  |  | 151,934 |  |  |  | 7,826 |  |  |  | 159,760 |  |
| Intercompany elimination |  |  | - |  |  |  | (40,901 | ) |  |  | (40,901 | ) |  |  | - |  |  |  | (19,296 | ) |  |  | (19,296 | ) |
| Total net sales |  | $ | 1,088,258 |  |  | $ | - |  |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | - |  |  | $ | 942,698 |  |

[0001437749-22-026207:mdna:59]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 159,810 |  |  | $ | 187,726 |  |  | $ | (27,916 | ) |  |  | -14.9 | % |
| International |  |  | 24,006 |  |  |  | 21,475 |  |  |  | 2,531 |  |  |  | 11.8 | % |
| Total Adjusted EBITDA |  | $ | 183,816 |  |  | $ | 209,201 |  |  | $ | (25,385 | ) |  |  | -12.1 | % |

[0001437749-22-026207:mdna:60]
[same as prior period, unchanged from 0001437749-22-019367:mdna:61]

[0001437749-22-026207:mdna:61]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 664,115 |  |  | $ | 608,816 |  |  | $ | 55,299 |  |  |  | 9.1 | % |
| Commercial & industrial products |  |  | 311,186 |  |  |  | 258,309 |  |  |  | 52,877 |  |  |  | 20.5 | % |
| Other |  |  | 112,957 |  |  |  | 75,573 |  |  |  | 37,384 |  |  |  | 49.5 | % |
| Total net sales |  | $ | 1,088,258 |  |  | $ | 942,698 |  |  | $ | 145,560 |  |  |  | 15.4 | % |

[0001437749-22-026207:mdna:62]
Net sales.    Domestic segment total sales (including inter-segment sales) increased 18.0% to $946.6 million as compared to $802.2 million in the prior year quarter, with the impact of non-annualized acquisitions contributing $64.2 million of the revenue growth for the quarter. Core sales growth was led by C&I product shipments experiencing strong growth across all channels, highlighted by national rental equipment, telecom and industrial distributor customers, with home standby generators also experiencing year-over-year growth in the quarter. This growth was partially offset by lower clean energy product sales.

[0001437749-22-026207:mdna:63]
International segment total sales (including inter-segment sales) increased 14.3% to $182.5 million as compared to $159.8 million in the prior year quarter, with the impact of non-annualized acquisitions and foreign currency providing a $(12.1) million net headwind to revenue growth for the quarter. The core total sales growth for the segment was driven by strong growth across all major regions as compared to the prior year quarter, most notably in Europe.

[0001437749-22-026207:mdna:64]
The net sales contribution from all non-annualized recent acquisitions for the three months ended September 30, 2022 was $67.8 million.

[0001437749-22-026207:mdna:65]
Gross profit.    Gross profit margin for the third quarter of 2022 was 33.2% compared to 35.6% in the prior year third quarter. Continued higher input costs were partially offset by realization of previously implemented pricing actions, resulting in a modest price/cost headwind compared to the prior year. In addition, recent acquisitions and less favorable sales mix negatively impacted margins during the current year quarter.

[0001437749-22-026207:mdna:66]
Operating expenses.   Operating expenses increased $111.2 million, or 68.4%, as compared to the prior year third quarter, including a $37.3 million provision for clean energy product warranty-related matters recorded in selling and service, a $17.9 million provision for bad debt related to a clean energy product customer that has filed for bankruptcy recorded in selling and service, and a $13.5 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and higher marketing spend most notably in the home standby category, which was partially offset by a $8.3 million net gain on contingent acquisition consideration recorded in general and administrative.

[0001437749-22-026207:mdna:67]
Other expense.    The increase in Other expense, net was driven by an increase in interest expense due to increased borrowings, higher interest rates, and additional interest accretion on contingent acquisition consideration in the current year quarter.

[0001437749-22-026207:mdna:68]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2022 and 2021 were 16.1% and 19.7%, respectively. The decrease in the effective tax rate was primarily driven by certain discrete tax items including the unfavorable tax rate adjustment in a foreign jurisdiction increasing the tax expense in the prior year quarter, and a nontaxable adjustment to contingent consideration in the current year quarter. These were partially off-set by a lower tax benefit from the exercise of equity compensation in the current year.

[0001437749-22-026207:mdna:69]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $58.3 million as compared to $131.6 million in the prior year third quarter. This decrease was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-22-026207:mdna:70]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the third quarter of 2022 was $159.8 million, or 16.9% of domestic segment total sales, as compared to $187.7 million, or 23.4% of total sales, in the prior year quarter. This margin performance was impacted by the higher input costs, partially offset by pricing benefits. In addition, continued operating expense investments for future growth and the impact of acquisitions had an unfavorable effect on margins during the quarter, as operating expenses as a percentage of sales came in higher than expected on the lower shipment volumes relative to expectations.

[0001437749-22-026207:mdna:71]
Adjusted EBITDA for the International segment in the third quarter of 2022, before deducting for non-controlling interests, was $24.0 million, or 13.2% of international segment total sales, as compared to $21.5 million, or 13.4% of total sales, in the prior year quarter. This margin performance was impacted by less favorable sales mix, mostly offset by improved operating leverage on higher sales volumes.

[0001437749-22-026207:mdna:72]
Adjusted Net Income.    Adjusted Net Income of $112.2 million for the three months ended September 30, 2022 decreased 25.8% from $151.1 million for the three months ended September 30, 2021. This decrease was primarily driven by decreased net income due to the factors outlined above, partially offset by the impact of various add-backs in the current year quarter.

[0001437749-22-026207:mdna:73]
[same as prior period, unchanged from 0001437749-22-019367:mdna:74]

[0001437749-22-026207:mdna:74]
[same as prior period, unchanged from 0001437749-22-019367:mdna:75]

[0001437749-22-026207:mdna:75]
Nine months ended September 30, 2022 compared to the nine months ended September 30, 2021

[0001437749-22-026207:mdna:76]
[same as prior period, unchanged from 0001437749-22-019367:mdna:77]

[0001437749-22-026207:mdna:77]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |  | $ | 845,392 |  |  |  | 31.7 | % |
| Costs of goods sold |  |  | 2,336,668 |  |  |  | 1,672,570 |  |  |  | 664,098 |  |  |  | 39.7 | % |
| Gross profit |  |  | 1,178,837 |  |  |  | 997,543 |  |  |  | 181,294 |  |  |  | 18.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 388,690 |  |  |  | 229,443 |  |  |  | 159,247 |  |  |  | 69.4 | % |
| Research and development |  |  | 121,328 |  |  |  | 74,897 |  |  |  | 46,431 |  |  |  | 62.0 | % |
| General and administrative |  |  | 132,036 |  |  |  | 115,311 |  |  |  | 16,725 |  |  |  | 14.5 | % |
| Amortization of intangible assets |  |  | 77,681 |  |  |  | 32,237 |  |  |  | 45,444 |  |  |  | 141.0 | % |
| Total operating expenses |  |  | 719,735 |  |  |  | 451,888 |  |  |  | 267,847 |  |  |  | 59.3 | % |
| Income from operations |  |  | 459,102 |  |  |  | 545,655 |  |  |  | (86,553 | ) |  |  | -15.9 | % |
| Total other expense, net |  |  | (38,095 | ) |  |  | (20,707 | ) |  |  | (17,388 | ) |  |  | 84.0 | % |
| Income before provision for income taxes |  |  | 421,007 |  |  |  | 524,948 |  |  |  | (103,941 | ) |  |  | -19.8 | % |
| Provision for income taxes |  |  | 86,028 |  |  |  | 114,341 |  |  |  | (28,313 | ) |  |  | -24.8 | % |
| Net income |  |  | 334,979 |  |  |  | 410,607 |  |  |  | (75,628 | ) |  |  | -18.4 | % |
| Net income attributable to noncontrolling interests |  |  | 6,492 |  |  |  | 3,008 |  |  |  | 3,484 |  |  |  | 115.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 328,487 |  |  | $ | 407,599 |  |  | $ | (79,112 | ) |  |  | -19.4 | % |

[0001437749-22-026207:mdna:78]
[same as prior period, unchanged from 0001437749-22-019367:mdna:79]

[0001437749-22-026207:mdna:79]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,003,237 |  |  | $ | 2,267,648 |  |  | $ | 735,589 |  |  |  | 32.4 | % |
| International |  |  | 512,268 |  |  |  | 402,465 |  |  |  | 109,803 |  |  |  | 27.3 | % |
| Total net sales |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |  | $ | 845,392 |  |  |  | 31.7 | % |

[0001437749-22-026207:mdna:80]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |  | Nine Months Ended September 30, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,003,237 |  |  | $ | 44,742 |  |  | $ | 3,047,979 |  |  | $ | 2,267,648 |  |  | $ | 26,949 |  |  | $ | 2,294,597 |  |
| International |  |  | 512,268 |  |  |  | 59,075 |  |  |  | 571,343 |  |  |  | 402,465 |  |  |  | 16,378 |  |  |  | 418,843 |  |
| Intercompany elimination |  |  | - |  |  |  | (103,817 | ) |  |  | (103,817 | ) |  |  | - |  |  |  | (43,327 | ) |  |  | (43,327 | ) |
| Total net sales |  | $ | 3,515,505 |  |  | $ | - |  |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |  | $ | - |  |  | $ | 2,670,113 |  |

[0001437749-22-026207:mdna:81]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 572,159 |  |  | $ | 598,730 |  |  | $ | (26,571 | ) |  |  | -4.4 | % |
| International |  |  | 79,532 |  |  |  | 42,344 |  |  |  | 37,188 |  |  |  | 87.8 | % |
| Total Adjusted EBITDA |  | $ | 651,691 |  |  | $ | 641,074 |  |  | $ | 10,617 |  |  |  | 1.7 | % |

[0001437749-22-026207:mdna:82]
[same as prior period, unchanged from 0001437749-22-019367:mdna:83]

[0001437749-22-026207:mdna:83]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,337,072 |  |  | $ | 1,750,957 |  |  | $ | 586,115 |  |  |  | 33.5 | % |
| Commercial & industrial products |  |  | 899,263 |  |  |  | 714,994 |  |  |  | 184,269 |  |  |  | 25.8 | % |
| Other |  |  | 279,170 |  |  |  | 204,162 |  |  |  | 75,008 |  |  |  | 36.7 | % |
| Total net sales |  | $ | 3,515,505 |  |  | $ | 2,670,113 |  |  | $ | 845,392 |  |  |  | 31.7 | % |

[0001437749-22-026207:mdna:84]
Net sales.    Domestic segment total sales (including inter-segment sales) increased 32.8% to $3,048.0 million as compared to $2,294.6 million in the prior year period, with the impact of non-annualized acquisitions contributing $147.9 million of the revenue growth for the nine-month period. The core sales growth was led by home standby generators, while C&I channels also experienced strong year-over-year growth, highlighted by national rental equipment and telecom customers and the industrial distributor channel.

[0001437749-22-026207:mdna:85]
International segment total sales (including inter-segment sales) increased 36.4% to $571.3 million as compared to $418.8 million in the prior year period, with the net impact of non-annualized acquisitions and foreign currency contributing $26.9 million of the revenue growth for the nine-month period. The core sales growth for the segment was driven by growth across all major regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-22-026207:mdna:86]
The net sales contribution from all non-annualized recent acquisitions for the nine months ended September 30, 2022 was $205.8 million.

[0001437749-22-026207:mdna:87]
Gross profit.    Gross profit margin for the nine months ended September 30, 2022 was 33.5% compared to 37.4% in the prior year. Gross margins were pressured by higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor.  These higher costs were partially offset by the realization of previously implemented pricing actions. In addition, less favorable sales mix negatively impacted margins during the current year period.

[0001437749-22-026207:mdna:88]
Operating expenses.   Operating expenses increased $267.8 million, or 59.3%, as compared to the prior year, including a $45.4 million increase in acquisition-related amortization expense, a $37.3 million provision for clean energy product warranty-related matters recorded in selling and service, and a $17.9 million provision for bad debt related to a clean energy product customer that has filed bankruptcy recorded in selling and service. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes, which was partially offset by an $11.0 million net gain on contingent acquisition consideration recorded in general and administrative.

[0001437749-22-026207:mdna:89]
Other expense.    The increase in Other expense, net was driven by an increase in interest expense due to increased borrowings, higher interest rates, and interest accretion on contingent acquisition consideration in the current year, as well as a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to our credit agreement refinancing during the current year.

[0001437749-22-026207:mdna:90]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2022 and 2021 were 20.4% and 21.8%, respectively. The decrease in the effective tax rate was primarily driven by certain discrete tax items including the unfavorable tax rate adjustment in a foreign jurisdiction increasing the tax expense in the prior year period and a nontaxable adjustment to contingent consideration in the current year period. These were partially off-set by a lower tax benefit from the exercise of equity compensation in the current year.

[0001437749-22-026207:mdna:91]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $328.5 million as compared to $407.6 million in the prior year period. This reduction was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-22-026207:mdna:92]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $572.2 million, or 18.8% of domestic segment total sales, as compared to $598.7 million, or 26.1% of total sales, in the prior year period. This margin performance was primarily impacted by the higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-026207:mdna:93]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $79.5 million, or 13.9% of international segment total sales, as compared to $42.3 million, or 10.1% of total sales, in the prior year period. This margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on significantly higher sales volumes, partially offset by less favorable sales mix.

[0001437749-22-026207:mdna:94]
Adjusted Net Income.    Adjusted Net Income of $425.3 million for the nine months ended September 30, 2022 decreased 6.9% from $457.1 million for the nine months ended September 30, 2021. This decrease was primarily driven by decreased net income due to the factors outlined above, partially offset by the impact of various add-backs in the current year period.

[0001437749-22-026207:mdna:95]
[same as prior period, unchanged from 0001437749-22-019367:mdna:96]

[0001437749-22-026207:mdna:96]
[same as prior period, unchanged from 0001437749-22-019367:mdna:97]

[0001437749-22-026207:mdna:97]
[same as prior period, unchanged from 0001437749-22-019367:mdna:98]

[0001437749-22-026207:mdna:98]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements also previously provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-22-026207:mdna:99]
In June 2022, we amended and restated the existing credit agreements (Amended Credit Agreement) that established a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1.25 billion (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility, make a $250 million voluntary prepayment on our Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-22-026207:mdna:100]
There are no installment payments required on the Tranche B Term Loan Facility until the maturity date of December 13, 2026.

[0001437749-22-026207:mdna:101]
The Tranche A Term Loan Facility is repayable in quarterly installments in total for the twelve months ended 0.0% of the original principal amount during the fiscal quarters ending June 30, 2022 through and including June 30, 2023, in total for the twelve months ended 2.5% of the original principal amount during the fiscal quarters ending September 30, 2023 through and including June 30, 2024, in total for the twelve months ended 5.0% of the original principal amount during the fiscal quarters ending September 30, 2024 through and including June 30, 2025, in total for the twelve months ended 7.5% of the original principal amount during the fiscal quarters ending September 30, 2025 through and including June 30, 2026, and in total for the twelve months ended 10% of the original principal amount during the fiscal quarters ending September 30, 2026 through and including March 31, 2027, with the remaining principal balance due and payable on the maturity date.

[0001437749-22-026207:mdna:102]
As of September 30, 2022, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and no borrowings outstanding on our Revolving Facility, leaving $1,248.6 million of availability, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Our Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based upon adjusted SOFR plus an applicable margin of 1.5% through December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility will bear interest at a rate based upon adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based upon the Company's total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-22-026207:mdna:103]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of September 30, 2022, our secured leverage ratio was 1.25 to 1.00 times, and we are in compliance with all covenants of the Tranche B Term Loan Facility. Additionally, the Tranche A Term Loan Facility and Revolving Facility added certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of September 30, 2022, our total leverage ratio was 1.33 to 1.00 times, and our interest coverage ratio was 20.81 to 1.00. We are also in compliance with all other covenants of the Amended Credit Agreement as of September 30, 2022.

[0001437749-22-026207:mdna:104]
As of September 30, 2022, we had $1,478.5 million of liquidity comprised of $229.9 million of cash and equivalents and $1,248.6 million available under our Revolving Facility. We believe this strong liquidity position will allow us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-22-026207:mdna:105]
In September 2020, our Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allowed for the repurchase of up to $250 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. That program was exhausted in the third quarter of 2022. In July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the third quarter of 2022, we repurchased 536,633 shares of our common stock for $123.9 million. There were no share repurchases under the program during the first and second quarters of 2022. Additionally, there were no share repurchases under the program during the three and nine months ended September 30, 2021. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 9,563,339 shares of our common stock for $555.4 million (at an average cost per share of $58.08).

[0001437749-22-026207:mdna:106]
[same as prior period, unchanged from 0001437749-22-019367:mdna:107]

[0001437749-22-026207:mdna:107]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. The amount financed by dealers which remained outstanding was $222.4 million and $115.9 million as of September 30, 2022 and December 31, 2021, respectively.

[0001437749-22-026207:mdna:108]
[same as prior period, unchanged from 0001437749-22-019367:mdna:109]

[0001437749-22-026207:mdna:109]
[same as prior period, unchanged from 0001437749-22-019367:mdna:110]

[0001437749-22-026207:mdna:110]
[same as prior period, unchanged from 0001437749-22-019367:mdna:111]

[0001437749-22-026207:mdna:111]
Nine months ended September 30, 2022 compared to the nine months ended September 30, 2021

[0001437749-22-026207:mdna:112]
[same as prior period, unchanged from 0001437749-22-019367:mdna:113]

[0001437749-22-026207:mdna:113]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net cash (used in) provided by operating activities |  | $ | (42,352 | ) |  | $ | 349,404 |  |  | $ | (391,756 | ) |  |  | -112.1 | % |
| Net cash used in investing activities |  |  | (85,082 | ) |  |  | (546,773 | ) |  |  | 461,691 |  |  |  | 84.4 | % |
| Net cash provided by (used in) financing activities |  |  | 214,871 |  |  |  | (33,445 | ) |  |  | 248,316 |  |  |  | 742.5 | % |

[0001437749-22-026207:mdna:114]
The decline in operating cash flow for the nine months ended September 30, 2022, was primarily due to lower operating earnings, increased tax payments, and significantly higher working capital investment in the current year given our substantial growth coupled with the challenging supply chain environment.

[0001437749-22-026207:mdna:115]
Net cash used in investing activities for the nine months ended September 30, 2022 primarily represents cash payments of $64.8 million related to the purchase of property and equipment, $14.9 million for a contribution to an equity method investment,  and $11.4 million related to the acquisition of businesses, which were partially offset by cash proceeds from beneficial interests in securitization transactions of $2.7 million, cash proceeds from the sale of property and equipment of $2.0 million, and cash proceeds from the sale of an investment of $1.3 million. Net cash used in investing activities for the nine months ended September 30, 2021 primarily represents cash payments of $465.9 million related to the acquisition of businesses and $87.5 million related to the purchase of property and equipment, which were partially offset by cash proceeds from the sale of an investment of $5.0 million.

[0001437749-22-026207:mdna:116]
Net cash provided by financing activities for the nine months ended September 30, 2022 primarily represents proceeds of $935.6 million from long-term borrowings, $237.2 million from short-term borrowings, and $13.6 million from the exercise of stock options. These cash proceeds were partially offset by $780.0 million of debt repayments ($239.6 million of short-term borrowings and $540.4 million of long-term borrowings and finance lease obligations), $123.9 million of stock repurchases, $40.5 million of taxes paid related to equity awards, $16.1 million of contingent consideration for acquired businesses, and $10.3 million for payment of debt issuance costs.

[0001437749-22-026207:mdna:117]
Net cash used in financing activities for the nine months ended September 30, 2021 primarily represents $160.1 million of debt repayments ($105.2 million of short-term borrowings and $54.9 million of long-term borrowings and finance lease obligations), $50.0 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of Pramac, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $127.8 million from short-term borrowings, $50.0 million from long-term borrowings, and $30.5 million from the exercise of stock options.

[0001437749-22-026207:mdna:118]
[same as prior period, unchanged from 0001437749-22-019367:mdna:119]

[0001437749-22-026207:mdna:119]
There have been no material changes to our contractual obligations since the February 22, 2022 filing of our Annual Report on Form 10-K for the year ended December 31, 2021, except for the amendment and restatement of our credit agreements as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-22-026207:mdna:120]
[same as prior period, unchanged from 0001437749-22-019367:mdna:121]

[0001437749-22-026207:mdna:121]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2021, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-22-026207:mdna:122]
There have been no material changes in our income taxes and business combinations and purchase accounting critical accounting policies since the February 22, 2022 filing of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001437749-22-026207:mdna:123]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-22-026207:mdna:124]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of October 31) and, if certain events or circumstances indicate that an impairment loss may have been incurred, on an interim basis.  As disclosed in Note 2, "Significant Accounting Policies - Goodwill and Other Indefinite-Lived Intangible Assets," to the consolidated financial statements in Item 8 of our 2021 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of October 31, 2021.

[0001437749-22-026207:mdna:125]
During the three months ended September 30, 2022, the Company identified a triggering event for its clean energy reporting unit requiring an interim impairment assessment to be performed due to the loss of a key customer as well as certain clean energy product warranty-related matters. Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test were based on updated projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows as well as the current discount rate based on the estimated weighted average cost of capital for the business.

[0001437749-22-026207:mdna:126]
Based on the interim impairment assessment as of September 30, 2022, the Company determined that the goodwill and indefinite-lived intangible assets ascribed to the clean energy reporting unit are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the economic environment, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

[0001437749-22-026207:mdna:127]
[same as prior period, unchanged from 0001437749-22-019367:mdna:124]

[0001437749-22-026207:mdna:128]
[same as prior period, unchanged from 0001437749-22-019367:mdna:125]

[0001437749-22-026207:mdna:129]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-22-026207:mdna:130]
[same as prior period, unchanged from 0001437749-22-019367:mdna:127]

[0001437749-22-026207:mdna:131]
[same as prior period, unchanged from 0001437749-22-019367:mdna:128]

[0001437749-22-026207:mdna:132]
[same as prior period, unchanged from 0001437749-22-019367:mdna:129]

[0001437749-22-026207:mdna:133]
[same as prior period, unchanged from 0001437749-22-019367:mdna:130]

[0001437749-22-026207:mdna:134]
[same as prior period, unchanged from 0001437749-22-019367:mdna:131]

[0001437749-22-026207:mdna:135]
[same as prior period, unchanged from 0001437749-22-019367:mdna:132]

[0001437749-22-026207:mdna:136]
[same as prior period, unchanged from 0001437749-22-019367:mdna:133]

[0001437749-22-026207:mdna:137]
[same as prior period, unchanged from 0001437749-22-019367:mdna:134]

[0001437749-22-026207:mdna:138]
[same as prior period, unchanged from 0001437749-22-019367:mdna:135]

[0001437749-22-026207:mdna:139]
[same as prior period, unchanged from 0001437749-22-019367:mdna:136]

[0001437749-22-026207:mdna:140]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-22-026207:mdna:141]
[same as prior period, unchanged from 0001437749-22-019367:mdna:138]

[0001437749-22-026207:mdna:142]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-22-026207:mdna:143]
[same as prior period, unchanged from 0001437749-22-019367:mdna:140]

[0001437749-22-026207:mdna:144]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-22-026207:mdna:145]
[same as prior period, unchanged from 0001437749-22-019367:mdna:142]

[0001437749-22-026207:mdna:146]
[same as prior period, unchanged from 0001437749-22-019367:mdna:143]

[0001437749-22-026207:mdna:147]
[same as prior period, unchanged from 0001437749-22-019367:mdna:144]

[0001437749-22-026207:mdna:148]
[same as prior period, unchanged from 0001437749-22-019367:mdna:145]

[0001437749-22-026207:mdna:149]
[same as prior period, unchanged from 0001437749-22-019367:mdna:146]

[0001437749-22-026207:mdna:150]
[same as prior period, unchanged from 0001437749-22-019367:mdna:147]

[0001437749-22-026207:mdna:151]
[same as prior period, unchanged from 0001437749-22-019367:mdna:148]

[0001437749-22-026207:mdna:152]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-22-026207:mdna:153]
[same as prior period, unchanged from 0001437749-22-019367:mdna:150]

[0001437749-22-026207:mdna:154]
[same as prior period, unchanged from 0001437749-22-019367:mdna:151]

[0001437749-22-026207:mdna:155]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 6,492 |  |  |  | 3,008 |  |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | 334,979 |  |  |  | 410,607 |  |
| Interest expense |  |  | 15,514 |  |  |  | 7,980 |  |  |  | 35,303 |  |  |  | 23,424 |  |
| Depreciation and amortization |  |  | 39,165 |  |  |  | 23,216 |  |  |  | 116,724 |  |  |  | 62,682 |  |
| Provision for income taxes |  |  | 11,594 |  |  |  | 32,611 |  |  |  | 86,028 |  |  |  | 114,341 |  |
| Non-cash write-down and other adjustments (a) |  |  | (6,840 | ) |  |  | 3,333 |  |  |  | (10,025 | ) |  |  | 638 |  |
| Non-cash share-based compensation expense (b) |  |  | 6,861 |  |  |  | 5,783 |  |  |  | 23,423 |  |  |  | 18,204 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (d) |  |  | 1,250 |  |  |  | 3,385 |  |  |  | 3,831 |  |  |  | 9,471 |  |
| Business optimization and other charges (e) |  |  | 622 |  |  |  | - |  |  |  | 3,371 |  |  |  | 159 |  |
| Provision for clean energy product charges (f) |  |  | 55,265 |  |  |  | - |  |  |  | 55,265 |  |  |  |  |  |
| Other |  |  | (61 | ) |  |  | 140 |  |  |  | (951 | ) |  |  | 717 |  |
| Adjusted EBITDA |  |  | 183,816 |  |  |  | 209,201 |  |  |  | 651,691 |  |  |  | 641,074 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,632 |  |  |  | 2,247 |  |  |  | 10,799 |  |  |  | 6,454 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 180,184 |  |  | $ | 206,954 |  |  | $ | 640,892 |  |  | $ | 634,620 |  |

[0001437749-22-026207:mdna:156]
[same as prior period, unchanged from 0001437749-22-019367:mdna:153]

[0001437749-22-026207:mdna:157]
[same as prior period, unchanged from 0001437749-22-019367:mdna:154]

[0001437749-22-026207:mdna:158]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |
|  | ● | Purchase accounting and contingent consideration related adjustments relate to the acquisition of businesses and the accounting related to those acquisitions. |

[0001437749-22-026207:mdna:159]
[same as prior period, unchanged from 0001437749-22-019367:mdna:156]

[0001437749-22-026207:mdna:160]
[same as prior period, unchanged from 0001437749-22-019367:mdna:157]

[0001437749-22-026207:mdna:161]
(d)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-22-026207:mdna:162]
(e)  The current year periods predominantly represent severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-22-026207:mdna:163]
(f)  Represents a specific credit loss provision of $17.9 million for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters.

[0001437749-22-026207:mdna:164]
[same as prior period, unchanged from 0001437749-22-019367:mdna:160]

[0001437749-22-026207:mdna:165]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses or charges, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-22-026207:mdna:166]
[same as prior period, unchanged from 0001437749-22-019367:mdna:162]

[0001437749-22-026207:mdna:167]
[same as prior period, unchanged from 0001437749-22-019367:mdna:163]

[0001437749-22-026207:mdna:168]
[same as prior period, unchanged from 0001437749-22-019367:mdna:164]

[0001437749-22-026207:mdna:169]
[same as prior period, unchanged from 0001437749-22-019367:mdna:165]

[0001437749-22-026207:mdna:170]
[same as prior period, unchanged from 0001437749-22-019367:mdna:166]

[0001437749-22-026207:mdna:171]
[same as prior period, unchanged from 0001437749-22-019367:mdna:167]

[0001437749-22-026207:mdna:172]
[same as prior period, unchanged from 0001437749-22-019367:mdna:168]

[0001437749-22-026207:mdna:173]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 58,270 |  |  | $ | 131,570 |  |  | $ | 328,487 |  |  | $ | 407,599 |  |
| Net income attributable to noncontrolling interests |  |  | 2,176 |  |  |  | 1,183 |  |  |  | 6,492 |  |  |  | 3,008 |  |
| Net income |  |  | 60,446 |  |  |  | 132,753 |  |  |  | 334,979 |  |  |  | 410,607 |  |
| Provision for income taxes (a) |  |  | - |  |  |  | 32,611 |  |  |  | - |  |  |  | 114,341 |  |
| Amortization of intangible assets |  |  | 25,751 |  |  |  | 12,206 |  |  |  | 77,681 |  |  |  | 32,237 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 974 |  |  |  | 646 |  |  |  | 2,261 |  |  |  | 1,941 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (b) |  |  | (7,605 | ) |  |  | 5,487 |  |  |  | (7,651 | ) |  |  | 11,130 |  |
| (Gain)/loss attributable to business or asset dispositions (c) |  |  | - |  |  |  | - |  |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges |  |  | 622 |  |  |  | - |  |  |  | 3,371 |  |  |  | 159 |  |
| Provision for clean energy product charges (d) |  |  | 55,265 |  |  |  | - |  |  |  | 55,265 |  |  |  | - |  |
| Tax effect of add backs (e) |  |  | (21,233 | ) |  |  | - |  |  |  | (36,907 | ) |  |  | - |  |
| Cash income tax expense (a) |  |  | - |  |  |  | (31,290 | ) |  |  | - |  |  |  | (106,564 | ) |
| Adjusted net income |  |  | 114,220 |  |  |  | 152,413 |  |  |  | 432,513 |  |  |  | 460,691 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 2,031 |  |  |  | 1,272 |  |  |  | 7,199 |  |  |  | 3,616 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 112,189 |  |  | $ | 151,141 |  |  | $ | 425,314 |  |  | $ | 457,075 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.75 |  |  | $ | 2.35 |  |  | $ | 6.58 |  |  | $ | 7.13 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,267,638 |  |  |  | 64,208,116 |  |  |  | 64,630,346 |  |  |  | 64,146,281 |  |

[0001437749-22-026207:mdna:174]
(a) Amount for the three and nine months ended September 30, 2021 is based on an anticipated cash income tax rate at the time of approximately 20.0% to 20.5% for the full year ended December 31, 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP income tax expense for the three and nine months ended September 30, 2021 would result in an adjusted net income per diluted share of $2.25 and $6.83, respectively, on a pro forma basis.

[0001437749-22-026207:mdna:175]
(b) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-22-026207:mdna:176]
(c) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-22-026207:mdna:177]
(d) Represents a specific credit loss provision of $17.9 million for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters.

[0001437749-22-026207:mdna:178]
(e) In the third quarter of 2022, management determined that certain add-backs in 2022 should be reported net of tax. Add-backs in the first and second quarter of 2022 were not reported net of tax, and we reported adjusted net income attributable to Generac Holdings Inc. for the first and second quarters ended 2022 of $135,271 or $2.09 and $193,528 or $2.99, respectively. Taking into account the tax effect on certain add-backs, the revised reported adjusted net income attributable to Generac Holdings Inc. for the first and second quarters ended 2022 is $128,150 or $1.98 and $185,270 or $2.86, respectively.

[0001437749-22-026207:mdna:179]
[same as prior period, unchanged from 0001437749-22-019367:mdna:173]

[0001437749-22-026207:mdna:180]
[same as prior period, unchanged from 0001437749-22-019367:mdna:174]
