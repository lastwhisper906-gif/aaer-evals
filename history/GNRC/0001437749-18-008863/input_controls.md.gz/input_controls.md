# GNRC 10-Q controls and the auditor's report


## item_4_controls

[0001437749-18-008863:item_4_controls:1]
Item 4.           Controls and Procedures

[0001437749-18-008863:item_4_controls:2]
Disclosure Controls and Procedures

[0001437749-18-008863:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) or 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended, or the Exchange Act. Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0001437749-18-008863:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001437749-18-008863:item_4_controls:5]
Beginning January 1, 2018, we implemented ASU 2014-09 Revenue from Contracts with Customers (Topic 606) and ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of Effective Date. Although the adoption of the new revenue standard did not have a significant impact on our results of operations, cash flows, or financial position, we did implement changes to our controls related to revenue. These included the development of new policies based on the five-step model provided in the new revenue standard, enhanced contract review requirements, and other ongoing monitoring activities. These controls were designed to provide assurance at a reasonable level of the fair presentation of our condensed consolidated financial statements and related disclosures.

[0001437749-18-008863:item_4_controls:6]
There have been no other changes during the three months ended March 31, 2018 in our internal control over financial reporting (as defined in Exchange Act Rule 13a-15(f)) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
