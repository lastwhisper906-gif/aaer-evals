# GNRC MD&A — 0001437749-18-008863


## mdna

[0001437749-18-008863:mdna:1]
[same as prior period, unchanged from 0001437749-17-018410:mdna:1]

[0001437749-18-008863:mdna:2]
This quarterly report contains forward-looking statements that are subject to risks and uncertainties. Forward-looking statements give our current expectations and projections relating to our financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as “anticipate,” “estimate,” “expect,” “forecast,” “project,” “plan,” “intend,” “believe,” “confident,” “may,” “should,” “can have,” “likely,” “future,” “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-18-008863:mdna:3]
[same as prior period, unchanged from 0001437749-17-018410:mdna:3]

[0001437749-18-008863:mdna:4]
[same as prior period, unchanged from 0001437749-17-018410:mdna:4]

[0001437749-18-008863:mdna:5]
[same as prior period, unchanged from 0001437749-17-018410:mdna:5]

[0001437749-18-008863:mdna:6]
[same as prior period, unchanged from 0001437749-17-018410:mdna:6]

[0001437749-18-008863:mdna:7]
[same as prior period, unchanged from 0001437749-17-018410:mdna:7]

[0001437749-18-008863:mdna:8]
[same as prior period, unchanged from 0001437749-17-018410:mdna:8]

[0001437749-18-008863:mdna:9]
[same as prior period, unchanged from 0001437749-17-018410:mdna:9]

[0001437749-18-008863:mdna:10]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities and product mix; |

[0001437749-18-008863:mdna:11]
[same as prior period, unchanged from 0001437749-17-018410:mdna:11]

[0001437749-18-008863:mdna:12]
[same as prior period, unchanged from 0001437749-17-018410:mdna:12]

[0001437749-18-008863:mdna:13]
[same as prior period, unchanged from 0001437749-17-018410:mdna:13]

[0001437749-18-008863:mdna:14]
[same as prior period, unchanged from 0001437749-17-018410:mdna:15]

[0001437749-18-008863:mdna:15]
[same as prior period, unchanged from 0001437749-17-018410:mdna:16]

[0001437749-18-008863:mdna:16]
[same as prior period, unchanged from 0001437749-17-018410:mdna:17]

[0001437749-18-008863:mdna:17]
[same as prior period, unchanged from 0001437749-17-018410:mdna:18]

[0001437749-18-008863:mdna:18]
[same as prior period, unchanged from 0001437749-17-018410:mdna:19]

[0001437749-18-008863:mdna:19]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2017. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-18-008863:mdna:20]
[same as prior period, unchanged from 0001437749-17-018410:mdna:21]

[0001437749-18-008863:mdna:21]
We are a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-18-008863:mdna:22]
Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q, and in Item 8 (Note 1 “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-008863:mdna:23]
Recent Developments

[0001437749-18-008863:mdna:24]
On February 13, 2018, we signed a purchase agreement to acquire Selmec Equipos Industriales, S.A. de C.V. (Selmec), which is headquartered in Mexico City, Mexico. Selmec, which has approximately 300 employees, is a designer and manufacturer of industrial generators ranging from 10 kW to 2,750 kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. The transaction is expected to close following receipt of required regulatory approval.

[0001437749-18-008863:mdna:25]
[same as prior period, unchanged from 0001437749-17-018410:mdna:24]

[0001437749-18-008863:mdna:26]
[same as prior period, unchanged from 0001437749-17-018410:mdna:25]

[0001437749-18-008863:mdna:27]
[same as prior period, unchanged from 0001437749-17-018410:mdna:26]

[0001437749-18-008863:mdna:28]
[same as prior period, unchanged from 0001437749-17-018410:mdna:27]

[0001437749-18-008863:mdna:29]
Increasing penetration opportunity. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result, these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas-fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-18-008863:mdna:30]
Effect of large scale and baseline power disruptions. Power disruptions are an important driver of customer awareness and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in 2017 and the first quarter of 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-18-008863:mdna:31]
Impact of residential investment cycle. The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-18-008863:mdna:32]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment. We believe the passage of the Tax Act in late 2017 could have a favorable impact on future demand within many of the end markets that we serve, as the improved cash flow, liquidity and business sentiment may lead to further investments in equipment, facilities and infrastructure in the United States.

[0001437749-18-008863:mdna:33]
[same as prior period, unchanged from 0001437749-17-018410:mdna:32]

[0001437749-18-008863:mdna:34]
[same as prior period, unchanged from 0001437749-17-018410:mdna:33]

[0001437749-18-008863:mdna:35]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These acquisitions, along with our existing international presence and global supply chain, expose us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-18-008863:mdna:36]
[same as prior period, unchanged from 0001437749-17-018410:mdna:35]

[0001437749-18-008863:mdna:37]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 20% to 27% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods when no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-18-008863:mdna:38]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Cash interest expense decreased during the three months ended March 31, 2018 compared to the three months ended March 31, 2017, primarily due to lower interest rates resulting from the May and December 2017 Term Loan amendments and the repayment of $100 million of ABL Facility borrowings, partially offset by increased borrowings at other subsidiaries and an increase in the market LIBOR rate. Refer to Note 10, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-18-008863:mdna:39]
Factors influencing provision for income taxes and cash income taxes paid.   The Tax Act significantly changes how the U.S. taxes corporations. The Tax Act requires complex computations to be performed that were not previously required in U.S. tax law, significant judgments to be made in interpretation of the provisions of the Tax Act and significant estimates in calculations, and the preparation and analysis of information not previously relevant or regularly produced. The U.S. Treasury Department, the IRS, and other standard-setting bodies could interpret or issue guidance on how provisions of the Tax Act will be applied or otherwise administered that is different from our interpretation.

[0001437749-18-008863:mdna:40]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. While the Company continues to assess the full impact of the Tax Act, the preliminary analysis suggests a meaningful benefit from the legislation. Specifically for 2018, the combined federal and state effective tax rate is expected to decline to between 25 to 26%, resulting in lower cash income taxes. As we complete our analysis of the Tax Act, collect and prepare necessary data, and interpret any additional guidance, we may make adjustments to provisional amounts that we have recorded that may materially impact our provision for income taxes in the period in which the adjustments are made. Refer to Note 13, “Income Taxes,” to the consolidated financial statements in Item 8 of the Annual Report on Form 10-K for the year ended December 31, 2017 for further information on the Tax Act and its impact.

[0001437749-18-008863:mdna:41]
Further, we had approximately $470 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2017 related to our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $122 million through 2021, assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $61 million from prior estimates due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The amortization of these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $32 million through 2020 and $26 million in 2021, assuming profitability and a 26% combined federal and state tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $34 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2017. We expect these assets to generate aggregate cash tax savings of $9.0 million through 2026 assuming continued profitability and a 26% combined federal and state tax rate. The aggregate cash tax savings reflects a decrease of $4.5 million due to a reduction in the assumed tax rate from 39% to 26% as a result of the Tax Act. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.0 million through 2025 and $0.7 million in 2026, assuming profitability and a 26% combined federal and state tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-18-008863:mdna:42]
[same as prior period, unchanged from 0001437749-17-018410:mdna:39]

[0001437749-18-008863:mdna:43]
Three months ended March 31, 2018 compared to the three months ended March 31, 2017

[0001437749-18-008863:mdna:44]
[same as prior period, unchanged from 0001437749-17-018410:mdna:41]

[0001437749-18-008863:mdna:45]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |  | $ | 67,149 |  |  |  | 20.3 | % |
| Cost of goods sold |  |  | 257,645 |  |  |  | 221,685 |  |  |  | 35,960 |  |  |  | 16.2 | % |
| Gross profit |  |  | 139,989 |  |  |  | 108,800 |  |  |  | 31,189 |  |  |  | 28.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 42,682 |  |  |  | 39,467 |  |  |  | 3,215 |  |  |  | 8.1 | % |
| Research and development |  |  | 11,853 |  |  |  | 10,287 |  |  |  | 1,566 |  |  |  | 15.2 | % |
| General and administrative |  |  | 23,475 |  |  |  | 20,973 |  |  |  | 2,502 |  |  |  | 11.9 | % |
| Amortization of intangible assets |  |  | 5,632 |  |  |  | 7,183 |  |  |  | (1,551 | ) |  |  | -21.6 | % |
| Total operating expenses |  |  | 83,642 |  |  |  | 77,910 |  |  |  | 5,732 |  |  |  | 7.4 | % |
| Income from operations |  |  | 56,347 |  |  |  | 30,890 |  |  |  | 25,457 |  |  |  | 82.4 | % |
| Total other income (expense), net |  |  | (11,161 | ) |  |  | (10,885 | ) |  |  | (276 | ) |  |  | 2.5 | % |
| Income before provision for income taxes |  |  | 45,186 |  |  |  | 20,005 |  |  |  | 25,181 |  |  |  | 125.9 | % |
| Provision for income taxes |  |  | 11,416 |  |  |  | 7,823 |  |  |  | 3,593 |  |  |  | 45.9 | % |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |  |  | 21,588 |  |  |  | 177.2 | % |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |  |  | 118 |  |  |  | 1685.7 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |  |  | 21,470 |  |  |  | 176.3 | % |

[0001437749-18-008863:mdna:46]
[same as prior period, unchanged from 0001437749-17-018410:mdna:43]

[0001437749-18-008863:mdna:47]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 300,219 |  |  | $ | 247,168 |  |  |  | 53,051 |  |  |  | 21.5 | % |
| International |  |  | 97,415 |  |  |  | 83,317 |  |  |  | 14,098 |  |  |  | 16.9 | % |
| Total net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |  |  | 67,149 |  |  |  | 20.3 | % |

[0001437749-18-008863:mdna:48]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 65,475 |  |  | $ | 41,891 |  |  |  | 23,584 |  |  |  | 56.3 | % |
| International |  |  | 6,306 |  |  |  | 4,812 |  |  |  | 1,494 |  |  |  | 31.0 | % |
| Total Adjusted EBITDA |  | $ | 71,781 |  |  | $ | 46,703 |  |  |  | 25,078 |  |  |  | 53.7 | % |

[0001437749-18-008863:mdna:49]
[same as prior period, unchanged from 0001437749-17-018410:mdna:47]

[0001437749-18-008863:mdna:50]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 190,474 |  |  | $ | 154,217 |  |  |  | 36,257 |  |  |  | 23.5 | % |
| Commercial & industrial products |  |  | 175,125 |  |  |  | 150,753 |  |  |  | 24,372 |  |  |  | 16.2 | % |
| Other |  |  | 32,035 |  |  |  | 25,515 |  |  |  | 6,520 |  |  |  | 25.6 | % |
| Total net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |  |  | 67,149 |  |  |  | 20.3 | % |

[0001437749-18-008863:mdna:51]
Net sales.    The increase in Domestic sales for the three months ended March 31, 2018 was primarily due to strong growth in shipments of home standby and portable generators driven by increased power outage activity in recent quarters, along with the continuation of significant growth for C&I mobile products given the on-going replacement cycle for these products. Also contributing to the year-over-year sales growth were increases in service parts.

[0001437749-18-008863:mdna:52]
The increase in International sales for the three months ended March 31, 2018 was primarily due to the favorable impact of the stronger Euro along with some broad-based organic growth from the Pramac, Ottomotores and Motortech businesses.

[0001437749-18-008863:mdna:53]
Gross profit.    Gross profit margin for the first quarter of 2018 was 35.2% compared to 32.9% in the prior-year first quarter. The improvement was most notably due to favorable pricing and mix impacts along with improved leverage of fixed manufacturing costs on the significant increase in sales, which were partially offset by higher commodity prices.

[0001437749-18-008863:mdna:54]
Operating expenses.   The increase in operating expenses was primarily driven by an increase in employee costs including higher incentive compensation along with a stronger Euro, partially offset by lower promotional costs benefitting from the higher power outage environment as well as lower intangible asset amortization.

[0001437749-18-008863:mdna:55]
Other expense.    Other expense, net was roughly flat compared to prior year due to higher non-operating expenses mostly offset by a decrease in interest expense.

[0001437749-18-008863:mdna:56]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2018 and 2017 were 25.3% and 39.1%, respectively. The decrease in the effective income tax rate in 2018 was primarily due to a reduction in the US federal corporate tax rate as a result of the Tax Act enacted on December 22, 2017.

[0001437749-18-008863:mdna:57]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate recorded during the current year quarter.

[0001437749-18-008863:mdna:58]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $65.5 million, or 21.8% of net sales, as compared to $41.9 million in the prior year, or 16.9% of net sales. Adjusted EBITDA margin in the current year benefitted from a favorable pricing environment including lower promotional costs, favorable product mix and improved overall leverage of fixed operating costs on the higher organic sales volumes. These impacts were partially offset by higher commodity prices and an increase in employee costs including higher incentive compensation.

[0001437749-18-008863:mdna:59]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, improved to $6.3 million, or 6.5% of net sales, as compared to $4.8 million, or 5.8% of net sales, in the prior year. The improvement in adjusted EBITDA margin as compared to the prior year was primarily due to favorable sales mix and increased leverage of fixed operating costs on the increase in organic sales. These favorable impacts were partially offset by higher commodity prices along with the costs of expansion of certain branch operations.

[0001437749-18-008863:mdna:60]
Adjusted Net Income.    Adjusted Net Income of $46.1 million for the three months ended March 31, 2018 increased 86.6% from $24.7 million for the three months ended March 31, 2017, due to the factors outlined above partially offset by an increase in cash income tax expense.

[0001437749-18-008863:mdna:61]
[same as prior period, unchanged from 0001437749-17-018410:mdna:60]

[0001437749-18-008863:mdna:62]
[same as prior period, unchanged from 0001437749-17-018410:mdna:81]

[0001437749-18-008863:mdna:63]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-18-008863:mdna:64]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility that could be utilized in the future if needed. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2018, the Company’s secured leverage ratio was 2.47 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-18-008863:mdna:65]
Our credit agreements also provide for the $250.0 million ABL Facility. The maturity date of the ABL Facility is May 29, 2020. As of March 31, 2018, there were no borrowings outstanding and $234.2 million of availability under the ABL Facility, net of outstanding letters of credit. The Company is in compliance with all covenants of the ABL Facility.

[0001437749-18-008863:mdna:66]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. Since the inception of both programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand. For the three months ended March 31, 2018, the Company repurchased 560,000 shares of its common stock for $25.7 million. There were no share repurchases during the three months ended March 31, 2017.

[0001437749-18-008863:mdna:67]
See Note 10, “Credit Agreements” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-18-008863:mdna:68]
[same as prior period, unchanged from 0001437749-17-018410:mdna:88]

[0001437749-18-008863:mdna:69]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-18-008863:mdna:70]
[same as prior period, unchanged from 0001437749-17-018410:mdna:90]

[0001437749-18-008863:mdna:71]
Three months ended March 31, 2018 compared to the three months ended March 31, 2017

[0001437749-18-008863:mdna:72]
[same as prior period, unchanged from 0001437749-17-018410:mdna:92]

[0001437749-18-008863:mdna:73]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net cash (used in) provided by operating activities |  | $ | 28,968 |  |  | $ | (5,175 | ) |  | $ | 34,143 |  |  |  | 659.8 | % |
| Net cash used in investing activities |  |  | (5,997 | ) |  |  | (1,274 | ) |  |  | (4,723 | ) |  |  | 370.7 | % |
| Net cash used in financing activities |  |  | (16,200 | ) |  |  | (4,764 | ) |  |  | (11,436 | ) |  |  | 240.1 | % |

[0001437749-18-008863:mdna:74]
20

[0001437749-18-008863:mdna:75]
The increase in net cash from operating activities was driven by a variety of factors including the increase in operating earnings as compared to the prior year and lower working capital usage during the current year.

[0001437749-18-008863:mdna:76]
Net cash used in investing activities for the three months ended March 31, 2018 primarily represents cash payments for the purchase of property and equipment. Net cash used in investing activities for the three months ended March 31, 2017 primarily represents cash payments for the purchase of property and equipment partially offset by cash acquired in the acquisition of a business.

[0001437749-18-008863:mdna:77]
Net cash used in financing activities for the three months ended March 31, 2018 primarily represents $14.3 million of cash proceeds from short-term borrowings, partially offset by $4.3 million of debt repayments ($3.9 million of short-term borrowings and $0.4 million of long-term borrowings and capital lease obligations), as well as $25.7 million cash used for stock repurchases under previously announced stock repurchase programs.

[0001437749-18-008863:mdna:78]
Net cash used in financing activities for the three months ended March 31, 2017 primarily represents $36.2 million of debt repayments ($35.2 million of short-term borrowings and $1.0 million of long-term borrowings and capital lease obligations), partially offset by $32.3 million cash proceeds from borrowings ($31.0 million short-term and $1.3 million long-term).

[0001437749-18-008863:mdna:79]
[same as prior period, unchanged from 0001437749-17-018410:mdna:98]

[0001437749-18-008863:mdna:80]
There have been no material changes to our contractual obligations since the February 26, 2018 filing of our Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-008863:mdna:81]
[same as prior period, unchanged from 0001437749-17-018410:mdna:100]

[0001437749-18-008863:mdna:82]
There have been no material changes to off-balance sheet arrangements since the February 26, 2018 filing of our Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-008863:mdna:83]
[same as prior period, unchanged from 0001437749-17-018410:mdna:102]

[0001437749-18-008863:mdna:84]
There have been no material changes in our critical accounting policies since the February 26, 2018 filing of our Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-008863:mdna:85]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2017, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-18-008863:mdna:86]
[same as prior period, unchanged from 0001437749-17-018410:mdna:105]

[0001437749-18-008863:mdna:87]
[same as prior period, unchanged from 0001437749-17-018410:mdna:106]

[0001437749-18-008863:mdna:88]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement, as amended. To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-18-008863:mdna:89]
[same as prior period, unchanged from 0001437749-17-018410:mdna:108]

[0001437749-18-008863:mdna:90]
[same as prior period, unchanged from 0001437749-17-018410:mdna:109]

[0001437749-18-008863:mdna:91]
[same as prior period, unchanged from 0001437749-17-018410:mdna:110]

[0001437749-18-008863:mdna:92]
|  | • | as one component for the determination of bonus compensation for our senior executives under our management incentive plan, as described further in our 2018 Proxy Statement; |

[0001437749-18-008863:mdna:93]
[same as prior period, unchanged from 0001437749-17-018410:mdna:112]

[0001437749-18-008863:mdna:94]
[same as prior period, unchanged from 0001437749-17-018410:mdna:113]

[0001437749-18-008863:mdna:95]
[same as prior period, unchanged from 0001437749-17-018410:mdna:114]

[0001437749-18-008863:mdna:96]
[same as prior period, unchanged from 0001437749-17-018410:mdna:115]

[0001437749-18-008863:mdna:97]
[same as prior period, unchanged from 0001437749-17-018410:mdna:116]

[0001437749-18-008863:mdna:98]
[same as prior period, unchanged from 0001437749-17-018410:mdna:117]

[0001437749-18-008863:mdna:99]
[same as prior period, unchanged from 0001437749-17-018410:mdna:118]

[0001437749-18-008863:mdna:100]
[same as prior period, unchanged from 0001437749-17-018410:mdna:119]

[0001437749-18-008863:mdna:101]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-18-008863:mdna:102]
[same as prior period, unchanged from 0001437749-17-018410:mdna:121]

[0001437749-18-008863:mdna:103]
We explain in more detail in footnotes (a) through (d) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-18-008863:mdna:104]
[same as prior period, unchanged from 0001437749-17-018410:mdna:123]

[0001437749-18-008863:mdna:105]
[same as prior period, unchanged from 0001437749-17-018410:mdna:124]

[0001437749-18-008863:mdna:106]
[same as prior period, unchanged from 0001437749-17-018410:mdna:125]

[0001437749-18-008863:mdna:107]
[same as prior period, unchanged from 0001437749-17-018410:mdna:126]

[0001437749-18-008863:mdna:108]
[same as prior period, unchanged from 0001437749-17-018410:mdna:127]

[0001437749-18-008863:mdna:109]
[same as prior period, unchanged from 0001437749-17-018410:mdna:128]

[0001437749-18-008863:mdna:110]
[same as prior period, unchanged from 0001437749-17-018410:mdna:129]

[0001437749-18-008863:mdna:111]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-18-008863:mdna:112]
[same as prior period, unchanged from 0001437749-17-018410:mdna:131]

[0001437749-18-008863:mdna:113]
[same as prior period, unchanged from 0001437749-17-018410:mdna:133]

[0001437749-18-008863:mdna:114]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |
| Interest expense |  |  | 10,113 |  |  |  | 10,788 |  |
| Depreciation and amortization |  |  | 11,683 |  |  |  | 12,597 |  |
| Provision for income taxes |  |  | 11,416 |  |  |  | 7,823 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,306 |  |  |  | 166 |  |
| Non-cash share-based compensation expense (b) |  |  | 3,106 |  |  |  | 2,632 |  |
| Transaction costs and credit facility fees (c) |  |  | 262 |  |  |  | 316 |  |
| Business optimization expenses (d) |  |  | 138 |  |  |  | 100 |  |
| Other |  |  | (13 | ) |  |  | 99 |  |
| Adjusted EBITDA |  |  | 71,781 |  |  |  | 46,703 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,549 |  |  |  | 956 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 70,232 |  |  | $ | 45,747 |  |

[0001437749-18-008863:mdna:115]
(a)   Represents the following non-cash charges: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, transactional foreign currency gains/losses and certain purchase accounting related adjustments. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-18-008863:mdna:116]
[same as prior period, unchanged from 0001437749-17-018410:mdna:137]

[0001437749-18-008863:mdna:117]
[same as prior period, unchanged from 0001437749-17-018410:mdna:138]

[0001437749-18-008863:mdna:118]
[same as prior period, unchanged from 0001437749-17-018410:mdna:139]

[0001437749-18-008863:mdna:119]
(b)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-18-008863:mdna:120]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-18-008863:mdna:121]
(d) For the three months ended March 31, 2018, represents severance and other non-recurring restructuring charges. For the three months ended March 31, 2017, represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-18-008863:mdna:122]
[same as prior period, unchanged from 0001437749-17-018410:mdna:144]

[0001437749-18-008863:mdna:123]
[same as prior period, unchanged from 0001437749-17-018410:mdna:145]

[0001437749-18-008863:mdna:124]
[same as prior period, unchanged from 0001437749-17-018410:mdna:146]

[0001437749-18-008863:mdna:125]
[same as prior period, unchanged from 0001437749-17-018410:mdna:147]

[0001437749-18-008863:mdna:126]
[same as prior period, unchanged from 0001437749-17-018410:mdna:148]

[0001437749-18-008863:mdna:127]
[same as prior period, unchanged from 0001437749-17-018410:mdna:149]

[0001437749-18-008863:mdna:128]
[same as prior period, unchanged from 0001437749-17-018410:mdna:150]

[0001437749-18-008863:mdna:129]
[same as prior period, unchanged from 0001437749-17-018410:mdna:151]

[0001437749-18-008863:mdna:130]
[same as prior period, unchanged from 0001437749-17-018410:mdna:152]

[0001437749-18-008863:mdna:131]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |
| Provision for income taxes |  |  | 11,416 |  |  |  | 7,823 |  |
| Income before provision for income taxes |  |  | 45,186 |  |  |  | 20,005 |  |
| Amortization of intangible assets |  |  | 5,632 |  |  |  | 7,183 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,177 |  |  |  | 490 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 20 |  |  |  | 585 |  |
| Business optimization expenses |  |  | 138 |  |  |  | 100 |  |
| Adjusted net income before provision for income taxes |  |  | 52,153 |  |  |  | 28,363 |  |
| Cash income tax expense (b) |  |  | (5,410 | ) |  |  | (3,087 | ) |
| Adjusted net income |  |  | 46,743 |  |  |  | 25,276 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 661 |  |  |  | 582 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 46,082 |  |  | $ | 24,694 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.74 |  |  | $ | 0.39 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,474,936 |  |  |  | 62,936,126 |  |

[0001437749-18-008863:mdna:132]
[same as prior period, unchanged from 0001437749-17-018410:mdna:154]

[0001437749-18-008863:mdna:133]
(b) Amount for the three months ended March 31, 2018 is based on an anticipated cash income tax rate at that time of approximately 13% for the full year ended 2018. Amount for the three months ended March 31, 2017 is based on an anticipated cash income tax rate at that time of approximately 15% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-18-008863:mdna:134]
[same as prior period, unchanged from 0001437749-17-018410:mdna:156]

[0001437749-18-008863:mdna:135]
[same as prior period, unchanged from 0001437749-17-018410:mdna:157]
