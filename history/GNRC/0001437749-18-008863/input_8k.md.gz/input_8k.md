# GNRC 8-K — 0001437749-18-008304 filed 2018-05-02

## item codes, every 8-K on or before 2018-05-07

- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2018-05-07

- none on or before 2018-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-008304:8k_2_02:1]
EX-99.1
2
ex_112173.htm
EXHIBIT 99.1

[0001437749-18-008304:8k_2_02:2]
ex_112173.htm

[0001437749-18-008304:8k_2_02:3]
Exhibit 99.1

[0001437749-18-008304:8k_2_02:4]
Generac Reports First Quarter 2018 Results

[0001437749-18-008304:8k_2_02:5]
Strong growth in sales, margins and cash flow compared to prior year; Raising outlook for 2018

[0001437749-18-008304:8k_2_02:6]
WAUKESHA, WISCONSIN, (May 2, 2018) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its first quarter ended March 31, 2018.

[0001437749-18-008304:8k_2_02:7]
First Quarter 2018 Highlights

[0001437749-18-008304:8k_2_02:8]
| ● | Net sales increased organically 20.3% to $397.6 million during the first quarter of 2018 as compared to $330.5 million in the prior-year first quarter. Core sales growth, which also excludes the impact of foreign currency, was approximately 17%. |

[0001437749-18-008304:8k_2_02:9]
| ● | Gross profit margin improved 230 basis points to 35.2% as compared to 32.9% in the first quarter of 2017. |

[0001437749-18-008304:8k_2_02:10]
| ● | Net income attributable to the Company during the first quarter was $33.6 million, or $0.42 per share, as compared to $12.2 million, or $0.20 per share, for the same period of 2017. |

[0001437749-18-008304:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $46.1 million, or $0.74 per share, as compared to $24.7 million, or $0.39 per share, in the first quarter of 2017. |

[0001437749-18-008304:8k_2_02:12]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $70.2 million as compared to $45.7 million in the first quarter last year. |

[0001437749-18-008304:8k_2_02:13]
| ● | Cash flow from operations was $29.0 million as compared to ($5.2) million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $23.3 million as compared to ($8.1) million in the first quarter of 2017. |

[0001437749-18-008304:8k_2_02:14]
| ● | The Company repurchased 560,000 shares of its common stock during the first quarter for $25.7 million under its current share repurchase program. |

[0001437749-18-008304:8k_2_02:15]
| ● | As previously disclosed in a separate press release on February 13, 2018, the Company entered into a purchase agreement to acquire the shares of Selmec Equipos Industriales, S.A. de C.V., a leading generator manufacturer and services company headquartered in Mexico City. The closing date of the transaction is still undetermined pending receipt of regulatory approval, but is likely to occur during the second quarter of 2018. |

[0001437749-18-008304:8k_2_02:16]
“We are excited with our start to 2018 as we continued to see very strong year-over-year sales growth in the first quarter which drove improvements in our margins and free cash flow,” said Aaron Jagdfeld, President and Chief Executive Officer. “The fundamental demand environment for home standby and portable generators continues to be robust, benefitting from increased power outage activity in recent quarters contributing to excellent growth in both in-home consultations and end-user activations. Additionally, shipments of commercial and industrial (C&I) products also experienced strong growth during the quarter driven by the ongoing replacement cycle for mobile products, as well as organic growth within International which led to year-over-year margin improvement in the segment.”

[0001437749-18-008304:8k_2_02:17]
Additional First Quarter 2018 Consolidated Highlights

[0001437749-18-008304:8k_2_02:18]
Residential product sales increased 23.5% to $190.5 million as compared to $154.2 million in the prior year. C&I product sales increased 16.2% to $175.1 million as compared to $150.8 million in the prior year, with core sales growth was approximately 11%.

[0001437749-18-008304:8k_2_02:19]
Gross profit margin improved 230 basis points to 35.2% as compared to 32.9% in the prior-year first quarter, which was due to a variety of factors. The improvement was most notably due to favorable pricing and mix impacts along with improved leverage of fixed manufacturing costs on the significant increase in sales, which were partially offset by higher commodity prices.

[0001437749-18-008304:8k_2_02:20]
1

[0001437749-18-008304:8k_2_02:21]
Operating expenses increased $5.7 million, or 7.4%, as compared to the first quarter of 2017. The increase was primarily driven by an increase in employee costs including higher incentive compensation along with a stronger Euro, partially offset by lower promotional costs benefitting from the higher power outage environment as well as lower intangible amortization.

[0001437749-18-008304:8k_2_02:22]
Cash flow from operations was $29.0 million as compared to ($5.2) million in the prior-year first quarter, and free cash flow was $23.3 million as compared to ($8.1) million in the same quarter last year. The improvement in cash flow was driven by a variety of factors including the increase in operating earnings as compared to the prior year and lower working capital usage during the current year, partially offset by higher capital expenditures.

[0001437749-18-008304:8k_2_02:23]
The current year earnings per share calculation of $0.42 includes the impact of a $7.7 million adjustment to increase the value of the redeemable noncontrolling interest for the Pramac acquisition, resulting in a $0.12 reduction in earnings per share. Any adjustments to the redemption value are recorded directly to retained earnings. However, the redemption value adjustments are required to be reflected in the earnings per share calculation as detailed in the accompanying reconciliation schedules.

[0001437749-18-008304:8k_2_02:24]
On January 1, 2018, the Company adopted Accounting Standards Update 2014-09, Revenue from Contracts with Customers, and all related amendments, commonly known as the “new revenue recognition standard”. The full retrospective method was elected under this standard, which requires application to all periods presented, and the prior-year first quarter of 2017 results have been restated accordingly. However, the adoption of this standard did not have a material impact on the Company’s financial statements.

[0001437749-18-008304:8k_2_02:25]
Business Segment Results

[0001437749-18-008304:8k_2_02:26]
Domestic Segment

[0001437749-18-008304:8k_2_02:27]
Domestic segment sales increased 21.5% to $300.2 million as compared to $247.2 million in the prior-year quarter. The current-year first quarter experienced strong growth in shipments of home standby and portable generators driven by increased outage activity, along with the continuation of significant growth for C&I mobile products. Also contributing to the year-over-year sales growth were increases in service parts.

[0001437749-18-008304:8k_2_02:28]
Adjusted EBITDA for the segment was $65.5 million, or 21.8% of net sales, as compared to $41.9 million in the prior year, or 16.9% of net sales. Adjusted EBITDA margin in the current year benefitted from a favorable pricing environment including lower promotional costs, favorable mix and improved overall leverage of fixed operating costs on the higher organic sales volumes. These impacts were partially offset by higher commodity prices and an increase in employee costs including higher incentive compensation.

[0001437749-18-008304:8k_2_02:29]
International Segment

[0001437749-18-008304:8k_2_02:30]
International segment sales increased 16.9% to $97.4 million as compared to $83.3 million in the prior-year quarter, with core sales growth of approximately 5%. The overall growth compared to the prior year was primarily due to the favorable impact of the stronger Euro along with some broad organic growth from the Pramac, Ottomotores and Motortech businesses.

[0001437749-18-008304:8k_2_02:31]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, improved to $6.3 million, or 6.5% of net sales, as compared to $4.8 million, or 5.8% of net sales, in the prior year. The improvement in adjusted EBITDA margin as compared to the prior year was primarily due to favorable sales mix and increased leverage of fixed operating costs on the increase in organic sales. These favorable impacts were partially offset by higher commodity prices along with the expansion of certain branch operations.

[0001437749-18-008304:8k_2_02:32]
2018 Outlook

[0001437749-18-008304:8k_2_02:33]
The Company is increasing its prior guidance for revenue growth for full-year 2018, which is due to improving end-market conditions for both residential and C&I products. Full year net sales are now expected to improve between 6 to 8% over the prior year, which is an increase from the 3 to 5% growth previously expected. Core sales growth is expected to be between 5 to 6%, which is an increase from the 2 to 3% growth previously expected. Importantly, this guidance does not yet include any impact from the Selmec acquisition, as the specific timing of closing is undetermined pending regulatory approvals. Also, this top-line guidance assumes no “major” outage events and a baseline power outage severity level similar to the longer-term average for the remainder of the year. Should the baseline power outage environment in 2018 continue to be higher, or if there is “major” event during the year, the Company could exceed these expectations.

[0001437749-18-008304:8k_2_02:34]
Net income margins, before deducting for non-controlling interests, are still expected to be between 9.5 to 10.0% for the full-year 2018, with adjusted EBITDA margins, also before deducting for non-controlling interests, still expected to be between 19.0 to 19.5% for the year. This updated guidance assumes that additional inflationary pressures from higher commodity prices, tariffs, the weaker U.S. dollar and certain wage pressures will be largely offset by the benefit from additional leverage of fixed operating costs on the expected higher core sales growth.

[0001437749-18-008304:8k_2_02:35]
Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income to free cash flow expected to be over 90%.

[0001437749-18-008304:8k_2_02:36]
Conference Call and Webcast

[0001437749-18-008304:8k_2_02:37]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, May 2, 2018 to discuss highlights of the first quarter of 2018 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 1957709.

[0001437749-18-008304:8k_2_02:38]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-18-008304:8k_2_02:39]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 1957709. The telephonic replay will be available for 7 days.

[0001437749-18-008304:8k_2_02:40]
About Generac

[0001437749-18-008304:8k_2_02:41]
Founded in 1959, Generac is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-008304:8k_2_02:42]
Forward-looking Information

[0001437749-18-008304:8k_2_02:43]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-18-008304:8k_2_02:44]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-18-008304:8k_2_02:45]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-18-008304:8k_2_02:46]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-18-008304:8k_2_02:47]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities and product mix; |

[0001437749-18-008304:8k_2_02:48]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-18-008304:8k_2_02:49]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-18-008304:8k_2_02:50]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-18-008304:8k_2_02:51]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-18-008304:8k_2_02:52]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-18-008304:8k_2_02:53]
|  | ● | loss of key management and employees; |

[0001437749-18-008304:8k_2_02:54]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-18-008304:8k_2_02:55]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-18-008304:8k_2_02:56]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2017 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-18-008304:8k_2_02:57]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-18-008304:8k_2_02:58]
Reconciliations to GAAP Financial Metrics

[0001437749-18-008304:8k_2_02:59]
Adjusted EBITDA

[0001437749-18-008304:8k_2_02:60]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-18-008304:8k_2_02:61]
Adjusted Net Income

[0001437749-18-008304:8k_2_02:62]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-18-008304:8k_2_02:63]
Free Cash Flow

[0001437749-18-008304:8k_2_02:64]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-18-008304:8k_2_02:65]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-18-008304:8k_2_02:66]
SOURCE: Generac Holdings Inc.

[0001437749-18-008304:8k_2_02:67]
CONTACT:

[0001437749-18-008304:8k_2_02:68]
Michael W. Harris

[0001437749-18-008304:8k_2_02:69]
Vice President – Finance

[0001437749-18-008304:8k_2_02:70]
(262) 544-4811 x2675

[0001437749-18-008304:8k_2_02:71]
Michael.Harris@Generac.com

[0001437749-18-008304:8k_2_02:72]
5

[0001437749-18-008304:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-008304:8k_2_02:74]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |
| Costs of goods sold |  |  | 257,645 |  |  |  | 221,685 |  |
| Gross profit |  |  | 139,989 |  |  |  | 108,800 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 42,682 |  |  |  | 39,467 |  |
| Research and development |  |  | 11,853 |  |  |  | 10,287 |  |
| General and administrative |  |  | 23,475 |  |  |  | 20,973 |  |
| Amortization of intangibles |  |  | 5,632 |  |  |  | 7,183 |  |
| Total operating expenses |  |  | 83,642 |  |  |  | 77,910 |  |
| Income from operations |  |  | 56,347 |  |  |  | 30,890 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,113 | ) |  |  | (10,788 | ) |
| Investment income |  |  | 346 |  |  |  | 5 |  |
| Costs related to acquisition |  |  | (11 | ) |  |  | (185 | ) |
| Other, net |  |  | (1,383 | ) |  |  | 83 |  |
| Total other expense, net |  |  | (11,161 | ) |  |  | (10,885 | ) |
| Income before provision for income taxes |  |  | 45,186 |  |  |  | 20,005 |  |
| Provision for income taxes |  |  | 11,416 |  |  |  | 7,823 |  |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Net income attributable to Generac Holdings Inc. per common share - basic: |  | $ | 0.42 |  |  | $ | 0.21 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,943,495 |  |  |  | 62,366,263 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.42 |  |  | $ | 0.20 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,474,936 |  |  |  | 62,936,126 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 44,703 |  |  | $ | 15,720 |  |

[0001437749-18-008304:8k_2_02:75]
6

[0001437749-18-008304:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-008304:8k_2_02:77]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 146,162 |  |  | $ | 138,472 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 262,170 |  |  |  | 279,294 |  |
| Inventories |  |  | 439,745 |  |  |  | 387,049 |  |
| Prepaid expenses and other assets |  |  | 18,768 |  |  |  | 19,741 |  |
| Total current assets |  |  | 866,845 |  |  |  | 824,556 |  |
| Property and equipment, net |  |  | 232,023 |  |  |  | 230,380 |  |
| Customer lists, net |  |  | 39,516 |  |  |  | 41,064 |  |
| Patents, net |  |  | 37,310 |  |  |  | 39,617 |  |
| Other intangible assets, net |  |  | 2,302 |  |  |  | 2,401 |  |
| Tradenames, net |  |  | 151,972 |  |  |  | 152,683 |  |
| Goodwill |  |  | 724,206 |  |  |  | 721,523 |  |
| Deferred income taxes |  |  | 3,466 |  |  |  | 3,238 |  |
| Other assets |  |  | 19,828 |  |  |  | 10,502 |  |
| Total assets |  | $ | 2,077,468 |  |  | $ | 2,025,964 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 31,414 |  |  | $ | 20,602 |  |
| Accounts payable |  |  | 228,070 |  |  |  | 233,639 |  |
| Accrued wages and employee benefits |  |  | 29,014 |  |  |  | 27,992 |  |
| Other accrued liabilities |  |  | 122,546 |  |  |  | 112,618 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 1,593 |  |  |  | 1,572 |  |
| Total current liabilities |  |  | 412,637 |  |  |  | 396,423 |  |
| Long-term borrowings and capital lease obligations |  |  | 907,459 |  |  |  | 906,548 |  |
| Deferred income taxes |  |  | 49,140 |  |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 83,634 |  |  |  | 82,893 |  |
| Total liabilities |  |  | 1,452,870 |  |  |  | 1,427,716 |  |
| Redeemable noncontrolling interests |  |  | 54,404 |  |  |  | 43,929 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,989,164 and 70,820,173 shares issued at March 31, 2018 and December 31, 2017, respectively |  |  | 707 |  |  |  | 708 |  |
| Additional paid-in capital |  |  | 464,060 |  |  |  | 459,816 |  |
| Treasury stock, at cost |  |  | (321,025 | ) |  |  | (294,005 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 636,814 |  |  |  | 610,835 |  |
| Accumulated other comprehensive loss |  |  | (8,372 | ) |  |  | (21,198 | ) |
| Stockholders’ equity attributable to Generac Holdings, Inc. |  |  | 570,068 |  |  |  | 554,040 |  |
| Noncontrolling interests |  |  | 126 |  |  |  | 279 |  |
| Total stockholders' equity |  |  | 570,194 |  |  |  | 554,319 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,077,468 |  |  | $ | 2,025,964 |  |

[0001437749-18-008304:8k_2_02:78]
7

[0001437749-18-008304:8k_2_02:79]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-008304:8k_2_02:80]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 33,770 |  |  | $ | 12,182 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 6,051 |  |  |  | 5,414 |  |
| Amortization of intangible assets |  |  | 5,632 |  |  |  | 7,183 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,177 |  |  |  | 490 |  |
| Deferred income taxes |  |  | 4,283 |  |  |  | 6,530 |  |
| Share-based compensation expense |  |  | 3,106 |  |  |  | 2,632 |  |
| Other |  |  | 102 |  |  |  | 120 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 18,744 |  |  |  | 20,368 |  |
| Inventories |  |  | (48,798 | ) |  |  | (35,675 | ) |
| Other assets |  |  | 2,658 |  |  |  | 192 |  |
| Accounts payable |  |  | (9,439 | ) |  |  | (24,975 | ) |
| Accrued wages and employee benefits |  |  | 813 |  |  |  | 697 |  |
| Other accrued liabilities |  |  | 11,065 |  |  |  | 103 |  |
| Excess tax benefits from equity awards |  |  | (196 | ) |  |  | (436 | ) |
| Net cash provided by (used in) operating activities |  |  | 28,968 |  |  |  | (5,175 | ) |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1 |  |  |  | 35 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 867 |  |  |  | 629 |  |
| Expenditures for property and equipment |  |  | (6,496 | ) |  |  | (3,548 | ) |
| Acquisition of business, net of cash acquired |  |  | (369 | ) |  |  | 1,610 |  |
| Net cash used in investing activities |  |  | (5,997 | ) |  |  | (1,274 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 14,315 |  |  |  | 31,004 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 1,278 |  |
| Repayments of short-term borrowings |  |  | (3,911 | ) |  |  | (35,194 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (408 | ) |  |  | (1,056 | ) |
| Stock repurchases |  |  | (25,656 | ) |  |  | – |  |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (314 | ) |  |  | – |  |
| Payment of debt issuance costs |  |  | – |  |  |  | – |  |
| Taxes paid related to equity awards |  |  | (1,626 | ) |  |  | (1,903 | ) |
| Proceeds from exercise of stock options |  |  | 1,400 |  |  |  | 1,107 |  |
| Net cash used in financing activities |  |  | (16,200 | ) |  |  | (4,764 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 919 |  |  |  | 1,435 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 7,690 |  |  |  | (9,778 | ) |
| Cash and cash equivalents at beginning of period |  |  | 138,472 |  |  |  | 67,272 |  |
| Cash and cash equivalents at end of period |  | $ | 146,162 |  |  | $ | 57,494 |  |

[0001437749-18-008304:8k_2_02:81]
8

[0001437749-18-008304:8k_2_02:82]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |

[0001437749-18-008304:8k_2_02:83]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 300,219 |  |  | $ | 247,168 |  |
| International |  |  | 97,415 |  |  |  | 83,317 |  |
| Total net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 190,474 |  |  | $ | 154,217 |  |
| Commercial & industrial products |  |  | 175,125 |  |  |  | 150,753 |  |
| Other |  |  | 32,035 |  |  |  | 25,515 |  |
| Total net sales |  | $ | 397,634 |  |  | $ | 330,485 |  |

[0001437749-18-008304:8k_2_02:84]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 65,475 |  |  | $ | 41,891 |  |
| International |  |  | 6,306 |  |  |  | 4,812 |  |
| Total adjusted EBITDA (1) |  | $ | 71,781 |  |  | $ | 46,703 |  |

[0001437749-18-008304:8k_2_02:85]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-18-008304:8k_2_02:86]
9

[0001437749-18-008304:8k_2_02:87]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-18-008304:8k_2_02:88]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |
| Interest expense |  |  | 10,113 |  |  |  | 10,788 |  |
| Depreciation and amortization |  |  | 11,683 |  |  |  | 12,597 |  |
| Income taxes provision |  |  | 11,416 |  |  |  | 7,823 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,306 |  |  |  | 166 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,106 |  |  |  | 2,632 |  |
| Transaction costs and credit facility fees (3) |  |  | 262 |  |  |  | 316 |  |
| Business optimization expenses (4) |  |  | 138 |  |  |  | 100 |  |
| Other |  |  | (13 | ) |  |  | 99 |  |
| Adjusted EBITDA |  |  | 71,781 |  |  |  | 46,703 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,549 |  |  |  | 956 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 70,232 |  |  | $ | 45,747 |  |

[0001437749-18-008304:8k_2_02:89]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-18-008304:8k_2_02:90]
10

[0001437749-18-008304:8k_2_02:91]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Net income attributable to noncontrolling interests |  |  | 125 |  |  |  | 7 |  |
| Net income |  |  | 33,770 |  |  |  | 12,182 |  |
| Provision for income taxes |  |  | 11,416 |  |  |  | 7,823 |  |
| Income before provision for income taxes |  |  | 45,186 |  |  |  | 20,005 |  |
| Amortization of intangible assets |  |  | 5,632 |  |  |  | 7,183 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,177 |  |  |  | 490 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 20 |  |  |  | 585 |  |
| Business optimization expenses (4) |  |  | 138 |  |  |  | 100 |  |
| Adjusted net income before provision for income taxes |  |  | 52,153 |  |  |  | 28,363 |  |
| Cash income tax expense (6) |  |  | (5,410 | ) |  |  | (3,087 | ) |
| Adjusted net income |  |  | 46,743 |  |  |  | 25,276 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 661 |  |  |  | 582 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 46,082 |  |  | $ | 24,694 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.74 |  |  | $ | 0.39 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,474,936 |  |  |  | 62,936,126 |  |

[0001437749-18-008304:8k_2_02:92]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (6) Amount for the three months ended March 31, 2018 is based on an anticipated cash income tax rate at that time of approximately 13% for the full year ended 2018. Amount for the three months ended March 31, 2017 is based on an anticipated cash income tax rate at that time of approximately 15% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-18-008304:8k_2_02:93]
11

[0001437749-18-008304:8k_2_02:94]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 28,968 |  |  | $ | (5,175 | ) |
| Proceeds from beneficial interests in securitization transactions |  |  | 867 |  |  |  | 629 |  |
| Expenditures for property and equipment |  |  | (6,496 | ) |  |  | (3,548 | ) |
| Free cash flow |  | $ | 23,339 |  |  | $ | (8,094 | ) |

[0001437749-18-008304:8k_2_02:95]
| GAAP Earnings Per Share Calculation |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (7,665 | ) |  |  | 614 |  |
| Net income attributable to common shareholders |  | $ | 25,980 |  |  | $ | 12,789 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,943,495 |  |  |  | 62,366,263 |  |
| Dilutive effect of stock compensation awards |  |  | 531,441 |  |  |  | 569,863 |  |
| Diluted shares |  |  | 62,474,936 |  |  |  | 62,936,126 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | 0.21 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.20 |  |

[0001437749-18-008304:8k_2_02:96]
12
