# GNRC notes — 0001437749-18-008863


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-18-008863:notes:1]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,556 |  |  | $ | 20,576 |  |
| Long-term portion - other long-term liabilities |  |  | 15,763 |  |  |  | 14,846 |  |
| Total |  | $ | 36,319 |  |  | $ | 35,422 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 11,998 |  |  | $ | 11,017 |  |
| Long-term portion - other long-term liabilities |  |  | 48,115 |  |  |  | 46,837 |  |
| Total |  | $ | 60,113 |  |  | $ | 57,854 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-18-008863:notes:2]
3

[0001437749-18-008863:notes:3]
.

[0001437749-18-008863:notes:4]
Redeemable Noncontrolling

[0001437749-18-008863:notes:5]
Interest

[0001437749-18-008863:notes:6]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell his interest to the Company any time within 
five
 years from the date of acquisition. Within the 
first

[0001437749-18-008863:notes:7]
two
 years from the date of acquisition, the put option price was based on a fixed amount if voluntarily exercised. Subsequently, the put option price is based on the greater of the fixed amount or a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it 
 may 
redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with 
no
 partial transfers of interest permitted.

[0001437749-18-008863:notes:8]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
12,
 “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-18-008863:notes:9]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 43,929 |  |  | $ | 33,138 |  |
| Net income |  |  | (26 | ) |  |  | 118 |  |
| Foreign currency translation |  |  | 2,836 |  |  |  | 924 |  |
| Redemption value adjustment |  |  | 7,665 |  |  |  | (614 | ) |
| Balance at end of period |  | $ | 54,404 |  |  | $ | 33,566 |  |

[0001437749-18-008863:notes:10]
The redemption value adjustment recorded in the 
three
 month period ended 
 March 31, 2018 
relates to the adjustment required to reflect the redeemable noncontrolling interest value as a multiple of earnings after 
two
 years from the date of acquisition, in accordance with the terms of the acquisition.


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-18-008863:notes:11]
|  |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Commodity contracts |  | $ | (163 | ) |  | $ | 107 |  |
| Foreign currency contracts |  |  | (25 | ) |  |  | 167 |  |
| Interest rate swaps |  |  | 13,339 |  |  |  | 4,356 |  |


## gnrc:ScheduleOfRecognitionOfDeferredRevenueRelatedToExtendedWarrantiesTableTextBlock

[0001437749-18-008863:notes:12]
| Remainder of 2018 |  | $ | 9,196 |  |
| 2019 |  |  | 12,041 |  |
| 2020 |  |  | 10,666 |  |
| 2021 |  |  | 8,703 |  |
| 2022 |  |  | 6,811 |  |
| After 2022 |  |  | 12,696 |  |
| Total |  | $ | 60,113 |  |


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-18-008863:notes:13]
[same as prior period, unchanged from 0001437749-17-018410:notes:16]

[0001437749-18-008863:notes:14]
[same as prior period, unchanged from 0001437749-17-018410:notes:17]

[0001437749-18-008863:notes:15]
[same as prior period, unchanged from 0001437749-17-018410:notes:18]

[0001437749-18-008863:notes:16]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-008863:notes:17]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:

[0001437749-18-008863:notes:18]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. |

[0001437749-18-008863:notes:19]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-18-008863:notes:20]
The condensed consolidated balance sheet as of 
 March 31, 2018, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-18-008863:notes:21]
The preparation of the condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-18-008863:notes:22]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.

[0001437749-18-008863:notes:23]
[same as prior period, unchanged from 0001437749-17-018410:notes:28]

[0001437749-18-008863:notes:24]
Not
 Yet Adopted

[0001437749-18-008863:notes:25]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,

[0001437749-18-008863:notes:26]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-008863:notes:27]
[same as prior period, unchanged from 0001437749-17-018410:notes:48]

[0001437749-18-008863:notes:28]
[same as prior period, unchanged from 0001437749-17-018410:notes:49]

[0001437749-18-008863:notes:29]
[same as prior period, unchanged from 0001437749-17-018410:notes:50]

[0001437749-18-008863:notes:30]
Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-008863:notes:31]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

[0001437749-18-008863:notes:32]
Recently Adopted

[0001437749-18-008863:notes:33]
Accounting Standards

[0001437749-18-008863:notes:34]
On 
 January 1, 2018, 
the Company adopted ASU 
2017
-
07,

[0001437749-18-008863:notes:35]
Improving the Presentation of Net Periodic Pension Cost and Net

[0001437749-18-008863:notes:36]
Periodic

[0001437749-18-008863:notes:37]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

[0001437749-18-008863:notes:38]
On 
 January 1, 2018, 
the Company adopted ASU 
2016
-
15,

[0001437749-18-008863:notes:39]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. The changes in presentation of the proceeds from beneficial interests in securitization transactions were applied retrospectively to all periods presented.

[0001437749-18-008863:notes:40]
On 
 January 1, 2018, 
the Company adopted ASU 
2014
-
09,

[0001437749-18-008863:notes:41]
Revenue from Contracts with Customers
, and all related amendments (the “new revenue recognition standard”) using the full retrospective method, which requires application to all periods presented.

[0001437749-18-008863:notes:42]
The impact of adopting the above standards on the Company’s previously reported condensed consolidated financial statements is as follows:

[0001437749-18-008863:notes:43]
| Condensed Consolidated Balance Sheet |  | March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 223,031 |  |  | $ | (2,484 | ) |  | $ | 220,547 |  |
| Inventories |  |  | 390,908 |  |  |  | 6,082 |  |  |  | 396,990 |  |
| Other accrued liabilities |  |  | 91,853 |  |  |  | 5,604 |  |  |  | 97,457 |  |
| Deferred income taxes |  |  | 27,376 |  |  |  | (2,954 | ) |  |  | 24,422 |  |
| Other long-term liabilities |  |  | 62,129 |  |  |  | 5,548 |  |  |  | 67,677 |  |
| Retained earnings |  | $ | 469,508 |  |  | $ | (4,600 | ) |  | $ | 464,908 |  |

[0001437749-18-008863:notes:44]
| Condensed Consolidated Statement of Comprehensive Income |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 331,814 |  |  | $ | (1,329 | ) |  | $ | 330,485 |  |
| Cost of goods sold |  |  | 221,328 |  |  |  | 357 |  |  |  | 221,685 |  |
| Selling and service expenses |  |  | 40,184 |  |  |  | (717 | ) |  |  | 39,467 |  |
| Research and development expenses |  |  | 10,301 |  |  |  | (14 | ) |  |  | 10,287 |  |
| Other, net |  |  | (223 | ) |  |  | 140 |  |  |  | (83 | ) |
| Provision for income taxes |  |  | 8,251 |  |  |  | (428 | ) |  |  | 7,823 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | (667 | ) |  | $ | 12,175 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  |  | $ | (0.01 | ) |  | $ | 0.21 |  |
| Diluted |  | $ | 0.21 |  |  | $ | (0.01 | ) |  | $ | 0.20 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 16,387 |  |  | $ | (667 | ) |  | $ | 15,720 |  |

[0001437749-18-008863:notes:45]
| Condensed Consolidated Statement of Cash Flows |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 12,849 |  |  | $ | (667 | ) |  | $ | 12,182 |  |
| Deferred income taxes |  |  | 6,958 |  |  |  | (428 | ) |  |  | 6,530 |  |
| Accounts receivable |  |  | 19,973 |  |  |  | 395 |  |  |  | 20,368 |  |
| Inventories |  |  | (35,338 | ) |  |  | (337 | ) |  |  | (35,675 | ) |
| Other accrued liabilities |  |  | (305 | ) |  |  | 408 |  |  |  | 103 |  |
| Net cash used in operating activities |  | $ | (4,546 | ) |  | $ | (629 | ) |  | $ | (5,175 | ) |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 629 |  |  | $ | 629 |  |
| Net cash provided by (used in) investing activities |  | $ | (1,903 | ) |  | $ | 629 |  |  | $ | (1,274 | ) |

[0001437749-18-008863:notes:46]
| Condensed Consolidated Balance Sheet |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-18-008863:notes:47]
1

[0001437749-18-008863:notes:48]
4

[0001437749-18-008863:notes:49]
. Commitments and

[0001437749-18-008863:notes:50]
Contingencies

[0001437749-18-008863:notes:51]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2018 
and 
 December 31, 2017 
was approximately 
$34,600
 and 
$36,500,
 respectively.

[0001437749-18-008863:notes:52]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-18-008863:notes:53]
6

[0001437749-18-008863:notes:54]
. Accumulated Other Comprehensive

[0001437749-18-008863:notes:55]
Loss

[0001437749-18-008863:notes:56]
The following presents a tabular disclosure of changes in AOCL during the 
three
 months ended 
 March 31, 2018 
and 
2017,
 net of tax:

[0001437749-18-008863:notes:57]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income before reclassifications |  |  | 6,179 |  |  |  | - |  |  |  | 6,647 | (1) |  |  | 12,826 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 6,179 |  |  |  | - |  |  |  | 6,647 |  |  |  | 12,826 |  |
| Ending Balance – March 31, 2018 |  | $ | (6,677 | ) |  | $ | (10,978 | ) |  | $ | 9,283 |  |  | $ | (8,372 | ) |

[0001437749-18-008863:notes:58]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 3,600 |  |  |  | - |  |  |  | 440 | (2) |  |  | 4,040 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 3,600 |  |  |  | - |  |  |  | 440 |  |  |  | 4,040 |  |
| Ending Balance – March 31, 2017 |  | $ | (24,447 | ) |  | $ | (11,040 | ) |  | $ | (636 | ) |  | $ | (36,123 | ) |

[0001437749-18-008863:notes:59]
|  | (1) | Represents unrealized gains of $8,982, net of tax effect of $(2,335) for the three months ended March 31, 2018. |

[0001437749-18-008863:notes:60]
|  | (2) | Represents unrealized gains of $723, net of tax effect of $(283) for the three months ended March 31, 2017. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-008863:notes:61]
10

[0001437749-18-008863:notes:62]
. Credit Agreements

[0001437749-18-008863:notes:63]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-008863:notes:64]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,414 |  |  |  | 20,602 |  |
| Total |  | $ | 31,414 |  |  | $ | 20,602 |  |

[0001437749-18-008863:notes:65]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-008863:notes:66]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,760 | ) |  |  | (26,937 | ) |
| Capital lease obligation |  |  | 4,650 |  |  |  | 4,690 |  |
| Other |  |  | 1,162 |  |  |  | 1,367 |  |
| Total |  |  | 909,052 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 944 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 649 |  |  |  | 636 |  |
| Total |  | $ | 907,459 |  |  | $ | 906,548 |  |

[0001437749-18-008863:notes:67]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023

[0001437749-18-008863:notes:68]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-18-008863:notes:69]
In 
 May 2017, 
the Company amended the Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing, however, is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2017.

[0001437749-18-008863:notes:70]
In 
 December 2017, 
the Company once again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminates future related payment requirements if the Company’s secured leverage ratio is maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in 
fourth
 quarter of 
2017.

[0001437749-18-008863:notes:71]
As of 
 March 31, 2018, 
the Company’s secured leverage ratio was 
2.47
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-18-008863:notes:72]
The Company’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility. 
No
 amounts were outstanding under the ABL Facility at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively.

[0001437749-18-008863:notes:73]
As of 
 March 31, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$31,414
 and 
$20,602,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-18-008863:notes:74]
. Derivative Instruments

[0001437749-18-008863:notes:75]
and Hedging Activities

[0001437749-18-008863:notes:76]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 
815,

[0001437749-18-008863:notes:77]
[same as prior period, unchanged from 0001437749-17-018410:notes:88]

[0001437749-18-008863:notes:78]
[same as prior period, unchanged from 0001437749-17-018410:notes:89]

[0001437749-18-008863:notes:79]
The Company is exposed to price fluctuations in commodities it uses as raw materials; primarily steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. In the 
first
 quarter of 
2018,
 the Company entered into the following commodity forward contracts:

[0001437749-18-008863:notes:80]
| Hedged Item |  | Contract Date |  | Effective Date |  | Notional Amount |  |  | Fixed Price (per lb) |  | Expiration Date |
| Copper |  | February 12, 2018 |  | February 1, 2018 |  | $ | 3,776 |  |  | $ | 3.114 |  | December 31, 2018 |
| Copper |  | March 8, 2018 |  | March 9, 2018 |  | $ | 3,427 |  |  | $ | 3.109 |  | December 31, 2018 |
| Copper |  | March 20, 2018 |  | March 21, 2018 |  | $ | 3,418 |  |  | $ | 3.101 |  | December 31, 2018 |
| Copper |  | March 20, 2018 |  | March 21, 2018 |  | $ | 1,697 |  |  | $ | 3.079 |  | December 31, 2018 |
| Copper |  | March 26, 2018 |  | April 1, 2018 |  | $ | 3,003 |  |  | $ | 3.027 |  | December 31, 2018 |

[0001437749-18-008863:notes:81]
At 
 March 31, 2018,

[0001437749-18-008863:notes:82]
December 31, 2017 
and 
 March 31, 2017, 
the Company had five, 
one
 and 
one
 commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-18-008863:notes:83]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the 
three
 months ended 
 March 31, 2018 
and 
2017
 were $(
156
) and 
$183,
 respectively.

[0001437749-18-008863:notes:84]
[same as prior period, unchanged from 0001437749-17-018410:notes:95]

[0001437749-18-008863:notes:85]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 March 31, 2018,

[0001437749-18-008863:notes:86]
December 31, 2017 
and 
 March 31, 2017, 
the Company had 
22,

[0001437749-18-008863:notes:87]
28
 and 
19
 foreign currency contracts outstanding, respectively.

[0001437749-18-008863:notes:88]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in other, net in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the 
three
 months ended 
 March 31, 2018 
and 
2017
 were 
$227
 and (
$201
), respectively.

[0001437749-18-008863:notes:89]
[same as prior period, unchanged from 0001437749-17-018410:notes:99]

[0001437749-18-008863:notes:90]
In 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements; in 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement; and in 
2017,
 the Company entered into 
20
 additional interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains (net of tax) recognized in accumulated other comprehensive loss (AOCL) for the 
three
 months ended 
 March 31, 2018 
and 
2017
 were 
$6,647
 and 
$440,
 respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-18-008863:notes:91]
[same as prior period, unchanged from 0001437749-17-018410:notes:105]

[0001437749-18-008863:notes:92]
The following table presents the fair value of all of the Company’s derivatives:

[0001437749-18-008863:notes:93]
The fair value of the commodity contracts and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheets as of 
 March 31, 2018. 
The fair value of the commodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair value of the interest rate swaps are included in other assets in the consolidated balance sheet as of 
 December 31, 2017. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 March 31, 2018 
and 
 December 31, 2017 
is an asset of 
$13,375
 and 
$4,703,
 respectively, which represents the amount the Company would receive upon exit of the agreements on those dates.


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-008863:notes:94]
2

[0001437749-18-008863:notes:95]
. Earnings Per

[0001437749-18-008863:notes:96]
Share

[0001437749-18-008863:notes:97]
Basic earnings per share is calculated by dividing net income attributable to the common stockholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-18-008863:notes:98]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 33,645 |  |  | $ | 12,175 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (7,665 | ) |  |  | 614 |  |
| Net income attributable to common shareholders |  | $ | 25,980 |  |  | $ | 12,789 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,943,495 |  |  |  | 62,366,263 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 531,441 |  |  |  | 569,863 |  |
| Diluted shares |  |  | 62,474,936 |  |  |  | 62,936,126 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | 0.21 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.20 |  |

[0001437749-18-008863:notes:99]
(
1
) Excludes approximately 
93,600
 and 
154,900
 stock options for the 
three
 months ended 
 March 31, 2018 
and 
 March 31, 2017, 
respectively, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-008863:notes:100]
5

[0001437749-18-008863:notes:101]
. Fair Value

[0001437749-18-008863:notes:102]
Measurements

[0001437749-18-008863:notes:103]
[same as prior period, unchanged from 0001437749-17-018410:notes:117]

[0001437749-18-008863:notes:104]
[same as prior period, unchanged from 0001437749-17-018410:notes:118]

[0001437749-18-008863:notes:105]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$904,044,
 was approximately 
$904,587
 (Level 
2
) at 
 March 31, 2018, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-18-008863:notes:106]
For the fair value of the derivatives measured on a recurring basis, see the fair value table in Note 
4,
 “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 
820
-
10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-008863:notes:107]
[same as prior period, unchanged from 0001437749-17-018410:notes:122]

[0001437749-18-008863:notes:108]
The effective income tax rates for the 
three
 months ended 
 March 31, 2018 
and 
2017
 were 
25.3%
 and 
39.1%,
 respectively. The decrease in the effective income tax rate in 
2018
 was primarily due to a reduction of the US federal corporate tax rate as a result of the Tax Cuts and Jobs Act (Tax Act) enacted on 
 December 22, 2017.

[0001437749-18-008863:notes:109]
The SEC staff issued SAB 
118,
 which provides guidance on accounting for the tax effects of the Tax Act. SAB 
118
 provides a measurement period that should 
not
 extend beyond 
one
 year from the Tax Act enactment date for companies to complete the accounting under ASC 
740.
 In accordance with SAB 
118,
 a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 
740
 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 
740
 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. The Company's accounting for certain elements of the Tax Act is incomplete. However, reasonable estimates of certain effects were able to be made and, therefore, provisional adjustments were recorded in the Company’s financial statements as of, and for the period ended, 
 December 31, 2017. 
There were 
no
 significant adjustments recorded during the 
three
 months ended 
 March 31, 2018 
related to provisional amounts recorded in 
2017
 as a result of the Tax Act. For further discussion on the impact of the Tax Act, see Item 
8
 (Note 
13
 “Income Taxes”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-18-008863:notes:110]
9

[0001437749-18-008863:notes:111]
. Product Warranty

[0001437749-18-008863:notes:112]
Obligations

[0001437749-18-008863:notes:113]
The Company records a liability for product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s product warranty liability:

[0001437749-18-008863:notes:114]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 35,422 |  |  | $ | 31,695 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 43 |  |
| Payments |  |  | (4,985 | ) |  |  | (4,560 | ) |
| Provision for warranty issued |  |  | 5,203 |  |  |  | 4,160 |  |
| Changes in estimates for pre-existing warranties |  |  | 679 |  |  |  | 670 |  |
| Balance at end of period |  | $ | 36,319 |  |  | $ | 32,008 |  |

[0001437749-18-008863:notes:115]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of 
five
 to 
ten
 years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to selling and service expenses on the condensed consolidated statements of comprehensive income as an offset to warranty expense. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-18-008863:notes:116]
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 57,854 |  |  | $ | 36,139 |  |
| Deferred revenue contracts issued |  |  | 4,716 |  |  |  | 1,969 |  |
| Amortization of deferred revenue contracts |  |  | (2,457 | ) |  |  | (546 | ) |
| Balance at end of period |  | $ | 60,113 |  |  | $ | 37,562 |  |

[0001437749-18-008863:notes:117]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at 
 March 31, 2018 
is as follows:

[0001437749-18-008863:notes:118]
In the 
second
 quarter of 
2017,
 the Company launched a post-sale extended warranty marketing program. In the program’s agreement, the Company is required to pay fees to a 
third
-party service provider based on the number of extended warranty contracts sold, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the condensed consolidated balance sheet. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statement of comprehensive income consistent with how the related deferred revenue is recognized. The balance of deferred contract costs as of 
 March 31, 2018 
was 
$3,759,
 and 
$127
 of amortization was recorded during the 
three
 months ended 
 March 31, 2018. 
There were 
no
 deferred contract costs recorded as of and for the 
three
 months ended 
 March 31, 2017.

[0001437749-18-008863:notes:119]
Product warranty obligations and extended warranty related deferred revenues are included in the condensed consolidated balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-18-008863:notes:120]
|  |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Land and improvements |  | $ | 13,396 |  |  | $ | 13,118 |  |
| Buildings and improvements |  |  | 141,532 |  |  |  | 132,072 |  |
| Machinery and equipment |  |  | 93,056 |  |  |  | 90,487 |  |
| Dies and tools |  |  | 25,410 |  |  |  | 24,504 |  |
| Vehicles |  |  | 1,736 |  |  |  | 1,878 |  |
| Office equipment and systems |  |  | 76,982 |  |  |  | 73,254 |  |
| Leasehold improvements |  |  | 1,748 |  |  |  | 2,436 |  |
| Construction in progress |  |  | 9,122 |  |  |  | 18,799 |  |
| Gross property and equipment |  |  | 362,982 |  |  |  | 356,548 |  |
| Accumulated depreciation |  |  | (130,959 | ) |  |  | (126,168 | ) |
| Total |  | $ | 232,023 |  |  | $ | 230,380 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-18-008863:notes:121]
2.
 Revenue Recognition

[0001437749-18-008863:notes:122]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers, and therefore are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time, and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment; and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company's contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

[0001437749-18-008863:notes:123]
At the request of certain customers, the Company will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-18-008863:notes:124]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheet as accounts receivable, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheet. The balance of customer deposits (contract liability) was 
$8,028
 and 
$7,034
 at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

[0001437749-18-008863:notes:125]
The Company offers standard warranty coverage on substantially all products that it sells, and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-18-008863:notes:126]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation and extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets, and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
 party marketing agreement, it is required to pay fees to the 
third
-party service provider, and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheet. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statement of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-18-008863:notes:127]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue.

[0001437749-18-008863:notes:128]
Refer to Note 
7,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company's product classes.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-18-008863:notes:129]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 176,685 |  |  | $ | 13,789 |  |  | $ | 190,474 |  |
| Commercial & industrial products |  |  | 97,771 |  |  |  | 77,354 |  |  |  | 175,125 |  |
| Other |  |  | 25,763 |  |  |  | 6,272 |  |  |  | 32,035 |  |
| Total net sales |  | $ | 300,219 |  |  | $ | 97,415 |  |  | $ | 397,634 |  |

[0001437749-18-008863:notes:130]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 141,701 |  |  | $ | 12,516 |  |  | $ | 154,217 |  |
| Commercial & industrial products |  |  | 84,765 |  |  |  | 65,988 |  |  |  | 150,753 |  |
| Other |  |  | 20,702 |  |  |  | 4,813 |  |  |  | 25,515 |  |
| Total net sales |  | $ | 247,168 |  |  | $ | 83,317 |  |  | $ | 330,485 |  |

[0001437749-18-008863:notes:131]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 65,475 |  |  | $ | 41,891 |  |
| International |  |  | 6,306 |  |  |  | 4,812 |  |
| Total adjusted EBITDA |  | $ | 71,781 |  |  | $ | 46,703 |  |
| Interest expense |  |  | (10,113 | ) |  |  | (10,788 | ) |
| Depreciation and amortization |  |  | (11,683 | ) |  |  | (12,597 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,306 | ) |  |  | (166 | ) |
| Non-cash share-based compensation expense (2) |  |  | (3,106 | ) |  |  | (2,632 | ) |
| Transaction costs and credit facility fees (3) |  |  | (262 | ) |  |  | (316 | ) |
| Business optimization expenses (4) |  |  | (138 | ) |  |  | (100 | ) |
| Other |  |  | 13 |  |  |  | (99 | ) |
| Income before provision for income taxes |  | $ | 45,186 |  |  | $ | 20,005 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-18-008863:notes:132]
|  |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Raw material |  | $ | 273,608 |  |  | $ | 242,947 |  |
| Work-in-process |  |  | 7,543 |  |  |  | 2,544 |  |
| Finished goods |  |  | 158,594 |  |  |  | 141,558 |  |
| Total |  | $ | 439,745 |  |  | $ | 387,049 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-008863:notes:133]
7

[0001437749-18-008863:notes:134]
[same as prior period, unchanged from 0001437749-17-018410:notes:141]

[0001437749-18-008863:notes:135]
The Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac and Motortech businesses, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-18-008863:notes:136]
The Company's product offerings consist primarily of power generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, commercial & industrial, and other products by reportable segment is as follows:

[0001437749-18-008863:notes:137]
Residential products consist primarily of automatic standby generators ranging in output from 
6kW
 to 
60kW,
 portable generators, power washers and outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical and HVAC wholesalers and outdoor power equipment dealers. The Company’s revenue consists of the sale of the product to our distribution channels, which in turn sell the product to the end consumer, including installation and maintenance services. In some cases, the Company sells direct to the end consumer. Substantially all of the Company’s revenues are from sales of residential product transferred to the customer at a point in time.

[0001437749-18-008863:notes:138]
Commercial and industrial (C&I) products consist primarily of generators fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 
10kW
 up to 
3,250kW.
 Also included in C&I products are mobile generators, mobile heaters and light towers. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The Company’s revenue consists of the sale of the generator to our distribution channels, which in turn sell the product to the end consumer, including installation and maintenance services. In some cases, the Company sells direct to the end consumer. Substantially all of the Company’s revenues are from sales of C&I product transferred to the customer at a point in time.

[0001437749-18-008863:notes:139]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-18-008863:notes:140]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments. |

[0001437749-18-008863:notes:141]
[same as prior period, unchanged from 0001437749-17-018410:notes:146]

[0001437749-18-008863:notes:142]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-18-008863:notes:143]
|  | (4) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-18-008863:notes:144]
The Company’s sales in the United States represented approximately 
71%
 of total sales for the 
three
 months ended 
 March 31, 2018 
and 
2017.
 Approximately 
85%
 of the Company’s identifiable long-lived assets were located in the United States at both 
 March 31, 2018 
and 
 December 31, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-18-008863:notes:145]
8

[0001437749-18-008863:notes:146]
. Balance Sheet

[0001437749-18-008863:notes:147]
Details

[0001437749-18-008863:notes:148]
[same as prior period, unchanged from 0001437749-17-018410:notes:153]

[0001437749-18-008863:notes:149]
[same as prior period, unchanged from 0001437749-17-018410:notes:154]


## us-gaap:TreasuryStockTextBlock

[0001437749-18-008863:notes:150]
11

[0001437749-18-008863:notes:151]
. Stock Repurchase

[0001437749-18-008863:notes:152]
Program

[0001437749-18-008863:notes:153]
In 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the 
second
 program, the Company 
 may 
repurchase up to 
$250,000
 of its common stock over the 
24
 months following the date of approval. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
three
 months ended 
 March 31, 2018, 
the Company repurchased 
560,000
 shares of its common stock for 
$25,656,
 funded with cash on hand. There were 
no
 share repurchases during the 
three
 months ended 
 March 31, 2017. 
Since the inception of both programs, the Company has repurchased 
8,676,706
 shares of its common stock for 
$305,547,
 all funded with cash on hand.
