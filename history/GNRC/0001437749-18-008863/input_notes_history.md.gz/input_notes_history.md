# GNRC note change history — 0001437749-17-018410 → 0001437749-18-008863


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-07):
[0001437749-18-008863:note_history:1]
. Commitments and
  (was, 2017-11-06, similarity 0.7083):
[0001437749-17-018410:note_history:1]
. Commitments and Contingencies

- added (2018-05-07):
[0001437749-18-008863:note_history:2]
Contingencies

- changed (2018-05-07):
[0001437749-18-008863:note_history:3]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2018 
and 
 December 31, 2017 
was approximately 
$34,600
 and 
$36,500,
 respectively.
  (was, 2017-11-06, similarity 0.9718):
[0001437749-17-018410:note_history:3]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses it incurs. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2017 
and 
 December 31, 2016 
was approximately 
$40,500
 and 
$33,900,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-07):
[0001437749-18-008863:note_history:4]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2018-05-07):
[0001437749-18-008863:note_history:5]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017). 
A summary of acquisitions affecting the reporting periods presented include:
  (was, 2017-11-06, similarity 0.7885):
[0001437749-17-018410:note_history:5]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 and Item 
8
 (Note 
1
 “Description of Business”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2016). 
A summary of recent acquisitions include the following:

- changed (2018-05-07):
[0001437749-18-008863:note_history:6]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. |
  (was, 2017-11-06, similarity 0.6341):
[0001437749-17-018410:note_history:6]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold globally to gas-engine manufacturers and to aftermarket customers. While the Motortech acquisition was completed in January 2017, it was funded in the fourth quarter of 2016. |

- changed (2018-05-07):
[0001437749-18-008863:note_history:7]
The condensed consolidated balance sheet as of 
 March 31, 2018, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2017-11-06, similarity 0.8722):
[0001437749-17-018410:note_history:7]
The condensed conso
lidated balance sheet as of 
 September 30, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2017 
and 
2016,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2017 
and 
2016
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operations and cash flows, have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- added (2018-05-07):
[0001437749-18-008863:note_history:8]
Not
 Yet Adopted

- changed (2018-05-07):
[0001437749-18-008863:note_history:9]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,
  (was, 2017-11-06, similarity 0.872):
[0001437749-17-018410:note_history:9]
In 
 May 2014, 
the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

- changed (2018-05-07):
[0001437749-18-008863:note_history:10]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.
  (was, 2017-11-06, similarity 0.9599):
[0001437749-17-018410:note_history:10]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2018-05-07):
[0001437749-18-008863:note_history:11]
Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.
  (was, 2017-11-06, similarity 0.8592):
[0001437749-17-018410:note_history:11]
Targeted Improvements to Accounting for Hedging Activities
. This guidance is being issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements, and to make certain targeted improvements to simplify the application of the hedge accounting guidance. For existing hedges, this guidance should be applied using a cumulative effect adjustment, while the presentation and disclosure guidance should be adopted on a prospective basis. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2018-05-07):
[0001437749-18-008863:note_history:12]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.
  (was, 2017-11-06, similarity 0.9907):
[0001437749-17-018410:note_history:12]
There are several other new accounting pronouncements issued by the FASB. 
Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

- added (2018-05-07):
[0001437749-18-008863:note_history:13]
Recently Adopted

- added (2018-05-07):
[0001437749-18-008863:note_history:14]
Accounting Standards

- changed (2018-05-07):
[0001437749-18-008863:note_history:15]
On 
 January 1, 2018, 
the Company adopted ASU 
2017
-
07,
  (was, 2017-11-06, similarity 0.7677):
[0001437749-17-018410:note_history:15]
In the 
first
 quarter of 
2017,
 the Company adopted ASU 
2016
-
09,

- added (2018-05-07):
[0001437749-18-008863:note_history:16]
Improving the Presentation of Net Periodic Pension Cost and Net

- added (2018-05-07):
[0001437749-18-008863:note_history:17]
Periodic

- added (2018-05-07):
[0001437749-18-008863:note_history:18]
Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

- changed (2018-05-07):
[0001437749-18-008863:note_history:19]
On 
 January 1, 2018, 
the Company adopted ASU 
2016
-
15,
  (was, 2017-11-06, similarity 0.7317):
[0001437749-17-018410:note_history:19]
In 
 January 2017, 
the FASB issued ASU 
2017
-
04,

- added (2018-05-07):
[0001437749-18-008863:note_history:20]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. The changes in presentation of the proceeds from beneficial interests in securitization transactions were applied retrospectively to all periods presented.

- changed (2018-05-07):
[0001437749-18-008863:note_history:21]
On 
 January 1, 2018, 
the Company adopted ASU 
2014
-
09,
  (was, 2017-11-06, similarity 0.6173):
[0001437749-17-018410:note_history:21]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

- added (2018-05-07):
[0001437749-18-008863:note_history:22]
Revenue from Contracts with Customers
, and all related amendments (the “new revenue recognition standard”) using the full retrospective method, which requires application to all periods presented.

- added (2018-05-07):
[0001437749-18-008863:note_history:23]
The impact of adopting the above standards on the Company’s previously reported condensed consolidated financial statements is as follows:

- added (2018-05-07):
[0001437749-18-008863:note_history:24]
| Condensed Consolidated Balance Sheet |  | March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 223,031 |  |  | $ | (2,484 | ) |  | $ | 220,547 |  |
| Inventories |  |  | 390,908 |  |  |  | 6,082 |  |  |  | 396,990 |  |
| Other accrued liabilities |  |  | 91,853 |  |  |  | 5,604 |  |  |  | 97,457 |  |
| Deferred income taxes |  |  | 27,376 |  |  |  | (2,954 | ) |  |  | 24,422 |  |
| Other long-term liabilities |  |  | 62,129 |  |  |  | 5,548 |  |  |  | 67,677 |  |
| Retained earnings |  | $ | 469,508 |  |  | $ | (4,600 | ) |  | $ | 464,908 |  |

- added (2018-05-07):
[0001437749-18-008863:note_history:25]
| Condensed Consolidated Statement of Comprehensive Income |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 331,814 |  |  | $ | (1,329 | ) |  | $ | 330,485 |  |
| Cost of goods sold |  |  | 221,328 |  |  |  | 357 |  |  |  | 221,685 |  |
| Selling and service expenses |  |  | 40,184 |  |  |  | (717 | ) |  |  | 39,467 |  |
| Research and development expenses |  |  | 10,301 |  |  |  | (14 | ) |  |  | 10,287 |  |
| Other, net |  |  | (223 | ) |  |  | 140 |  |  |  | (83 | ) |
| Provision for income taxes |  |  | 8,251 |  |  |  | (428 | ) |  |  | 7,823 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | (667 | ) |  | $ | 12,175 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  |  | $ | (0.01 | ) |  | $ | 0.21 |  |
| Diluted |  | $ | 0.21 |  |  | $ | (0.01 | ) |  | $ | 0.20 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 16,387 |  |  | $ | (667 | ) |  | $ | 15,720 |  |

- added (2018-05-07):
[0001437749-18-008863:note_history:26]
| Condensed Consolidated Statement of Cash Flows |  | Three Months Ended March 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 12,849 |  |  | $ | (667 | ) |  | $ | 12,182 |  |
| Deferred income taxes |  |  | 6,958 |  |  |  | (428 | ) |  |  | 6,530 |  |
| Accounts receivable |  |  | 19,973 |  |  |  | 395 |  |  |  | 20,368 |  |
| Inventories |  |  | (35,338 | ) |  |  | (337 | ) |  |  | (35,675 | ) |
| Other accrued liabilities |  |  | (305 | ) |  |  | 408 |  |  |  | 103 |  |
| Net cash used in operating activities |  | $ | (4,546 | ) |  | $ | (629 | ) |  | $ | (5,175 | ) |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 629 |  |  | $ | 629 |  |
| Net cash provided by (used in) investing activities |  | $ | (1,903 | ) |  | $ | 629 |  |  | $ | (1,274 | ) |

- added (2018-05-07):
[0001437749-18-008863:note_history:27]
| Condensed Consolidated Balance Sheet |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts Receivable |  | $ | 280,002 |  |  | $ | (708 | ) |  | $ | 279,294 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,513 | ) |  | $ | 610,835 |  |

- removed (2018-05-07):
[0001437749-17-018410:note_history:28]
Founded in 
1959,

- removed (2018-05-07):
[0001437749-17-018410:note_history:29]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- removed (2018-05-07):
[0001437749-17-018410:note_history:30]
|  | ● | In March 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

- removed (2018-05-07):
[0001437749-17-018410:note_history:31]
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a 
five
-step process that entities should follow in order to achieve that core principal. ASU 
2014
-
09,
 as amended by ASU 
2015
-
14,

- removed (2018-05-07):
[0001437749-17-018410:note_history:32]
Revenue from Contracts with Customers (Topic

- removed (2018-05-07):
[0001437749-17-018410:note_history:33]
606
): D

- removed (2018-05-07):
[0001437749-17-018410:note_history:34]
eferral of the Effective Date
, ASU 
2016
-
08,

- removed (2018-05-07):
[0001437749-17-018410:note_history:35]
Revenue from Contracts with Customers (Topic 
606
): Principal versus Agent Considerations
, ASU 
2016
-
10,

- removed (2018-05-07):
[0001437749-17-018410:note_history:36]
Revenue from Contracts with Customers (Topic 
606
): Identifying Performance Obligations and Licensin

- removed (2018-05-07):
[0001437749-17-018410:note_history:37]
g, 
ASU 
2016
-
12,

- removed (2018-05-07):
[0001437749-17-018410:note_history:38]
Revenue from Contracts with Customers (Topic 
606
):

- removed (2018-05-07):
[0001437749-17-018410:note_history:39]
Narrow-

- removed (2018-05-07):
[0001437749-17-018410:note_history:40]
Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

- removed (2018-05-07):
[0001437749-17-018410:note_history:41]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company has substantially completed its assessment of the potential impacts the standard 
 may 
have on its financial statements, and believes that the adoption will 
not
 have a material impact. The Company is currently planning to adopt the standard using the full retrospective method.

- removed (2018-05-07):
[0001437749-17-018410:note_history:42]
In 
 February

- removed (2018-05-07):
[0001437749-17-018410:note_history:43]
2016,
 the FASB issued ASU 
2016
-
02,

- removed (2018-05-07):
[0001437749-17-018410:note_history:44]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does 
not
 believe that the adoption of this guidance will have a significant impact on the presentation of the statement of cash flows.

- removed (2018-05-07):
[0001437749-17-018410:note_history:45]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should 
not
 exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January 1, 2017. 
The Company has early adopted this standard, which did 
not
 have a significant impact on its consolidated financial statements.

- removed (2018-05-07):
[0001437749-17-018410:note_history:46]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid in exchange for withheld shares had 
no
 impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were 
no
 cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were 
not
 applicable or had 
no
 impact to the Company.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-07):
[0001437749-18-008863:note_history:47]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:
  (was, 2017-11-06, similarity 0.8854):
[0001437749-17-018410:note_history:47]
Short-term borrowings included in the 
condensed consolidated balance sheets consist of the following:

- changed (2018-05-07):
[0001437749-18-008863:note_history:48]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,414 |  |  |  | 20,602 |  |
| Total |  | $ | 31,414 |  |  | $ | 20,602 |  |
  (was, 2017-11-06, similarity 0.9718):
[0001437749-17-018410:note_history:48]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,226 |  |  |  | 31,198 |  |
| Total |  | $ | 26,226 |  |  | $ | 31,198 |  |

- changed (2018-05-07):
[0001437749-18-008863:note_history:49]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:
  (was, 2017-11-06, similarity 0.8315):
[0001437749-17-018410:note_history:49]
Long-term borrowings in the 
condensed consolidated balance sheets include the following:

- added (2018-05-07):
[0001437749-18-008863:note_history:50]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,760 | ) |  |  | (26,937 | ) |
| Capital lease obligation |  |  | 4,650 |  |  |  | 4,690 |  |
| Other |  |  | 1,162 |  |  |  | 1,367 |  |
| Total |  |  | 909,052 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 944 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 649 |  |  |  | 636 |  |
| Total |  | $ | 907,459 |  |  | $ | 906,548 |  |

- added (2018-05-07):
[0001437749-18-008863:note_history:51]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023

- changed (2018-05-07):
[0001437749-18-008863:note_history:52]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.
  (was, 2017-11-06, similarity 0.8712):
[0001437749-17-018410:note_history:52]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

- added (2018-05-07):
[0001437749-18-008863:note_history:53]
In 
 May 2017, 
the Company amended the Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing, however, is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2017.

- added (2018-05-07):
[0001437749-18-008863:note_history:54]
In 
 December 2017, 
the Company once again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminates future related payment requirements if the Company’s secured leverage ratio is maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in 
fourth
 quarter of 
2017.

- added (2018-05-07):
[0001437749-18-008863:note_history:55]
As of 
 March 31, 2018, 
the Company’s secured leverage ratio was 
2.47
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

- changed (2018-05-07):
[0001437749-18-008863:note_history:56]
The Company’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility. 
No
 amounts were outstanding under the ABL Facility at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively.
  (was, 2017-11-06, similarity 0.9473):
[0001437749-17-018410:note_history:56]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

- changed (2018-05-07):
[0001437749-18-008863:note_history:57]
As of 
 March 31, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$31,414
 and 
$20,602,
 respectively.
  (was, 2017-11-06, similarity 0.9586):
[0001437749-17-018410:note_history:57]
September 30, 2017 
and 
 December 31, 2016, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$26,226
 and 
$31,198,
 respectively.

- removed (2018-05-07):
[0001437749-17-018410:note_history:58]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,708) |  |  |  | (26,677) |  |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,833 |  |  |  | 4,647 |  |
| Other |  |  | 4,658 |  |  |  | 14,753 |  |
| Total |  |  | 1,012,783 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 104,011 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 671 |  |  |  | 566 |  |
| Total |  | $ | 908,101 |  |  | $ | 1,006,758 |  |

- removed (2018-05-07):
[0001437749-17-018410:note_history:59]
As the Company
’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July 1, 2016, 
the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represents the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time.

- removed (2018-05-07):
[0001437749-17-018410:note_history:60]
In 
 May 2017, 
the Company amended its Term Loan
, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,

- removed (2018-05-07):
[0001437749-17-018410:note_history:61]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,432
 of fees as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.
 As of 
 September 30, 2017, 
the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

- removed (2018-05-07):
[0001437749-17-018410:note_history:62]
In

- removed (2018-05-07):
[0001437749-17-018410:note_history:63]
May 2015, 
the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 September 30, 2017, 
there was 
$100,000
 outstanding under the ABL Facility, leaving 
$142,220
 of availability, net of outstanding letters of credit. In 
 October 2017, 
the Company repaid 
$90,000
 of the outstanding ABL Facility balance.

- removed (2018-05-07):
[0001437749-17-018410:note_history:64]
As of


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-05-07):
[0001437749-18-008863:note_history:65]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,760 | ) |  |  | (26,937 | ) |
| Capital lease obligation |  |  | 4,650 |  |  |  | 4,690 |  |
| Other |  |  | 1,162 |  |  |  | 1,367 |  |
| Total |  |  | 909,052 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 944 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 649 |  |  |  | 636 |  |
| Total |  | $ | 907,459 |  |  | $ | 906,548 |  |

- removed (2018-05-07):
[0001437749-17-018410:note_history:66]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (25,708) |  |  |  | (26,677) |  |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,833 |  |  |  | 4,647 |  |
| Other |  |  | 4,658 |  |  |  | 14,753 |  |
| Total |  |  | 1,012,783 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 104,011 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 671 |  |  |  | 566 |  |
| Total |  | $ | 908,101 |  |  | $ | 1,006,758 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-07):
[0001437749-18-008863:note_history:67]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,414 |  |  |  | 20,602 |  |
| Total |  | $ | 31,414 |  |  | $ | 20,602 |  |
  (was, 2017-11-06, similarity 0.9718):
[0001437749-17-018410:note_history:67]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,226 |  |  |  | 31,198 |  |
| Total |  | $ | 26,226 |  |  | $ | 31,198 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-07):
[0001437749-18-008863:note_history:68]
2.
 Revenue Recognition

- added (2018-05-07):
[0001437749-18-008863:note_history:69]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers, and therefore are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time, and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the condensed consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment; and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company's contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

- added (2018-05-07):
[0001437749-18-008863:note_history:70]
At the request of certain customers, the Company will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customer takes possession of the product.

- added (2018-05-07):
[0001437749-18-008863:note_history:71]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheet as accounts receivable, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheet. The balance of customer deposits (contract liability) was 
$8,028
 and 
$7,034
 at 
 March 31, 2018 
and 
 December 31, 2017, 
respectively. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

- added (2018-05-07):
[0001437749-18-008863:note_history:72]
The Company offers standard warranty coverage on substantially all products that it sells, and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s standard warranties.

- added (2018-05-07):
[0001437749-18-008863:note_history:73]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation and extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue on the condensed consolidated balance sheets, and amortized on a straight-line basis to selling and service expenses in the condensed consolidated statements of comprehensive income, as an offset to warranty expense, over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
 party marketing agreement, it is required to pay fees to the 
third
-party service provider, and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets on the condensed consolidated balance sheet. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statement of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
9,
 “Product Warranty Obligations,” to the condensed consolidated financial statements for further information regarding the Company’s extended warranties.

- added (2018-05-07):
[0001437749-18-008863:note_history:74]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue.

- added (2018-05-07):
[0001437749-18-008863:note_history:75]
Refer to Note 
7,
 “Segment Reporting,” to the condensed consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company's product classes.
