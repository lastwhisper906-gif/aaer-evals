# GNRC 8-K — 0001437749-14-019673 filed 2014-11-06

## item codes, every 8-K on or before 2014-11-07

- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2014-11-07

- none on or before 2014-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-14-019673:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-14-019673:8k_2_02:2]
ex99-1.htm

[0001437749-14-019673:8k_2_02:3]
Exhibit 99.1

[0001437749-14-019673:8k_2_02:4]
Generac Reports Third Quarter 2014 Results

[0001437749-14-019673:8k_2_02:5]
WAUKESHA, WISCONSIN, (November 6, 2014) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its third quarter ended September 30, 2014.

[0001437749-14-019673:8k_2_02:6]
Third quarter 2014 Highlights

[0001437749-14-019673:8k_2_02:7]
| ● | Net sales were $352.3 million during the third quarter of 2014 as compared to $363.3 million in the prior-year third quarter. |

[0001437749-14-019673:8k_2_02:8]
|  | - | Residential product sales were $183.7 million during the third quarter as compared to $192.7 million in the prior-year quarter, primarily due to a decline in portable generator sales and, to a lesser extent, shipments of home standby generators. |

[0001437749-14-019673:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales were $146.4 million during the third quarter as compared to $151.5 million in the prior-year quarter. Contributions from recent acquisitions and strength in oil & gas markets were more than offset by a decline in shipments to telecom national account customers. |

[0001437749-14-019673:8k_2_02:10]
| ● | Net income during the third quarter of 2014 was $36.5 million, or $0.52 per share, as compared to $47.1 million, or $0.67 per share, for the same period of 2013. Adjusted net income, as defined in the accompanying reconciliation schedules, was $57.9 million, or $0.83 per share, as compared to $73.7 million, or $1.06 per share, in the third quarter of 2013. |

[0001437749-14-019673:8k_2_02:11]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $83.1 million as compared to $100.1 million in the third quarter last year. |

[0001437749-14-019673:8k_2_02:12]
| ● | Cash flow from operations in the third quarter of 2014 was $57.2 million as compared to $80.9 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $47.8 million as compared to $76.7 million in the third quarter of 2013. |

[0001437749-14-019673:8k_2_02:13]
| ● | For the trailing four quarters, including the third quarter of 2014, net sales were $1.433 billion; net income was $173.7 million; adjusted EBITDA was $348.7 million; cash flow from operations was $247.2 million; and free cash flow was $208.0 million. |

[0001437749-14-019673:8k_2_02:14]
| ● | On September 1, 2014, the Company acquired Pramac America, LLC, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |

[0001437749-14-019673:8k_2_02:15]
| ● | As previously announced, on October 1, 2014, the Company acquired MAC, Inc. and its related entities (“MAC”), a leading manufacturer of premium-grade commercial and industrial mobile heaters within the U.S. and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-14-019673:8k_2_02:16]
“Home standby generator sales improved at a solid rate as compared to the second quarter of 2014, as we continue to build awareness and expand our leadership position for this product category. Despite current market conditions where power outage severity has been well below normal, we believe the penetration opportunity that exists for home standby generators remains significant,” said Aaron Jagdfeld, President and Chief Executive Officer. “Our C&I product sales continued to experience good momentum within the oil & gas market, while capital spending with certain telecom customers was lower in the quarter resulting in reduced shipments to this end market. On the acquisition front, we have been active in recent months by closing two transactions which broaden our residential engine powered tool product line and expand our C&I mobile products platform, while also increasing our exposure to the oil & gas market. We remain focused on our “Powering Ahead” strategic plan by proactively executing on a number of growth initiatives to drive a new and higher baseline of demand for our products.”

[0001437749-14-019673:8k_2_02:17]
Additional Third quarter 2014 Highlights

[0001437749-14-019673:8k_2_02:18]
Residential product sales for the third quarter of 2014 improved on a sequential basis to $183.7 million from $179.6 million in the second quarter of 2014, driven by a solid increase in shipments of home standby generators partially offset by a normal seasonal decline in power washer sales. Residential product sales declined on a year-over-year basis from $192.7 million for the third quarter of 2013 as the prior year was still benefiting from the afterglow period of demand from Superstorm Sandy. Also, the third quarter of 2014 continued to experience a power outage severity environment that remained below normalized levels. These factors resulted in a year-over-year decline in portable generator sales and, to a lesser extent, shipments of home standby generators.

[0001437749-14-019673:8k_2_02:19]
C&I product sales for the third quarter of 2014 were $146.4 million as compared to $151.5 million for the comparable period in 2013. Shipments to telecom national account customers declined in the current year quarter as compared to the prior year primarily resulting from reduced capital spending by certain customers. This decline was partially offset by contributions from recent acquisitions and strength in oil & gas markets.

[0001437749-14-019673:8k_2_02:20]
Gross profit margin for the third quarter of 2014 was 37.0% compared to 38.4% in the prior-year third quarter. The decline was primarily driven by an increase in promotional activities during the current year quarter along with the mix impact from recent acquisitions. These declines were partially offset by a higher mix of home standby generators and lower mix of organic C&I product shipments.

[0001437749-14-019673:8k_2_02:21]
Operating expenses for the third quarter of 2014 increased $7.3 million, or 14.0%, as compared to the third quarter of 2013. The increase was driven by a $5.6 million favorable adjustment to warranty reserves in the third quarter of 2013 that did not repeat in the current year, along with increased marketing and advertising expenses and the addition of operating expenses associated with recent acquisitions.

[0001437749-14-019673:8k_2_02:22]
Interest expense in the third quarter of 2014 was $12.3 million, which was largely flat as compared to $12.5 million in the prior year. During the third quarter of 2014, a voluntary $50 million pre-payment of term loan debt was made which resulted in the recording of a $1.8 million loss on extinguishment of debt.

[0001437749-14-019673:8k_2_02:23]
2014 Outlook

[0001437749-14-019673:8k_2_02:24]
The Company is revising its prior guidance for revenue growth and adjusted EBITDA margins for full year 2014 resulting from a power outage environment that remains well below normalized levels, a reduced level of capital spending with certain telecom customers and the continued overall economic softness in Latin America. For the full-year 2014, the Company now expects net sales to decline in the mid-single digit range over the prior year, and adjusted EBITDA margins are now expected to be in the low-to-mid 20% range. Free cash flow is expected to remain strong for the full year 2014 as a result of this strong margin profile, together with a low cost of debt, favorable tax attributes and capital-efficient operating model.

[0001437749-14-019673:8k_2_02:25]
“Although current market conditions were below our expectations in the third quarter of 2014, we believe the numerous long-term growth opportunities that impact our business remain in place,” continued Mr. Jagdfeld. “With our strong balance sheet and free cash flow generation profile, we are confident in our ability to continue to invest in the future growth of the business, both organically and through acquisitions. In doing this, we expect to drive further penetration of standby generators as well as benefit from being a more balanced and globally-focused company, as we further implement our diversification and international expansion strategies.”

[0001437749-14-019673:8k_2_02:26]
Conference Call and Webcast

[0001437749-14-019673:8k_2_02:27]
Generac management will hold a conference call at 9:00 a.m. EST on Thursday, November 6, 2014 to discuss highlights of the third quarter operating results. The conference call can be accessed by dialing (800) 510-0219 (domestic) or +1 (617) 614-3451 (international) and entering passcode 45412481.

[0001437749-14-019673:8k_2_02:28]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-14-019673:8k_2_02:29]
Following the live webcast, a replay will be available on the Company's web site. A telephonic replay will also be available approximately one hour after the call and can be accessed by dialing (888) 286-8010 (domestic) or +1 (617) 801-6888 (international) and entering passcode 60752580. The telephonic replay will be available for 30 days.

[0001437749-14-019673:8k_2_02:30]
About Generac

[0001437749-14-019673:8k_2_02:31]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-14-019673:8k_2_02:32]
Forward-looking Information

[0001437749-14-019673:8k_2_02:33]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-14-019673:8k_2_02:34]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-14-019673:8k_2_02:35]
|  | ● | demand for Generac products; |

[0001437749-14-019673:8k_2_02:36]
|  | ● | frequency and duration of power outages; |

[0001437749-14-019673:8k_2_02:37]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-14-019673:8k_2_02:38]
|  | ● | the impact on our results of possible fluctuations in interest rates; |

[0001437749-14-019673:8k_2_02:39]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-14-019673:8k_2_02:40]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-14-019673:8k_2_02:41]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-14-019673:8k_2_02:42]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-14-019673:8k_2_02:43]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-14-019673:8k_2_02:44]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-14-019673:8k_2_02:45]
|  | ● | loss of key management and employees; |

[0001437749-14-019673:8k_2_02:46]
|  | ● | increase in product and other liability claims; and |

[0001437749-14-019673:8k_2_02:47]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-14-019673:8k_2_02:48]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2013 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-14-019673:8k_2_02:49]
3

[0001437749-14-019673:8k_2_02:50]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-14-019673:8k_2_02:51]
Reconciliations to GAAP Financial Metrics

[0001437749-14-019673:8k_2_02:52]
Adjusted EBITDA

[0001437749-14-019673:8k_2_02:53]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-14-019673:8k_2_02:54]
Adjusted Net Income

[0001437749-14-019673:8k_2_02:55]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, and certain other non-cash gains and losses.

[0001437749-14-019673:8k_2_02:56]
Free Cash Flow

[0001437749-14-019673:8k_2_02:57]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-14-019673:8k_2_02:58]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-14-019673:8k_2_02:59]
SOURCE: Generac Holdings Inc.

[0001437749-14-019673:8k_2_02:60]
CONTACT:

[0001437749-14-019673:8k_2_02:61]
Michael W. Harris

[0001437749-14-019673:8k_2_02:62]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-14-019673:8k_2_02:63]
Michael.Harris@Generac.com

[0001437749-14-019673:8k_2_02:64]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-14-019673:8k_2_02:65]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 352,305 |  |  | $ | 363,269 |  |  | $ | 1,056,922 |  |  | $ | 1,109,529 |  |
| Costs of goods sold |  |  | 222,022 |  |  |  | 223,806 |  |  |  | 679,113 |  |  |  | 685,651 |  |
| Gross profit |  |  | 130,283 |  |  |  | 139,463 |  |  |  | 377,809 |  |  |  | 423,878 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 32,961 |  |  |  | 24,295 |  |  |  | 90,045 |  |  |  | 83,048 |  |
| Research and development |  |  | 7,822 |  |  |  | 7,183 |  |  |  | 23,580 |  |  |  | 20,892 |  |
| General and administrative |  |  | 13,429 |  |  |  | 13,693 |  |  |  | 39,080 |  |  |  | 40,158 |  |
| Amortization of intangible assets |  |  | 5,277 |  |  |  | 7,003 |  |  |  | 15,721 |  |  |  | 19,533 |  |
| Gain on remeasurement of contingent consideration |  | – |  |  | – |  |  |  | (4,877 | ) |  | – |  |
| Total operating expenses |  |  | 59,489 |  |  |  | 52,174 |  |  |  | 163,549 |  |  |  | 163,631 |  |
| Income from operations |  |  | 70,794 |  |  |  | 87,289 |  |  |  | 214,260 |  |  |  | 260,247 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (12,294 | ) |  |  | (12,494 | ) |  |  | (35,411 | ) |  |  | (42,432 | ) |
| Investment income |  |  | 38 |  |  |  | 23 |  |  |  | 119 |  |  |  | 65 |  |
| Loss on extinguishment of debt |  |  | (1,836 | ) |  | – |  |  |  | (1,836 | ) |  |  | (15,336 | ) |
| Gain on change in contractual interest rate |  | – |  |  | – |  |  |  | 16,014 |  |  | – |  |
| Costs related to acquisitions |  |  | (396 | ) |  |  | (656 | ) |  |  | (396 | ) |  |  | (1,059 | ) |
| Other, net |  |  | (1,444 | ) |  |  | (117 | ) |  |  | (1,242 | ) |  |  | (1,227 | ) |
| Total other expense, net |  |  | (15,932 | ) |  |  | (13,244 | ) |  |  | (22,752 | ) |  |  | (59,989 | ) |
| Income before provision for income taxes |  |  | 54,862 |  |  |  | 74,045 |  |  |  | 191,508 |  |  |  | 200,258 |  |
| Provision for income taxes |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Net income per common share - basic: |  | $ | 0.53 |  |  | $ | 0.69 |  |  | $ | 1.83 |  |  | $ | 1.85 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,556,051 |  |  |  | 68,198,006 |  |  |  | 68,511,409 |  |  |  | 68,026,705 |  |
| Net income per common share - diluted: |  | $ | 0.52 |  |  | $ | 0.67 |  |  | $ | 1.79 |  |  | $ | 1.81 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,033,224 |  |  |  | 69,887,025 |  |  |  | 70,050,953 |  |  |  | 69,627,215 |  |
| Dividends declared per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 5.00 |  |
| Comprehensive income |  | $ | 35,472 |  |  | $ | 48,336 |  |  | $ | 122,474 |  |  | $ | 129,288 |  |

[0001437749-14-019673:8k_2_02:66]
5

[0001437749-14-019673:8k_2_02:67]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-14-019673:8k_2_02:68]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 173,162 |  |  | $ | 150,147 |  |
| Restricted cash |  | – |  |  |  | 6,645 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 199,884 |  |  |  | 164,907 |  |
| Inventories |  |  | 327,581 |  |  |  | 300,253 |  |
| Deferred income taxes |  |  | 25,380 |  |  |  | 26,869 |  |
| Prepaid expenses and other assets |  |  | 6,256 |  |  |  | 5,358 |  |
| Total current assets |  |  | 732,263 |  |  |  | 654,179 |  |
| Property and equipment, net |  |  | 159,058 |  |  |  | 146,390 |  |
| Customer lists, net |  |  | 33,191 |  |  |  | 42,764 |  |
| Patents, net |  |  | 56,521 |  |  |  | 62,418 |  |
| Trade names, net |  |  | 174,604 |  |  |  | 173,196 |  |
| Goodwill |  |  | 607,763 |  |  |  | 608,287 |  |
| Other intangible assets, net |  |  | 3,162 |  |  |  | 4,447 |  |
| Deferred income taxes |  |  | 50,105 |  |  |  | 85,104 |  |
| Deferred financing costs, net |  |  | 17,082 |  |  |  | 20,051 |  |
| Other assets |  |  | 155 |  |  |  | 1,369 |  |
| Total assets |  | $ | 1,833,904 |  |  | $ | 1,798,205 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 5,502 |  |  | $ | 9,575 |  |
| Accounts payable |  |  | 131,445 |  |  |  | 109,238 |  |
| Accrued wages and employee benefits |  |  | 14,446 |  |  |  | 26,564 |  |
| Other accrued liabilities |  |  | 77,767 |  |  |  | 92,997 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 316 |  |  |  | 12,471 |  |
| Total current liabilities |  |  | 229,476 |  |  |  | 250,845 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,106,293 |  |  |  | 1,175,349 |  |
| Other long-term liabilities |  |  | 50,218 |  |  |  | 54,940 |  |
| Total liabilities |  |  | 1,385,987 |  |  |  | 1,481,134 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,057,195 and 68,767,367 shares issued at September 30, 2014 and December 31, 2013, respectively |  |  | 690 |  |  |  | 688 |  |
| Additional paid-in capital |  |  | 431,523 |  |  |  | 421,672 |  |
| Treasury stock, at cost |  |  | (8,052 | ) |  |  | (6,571 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 231,036 |  |  |  | 105,813 |  |
| Accumulated other comprehensive loss |  |  | (5,164 | ) |  |  | (2,415 | ) |
| Total stockholders’ equity |  |  | 447,917 |  |  |  | 317,071 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,833,904 |  |  | $ | 1,798,205 |  |

[0001437749-14-019673:8k_2_02:69]
6

[0001437749-14-019673:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (Dollars in Thousands) |
| (Unaudited) |

[0001437749-14-019673:8k_2_02:71]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 10,024 |  |  |  | 7,969 |  |
| Amortization of intangible assets |  |  | 15,721 |  |  |  | 19,533 |  |
| Amortization of original issue discount |  |  | 2,573 |  |  |  | 1,615 |  |
| Amortization of deferred financing costs |  |  | 2,272 |  |  |  | 1,932 |  |
| Amortization of unrealized loss on interest rate swaps |  | – |  |  |  | 2,381 |  |
| Loss on extinguishment of debt |  |  | 1,836 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate |  |  | (16,014 | ) |  | – |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  | – |  |
| Provision for losses on accounts receivable |  |  | 344 |  |  |  | 880 |  |
| Deferred income taxes |  |  | 35,572 |  |  |  | 57,363 |  |
| Loss on disposal of property and equipment |  |  | 135 |  |  |  | 369 |  |
| Share-based compensation expense |  |  | 9,403 |  |  |  | 9,471 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (28,747 | ) |  |  | (16,268 | ) |
| Inventories |  |  | (9,501 | ) |  |  | (61,310 | ) |
| Other assets |  |  | 2,768 |  |  |  | (5 | ) |
| Accounts payable |  |  | 20,215 |  |  |  | (6,605 | ) |
| Accrued wages and employee benefits |  |  | (12,037 | ) |  |  | 5,527 |  |
| Other accrued liabilities |  |  | (3,232 | ) |  |  | 495 |  |
| Excess tax benefits from equity awards |  |  | (9,167 | ) |  |  | (9,491 | ) |
| Net cash provided by operating activities |  |  | 142,511 |  |  |  | 155,213 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 7 |  |  |  | 75 |  |
| Expenditures for property and equipment |  |  | (22,722 | ) |  |  | (14,257 | ) |
| Proceeds from sale of business, net |  | – |  |  |  | 2,254 |  |
| Acquisition of business |  |  | (5,309 | ) |  |  | (73,961 | ) |
| Net cash used in investing activities |  |  | (28,024 | ) |  |  | (85,889 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 4,900 |  |  |  | 16,007 |  |
| Proceeds from long-term borrowings |  | – |  |  |  | 1,200,000 |  |
| Repayments of short-term borrowings |  |  | (24,741 | ) |  |  | (10,544 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (68,905 | ) |  |  | (897,932 | ) |
| Payment of debt issuance costs |  |  | (4 | ) |  |  | (21,935 | ) |
| Cash dividends paid |  |  | (705 | ) |  |  | (343,424 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (10,255 | ) |  |  | (12,468 | ) |
| Excess tax benefits from equity awards |  |  | 9,167 |  |  |  | 9,491 |  |
| Proceeds from exercise of stock options |  |  | 21 |  |  |  | 32 |  |
| Net cash used in financing activities |  |  | (90,522 | ) |  |  | (60,773 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (950 | ) |  |  | (53 | ) |
| Net increase in cash and cash equivalents |  |  | 23,015 |  |  |  | 8,498 |  |
| Cash and cash equivalents at beginning of period |  |  | 150,147 |  |  |  | 108,023 |  |
| Cash and cash equivalents at end of period |  | $ | 173,162 |  |  | $ | 116,521 |  |

[0001437749-14-019673:8k_2_02:72]
7

[0001437749-14-019673:8k_2_02:73]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-14-019673:8k_2_02:74]
Net income to Adjusted EBITDA reconciliation

[0001437749-14-019673:8k_2_02:75]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Interest expense |  |  | 12,294 |  |  |  | 12,494 |  |  |  | 35,411 |  |  |  | 42,432 |  |
| Depreciation and amortization |  |  | 8,789 |  |  |  | 9,846 |  |  |  | 25,745 |  |  |  | 27,502 |  |
| Income taxes provision |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,099 |  |  |  | (782 | ) |  |  | (4,653 | ) |  |  | 35 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,200 |  |  |  | 3,279 |  |  |  | 9,403 |  |  |  | 9,471 |  |
| Loss on extinguishment of debt (3) |  |  | 1,836 |  |  |  | - |  |  |  | 1,836 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (4) |  |  | - |  |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | 889 |  |  |  | 1,125 |  |  |  | 1,590 |  |  |  | 3,028 |  |
| Other |  |  | 91 |  |  |  | 61 |  |  |  | 264 |  |  |  | 904 |  |
| Adjusted EBITDA |  | $ | 83,060 |  |  | $ | 100,068 |  |  | $ | 245,090 |  |  | $ | 298,966 |  |

[0001437749-14-019673:8k_2_02:76]
| (1) Includes losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. Additionally, the nine months ended September 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Includes share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) For the nine months ended September 30, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three and nine months ended September 30, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment. |
| (4) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-14-019673:8k_2_02:77]
8

[0001437749-14-019673:8k_2_02:78]
Net income to Adjusted net income reconciliation

[0001437749-14-019673:8k_2_02:79]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Provision for income taxes |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Income before provision for income taxes |  |  | 54,862 |  |  |  | 74,045 |  |  |  | 191,508 |  |  |  | 200,258 |  |
| Amortization of intangible assets |  |  | 5,277 |  |  |  | 7,003 |  |  |  | 15,721 |  |  |  | 19,533 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,824 |  |  |  | 1,220 |  |  |  | 4,845 |  |  |  | 3,547 |  |
| Loss on extinguishment of debt (6) |  |  | 1,836 |  |  |  | - |  |  |  | 1,836 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (7) |  |  | - |  |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 565 |  |  |  | 977 |  |  |  | (4,134 | ) |  |  | 2,154 |  |
| Adjusted net income before provision for income taxes |  |  | 64,364 |  |  |  | 83,245 |  |  |  | 193,762 |  |  |  | 240,828 |  |
| Cash income tax expense (9) |  |  | (6,470 | ) |  |  | (9,510 | ) |  |  | (28,030 | ) |  |  | (16,680 | ) |
| Adjusted net income |  | $ | 57,894 |  |  | $ | 73,735 |  |  | $ | 165,732 |  |  | $ | 224,148 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.83 |  |  | $ | 1.06 |  |  | $ | 2.37 |  |  | $ | 3.22 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,033,224 |  |  |  | 69,887,025 |  |  |  | 70,050,953 |  |  |  | 69,627,215 |  |

[0001437749-14-019673:8k_2_02:80]
| (6) For the nine months ended September 30, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three and nine months ended September 30, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment. |
| (7) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times. |
| (8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. The nine months ended September 30, 2014 also includes certain purchase accounting adjustments and adjustments to certain earn-out obligations in connection with aquisitions ($4.9 million). |
| (9) Amount for the three and nine months ended September 30, 2014 is based on an anticipated cash income tax rate of approximately 14% for the full year-ended 2014. Amount for the three and nine months ended September 30, 2013 is based on an anticipated cash income tax rate of approximately 9% for the full year-ended 2013. |

[0001437749-14-019673:8k_2_02:81]
9

[0001437749-14-019673:8k_2_02:82]
Free cash flow reconciliation

[0001437749-14-019673:8k_2_02:83]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 57,226 |  |  | $ | 80,895 |  |  | $ | 142,511 |  |  | $ | 155,213 |  |
| Expenditures for property and equipment |  |  | (9,405 | ) |  |  | (4,206 | ) |  |  | (22,722 | ) |  |  | (14,257 | ) |
| Free cash flow |  | $ | 47,821 |  |  | $ | 76,689 |  |  | $ | 119,789 |  |  | $ | 140,956 |  |

[0001437749-14-019673:8k_2_02:84]
| LTM free cash flow reconciliation |  | LTM September 30, |  |
|  |  | 2014 |  |
|  |  | (unaudited) |  |
| 2013 net cash provided by operating activities, as reported |  | $ | 259,944 |  |
| Add: September 2014 net cash provided by operating activities, as reported |  |  | 142,511 |  |
| Less: September 2013 net cash provided by operating activities, as reported |  |  | (155,213 | ) |
| LTM net cash provided by operating activities |  |  | 247,242 |  |
| 2013 expenditures for property and equipment, as reported |  |  | (30,770 | ) |
| Include: September 2014 expenditures for property and equipment, as reported |  |  | (22,722 | ) |
| Exclude: September 2013 expenditures for property and equipment, as reported |  |  | 14,257 |  |
| LTM expenditures for property and equipment |  |  | (39,235 | ) |
| LTM Free cash flow |  | $ | 208,007 |  |
| LTM Adjusted EBITDA reconciliation |  | LTM September 30, |  |
|  |  | 2014 |  |
|  |  | (unaudited) |  |
| 2013 Adjusted EBITDA, as reported |  | $ | 402,613 |  |
| Add: September 2014 Adjusted EBITDA, as reported |  |  | 245,090 |  |
| Less: September 2013 Adjusted EBITDA, as reported |  |  | (298,966 | ) |
| LTM Adjusted EBITDA |  | $ | 348,737 |  |

[0001437749-14-019673:8k_2_02:85]
10
