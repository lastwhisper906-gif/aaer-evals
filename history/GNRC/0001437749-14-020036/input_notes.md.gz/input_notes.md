# GNRC notes — 0001437749-14-020036


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-14-020036:notes:1]
[same as prior period, unchanged from 0001437749-14-014607:notes:1]

[0001437749-14-020036:notes:2]
[same as prior period, unchanged from 0001437749-14-014607:notes:2]

[0001437749-14-020036:notes:3]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products. As a leader in power equipment serving residential, light-commercial, industrial, oil & gas, and construction markets, Generac’s power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-14-020036:notes:4]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

[0001437749-14-020036:notes:5]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-14-020036:notes:6]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-14-020036:notes:7]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-14-020036:notes:8]
[same as prior period, unchanged from 0001437749-14-014607:notes:8]

[0001437749-14-020036:notes:9]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |

[0001437749-14-020036:notes:10]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-14-020036:notes:11]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts contained in Note 7, “Product Warranty Obligations” have been reclassified to conform to the current period’s presentation.

[0001437749-14-020036:notes:12]
The condensed consolidated balance sheet as of September 30, 2014, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-14-020036:notes:13]
[same as prior period, unchanged from 0001437749-14-014607:notes:11]

[0001437749-14-020036:notes:14]
[same as prior period, unchanged from 0001437749-14-014607:notes:12]

[0001437749-14-020036:notes:15]
[same as prior period, unchanged from 0001437749-14-014607:notes:13]

[0001437749-14-020036:notes:16]
The following presents a tabular disclosure of changes in accumulated other comprehensive loss during the three and nine months ended September 30, 2014 and 2013, net of tax:

[0001437749-14-020036:notes:17]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

[0001437749-14-020036:notes:18]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |
| Other comprehensive income before reclassifications |  |  | 867 |  |  |  | - |  |  |  | - |  |  |  | 867 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 376 |  |  |  | 376 |  |
| Net current-period other comprehensive income |  |  | 867 |  |  |  | - |  |  |  | 376 |  |  |  | 1,243 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |

[0001437749-14-020036:notes:19]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $393 net of tax benefit of $17 for the three months ended September 30, 2013. |

[0001437749-14-020036:notes:20]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

[0001437749-14-020036:notes:21]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 886 |  |  |  | - |  |  |  | - |  |  |  | 886 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,381 |  |  |  | 2,381 |  |
| Net current-period other comprehensive income |  |  | 886 |  |  |  | - |  |  |  | 2,381 |  |  |  | 3,267 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |

[0001437749-14-020036:notes:22]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,490 net of tax benefit of $109 for the nine months ended September 30, 2013. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-14-020036:notes:23]
[same as prior period, unchanged from 0001437749-14-014607:notes:21]

[0001437749-14-020036:notes:24]
[same as prior period, unchanged from 0001437749-14-014607:notes:22]

[0001437749-14-020036:notes:25]
[same as prior period, unchanged from 0001437749-14-014607:notes:23]

[0001437749-14-020036:notes:26]
[same as prior period, unchanged from 0001437749-14-014607:notes:24]

[0001437749-14-020036:notes:27]
[same as prior period, unchanged from 0001437749-14-014607:notes:25]

[0001437749-14-020036:notes:28]
| As of September 30, 2014: |  |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 1/31/2014 | 2/1/2014 | $ 3,879 | 12/31/2014 |
| Copper | 3/11/2014 | 4/1/2014 | 3,014 | 12/31/2014 |

[0001437749-14-020036:notes:29]
| As of December 31, 2013: |  |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 6/21/2013 | 10/1/2013 | $ 2,169 | 6/30/2014 |

[0001437749-14-020036:notes:30]
| As of September 30, 2013: |  |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 2/26/2013 | 3/1/2013 | $ 2,677 | 12/31/2013 |
| Copper | 3/1/2013 | 3/1/2013 | 2,636 | 12/31/2013 |
| Copper | 4/15/2013 | 5/1/2013 | 4,033 | 12/31/2013 |
| Copper | 6/21/2013 | 10/1/2013 | 2,169 | 6/30/2014 |

[0001437749-14-020036:notes:31]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Total losses recognized for the three and nine months ended September 30, 2014 were $(106) and $(154), respectively. Total gains (losses) recognized for the three and nine months ended September 30, 2013 were $578 and $(540), respectively.

[0001437749-14-020036:notes:32]
[same as prior period, unchanged from 0001437749-14-014607:notes:30]

[0001437749-14-020036:notes:33]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. There were no foreign currency hedge contracts outstanding as of September 30, 2013. As of September 30, 2014 and December 31, 2013, the following foreign currency contracts were outstanding:

[0001437749-14-020036:notes:34]
| As of September 30, 2014: |  |  |  |  |
| Currency Denomination |  | Notional Amount |  |
| British Pound Sterling (GBP) to Euro |  | £ | 3,000 |  |
| As of December 31, 2013: |  |  |  |  |
| Currency Denomination |  | Notional Amount |  |
| United States Dollar (USD) to Euro |  | $ | 650 |  |
| British Pound Sterling (GBP) to Euro |  | £ | 4,000 |  |

[0001437749-14-020036:notes:35]
Total losses recognized in the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2014 were $(93) and $(190), respectively.

[0001437749-14-020036:notes:36]
[same as prior period, unchanged from 0001437749-14-014607:notes:35]

[0001437749-14-020036:notes:37]
[same as prior period, unchanged from 0001437749-14-014607:notes:36]

[0001437749-14-020036:notes:38]
On October 23, 2013, the Company entered into two interest rate swap agreements, and on May 19, 2014, the Company entered into one interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges. For derivatives that are designated and qualify as a cash flow hedge, the effective portion of the gain or loss on the derivative is reported as a component of accumulated other comprehensive loss. The cash flows of the swaps are recognized as adjustments to interest expense each period.  The ineffective portion of the derivatives’ change in fair value, if any, is immediately recognized in earnings. The Company assesses on an ongoing basis whether derivatives
      used in hedging transactions are highly effective in offsetting changes in cash flows of hedged items.  The effective dates of the swaps are July 1, 2014 with a notional amount of $100,000 each and a fixed LIBOR rate of 1.7370%, 1.7420% and 1.6195%, including a LIBOR floor of 0.75%, with expiration dates of July 1, 2018.

[0001437749-14-020036:notes:39]
[same as prior period, unchanged from 0001437749-14-014607:notes:38]

[0001437749-14-020036:notes:40]
|  |  | September 30, 2014 |  |  | December 31, 2013 |  |
| Commodity contracts |  | $ | (55 | ) |  | $ | 69 |  |
| Foreign currency contracts |  |  | (190 | ) |  |  | 56 |  |
| Interest rate swaps |  |  | 103 |  |  |  | 1,236 |  |

[0001437749-14-020036:notes:41]
The fair value of the commodity and foreign currency contracts is included in other accrued liabilities and other assets in the condensed consolidated balance sheets as of September 30, 2014 and December 31, 2013, respectively. The fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheets as of September 30, 2014 and December 31, 2013. Excluding the impact of credit risk, the fair value of the derivative contracts as of September 30, 2014 and December 31, 2013 is a liability of $(140) and an asset of $1,385, respectively, which represents the amount the Company would need to pay or would receive to exit the agreements on those dates.

[0001437749-14-020036:notes:42]
The following presents the impact of interest rate swaps, commodity contracts and foreign currency contracts on the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2014 and 2013:

[0001437749-14-020036:notes:43]
|  |  | Amount of Gain Recognized in Accumulated Other Comprehensive Loss for the Three Months Ended September 30, |  | Location of Gain (Loss) Recognized in Net Income on Ineffective Portion of Hedges |  | Amount of Loss Reclassified from Accumulated Other Comprehensive Loss into Net Income for the Three Months Ended September 30, |  |  | Amount of Gain (Loss) Recognized in Net Income on Hedges (Ineffective Portion) for the Three Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | 989 |  |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps (1) |  | $ | — |  |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | (376 | ) |  | $ | — |  |  | $ | 501 |  |
| Commodity and foreign currency contracts |  | $ | — |  |  | $ | — |  | Cost of goods sold |  | $ | — |  |  | $ | — |  |  | $ | (199 | ) |  | $ | 578 |  |

[0001437749-14-020036:notes:44]
|  |  | Amount of Loss Recognized in Accumulated Other Comprehensive Loss for the Nine Months Ended September 30, |  | Location of Gain (Loss) Recognized in Net Income on Ineffective Portion of Hedges |  | Amount of Loss Reclassified from Accumulated Other Comprehensive Loss into Net Income for the Nine Months Ended September 30, |  |  | Amount of Gain (Loss) Recognized in Net Income on Hedges (Ineffective Portion) for the Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | (719 | ) |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps (1) |  | $ | — |  |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | (2,381 | ) |  | $ | — |  |  | $ | 2,973 |  |
| Commodity and foreign currency contracts |  | $ | — |  |  | $ | — |  | Cost of goods sold |  | $ | — |  |  | $ | — |  |  | $ | (344 | ) |  | $ | (540 | ) |

[0001437749-14-020036:notes:45]
(1) Amounts recorded for the three and nine months ended September 30, 2013 relate to interest rate swap agreements outstanding as of May 30, 2012, the date the hedging relationships for these agreements were terminated.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-14-020036:notes:46]
[same as prior period, unchanged from 0001437749-14-014607:notes:45]

[0001437749-14-020036:notes:47]
ASC 820-10, Fair Value Measurement, among other things, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level
      2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-14-020036:notes:48]
[same as prior period, unchanged from 0001437749-14-014607:notes:47]

[0001437749-14-020036:notes:49]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued liabilities and short-term borrowings), excluding long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $1,104,419, was approximately $1,082,993 (Level 2) at September 30, 2014, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-14-020036:notes:50]
[same as prior period, unchanged from 0001437749-14-014607:notes:49]

[0001437749-14-020036:notes:51]
|  |  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | Total September 30, 2014 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | 103 |  |  | $ | – |  |  | $ | 103 |  |
| Commodity contracts |  | $ | (55 | ) |  | $ | – |  |  | $ | (55 | ) |
| Foreign currency contracts |  | $ | (190 | ) |  | $ | – |  |  | $ | (190 | ) |

[0001437749-14-020036:notes:52]
|  |  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | Total December 31, 2013 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | 1,236 |  |  | $ | – |  |  | $ | 1,236 |  |
| Commodity contracts |  | $ | 69 |  |  | $ | – |  |  | $ | 69 |  |
| Foreign currency contracts |  | $ | 56 |  |  | $ | – |  |  | $ | 56 |  |

[0001437749-14-020036:notes:53]
[same as prior period, unchanged from 0001437749-14-014607:notes:52]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-14-020036:notes:54]
4. Acquisitions

[0001437749-14-020036:notes:55]
On August 1, 2013, a subsidiary of the Company acquired all of the shares of Tower Light for a purchase price, net of cash acquired and inclusive of earn-out payments, of $85,812. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. Tower Light has built a leading market position in the equipment rental markets by leveraging its broad product offering and strong global distribution network in over 50 countries worldwide.

[0001437749-14-020036:notes:56]
The net cash paid at closing of $80,239 included a cash deposit of $6,645 into an escrow account to fund future earn-out payments required by the purchase agreement, which was recorded as restricted cash on the Company’s condensed consolidated balance sheet. The earn-out payment of $7,641 was finalized during the second quarter of 2014, resulting in a cash payment of $996 in addition to the $6,645 cash escrow. This cash payment was reflected as an addition to the purchase price. Additionally, the cash paid at closing included an estimate of acquired working capital. This estimate was finalized during the third quarter of 2013, resulting in a $300 decrease to the purchase price. This acquisition was funded solely by existing cash.

[0001437749-14-020036:notes:57]
The Company recorded a preliminary purchase price allocation during the third quarter of 2013 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $67,900 of intangible assets, including approximately $38,400 of goodwill, as of the acquisition date. Based on revised purchase accounting estimates, an additional $9,868 of goodwill was recorded in the fourth quarter of 2013. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Tower Light from August 1, 2013 through September 30, 2014.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-14-020036:notes:58]
5. Segment Reporting

[0001437749-14-020036:notes:59]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production processes and methods of distribution. The Company’s sales in the United States represent approximately 86% and 87% of total sales for the three months ended September 30, 2014 and 2013, respectively, and represent 85% and 89% of total sales for the nine months ended September 30, 2014 and 2013, respectively. Approximately 90% of the Company’s identifiable long-lived assets are located in the
      United States at both September 30, 2014 and December 31, 2013.

[0001437749-14-020036:notes:60]
[same as prior period, unchanged from 0001437749-14-014607:notes:55]

[0001437749-14-020036:notes:61]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Residential power products |  | $ | 183,747 |  |  | $ | 192,728 |  |  | $ | 527,308 |  |  | $ | 644,588 |  |
| Commercial & industrial power products |  |  | 146,411 |  |  |  | 151,488 |  |  |  | 467,248 |  |  |  | 411,995 |  |
| Other |  |  | 22,147 |  |  |  | 19,053 |  |  |  | 62,366 |  |  |  | 52,946 |  |
| Total |  | $ | 352,305 |  |  | $ | 363,269 |  |  | $ | 1,056,922 |  |  | $ | 1,109,529 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-14-020036:notes:62]
6. Balance Sheet Details

[0001437749-14-020036:notes:63]
[same as prior period, unchanged from 0001437749-14-014607:notes:58]

[0001437749-14-020036:notes:64]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Raw material |  | $ | 195,597 |  |  | $ | 183,787 |  |
| Work-in-process |  |  | 10,065 |  |  |  | 9,620 |  |
| Finished goods |  |  | 129,362 |  |  |  | 113,404 |  |
| Reserves for excess and obsolescence |  |  | (7,443 | ) |  |  | (6,558 | ) |
| Total |  | $ | 327,581 |  |  | $ | 300,253 |  |

[0001437749-14-020036:notes:65]
[same as prior period, unchanged from 0001437749-14-014607:notes:60]

[0001437749-14-020036:notes:66]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Land and improvements |  | $ | 7,442 |  |  | $ | 7,416 |  |
| Buildings and improvements |  |  | 98,193 |  |  |  | 96,161 |  |
| Machinery and equipment |  |  | 62,356 |  |  |  | 54,847 |  |
| Dies and tools |  |  | 16,073 |  |  |  | 17,071 |  |
| Vehicles |  |  | 1,945 |  |  |  | 1,979 |  |
| Office equipment |  |  | 20,552 |  |  |  | 17,304 |  |
| Leasehold improvements |  |  | 2,519 |  |  |  | 2,229 |  |
| Construction in progress |  |  | 16,216 |  |  |  | 9,724 |  |
| Gross property and equipment |  |  | 225,296 |  |  |  | 206,731 |  |
| Accumulated depreciation |  |  | (66,238 | ) |  |  | (60,341 | ) |
| Total |  | $ | 159,058 |  |  | $ | 146,390 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-14-020036:notes:67]
7. Product Warranty Obligations

[0001437749-14-020036:notes:68]
[same as prior period, unchanged from 0001437749-14-014607:notes:63]

[0001437749-14-020036:notes:69]
[same as prior period, unchanged from 0001437749-14-014607:notes:64]

[0001437749-14-020036:notes:70]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 32,171 |  |  | $ | 40,156 |  |  | $ | 33,734 |  |  | $ | 36,112 |  |
| Product warranty reserve assumed in acquisition |  |  | 193 |  |  |  | - |  |  |  | 193 |  |  |  | - |  |
| Payments |  |  | (5,672 | ) |  |  | (4,571 | ) |  |  | (16,696 | ) |  |  | (14,167 | ) |
| Provision for warranties issued |  |  | 5,595 |  |  |  | 7,607 |  |  |  | 17,623 |  |  |  | 27,947 |  |
| Changes in estimates for pre-existing warranties |  |  | 182 |  |  |  | (5,600 | ) |  |  | (2,385 | ) |  |  | (12,300 | ) |
| Balance at end of period |  | $ | 32,469 |  |  | $ | 37,592 |  |  | $ | 32,469 |  |  | $ | 37,592 |  |

[0001437749-14-020036:notes:71]
[same as prior period, unchanged from 0001437749-14-014607:notes:66]

[0001437749-14-020036:notes:72]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 25,679 |  |  | $ | 16,729 |  |  | $ | 23,092 |  |  | $ | 13,473 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,315 |  |  |  | 4,138 |  |  |  | 5,329 |  |  |  | 8,544 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (850 | ) |  |  | (600 | ) |  |  | (2,277 | ) |  |  | (1,750 | ) |
| Balance at end of period |  | $ | 26,144 |  |  | $ | 20,267 |  |  | $ | 26,144 |  |  | $ | 20,267 |  |

[0001437749-14-020036:notes:73]
Product warranty obligations and extended warranty related deferred revenues are included in the condensed consolidated balance sheets as follows:

[0001437749-14-020036:notes:74]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 24,961 |  |  | $ | 26,080 |  |
| Long-term portion - other long-term liabilities |  |  | 7,508 |  |  |  | 7,654 |  |
| Total |  | $ | 32,469 |  |  | $ | 33,734 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 6,377 |  |  | $ | 3,325 |  |
| Long-term portion - other long-term liabilities |  |  | 19,767 |  |  |  | 19,767 |  |
| Total |  | $ | 26,144 |  |  | $ | 23,092 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-14-020036:notes:75]
8. Credit Agreements

[0001437749-14-020036:notes:76]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-14-020036:notes:77]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,502 |  |  |  | 9,575 |  |
| Total |  | $ | 5,502 |  |  | $ | 9,575 |  |

[0001437749-14-020036:notes:78]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-14-020036:notes:79]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,129,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (25,040 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,190 |  |  |  | 2,529 |  |
| Other |  |  | 459 |  |  |  | 1,026 |  |
| Total |  |  | 1,106,609 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 174 |  |  |  | 185 |  |
| Total |  | $ | 1,106,293 |  |  | $ | 1,175,349 |  |

[0001437749-14-020036:notes:80]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement) with certain commercial banks and other lenders. The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (New Term Loan) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses.

[0001437749-14-020036:notes:81]
The New Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which will be secured by a second priority lien.

[0001437749-14-020036:notes:82]
Prior to any voluntary prepayments, the New Term Loan amortized in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the New Term Loan Credit Agreement, falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net
      debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets. The Borrower’s net debt leverage ratio as of September 30, 2014 was below 3.00 to 1.00.

[0001437749-14-020036:notes:83]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends. Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit
      the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

[0001437749-14-020036:notes:84]
The New Term Loan Credit Agreement contains customary events of default, including; nonpayment of principal, interest or other amounts; failure to perform covenants; inaccuracy of representations or warranties in any material respect; cross-defaults with other material indebtedness; certain undischarged judgments; the occurrence of certain ERISA or bankruptcy or insolvency events; or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

[0001437749-14-020036:notes:85]
Concurrent with the closing of the New Term Loan Credit Agreement on May 31, 2013, the Borrower amended its then existing ABL credit agreement (New ABL Credit Agreement). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018.

[0001437749-14-020036:notes:86]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of September 30, 2014, no amounts were outstanding under the ABL Facility. As of September 30, 2014, the Company had $173,162 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

[0001437749-14-020036:notes:87]
On February 11, 2013, the Company made an $80,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations on the Term Loan Credit Agreement.  As a result, the Company wrote off $1,839 of original issue discount and capitalized debt issuance costs during the first quarter of 2013.  On May 2, 2013, the Company made an additional $30,000 voluntary prepayment of existing debt with available cash on hand.  As a result, the Company wrote off $924 of original issue discount and capitalized debt issuance costs during the second quarter of 2013.

[0001437749-14-020036:notes:88]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the nine months ended September 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its
      loans under the effective interest method.

[0001437749-14-020036:notes:89]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2014.

[0001437749-14-020036:notes:90]
On September 30, 2014, the Company made a $50,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2015. As a result, the Company wrote off $1,836 of original issue discount and capitalized debt issuance costs during the third quarter of 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-14-020036:notes:91]
As of September 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $5,502 and $9,575, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-14-020036:notes:92]
9. Earnings Per Share

[0001437749-14-020036:notes:93]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-14-020036:notes:94]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator- net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Denominator- weighted average shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,556,051 |  |  |  | 68,198,006 |  |  |  | 68,511,409 |  |  |  | 68,026,705 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,477,173 |  |  |  | 1,689,019 |  |  |  | 1,539,544 |  |  |  | 1,600,510 |  |
| Diluted |  |  | 70,033,224 |  |  |  | 69,887,025 |  |  |  | 70,050,953 |  |  |  | 69,627,215 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.53 |  |  | $ | 0.69 |  |  | $ | 1.83 |  |  | $ | 1.85 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.67 |  |  | $ | 1.79 |  |  | $ | 1.81 |  |

[0001437749-14-020036:notes:95]
(1) Excludes approximately 91,300 and 75,400 stock options for the three and nine month periods ended September 30, 2014, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 8,000 and 18,000 stock options for the three and nine month periods ended September 30, 2013, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-14-020036:notes:96]
10. Income Taxes

[0001437749-14-020036:notes:97]
The effective income tax rates for the nine months ended September 30, 2014 and 2013 were 34.6% and 37.1%, respectively. For the nine months ended September 30, 2014, the provision for income taxes includes a $1,100 discrete tax benefit primarily due to utilization of the federal research credit. Additionally, the decrease in the effective income tax rate year-over-year is primarily due to the Company’s ability to utilize the federal domestic production activity deduction due to sufficient taxable income, as well as the lower tax rate of a foreign subsidiary acquired during the third quarter of 2013.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-14-020036:notes:98]
11. Commitments and Contingencies

[0001437749-14-020036:notes:99]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2014 and December 31, 2013 was approximately $32,400 and $24,300 respectively.

[0001437749-14-020036:notes:100]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:SubsequentEventsTextBlock

[0001437749-14-020036:notes:101]
12. Subsequent Events

[0001437749-14-020036:notes:102]
On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC, with approximately 100 employees, is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market.
