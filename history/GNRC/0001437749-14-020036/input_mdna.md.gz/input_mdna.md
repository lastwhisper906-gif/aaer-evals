# GNRC MD&A — 0001437749-14-020036


## mdna

[0001437749-14-020036:mdna:1]
[same as prior period, unchanged from 0001437749-14-014607:mdna:1]

[0001437749-14-020036:mdna:2]
This quarterly report contains forward-looking statements that are subject to risks and uncertainties. Forward-looking statements give our current expectations and projections relating to our financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as “anticipate,” “estimate,” “expect,” “forecast,” “project,” “plan,” “intend,” “believe,” “confident,” “may,” “should,” “can have,” “likely,” “future”, “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-14-020036:mdna:3]
[same as prior period, unchanged from 0001437749-14-014607:mdna:3]

[0001437749-14-020036:mdna:4]
[same as prior period, unchanged from 0001437749-14-014607:mdna:4]

[0001437749-14-020036:mdna:5]
[same as prior period, unchanged from 0001437749-14-014607:mdna:5]

[0001437749-14-020036:mdna:6]
[same as prior period, unchanged from 0001437749-14-014607:mdna:6]

[0001437749-14-020036:mdna:7]
[same as prior period, unchanged from 0001437749-14-014607:mdna:7]

[0001437749-14-020036:mdna:8]
[same as prior period, unchanged from 0001437749-14-014607:mdna:8]

[0001437749-14-020036:mdna:9]
[same as prior period, unchanged from 0001437749-14-014607:mdna:9]

[0001437749-14-020036:mdna:10]
[same as prior period, unchanged from 0001437749-14-014607:mdna:10]

[0001437749-14-020036:mdna:11]
|  | ● | the impact on our results of possible fluctuations in interest rates; |

[0001437749-14-020036:mdna:12]
[same as prior period, unchanged from 0001437749-14-014607:mdna:12]

[0001437749-14-020036:mdna:13]
[same as prior period, unchanged from 0001437749-14-014607:mdna:13]

[0001437749-14-020036:mdna:14]
[same as prior period, unchanged from 0001437749-14-014607:mdna:14]

[0001437749-14-020036:mdna:15]
[same as prior period, unchanged from 0001437749-14-014607:mdna:15]

[0001437749-14-020036:mdna:16]
[same as prior period, unchanged from 0001437749-14-014607:mdna:16]

[0001437749-14-020036:mdna:17]
[same as prior period, unchanged from 0001437749-14-014607:mdna:17]

[0001437749-14-020036:mdna:18]
[same as prior period, unchanged from 0001437749-14-014607:mdna:18]

[0001437749-14-020036:mdna:19]
[same as prior period, unchanged from 0001437749-14-014607:mdna:19]

[0001437749-14-020036:mdna:20]
[same as prior period, unchanged from 0001437749-14-014607:mdna:20]

[0001437749-14-020036:mdna:21]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the fiscal year ended December 31, 2013. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-14-020036:mdna:22]
[same as prior period, unchanged from 0001437749-14-014607:mdna:22]

[0001437749-14-020036:mdna:23]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas, and construction markets. Unlike our primary competitors in the generator market, power generation is our main focus. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets and a broad product line of power washers for residential and commercial use.

[0001437749-14-020036:mdna:24]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

[0001437749-14-020036:mdna:25]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-14-020036:mdna:26]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-14-020036:mdna:27]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-14-020036:mdna:28]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW. |

[0001437749-14-020036:mdna:29]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |

[0001437749-14-020036:mdna:30]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-14-020036:mdna:31]
[same as prior period, unchanged from 0001437749-14-014607:mdna:29]

[0001437749-14-020036:mdna:32]
[same as prior period, unchanged from 0001437749-14-014607:mdna:30]

[0001437749-14-020036:mdna:33]
[same as prior period, unchanged from 0001437749-14-014607:mdna:31]

[0001437749-14-020036:mdna:34]
[same as prior period, unchanged from 0001437749-14-014607:mdna:32]

[0001437749-14-020036:mdna:35]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.0% of U.S. single-family detached, owner-occupied households with a home value of over $100 thousand, as defined by the U.S. Census Bureau's 2011 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment (ROI) driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. In addition, the emergence of lower cost, cleaner burning natural gas fueled generators has helped to accelerate the penetration of standby generators in the light-commercial market. Also, the importance of backup power for telecommunications infrastructure is increasing due to the growing demand for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for both residential and commercial purposes.

[0001437749-14-020036:mdna:36]
[same as prior period, unchanged from 0001437749-14-014607:mdna:34]

[0001437749-14-020036:mdna:37]
[same as prior period, unchanged from 0001437749-14-014607:mdna:35]

[0001437749-14-020036:mdna:38]
[same as prior period, unchanged from 0001437749-14-014607:mdna:36]

[0001437749-14-020036:mdna:39]
[same as prior period, unchanged from 0001437749-14-014607:mdna:37]

[0001437749-14-020036:mdna:40]
[same as prior period, unchanged from 0001437749-14-014607:mdna:38]

[0001437749-14-020036:mdna:41]
[same as prior period, unchanged from 0001437749-14-014607:mdna:39]

[0001437749-14-020036:mdna:42]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 16% to 27% of our net sales occurred in the first quarter, 20% to 23% in the second quarter, 24% to 30% in the third quarter and 25% to 34% in the fourth quarter, with different seasonality depending on the presence, timing and severity of major power outage activity. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-14-020036:mdna:43]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements and repayments of indebtedness. Additionally, cash interest expense decreased during the nine months ended September 30, 2014 compared to the nine months ended September 30, 2013, primarily due to a reduction in interest rate from the credit agreement refinancing completed in May 2013 and the 25 basis point reduction in borrowing costs during the second quarter of 2014 as a result of our net debt leverage ratio, as defined in our New Term Loan Credit Agreement, falling below 3.0 times.

[0001437749-14-020036:mdna:44]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $960 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2013 related to our acquisition by CCMP in 2006 that we expect to generate cumulative cash tax savings of approximately $374 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax deduction associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum Products business in the fourth quarter of 2011, we had approximately $48.3 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2013. We expect these assets to generate cash tax savings of $18.9 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be a $3.8 million deduction annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-14-020036:mdna:45]
[same as prior period, unchanged from 0001437749-14-014607:mdna:43]

[0001437749-14-020036:mdna:46]
[same as prior period, unchanged from 0001437749-14-014607:mdna:44]

[0001437749-14-020036:mdna:47]
Three and nine months ended September 30, 2014 compared to three and nine months ended September 30, 2013

[0001437749-14-020036:mdna:48]
[same as prior period, unchanged from 0001437749-14-014607:mdna:46]

[0001437749-14-020036:mdna:49]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 352,305 |  |  | $ | 363,269 |  |  | $ | 1,056,922 |  |  | $ | 1,109,529 |  |
| Cost of goods sold |  |  | 222,022 |  |  |  | 223,806 |  |  |  | 679,113 |  |  |  | 685,651 |  |
| Gross profit |  |  | 130,283 |  |  |  | 139,463 |  |  |  | 377,809 |  |  |  | 423,878 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 32,961 |  |  |  | 24,295 |  |  |  | 90,045 |  |  |  | 83,048 |  |
| Research and development |  |  | 7,822 |  |  |  | 7,183 |  |  |  | 23,580 |  |  |  | 20,892 |  |
| General and administrative |  |  | 13,429 |  |  |  | 13,693 |  |  |  | 39,080 |  |  |  | 40,158 |  |
| Amortization of intangible assets |  |  | 5,277 |  |  |  | 7,003 |  |  |  | 15,721 |  |  |  | 19,533 |  |
| Gain on remeasurement of contingent consideration |  |  | - |  |  |  | - |  |  |  | (4,877 | ) |  |  | - |  |
| Total operating expenses |  |  | 59,489 |  |  |  | 52,174 |  |  |  | 163,549 |  |  |  | 163,631 |  |
| Income from operations |  |  | 70,794 |  |  |  | 87,289 |  |  |  | 214,260 |  |  |  | 260,247 |  |
| Total other expense, net |  |  | (15,932 | ) |  |  | (13,244 | ) |  |  | (22,752 | ) |  |  | (59,989 | ) |
| Income before provision for income taxes |  |  | 54,862 |  |  |  | 74,045 |  |  |  | 191,508 |  |  |  | 200,258 |  |
| Provision for income taxes |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Residential power products |  | $ | 183,747 |  |  | $ | 192,728 |  |  | $ | 527,308 |  |  | $ | 644,588 |  |
| Commercial & industrial power products |  |  | 146,411 |  |  |  | 151,488 |  |  |  | 467,248 |  |  |  | 411,995 |  |
| Other |  |  | 22,147 |  |  |  | 19,053 |  |  |  | 62,366 |  |  |  | 52,946 |  |
| Net sales |  | $ | 352,305 |  |  | $ | 363,269 |  |  | $ | 1,056,922 |  |  | $ | 1,109,529 |  |

[0001437749-14-020036:mdna:50]
Net sales.    Net sales decreased $11.0 million, or 3.0%, to $352.3 million for the three months ended September 30, 2014 from $363.3 million for the three months ended September 30, 2013. Residential product sales for the third quarter of 2014 were $183.7 million as compared to $192.7 million for the comparable period in 2013. Residential product sales declined on a year-over-year basis as the prior year third quarter was still benefitting from the afterglow period of demand from Superstorm Sandy. Also, the third quarter of 2014 continued to experience a power outage severity environment that remained below normalized levels. These factors resulted in a year-over-year decline in portable generator sales and, to a lesser extent, shipments of home standby generators. Commercial and industrial (C&I) product sales for the third quarter of 2014 decreased 3.4% to $146.4 million from $151.5 million for the comparable period in 2013. Shipments to telecom national account customers declined in the current year quarter as compared to the prior year primarily resulting from reduced capital spending by certain customers. This decline was partially offset by contributions from recent acquisitions and strength in the oil & gas markets.

[0001437749-14-020036:mdna:51]
Net sales decreased $52.6 million, or 4.7%, to $1,056.9 million for the nine months ended September 30, 2014 from $1,109.5 million for the nine months ended September 30, 2013. Residential product sales for the nine months ended September 30, 2014 decreased 18.2% to $527.3 million from $644.6 million for the comparable period in 2013. Sales of residential products for the nine months ended September 30, 2013 were positively impacted by approximately $140 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during the nine months ended September 30, 2014. In addition, the current year period continued to experience a power outage severity environment that remained below normalized levels. These factors resulted in a year-over-year decline in portable generator sales and shipments of home standby generators. C&I product sales for the nine months ended September 30, 2014 increased 13.4% to $467.2 million from $412.0 million for the comparable period in 2013. The increase was primarily driven by contributions from recent acquisitions and strength in the oil & gas markets, partially offset by a decline in shipments to telecom national account customers due to reduced capital spending by certain customers, and a year-over-year decline in sales within Latin America.

[0001437749-14-020036:mdna:52]
Gross profit.    Gross profit margin for the third quarter of 2014 was 37.0% compared to 38.4% in the prior-year third quarter. The decline was primarily driven by an increase in promotional activities during the current year quarter along with the mix impact from recent acquisitions. These declines were partially offset by a higher mix of home standby generators and lower mix of organic C&I product shipments.

[0001437749-14-020036:mdna:53]
Gross profit margin for the nine months ended September 30, 2014 was 35.7% compared to 38.2% for the nine months ended September 30, 2013. Gross margin was impacted over the prior year primarily due to an increase in promotional activities during the current year along with the mix impact from recent acquisitions.

[0001437749-14-020036:mdna:54]
Operating expenses.    Operating expenses increased $7.3 million, or 14.0%, to $59.5 million for the three months ended September 30, 2014 from $52.2 million for the three months ended September 30, 2013. The increase was driven by a $5.6 million favorable adjustment to warranty reserves in the third quarter of 2013 that did not repeat in the current year, along with increased marketing and advertising expenses and the addition of operating expenses associated with recent acquisitions. This was partially offset by a $1.7 million year-over-year decline in amortization of intangible assets.

[0001437749-14-020036:mdna:55]
Operating expenses decreased $0.1 million, or 0.1%, to $163.5 million for the nine months ended September 30, 2014 from $163.6 million for the nine months ended September 30, 2013, primarily due to a $4.9 million gain recorded in the second quarter of 2014 relating to a remeasurement of a contingent earn-out obligation from a recent acquisitions and a $3.8 million year–over-year decline in amortization of intangible assets. This was primarily offset by a $12.3 million favorable adjustment to warranty reserves through the first three quarters of 2013 that did not repeat in the current year.

[0001437749-14-020036:mdna:56]
Other expense.    Other expense increased $2.7 million, or 20.3%, to $15.9 million for the three months ended September 30, 2014 from $13.2 million for the three months ended September 30, 2013. During the third quarter of 2014, a voluntary $50 million prepayment of term loan debt was made, which resulted in the recording of a $1.8 million loss on extinguishment of debt.

[0001437749-14-020036:mdna:57]
Other expense decreased $37.2 million, or 62.1%, to $22.8 million for the nine months ended September 30, 2014 from $60.0 million for the nine months ended September 30, 2013. Beginning in the second quarter of 2014, there was a 25 basis point reduction in borrowing costs as a result of the net debt leverage ratio falling below 3.0 times, resulting in a $16.0 million non-cash gain being recorded in the second quarter of 2014. In conjunction with the May 2013 refinancing and other debt prepayments made in the prior year second quarter, a $13.5 million loss on extinguishment of debt was recorded during the second quarter of 2013. During the third quarter of 2014, a voluntary $50 million prepayment of term loan debt was made, which resulted in the recording of a $1.8 million loss on extinguishment of debt. Additionally, there was a $7.0 million year-over-year decrease in interest expense.

[0001437749-14-020036:mdna:58]
Provision for income taxes.   Income tax expense was $18.4 million for the three months ended September 30, 2014 compared to $27.0 million for the three months ended September 30, 2013. Income tax expense was $66.3 million for the nine months ended September 30, 2014 compared to $74.2 million for the nine months ended September 30, 2013. The decrease in income tax expense was primarily driven by the decrease in pre-tax income during the three and nine months ended September 30, 2014 as compared to the three and nine months ended September 30, 2013, and the decrease in effective income tax rate from 37.1% for the nine months ended September 30, 2013 to 34.6% for the nine months ended September 30, 2014, which included a $1.1 million discrete tax benefit due to utilization of the federal research credit. Additionally, the decrease in the effective income tax rate year-over-year is primarily due to the Company’s ability to utilize the federal domestic production activity deduction due to sufficient taxable income, as well as the lower tax rate of a foreign subsidiary acquired during the third quarter of 2013.

[0001437749-14-020036:mdna:59]
Net income.    Due to the factors outlined above, we generated net income of $36.5 million for the three months ended September 30, 2014 compared to $47.1 million for the three months ended September 30, 2013, and generated net income of $125.2 million for the nine months ended September 30, 2014 compared to $126.0 million for the nine months ended September 30, 2013.

[0001437749-14-020036:mdna:60]
Adjusted EBITDA.    Adjusted EBITDA, as defined in the accompanying reconciliation schedules, decreased $17.0 million or 17.0%, to $83.1 million for the three months ended September 30, 2014 from $100.1 million for the three months ended September 30, 2013, due to the factors outlined above. Adjusted EBITDA decreased $53.9 million or 18.0%, to $245.1 million for the nine months ended September 30, 2014 from $299.0 million for the nine months ended September 30, 2013, due to the factors outlined above.

[0001437749-14-020036:mdna:61]
Adjusted Net Income.    Adjusted Net Income, as defined in the accompanying reconciliation schedules, of $57.9 million for the three months ended September 30, 2014 decreased 21.5% from $73.7 million for the three months ended September 30, 2013, due to the factors outlined above. Adjusted Net Income of $165.7 million for the nine months ended September 30, 2014 decreased 26.1% from $224.1 million for the nine months ended September 30, 2013, due to the factors outlined above.

[0001437749-14-020036:mdna:62]
[same as prior period, unchanged from 0001437749-14-014607:mdna:60]

[0001437749-14-020036:mdna:63]
[same as prior period, unchanged from 0001437749-14-014607:mdna:61]

[0001437749-14-020036:mdna:64]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL revolving credit facility.

[0001437749-14-020036:mdna:65]
On May 31, 2013, we amended and restated our then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement). The New Term Loan Credit Agreement provides for a $1.2 billion term loan B credit facility (New Term Loan) and includes a $300.0 million uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay the previous credit agreement and to fund a special cash dividend of $5.00 per share on our common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses. The New Term Loan initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans has been reduced to 1.50% and the applicable margin related to LIBOR rate loans has been reduced to 2.50%, to the extent that Generac Power Systems’ (Borrower) net debt leverage ratio, as defined in the New Term Loan Credit Agreement, is below 3.00 to 1.00 for that measurement period. For the third quarter of 2014, the Borrower’s net debt leverage ratio was below 3.00 to 1.00.

[0001437749-14-020036:mdna:66]
Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, we amended our then existing ABL credit agreement. The amendment provides for a one year extension of the maturity date in respect of the $150.0 million senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018. As of September 30, 2014, no amounts were outstanding under the ABL Facility.

[0001437749-14-020036:mdna:67]
For additional information regarding our credit agreements and their potential impact, we refer you to Note 8, “Credit Agreements” of our condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-14-020036:mdna:68]
At September 30, 2014, we had cash and cash equivalents of $173.2 million and $148.5 million of net availability under our revolving credit facility, net of outstanding letters of credit.

[0001437749-14-020036:mdna:69]
[same as prior period, unchanged from 0001437749-14-014607:mdna:66]

[0001437749-14-020036:mdna:70]
We believe that our cash flow from operations and availability under our revolving credit facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-14-020036:mdna:71]
[same as prior period, unchanged from 0001437749-14-014607:mdna:68]

[0001437749-14-020036:mdna:72]
Nine months ended September 30, 2014 compared to nine months ended September 30, 2013

[0001437749-14-020036:mdna:73]
[same as prior period, unchanged from 0001437749-14-014607:mdna:70]

[0001437749-14-020036:mdna:74]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 142,511 |  |  | $ | 155,213 |  |  | $ | (12,702 | ) |  |  | (8.2 | )% |
| Net cash used in investing activities |  | $ | (28,024 | ) |  | $ | (85,889 | ) |  | $ | 57,865 |  |  |  | 67.4 | % |
| Net cash used in financing activities |  | $ | (90,522 | ) |  | $ | (60,773 | ) |  | $ | (29,749 | ) |  |  | (49.0 | )% |

[0001437749-14-020036:mdna:75]
Net cash provided by operating activities was $142.5 million for the nine months ended September 30, 2014 compared to $155.2 million for the nine months ended September 30, 2013. This 8.2% decrease was primarily driven by lower operating income in the current year, partially offset by a reduction in working capital investment due to lower inventory levels in 2014 as compared to 2013. The prior year period included a significant use of cash to replenish finished goods inventory levels that had been depleted from major power outages.

[0001437749-14-020036:mdna:76]
Net cash used in investing activities was $28.0 million for the nine months ended September 30, 2014, which primarily related to the purchase of property and equipment. Net cash used in investing activities was $85.9 million for the nine months ended September 30, 2013, which included cash payments of $14.3 million for the purchase of property and equipment, and $80.3 million for the acquisition of the Tower Light business, partially offset by cash proceeds of $2.3 million from the sale of a business and $6.3 million relating to the finalization of the Ottomotores purchase price.

[0001437749-14-020036:mdna:77]
Net cash used in financing activities was $90.5 million for the nine months ended September 30, 2014, primarily representing $93.6 million of debt repayments ($68.9 million of long-term borrowings and $24.7 of short-term borrowings) partially offset by $4.9 million cash proceeds from short-term borrowings. In addition, the Company paid $10.3 million related to the net share settlement of equity awards which was partially offset by $9.2 million of cash inflow related to excess tax benefits of equity awards.

[0001437749-14-020036:mdna:78]
Net cash used in financing activities was $60.8 million for the nine months ended September 30, 2013, primarily representing the net cash impact of debt prepayments and the dividend recapitalization transaction that occurred during the first half of 2013, including cash proceeds from long-term borrowings of $1,200.0 million, offset by $897.8 million of long-term borrowing prepayments. The Company paid $21.9 million for transaction fees incurred in connection with the dividend recapitalization transaction. Following the refinancing, the Company paid a special cash dividend of $5.00 per share ($340.8 million) on the Company’s common stock (incremental to the $2.6 million cash dividends paid during the first quarter of 2013). In addition, the Company paid $12.5 million in taxes related to the net share settlement of equity awards which was partially offset by approximately $9.5 million of excess tax benefits of equity awards. Finally, the Company received net cash proceeds of $16.0 million from short-term borrowings, which were offset by approximately $10.5 million of short-term borrowing repayments. .

[0001437749-14-020036:mdna:79]
[same as prior period, unchanged from 0001437749-14-014607:mdna:77]

[0001437749-14-020036:mdna:80]
For the nine months ended September 30, 2014, the Company made a total of $62,000 in voluntary prepayments of its term loan debt. Refer to Note 8, “Credit Agreements” to the condensed consolidated financial statements for further information. Other than these debt prepayments, there have been no material changes to our contractual obligations since the March 3, 2014 filing of our Annual Report on Form 10-K for the fiscal year ended December 31, 2013.

[0001437749-14-020036:mdna:81]
[same as prior period, unchanged from 0001437749-14-014607:mdna:79]

[0001437749-14-020036:mdna:82]
[same as prior period, unchanged from 0001437749-14-014607:mdna:80]

[0001437749-14-020036:mdna:83]
[same as prior period, unchanged from 0001437749-14-014607:mdna:81]

[0001437749-14-020036:mdna:84]
[same as prior period, unchanged from 0001437749-14-014607:mdna:82]

[0001437749-14-020036:mdna:85]
As discussed in our Annual Report on Form 10-K for the fiscal year ended December 31, 2013, in preparing the financial statements in accordance with accounting principles generally accepted in the U.S., we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to accounting principles generally accepted in the U.S., and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment, business combinations and purchase accounting, defined benefit pension obligations, estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty, other contingencies, derivative accounting, income taxes and share based compensation.

[0001437749-14-020036:mdna:86]
[same as prior period, unchanged from 0001437749-14-014607:mdna:84]

[0001437749-14-020036:mdna:87]
[same as prior period, unchanged from 0001437749-14-014607:mdna:85]

[0001437749-14-020036:mdna:88]
[same as prior period, unchanged from 0001437749-14-014607:mdna:86]

[0001437749-14-020036:mdna:89]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-14-020036:mdna:90]
[same as prior period, unchanged from 0001437749-14-014607:mdna:88]

[0001437749-14-020036:mdna:91]
[same as prior period, unchanged from 0001437749-14-014607:mdna:89]

[0001437749-14-020036:mdna:92]
[same as prior period, unchanged from 0001437749-14-014607:mdna:90]

[0001437749-14-020036:mdna:93]
[same as prior period, unchanged from 0001437749-14-014607:mdna:91]

[0001437749-14-020036:mdna:94]
[same as prior period, unchanged from 0001437749-14-014607:mdna:92]

[0001437749-14-020036:mdna:95]
[same as prior period, unchanged from 0001437749-14-014607:mdna:93]

[0001437749-14-020036:mdna:96]
[same as prior period, unchanged from 0001437749-14-014607:mdna:94]

[0001437749-14-020036:mdna:97]
[same as prior period, unchanged from 0001437749-14-014607:mdna:95]

[0001437749-14-020036:mdna:98]
[same as prior period, unchanged from 0001437749-14-014607:mdna:96]

[0001437749-14-020036:mdna:99]
[same as prior period, unchanged from 0001437749-14-014607:mdna:97]

[0001437749-14-020036:mdna:100]
[same as prior period, unchanged from 0001437749-14-014607:mdna:98]

[0001437749-14-020036:mdna:101]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; |

[0001437749-14-020036:mdna:102]
[same as prior period, unchanged from 0001437749-14-014607:mdna:100]

[0001437749-14-020036:mdna:103]
[same as prior period, unchanged from 0001437749-14-014607:mdna:101]

[0001437749-14-020036:mdna:104]
[same as prior period, unchanged from 0001437749-14-014607:mdna:102]

[0001437749-14-020036:mdna:105]
[same as prior period, unchanged from 0001437749-14-014607:mdna:103]

[0001437749-14-020036:mdna:106]
[same as prior period, unchanged from 0001437749-14-014607:mdna:104]

[0001437749-14-020036:mdna:107]
[same as prior period, unchanged from 0001437749-14-014607:mdna:105]

[0001437749-14-020036:mdna:108]
[same as prior period, unchanged from 0001437749-14-014607:mdna:106]

[0001437749-14-020036:mdna:109]
[same as prior period, unchanged from 0001437749-14-014607:mdna:107]

[0001437749-14-020036:mdna:110]
[same as prior period, unchanged from 0001437749-14-014607:mdna:109]

[0001437749-14-020036:mdna:111]
[same as prior period, unchanged from 0001437749-14-014607:mdna:110]

[0001437749-14-020036:mdna:112]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our board of directors in the context of the board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our board of directors in the context of the board's review of our quarterly financial statements and certification by our chief financial officer in a compliance certificate provided to the lenders under our New Term Loan Credit Agreement and New ABL Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-14-020036:mdna:113]
[same as prior period, unchanged from 0001437749-14-014607:mdna:112]

[0001437749-14-020036:mdna:114]
24

[0001437749-14-020036:mdna:115]
[same as prior period, unchanged from 0001437749-14-014607:mdna:113]

[0001437749-14-020036:mdna:116]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Interest expense |  |  | 12,294 |  |  |  | 12,494 |  |  |  | 35,411 |  |  |  | 42,432 |  |
| Depreciation and amortization |  |  | 8,789 |  |  |  | 9,846 |  |  |  | 25,745 |  |  |  | 27,502 |  |
| Income taxes provision |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,099 |  |  |  | (782 | ) |  |  | (4,653 | ) |  |  | 35 |  |
| Non-cash share-based compensation expense (b) |  |  | 3,200 |  |  |  | 3,279 |  |  |  | 9,403 |  |  |  | 9,471 |  |
| Loss on extinguishment of debt (c) |  |  | 1,836 |  |  |  | - |  |  |  | 1,836 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (d) |  |  | - |  |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and credit facility fees (e) |  |  | 889 |  |  |  | 1,125 |  |  |  | 1,590 |  |  |  | 3,028 |  |
| Other |  |  | 91 |  |  |  | 61 |  |  |  | 264 |  |  |  | 904 |  |
| Adjusted EBITDA |  | $ | 83,060 |  |  | $ | 100,068 |  |  | $ | 245,090 |  |  | $ | 298,966 |  |

[0001437749-14-020036:mdna:117]
[same as prior period, unchanged from 0001437749-14-014607:mdna:115]

[0001437749-14-020036:mdna:118]
• for the three and nine months ended September 30, 2014, losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. Additionally, the nine months ended September 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-14-020036:mdna:119]
• for the three and nine months ended September 30, 2013, unrealized mark-to-market adjustments on commodity contracts, losses on disposals of assets and an adjustment to an earn-out obligation in connection with permitted business acquisitions, as defined in our credit agreement.

[0001437749-14-020036:mdna:120]
[same as prior period, unchanged from 0001437749-14-014607:mdna:118]

[0001437749-14-020036:mdna:121]
[same as prior period, unchanged from 0001437749-14-014607:mdna:119]

[0001437749-14-020036:mdna:122]
[same as prior period, unchanged from 0001437749-14-014607:mdna:120]

[0001437749-14-020036:mdna:123]
[same as prior period, unchanged from 0001437749-14-014607:mdna:121]

[0001437749-14-020036:mdna:124]
(c) For the nine months ended September 30, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three and nine months ended September 30, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment.

[0001437749-14-020036:mdna:125]
(d) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-14-020036:mdna:126]
[same as prior period, unchanged from 0001437749-14-014607:mdna:124]

[0001437749-14-020036:mdna:127]
• administrative agent fees and revolving credit facility commitment fees under our New Term Loan Credit Agreement and New ABL Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-14-020036:mdna:128]
[same as prior period, unchanged from 0001437749-14-014607:mdna:126]

[0001437749-14-020036:mdna:129]
[same as prior period, unchanged from 0001437749-14-014607:mdna:127]

[0001437749-14-020036:mdna:130]
[same as prior period, unchanged from 0001437749-14-014607:mdna:128]

[0001437749-14-020036:mdna:131]
[same as prior period, unchanged from 0001437749-14-014607:mdna:129]

[0001437749-14-020036:mdna:132]
[same as prior period, unchanged from 0001437749-14-014607:mdna:130]

[0001437749-14-020036:mdna:133]
[same as prior period, unchanged from 0001437749-14-014607:mdna:131]

[0001437749-14-020036:mdna:134]
[same as prior period, unchanged from 0001437749-14-014607:mdna:132]

[0001437749-14-020036:mdna:135]
[same as prior period, unchanged from 0001437749-14-014607:mdna:133]

[0001437749-14-020036:mdna:136]
[same as prior period, unchanged from 0001437749-14-014607:mdna:134]

[0001437749-14-020036:mdna:137]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (Dollars in thousands, except share and per share data) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net income |  | $ | 36,497 |  |  | $ | 47,093 |  |  | $ | 125,223 |  |  | $ | 126,021 |  |
| Provision for income taxes |  |  | 18,365 |  |  |  | 26,952 |  |  |  | 66,285 |  |  |  | 74,237 |  |
| Income before provision for income taxes |  |  | 54,862 |  |  |  | 74,045 |  |  |  | 191,508 |  |  |  | 200,258 |  |
| Amortization of intangible assets |  |  | 5,277 |  |  |  | 7,003 |  |  |  | 15,721 |  |  |  | 19,533 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,824 |  |  |  | 1,220 |  |  |  | 4,845 |  |  |  | 3,547 |  |
| Loss on extinguishment of debt (a) |  |  | 1,836 |  |  |  | - |  |  |  | 1,836 |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (b) |  |  | - |  |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (c) |  |  | 565 |  |  |  | 977 |  |  |  | (4,134 | ) |  |  | 2,154 |  |
| Adjusted net income before provision for income taxes |  |  | 64,364 |  |  |  | 83,245 |  |  |  | 193,762 |  |  |  | 240,828 |  |
| Cash income tax expense (d) |  |  | (6,470 | ) |  |  | (9,510 | ) |  |  | (28,030 | ) |  |  | (16,680 | ) |
| Adjusted net income |  | $ | 57,894 |  |  | $ | 73,735 |  |  | $ | 165,732 |  |  | $ | 224,148 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.83 |  |  | $ | 1.06 |  |  | $ | 2.37 |  |  | $ | 3.22 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,033,224 |  |  |  | 69,887,025 |  |  |  | 70,050,953 |  |  |  | 69,627,215 |  |

[0001437749-14-020036:mdna:138]
(a) For the nine months ended September 30, 2013, relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt. For the three and nine months ended September 30, 2014, relates to the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment.

[0001437749-14-020036:mdna:139]
[same as prior period, unchanged from 0001437749-14-014607:mdna:137]

[0001437749-14-020036:mdna:140]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. The nine months ended September 30, 2014 also includes certain purchase accounting adjustments and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-14-020036:mdna:141]
(d) Amount for the three and nine months ended September 30, 2014 is based on an anticipated cash income tax rate of approximately 14% for the full year-ended 2014. Amount for the three and nine months ended September 30, 2013 is based on an anticipated cash income tax rate of approximately 9% for the full year-ended 2013.

[0001437749-14-020036:mdna:142]
[same as prior period, unchanged from 0001437749-14-014607:mdna:140]

[0001437749-14-020036:mdna:143]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. The guidance is effective for fiscal years and interim periods within those years, beginning after December 15, 2016. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-14-020036:mdna:144]
In July 2013, the FASB issued ASU No. 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The guidance requires an entity to net their unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements against a deferred tax asset for a net operating loss carryforward, a similar tax loss or tax credit carryforward, unless such tax loss or credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes resulting from the disallowance of a tax position. In the event that the tax position is disallowed or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit shall be presented in the financial statements as a liability and shall not be combined with deferred tax assets. The guidance is effective for fiscal years and interim periods within those years, beginning after December 15, 2013, and is to be applied prospectively to all unrecognized tax benefits that exist at the effective date. The Company’s adoption of this standard did not have a material impact on the Company’s financial condition or results of operations.

[0001437749-14-020036:mdna:145]
[same as prior period, unchanged from 0001437749-14-014607:mdna:143]
