# GNRC 8-K — 0001437749-14-013723 filed 2014-07-31

## item codes, every 8-K on or before 2014-08-07

- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2014-08-07

- none on or before 2014-08-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-14-013723:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-14-013723:8k_2_02:2]
ex99-1.htm

[0001437749-14-013723:8k_2_02:3]
Exhibit 99.1

[0001437749-14-013723:8k_2_02:4]
Generac Reports Second Quarter 2014 Results

[0001437749-14-013723:8k_2_02:5]
Strong home standby shipments drive sequential sales improvement in residential products as increased sales from C&I products further diversifies business

[0001437749-14-013723:8k_2_02:6]
WAUKESHA, WISCONSIN, (July 31, 2014) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its second quarter ended June 30, 2014.

[0001437749-14-013723:8k_2_02:7]
Second Quarter 2014 Highlights

[0001437749-14-013723:8k_2_02:8]
| ● | Net sales increased over the prior year by 4.6% to $362.6 million as compared to $346.7 million in the second quarter of 2013. |

[0001437749-14-013723:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales increased 22.5% to $163.5 million as compared $133.4 million in the prior-year second quarter, primarily due to the contribution of recent acquisitions and continued strength in the oil & gas market. |

[0001437749-14-013723:8k_2_02:10]
|  | - | Residential product sales were $179.6 million during the second quarter of 2014 as compared to $196.6 million in the prior year quarter. The prior year second quarter benefited from approximately $40 million in shipments due to Superstorm Sandy. Excluding this prior year benefit, residential product sales increased approximately 15% primarily as a result of strong home standby generator shipments. |

[0001437749-14-013723:8k_2_02:11]
| ● | Net income during the second quarter of 2014 was $54.0 million, or $0.77 per share, as compared to $28.3 million, or $0.40 per share, for the same period of 2013. |

[0001437749-14-013723:8k_2_02:12]
| ● | Adjusted net income, as defined in the accompanying reconciliation schedules, was $57.1 million, or $0.82 per share, as compared to $66.6 million, or $0.95 per share, in the second quarter of 2013. |

[0001437749-14-013723:8k_2_02:13]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $84.5 million as compared to $90.1 million in the second quarter last year. |

[0001437749-14-013723:8k_2_02:14]
| ● | Cash flow from operations in the second quarter of 2014 was $48.9 million as compared to $36.1 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $40.5 million as compared to $30.3 million in the second quarter of 2013. |

[0001437749-14-013723:8k_2_02:15]
| ● | For the trailing four quarters, including the second quarter of 2014, net sales were $1.444 billion; net income was $184.3 million; adjusted EBITDA was $365.7 million; cash flow from operations was $270.9 million; and free cash flow was $236.9 million. |

[0001437749-14-013723:8k_2_02:16]
“Our second quarter results for residential products were seasonally higher as we saw shipments increase as compared to the first quarter of 2014 due to strength in home standby generators. We remain focused on a number of key initiatives to continue to grow the market, further building on our leadership position in this product category,” said Aaron Jagdfeld, President and Chief Executive Officer. “C&I products continue to represent a growing portion of our sales as we have recently increased our exposure to new markets such as oil & gas, broadened our industrial product line, and strengthened our industrial distribution network to further diversify our business. We also continue to convert a significant amount of our earnings to free cash flow, providing us with the flexibility to drive our Powering Ahead strategic plan forward.”

[0001437749-14-013723:8k_2_02:17]
Additional Second quarter 2014 Highlights

[0001437749-14-013723:8k_2_02:18]
Residential product sales for the second quarter of 2014 were $179.6 million as compared to $164.0 million in the first quarter of 2014, and as compared to $196.6 million for the second quarter of 2013. Sales of residential products during the prior-year second quarter were positively impacted by approximately $40 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during the second quarter of 2014. Excluding this benefit in the prior year quarter, residential product revenue increased approximately 15% during the current year quarter, driven by strong shipments of home standby generators. In addition, increased revenue from power washer products contributed to this year-over-year sales growth in residential products.

[0001437749-14-013723:8k_2_02:19]
C&I product sales for the second quarter of 2014 increased 22.5% to $163.5 million from $133.4 million for the comparable period in 2013. The improvement was driven primarily by contributions from recent acquisitions and strength in oil & gas end markets, along with increased sales of natural gas generators used in light commercial and retail applications. Partially offsetting this strength was a year-over-year decline in sales within Latin America driven by the combination of a difficult prior-year comparison related to certain large projects which did not repeat, as well as overall economic softness in the region.

[0001437749-14-013723:8k_2_02:20]
Gross profit margin for the second quarter of 2014 was 35.3% compared to 37.8% in the prior-year second quarter. Gross margin was impacted over the prior year due to the addition of recent acquisitions along with a return to regular promotional activities consistent with a period of normal seasonality.

[0001437749-14-013723:8k_2_02:21]
Operating expenses for the second quarter of 2014 declined $4.7 million, or 8.6%, as compared to the second quarter of 2013, primarily driven by a $4.9 million gain recorded in the current year quarter relating to a remeasurement of a contingent earn-out obligation from a recent acquisition. Excluding this gain, operating expenses were approximately flat relative to prior year despite the addition of SG&A costs associated with recent acquisitions.

[0001437749-14-013723:8k_2_02:22]
Interest expense in the second quarter of 2014 declined to $11.4 million compared to $14.3 million in the same period last year, resulting from a reduction in interest rate from the credit agreement refinancing completed in May 2013. In conjunction with the May 2013 refinancing and other debt prepayments made in the prior year quarter, a $13.5 million loss on extinguishment of debt was recorded during the second quarter of 2013.

[0001437749-14-013723:8k_2_02:23]
Beginning in the second quarter of 2014, there was a further 25 basis point reduction in borrowing costs as a result of the leverage ratio as defined in the credit agreement falling below 3.0 times, resulting in a $16.0 million non-cash gain being recorded in the current year quarter.

[0001437749-14-013723:8k_2_02:24]
2014 Outlook

[0001437749-14-013723:8k_2_02:25]
The Company is reaffirming its prior guidance for 2014 in terms of revenue growth, EBITDA margins and cash flows. For the full-year 2014, the Company still expects net sales to increase in the mid-single digit range as compared to the prior year. This sales outlook assumes an increased level of power outage severity in the second half of 2014 as compared to recent quarters, returning to a more normalized annual baseline level. Adjusted EBITDA margins are expected to remain in the mid-20% range as previously guided, which are consistent with the average levels seen during the past four years. Free cash flow is still expected to be approximately 90% of full year 2014 adjusted net income.

[0001437749-14-013723:8k_2_02:26]
“We remain excited about the compelling penetration opportunities for our residential and light commercial standby generators as we continue to focus our efforts on several high impact initiatives to increase the adoption for these products,” continued Mr. Jagdfeld. “These initiatives are targeted at improving the awareness, availability and affordability of standby generators and are highlighted by our innovative sales and marketing processes, our efforts to increase and develop distribution, and our introduction of new products. In addition, we have several initiatives aimed at increasing our share of the C&I market by leveraging our recently expanded product offering. We also believe the overall secular trends toward natural gas generators, rental of mobile power equipment, and the penetration of certain end markets such as telecommunications and oil & gas will continue to drive additional growth. Through the execution of our Powering Ahead strategic plan, we expect to capitalize on these long-term opportunities, while also becoming a more balanced company as we further implement our diversification and international expansion strategies.”

[0001437749-14-013723:8k_2_02:27]
Conference Call and Webcast

[0001437749-14-013723:8k_2_02:28]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, July 31, 2014 to discuss highlights of the second quarter operating results. The conference call can be accessed by dialing (877) 703-6103 (domestic) or +1 (857) 244-7302 (international) and entering passcode 50076462.

[0001437749-14-013723:8k_2_02:29]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-14-013723:8k_2_02:30]
Following the live webcast, a replay will be available on the Company's web site. A telephonic replay will also be available approximately one hour after the call and can be accessed by dialing (888) 286-8010 (domestic) or +1 (617) 801-6888 (international) and entering passcode 19346995. The telephonic replay will be available for 30 days.

[0001437749-14-013723:8k_2_02:31]
About Generac

[0001437749-14-013723:8k_2_02:32]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial and construction markets, Generac's power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-14-013723:8k_2_02:33]
Forward-looking Information

[0001437749-14-013723:8k_2_02:34]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-14-013723:8k_2_02:35]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-14-013723:8k_2_02:36]
|  | ● | demand for Generac products; |

[0001437749-14-013723:8k_2_02:37]
|  | ● | frequency and duration of power outages; |

[0001437749-14-013723:8k_2_02:38]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-14-013723:8k_2_02:39]
|  | ● | the impact on our results of possible fluctuations in interest rates; |

[0001437749-14-013723:8k_2_02:40]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-14-013723:8k_2_02:41]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-14-013723:8k_2_02:42]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-14-013723:8k_2_02:43]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-14-013723:8k_2_02:44]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-14-013723:8k_2_02:45]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-14-013723:8k_2_02:46]
|  | ● | loss of key management and employees; |

[0001437749-14-013723:8k_2_02:47]
|  | ● | increase in product and other liability claims; and |

[0001437749-14-013723:8k_2_02:48]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-14-013723:8k_2_02:49]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2013 Annual Report on Form 10K and in its periodic reports on Form 10Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-14-013723:8k_2_02:50]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-14-013723:8k_2_02:51]
Reconciliations to GAAP Financial Metrics

[0001437749-14-013723:8k_2_02:52]
Adjusted EBITDA

[0001437749-14-013723:8k_2_02:53]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements. To supplement the Company's condensed consolidated financial statements presented in accordance with US GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-14-013723:8k_2_02:54]
Adjusted Net Income

[0001437749-14-013723:8k_2_02:55]
To further supplement Generac's condensed consolidated financial statements presented in accordance with US GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision (benefit) for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, and certain other non-cash gains and losses.

[0001437749-14-013723:8k_2_02:56]
Free Cash Flow

[0001437749-14-013723:8k_2_02:57]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with US GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-14-013723:8k_2_02:58]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with US GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-14-013723:8k_2_02:59]
SOURCE: Generac Holdings Inc.

[0001437749-14-013723:8k_2_02:60]
CONTACT:

[0001437749-14-013723:8k_2_02:61]
Michael W. Harris

[0001437749-14-013723:8k_2_02:62]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-14-013723:8k_2_02:63]
Michael.Harris@Generac.com

[0001437749-14-013723:8k_2_02:64]
Generac Holdings Inc.

[0001437749-14-013723:8k_2_02:65]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-14-013723:8k_2_02:66]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-14-013723:8k_2_02:67]
(Unaudited)

[0001437749-14-013723:8k_2_02:68]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 362,609 |  |  | $ | 346,688 |  |  | $ | 704,617 |  |  | $ | 746,260 |  |
| Costs of goods sold |  |  | 234,597 |  |  |  | 215,735 |  |  |  | 457,091 |  |  |  | 461,845 |  |
| Gross profit |  |  | 128,012 |  |  |  | 130,953 |  |  |  | 247,526 |  |  |  | 284,415 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 29,115 |  |  |  | 27,072 |  |  |  | 57,084 |  |  |  | 58,753 |  |
| Research and development |  |  | 8,012 |  |  |  | 7,064 |  |  |  | 15,758 |  |  |  | 13,709 |  |
| General and administrative |  |  | 12,503 |  |  |  | 14,039 |  |  |  | 25,651 |  |  |  | 26,465 |  |
| Amortization of intangible assets |  |  | 5,099 |  |  |  | 6,345 |  |  |  | 10,444 |  |  |  | 12,530 |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  | – |  |  |  | (4,877 | ) |  | – |  |
| Total operating expenses |  |  | 49,852 |  |  |  | 54,520 |  |  |  | 104,060 |  |  |  | 111,457 |  |
| Income from operations |  |  | 78,160 |  |  |  | 76,433 |  |  |  | 143,466 |  |  |  | 172,958 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,428 | ) |  |  | (14,263 | ) |  |  | (23,117 | ) |  |  | (29,938 | ) |
| Investment income |  |  | 42 |  |  |  | 25 |  |  |  | 81 |  |  |  | 42 |  |
| Loss on extinguishment of debt |  | – |  |  |  | (13,497 | ) |  | – |  |  |  | (15,336 | ) |
| Gain on change in contractual interest rate |  |  | 16,014 |  |  | – |  |  |  | 16,014 |  |  | – |  |
| Other, net |  |  | (366 | ) |  |  | (1,909 | ) |  |  | 202 |  |  |  | (1,513 | ) |
| Total other expense, net |  |  | 4,262 |  |  |  | (29,644 | ) |  |  | (6,820 | ) |  |  | (46,745 | ) |
| Income before provision for income taxes |  |  | 82,422 |  |  |  | 46,789 |  |  |  | 136,646 |  |  |  | 126,213 |  |
| Provision for income taxes |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Net income per common share - basic: |  | $ | 0.79 |  |  | $ | 0.41 |  |  | $ | 1.30 |  |  | $ | 1.16 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,538,251 |  |  |  | 68,140,330 |  |  |  | 68,481,682 |  |  |  | 68,003,164 |  |
| Net income per common share - diluted: |  | $ | 0.77 |  |  | $ | 0.40 |  |  | $ | 1.27 |  |  | $ | 1.13 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,087,976 |  |  |  | 69,809,599 |  |  |  | 70,088,438 |  |  |  | 69,801,498 |  |
| Dividends declared per share |  | $ | - |  |  | $ | 5.00 |  |  | $ | - |  |  | $ | 5.00 |  |
| Comprehensive income |  | $ | 52,730 |  |  | $ | 29,276 |  |  | $ | 87,002 |  |  | $ | 80,952 |  |

[0001437749-14-013723:8k_2_02:69]
Generac Holdings Inc.

[0001437749-14-013723:8k_2_02:70]
Condensed Consolidated Balance Sheets

[0001437749-14-013723:8k_2_02:71]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-14-013723:8k_2_02:72]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 197,959 |  |  | $ | 150,147 |  |
| Restricted cash |  | – |  |  |  | 6,645 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 203,692 |  |  |  | 164,907 |  |
| Inventories |  |  | 287,233 |  |  |  | 300,253 |  |
| Deferred income taxes |  |  | 22,392 |  |  |  | 26,869 |  |
| Prepaid expenses and other assets |  |  | 5,879 |  |  |  | 5,358 |  |
| Total current assets |  |  | 717,155 |  |  |  | 654,179 |  |
| Property and equipment, net |  |  | 153,063 |  |  |  | 146,390 |  |
| Customer lists, net |  |  | 36,076 |  |  |  | 42,764 |  |
| Patents, net |  |  | 58,509 |  |  |  | 62,418 |  |
| Trade names, net |  |  | 173,062 |  |  |  | 173,196 |  |
| Goodwill |  |  | 607,763 |  |  |  | 608,287 |  |
| Other intangible assets, net |  |  | 3,543 |  |  |  | 4,447 |  |
| Deferred income taxes |  |  | 61,391 |  |  |  | 85,104 |  |
| Deferred financing costs, net |  |  | 18,548 |  |  |  | 20,051 |  |
| Other assets |  |  | 58 |  |  |  | 1,369 |  |
| Total assets |  | $ | 1,829,168 |  |  | $ | 1,798,205 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 6,509 |  |  | $ | 9,575 |  |
| Accounts payable |  |  | 116,149 |  |  |  | 109,238 |  |
| Accrued wages and employee benefits |  |  | 16,115 |  |  |  | 26,564 |  |
| Other accrued liabilities |  |  | 74,840 |  |  |  | 92,997 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 436 |  |  |  | 12,471 |  |
| Total current liabilities |  |  | 214,049 |  |  |  | 250,845 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,154,316 |  |  |  | 1,175,349 |  |
| Other long-term liabilities |  |  | 52,241 |  |  |  | 54,940 |  |
| Total liabilities |  |  | 1,420,606 |  |  |  | 1,481,134 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,026,792 and 68,767,367 shares issued at June 30, 2014 and December 31, 2013, respectively |  |  | 690 |  |  |  | 688 |  |
| Additional paid-in capital |  |  | 427,269 |  |  |  | 421,672 |  |
| Treasury stock, at cost |  |  | (7,681 | ) |  |  | (6,571 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 194,539 |  |  |  | 105,813 |  |
| Accumulated other comprehensive loss |  |  | (4,139 | ) |  |  | (2,415 | ) |
| Total stockholders’ equity |  |  | 408,562 |  |  |  | 317,071 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,829,168 |  |  | $ | 1,798,205 |  |

[0001437749-14-013723:8k_2_02:73]
Generac Holdings Inc.

[0001437749-14-013723:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001437749-14-013723:8k_2_02:75]
(Dollars in Thousands)

[0001437749-14-013723:8k_2_02:76]
(Unaudited)

[0001437749-14-013723:8k_2_02:77]
|  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 6,512 |  |  |  | 5,126 |  |
| Amortization of intangible assets |  |  | 10,444 |  |  |  | 12,530 |  |
| Amortization of original issue discount |  |  | 1,514 |  |  |  | 1,138 |  |
| Amortization of deferred financing costs |  |  | 1,507 |  |  |  | 1,189 |  |
| Amortization of unrealized loss on interest rate swaps |  | – |  |  |  | 2,005 |  |
| Loss on extinguishment of debt |  | – |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate |  |  | (16,014 | ) |  | – |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  | – |  |
| Provision for losses on accounts receivable |  |  | 115 |  |  |  | 636 |  |
| Deferred income taxes |  |  | 28,145 |  |  |  | 35,324 |  |
| Loss on disposal of property and equipment |  |  | 95 |  |  |  | 36 |  |
| Share-based compensation expense |  |  | 6,203 |  |  |  | 6,192 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (38,924 | ) |  |  | (36,908 | ) |
| Inventories |  |  | 12,460 |  |  |  | (62,561 | ) |
| Other assets |  |  | 839 |  |  |  | 182 |  |
| Accounts payable |  |  | 6,717 |  |  |  | 18,984 |  |
| Accrued wages and employee benefits |  |  | (10,427 | ) |  |  | 1,452 |  |
| Other accrued liabilities |  |  | (521 | ) |  |  | 3,130 |  |
| Excess tax benefits from equity awards |  |  | (7,229 | ) |  |  | (8,401 | ) |
| Net cash provided by operating activities |  |  | 85,285 |  |  |  | 74,318 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 7 |  |  |  | 35 |  |
| Expenditures for property and equipment |  |  | (13,317 | ) |  |  | (10,051 | ) |
| Proceeds from sale of business, net |  | – |  |  |  | 2,254 |  |
| Acquisition of business |  |  | (429 | ) |  |  | 6,278 |  |
| Net cash used in investing activities |  |  | (13,739 | ) |  |  | (1,484 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 4,000 |  |  |  | 14,007 |  |
| Proceeds from long-term borrowings |  | – |  |  |  | 1,200,000 |  |
| Repayments of short-term borrowings |  |  | (7,066 | ) |  |  | (2,510 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (18,567 | ) |  |  | (897,750 | ) |
| Payment of debt issuance costs |  |  | (4 | ) |  |  | (21,698 | ) |
| Cash dividends paid |  |  | (459 | ) |  |  | (343,421 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (8,950 | ) |  |  | (11,259 | ) |
| Excess tax benefits from equity awards |  |  | 7,229 |  |  |  | 8,401 |  |
| Net cash used in financing activities |  |  | (23,817 | ) |  |  | (54,230 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 83 |  |  |  | (29 | ) |
| Net increase in cash and cash equivalents |  |  | 47,812 |  |  |  | 18,575 |  |
| Cash and cash equivalents at beginning of period |  |  | 150,147 |  |  |  | 108,023 |  |
| Cash and cash equivalents at end of period |  | $ | 197,959 |  |  | $ | 126,598 |  |

[0001437749-14-013723:8k_2_02:78]
Generac Holdings Inc.

[0001437749-14-013723:8k_2_02:79]
Reconciliation Schedules

[0001437749-14-013723:8k_2_02:80]
(Dollars in Thousands, Except Share and Per Share Data)

[0001437749-14-013723:8k_2_02:81]
Net income to Adjusted EBITDA reconciliation

[0001437749-14-013723:8k_2_02:82]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Interest expense |  |  | 11,428 |  |  |  | 14,263 |  |  |  | 23,117 |  |  |  | 29,938 |  |
| Depreciation and amortization |  |  | 8,381 |  |  |  | 8,906 |  |  |  | 16,956 |  |  |  | 17,656 |  |
| Income taxes provision |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Non-cash write-down and other adjustments (1) |  |  | (5,198 | ) |  |  | 1,240 |  |  |  | (5,752 | ) |  |  | 817 |  |
| Non-cash share-based compensation expense (2) |  |  | 2,881 |  |  |  | 3,261 |  |  |  | 6,203 |  |  |  | 6,192 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 13,497 |  |  |  | - |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (4) |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and credit facility fees (5) |  |  | 498 |  |  |  | 1,589 |  |  |  | 701 |  |  |  | 1,903 |  |
| Other |  |  | 134 |  |  |  | 552 |  |  |  | 173 |  |  |  | 843 |  |
| Adjusted EBITDA |  | $ | 84,532 |  |  | $ | 90,097 |  |  | $ | 162,030 |  |  | $ | 198,898 |  |

[0001437749-14-013723:8k_2_02:83]
(1) Includes losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-14-013723:8k_2_02:84]
(2) Includes share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-14-013723:8k_2_02:85]
(3) Relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt.

[0001437749-14-013723:8k_2_02:86]
(4) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-14-013723:8k_2_02:87]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-14-013723:8k_2_02:88]
Net income to Adjusted net income reconciliation

[0001437749-14-013723:8k_2_02:89]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Provision for income taxes |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Income before provision for income taxes |  |  | 82,422 |  |  |  | 46,789 |  |  |  | 136,646 |  |  |  | 126,213 |  |
| Amortization of intangible assets |  |  | 5,099 |  |  |  | 6,345 |  |  |  | 10,444 |  |  |  | 12,530 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,818 |  |  |  | 1,150 |  |  |  | 3,021 |  |  |  | 2,327 |  |
| Loss on extinguishment of debt (6) |  |  | - |  |  |  | 13,497 |  |  |  | - |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (7) |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | (4,512 | ) |  |  | 1,430 |  |  |  | (4,699 | ) |  |  | 1,177 |  |
| Adjusted net income before provision for income taxes |  |  | 68,813 |  |  |  | 69,211 |  |  |  | 129,398 |  |  |  | 157,583 |  |
| Cash income tax expense (9) |  |  | (11,690 | ) |  |  | (2,650 | ) |  |  | (21,560 | ) |  |  | (7,170 | ) |
| Adjusted net income |  | $ | 57,123 |  |  | $ | 66,561 |  |  | $ | 107,838 |  |  | $ | 150,413 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.82 |  |  | $ | 0.95 |  |  | $ | 1.54 |  |  | $ | 2.15 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,087,976 |  |  |  | 69,809,599 |  |  |  | 70,088,438 |  |  |  | 69,801,498 |  |

[0001437749-14-013723:8k_2_02:90]
(6) Relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt.

[0001437749-14-013723:8k_2_02:91]
(7) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-14-013723:8k_2_02:92]
(8) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. Also includes certain purchase accounting adjustments and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-14-013723:8k_2_02:93]
(9) Amount for the three and six months ended June 30, 2014 is based on an anticipated cash income tax rate of approximately 18% for the full year-ended 2014. Amount for the three and six months ended June 30, 2013 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2013.

[0001437749-14-013723:8k_2_02:94]
Free cash flow reconciliation

[0001437749-14-013723:8k_2_02:95]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 48,932 |  |  | $ | 36,052 |  |  | $ | 85,285 |  |  | $ | 74,318 |  |
| Expenditures for property and equipment |  |  | (8,392 | ) |  |  | (5,729 | ) |  |  | (13,317 | ) |  |  | (10,051 | ) |
| Free cash flow |  | $ | 40,540 |  |  | $ | 30,323 |  |  | $ | 71,968 |  |  | $ | 64,267 |  |

[0001437749-14-013723:8k_2_02:96]
LTM free cash flow reconciliation

[0001437749-14-013723:8k_2_02:97]
|  |  | LTM June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2013 net cash provided by operating activities, as reported |  | $ | 259,944 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add: June 2014 net cash provided by operating activities, as reported |  |  | 85,285 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: June 2013 net cash provided by operating activities, as reported |  |  | (74,318 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| LTM net cash provided by operating activities |  |  | 270,911 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2013 expenditures for property and equipment, as reported |  |  | (30,770 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| Include: June 2014 expenditures for property and equipment, as reported |  |  | (13,317 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| Exclude: June 2013 expenditures for property and equipment, as reported |  |  | 10,051 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LTM expenditures for property and equipment |  |  | (34,036 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 236,875 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-14-013723:8k_2_02:98]
LTM Adjusted EBITDA reconciliation

[0001437749-14-013723:8k_2_02:99]
|  |  | LTM June 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2013 Adjusted EBITDA, as reported |  | $ | 402,613 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add: June 2014 Adjusted EBITDA, as reported |  |  | 162,030 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: June 2013 Adjusted EBITDA, as reported |  |  | (198,898 | ) |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 365,745 |  |  |  |  |  |  |  |  |  |  |  |  |  |
