# GNRC notes — 0001437749-14-014607


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001437749-14-014607:notes:1]
1. Basis of Presentation

[0001437749-14-014607:notes:2]
[same as prior period, unchanged from 0001474735-14-000015:notes:52]

[0001437749-14-014607:notes:3]
[same as prior period, unchanged from 0001474735-14-000015:notes:53]

[0001437749-14-014607:notes:4]
In the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of recent acquisitions include the following:

[0001437749-14-014607:notes:5]
|  | ● | On October 3, 2011, the Company acquired Magnum Products, a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products and distribution channels. |

[0001437749-14-014607:notes:6]
|  | ● | On December 8, 2012, the Company acquired Ottomotores, with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a significant market participant throughout all of Latin America. |

[0001437749-14-014607:notes:7]
|  | ● | On August 1, 2013, the Company acquired Tower Light. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-14-014607:notes:8]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW. |

[0001437749-14-014607:notes:9]
[same as prior period, unchanged from 0001474735-14-000015:notes:54]

[0001437749-14-014607:notes:10]
The condensed consolidated balance sheet as of June 30, 2014, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the six months ended June 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-14-014607:notes:11]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-14-014607:notes:12]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0001437749-14-014607:notes:13]
[same as prior period, unchanged from 0001474735-14-000015:notes:59]

[0001437749-14-014607:notes:14]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three and six months ended June 30, 2014 and 2013, net of tax:

[0001437749-14-014607:notes:15]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |
| Other comprehensive loss before reclassifications |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

[0001437749-14-014607:notes:16]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,003 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,022 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |

[0001437749-14-014607:notes:17]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $1,049 net of tax benefit of $46 for the three months ended June 30, 2013 |

[0001437749-14-014607:notes:18]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

[0001437749-14-014607:notes:19]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,005 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,024 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |

[0001437749-14-014607:notes:20]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,097 net of tax benefit of $92 for the six months ended June 30, 2013 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-14-014607:notes:21]
[same as prior period, unchanged from 0001474735-14-000015:notes:17]

[0001437749-14-014607:notes:22]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 815, Derivatives and Hedging, which requires all derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies, and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-14-014607:notes:23]
[same as prior period, unchanged from 0001474735-14-000015:notes:19]

[0001437749-14-014607:notes:24]
[same as prior period, unchanged from 0001474735-14-000015:notes:20]

[0001437749-14-014607:notes:25]
The Company primarily utilizes commodity contracts with maturities of less than twelve months. The impact of such contracts is intended to offset the effect of price fluctuations on actual inventory purchases. Outstanding commodity forward contracts in place to hedge the Company’s projected commodity purchases were as follows:

[0001437749-14-014607:notes:26]
| As of June 30, 2014: |  |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | 1/31/2014 | 2/1/2014 |  |  | $ 3,879 |  | 12/31/2014 |
| Copper | 3/11/2014 | 4/1/2014 |  |  | $ 3,014 |  | 12/31/2014 |

[0001437749-14-014607:notes:27]
| As of December 31, 2013: |  |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | 6/21/2013 | 10/1/2013 |  |  | $ 2,169 |  | 6/30/2014 |

[0001437749-14-014607:notes:28]
| As of June 30, 2013: |  |  |  |  |  |  |  |
| Commodity | Trade Date | Effective Date |  | Notional Amount |  | Termination Date |
| Copper | 10/29/2012 | 1/1/2013 |  |  | $ 3,472 |  | 9/30/2013 |
| Copper | 2/26/2013 | 3/1/2013 |  |  | $ 2,677 |  | 12/31/2013 |
| Copper | 3/1/2013 | 3/1/2013 |  |  | $ 2,636 |  | 12/31/2013 |
| Copper | 4/15/2013 | 5/1/2013 |  |  | $ 4,033 |  | 12/31/2013 |
| Copper | 6/21/2013 | 10/1/2013 |  |  | $ 2,169 |  | 6/30/2014 |

[0001437749-14-014607:notes:29]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Total gains (losses) recognized for the three and six months ended June 30, 2014 were $279 and $(47), respectively. Total losses recognized for the three and six months ended June 30, 2013 were $(826) and $(1,118), respectively.

[0001437749-14-014607:notes:30]
[same as prior period, unchanged from 0001474735-14-000015:notes:24]

[0001437749-14-014607:notes:31]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. There were no foreign currency hedge contracts outstanding as of June 30, 2013. As of June 30, 2014 and December 31, 2013, the following foreign currency contracts were outstanding:

[0001437749-14-014607:notes:32]
| As of June 30, 2014: |  |  |  |  |
| Currency Denomination |  | Notional Amount |  |
| United States Dollar (USD) to Euro |  | $ | 250 |  |
| British Pound Sterling (GBP) to Euro |  | £ | 3,000 |  |

[0001437749-14-014607:notes:33]
| As of December 31, 2013: |  |  |  |  |
| Currency Denomination |  | Notional Amount |  |
| United States Dollar (USD) to Euro |  | $ | 650 |  |
| British Pound Sterling (GBP) to Euro |  | £ | 4,000 |  |

[0001437749-14-014607:notes:34]
Total losses recognized in the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2014 were $(55) and $(97), respectively.

[0001437749-14-014607:notes:35]
[same as prior period, unchanged from 0001474735-14-000015:notes:28]

[0001437749-14-014607:notes:36]
As of May 30, 2012, the date of a previous credit agreement refinancing, the Company had four interest rate swap agreements outstanding. The first swap was entered into on January 21, 2010, had an effective date of July 1, 2010, a notional amount of $200,000, a fixed LIBOR rate of 1.73% and an expiration date of July 1, 2012. The second swap was entered into on June 29, 2010, had an effective date of October 1, 2010, a notional amount of $100,000, a fixed LIBOR rate of 1.025% and an expiration date of October 1, 2012. The third swap was entered into on April 1, 2011, had an effective date of July 1, 2012, a notional amount of $200,000, a fixed LIBOR rate of 1.905% and an expiration date of July 1, 2013. The fourth swap was entered into on April 1, 2011, had an effective date of October 1, 2012, a notional amount of $100,000, a fixed LIBOR rate of 2.22% and an expiration date of October 1, 2013. Due to
      the incorporation of a new interest rate floor provision in the then new credit agreement, which constituted a change in critical terms, the Company concluded that as of May 30, 2012, the then outstanding swaps would no longer be highly effective in achieving offsetting changes in cash flows during the periods the hedges were designated.  As a result, the Company was required to de-designate the four outstanding hedges as of May 30, 2012.  Beginning May 31, 2012, the effective portion of the swaps prior to the change (i.e. amounts previously recorded in Accumulated Other Comprehensive Loss) were amortized into interest expense over the period of the originally designated hedged transactions which had various termination dates through October 2013.  Future changes in fair value of these swaps were immediately recognized in the consolidated statements of comprehensive income as interest expense.

[0001437749-14-014607:notes:37]
On October 23, 2013, the Company entered into two interest rate swap agreements, and on May 19, 2014, the Company entered into one interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges. For derivatives that are designated and qualify as a cash flow hedge, the effective portion of the gain or loss on the derivative is reported as a component of accumulated other comprehensive loss. The cash flows of the swaps are recognized as adjustments to interest expense each period.  The ineffective portion of the derivatives’ change in fair value, if any, is immediately recognized in earnings. The Company assesses on an ongoing basis whether derivatives
      used in hedging transactions are highly effective in offsetting changes in cash flows of hedged items.  The effective dates of the swaps are July 1, 2014 with a notional amount of $100,000 each and a fixed LIBOR rate of 1.7370%, 1.7420% and 1.6195%, including a LIBOR floor of 0.75%, with expiration dates of July 1, 2018.

[0001437749-14-014607:notes:38]
[same as prior period, unchanged from 0001474735-14-000015:notes:31]

[0001437749-14-014607:notes:39]
|  |  | June 30, 2014 |  |  | December 31, 2013 |  |
| Commodity contracts |  | $ | 77 |  |  | $ | 69 |  |
| Foreign currency contracts |  |  | (97 | ) |  |  | 56 |  |
| Interest rate swaps |  |  | (1,435 | ) |  |  | 1,236 |  |

[0001437749-14-014607:notes:40]
The fair value of the interest rate swaps is included in other long-term liabilities and other assets in the condensed consolidated balance sheets as of June 30, 2014 and December 31, 2013, respectively. The fair value of the commodity contracts is included in other assets in the condensed consolidated balance sheets as of June 30, 2014 and December 31, 2013, respectively. Excluding the impact of credit risk, the fair value of the derivative contracts as of June 30, 2014 and December 31, 2013 is a liability of $(1,463) and an asset of $1,385, respectively, which represents the amount the Company would need to pay or receive to exit the agreements on those dates.

[0001437749-14-014607:notes:41]
The following presents the impact of interest rate swaps, commodity contracts and foreign currency contracts on the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2014 and 2013:

[0001437749-14-014607:notes:42]
|  |  | Amount of Loss Recognized in Accumulated Other Comprehensive Loss for the Three Months Ended June 30, |  | Location of Gain (Loss) Recognized in Net Income on Ineffective Portion of Hedges |  | Amount of Loss Reclassified from Accumulated Other Comprehensive Loss into Net Income for the Three Months Ended June 30, |  |  | Amount of Gain (Loss) Recognized in Net Income on Hedges (Ineffective Portion) for the Three Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | (1,208 | ) |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps (1) |  | $ | — |  |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | (1,003 | ) |  | $ | — |  |  | $ | 1,266 |  |
| Commodity and foreign currency contracts |  | $ | — |  |  | $ | — |  | Cost of goods sold |  | $ | — |  |  | $ | — |  |  | $ | 224 |  |  | $ | (826 | ) |

[0001437749-14-014607:notes:43]
|  |  | Amount of Loss Recognized in Accumulated Other Comprehensive Loss for the Six Months Ended June 30, |  | Location of Gain (Loss) Recognized in Net Income on Ineffective Portion of Hedges |  | Amount of Loss Reclassified from Accumulated Other Comprehensive Loss into Net Income for the Six Months Ended June 30, |  |  | Amount of Gain (Loss) Recognized in Net Income on Hedges (Ineffective Portion) for the Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | (1,708 | ) |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps (1) |  | $ | — |  |  | $ | — |  | Interest expense |  | $ | — |  |  | $ | (2,005 | ) |  | $ | — |  |  | $ | 2,472 |  |
| Commodity and foreign currency contracts |  | $ | — |  |  | $ | — |  | Cost of goods sold |  | $ | — |  |  | $ | — |  |  | $ | (144 | ) |  | $ | (1,118 | ) |

[0001437749-14-014607:notes:44]
(1) Amounts recorded for the three and six months ended June 30, 2013 relate to interest rate swap agreements outstanding as of May 30, 2012, the date the hedging relationships for these agreements were terminated.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-14-014607:notes:45]
[same as prior period, unchanged from 0001474735-14-000015:notes:41]

[0001437749-14-014607:notes:46]
ASC 820-10, Fair Value Measurements and Disclosures, among other things, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in
      active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-14-014607:notes:47]
[same as prior period, unchanged from 0001474735-14-000015:notes:43]

[0001437749-14-014607:notes:48]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued liabilities and short-term borrowings), excluding long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $1,152,331, was approximately $1,146,570 (Level 2) at June 30, 2014, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-14-014607:notes:49]
[same as prior period, unchanged from 0001474735-14-000015:notes:45]

[0001437749-14-014607:notes:50]
|  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | Total June 30, 2014 |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | (1,435 | ) | $ – |  | $ | (1,435 | ) |
| Commodity contracts |  | $ | 77 |  | $ – |  | $ | 77 |  |
| Foreign currency contracts |  | $ | (97 | ) | $ – |  | $ | (97 | ) |

[0001437749-14-014607:notes:51]
|  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | Total December 31, 2013 |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  | Significant Other Observable Inputs (Level 2) |  |
| Interest rate swaps |  | $ | 1,236 |  | $ – |  | $ | 1,236 |  |
| Commodity contracts |  | $ | 69 |  | $ – |  | $ | 69 |  |
| Foreign currency contracts |  | $ | 56 |  | $ – |  | $ | 56 |  |

[0001437749-14-014607:notes:52]
The valuation techniques used to measure the fair value of derivative contracts classified as Level 2, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-14-014607:notes:53]
[same as prior period, unchanged from 0001474735-14-000015:notes:83]

[0001437749-14-014607:notes:54]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production processes and methods of distribution. The Company’s sales in the United States represent approximately 85% and 90% of total sales for the three months ended June 30, 2014 and 2013, respectively, and represent 85% and 90% of total sales for the six months ended June 30, 2014 and 2013, respectively. Approximately 90% of the Company’s identifiable long-lived assets are located in the United States at
      both June 30, 2014 and December 31, 2013.

[0001437749-14-014607:notes:55]
The Company's product offerings consist primarily of power products with a range of power output geared for varying end customer uses. Residential power products and commercial & industrial power products are each a similar class of products based on similar power output and end customer usage. The breakout of net sales between residential, commercial & industrial, and other products is as follows:

[0001437749-14-014607:notes:56]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Residential power products |  | $ | 179,592 |  |  | $ | 196,616 |  |  | $ | 343,561 |  |  | $ | 451,860 |  |
| Commercial & industrial power products |  |  | 163,467 |  |  |  | 133,427 |  |  |  | 320,837 |  |  |  | 260,507 |  |
| Other |  |  | 19,550 |  |  |  | 16,645 |  |  |  | 40,219 |  |  |  | 33,893 |  |
| Total |  | $ | 362,609 |  |  | $ | 346,688 |  |  | $ | 704,617 |  |  | $ | 746,260 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-14-014607:notes:57]
5. Balance Sheet Details

[0001437749-14-014607:notes:58]
Inventories consist of the following:

[0001437749-14-014607:notes:59]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Raw material |  | $ | 185,435 |  |  | $ | 183,787 |  |
| Work-in-process |  |  | 8,334 |  |  |  | 9,620 |  |
| Finished goods |  |  | 100,440 |  |  |  | 113,404 |  |
| Reserves for excess and obsolescence |  |  | (6,976 | ) |  |  | (6,558 | ) |
| Total |  | $ | 287,233 |  |  | $ | 300,253 |  |

[0001437749-14-014607:notes:60]
Property and equipment consists of the following:

[0001437749-14-014607:notes:61]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Land and improvements |  | $ | 7,444 |  |  | $ | 7,416 |  |
| Buildings and improvements |  |  | 97,132 |  |  |  | 96,161 |  |
| Machinery and equipment |  |  | 61,214 |  |  |  | 54,847 |  |
| Dies and tools |  |  | 15,491 |  |  |  | 17,071 |  |
| Vehicles |  |  | 2,023 |  |  |  | 1,979 |  |
| Office equipment |  |  | 19,281 |  |  |  | 17,304 |  |
| Leasehold improvements |  |  | 2,412 |  |  |  | 2,229 |  |
| Construction in progress |  |  | 11,480 |  |  |  | 9,724 |  |
| Gross property and equipment |  |  | 216,477 |  |  |  | 206,731 |  |
| Accumulated depreciation |  |  | (63,414 | ) |  |  | (60,341 | ) |
| Total |  | $ | 153,063 |  |  | $ | 146,390 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-14-014607:notes:62]
[same as prior period, unchanged from 0001474735-14-000015:notes:67]

[0001437749-14-014607:notes:63]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The Company also sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, and we recognize the revenue from sales of extended warranties over the life of the contracts. The Company’s product warranty obligations, including deferred revenue related to extended warranty coverage, are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-14-014607:notes:64]
[same as prior period, unchanged from 0001474735-14-000015:notes:69]

[0001437749-14-014607:notes:65]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 31,907 |  |  | $ | 40,207 |  |  | $ | 33,734 |  |  | $ | 36,112 |  |
| Payments |  |  | (4,076 | ) |  |  | (3,903 | ) |  |  | (11,024 | ) |  |  | (9,596 | ) |
| Provision for warranties issued |  |  | 5,764 |  |  |  | 9,352 |  |  |  | 12,028 |  |  |  | 20,340 |  |
| Changes in estimates for pre-existing warranties |  |  | (1,424 | ) |  |  | (5,500 | ) |  |  | (2,567 | ) |  |  | (6,700 | ) |
| Balance at end of period |  | $ | 32,171 |  |  | $ | 40,156 |  |  | $ | 32,171 |  |  | $ | 40,156 |  |

[0001437749-14-014607:notes:66]
[same as prior period, unchanged from 0001474735-14-000015:notes:71]

[0001437749-14-014607:notes:67]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 24,632 |  |  | $ | 15,042 |  |  | $ | 23,092 |  |  | $ | 13,473 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,795 |  |  |  | 2,268 |  |  |  | 4,014 |  |  |  | 4,406 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (748 | ) |  |  | (581 | ) |  |  | (1,427 | ) |  |  | (1,150 | ) |
| Balance at end of period |  | $ | 25,679 |  |  | $ | 16,729 |  |  | $ | 25,679 |  |  | $ | 16,729 |  |

[0001437749-14-014607:notes:68]
Product warranty obligations and warranty related deferred revenues are included in the condensed consolidated balance sheets as follows:

[0001437749-14-014607:notes:69]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 25,331 |  |  | $ | 26,080 |  |
| Long-term portion - other long-term liabilities |  |  | 6,840 |  |  |  | 7,654 |  |
| Total |  | $ | 32,171 |  |  | $ | 33,734 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 5,912 |  |  | $ | 3,325 |  |
| Long-term portion - other long-term liabilities |  |  | 19,767 |  |  |  | 19,767 |  |
| Total |  | $ | 25,679 |  |  | $ | 23,092 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-14-014607:notes:70]
7. Credit Agreements

[0001437749-14-014607:notes:71]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-14-014607:notes:72]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 6,509 |  |  |  | 9,575 |  |
| Total |  | $ | 6,509 |  |  | $ | 9,575 |  |

[0001437749-14-014607:notes:73]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-14-014607:notes:74]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,179,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (27,235 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,421 |  |  |  | 2,529 |  |
| Other |  |  | 566 |  |  |  | 1,026 |  |
| Total |  |  | 1,154,752 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,154,316 |  |  | $ | 1,175,349 |  |

[0001437749-14-014607:notes:75]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement) with certain commercial banks and other lenders. The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (New Term Loan) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses.

[0001437749-14-014607:notes:76]
The New Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which will be secured by a second priority lien.

[0001437749-14-014607:notes:77]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25
      basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets.

[0001437749-14-014607:notes:78]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends. Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit
      the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

[0001437749-14-014607:notes:79]
The New Term Loan Credit Agreement contains customary events of default, including; nonpayment of principal, interest or other amounts; failure to perform covenants; inaccuracy of representations or warranties in any material respect; cross-defaults with other material indebtedness; certain undischarged judgments; the occurrence of certain ERISA or bankruptcy or insolvency events; or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

[0001437749-14-014607:notes:80]
Concurrent with the closing of the New Term Loan Credit Agreement on May 31, 2013, the Borrower amended its then existing ABL credit agreement (New ABL Credit Agreement). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018.

[0001437749-14-014607:notes:81]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of June 30, 2014, no amounts were outstanding under the ABL Facility. As of June 30, 2014, the Company had $197,959 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

[0001437749-14-014607:notes:82]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement.

[0001437749-14-014607:notes:83]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the three and six months ended June 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on
      its loans under the effective interest method.

[0001437749-14-014607:notes:84]
As of June 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $6,509 and $9,575, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-14-014607:notes:85]
[same as prior period, unchanged from 0001474735-14-000015:notes:37]

[0001437749-14-014607:notes:86]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, dilutive earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-14-014607:notes:87]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator- net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Denominator- weighted average shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,538,251 |  |  |  | 68,140,330 |  |  |  | 68,481,682 |  |  |  | 68,003,164 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,549,725 |  |  |  | 1,669,269 |  |  |  | 1,606,756 |  |  |  | 1,798,334 |  |
| Diluted |  |  | 70,087,976 |  |  |  | 69,809,599 |  |  |  | 70,088,438 |  |  |  | 69,801,498 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.79 |  |  | $ | 0.41 |  |  | $ | 1.30 |  |  | $ | 1.16 |  |
| Diluted |  | $ | 0.77 |  |  | $ | 0.40 |  |  | $ | 1.27 |  |  | $ | 1.13 |  |

[0001437749-14-014607:notes:88]
(1) Excludes approximately 64,800 and 70,400 stock options for the three and six month periods ended June 30, 2014, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 300,000 and 250,000 stock options for the three and six month periods ended June 30, 2013, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-14-014607:notes:89]
[same as prior period, unchanged from 0001474735-14-000015:notes:49]

[0001437749-14-014607:notes:90]
The effective income tax rates for the six months ended June 30, 2014 and 2013 were 35.1% and 37.5%, respectively. The decrease in the effective income tax rate year-over-year is primarily due to the Company’s ability to utilize the federal domestic production activity deduction due to sufficient taxable income and the lower tax rate of a foreign subsidiary acquired during the third quarter of 2013.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-14-014607:notes:91]
10. Commitments and Contingencies

[0001437749-14-014607:notes:92]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2014 and December 31, 2013 was approximately $31,700 and $24,300 respectively.

[0001437749-14-014607:notes:93]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.
