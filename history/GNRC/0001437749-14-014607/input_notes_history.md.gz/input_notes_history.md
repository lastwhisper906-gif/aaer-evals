# GNRC note change history — 0001474735-14-000015 → 0001437749-14-014607


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001437749-14-014607:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2014 and December 31, 2013 was approximately $31,700 and $24,300 respectively.
  (was, 2014-05-08, similarity 0.9923):
[0001474735-14-000015:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2014 and December 31, 2013 was approximately $27,000 and $24,300 respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-08-07):
[0001437749-14-014607:note_history:2]
In the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of recent acquisitions include the following:

- added (2014-08-07):
[0001437749-14-014607:note_history:3]
|  | ● | On October 3, 2011, the Company acquired Magnum Products, a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products and distribution channels. |

- added (2014-08-07):
[0001437749-14-014607:note_history:4]
|  | ● | On December 8, 2012, the Company acquired Ottomotores, with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a significant market participant throughout all of Latin America. |

- added (2014-08-07):
[0001437749-14-014607:note_history:5]
|  | ● | On August 1, 2013, the Company acquired Tower Light. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- added (2014-08-07):
[0001437749-14-014607:note_history:6]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW. |

- changed (2014-08-07):
[0001437749-14-014607:note_history:7]
The condensed consolidated balance sheet as of June 30, 2014, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the six months ended June 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2014-05-08, similarity 0.9268):
[0001474735-14-000015:note_history:7]
The condensed consolidated balance sheet as of March 31, 2014, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2014 and 2013, and the condensed consolidated statements of cash flows for the three months ended March 31, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- added (2014-08-07):
[0001437749-14-014607:note_history:8]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- changed (2014-08-07):
[0001437749-14-014607:note_history:9]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2013.
  (was, 2014-05-08, similarity 0.9476):
[0001474735-14-000015:note_history:9]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2013.

- changed (2014-08-07):
[0001437749-14-014607:note_history:10]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three and six months ended June 30, 2014 and 2013, net of tax:
  (was, 2014-05-08, similarity 0.9464):
[0001474735-14-000015:note_history:10]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013, net of tax:

- changed (2014-08-07):
[0001437749-14-014607:note_history:11]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |
| Other comprehensive loss before reclassifications |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |
  (was, 2014-05-08, similarity 0.8437):
[0001474735-14-000015:note_history:11]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Ending Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |

- changed (2014-08-07):
[0001437749-14-014607:note_history:12]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,003 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 1,003 |  |  |  | 1,022 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |
  (was, 2014-05-08, similarity 0.8236):
[0001474735-14-000015:note_history:12]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Net current-period other comprehensive income |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Ending Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |

- added (2014-08-07):
[0001437749-14-014607:note_history:13]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $1,049 net of tax benefit of $46 for the three months ended June 30, 2013 |

- added (2014-08-07):
[0001437749-14-014607:note_history:14]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

- added (2014-08-07):
[0001437749-14-014607:note_history:15]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 19 |  |  |  | - |  |  |  | - |  |  |  | 19 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,005 |  |
| Net current-period other comprehensive income |  |  | 19 |  |  |  | - |  |  |  | 2,005 |  |  |  | 2,024 |  |
| Ending Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |

- added (2014-08-07):
[0001437749-14-014607:note_history:16]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,097 net of tax benefit of $92 for the six months ended June 30, 2013 |

- removed (2014-08-07):
[0001474735-14-000015:note_history:17]
Expenses are charged to operations in the year incurred. However, for interim reporting purposes certain expenses are charged to operations based on a proportionate share of annual amounts rather than as they are actually incurred.

- removed (2014-08-07):
[0001474735-14-000015:note_history:18]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- removed (2014-08-07):
[0001474735-14-000015:note_history:19]
The components of accumulated other comprehensive loss, net of tax, at March 31, 2014 and December 31, 2013 are as follows:

- removed (2014-08-07):
[0001474735-14-000015:note_history:20]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Foreign currency translation adjustments |  | $ | 1,275 |  |  | $ | 1,204 |  |
| Pension liability, net of tax of $886 |  |  | (4,393 | ) |  |  | (4,393 | ) |
| Unrealized gain on cash flow hedges, net of tax of $178 and $462 |  |  | 274 |  |  |  | 774 |  |
| Accumulated other comprehensive loss |  | $ | (2,844 | ) |  | $ | (2,415 | ) |

- removed (2014-08-07):
[0001474735-14-000015:note_history:21]
The following presents a tabular disclosure about reclassification adjustments out of accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013:

- removed (2014-08-07):
[0001474735-14-000015:note_history:22]
|  |  | Amounts reclassified from other accumulated comprehensive loss for the three months ended March 31, |  | Affected line item in the statement where net income is presented |
| Amortization of unrealized loss on interest rate swaps |  | 2014 |  |  | 2013 |  |  |
| Gross |  |  | - |  |  | $ | (1,048 | ) | Interest expense |
| Tax benefit |  |  | - |  |  |  | 46 |  |  |
| Net of tax |  |  | - |  |  | $ | (1,002 | ) |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001437749-14-014607:note_history:23]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:
  (was, 2014-05-08, similarity 0.8553):
[0001474735-14-000015:note_history:23]
Short-term borrowings are included in the balance sheets as follows:

- changed (2014-08-07):
[0001437749-14-014607:note_history:24]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 6,509 |  |  |  | 9,575 |  |
| Total |  | $ | 6,509 |  |  | $ | 9,575 |  |
  (was, 2014-05-08, similarity 0.9769):
[0001474735-14-000015:note_history:24]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 7,004 |  |  |  | 9,575 |  |
| Total |  | $ | 7,004 |  |  | $ | 9,575 |  |

- changed (2014-08-07):
[0001437749-14-014607:note_history:25]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:
  (was, 2014-05-08, similarity 0.8535):
[0001474735-14-000015:note_history:25]
Long-term borrowings are included in the balance sheets as follows:

- changed (2014-08-07):
[0001437749-14-014607:note_history:26]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,179,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (27,235 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,421 |  |  |  | 2,529 |  |
| Other |  |  | 566 |  |  |  | 1,026 |  |
| Total |  |  | 1,154,752 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,154,316 |  |  | $ | 1,175,349 |  |
  (was, 2014-05-08, similarity 0.9868):
[0001474735-14-000015:note_history:26]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,194,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (12,283 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,482 |  |  |  | 2,529 |  |
| Other |  |  | 712 |  |  |  | 1,026 |  |
| Total |  |  | 1,184,911 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 12,356 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,172,368 |  |  | $ | 1,175,349 |  |

- changed (2014-08-07):
[0001437749-14-014607:note_history:27]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement) with certain commercial banks and other lenders. The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (New Term Loan) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses.
  (was, 2014-05-08, similarity 0.9372):
[0001474735-14-000015:note_history:27]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (“New Term Loan Credit Agreement”) with certain commercial banks and other lenders.  The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (the “New Term Loan”) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020.  Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loans were used for general corporate purposes and to pay related financing fees and expenses.

- changed (2014-08-07):
[0001437749-14-014607:note_history:28]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25
      basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets.
  (was, 2014-05-08, similarity 0.716):
[0001474735-14-000015:note_history:28]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020.  It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00.

- changed (2014-08-07):
[0001437749-14-014607:note_history:29]
The New Term Loan Credit Agreement contains customary events of default, including; nonpayment of principal, interest or other amounts; failure to perform covenants; inaccuracy of representations or warranties in any material respect; cross-defaults with other material indebtedness; certain undischarged judgments; the occurrence of certain ERISA or bankruptcy or insolvency events; or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.
  (was, 2014-05-08, similarity 0.9004):
[0001474735-14-000015:note_history:29]
The New Term Loan Credit Agreement contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA or bankruptcy or insolvency events or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

- changed (2014-08-07):
[0001437749-14-014607:note_history:30]
Concurrent with the closing of the New Term Loan Credit Agreement on May 31, 2013, the Borrower amended its then existing ABL credit agreement (New ABL Credit Agreement). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018.
  (was, 2014-05-08, similarity 0.9568):
[0001474735-14-000015:note_history:30]
Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, the Borrower amended its then existing ABL credit agreement (the “New ABL Credit Agreement”). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (the “ABL Facility”). The extended maturity date of the ABL Facility is May 31, 2018.

- changed (2014-08-07):
[0001437749-14-014607:note_history:31]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of June 30, 2014, no amounts were outstanding under the ABL Facility. As of June 30, 2014, the Company had $197,959 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.
  (was, 2014-05-08, similarity 0.9941):
[0001474735-14-000015:note_history:31]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company).  Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above.  As of March 31, 2014, no amounts were outstanding under the ABL Facility.  As of March 31, 2014, the Company had $173,740 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

- added (2014-08-07):
[0001437749-14-014607:note_history:32]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement.

- added (2014-08-07):
[0001437749-14-014607:note_history:33]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the three and six months ended June 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on
      its loans under the effective interest method.

- changed (2014-08-07):
[0001437749-14-014607:note_history:34]
As of June 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $6,509 and $9,575, respectively.
  (was, 2014-05-08, similarity 0.9749):
[0001474735-14-000015:note_history:34]
As of March 31, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $7,004 and $9,575, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001437749-14-014607:note_history:35]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,179,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (27,235 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,421 |  |  |  | 2,529 |  |
| Other |  |  | 566 |  |  |  | 1,026 |  |
| Total |  |  | 1,154,752 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,154,316 |  |  | $ | 1,175,349 |  |
  (was, 2014-05-08, similarity 0.9868):
[0001474735-14-000015:note_history:35]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,194,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (12,283 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,482 |  |  |  | 2,529 |  |
| Other |  |  | 712 |  |  |  | 1,026 |  |
| Total |  |  | 1,184,911 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 12,356 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,172,368 |  |  | $ | 1,175,349 |  |

- removed (2014-08-07):
[0001474735-14-000015:note_history:36]
Long-term borrowings are included in the balance sheets as follows:


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001437749-14-014607:note_history:37]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 6,509 |  |  |  | 9,575 |  |
| Total |  | $ | 6,509 |  |  | $ | 9,575 |  |
  (was, 2014-05-08, similarity 0.9769):
[0001474735-14-000015:note_history:37]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 7,004 |  |  |  | 9,575 |  |
| Total |  | $ | 7,004 |  |  | $ | 9,575 |  |

- removed (2014-08-07):
[0001474735-14-000015:note_history:38]
Short-term borrowings are included in the balance sheets as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-08-07):
[0001474735-14-000015:note_history:39]
11 Subsequent Events

- removed (2014-08-07):
[0001474735-14-000015:note_history:40]
On April 30, 2014, the Company prepaid $12,000 of principal on its existing New Term Loan with available cash on hand.
