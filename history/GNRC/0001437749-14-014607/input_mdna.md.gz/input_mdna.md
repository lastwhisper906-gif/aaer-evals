# GNRC MD&A — 0001437749-14-014607


## mdna

[0001437749-14-014607:mdna:1]
Item 2.          Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-14-014607:mdna:2]
[same as prior period, unchanged from 0001474735-14-000015:mdna:2]

[0001437749-14-014607:mdna:3]
[same as prior period, unchanged from 0001474735-14-000015:mdna:3]

[0001437749-14-014607:mdna:4]
|  | ● | our business, financial and operating results and future economic performance; |

[0001437749-14-014607:mdna:5]
|  | ● | proposed new product and service offerings; and |

[0001437749-14-014607:mdna:6]
|  | ● | management's goals, expectations and objectives and other similar expressions concerning matters that are not historical facts. |

[0001437749-14-014607:mdna:7]
[same as prior period, unchanged from 0001474735-14-000015:mdna:7]

[0001437749-14-014607:mdna:8]
|  | ● | demand for our products; |

[0001437749-14-014607:mdna:9]
|  | ● | frequency and duration of power outages; |

[0001437749-14-014607:mdna:10]
|  | ● | availability, cost and quality of raw materials and key components used in producing our products; |

[0001437749-14-014607:mdna:11]
|  | ● | the impact on our results of the possible fluctuations in interest rates; |

[0001437749-14-014607:mdna:12]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-14-014607:mdna:13]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-14-014607:mdna:14]
|  | ● | difficulties we may encounter as our business expands globally; |

[0001437749-14-014607:mdna:15]
|  | ● | competitive factors in the industry in which we operate; |

[0001437749-14-014607:mdna:16]
|  | ● | our dependence on our distribution network; |

[0001437749-14-014607:mdna:17]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-14-014607:mdna:18]
|  | ● | loss of our key management and employees; |

[0001437749-14-014607:mdna:19]
|  | ● | increase in product and other liability claims; and |

[0001437749-14-014607:mdna:20]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-14-014607:mdna:21]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the fiscal year ended December 31, 2013. Stockholders, potential investors and other readers should consider these factors carefully in evaluating forward-looking statements.

[0001437749-14-014607:mdna:22]
[same as prior period, unchanged from 0001474735-14-000015:mdna:22]

[0001437749-14-014607:mdna:23]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial and construction markets. Unlike our primary competitors in the generator market, power generation is our main focus. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets and a broad product line of power washers for residential and commercial use.

[0001437749-14-014607:mdna:24]
In the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of recent acquisitions include the following:

[0001437749-14-014607:mdna:25]
|  | ● | On October 3, 2011, the Company acquired Magnum Products, a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products and distribution channels. |

[0001437749-14-014607:mdna:26]
|  | ● | On December 8, 2012, the Company acquired Ottomotores, with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a significant market participant throughout all of Latin America. |

[0001437749-14-014607:mdna:27]
|  | ● | On August 1, 2013, the Company acquired Tower Light. Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-14-014607:mdna:28]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation products throughout North America with power output up to 2.5MW. |

[0001437749-14-014607:mdna:29]
Business Drivers and Operational Factors

[0001437749-14-014607:mdna:30]
[same as prior period, unchanged from 0001474735-14-000015:mdna:25]

[0001437749-14-014607:mdna:31]
Business Drivers and Trends

[0001437749-14-014607:mdna:32]
[same as prior period, unchanged from 0001474735-14-000015:mdna:27]

[0001437749-14-014607:mdna:33]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.0% of U.S. single-family detached, owner-occupied households with a home value of over $100 thousand, as defined by the U.S. Census Bureau's 2011 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment (ROI) driven and as a result these applications have relatively lower penetration rates as compared to buildings used in more code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. In addition, the emergence of lower cost, cleaner burning natural gas fueled generators has helped to accelerate the penetration of standby generators in the light-commercial market. Also, the importance of backup power for telecommunications infrastructure is increasing due to the growing demand for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators.

[0001437749-14-014607:mdna:34]
Effect of large scale power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators. Increased frequency and duration of major power outage events caused by the aging U.S. power grid increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months for standby generators. For example, the multiple major outage events that occurred during the second half of both 2011 and 2012 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to substantial organic revenue growth in 2012 with strong growth continuing during 2013. While there are localized power outages that occur frequently across the U.S., major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period.

[0001437749-14-014607:mdna:35]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential products.

[0001437749-14-014607:mdna:36]
Impact of business capital investment cycle.   The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions and credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-14-014607:mdna:37]
Factors Affecting Results of Operations

[0001437749-14-014607:mdna:38]
[same as prior period, unchanged from 0001474735-14-000015:mdna:33]

[0001437749-14-014607:mdna:39]
[same as prior period, unchanged from 0001474735-14-000015:mdna:34]

[0001437749-14-014607:mdna:40]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 16% to 27% of our net sales occurred in the first quarter, 20% to 23% in the second quarter, 24% to 30% in the third quarter and 25% to 34% in the fourth quarter, with different seasonality depending on the presence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand, but assuming no major outage events, typically increase production levels in the second and third quarters of each year.

[0001437749-14-014607:mdna:41]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements and repayments of indebtedness. Cash interest expense decreased during the six months ended June 30, 2014 compared to the six months ended June 30, 2013, primarily due to a reduction in interest rate from the credit agreement refinancing completed in May 2013 and the 25 basis point reduction in borrowing costs for the second quarter of 2014 as a result of our net debt leverage ratio, as defined in our New Term Loan Credit Agreement, falling below 3.0 times.

[0001437749-14-014607:mdna:42]
[same as prior period, unchanged from 0001474735-14-000015:mdna:37]

[0001437749-14-014607:mdna:43]
In the second quarter of 2013, the dividend recapitalization discussed under “Liquidity and Financial Position” was completed. After considering the increased debt and related interest expense, the Company believes it will still generate sufficient taxable income to fully utilize the tax attributes discussed above.

[0001437749-14-014607:mdna:44]
Results of Operations

[0001437749-14-014607:mdna:45]
Three and six months ended June 30, 2014 compared to three and six months ended June 30, 2013

[0001437749-14-014607:mdna:46]
[same as prior period, unchanged from 0001474735-14-000015:mdna:41]

[0001437749-14-014607:mdna:47]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 362,609 |  |  | $ | 346,688 |  |  | $ | 704,617 |  |  | $ | 746,260 |  |
| Cost of goods sold |  |  | 234,597 |  |  |  | 215,735 |  |  |  | 457,091 |  |  |  | 461,845 |  |
| Gross profit |  |  | 128,012 |  |  |  | 130,953 |  |  |  | 247,526 |  |  |  | 284,415 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 29,115 |  |  |  | 27,072 |  |  |  | 57,084 |  |  |  | 58,753 |  |
| Research and development |  |  | 8,012 |  |  |  | 7,064 |  |  |  | 15,758 |  |  |  | 13,709 |  |
| General and administrative |  |  | 12,503 |  |  |  | 14,039 |  |  |  | 25,651 |  |  |  | 26,465 |  |
| Amortization of intangible assets |  |  | 5,099 |  |  |  | 6,345 |  |  |  | 10,444 |  |  |  | 12,530 |  |
| Gain on remeasurement of contingent consideration |  |  | (4,877 | ) |  |  | - |  |  |  | (4,877 | ) |  |  | - |  |
| Total operating expenses |  |  | 49,852 |  |  |  | 54,520 |  |  |  | 104,060 |  |  |  | 111,457 |  |
| Income from operations |  |  | 78,160 |  |  |  | 76,433 |  |  |  | 143,466 |  |  |  | 172,958 |  |
| Total other income (expense), net |  |  | 4,262 |  |  |  | (29,644 | ) |  |  | (6,820 | ) |  |  | (46,745 | ) |
| Income before provision for income taxes |  |  | 82,422 |  |  |  | 46,789 |  |  |  | 136,646 |  |  |  | 126,213 |  |
| Provision for income taxes |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Residential power products |  | $ | 179,592 |  |  | $ | 196,616 |  |  | $ | 343,561 |  |  | $ | 451,860 |  |
| Commercial & industrial power products |  |  | 163,467 |  |  |  | 133,427 |  |  |  | 320,837 |  |  |  | 260,507 |  |
| Other |  |  | 19,550 |  |  |  | 16,645 |  |  |  | 40,219 |  |  |  | 33,893 |  |
| Net sales |  | $ | 362,609 |  |  | $ | 346,688 |  |  | $ | 704,617 |  |  | $ | 746,260 |  |

[0001437749-14-014607:mdna:48]
Net sales.    Net sales increased $15.9 million, or 4.6%, to $362.6 million for the three months ended June 30, 2014 from $346.7 million for the three months ended June 30, 2013. Residential product sales for the second quarter of 2014 were $179.6 million as compared to $196.6 million for the comparable period in 2013. Sales of residential products during the prior-year second quarter were positively impacted by approximately $40 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during the second quarter of 2014. Excluding this benefit in the prior-year quarter, residential product revenue increased approximately 15% during the second quarter of 2014, driven by strong shipments of home standby generators. Additionally, increased revenue from power washer products contributed to the year-over-year sales growth in residential products. Commercial and industrial (“C&I”) product sales for the second quarter of 2014 increased 22.5% to $163.5 million from $133.4 million for the comparable period in 2013. The improvement was driven primarily by contributions from recent acquisitions, and to a lesser extent by strength in the oil & gas end markets, and increased sales of natural gas generators used in light commercial and retail applications. Partially offsetting this strength was a year-over-year decline in sales within Latin American driven by the combination of a difficult prior-year comparison related to certain large projects which did not repeat, as well as overall economic softness in the region.

[0001437749-14-014607:mdna:49]
Net sales decreased $41.7 million, or 5.6%, to $704.6 million for the six months ended June 30, 2014 from $746.3 million for the six months ended June 30, 2013. Residential product sales for the first half of 2014 decreased 24.0% to $343.6 million from $451.9 million for the comparable period in 2013. Sales of residential products during the prior-year first half were positively impacted by approximately $140 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during the first half of 2014. Excluding this benefit in the prior-year, residential product revenue increased primarily due to strong shipments of both home standby and portable generators, and higher revenue from power washer products. Commercial and industrial (“C&I”) product sales for the first half of 2014 increased 23.2% to $320.8 million from $260.5 million for the comparable period in 2013. The increase was driven primarily by contributions from recent acquisitions, and to a lesser extent by strength in the oil & gas end markets, and organic growth for stationary generators, light towers and natural gas generators.

[0001437749-14-014607:mdna:50]
Gross profit.    Gross profit margin for the second quarter of 2014 was 35.3% compared to 37.8% in the prior-year second quarter. Gross margin was impacted over the prior year due to the addition of recent acquisitions along with a return to regular promotional activities consistent with a period of normal seasonality.

[0001437749-14-014607:mdna:51]
Gross profit margin for the first half of 2014 was 35.1% compared to 38.1% in the prior-year first half. Gross margin was impacted over the prior year primarily due to the factors affecting gross margin described above.

[0001437749-14-014607:mdna:52]
Operating expenses.    Operating expenses decreased $4.7 million, or 8.6%, to $49.8 million for the three months ended June 30, 2014 from $54.5 million for the three months ended June 30, 2013. The decrease was primarily driven by a $4.9 million gain recorded in the second quarter of 2014 relating to a remeasurement of a contingent earn-out obligation from a recent acquisition. Excluding this gain, operating expenses were approximately flat relative to prior year despite the addition of operating expenses associated with recent acquisitions.

[0001437749-14-014607:mdna:53]
Operating expenses decreased $7.4 million, or 6.6%, to $104.1 million for the six months ended June 30, 2014 from $111.5 million for the six months ended June 30, 2013, primarily due to the factors affecting operating expenses noted above, plus a $2.1 million year over year decline in amortization of intangible assets.

[0001437749-14-014607:mdna:54]
Other expense.    Other expense decreased $33.9 million, or 114.4%, to income of $4.3 million for the three months ended June 30, 2014 from expense of $29.6 million for the three months ended June 30, 2013. Beginning in the second quarter of 2014, there was a 25 basis point reduction in borrowing costs as a result of the net debt leverage ratio falling below 3.0 times, resulting in a $16.0 million non-cash gain being recorded in the second quarter of 2014. In conjunction with the May 2013 refinancing and other debt prepayments made in the prior year quarter, a $13.5 million loss on extinguishment of debt was recorded during the second quarter of 2013. Additionally, there was a $2.8 million year over year decrease in interest expense.

[0001437749-14-014607:mdna:55]
Other expense decreased $39.9 million, or 85.4%, to $6.8 million for the six months ended June 30, 2014 from $46.7 million for the six months ended June 30, 2013, primarily due to the current year $16.0 million gain and prior year $15.3 million loss on extinguishment of debt described above, and a $6.8 million year over year decrease in interest expense.

[0001437749-14-014607:mdna:56]
Provision for income taxes.   Income tax expense was $28.4 million for the three months ended June 30, 2014 compared to $18.5 million for the three months ended June 30, 2013. Income tax expense was $47.9 million for the six months ended June 30, 2014 compared to $47.3 million for the six months ended June 30, 2013. The increase in income tax expense was primarily driven by the increase in pre-tax income during the first half of 2014 compared to the first half of 2013, and the decrease in effective income tax rate from 37.5% for the six months eneded June 30, 2013 to 35.1% for the six months ended June 30, 2014

[0001437749-14-014607:mdna:57]
Net income.    Due to the factors outlined above, we generated net income of $54.0 million for the three months ended June 30, 2014 compared to $28.3 million for the three months ended June 30, 2013, and generated net income of $88.7 million for the six months ended June 30, 2014 compared to $78.9 million for the six months ended June 30, 2013.

[0001437749-14-014607:mdna:58]
Adjusted EBITDA.    Adjusted EBITDA, as defined in the accompanying reconciliation schedules, decreased $5.6 million or 6.2%, to $84.5 million for the three months ended June 30, 2014 from $90.1 million for the three months ended June 30, 2013, due to the factors outlined above. Adjusted EBITDA decreased $36.9 million or 18.5%, to $162.0 million for the six months ended June 30, 2014 from $198.9 million for the six months ended June 30, 2013, due to the factors outlined above.

[0001437749-14-014607:mdna:59]
Adjusted Net Income.    Adjusted Net Income, as defined in the accompanying reconciliation schedules, of $57.1 million for the three months ended June 30, 2014 decreased 14.2% from $66.6 million for the three months ended June 30, 2013, due to the factors outlined above. Adjusted Net Income of $107.8 million for the six months ended June 30, 2014 decreased 28.3% from $150.4 million for the six months ended June 30, 2013, due to the factors outlined above.

[0001437749-14-014607:mdna:60]
See “Non-GAAP Measures” for a discussion of how we calculate these non-GAAP measures and limitations on their usefulness.

[0001437749-14-014607:mdna:61]
Liquidity and Financial Position

[0001437749-14-014607:mdna:62]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL revolving credit facility.

[0001437749-14-014607:mdna:63]
On May 31, 2013, we amended and restated our then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement).The New Term Loan Credit Agreement provides for a $1.2 billion term loan B credit facility (New Term Loan) and includes a $300.0 million uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay the previous credit agreement and to fund a special cash dividend of $5.00 per share on our common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses. The New Term Loan initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans has been reduced to 1.50% and the applicable margin related to LIBOR rate loans has been reduced to 2.50%, to the extent that Generac Power Systems’ (Borrower) net debt leverage ratio, as defined in the New Term Loan Credit Agreement, is below 3.00 to 1.00 for that measurement period. Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, we amended our then existing ABL credit agreement. The amendment provides for a one year extension of the maturity date in respect of the $150.0 million senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018. As of June 30, 2014, no amounts were outstanding under the ABL Facility.

[0001437749-14-014607:mdna:64]
[same as prior period, unchanged from 0001474735-14-000015:mdna:55]

[0001437749-14-014607:mdna:65]
At June 30, 2014, we had cash and cash equivalents of $198.0 million and $148.5 million of net availability under our revolving credit facility.

[0001437749-14-014607:mdna:66]
Long-term Liquidity

[0001437749-14-014607:mdna:67]
We believe that our cash flow from operations and availability under our revolving credit facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provides us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-14-014607:mdna:68]
Cash Flow

[0001437749-14-014607:mdna:69]
Six months ended June 30, 2014 compared to six months ended June 30, 2013

[0001437749-14-014607:mdna:70]
[same as prior period, unchanged from 0001474735-14-000015:mdna:61]

[0001437749-14-014607:mdna:71]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | $ Change |  |  | % Change |  |
| (Dollars in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 85,285 |  |  | $ | 74,318 |  |  | $ | 10,967 |  |  |  | 14.8 | % |
| Net cash used in investing activities |  | $ | (13,739 | ) |  | $ | (1,484 | ) |  | $ | (12,255 | ) |  |  | * |  |
| Net cash used in financing activities |  | $ | (23,817 | ) |  | $ | (54,230 | ) |  | $ | 30,413 |  |  |  | 56.1 | % |

[0001437749-14-014607:mdna:72]
* Measure not meaningful

[0001437749-14-014607:mdna:73]
Net cash provided by operating activities was $85.3 million for the six months ended June 30, 2014 compared to $74.3 million for the six months ended June 30, 2013. This 14.8% increase was primarily driven by a reduction in working capital investment due to lower inventory levels in 2014 as compared to 2013. The prior period included a significant use of cash to replenish finished goods inventory levels that had been depleted from major power outages.

[0001437749-14-014607:mdna:74]
Net cash used in investing activities was $13.7 million for the six months ended June 30, 2014, which primarily related to the purchase of property and equipment. Net cash used in investing activities was $1.5 million for the six months ended June 30, 2013, which primarily related to the purchase of property and equipment, partially offset by cash proceeds relating to the finalization of the Ottomotores purchase price.

[0001437749-14-014607:mdna:75]
Net cash used in financing activities was $23.8 million for the six months ended June 30, 2014, primarily representing $25.6 million of debt repayments ($18.6 million of long-term borrowings and $7.1 of short-term borrowings) partially offset by $4.0 million cash proceeds from short-term borrowings. In addition, the Company paid $8.9 million related to the net share settlement of equity awards which was partially offset by $7.2 million of cash inflow related to excess tax benefits of equity awards.

[0001437749-14-014607:mdna:76]
Net cash used in financing activities was $54.2 million for the six months ended June 30, 2013, primarily representing the net cash impact of debt prepayments and the dividend recapitalization transaction that occurred during the first half of 2013, including cash proceeds from long-term borrowings of $1,200.0 million, offset by $897.8 million of long-term borrowing prepayments. The Company paid $21.7 million for transaction fees incurred in connection with the dividend recapitalization transaction. Following the refinancing, the Company paid a special cash dividend of $5.00 per share ($340.8 million) on the Company’s common stock (incremental to the $2.6 million cash dividends paid during the first quarter of 2013 related to the payment of a prior year dividend paid upon vesting of restricted shares). In addition, the Company paid $11.3 million related to the net share settlement of equity awards which was partially offset by approximately $8.4 million of cash inflow due to excess tax benefits of equity awards. Finally, the Company received net cash proceeds of $11.5 million from short-term borrowings.

[0001437749-14-014607:mdna:77]
[same as prior period, unchanged from 0001474735-14-000015:mdna:67]

[0001437749-14-014607:mdna:78]
[same as prior period, unchanged from 0001474735-14-000015:mdna:68]

[0001437749-14-014607:mdna:79]
Off-Balance Sheet Arrangements

[0001437749-14-014607:mdna:80]
[same as prior period, unchanged from 0001474735-14-000015:mdna:70]

[0001437749-14-014607:mdna:81]
Critical Accounting Policies

[0001437749-14-014607:mdna:82]
[same as prior period, unchanged from 0001474735-14-000015:mdna:72]

[0001437749-14-014607:mdna:83]
As discussed in our Annual Report on Form 10-K for the fiscal year ended December 31, 2013, in preparing the financial statements in accordance with accounting principles generally accepted in the U.S., we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to accounting principles generally accepted in the U.S., and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment, business combinations and purchase accounting, defined benefit pension obligations, estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty, other contingencies, derivative accounting, income taxes and share based compensation.

[0001437749-14-014607:mdna:84]
Non-GAAP Measures

[0001437749-14-014607:mdna:85]
[same as prior period, unchanged from 0001474735-14-000015:mdna:75]

[0001437749-14-014607:mdna:86]
Adjusted EBITDA represents net income before interest expense, taxes, depreciation and amortization, as further adjusted for the other items reflected in the reconciliation table set forth below. The computation of Adjusted EBITDA is based on the definition of EBITDA contained in both Generac's New Term Loan and New ABL Credit Agreements, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements.

[0001437749-14-014607:mdna:87]
[same as prior period, unchanged from 0001474735-14-000015:mdna:77]

[0001437749-14-014607:mdna:88]
|  | • | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-14-014607:mdna:89]
|  | • | to allocate resources to enhance the financial performance of our business; |

[0001437749-14-014607:mdna:90]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2014 Proxy Statement; |

[0001437749-14-014607:mdna:91]
|  | • | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-14-014607:mdna:92]
|  | • | in communications with our board of directors and investors concerning our financial performance. |

[0001437749-14-014607:mdna:93]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of our company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-14-014607:mdna:94]
|  | • | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-14-014607:mdna:95]
|  | • | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our company, including our ability to service our debt and other cash needs; and |

[0001437749-14-014607:mdna:96]
|  | • | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-14-014607:mdna:97]
[same as prior period, unchanged from 0001474735-14-000015:mdna:87]

[0001437749-14-014607:mdna:98]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-down and other charges, non-cash gains and write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-14-014607:mdna:99]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; |

[0001437749-14-014607:mdna:100]
|  | • | are non-cash in nature, such as share-based compensation; or |

[0001437749-14-014607:mdna:101]
|  | • | were eliminated following the consummation of our initial public offering. |

[0001437749-14-014607:mdna:102]
[same as prior period, unchanged from 0001474735-14-000015:mdna:92]

[0001437749-14-014607:mdna:103]
[same as prior period, unchanged from 0001474735-14-000015:mdna:93]

[0001437749-14-014607:mdna:104]
|  | • | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-14-014607:mdna:105]
|  | • | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-14-014607:mdna:106]
|  | • | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-14-014607:mdna:107]
|  | • | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-14-014607:mdna:108]
21

[0001437749-14-014607:mdna:109]
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-down and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-14-014607:mdna:110]
|  | • | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-14-014607:mdna:111]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the items that are included as adjustments in calculating Adjusted EBITDA (subject ultimately to review by our board of directors in the context of the board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our board of directors in the context of the board's review of our quarterly financial statements and certification by our chief financial officer in a compliance certificate provided to the lenders under our New Term Loan Credit Agreement and New ABL Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-14-014607:mdna:112]
[same as prior period, unchanged from 0001474735-14-000015:mdna:101]

[0001437749-14-014607:mdna:113]
[same as prior period, unchanged from 0001474735-14-000015:mdna:102]

[0001437749-14-014607:mdna:114]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (Dollars in thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Interest expense |  |  | 11,428 |  |  |  | 14,263 |  |  |  | 23,117 |  |  |  | 29,938 |  |
| Depreciation and amortization |  |  | 8,381 |  |  |  | 8,906 |  |  |  | 16,956 |  |  |  | 17,656 |  |
| Income taxes provision |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Non-cash write-down and other adjustments (a) |  |  | (5,198 | ) |  |  | 1,240 |  |  |  | (5,752 | ) |  |  | 817 |  |
| Non-cash share-based compensation expense (b) |  |  | 2,881 |  |  |  | 3,261 |  |  |  | 6,203 |  |  |  | 6,192 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | 13,497 |  |  |  | - |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (d) |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and credit facility fees (e) |  |  | 498 |  |  |  | 1,589 |  |  |  | 701 |  |  |  | 1,903 |  |
| Other |  |  | 134 |  |  |  | 552 |  |  |  | 173 |  |  |  | 843 |  |
| Adjusted EBITDA |  | $ | 84,532 |  |  | $ | 90,097 |  |  | $ | 162,030 |  |  | $ | 198,898 |  |

[0001437749-14-014607:mdna:115]
[same as prior period, unchanged from 0001474735-14-000015:mdna:104]

[0001437749-14-014607:mdna:116]
• for the three and six months ended June 30, 2014, losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-14-014607:mdna:117]
• for the three and six months ended June 30, 2013, losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and adjustments to an earn-out obligations in connection with an acquisition.

[0001437749-14-014607:mdna:118]
[same as prior period, unchanged from 0001474735-14-000015:mdna:106]

[0001437749-14-014607:mdna:119]
• The loss on disposals of assets described above result from the sale of assets that are no longer useful in our business and therefore represent losses that are not from our core operations.

[0001437749-14-014607:mdna:120]
• The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance.

[0001437749-14-014607:mdna:121]
(b)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their vesting period.

[0001437749-14-014607:mdna:122]
(c)  Relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt.

[0001437749-14-014607:mdna:123]
(d)  Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-14-014607:mdna:124]
(e)   Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as:

[0001437749-14-014607:mdna:125]
• administrative agent fees and revolving credit facility commitment fees under our New Term Loan Credit Agreement and New ABL Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-14-014607:mdna:126]
• transaction costs relating to the acquisition of a business.

[0001437749-14-014607:mdna:127]
[same as prior period, unchanged from 0001474735-14-000015:mdna:113]

[0001437749-14-014607:mdna:128]
Adjusted Net Income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company’s debt, gains and losses on changes in cash flows related to the Company’s debt, intangible asset impairment charges (as applicable), transaction costs and other purchase accounting adjustments, and certain non-cash gains and losses as reflected in the reconciliation table set forth below (as applicable).

[0001437749-14-014607:mdna:129]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations, our cash flows, and the factors and trends affecting our business.

[0001437749-14-014607:mdna:130]
[same as prior period, unchanged from 0001474735-14-000015:mdna:116]

[0001437749-14-014607:mdna:131]
[same as prior period, unchanged from 0001474735-14-000015:mdna:117]

[0001437749-14-014607:mdna:132]
|  | • | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-14-014607:mdna:133]
|  | • | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; |

[0001437749-14-014607:mdna:134]
|  | • | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-14-014607:mdna:135]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (Dollars in thousands, except share and per share data) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net income |  | $ | 54,025 |  |  | $ | 28,254 |  |  | $ | 88,726 |  |  | $ | 78,928 |  |
| Provision for income taxes |  |  | 28,397 |  |  |  | 18,535 |  |  |  | 47,920 |  |  |  | 47,285 |  |
| Income before provision for income taxes |  |  | 82,422 |  |  |  | 46,789 |  |  |  | 136,646 |  |  |  | 126,213 |  |
| Amortization of intangible assets |  |  | 5,099 |  |  |  | 6,345 |  |  |  | 10,444 |  |  |  | 12,530 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,818 |  |  |  | 1,150 |  |  |  | 3,021 |  |  |  | 2,327 |  |
| Loss on extinguishment of debt (a) |  |  | - |  |  |  | 13,497 |  |  |  | - |  |  |  | 15,336 |  |
| Gain on change in contractual interest rate (b) |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (c) |  |  | (4,512 | ) |  |  | 1,430 |  |  |  | (4,699 | ) |  |  | 1,177 |  |
| Adjusted net income before provision for income taxes |  |  | 68,813 |  |  |  | 69,211 |  |  |  | 129,398 |  |  |  | 157,583 |  |
| Cash income tax expense (d) |  |  | (11,690 | ) |  |  | (2,650 | ) |  |  | (21,560 | ) |  |  | (7,170 | ) |
| Adjusted net income |  | $ | 57,123 |  |  | $ | 66,561 |  |  | $ | 107,838 |  |  | $ | 150,413 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.82 |  |  | $ | 0.95 |  |  | $ | 1.54 |  |  | $ | 2.15 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,087,976 |  |  |  | 69,809,599 |  |  |  | 70,088,438 |  |  |  | 69,801,498 |  |

[0001437749-14-014607:mdna:136]
(a) Relates to the May 2013 credit agreement refinancing and other debt prepayments, resulting in a loss on extinguishment of debt.

[0001437749-14-014607:mdna:137]
(b) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-14-014607:mdna:138]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. Also includes certain purchase accounting adjustments and adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-14-014607:mdna:139]
(d) Amount for the three and six months ended June 30, 2014 is based on an anticipated cash income tax rate of approximately 18% for the full year-ended 2014. Amount for the three and six months ended June 30, 2013 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2013.

[0001437749-14-014607:mdna:140]
[same as prior period, unchanged from 0001474735-14-000015:mdna:124]

[0001437749-14-014607:mdna:141]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. The guidance is effective for fiscal years and interim periods within those years, beginning after December 15, 2016. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s result of operations.

[0001437749-14-014607:mdna:142]
In July 2013, the FASB issued ASU No. 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The guidance requires an entity to net their unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements against a deferred tax asset for a net operating loss carryforward, a similar tax loss or tax credit carryforward, unless such tax loss or credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes resulting from the disallowance of a tax position. In the event that the tax position is disallowed or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit shall be presented in the financial statements as a liability and shall not be combined with deferred tax assets. The guidance is effective for fiscal years and interim periods within those years, beginning after December 15, 2013, and is to be applied prospectively to all unrecognized tax benefits that exist at the effective date. The Company’s adoption of this standard did not have a material impact on the Company’s financial condition or results of operations.

[0001437749-14-014607:mdna:143]
[same as prior period, unchanged from 0001474735-14-000015:mdna:126]
