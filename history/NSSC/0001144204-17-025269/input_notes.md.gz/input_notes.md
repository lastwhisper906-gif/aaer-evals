# NSSC notes — 0001144204-17-025269


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-17-025269:notes:1]
[same as prior period, unchanged from 0001144204-17-006227:notes:3]

[0001144204-17-025269:notes:2]
[same as prior period, unchanged from 0001144204-17-006227:notes:4]

[0001144204-17-025269:notes:3]
[same as prior period, unchanged from 0001144204-17-006227:notes:5]

[0001144204-17-025269:notes:4]
[same as prior period, unchanged from 0001144204-17-006227:notes:6]

[0001144204-17-025269:notes:5]
[same as prior period, unchanged from 0001144204-17-006227:notes:7]

[0001144204-17-025269:notes:6]
[same as prior period, unchanged from 0001144204-17-006227:notes:8]

[0001144204-17-025269:notes:7]
[same as prior period, unchanged from 0001144204-17-006227:notes:9]

[0001144204-17-025269:notes:8]
[same as prior period, unchanged from 0001144204-17-006227:notes:10]

[0001144204-17-025269:notes:9]
[same as prior period, unchanged from 0001144204-17-006227:notes:11]

[0001144204-17-025269:notes:10]
[same as prior period, unchanged from 0001144204-17-006227:notes:12]

[0001144204-17-025269:notes:11]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2017 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt at March 31, 2017 in the amount of $3,500,000 approximates fair value.

[0001144204-17-025269:notes:12]
[same as prior period, unchanged from 0001144204-17-006227:notes:14]

[0001144204-17-025269:notes:13]
Cash and cash equivalents include approximately $461,000 of short-term time deposits at March 31, 2017 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2017 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

[0001144204-17-025269:notes:14]
[same as prior period, unchanged from 0001144204-17-006227:notes:16]

[0001144204-17-025269:notes:15]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of March 31, 2017 and June 30, 2016 and for returns and other allowances of $1,280,000 and $1,255,000 as of March 31, 2017 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.

[0001144204-17-025269:notes:16]
[same as prior period, unchanged from 0001144204-17-006227:notes:18]

[0001144204-17-025269:notes:17]
[same as prior period, unchanged from 0001144204-17-006227:notes:19]

[0001144204-17-025269:notes:18]
[same as prior period, unchanged from 0001144204-17-006227:notes:20]

[0001144204-17-025269:notes:19]
[same as prior period, unchanged from 0001144204-17-006227:notes:21]

[0001144204-17-025269:notes:20]
[same as prior period, unchanged from 0001144204-17-006227:notes:22]

[0001144204-17-025269:notes:21]
[same as prior period, unchanged from 0001144204-17-006227:notes:23]

[0001144204-17-025269:notes:22]
[same as prior period, unchanged from 0001144204-17-006227:notes:24]

[0001144204-17-025269:notes:23]
[same as prior period, unchanged from 0001144204-17-006227:notes:25]

[0001144204-17-025269:notes:24]
[same as prior period, unchanged from 0001144204-17-006227:notes:26]

[0001144204-17-025269:notes:25]
[same as prior period, unchanged from 0001144204-17-006227:notes:27]

[0001144204-17-025269:notes:26]
[same as prior period, unchanged from 0001144204-17-006227:notes:28]

[0001144204-17-025269:notes:27]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,674) |  | $ | 2,126 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,674) |  | $ | 8,026 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

[0001144204-17-025269:notes:28]
Amortization expense for intangible assets subject to amortization was approximately $111,000 and $131,000 for the three months ended March 31, 2017 and 2016, respectively. Amortization expense for intangible assets subject to amortization was approximately $331,000 and $398,000 for the nine months ended March 31, 2017 and 2016, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.3 years and  12.3 years at March 31, 2017 and 2016, respectively.

[0001144204-17-025269:notes:29]
[same as prior period, unchanged from 0001144204-17-006227:notes:31]

[0001144204-17-025269:notes:30]
[same as prior period, unchanged from 0001144204-17-006227:notes:32]

[0001144204-17-025269:notes:31]
[same as prior period, unchanged from 0001144204-17-006227:notes:33]

[0001144204-17-025269:notes:32]
[same as prior period, unchanged from 0001144204-17-006227:notes:34]

[0001144204-17-025269:notes:33]
[same as prior period, unchanged from 0001144204-17-006227:notes:35]

[0001144204-17-025269:notes:34]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2017 and 2016, respectively.

[0001144204-17-025269:notes:35]
[same as prior period, unchanged from 0001144204-17-006227:notes:37]

[0001144204-17-025269:notes:36]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2017 and 2016 was $365,000 and $259,000, respectively. Advertising expense for the nine months ended March 31, 2017 and 2016 was $1,537,000 and $1,328,000, respectively.

[0001144204-17-025269:notes:37]
[same as prior period, unchanged from 0001144204-17-006227:notes:39]

[0001144204-17-025269:notes:38]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2017 and 2016 was $1,698,000 and $1,513,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2017 and 2016 was $4,935,000 and $4,521,000, respectively.

[0001144204-17-025269:notes:39]
[same as prior period, unchanged from 0001144204-17-006227:notes:41]

[0001144204-17-025269:notes:40]
[same as prior period, unchanged from 0001144204-17-006227:notes:42]

[0001144204-17-025269:notes:41]
[same as prior period, unchanged from 0001144204-17-006227:notes:43]

[0001144204-17-025269:notes:42]
[same as prior period, unchanged from 0001144204-17-006227:notes:44]

[0001144204-17-025269:notes:43]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

[0001144204-17-025269:notes:44]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 952 |  | $ | 1,044 |  |  | 18,819 |  |  | 18,811 |  | $ | 0.05 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 36 |  |  | 17 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 952 |  | $ | 1,044 |  |  | 18,855 |  |  | 18,828 |  | $ | 0.05 |  | $ | 0.06 |  |

[0001144204-17-025269:notes:45]
Options to  purchase  0 and  166,000 shares of common stock for the three months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-17-025269:notes:46]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

[0001144204-17-025269:notes:47]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 2,357 |  | $ | 2,335 |  |  | 18,797 |  |  | 18,903 |  | $ | 0.13 |  | $ | 0.12 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 47 |  |  | 20 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 2,357 |  | $ | 2,335 |  |  | 18,844 |  |  | 18,923 |  | $ | 0.13 |  | $ | 0.12 |  |

[0001144204-17-025269:notes:48]
Options to  purchase  0 and  147,000 shares of common stock for the nine months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-17-025269:notes:49]
[same as prior period, unchanged from 0001144204-17-006227:notes:51]

[0001144204-17-025269:notes:50]
[same as prior period, unchanged from 0001144204-17-006227:notes:52]

[0001144204-17-025269:notes:51]
[same as prior period, unchanged from 0001144204-17-006227:notes:53]

[0001144204-17-025269:notes:52]
No stock-based compensation costs were recognized for three months ended March 31, 2017 or 2016. Stock-based compensation costs of $97,000 and $92,000 were recognized for nine months ended March 31, 2017 and 2016, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended March 31, 2017 and 2016. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the nine months ended March 31, 2017 and 2016.

[0001144204-17-025269:notes:53]
[same as prior period, unchanged from 0001144204-17-006227:notes:55]

[0001144204-17-025269:notes:54]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2017 and 2016.

[0001144204-17-025269:notes:55]
[same as prior period, unchanged from 0001144204-17-006227:notes:57]

[0001144204-17-025269:notes:56]
For the three and nine months ended March 31, 2017 and 2016, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

[0001144204-17-025269:notes:57]
[same as prior period, unchanged from 0001144204-17-006227:notes:59]

[0001144204-17-025269:notes:58]
[same as prior period, unchanged from 0001144204-17-006227:notes:60]

[0001144204-17-025269:notes:59]
[same as prior period, unchanged from 0001144204-17-006227:notes:61]

[0001144204-17-025269:notes:60]
The Company records the amount billed to customers for shipping and handling in net sales ($104,000 and $109,000 in the three months ended March 31, 2017 and 2016, respectively and $349,000 and $365,000 in the nine months ended March 31, 2017 and 2016, respectively) and classifies the costs associated with these revenues in cost of sales ($250,000 and $232,000 in the three months ended March 31, 2017 and 2016, respectively and $683,000 and $673,000 in the nine months ended March 31, 2017 and 2016, respectively).

[0001144204-17-025269:notes:61]
Recently Issued Accounting Standards

[0001144204-17-025269:notes:62]
[same as prior period, unchanged from 0001144204-17-006227:notes:64]

[0001144204-17-025269:notes:63]
[same as prior period, unchanged from 0001144204-17-006227:notes:65]

[0001144204-17-025269:notes:64]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively. Prior periods were not retrospectively adjusted.

[0001144204-17-025269:notes:65]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-17-025269:notes:66]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-025269:notes:67]
[same as prior period, unchanged from 0001144204-17-006227:notes:69]

[0001144204-17-025269:notes:68]
[same as prior period, unchanged from 0001144204-17-006227:notes:70]

[0001144204-17-025269:notes:69]
[same as prior period, unchanged from 0001144204-17-006227:notes:71]

[0001144204-17-025269:notes:70]
|  |  | Three months ended March 31, |  | Nine months ended March 31, |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
|  |  | (in thousands) |  | (in thousands) |  |  |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 20,059 |  | $ | 19,229 |  | $ | 59,652 |  | $ | 56,515 |  |
| Foreign |  |  | 748 |  |  | 579 |  |  | 2,038 |  |  | 1,939 |  |
| Total Net Sales |  | $ | 20,807 |  | $ | 19,808 |  | $ | 61,690 |  | $ | 58,454 |  |

[0001144204-17-025269:notes:71]
| Identifiable assets: |  | March 31, 2017 |  | June 30, 2016 |  |
| United States |  | $ | 50,081 |  | $ | 51,272 |  |
| Dominican Republic (2) |  |  | 15,924 |  |  | 13,497 |  |
| Total Identifiable Assets |  | $ | 66,005 |  | $ | 64,769 |  |

[0001144204-17-025269:notes:72]
[same as prior period, unchanged from 0001144204-17-006227:notes:74]

[0001144204-17-025269:notes:73]
(2) Consists primarily of inventories (March 31, 2017 = $12,371, June 30, 2016 = $10,076) and fixed assets (March 31, 2017 = $3,331, June 30, 2016 = $3,311) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-17-025269:notes:74]
NOTE 10 - Commitments and Contingencies

[0001144204-17-025269:notes:75]
Leases

[0001144204-17-025269:notes:76]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2020.

[0001144204-17-025269:notes:77]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $6,000 for the three months ended March 31, 2017 and 2016, respectively and $17,000 and $20,000 for the nine months ended March 31, 2017 and 2016, respectively.

[0001144204-17-025269:notes:78]
Land Lease

[0001144204-17-025269:notes:79]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-17-025269:notes:80]
Litigation

[0001144204-17-025269:notes:81]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-17-025269:notes:82]
Employment Agreements

[0001144204-17-025269:notes:83]
As of March 31, 2017, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $730,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-025269:notes:84]
[same as prior period, unchanged from 0001144204-17-006227:notes:104]

[0001144204-17-025269:notes:85]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $32,000 and $26,000 for the three months ended March 31, 2017 and 2016, respectively, and $87,000 and $81,000 for the nine months ended March 31, 2017 and 2016, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-025269:notes:86]
NOTE 8 – Stockholders’ Equity Transactions

[0001144204-17-025269:notes:87]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. No shares were purchased under this plan during the nine months ended March 31, 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-025269:notes:88]
[same as prior period, unchanged from 0001144204-17-006227:notes:120]

[0001144204-17-025269:notes:89]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended March 31, 2017 and 2016, the Company recorded non-cash no compensation expense relating to stock-based compensation. For the nine months ended March 31, 2017 and 2016, the Company recorded non-cash compensation expense of $97,000 ($.00 per basic and diluted share) and $92,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-17-025269:notes:90]
[same as prior period, unchanged from 0001144204-17-006227:notes:122]

[0001144204-17-025269:notes:91]
In December 2012, the stockholders approved the 2012 Employee Stock Option Plan (the 2012 Employee Plan). The 2012 Employee Plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  950,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options, which are intended to qualify as incentive stock options (ISOs), to valued employees.  Any plan participant who is granted ISOs and possesses more than 10% of the voting rights of the Company's outstanding common stock  must be granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-17-025269:notes:92]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2017,  117,500 stock options were granted,  38,500 stock options were exercisable and  822,900 stock options were available for grant under this plan.

[0001144204-17-025269:notes:93]
The following table reflects activity under the 2012 Plan for the nine months ended March 31,:

[0001144204-17-025269:notes:94]
|  |  | 2017 |  | 2016 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 112,500 |  | $ | 5.54 |  |  | 112,500 |  | $ | 5.30 |  |
| Granted |  |  | 5,000 |  |  | 8.15 |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | (10,400) |  |  | 6.08 |  |  | (15,000) |  |  | 4.29 |  |
| Exercised |  |  | (35,500) |  |  | 5.13 |  |  | -- |  |  | -- |  |
| Outstanding, end of period |  |  | 71,600 |  | $ | 5.84 |  |  | 97,500 |  | $ | 5.46 |  |
| Exercisable, end of period |  |  | 38,500 |  | $ | 5.99 |  |  | 52,700 |  | $ | 5.56 |  |
| Weighted average fair value at grant date of options granted |  | $ | 26,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 180,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 312,000 |  |  |  |  | $ | 80,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 162,000 |  |  |  |  | $ | 38,000 |  |  |  |  |

[0001144204-17-025269:notes:95]
34,000 and 0 stock options were exercised during the three months ended March 31, 2017 and 2016, respectively.  35,500 and 0 stock options were exercised during the nine months ended March 31, 2017 and 2016, respectively. The 34,000 stock options exercised during the three months ended March 31, 2017 were settled in cashless exercises by  exchanging  16,121 shares of the Company’s common stock which were retired and returned to unissued status. No cash was received from option exercises during the three months ended March 31, 2017 and 2016 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods. $9,000 and $0 was received from option exercises during the nine months ended March 31, 2017 and 2016, respectively and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-025269:notes:96]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at March 31, 2017:

[0001144204-17-025269:notes:97]
|  |  | Options outstanding |  |  | Options exercisable |  |
|  |  |  |  |  |  | Weighted average |  |  |  |  |  |  |  |  |  |  |
| Range of |  |  | Number |  |  | remaining |  |  | Weighted average |  |  | Number |  |  | Weighted average |  |
| exercise prices |  |  | outstanding |  |  | contractual life |  |  | exercise price |  |  | exercisable |  |  | exercise price |  |
| $4.88-$8.15 |  |  | 71,600 |  |  | 7.2 |  | $ | 5.84 |  |  | 38,500 |  | $ | 5.99 |  |
|  |  |  | 71,600 |  |  | 7.2 |  | $ | 5.84 |  |  | 38,500 |  | $ | 5.99 |  |

[0001144204-17-025269:notes:98]
As of March 31, 2017, there was $123,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during the three months ended March 31, 2017.  5,000 options were granted during the nine months ended March 31, 2017.   No options vested during either of the three months ended March 31, 2017 or 2016. The total fair value of the options vesting during the nine months ended March 31, 2017 and 2016 under this plan was $75,000 and $110,000, respectively.

[0001144204-17-025269:notes:99]
[same as prior period, unchanged from 0001144204-17-006227:notes:127]

[0001144204-17-025269:notes:100]
[same as prior period, unchanged from 0001144204-17-006227:notes:128]

[0001144204-17-025269:notes:101]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2017,  35,000 stock options were granted,  5,200 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-17-025269:notes:102]
The following table reflects activity under the 2012 Non-Employee Plan for the nine months ended March 31,:

[0001144204-17-025269:notes:103]
|  |  | 2017 |  | 2016 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 35,000 |  | $ | 4.73 |  |  | 35,000 |  | $ | 4.73 |  |
| Granted |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Exercised |  |  | (20,800) |  |  | 4.76 |  |  | -- |  |  | -- |  |
| Outstanding, end of period |  |  | 14,200 |  | $ | 4.69 |  |  | 35,000 |  | $ | 4.73 |  |
| Exercisable, end of period |  |  | 5,200 |  | $ | 4.76 |  |  | 19,000 |  | $ | 4.77 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 113,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 78,000 |  |  |  |  | $ | 53,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 28,000 |  |  |  |  | $ | 28,000 |  |  |  |  |

[0001144204-17-025269:notes:104]
15,600 and 0 options were exercised during the three months ended March 31, 2017 and 2016, respectively.  20,800 and 0 options were exercised during the nine months ended March 31, 2017 and 2016, respectively. All of the 20,800 exercises were settled in cashless exercises by exchanging  9,998 shares of the Company’s common stock which were retired and returned to unissued status. No cash was received from option exercises during the three and nine months ended March 31, 2017 and 2016 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-025269:notes:105]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at March 31, 2017:

[0001144204-17-025269:notes:106]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  | Weighted |  |  |  | Weighted |  |
| Range of |  | Number |  | remaining |  | average exercise |  | Number |  | average exercise |  |
| exercise prices |  | outstanding |  | contractual life |  | price |  | exercisable |  | price |  |
| $4.37 - $4.88 |  |  | 14,200 |  |  | 6.9 |  | $ | 4.69 |  |  | 5,200 |  | $ | 4.76 |  |
|  |  |  | 14,200 |  |  | 6.9 |  | $ | 4.69 |  |  | 5,200 |  | $ | 4.76 |  |

[0001144204-17-025269:notes:107]
As of March 31, 2017, there was $28,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three and nine months ended March 31, 2017. No options vested during either of the three months ended March 31, 2017 or 2016. The total fair value of the options vesting during each of the nine months ended March 31, 2017 and 2016 under this plan was   $22,000.

[0001144204-17-025269:notes:108]
[same as prior period, unchanged from 0001144204-17-006227:notes:132]

[0001144204-17-025269:notes:109]
In December 2002, the stockholders approved the 2002 Employee Stock Option Plan (the 2002 Employee Plan). This plan expired in October 2012. This plan authorized the granting of awards, the exercise of which would allow up to an aggregate of  1,836,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may have granted stock options, which were intended to qualify as incentive stock options (ISOs), to key employees.  Any plan participant who was granted ISOs and possessed more than 10% of the voting rights of the Company's outstanding common stock must have been granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-17-025269:notes:110]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At March 31, 2017,  1,471,480 stock options had been granted and  5,000 stock options were exercisable. No further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-17-025269:notes:111]
The following table reflects activity under the 2002 Employee plan for the nine months ended March 31,:

[0001144204-17-025269:notes:112]
|  |  | 2017 |  | 2016 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 102,500 |  | $ | 6.04 |  |  | 208,500 |  | $ | 6.86 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (10,500) |  |  | 6.02 |  |  | (38,500) |  |  | 11.03 |  |
| Exercised |  |  | (87,000) |  |  | 6.08 |  |  | (67,500) |  |  | 5.73 |  |
| Outstanding, end of period |  |  | 5,000 |  | $ | 5.35 |  |  | 102,500 |  | $ | 6.04 |  |
| Exercisable, end of period |  |  | 5,000 |  | $ | 5.35 |  |  | 102,500 |  | $ | 6.04 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 359,000 |  |  |  |  | $ | 98,000 |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 24,000 |  |  |  |  | $ | 31,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 24,000 |  |  |  |  | $ | 31,000 |  |  |  |  |

[0001144204-17-025269:notes:113]
35,000 and  0 stock options were exercised during the three months ended March 31, 2017 and 2016, respectively.  87,000 and  67,500 stock options were exercised during the nine months ended March 31, 2017 and 2016, respectively.   80,500 of the 87,000 exercises were settled in cashless exercises by exchanging   18,762 shares of the Company’s common stock which were retired and returned to unissued status. The remaining   6,500 exercises were paid for in cash. $40,000 and $0 was received from option exercises during the three and nine months ended March 31, 2017 and 2016, respectively and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-025269:notes:114]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at March 31, 2017:

[0001144204-17-025269:notes:115]
|  |  |  | Options outstanding and exercisable |  |
| Range of |  |  | Number |  |  | Weighted average |  |  | Weighted average |  |
| exercise prices |  |  | outstanding |  |  | remaining contractual life |  |  | exercise price |  |
| $5.35 - $5.35 |  |  | 5,000 |  |  | 0.5 |  | $ | 5.35 |  |
|  |  |  | 5,000 |  |  | 0.5 |  | $ | 5.35 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-17-025269:notes:116]
[same as prior period, unchanged from 0001144204-17-006227:notes:1]

[0001144204-17-025269:notes:117]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  28% and  22% of the Company’s accounts receivable at March 31, 2017 and June 30, 2016, respectively. Sales to this customer comprised  13% of net sales in each of the three months ended March 31, 2017 and 2016. Sales to this customer comprised  13% and  12% of net sales in the nine months ended March 31, 2017 and 2016, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-025269:notes:118]
[same as prior period, unchanged from 0001144204-17-006227:notes:76]

[0001144204-17-025269:notes:119]
[same as prior period, unchanged from 0001144204-17-006227:notes:77]

[0001144204-17-025269:notes:120]
[same as prior period, unchanged from 0001144204-17-006227:notes:78]

[0001144204-17-025269:notes:121]
|  |  | March 31, |  | June 30, |  |
|  |  | 2017 |  | 2016 |  |
| Component parts |  | $ | 16,439 |  | $ | 14,021 |  |
| Work-in-process |  |  | 4,406 |  |  | 3,758 |  |
| Finished product |  |  | 8,861 |  |  | 7,558 |  |
|  |  | $ | 29,706 |  | $ | 25,337 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 25,452 |  | $ | 21,428 |  |
| Non-current |  |  | 4,254 |  |  | 3,909 |  |
|  |  | $ | 29,706 |  | $ | 25,337 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001144204-17-025269:notes:122]
Property, plant and equipment consist of the following (in thousands):

[0001144204-17-025269:notes:123]
|  |  | March 31, |  | June 30, |  |  |  |  |
|  |  | 2017 |  | 2016 |  |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 7,058 |  |  | 7,036 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,559 |  |  | 2,531 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 22,035 |  |  | 21,035 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 345 |  |  | 294 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 41,812 |  |  | 40,711 |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 35,300 |  |  | 34,662 |  |  |  |  |
|  |  | $ | 6,512 |  | $ | 6,049 |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-17-025269:notes:124]
NOTE 4 – Property, Plant and Equipment

[0001144204-17-025269:notes:125]
Depreciation and amortization expense on property, plant, and equipment was $231,000 and $217,000 for the three months ended March 31, 2017 and 2016, respectively and $653,000 and $631,000 for the nine months ended March 31, 2017 and 2016, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-025269:notes:126]
[same as prior period, unchanged from 0001144204-17-006227:notes:94]

[0001144204-17-025269:notes:127]
[same as prior period, unchanged from 0001144204-17-006227:notes:95]

[0001144204-17-025269:notes:128]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of March 31, 2017 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for  fiscal years 2012 and thereafter.

[0001144204-17-025269:notes:129]
[same as prior period, unchanged from 0001144204-17-006227:notes:97]


## us-gaap:LongTermDebtTextBlock

[0001144204-17-025269:notes:130]
NOTE 6 - Long-Term Debt

[0001144204-17-025269:notes:131]
As of March 31, 2017, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021. The term loan has been repaid in full as of March 31, 2017.

[0001144204-17-025269:notes:132]
Outstanding balances and interest rates as of March 31, 2017 and June 30, 2016 are as follows:

[0001144204-17-025269:notes:133]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.1 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | — |  |  | — |  |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,500 |  |  | 2.1 | % | $ | 4,800 |  |  | 1.6 | % |

[0001144204-17-025269:notes:134]
The Revolving Credit Facility (the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.15% to  2.00%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-17-025269:notes:135]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.
