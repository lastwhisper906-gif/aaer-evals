# NSSC MD&A — 0001144204-17-025269


## mdna

[0001144204-17-025269:mdna:1]
Item 2.  
Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001144204-17-025269:mdna:2]
Management’s Discussion and Analysis
of Financial Condition and Results of Operations

[0001144204-17-025269:mdna:3]
|  | 19 |  |

[0001144204-17-025269:mdna:4]
|  | 20 |  |

[0001144204-17-025269:mdna:5]
16 Annual Report on Form 10-K.

[0001144204-17-025269:mdna:6]
Overview

[0001144204-17-025269:mdna:7]
The Company is a diversified manufacturer of security products,
encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products
for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International
sales accounted for approximately 4% and 3% of our revenues for the three months ended March 31, 2017 and 2016, respectively.
International sales accounted for approximately 3% of our revenues for each of the nine months ended March 31, 2017 and 2016.

[0001144204-17-025269:mdna:8]
The Company owns and operates manufacturing
facilities in Amityville, New York and the Dominican Republic. A significant portion of our operating costs are fixed, and do
not fluctuate with changes in production levels or utilization of our manufacturing capacity. As production levels rise and factory
utilization increases, the fixed costs are spread over increased output, which may contribute to increasing profit margins. Conversely,
when production levels decline our fixed costs are spread over reduced levels, which may contribute to decreasing margins.

[0001144204-17-025269:mdna:9]
The security products market is characterized
by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of revenues
to research and development (R&D) on an annual basis. The Company does not expect products resulting from our R&D investments
in fiscal 2017 to contribute materially to revenue during fiscal 2017, but should benefit the Company over future years. In general,
the new products introduced by the Company are initially shipped in limited quantities, and increase over time. Prices and manufacturing
costs tend to decline over time as products and technologies mature

[0001144204-17-025269:mdna:10]
Economic and Other Factors

[0001144204-17-025269:mdna:11]
We are subject to the effects of general economic
and market conditions. In the event that the U.S. or international economic conditions deteriorate, our revenue, profit and cash-flow
levels could be materially adversely affected in future periods. In the event of such deterioration, many of our current or potential
future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products.
Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. If such events
do occur, they may result in our expenses being too high in relation to our revenues and cash flows.

[0001144204-17-025269:mdna:12]
Seasonality

[0001144204-17-025269:mdna:13]
The Company's fiscal year begins on July 1
and ends on June 30. Historically, the end users of the Company’s products want to install its products prior to the summer;
therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter,
and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected
by the housing and construction markets. Deterioration of the current economic conditions may also affect this trend.

[0001144204-17-025269:mdna:14]
Critical Accounting Policies and Estimates

[0001144204-17-025269:mdna:15]
The Company's significant accounting policies
are fully described in Note 1 to the Company's consolidated financial statements included in its 2016 Annual Report on Form 10-K.  Management
believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in
the preparation of its consolidated financial statements.

[0001144204-17-025269:mdna:16]
Revenue Recognition

[0001144204-17-025269:mdna:17]
The Company recognizes revenue when the following criteria
are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product
or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured.
Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms
of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale.
The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of
actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001144204-17-025269:mdna:18]
19

[0001144204-17-025269:mdna:19]
The Company analyzes sales returns and is able to make
reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are
based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly,
the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results
could differ from those estimates.

[0001144204-17-025269:mdna:20]
Concentration of Credit Risk

[0001144204-17-025269:mdna:21]
An entity is more vulnerable to
concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through
diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration,
and vary in significance. The Company had one customer with an accounts receivable balance that comprised 28% and 22% of the Company’s
accounts receivable at March 31, 2017 and June 30, 2016, respectively. Sales to this customer comprised 13% of net sales in each
of the three months ended March 31, 2017 and 2016. Sales to this customer comprised 13% and 12% of net sales in the nine months
ended March 31, 2017 and 2016, respectively.

[0001144204-17-025269:mdna:22]
In the ordinary course of business,
we have established a reserve for doubtful accounts and customer deductions in the amount of $145,000 as of March 31, 2017 and
as of June 30, 2016. Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported
net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical or anticipated
events.

[0001144204-17-025269:mdna:23]
Inventories

[0001144204-17-025269:mdna:24]
Inventories are valued at the lower
of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory
includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory
costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon
estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture
and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in
ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-17-025269:mdna:25]
In addition, the Company records
an inventory obsolescence reserve, which represents the difference between the cost of the inventory and its estimated market
value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied
to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate
applications of its raw materials and to convert finished product into alternate versions of the same product to better match
customer demand. There is inherent professional judgment and subjectivity made by both production and engineering members of management
in determining the estimated obsolescence percentage. In addition, and as necessary, the Company may establish specific reserves
for future known or anticipated events. The Company also regularly reviews the period over which its inventories will be converted
to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001144204-17-025269:mdna:26]
Intangible Assets

[0001144204-17-025269:mdna:27]
The Company evaluates its Intangible
Assets for impairment at least on an annual basis and will evaluate them earlier if there are indicators of a potential impairment.
Those intangible assets that are classified as goodwill or as other intangibles with indefinite lives are not amortized. Impairment
testing is performed in two steps: (i) the Company determines if there is impairment by comparing the fair value of a reporting
unit with its carrying value, and (ii) if there is impairment, the Company measures the amount of impairment loss by comparing
the implied fair value of intangible assets with the carrying amount of the intangible assets.

[0001144204-17-025269:mdna:28]
Income Taxes

[0001144204-17-025269:mdna:29]
The Company has identified the
United States and New York State as its major tax jurisdictions. The fiscal 2012 and forward years are still open for examination.

[0001144204-17-025269:mdna:30]
For the nine months ended March
31, 2017, the Company recognized a net income tax expense of $480,000. During the nine months ended March 31, 2017 the Company
increased its reserve for uncertain income tax positions by $35,000. The Company’s practice is to recognize interest and
penalties related to income tax matters in income tax expense and accrued income taxes. As of March 31, 2017, the Company had
accrued interest totaling $0 and $183,000 of unrecognized net tax benefits that, if recognized, would favorably affect the Company’s
effective income tax rate in any future period. The Company uses the flow through method to account for investment tax credits
earned on eligible research and development expenditures. Under this method, the investment tax credits are recognized as a reduction
to income tax expense.

[0001144204-17-025269:mdna:31]
20

[0001144204-17-025269:mdna:32]
Deferred tax assets and liabilities
are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying
amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using
enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered
or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that
includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and
deferred tax liabilities. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more
likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes
the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.

[0001144204-17-025269:mdna:33]
Results of Operations

[0001144204-17-025269:mdna:34]
|  |  | Three months ended March 31, (dollars in thousands) |  |  | Nine months ended March 31, (dollars in thousands) |  |
|  |  | 2017 |  |  | 2016 |  |  | % Increase/ (decrease) |  |  | 2017 |  |  | 2016 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 20,807 |  |  | $ | 19,808 |  |  |  | 5.0 | % |  | $ | 61,690 |  |  | $ | 58,454 |  |  |  | 5.5 | % |
| Gross profit |  |  | 6,663 |  |  |  | 6,108 |  |  |  | 9.1 | % |  |  | 19,732 |  |  |  | 17,946 |  |  |  | 10.0 | % |
| Gross profit as a % of net sales |  |  | 32.0 | % |  |  | 30.8 | % |  |  | 3.9 | % |  |  | 32.0 | % |  |  | 30.7 | % |  |  | 4.2 | % |
| Selling, general and administrative |  |  | 5,527 |  |  |  | 4,894 |  |  |  | 12.9 | % |  |  | 16,816 |  |  |  | 15,389 |  |  |  | 9.3 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 26.6 | % |  |  | 24.7 | % |  |  | 7.7 | % |  |  | 27.3 | % |  |  | 26.3 | % |  |  | 3.8 | % |
| Operating income |  |  | 1,136 |  |  |  | 1,214 |  |  |  | (6.4 | )% |  |  | 2,916 |  |  |  | 2,557 |  |  |  | 14.0 | % |
| Interest expense, net |  |  | 17 |  |  |  | 45 |  |  |  | (62.2 | )% |  |  | 59 |  |  |  | 139 |  |  |  | (57.6 | )% |
| Provision for income taxes |  |  | 167 |  |  |  | 125 |  |  |  | 33.6 | % |  |  | 480 |  |  |  | 83 |  |  |  | 478.3 | % |
| Net income |  |  | 952 |  |  |  | 1,044 |  |  |  | (8.8 | )% |  |  | 2,377 |  |  |  | 2,335 |  |  |  | 1.8 | % |

[0001144204-17-025269:mdna:35]
Sales for the three months ended March 31,
2017 increased by $999,000 to $20,807,000 as compared to $19,808,000 for the same period a year ago. Sales for the nine months
ended March 31, 2017 increased by $3,236,000 to $61,690,000 as compared to $58,454,000 for the same period a year ago. The increase
in sales for the three months ended March 31, 2017 was due primarily to increased sales of the Company’s intrusion products
($801,000), access control products ($150,000) and door-locking products ($47,000). The increase in sales for the nine months
ended March 31, 2017 was due primarily to increased sales of the Company’s intrusion products ($3,048,000) and door-locking
products ($357,000) as partially offset by decreased sales of access control products ($169,000). Sales of the Company’s
intrusion products increased primarily from increased sales of its wireless products.

[0001144204-17-025269:mdna:36]
Gross profit for the three months ended March
31, 2017 increased to $6,663,000 or 32.0% of sales as compared to $6,108,000 or 30.8% of sales for the same period a year ago.
Gross profit for the nine months ended March 31, 2017 increased to $19,732,000 or 32.0% of sales as compared to $17,946,000 or
30.7% of sales for the same period a year ago. The increase in gross profit for the three and nine months was primarily due to
the increase in sales as described above as well as a more favorable product mix.

[0001144204-17-025269:mdna:37]
Selling, general and administrative expenses
for the three months ended March 31, 2017 increased by $633,000 to $5,527,000 from $4,894,000 for the same period a year ago.
Selling, general and administrative expenses for the nine months ended March 31, 2017 increased by $1,427,000 to $16,816,000 from
$15,389,000 for the same period a year ago. Selling, general and administrative expenses as a percentage of net sales increased
to 26.6% for the three months ended March 31, 2017 from 24.7% for the same period a year ago. Selling, general and administrative
expenses as a percentage of net sales increased to 27.3% for the nine months ended March 31, 2017 from 26.3% for the same period
a year ago. The increase in dollars for the three and nine months was due primarily from increased advertising and the addition
of selling personnel. The increase as a percentage of sales for the three and nine months is due primarily to the increase in
these expenses being proportionally greater than the increase in sales.

[0001144204-17-025269:mdna:38]
|  | 21 |  |

[0001144204-17-025269:mdna:39]
Interest expense, net for the three months
ended March 31, 2017 decreased by $28,000 to $17,000 as compared to $45,000 for the same period a year ago. Interest expense,
net for the nine months ended March 31, 2017 decreased by $80,000 to $59,000 as compared to $139,000 for the same period a year
ago. The decrease in interest expense for the three and nine months ended March 31, 2017 resulted from lower average outstanding
debt during the current periods as compared to the same periods a year ago.

[0001144204-17-025269:mdna:40]
The Company’s provision for income
taxes for the three months ended March 31, 2017 increased by $42,000 to $167,000 as compared to $125,000 for the same period a
year ago. The Company’s provision for income taxes for the nine months ended March 31, 2017 increased by $397,000 to $480,000
as compared to $83,000 for the same period a year ago. The change in the provision for income taxes for the three months was caused
primarily by an increase in income allocated to the United States as compared to the same period a year ago. The change in the
provision for income taxes for the nine months was caused primarily by the increase in income before taxes as compared to the
same period a year ago as well as by the reversal of a liability during the nine months ended March 31, 2016 that was no longer
required relating to foreign source income and the reinstatement of the R&D Credit during the same period. As a result, the
Company’s effective rate for income tax was 15% and 11% for the three months ended March 31, 2017 and 2016, respectively
and 17% and 3% for the nine months ended March 31, 2017 and 2016, respectively.

[0001144204-17-025269:mdna:41]
Net income decreased by $92,000 to $952,000
or $0.05 per diluted share for the three months ended March 31, 2017 as compared to $1,044,000 or $0.06 per diluted share for
the same period a year ago. Net income increased by $42,000 to $2,377,000 or $0.13 per diluted share for the nine months ended
March 31, 2017 as compared to $2,335,000 or $0.12 per diluted share for the same period a year ago. The change in net income for
the three and nine months ended March 31, 2017 was primarily due to the items described above.

[0001144204-17-025269:mdna:42]
Liquidity and Capital Resources

[0001144204-17-025269:mdna:43]
During the nine months ended March 31,
2017 the Company utilized its cash generated from operations ($989,000) and a portion of its cash on hand at June 30, 2016 ($1,426,000
of $3,805,000) to repay outstanding debt ($1,300,000) and purchase property, plant and equipment ($1,115,000). The Company believes
its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s
operations through the next twelve months.

[0001144204-17-025269:mdna:44]
Accounts payable and accrued expenses other than accrued income
taxes decreased $270,000 to $8,418,000 as of March 31, 2017 as compared to $8,688,000 at June 30, 2016.

[0001144204-17-025269:mdna:45]
Inventories at March 31, 2017 increased $4,369,000
to $29,706,000 as compared to $25,337,000 at June 30, 2016. This increase is primarily the result of the Company’s level-loading
its production output throughout the year, whereas the Company’s sales are typically highest in the fourth quarter. The
increase is also due, in part, to the Company replenishing its inventory that was reduced at June 30, 2016 by a particularly strong
sales level in June 2016 which reduced inventory levels as of June 30, 2016.

[0001144204-17-025269:mdna:46]
Accounts payable and accrued expenses decreased $270,000 to $8,418,000
as of March 31, 2017 as compared to $8,688,000 at June 30, 2016.

[0001144204-17-025269:mdna:47]
As of March 31, 2017, long-term debt consisted
of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 As of March
31, 2017, the Company had $3,500,000 in outstanding borrowings and $7,500,000 in availability under the Revolving Credit Facility.
The Company’s long-term debt is described more fully in Note 6 to the condensed consolidated financial statements.

[0001144204-17-025269:mdna:48]
The agreement contains various restrictions
and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain
financial ratios, as defined in the restated agreement.

[0001144204-17-025269:mdna:49]
As of March 31, 2017 the Company had no material
commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
