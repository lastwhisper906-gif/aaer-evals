# NSSC 8-K — 0001144204-17-006515 filed 2017-02-07

## item codes, every 8-K on or before 2017-05-08

- 2017-02-07 0001144204-17-006515 — 2.02, 9.01
- 2016-12-13 0001144204-16-139204 — 5.07
- 2016-11-08 0001144204-16-132460 — 2.02, 9.01
- 2016-09-09 0001144204-16-123444 — 2.02, 9.01
- 2016-07-01 0001144204-16-111270 — 1.01
- 2016-05-10 0001144204-16-100142 — 2.02, 9.01
- 2015-12-14 0001144204-15-070760 — 5.07
- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2017-05-08

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-17-006515:8k_2_02:1]
EX-99.1
2
v458593_ex99-1.htm
EXHIBIT 99.1

[0001144204-17-006515:8k_2_02:2]
Exhibit 99.1

[0001144204-17-006515:8k_2_02:3]
NAPCO
Announces Results for the Second Quarter Ended December 31, 2016

[0001144204-17-006515:8k_2_02:4]
-Second Quarter Revenue a Record $20.7 Million
-

[0001144204-17-006515:8k_2_02:5]
- Recurring Revenues Grew 68%-

[0001144204-17-006515:8k_2_02:6]
-Management to Host Conference Call Today at 11 a.m. ET-

[0001144204-17-006515:8k_2_02:7]
AMITYVILLE, N.Y., February 6, 2017 -- NAPCO Security Technologies,
Inc. (NasdaqGS: NSSC), one of the world's leading solutions providers and manufacturers of high tech electronic intrusion security,
Internet of Things (IoT) connected home, video and fire systems, as well as enterprise-class access control and door locking products,
today announced financial results for its second fiscal quarter ended December 31,2016.

[0001144204-17-006515:8k_2_02:8]
Financial Highlights:

[0001144204-17-006515:8k_2_02:9]
|  | · | Net sales were $20.7 million, as compared to $20.5 million for the same quarter last year. |

[0001144204-17-006515:8k_2_02:10]
|  | · | Recurring monthly revenue (“RMR”) for the second quarter increased 68% compared to the same quarter a year ago and grew 14% sequentially. |

[0001144204-17-006515:8k_2_02:11]
|  | · | Gross margin for the second quarter increased to 31.9% as compared to 30.3% for the same quarter last year. |

[0001144204-17-006515:8k_2_02:12]
|  | · | Earnings per share (diluted) for the second quarter was $0.05 as compared to $0.05 for the same quarter last year. |

[0001144204-17-006515:8k_2_02:13]
Richard Soloway, Chairman and President said, “I am pleased
that quarterly revenue once again exceeded $20 million, which is the sales level where gross profit expansion and overhead absorption
begins to occur. We continue to build momentum for future growth, by focusing on vibrant markets, such as school security, IoT
and wireless alarm signal communicators, with an emphasis on products that deliver substantial recurring monthly revenue (RMR).
New product development initiatives are squarely aimed at increasing our portfolio of RMR building product entries, with four product
launches scheduled over the next six months in the (i) dual-path fire, (ii) IoT communicator, (iii) wireless video, and (iv) intrusion
alarm product segments.

[0001144204-17-006515:8k_2_02:14]
Mr. Soloway added, “ Demand
for our stable of integrated, cross-divisional product solutions for the school market, in the form of intrusion/fire alarms and
communicators, access control, electronic access control locks and architectural locking hardware, known as our Project LocDown™,
continues to grow. Also, our School Access-control Vulnerability Index (SAVI) and audit system continues to educate our dealers,
integrators and school officials in creating safe and secure schools. In one of our recent successes, NAPCO’s Continental
Access Control Division was chosen as the keyless access control system for all of the North East Independent School District of
San Antonio, which just received a bond for facility upgrades and improving security preparedness.”

[0001144204-17-006515:8k_2_02:15]
Mr. Soloway continued “Subscription-based recurring monthly
revenue continues to grow significantly, with a 68% increase versus Q2 a year-ago, fueled by the sales increases of our base StarLink®
3G/4G, Verizon CDMA and commercial fire and intrusion alarm communicators, as well as, iBridge® Connected Home products. Our
StarLink Fire and commercial communicators, launched in 2016, continue to see rapid growth and adoption by substantial dealers
and integrators across the country. Fiscal Q3 will witness the launch of our StarLink Dual-Path Fire Communicator, which will enable
us to expand our fire communicator business into major cities in the U.S., that require two methods of reporting fire alarms.”

[0001144204-17-006515:8k_2_02:16]
“Exhibited at the International Security Conference &
Exhibition East trade show, in November, StarLink Connect, met with widespread acceptance among security dealers. Launching this
March, StarLink Connect is a Verizon CDMA cellular communicator that can be easily installed to add a host of IoT, Connected Home
services to tens of millions of legacy and new alarm systems in the marketplace. This innovative product provides alarm dealers
with the ability to retrofit existing security installations to communicate alarm signals, as well as giving their customers the
power to remotely operate their security systems, lighting, locks, thermostats, and video cameras, from any smart device. StarLink
Connect will continue our rollout of new products which drive our Company’s recurring monthly revenue and vastly increases
our profitability.”

[0001144204-17-006515:8k_2_02:17]
Mr. Soloway concluded “Looking to the second half of our
fiscal 2017 and beyond, with its array of new product launches and considerable momentum, NAPCO is well-positioned for increased
sales and earnings for years to come.”

[0001144204-17-006515:8k_2_02:18]
Financial Results

[0001144204-17-006515:8k_2_02:19]
Net Sales for the three months ended December
31, 2016 increased to a record second quarter revenue of $20.7 million, as compared to $20.5 million for the same period one year
ago. Net sales for the six months ended December 31, 2016 increased to $40.9 million as compared to $38.6 million for the comparable
period last year, an increase of 6%. Selling, general and administrative expenses for the quarter were $5.6 million, or 26.8% of
sales, as compared to $5.2 million, or 25.3% of sales for the same period last year. Selling, general and administrative expenses
for the six months ended December 31, 2016 were $11.3 million or 27.6% of sales as compared to $10.5 million or 27.2% of sales
for the comparable period last year.

[0001144204-17-006515:8k_2_02:20]
Operating income for the three months ended December 31, 2016
increased to $1,064,000, as compared to $1,019,000 for the second quarter of fiscal 2016, an increase of 4%. Operating income for
the six months ended December 31, 2016 increased to $1.8 million as compared to $1.3 million for the same period a year ago, an
increase of 33%. Adjusted EBITDA* for the three months ended December 31, 2016 increased to $1.5 million, or $0.08 per diluted
share, as compared to $1.4 million, or $0.08 per diluted share, for the second quarter of fiscal 2016, an increase of 2%. Adjusted
EBITDA* for the six months ended December 31, 2016 increased to $2.5 million or $0.13 per diluted share as compared to $2.1 million
or $0.11 per diluted share for the same period last year, an increase of 19%. (*see table attached).

[0001144204-17-006515:8k_2_02:21]
Net income for the three months ended December 31, 2016 decreased
to $857,000, or $0.05 per diluted share, as compared to $976,000, or $0.05 per share, for the same quarter last year, a decrease
of 12%. Net income for the six months ended December 31, 2016 increased to $1.4 million or $0.08 per diluted share as compared
to $1.3 million or $0.07 per share for the same period a year ago, an increase of 10%.

[0001144204-17-006515:8k_2_02:22]
Balance Sheet Summary

[0001144204-17-006515:8k_2_02:23]
At December 31, 2016 and at June 30, 2016, the Company had $3.8
million in cash and cash equivalents. NAPCO had working capital of $35.3 million at December 31, 2016 as compared with working
capital of $36.9 million at June 30, 2016. Current ratio was 4.9:1 at December 31, 2016 and 5.1:1 at June 30, 2016.

[0001144204-17-006515:8k_2_02:24]
Conference Call Information

[0001144204-17-006515:8k_2_02:25]
Management will conduct a conference call at 11 a.m. ET today,
February 6, 2017. Interested parties may participate in the call by dialing 1-877-407-4018 or for international callers, 1-201-689-8471,
about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m.
ET on February 6, 2017 and ending on February 13, 2017 at 11:59 p.m. ET. For the replay, please dial 1-844-512-2921 domestically,
or 1-412-317-6671 for international callers, and use the replay access code 13654396. In addition, the call will be webcast and
will be available on the Company's website at www.napcosecurity.com.

[0001144204-17-006515:8k_2_02:26]
About NAPCO Security Technologies, Inc.

[0001144204-17-006515:8k_2_02:27]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security, including recurring revenue, connected home, video,
fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO,
its security and connected home segment, plus three wholly-owned subsidiaries: Alarm
Lock, Continental Instruments, and Marks USA.
Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in
commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for innovation,
technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic
security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-17-006515:8k_2_02:28]
Safe Harbor Statement

[0001144204-17-006515:8k_2_02:29]
This press release contains forward-looking statements that
involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated
in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the
Securities and Exchange Commission.

[0001144204-17-006515:8k_2_02:30]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-17-006515:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001144204-17-006515:8k_2_02:32]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,784 |  |  | $ | 3,805 |  |
| Accounts receivable, net of reserves and allowances |  |  | 16,267 |  |  |  | 19,012 |  |
| Inventories |  |  | 23,562 |  |  |  | 21,428 |  |
| Prepaid expenses and other current assets |  |  | 856 |  |  |  | 936 |  |
| Deferred income taxes |  |  | -- |  |  |  | 703 |  |
| Total Current Assets |  |  | 44,469 |  |  |  | 45,884 |  |
| Inventories - non-current |  |  | 4,144 |  |  |  | 3,909 |  |
| Deferred income taxes |  |  | 955 |  |  |  | 436 |  |
| Property, plant and equipment, net |  |  | 6,207 |  |  |  | 6,049 |  |
| Intangible assets, net |  |  | 8,137 |  |  |  | 8,357 |  |
| Other assets |  |  | 127 |  |  |  | 134 |  |
| TOTAL ASSETS |  | $ | 64,039 |  |  | $ | 64,769 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 300 |  |  | $ | 300 |  |
| Accounts payable |  |  | 4,777 |  |  |  | 4,328 |  |
| Accrued expenses |  |  | 1,699 |  |  |  | 1,893 |  |
| Accrued salaries and wages |  |  | 2,285 |  |  |  | 2,467 |  |
| Accrued income taxes |  |  | 84 |  |  |  | 8 |  |
| Total Current Liabilities |  |  | 9,145 |  |  |  | 8,996 |  |
| Long-term debt, net of current maturities |  |  | 2,050 |  |  |  | 4,500 |  |
| Total Liabilities |  |  | 11,195 |  |  |  | 13,496 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,131,732 and 21,116,743 shares issued; and 18,801,882 and 18,786,893 shares outstanding, respectively |  |  | 211 |  |  |  | 211 |  |
| Additional paid-in capital |  |  | 16,768 |  |  |  | 16,622 |  |
| Retained earnings |  |  | 47,597 |  |  |  | 46,172 |  |
|  |  |  | 64,576 |  |  |  | 63,005 |  |
| Less: Treasury Stock, at cost (2,329,850 shares) |  |  | (11,732 | ) |  |  | (11,732 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 52,844 |  |  |  | 51,273 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 64,039 |  |  | $ | 64,769 |  |

[0001144204-17-006515:8k_2_02:33]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-17-006515:8k_2_02:34]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME
(unaudited)

[0001144204-17-006515:8k_2_02:35]
|  |  | Three Months ended December 31, |  |  | Six Months ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Sales |  | $ | 20,715 |  |  | $ | 20,497 |  |  | $ | 40,883 |  |  | $ | 38,646 |  |
| Cost of sales |  |  | 14,098 |  |  |  | 14,296 |  |  |  | 27,814 |  |  |  | 26,808 |  |
| Gross Profit |  |  | 6,617 |  |  |  | 6,201 |  |  |  | 13,069 |  |  |  | 11,838 |  |
| Selling, general and administrative expenses |  |  | 5,553 |  |  |  | 5,182 |  |  |  | 11,289 |  |  |  | 10,495 |  |
| Operating income |  |  | 1,064 |  |  |  | 1,019 |  |  |  | 1,780 |  |  |  | 1,343 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest, net |  |  | 18 |  |  |  | 41 |  |  |  | 42 |  |  |  | 94 |  |
| Income before taxes |  |  | 1,046 |  |  |  | 978 |  |  |  | 1,738 |  |  |  | 1,249 |  |
| Income tax expense (benefit) |  |  | 189 |  |  |  | 2 |  |  |  | 313 |  |  |  | (42 | ) |
| Net income |  | $ | 857 |  |  | $ | 976 |  |  | $ | 1,425 |  |  | $ | 1,291 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.05 |  |  | $ | 0.08 |  |  | $ | 0.07 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 0.05 |  |  | $ | 0.08 |  |  | $ | 0.07 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,798,000 |  |  |  | 18,931,000 |  |  |  | 18,792,000 |  |  |  | 18,948,000 |  |
| Diluted |  |  | 18,851,000 |  |  |  | 18,957,000 |  |  |  | 18,844,000 |  |  |  | 18,971,000 |  |

[0001144204-17-006515:8k_2_02:36]
NAPCO SECURITY TECHNOLOGIES, INC.

[0001144204-17-006515:8k_2_02:37]
NON-GAAP MEASURES OF PERFORMANCE* (Unaudited)

[0001144204-17-006515:8k_2_02:38]
(in thousands)

[0001144204-17-006515:8k_2_02:39]
|  |  | Three months ended December 31, |  |  | Six months ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income (GAAP) |  | $ | 857 |  |  | $ | 976 |  |  | $ | 1,425 |  |  | $ | 1,291 |  |
| Add back provision (benefit) for income taxes |  |  | 189 |  |  |  | 2 |  |  |  | 313 |  |  |  | (42 | ) |
| Add back interest expense |  |  | 18 |  |  |  | 41 |  |  |  | 42 |  |  |  | 94 |  |
| Operating Income (GAAP) |  |  | 1,064 |  |  |  | 1,019 |  |  |  | 1,780 |  |  |  | 1,343 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 110 |  |  |  | 137 |  |  |  | 220 |  |  |  | 267 |  |
| Add back stock-based compensation expense |  |  | 65 |  |  |  | 60 |  |  |  | 98 |  |  |  | 92 |  |
| Adjusted non-GAAP operating income |  |  | 1,239 |  |  |  | 1,216 |  |  |  | 2,098 |  |  |  | 1,702 |  |
| Add back depreciation and other amortization |  |  | 217 |  |  |  | 207 |  |  |  | 429 |  |  |  | 421 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,456 |  |  | $ | 1,423 |  |  | $ | 2,527 |  |  | $ | 2,123 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | 0.13 |  |  | $ | 0.11 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,851,000 |  |  |  | 18,957,000 |  |  |  | 18,844,000 |  |  |  | 18,971,000 |  |

[0001144204-17-006515:8k_2_02:40]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-17-006515:8k_2_02:41]
Contacts:

[0001144204-17-006515:8k_2_02:42]
Patrick McKillop

[0001144204-17-006515:8k_2_02:43]
Director of Investor Relations

[0001144204-17-006515:8k_2_02:44]
NAPCO Security Technologies, Inc.

[0001144204-17-006515:8k_2_02:45]
OP: 800-645-9445 x 374

[0001144204-17-006515:8k_2_02:46]
CP: 516-404-3597

[0001144204-17-006515:8k_2_02:47]
pmckillop@napcosecurity.com
