# NSSC note change history — 0001144204-17-006227 → 0001144204-17-025269


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0001144204-17-025269:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $6,000 for the three months ended March 31, 2017 and 2016, respectively and $17,000 and $20,000 for the nine months ended March 31, 2017 and 2016, respectively.
  (was, 2017-02-06, similarity 0.8671):
[0001144204-17-006227:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $8,000 for the three months ended December 31, 2016 and 2015, respectively and $12,000 and $15,000 for the six months ended December 31, 2016 and 2015, respectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:2]
As of March 31, 2017, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $730,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.
  (was, 2017-02-06, similarity 0.9969):
[0001144204-17-006227:note_history:2]
As of December 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2017 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0001144204-17-025269:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2017 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt at March 31, 2017 in the amount of $3,500,000 approximates fair value.
  (was, 2017-02-06, similarity 0.9368):
[0001144204-17-006227:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2016 in the amount of $2,350,000 approximates fair value.

- changed (2017-05-08):
[0001144204-17-025269:note_history:4]
Cash and cash equivalents include approximately $461,000 of short-term time deposits at March 31, 2017 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2017 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits
  (was, 2017-02-06, similarity 0.9733):
[0001144204-17-006227:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2016 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2016 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2017-05-08):
[0001144204-17-025269:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of March 31, 2017 and June 30, 2016 and for returns and other allowances of $1,280,000 and $1,255,000 as of March 31, 2017 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.
  (was, 2017-02-06, similarity 0.9778):
[0001144204-17-006227:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of December 31, 2016 and June 30, 2016 and for returns and other allowances of $1,199,000 and $1,255,000 as of December 31, 2016 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.

- added (2017-05-08):
[0001144204-17-025269:note_history:6]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,674) |  | $ | 2,126 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,674) |  | $ | 8,026 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

- changed (2017-05-08):
[0001144204-17-025269:note_history:7]
Amortization expense for intangible assets subject to amortization was approximately $111,000 and $131,000 for the three months ended March 31, 2017 and 2016, respectively. Amortization expense for intangible assets subject to amortization was approximately $331,000 and $398,000 for the nine months ended March 31, 2017 and 2016, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.3 years and  12.3 years at March 31, 2017 and 2016, respectively.
  (was, 2017-02-06, similarity 0.9342):
[0001144204-17-006227:note_history:7]
Amortization expense for intangible assets subject to amortization was approximately $110,000 and $131,000 for the three months ended December 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $220,000 and $268,000 for the six months ended December 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.6 years and  12.6 years at December 31, 2016 and 2015, respectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2017 and 2016, respectively.
  (was, 2017-02-06, similarity 0.9612):
[0001144204-17-006227:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2016 and 2015, respectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:9]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2017 and 2016 was $365,000 and $259,000, respectively. Advertising expense for the nine months ended March 31, 2017 and 2016 was $1,537,000 and $1,328,000, respectively.
  (was, 2017-02-06, similarity 0.914):
[0001144204-17-006227:note_history:9]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2016 and 2015 was $498,000 and $510,000, respectively. Advertising expense for the six months ended December 31, 2016 and 2015 was $1,172,000 and $1,068,000, respectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2017 and 2016 was $1,698,000 and $1,513,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2017 and 2016 was $4,935,000 and $4,521,000, respectively.
  (was, 2017-02-06, similarity 0.9268):
[0001144204-17-006227:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2016 and 2015 was $1,609,000 and $1,519,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2016 and 2015 was $3,237,000 and $3,008,000, respectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):
  (was, 2017-02-06, similarity 0.9738):
[0001144204-17-006227:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

- changed (2017-05-08):
[0001144204-17-025269:note_history:12]
Options to  purchase  0 and  166,000 shares of common stock for the three months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2017-02-06, similarity 0.9771):
[0001144204-17-006227:note_history:12]
Options to purchase  5,000 and  106,000 shares of common stock for the three months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2017-05-08):
[0001144204-17-025269:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):
  (was, 2017-02-06, similarity 0.9588):
[0001144204-17-006227:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- changed (2017-05-08):
[0001144204-17-025269:note_history:14]
Options to  purchase  0 and  147,000 shares of common stock for the nine months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2017-02-06, similarity 0.9149):
[0001144204-17-006227:note_history:14]
Options to purchase  5,000 and  137,750 shares of common stock for the six months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2017-05-08):
[0001144204-17-025269:note_history:15]
No stock-based compensation costs were recognized for three months ended March 31, 2017 or 2016. Stock-based compensation costs of $97,000 and $92,000 were recognized for nine months ended March 31, 2017 and 2016, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended March 31, 2017 and 2016. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the nine months ended March 31, 2017 and 2016.

- changed (2017-05-08):
[0001144204-17-025269:note_history:16]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2017 and 2016.
  (was, 2017-02-06, similarity 0.9442):
[0001144204-17-006227:note_history:16]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2016 and 2015.

- changed (2017-05-08):
[0001144204-17-025269:note_history:17]
For the three and nine months ended March 31, 2017 and 2016, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.
  (was, 2017-02-06, similarity 0.9197):
[0001144204-17-006227:note_history:17]
For the three and six months ended December 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2017-05-08):
[0001144204-17-025269:note_history:18]
The Company records the amount billed to customers for shipping and handling in net sales ($104,000 and $109,000 in the three months ended March 31, 2017 and 2016, respectively and $349,000 and $365,000 in the nine months ended March 31, 2017 and 2016, respectively) and classifies the costs associated with these revenues in cost of sales ($250,000 and $232,000 in the three months ended March 31, 2017 and 2016, respectively and $683,000 and $673,000 in the nine months ended March 31, 2017 and 2016, respectively).
  (was, 2017-02-06, similarity 0.8607):
[0001144204-17-006227:note_history:18]
The Company records the amount billed to customers for shipping and handling in net sales ($105,000 and $125,000 in the three months ended December 31, 2016 and 2015, respectively and $245,000 and $256,000 in the six months ended December 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($217,000 and $225,000 in the three months ended December 31, 2016 and 2015, respectively and $433,000 and $441,000 in the six months ended December 31, 2016 and 2015, respectively).

- changed (2017-05-08):
[0001144204-17-025269:note_history:19]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively. Prior periods were not retrospectively adjusted.
  (was, 2017-02-06, similarity 0.9674):
[0001144204-17-006227:note_history:19]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively.

- changed (2017-05-08):
[0001144204-17-025269:note_history:20]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.
  (was, 2017-02-06, similarity 0.982):
[0001144204-17-006227:note_history:20]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements. Prior periods were not retrospectively adjusted.

- removed (2017-05-08):
[0001144204-17-006227:note_history:21]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,563) |  | $ | 2,237 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,563) |  | $ | 8,137 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

- removed (2017-05-08):
[0001144204-17-006227:note_history:22]
Stock-based compensation costs of $65,000 and $60,000 were recognized for three months ended December 31, 2016 and 2015, respectively. Stock-based compensation costs of $98,000 and $92,000 were recognized for six months ended December 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2016 and 2015.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-05-08):
[0001144204-17-025269:note_history:23]
As of March 31, 2017, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021. The term loan has been repaid in full as of March 31, 2017.

- changed (2017-05-08):
[0001144204-17-025269:note_history:24]
Outstanding balances and interest rates as of March 31, 2017 and June 30, 2016 are as follows:
  (was, 2017-02-06, similarity 0.9474):
[0001144204-17-006227:note_history:24]
Outstanding balances and interest rates as of December 31, 2016 and June 30, 2016 are as follows:

- changed (2017-05-08):
[0001144204-17-025269:note_history:25]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.1 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | — |  |  | — |  |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,500 |  |  | 2.1 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2017-02-06, similarity 0.9389):
[0001144204-17-006227:note_history:25]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | 350 |  |  | 1.8 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 2,350 |  |  | 1.9 | % | $ | 4,800 |  |  | 1.6 | % |

- changed (2017-05-08):
[0001144204-17-025269:note_history:26]
The Revolving Credit Facility (the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.15% to  2.00%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.
  (was, 2017-02-06, similarity 0.9896):
[0001144204-17-006227:note_history:26]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.15% to  2.00%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

- changed (2017-05-08):
[0001144204-17-025269:note_history:27]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.
  (was, 2017-02-06, similarity 0.9978):
[0001144204-17-006227:note_history:27]
The Agreements contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.

- removed (2017-05-08):
[0001144204-17-006227:note_history:28]
As of December 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 and one term loan which expires in June 2019 (the “Term Loan”). The term loan, which was originally for $6,000,000, is being repaid with 28 equal, quarterly payments of $75,000 which commenced on September 30, 2012, plus any additional payments made at the Company’s discretion with the remaining balance due on or before the expiration date.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0001144204-17-025269:note_history:29]
Outstanding balances and interest rates as of March 31, 2017 and June 30, 2016 are as follows:
  (was, 2017-02-06, similarity 0.9474):
[0001144204-17-006227:note_history:29]
Outstanding balances and interest rates as of December 31, 2016 and June 30, 2016 are as follows:

- changed (2017-05-08):
[0001144204-17-025269:note_history:30]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.1 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | — |  |  | — |  |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,500 |  |  | 2.1 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2017-02-06, similarity 0.9389):
[0001144204-17-006227:note_history:30]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | 350 |  |  | 1.8 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 2,350 |  |  | 1.9 | % | $ | 4,800 |  |  | 1.6 | % |
