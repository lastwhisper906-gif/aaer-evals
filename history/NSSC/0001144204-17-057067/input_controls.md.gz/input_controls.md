# NSSC 10-Q controls and the auditor's report


## item_4_controls

[0001144204-17-057067:item_4_controls:1]
ITEM 4: Controls and Procedures

[0001144204-17-057067:item_4_controls:2]
We maintain disclosure controls and procedures
that are designed to ensure that information required to be disclosed in our Exchange Act reports is recorded, processed, summarized
and reported within the time periods specified in the SEC's rules and forms, and that such information is accumulated and communicated
to our management to allow timely decisions regarding required disclosure. Management necessarily applied its judgment in assessing
the costs and benefits of such controls and procedures, which, by their nature, can provide only reasonable assurance regarding
management's control objectives.

[0001144204-17-057067:item_4_controls:3]
At the conclusion of the period ended September
30, 2017, we carried out an evaluation, under the supervision and with the participation of our management, including our Chief
Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and
procedures. As disclosed in our Annual Report on Form 10-K for the year ended June 30, 2017, we did not have effective disclosure
controls and procedures as of June 30, 2017 and also as of September 30, 2017.

[0001144204-17-057067:item_4_controls:4]
Management's review over its internal controls at the conclusion
of fiscal 2017 identified conditions which they deemed to be material weaknesses, (as defined by standards established by the SEC
and the Public Company Accounting Oversight Board): 1. The documentation of a key review control over product shipments was not
designed properly to evidence the operating effectiveness of the control, and a portion of the Company’s shipments were not
subjected to this review control due to in-process consolidation of warehouse operations. 2. Controls around subscription-based
service revenue were not assessed at the transaction level because they are largely automated, but subjected only to management-level
reasonableness review. 3. Management’s reviews of price lists and pricing discounts are not formally documented on a consistent
basis, and 4. Review of system-based pricing for certain products and services was not performed to correct data entry errors,
although no significant errors were detected. Management is currently designing and implementing additional controls and procedures
to remediate these items and expects to complete these actions during fiscal 2018. These include, but are not limited to, retaining
a different third-party consulting firm to assist in the evaluation and review of the Company’s internal controls.

[0001144204-17-057067:item_4_controls:5]
During the three months ended September 30, 2017, there were
no changes in the Company's internal controls over financial reporting that have materially affected, or are reasonably likely
to materially affect, the Company's internal controls over financial reporting.
