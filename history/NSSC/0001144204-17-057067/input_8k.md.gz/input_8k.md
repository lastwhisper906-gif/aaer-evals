# NSSC 8-K — 0001144204-17-057073 filed 2017-11-08

## item codes, every 8-K on or before 2017-11-08

- 2017-11-08 0001144204-17-057073 — 2.02, 9.01
- 2017-09-11 0001144204-17-047471 — 2.02, 9.01
- 2017-05-09 0001144204-17-025659 — 2.02, 9.01
- 2017-02-07 0001144204-17-006515 — 2.02, 9.01
- 2016-12-13 0001144204-16-139204 — 5.07
- 2016-11-08 0001144204-16-132460 — 2.02, 9.01
- 2016-09-09 0001144204-16-123444 — 2.02, 9.01
- 2016-07-01 0001144204-16-111270 — 1.01
- 2016-05-10 0001144204-16-100142 — 2.02, 9.01
- 2015-12-14 0001144204-15-070760 — 5.07
- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2017-11-08

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-17-057073:8k_2_02:1]
EX-99.1
2
tv478840_ex99-1.htm
EXHIBIT 99.1

[0001144204-17-057073:8k_2_02:2]
Exhibit 99.1

[0001144204-17-057073:8k_2_02:3]
NAPCO Announces First Quarter 2018 Results

[0001144204-17-057073:8k_2_02:4]
- Sales Increase 5% to a First Quarter Record
of $21.2 Million-

[0001144204-17-057073:8k_2_02:5]
-Recurring Revenues Grew 56% for the Quarter-

[0001144204-17-057073:8k_2_02:6]
-Earnings per Share increases to $0.05 from
$0.03-

[0001144204-17-057073:8k_2_02:7]
--Management to Host Conference Call Today
at 11 a.m. ET-

[0001144204-17-057073:8k_2_02:8]
AMITYVILLE, N.Y., November 6, 2017 -- NAPCO Security Technologies,
Inc. (NasdaqGS: NSSC), one of the world's leading solutions providers and manufacturers of high tech electronic intrusion security,
Internet of Things (IoT) connected home, video and fire systems, as well as enterprise-class access control and door locking products,
today announced financial results for its first fiscal quarter ended September 30, 2017.

[0001144204-17-057073:8k_2_02:9]
Financial Highlights:

[0001144204-17-057073:8k_2_02:10]
|  | · | Net sales for the quarter were a record $21.2 million, up 5% from the same quarter last year. |

[0001144204-17-057073:8k_2_02:11]
|  | · | Recurring revenue for the quarter (which are included in net sales) increased 56% and now has a prospective annual run rate of $10.6 million based on September 2017 recurring revenue.** |

[0001144204-17-057073:8k_2_02:12]
|  | · | Income before taxes for the quarter 2017 increased 49% to $1,033,000 from $692,000 a year ago. |

[0001144204-17-057073:8k_2_02:13]
|  | · | Earnings per share (diluted) for the quarter was $0.05, as compared to $0.03 for the same period a year ago. |

[0001144204-17-057073:8k_2_02:14]
Richard Soloway, Chairman and President commented, “We
are pleased that our Q1 Fiscal 2018 performance continued a string of 13 consecutive quarters of increased sales growth for our
Company. The investments we have made in sales, marketing and engineering continue to provide a solid foundation for steady, consistent
growth in sales and profitability and bode well for a strong future for NAPCO.”

[0001144204-17-057073:8k_2_02:15]
“As a leader in the wireless cellular alarm and IoT communicator
category, our expansive, unique StarLink® line of solutions continues to build market share providing us with a 56% increase
in subscription-based, recurring revenue for this quarter. Capitalizing on the recent need for millions of landline-connected fire
alarm control panels to upgrade to wireless, cellular or cellular/IP based communications technology, StarLink Fire® communicators,
with their unique Panel-Powered Technology®, continue to generate tremendous interest. With the launch in June, 2017, of our
dual-path fire communicator, needed by code in several municipalities across the U.S., StarLink now markets the most extensive
and feature-rich line of commercial intrusion and fire communicator products in the industry.”

[0001144204-17-057073:8k_2_02:16]
Mr. Soloway continued “Our award-winning StarLink Connect®
solution, which gives dealers the ability to add Smart Home services to millions of regular, existing alarm installations across
the country, is experiencing broad market acceptance and beginning to build market share. This RMR-generating, subscription-based
service offers residential consumers the ability to use an app to remotely operate their security systems, lighting, locks, thermostats,
and video cameras, from any smart device. StarLink Connect also, importantly, offers our dealers the opportunity to increase the
recurring monthly income stream from their customers, by trading them up from a regular alarm system to Smart Home services, adding
value to their account base.”

[0001144204-17-057073:8k_2_02:17]
“Our high-margin commercial Divisions Alarm Lock Access
Control Locks, Marks Architectural Hardware and Continental Enterprise-Class Access Control, continued to show a significant increase
in market presence in the Education market vertical. With a strong array of integrated, school venue designed security solutions,
along with the administering of the highly successful SAVI or School Access-control Vulnerability Index and auditing system, NAPCO
continues to lead the way in fortifying and augmenting school security levels. NAPCO dealers and integrators are trained in systematically
evaluating any school facility’s security level and then addressing any deficiency with school-specific security solutions.
This approach and portfolio of product solutions is also increasingly being used in any public venues, in addition to educational
facilities, concerned with addressing the growing threat of terrorist activities and active-shooter events.”

[0001144204-17-057073:8k_2_02:18]
Mr. Soloway concluded, “We are confident that we are on
track to consistently increase our sales and profits and we believe that our sales, marketing and engineering investments will
continue to pay dividends in future accelerated growth. All indicators and trends seem positive and we look forward to having an
exceptional fiscal year 2018.”

[0001144204-17-057073:8k_2_02:19]
Financial Results

[0001144204-17-057073:8k_2_02:20]
Net Sales for the three months ended September
30, 2017 increased to a record $21.2 million, as compared to $20.2 million for the same period one year ago, an increase of 5%.
Selling, general and administrative expenses for the quarter were $5.8 million, or 27.5% of sales, as compared to $5.7 million,
or 28.4% of sales for the same period last year.

[0001144204-17-057073:8k_2_02:21]
Operating income for the three months ended September 30, 2017
was $1,059,000, as compared to $716,000 for the same period a year ago, an increase of 48%. Adjusted EBITDA* for the three months
ended September 30, 2017 was $1.4 million, or $0.08 per diluted share, as compared to $1.1 million, or $0.06 per diluted share
an increase of 33%.

[0001144204-17-057073:8k_2_02:22]
Net income for the three months ended September 30, 2017 was
$890,000, or $0.05 per diluted share, as compared to $568,000, or $0.03 per share, for the same quarter last year, an increase
of 57%.

[0001144204-17-057073:8k_2_02:23]
Balance Sheet Summary

[0001144204-17-057073:8k_2_02:24]
At September 30, 2017, the Company had $4.5 million in cash
and cash equivalents as compared to $3.5 million as of June 30, 2017. NAPCO had working capital of $41.2 million at September 30,
2017 as compared with working capital of $40.8 million at June 30, 2017. Current ratio was 5.9:1 at September 30, 2017 and 4.9:1
at June 30, 2017.

[0001144204-17-057073:8k_2_02:25]
Conference Call Information

[0001144204-17-057073:8k_2_02:26]
Management will conduct a conference call at 11 a.m. ET today,
November 6, 2017. Interested parties may participate in the call by dialing 1-877-407-4018 or for international callers, 1-201-689-8471,
about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m.
ET on November 6, 2017 and ending on November 13, 2017 at 11:59 p.m. ET. For the replay, please dial 1-844-512-2921 domestically,
or 1-412-317-6671 for international callers, and use the replay access code 13673027. In addition, the call will be webcast and
will be available on the Company's website at www.napcosecurity.com.

[0001144204-17-057073:8k_2_02:27]
About NAPCO Security Technologies, Inc.

[0001144204-17-057073:8k_2_02:28]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security, including recurring revenue, connected home, video,
fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and
connected home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks
USA. Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide
in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for innovation,
technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic
security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-17-057073:8k_2_02:29]
Safe Harbor Statement

[0001144204-17-057073:8k_2_02:30]
**This press release contains forward-looking statements
that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those
anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings
with the Securities and Exchange Commission.

[0001144204-17-057073:8k_2_02:31]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,453 |  |  | $ | 3,454 |  |
| Accounts receivable, net of allowance for doubtful accounts of $175 and $155 at September 30, 2017 and June 30, 2017, respectively, and other reserves |  |  | 17,746 |  |  |  | 20,275 |  |
| Inventories |  |  | 26,284 |  |  |  | 26,212 |  |
| Prepaid expenses and other current assets |  |  | 1,130 |  |  |  | 1,330 |  |
| Total Current Assets |  |  | 49,613 |  |  |  | 51,271 |  |
| Inventories - non-current |  |  | 4,854 |  |  |  | 4,367 |  |
| Deferred income taxes |  |  | 484 |  |  |  | 644 |  |
| Property, plant and equipment, net |  |  | 6,820 |  |  |  | 6,543 |  |
| Intangible assets, net |  |  | 7,823 |  |  |  | 7,916 |  |
| Other assets |  |  | 151 |  |  |  | 121 |  |
| TOTAL ASSETS |  | $ | 69,745 |  |  | $ | 70,862 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 4,306 |  |  | $ | 5,653 |  |
| Accrued expenses |  |  | 1,941 |  |  |  | 2,209 |  |
| Accrued salaries and wages |  |  | 2,086 |  |  |  | 2,322 |  |
| Accrued income taxes |  |  | 88 |  |  |  | 289 |  |
| Total Current Liabilities |  |  | 8,421 |  |  |  | 10,473 |  |
| Long-term debt, net of current maturities |  |  | 3,500 |  |  |  | 3,500 |  |
| Total Liabilities |  |  | 11,921 |  |  |  | 13,973 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,178,692 and 21,174,507 shares issued; and 18,848,842 and 18,844,657 shares outstanding, respectively |  |  | 212 |  |  |  | 212 |  |
| Additional paid-in capital |  |  | 16,683 |  |  |  | 16,638 |  |
| Retained earnings |  |  | 52,661 |  |  |  | 51,771 |  |
|  |  |  | 69,556 |  |  |  | 68,621 |  |
| Less: Treasury Stock, at cost (2,329,850 shares) |  |  | (11,732 | ) |  |  | (11,732 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 57,824 |  |  |  | 56,889 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 69,745 |  |  | $ | 70,862 |  |

[0001144204-17-057073:8k_2_02:32]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME (unaudited) |

[0001144204-17-057073:8k_2_02:33]
|  |  | Three months ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 21,174 |  |  | $ | 20,168 |  |
| Cost of sales |  |  | 14,295 |  |  |  | 13,716 |  |
| Gross Profit |  |  | 6,879 |  |  |  | 6,452 |  |
| Selling, general, and administrative expenses |  |  | 5,820 |  |  |  | 5,736 |  |
| Operating Income |  |  | 1,059 |  |  |  | 716 |  |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest, net |  |  | 26 |  |  |  | 24 |  |
| Income before Income Taxes |  |  | 1,033 |  |  |  | 692 |  |
| Income tax expense |  |  | 143 |  |  |  | 124 |  |
| Net Income |  | $ | 890 |  |  | $ | 568 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.03 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 0.03 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,846,000 |  |  |  | 18,787,000 |  |
| Diluted |  |  | 18,879,000 |  |  |  | 18,838,000 |  |

[0001144204-17-057073:8k_2_02:34]
| NAPCO SECURITY TECHNOLOGIES, INC. |
| NON-GAAP MEASURES OF PERFORMANCE* (Unaudited) |
| (in thousands) |

[0001144204-17-057073:8k_2_02:35]
|  |  | 3 months ended September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Net income (GAAP) |  | $ | 890 |  |  | $ | 568 |  |
| Add back provision for income taxes |  |  | 143 |  |  |  | 124 |  |
| Add back interest expense |  |  | 26 |  |  |  | 24 |  |
| Operating Income (GAAP) |  |  | 1,059 |  |  |  | 716 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 93 |  |  |  | 110 |  |
| Add back stock-based compensation expense |  |  | 33 |  |  |  | 33 |  |
| Adjusted non-GAAP operating income |  |  | 1,185 |  |  |  | 859 |  |
| Add back depreciation and other amortization |  |  | 237 |  |  |  | 212 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,422 |  |  | $ | 1,071 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.08 |  |  | $ | 0.06 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,879,000 |  |  |  | 18,838,000 |  |

[0001144204-17-057073:8k_2_02:36]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-17-057073:8k_2_02:37]
Contacts:

[0001144204-17-057073:8k_2_02:38]
Patrick McKillop

[0001144204-17-057073:8k_2_02:39]
Director of Investor Relations

[0001144204-17-057073:8k_2_02:40]
NAPCO Security Technologies, Inc.

[0001144204-17-057073:8k_2_02:41]
OP: 800-645-9445 x 374

[0001144204-17-057073:8k_2_02:42]
CP: 516-404-3597

[0001144204-17-057073:8k_2_02:43]
pmckillop@napcosecurity.com
