# NSSC notes — 0001144204-17-057067


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-057067:notes:1]
[same as prior period, unchanged from 0001144204-17-025269:notes:67]

[0001144204-17-057067:notes:2]
[same as prior period, unchanged from 0001144204-17-025269:notes:68]

[0001144204-17-057067:notes:3]
[same as prior period, unchanged from 0001144204-17-025269:notes:69]

[0001144204-17-057067:notes:4]
|  |  | Three months ended September 30, |  |
|  |  | 2017 |  | 2016 |  |
|  |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |
| Domestic |  | $ | 20,652 |  | $ | 19,493 |  |
| Foreign |  |  | 522 |  |  | 675 |  |
| Total Net Sales |  | $ | 21,174 |  | $ | 20,168 |  |

[0001144204-17-057067:notes:5]
|  |  | September 30, |  | June 30, |  |
| Identifiable assets: |  | 2017 |  | 2017 |  |
| United States |  | $ | 51,595 |  | $ | 55,550 |  |
| Dominican Republic (2) |  |  | 18,150 |  |  | 15,312 |  |
| Total Identifiable Assets |  | $ | 69,745 |  | $ | 70,862 |  |

[0001144204-17-057067:notes:6]
[same as prior period, unchanged from 0001144204-17-025269:notes:72]

[0001144204-17-057067:notes:7]
(2) Consists primarily of inventories (September 30, 2017 = $14,500, June 30, 2017 = $11,831) and long-lived assets (September 30, 2017 = $3,413, June 30, 2017 = $3,233) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-17-057067:notes:8]
NOTE 10 - Commitments and Contingencies

[0001144204-17-057067:notes:9]
Leases

[0001144204-17-057067:notes:10]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2019.

[0001144204-17-057067:notes:11]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 for each of the three months ended September 30, 2017 and 2016, respectively.

[0001144204-17-057067:notes:12]
Land Lease

[0001144204-17-057067:notes:13]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-17-057067:notes:14]
Litigation

[0001144204-17-057067:notes:15]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-17-057067:notes:16]
Employment Agreements

[0001144204-17-057067:notes:17]
As of September 30, 2017, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $730,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $324,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $293,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-057067:notes:18]
[same as prior period, unchanged from 0001144204-17-025269:notes:84]

[0001144204-17-057067:notes:19]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $31,000 and $28,000 for the three months ended September 30, 2017 and 2016, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-057067:notes:20]
NOTE 8 - Stockholders’ Equity Transactions

[0001144204-17-057067:notes:21]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to  1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. No shares were purchased under this plan during the three months ended September 30, 2017.


## us-gaap:LongTermDebtTextBlock

[0001144204-17-057067:notes:22]
NOTE 6 - Long-Term Debt

[0001144204-17-057067:notes:23]
As of September 30, 2017, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021.

[0001144204-17-057067:notes:24]
Outstanding balances and interest rates as of September 30, 2017 and June 30, 2017 are as follows (dollars in thousands):

[0001144204-17-057067:notes:25]
|  |  | September 30, 2017 |  | June 30, 2017 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.4 | % | $ | 3,500 |  |  | 2.2 | % |

[0001144204-17-057067:notes:26]
The Revolving Credit Facility (the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.15% to  2.00%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-17-057067:notes:27]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-057067:notes:28]
[same as prior period, unchanged from 0001144204-17-025269:notes:126]

[0001144204-17-057067:notes:29]
[same as prior period, unchanged from 0001144204-17-025269:notes:127]

[0001144204-17-057067:notes:30]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of September 30, 2017 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2014 and thereafter.

[0001144204-17-057067:notes:31]
[same as prior period, unchanged from 0001144204-17-025269:notes:129]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-17-057067:notes:32]
NOTE 4 - Property, Plant and Equipment

[0001144204-17-057067:notes:33]
Property, plant and equipment consist of the following (in thousands):

[0001144204-17-057067:notes:34]
|  |  | September 30, |  | June 30, |  |  |  |
|  |  | 2017 |  | 2017 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | -- |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 7,169 |  |  | 7,058 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,596 |  |  | 2,570 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 22,430 |  |  | 22,183 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 615 |  |  | 485 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 42,625 |  |  | 42,111 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | (35,805) |  |  | (35,568) |  |  |  |
|  |  | $ | 6,820 |  | $ | 6,543 |  |  |  |

[0001144204-17-057067:notes:35]
Depreciation and amortization expense on property, plant, and equipment was $237,000 and $195,000 for the three months ended September 30, 2017 and 2016, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-057067:notes:36]
[same as prior period, unchanged from 0001144204-17-025269:notes:88]

[0001144204-17-057067:notes:37]
The Company follows Accounting Standards Codification (“ASC”) 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  The Company recorded non-cash compensation expense relating to stock-based compensation of $33,000 for each of the three months ended September 30, 2017 and 2016 ($0.00 per basic and diluted share for each period).

[0001144204-17-057067:notes:38]
[same as prior period, unchanged from 0001144204-17-025269:notes:90]

[0001144204-17-057067:notes:39]
[same as prior period, unchanged from 0001144204-17-025269:notes:91]

[0001144204-17-057067:notes:40]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2017,  70,600 stock options were granted,  41,700 stock options were exercisable and  843,900 stock options were available for grant under this plan.

[0001144204-17-057067:notes:41]
The following table reflects activity under the 2012 Plan for the three months ended September 30,:

[0001144204-17-057067:notes:42]
|  |  | 2017 |  | 2016 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 70,600 |  | $ | 5.84 |  |  | 112,500 |  | $ | 5.54 |  |
| Granted |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Exercised |  |  | (2,000) |  |  | 6.31 |  |  | -- |  |  | -- |  |
| Outstanding, end of period |  |  | 68,600 |  | $ | 5.82 |  |  | 112,500 |  | $ | 5.54 |  |
| Exercisable, end of period |  |  | 41,700 |  | $ | 5.86 |  |  | 60,700 |  | $ | 5.55 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 6,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 245,000 |  |  |  |  | $ | 186,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 148,000 |  |  |  |  | $ | 100,000 |  |  |  |  |

[0001144204-17-057067:notes:43]
2,000 and 0 stock options were exercised during the three months ended September 30, 2017 and 2016, respectively. $13,000 and $0 was received from option exercises during the three months ended September 30, 2017 and 2016, respectively, and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-057067:notes:44]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at September 30, 2017:

[0001144204-17-057067:notes:45]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  |  |  |  |  |  |  |
| Range of |  | Number |  | remaining |  | Weighted average |  | Number |  | Weighted average |  |
| exercise prices |  | outstanding |  | contractual life |  | exercise price |  | exercisable |  | exercise price |  |
| $4.29-$8.15 |  |  | 68,600 |  |  | 7.0 |  | $ | 5.82 |  |  | 41,700 |  | $ | 5.86 |  |
|  |  |  | 68,600 |  |  | 7.0 |  | $ | 5.82 |  |  | 41,700 |  | $ | 5.86 |  |

[0001144204-17-057067:notes:46]
As of September 30, 2017, there was $102,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during either of the three months ended September 30, 2017 or 2016. The total fair value of the options vesting during each of the three months ended September 30, 2017 and 2016 under this plan was $16,000.

[0001144204-17-057067:notes:47]
[same as prior period, unchanged from 0001144204-17-025269:notes:99]

[0001144204-17-057067:notes:48]
[same as prior period, unchanged from 0001144204-17-025269:notes:100]

[0001144204-17-057067:notes:49]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2017,  14,200 stock options were granted,  10,200 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-17-057067:notes:50]
The following table reflects activity under the 2012 Non-Employee Plan for the three months ended September 30,:

[0001144204-17-057067:notes:51]
|  |  | 2017 |  | 2016 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 14,200 |  | $ | 4.69 |  |  | 35,000 |  | $ | 4.73 |  |
| Granted |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Exercised |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Outstanding, end of period |  |  | 14,200 |  | $ | 4.69 |  |  | 35,000 |  | $ | 4.73 |  |
| Exercisable, end of period |  |  | 10,200 |  | $ | 4.82 |  |  | 24,000 |  | $ | 4.80 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 67,000 |  |  |  |  | $ | 86,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 47,000 |  |  |  |  | $ | 57,000 |  |  |  |  |

[0001144204-17-057067:notes:52]
No stock options were exercised during the three months ended September 30, 2017 and 2016, respectively. No cash was received from option exercises during the three months ended September 30, 2017 and 2016 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-057067:notes:53]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at September 30, 2017:

[0001144204-17-057067:notes:54]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  |  |  |  |  |  |  |
| Range of |  | Number |  | remaining |  | Weighted average |  | Number |  | Weighted average |  |
| exercise prices |  | outstanding |  | contractual life |  | exercise price |  | exercisable |  | exercise price |  |
| $4.37 - $4.88 |  |  | 14,200 |  |  | 6.6 |  | $ | 4.69 |  |  | 10,200 |  | $ | 4.82 |  |
|  |  |  | 14,200 |  |  | 6.6 |  | $ | 4.69 |  |  | 10,200 |  | $ | 4.82 |  |

[0001144204-17-057067:notes:55]
As of September 30, 2017, there was $12,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three months ended September 30, 2017. The total fair value of the options vesting during the three months ended September 30, 2017 and 2016 under this plan was $17,000 and $16,000, respectively.

[0001144204-17-057067:notes:56]
[same as prior period, unchanged from 0001144204-17-025269:notes:108]

[0001144204-17-057067:notes:57]
In December 2002, the stockholders approved the 2002 Employee Stock Option Plan (the 2002 Employee Plan). This plan expired in October 2012. This plan authorized the granting of awards, the exercise of which would allow up to an aggregate of  1,836,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may have granted stock options, which were intended to qualify as incentive stock options (ISOs), to key employees.  Any plan participant who was granted ISOs and possessed more than 10% of the voting rights of the Company's outstanding common stock  must have been granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-17-057067:notes:58]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At September 30, 2017,  1,471,480 stock options had been granted and no stock options were exercisable. No further stock options were available for grant under this plan after the plan’s expiration in October 2012.

[0001144204-17-057067:notes:59]
The following table reflects activity under the 2002 Employee plan for the three months ended September 30,:

[0001144204-17-057067:notes:60]
|  |  | 2017 |  | 2016 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 5,000 |  | $ | 5.35 |  |  | 102,500 |  | $ | 6.86 |  |
| Granted |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Exercised |  |  | (5,000) |  |  | 5.35 |  |  | -- |  |  | -- |  |
| Outstanding, end of period |  |  | -- |  | $ | -- |  |  | 102,500 |  | $ | 6.86 |  |
| Exercisable, end of period |  |  | -- |  | $ | -- |  |  | 102,500 |  | $ | 6.86 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 20,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  |  | n/a |  |  |  |  | $ | 118,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  |  | n/a |  |  |  |  | $ | 118,000 |  |  |  |  |

[0001144204-17-057067:notes:61]
5,000 and 0 stock options were exercised during the three months ended September 30, 2017 and 2016, respectively. The 5,000 exercises were settled in cashless exercises by exchanging  2,815 shares of the Company’s common stock which were retired and returned to unissued status. No cash was received from option exercises during either of the three months ended September 30, 2017 and 2016 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-057067:notes:62]
[same as prior period, unchanged from 0001144204-17-025269:notes:118]

[0001144204-17-057067:notes:63]
Inventories, net of reserves are valued at lower of cost (first-in, first-out method) or NRV. The Company regularly reviews parts and finished goods inventories on hand and, when necessary, records a provision for excess or obsolete inventories. The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001144204-17-057067:notes:64]
[same as prior period, unchanged from 0001144204-17-025269:notes:120]

[0001144204-17-057067:notes:65]
|  |  | September 30, |  | June 30, |  |
|  |  | 2017 |  | 2017 |  |
| Component parts |  | $ | 16,942 |  | $ | 16,638 |  |
| Work-in-process |  |  | 4,496 |  |  | 4,415 |  |
| Finished product |  |  | 9,700 |  |  | 9,526 |  |
|  |  | $ | 31,138 |  | $ | 30,579 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 26,284 |  | $ | 26,212 |  |
| Non-current |  |  | 4,854 |  |  | 4,367 |  |
|  |  | $ | 31,138 |  | $ | 30,579 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-17-057067:notes:66]
[same as prior period, unchanged from 0001144204-17-025269:notes:116]

[0001144204-17-057067:notes:67]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  22% and  24% of the Company’s accounts receivable at September 30, 2017 and June 30, 2017 respectively. Sales to this customer comprised  11% and  14% of net sales in the three months ended September 30, 2017 and 2016, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001144204-17-057067:notes:68]
Principles of Consolidation

[0001144204-17-057067:notes:69]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2017 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 13, 2017. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All significant inter-company accounts and transactions have been eliminated.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-17-057067:notes:70]
Cash and Cash Equivalents

[0001144204-17-057067:notes:71]
Cash and cash equivalents include approximately $460,000 of short-term certificates of deposit at September 30, 2017 and June 30, 2017. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2017 and June 30, 2017. The Company has historically not experienced any credit losses with balances in excess of FDIC limits


## us-gaap:ReceivablesPolicyTextBlock

[0001144204-17-057067:notes:72]
Accounts Receivable

[0001144204-17-057067:notes:73]
Accounts receivable is stated net of the reserves for doubtful accounts of $175,000 as of September 30, 2017 and $155,000 as of June 30, 2017 and for returns and other allowances of $1,170,000 as of September 30, 2017 and $1,250,000 as of June 30, 2017. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.


## us-gaap:InventoryPolicyTextBlock

[0001144204-17-057067:notes:74]
Inventories

[0001144204-17-057067:notes:75]
Inventories are valued at the lower of cost or net realizable value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-17-057067:notes:76]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.

[0001144204-17-057067:notes:77]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-17-057067:notes:78]
Property, Plant, and Equipment

[0001144204-17-057067:notes:79]
Property, plant, and equipment are carried at cost less accumulated depreciation. Expenditures for maintenance and repairs are charged to expense as incurred; costs of major renewals and improvements are capitalized. At the time property and equipment are retired or otherwise disposed of, the cost and accumulated depreciation are eliminated from the asset and accumulated depreciation accounts and the profit or loss on such disposition is reflected in income.

[0001144204-17-057067:notes:80]
Depreciation is recorded over the estimated service lives of the related assets using primarily the straight-line method. Amortization of leasehold improvements is calculated by using the straight-line method over the estimated useful life of the asset or lease term, whichever is shorter.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001144204-17-057067:notes:81]
Long-Lived Assets

[0001144204-17-057067:notes:82]
Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets in question may not be recoverable. Impairment would be recorded in circumstances where undiscounted cash flows expected to be generated by an asset are less than the carrying value of that asset.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-17-057067:notes:83]
Revenue Recognition

[0001144204-17-057067:notes:84]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-17-057067:notes:85]
Income Taxes

[0001144204-17-057067:notes:86]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-17-057067:notes:87]
Net Income Per Share

[0001144204-17-057067:notes:88]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.

[0001144204-17-057067:notes:89]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

[0001144204-17-057067:notes:90]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 890 |  | $ | 568 |  |  | 18,846 |  |  | 18,787 |  | $ | 0.05 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  | -- |  |  | 33 |  |  | 51 |  |  | -- |  |  | -- |  |
| Diluted EPS |  | $ | 890 |  | $ | 568 |  |  | 18,879 |  |  | 18,838 |  | $ | 0.05 |  | $ | 0.03 |  |

[0001144204-17-057067:notes:91]
No options to purchase shares of common stock for the three months ended September 30, 2017 and 2016 were excluded in the computation of Diluted EPS.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-17-057067:notes:92]
Foreign Currency

[0001144204-17-057067:notes:93]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal period. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not significant for the either of the three months ended September 30, 2017 and 2016.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001144204-17-057067:notes:94]
Comprehensive Income

[0001144204-17-057067:notes:95]
For the three months ended September 30, 2017 and 2016, the Company's operations did not give rise to significant items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001144204-17-057067:notes:96]
Segment Reporting

[0001144204-17-057067:notes:97]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001144204-17-057067:notes:98]
Shipping and Handling Revenues and Costs

[0001144204-17-057067:notes:99]
The Company records the amount billed to customers for shipping and handling in net sales ($122,000 and $139,000 in the three months ended September 30, 2017 and 2016, respectively, and classifies the costs associated with these revenues in cost of sales ($207,000 and $216,000 in the three months ended September 30, 2017 and 2016, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001144204-17-057067:notes:100]
Recently Issued Accounting Standards

[0001144204-17-057067:notes:101]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance became effective for the Company’s fiscal 2018 first quarter and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective or prospective).  The Company does not believe this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-17-057067:notes:102]
In February 2016, the FASB issued authoritative guidance that requires lessees to account for most leases on their balance sheets with the liability being equal to the present value of the lease payments.  The right-of-use asset will be based on the lease liability adjusted for certain costs such as direct costs.  Lease expense will be recognized similar to current accounting guidance with operating leases resulting in a straight-line expense and financing leases resulting in a front-loaded expense similar to the current accounting for capital leases.  This guidance becomes effective for the Company’s fiscal 2020 first quarter, with early adoption permitted.  This guidance must be adopted using a modified retrospective transition approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements, and provides for certain practical expedients.  The Company is currently evaluating the timing, impact and method of applying this guidance on its consolidated financial statements.

[0001144204-17-057067:notes:103]
In November 2015, the FASB issued Accounting Standard Update (“ASU”) 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance was applied prospectively. Prior periods were not retrospectively adjusted.

[0001144204-17-057067:notes:104]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value (“NRV”). ASU 2015-11 was effective for the Company’s quarter ended September 30, 2017. The Company does not believe this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-17-057067:notes:105]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.


## nssc:ScheduleOfIntangibleAssetsTableTextBlock

[0001144204-17-057067:notes:106]
Changes in intangible assets are as follows (in thousands):

[0001144204-17-057067:notes:107]
|  |  | September 30, 2017 |  | June 30, 2017 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,877) |  | $ | 1,923 |  | $ | 9,800 |  | $ | (7,784) |  | $ | 2,016 |  |
| Trade name |  |  | 5,900 |  |  | -- |  |  | 5,900 |  |  | 5,900 |  |  | -- |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,877) |  | $ | 7,823 |  | $ | 15,700 |  | $ | (7,784) |  | $ | 7,916 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-17-057067:notes:108]
[same as prior period, unchanged from 0001144204-17-025269:notes:1]

[0001144204-17-057067:notes:109]
[same as prior period, unchanged from 0001144204-17-025269:notes:2]

[0001144204-17-057067:notes:110]
[same as prior period, unchanged from 0001144204-17-025269:notes:3]

[0001144204-17-057067:notes:111]
[same as prior period, unchanged from 0001144204-17-025269:notes:4]

[0001144204-17-057067:notes:112]
[same as prior period, unchanged from 0001144204-17-025269:notes:5]

[0001144204-17-057067:notes:113]
[same as prior period, unchanged from 0001144204-17-025269:notes:8]

[0001144204-17-057067:notes:114]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent gains and losses at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Critical estimates include management's judgments associated with reserves for sales returns and allowances, allowance for doubtful accounts, inventory reserves, intangible assets and income taxes. Actual results could differ from those estimates.

[0001144204-17-057067:notes:115]
[same as prior period, unchanged from 0001144204-17-025269:notes:10]

[0001144204-17-057067:notes:116]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, short-term certificates of deposit, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2017 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt at September 30, 2017 in the amount of $3,500,000 approximates fair value.

[0001144204-17-057067:notes:117]
[same as prior period, unchanged from 0001144204-17-025269:notes:23]

[0001144204-17-057067:notes:118]
Intangible assets determined to have indefinite lives are not amortized. Intangible assets with definite lives are amortized over their useful lives. Indefinite-lived intangible assets are reviewed for impairment at least annually at the Company’s fiscal year end of June 30 or more often whenever there is an indication that the carrying amount may not be recovered.

[0001144204-17-057067:notes:119]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of twenty years (customer relationships). The Marks trade name was deemed to have an indefinite life.

[0001144204-17-057067:notes:120]
Amortization expense for intangible assets subject to amortization was approximately $93,000 and $110,000 for the three months ended September 30, 2017 and 2016, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2018 - $371,000; 2019 - $313,000; 2020 -$264,000; 2021 - $223,000; and 2022 - $188,000. The weighted average amortization period for intangible assets was  10.9 years and  11.9 years at September 30, 2017 and 2016, respectively.

[0001144204-17-057067:notes:121]
[same as prior period, unchanged from 0001144204-17-025269:notes:33]

[0001144204-17-057067:notes:122]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 9% for the three months ended September 30, 2017 and 2016, respectively.

[0001144204-17-057067:notes:123]
[same as prior period, unchanged from 0001144204-17-025269:notes:35]

[0001144204-17-057067:notes:124]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of income and are expensed as incurred. Advertising expense for the three months ended September 30, 2017 and 2016 was $641,000 and $674,000, respectively.

[0001144204-17-057067:notes:125]
[same as prior period, unchanged from 0001144204-17-025269:notes:37]

[0001144204-17-057067:notes:126]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of income. Company-sponsored research and development expense for the three months ended September 30, 2017 and 2016 was $1,627,000 and $1,628,000, respectively.

[0001144204-17-057067:notes:127]
[same as prior period, unchanged from 0001144204-17-025269:notes:49]

[0001144204-17-057067:notes:128]
[same as prior period, unchanged from 0001144204-17-025269:notes:50]

[0001144204-17-057067:notes:129]
[same as prior period, unchanged from 0001144204-17-025269:notes:51]

[0001144204-17-057067:notes:130]
Stock-based compensation costs of $33,000 were recognized for each of the three months ended September 30, 2017 and 2016. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended September 30, 2017 and 2016.
