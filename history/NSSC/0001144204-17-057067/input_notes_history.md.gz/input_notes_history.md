# NSSC note change history — 0001144204-17-025269 → 0001144204-17-057067


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001144204-17-057067:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 for each of the three months ended September 30, 2017 and 2016, respectively.
  (was, 2017-05-08, similarity 0.6103):
[0001144204-17-025269:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $6,000 for the three months ended March 31, 2017 and 2016, respectively and $17,000 and $20,000 for the nine months ended March 31, 2017 and 2016, respectively.

- changed (2017-11-08):
[0001144204-17-057067:note_history:2]
As of September 30, 2017, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $730,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $324,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $293,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.
  (was, 2017-05-08, similarity 0.9967):
[0001144204-17-025269:note_history:2]
As of March 31, 2017, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $730,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001144204-17-057067:note_history:3]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2017 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 13, 2017. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All significant inter-company accounts and transactions have been eliminated.
  (was, 2017-05-08, similarity 0.9927):
[0001144204-17-025269:note_history:3]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2016 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 8, 2016. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated.

- changed (2017-11-08):
[0001144204-17-057067:note_history:4]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent gains and losses at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Critical estimates include management's judgments associated with reserves for sales returns and allowances, allowance for doubtful accounts, inventory reserves, intangible assets and income taxes. Actual results could differ from those estimates.
  (was, 2017-05-08, similarity 0.8447):
[0001144204-17-025269:note_history:4]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent gains and losses at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Critical estimates include management's judgments associated with reserves for sales returns and allowances, concentration of credit risk, inventory reserves, intangible assets and income taxes. Actual results could differ from those estimates.

- changed (2017-11-08):
[0001144204-17-057067:note_history:5]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, short-term certificates of deposit, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2017 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt at September 30, 2017 in the amount of $3,500,000 approximates fair value.
  (was, 2017-05-08, similarity 0.7051):
[0001144204-17-025269:note_history:5]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2017 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt at March 31, 2017 in the amount of $3,500,000 approximates fair value.

- added (2017-11-08):
[0001144204-17-057067:note_history:6]
Cash and cash equivalents include approximately $460,000 of short-term certificates of deposit at September 30, 2017 and June 30, 2017. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2017 and June 30, 2017. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2017-11-08):
[0001144204-17-057067:note_history:7]
Accounts receivable is stated net of the reserves for doubtful accounts of $175,000 as of September 30, 2017 and $155,000 as of June 30, 2017 and for returns and other allowances of $1,170,000 as of September 30, 2017 and $1,250,000 as of June 30, 2017. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.
  (was, 2017-05-08, similarity 0.7947):
[0001144204-17-025269:note_history:7]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of March 31, 2017 and June 30, 2016 and for returns and other allowances of $1,280,000 and $1,255,000 as of March 31, 2017 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.

- changed (2017-11-08):
[0001144204-17-057067:note_history:8]
Inventories are valued at the lower of cost or net realizable value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.
  (was, 2017-05-08, similarity 0.9842):
[0001144204-17-025269:note_history:8]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

- changed (2017-11-08):
[0001144204-17-057067:note_history:9]
Intangible assets determined to have indefinite lives are not amortized. Intangible assets with definite lives are amortized over their useful lives. Indefinite-lived intangible assets are reviewed for impairment at least annually at the Company’s fiscal year end of June 30 or more often whenever there is an indication that the carrying amount may not be recovered.
  (was, 2017-05-08, similarity 0.9148):
[0001144204-17-025269:note_history:9]
Intangible assets determined to have indefinite lives are not amortized but are tested for impairment at least annually. Intangible assets with definite lives are amortized over their useful lives. Intangible assets are reviewed for impairment at least annually at the Company’s fiscal year end of June 30 or more often whenever there is an indication that the carrying amount may not be recovered.

- changed (2017-11-08):
[0001144204-17-057067:note_history:10]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of twenty years (customer relationships). The Marks trade name was deemed to have an indefinite life.
  (was, 2017-05-08, similarity 0.9504):
[0001144204-17-025269:note_history:10]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of twenty years (customer relationships) and seven years (non-compete agreement). The Marks trade name was deemed to have an indefinite life.

- changed (2017-11-08):
[0001144204-17-057067:note_history:11]
|  |  | September 30, 2017 |  | June 30, 2017 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,877) |  | $ | 1,923 |  | $ | 9,800 |  | $ | (7,784) |  | $ | 2,016 |  |
| Trade name |  |  | 5,900 |  |  | -- |  |  | 5,900 |  |  | 5,900 |  |  | -- |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,877) |  | $ | 7,823 |  | $ | 15,700 |  | $ | (7,784) |  | $ | 7,916 |  |
  (was, 2017-05-08, similarity 0.6281):
[0001144204-17-025269:note_history:11]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,674) |  | $ | 2,126 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,674) |  | $ | 8,026 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

- changed (2017-11-08):
[0001144204-17-057067:note_history:12]
Amortization expense for intangible assets subject to amortization was approximately $93,000 and $110,000 for the three months ended September 30, 2017 and 2016, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2018 - $371,000; 2019 - $313,000; 2020 -$264,000; 2021 - $223,000; and 2022 - $188,000. The weighted average amortization period for intangible assets was  10.9 years and  11.9 years at September 30, 2017 and 2016, respectively.
  (was, 2017-05-08, similarity 0.8062):
[0001144204-17-025269:note_history:12]
Amortization expense for intangible assets subject to amortization was approximately $111,000 and $131,000 for the three months ended March 31, 2017 and 2016, respectively. Amortization expense for intangible assets subject to amortization was approximately $331,000 and $398,000 for the nine months ended March 31, 2017 and 2016, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.3 years and  12.3 years at March 31, 2017 and 2016, respectively.

- changed (2017-11-08):
[0001144204-17-057067:note_history:13]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 9% for the three months ended September 30, 2017 and 2016, respectively.
  (was, 2017-05-08, similarity 0.9588):
[0001144204-17-025269:note_history:13]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2017 and 2016, respectively.

- changed (2017-11-08):
[0001144204-17-057067:note_history:14]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of income and are expensed as incurred. Advertising expense for the three months ended September 30, 2017 and 2016 was $641,000 and $674,000, respectively.
  (was, 2017-05-08, similarity 0.8046):
[0001144204-17-025269:note_history:14]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2017 and 2016 was $365,000 and $259,000, respectively. Advertising expense for the nine months ended March 31, 2017 and 2016 was $1,537,000 and $1,328,000, respectively.

- changed (2017-11-08):
[0001144204-17-057067:note_history:15]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of income. Company-sponsored research and development expense for the three months ended September 30, 2017 and 2016 was $1,627,000 and $1,628,000, respectively.
  (was, 2017-05-08, similarity 0.7864):
[0001144204-17-025269:note_history:15]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2017 and 2016 was $1,698,000 and $1,513,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2017 and 2016 was $4,935,000 and $4,521,000, respectively.

- changed (2017-11-08):
[0001144204-17-057067:note_history:16]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):
  (was, 2017-05-08, similarity 0.9709):
[0001144204-17-025269:note_history:16]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

- changed (2017-11-08):
[0001144204-17-057067:note_history:17]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 890 |  | $ | 568 |  |  | 18,846 |  |  | 18,787 |  | $ | 0.05 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  | -- |  |  | 33 |  |  | 51 |  |  | -- |  |  | -- |  |
| Diluted EPS |  | $ | 890 |  | $ | 568 |  |  | 18,879 |  |  | 18,838 |  | $ | 0.05 |  | $ | 0.03 |  |
  (was, 2017-05-08, similarity 0.8936):
[0001144204-17-025269:note_history:17]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 952 |  | $ | 1,044 |  |  | 18,819 |  |  | 18,811 |  | $ | 0.05 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 36 |  |  | 17 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 952 |  | $ | 1,044 |  |  | 18,855 |  |  | 18,828 |  | $ | 0.05 |  | $ | 0.06 |  |

- added (2017-11-08):
[0001144204-17-057067:note_history:18]
No options to purchase shares of common stock for the three months ended September 30, 2017 and 2016 were excluded in the computation of Diluted EPS.

- added (2017-11-08):
[0001144204-17-057067:note_history:19]
Stock-based compensation costs of $33,000 were recognized for each of the three months ended September 30, 2017 and 2016. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended September 30, 2017 and 2016.

- added (2017-11-08):
[0001144204-17-057067:note_history:20]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal period. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not significant for the either of the three months ended September 30, 2017 and 2016.

- added (2017-11-08):
[0001144204-17-057067:note_history:21]
For the three months ended September 30, 2017 and 2016, the Company's operations did not give rise to significant items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2017-11-08):
[0001144204-17-057067:note_history:22]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11.
  (was, 2017-05-08, similarity 0.9522):
[0001144204-17-025269:note_history:22]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11, and no additional segment data has been presented.

- changed (2017-11-08):
[0001144204-17-057067:note_history:23]
The Company records the amount billed to customers for shipping and handling in net sales ($122,000 and $139,000 in the three months ended September 30, 2017 and 2016, respectively, and classifies the costs associated with these revenues in cost of sales ($207,000 and $216,000 in the three months ended September 30, 2017 and 2016, respectively.
  (was, 2017-05-08, similarity 0.7734):
[0001144204-17-025269:note_history:23]
The Company records the amount billed to customers for shipping and handling in net sales ($104,000 and $109,000 in the three months ended March 31, 2017 and 2016, respectively and $349,000 and $365,000 in the nine months ended March 31, 2017 and 2016, respectively) and classifies the costs associated with these revenues in cost of sales ($250,000 and $232,000 in the three months ended March 31, 2017 and 2016, respectively and $683,000 and $673,000 in the nine months ended March 31, 2017 and 2016, respectively).

- changed (2017-11-08):
[0001144204-17-057067:note_history:24]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance became effective for the Company’s fiscal 2018 first quarter and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective or prospective).  The Company does not believe this to have a material effect on our consolidated results of operations and financial condition.
  (was, 2017-05-08, similarity 0.9257):
[0001144204-17-025269:note_history:24]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance becomes effective for the Company’s fiscal 2018 first quarter, with early adoption permitted, and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective, or prospective).  The Company is currently evaluating the impact of applying this guidance on its consolidated financial statements.

- changed (2017-11-08):
[0001144204-17-057067:note_history:25]
In November 2015, the FASB issued Accounting Standard Update (“ASU”) 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance was applied prospectively. Prior periods were not retrospectively adjusted.
  (was, 2017-05-08, similarity 0.9727):
[0001144204-17-025269:note_history:25]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively. Prior periods were not retrospectively adjusted.

- added (2017-11-08):
[0001144204-17-057067:note_history:26]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value (“NRV”). ASU 2015-11 was effective for the Company’s quarter ended September 30, 2017. The Company does not believe this to have a material effect on our consolidated results of operations and financial condition.

- removed (2017-11-08):
[0001144204-17-025269:note_history:27]
Cash and cash equivalents include approximately $461,000 of short-term time deposits at March 31, 2017 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2017 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- removed (2017-11-08):
[0001144204-17-025269:note_history:28]
Options to  purchase  0 and  166,000 shares of common stock for the three months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- removed (2017-11-08):
[0001144204-17-025269:note_history:29]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

- removed (2017-11-08):
[0001144204-17-025269:note_history:30]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Basic EPS |  | $ | 2,357 |  | $ | 2,335 |  |  | 18,797 |  |  | 18,903 |  | $ | 0.13 |  | $ | 0.12 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 47 |  |  | 20 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 2,357 |  | $ | 2,335 |  |  | 18,844 |  |  | 18,923 |  | $ | 0.13 |  | $ | 0.12 |  |

- removed (2017-11-08):
[0001144204-17-025269:note_history:31]
Options to  purchase  0 and  147,000 shares of common stock for the nine months ended March 31, 2017 and 2016, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- removed (2017-11-08):
[0001144204-17-025269:note_history:32]
No stock-based compensation costs were recognized for three months ended March 31, 2017 or 2016. Stock-based compensation costs of $97,000 and $92,000 were recognized for nine months ended March 31, 2017 and 2016, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended March 31, 2017 and 2016. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the nine months ended March 31, 2017 and 2016.

- removed (2017-11-08):
[0001144204-17-025269:note_history:33]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2017 and 2016.

- removed (2017-11-08):
[0001144204-17-025269:note_history:34]
For the three and nine months ended March 31, 2017 and 2016, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- removed (2017-11-08):
[0001144204-17-025269:note_history:35]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001144204-17-057067:note_history:36]
As of September 30, 2017, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021.
  (was, 2017-05-08, similarity 0.8049):
[0001144204-17-025269:note_history:36]
As of March 31, 2017, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021. The term loan has been repaid in full as of March 31, 2017.

- changed (2017-11-08):
[0001144204-17-057067:note_history:37]
Outstanding balances and interest rates as of September 30, 2017 and June 30, 2017 are as follows (dollars in thousands):
  (was, 2017-05-08, similarity 0.8308):
[0001144204-17-025269:note_history:37]
Outstanding balances and interest rates as of March 31, 2017 and June 30, 2016 are as follows:

- changed (2017-11-08):
[0001144204-17-057067:note_history:38]
|  |  | September 30, 2017 |  | June 30, 2017 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.4 | % | $ | 3,500 |  |  | 2.2 | % |
  (was, 2017-05-08, similarity 0.7441):
[0001144204-17-025269:note_history:38]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.1 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | — |  |  | — |  |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,500 |  |  | 2.1 | % | $ | 4,800 |  |  | 1.6 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-08):
[0001144204-17-057067:note_history:39]
Outstanding balances and interest rates as of September 30, 2017 and June 30, 2017 are as follows (dollars in thousands):
  (was, 2017-05-08, similarity 0.8308):
[0001144204-17-025269:note_history:39]
Outstanding balances and interest rates as of March 31, 2017 and June 30, 2016 are as follows:

- changed (2017-11-08):
[0001144204-17-057067:note_history:40]
|  |  | September 30, 2017 |  | June 30, 2017 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.4 | % | $ | 3,500 |  |  | 2.2 | % |
  (was, 2017-05-08, similarity 0.7441):
[0001144204-17-025269:note_history:40]
|  |  | March 31, 2017 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,500 |  |  | 2.1 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | — |  |  | — |  |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,500 |  |  | 2.1 | % | $ | 4,800 |  |  | 1.6 | % |
