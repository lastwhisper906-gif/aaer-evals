# NSSC notes — 0001157523-12-004922


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-12-004922:notes:1]
NOTE 6 - Income Taxes

[0001157523-12-004922:notes:2]
The
Provision (benefit) for income taxes is comprised of the following
(in thousands):

[0001157523-12-004922:notes:3]
|  |  | For the Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Current income taxes: |  |  |  |
| Federal |  | $ | 11 |  |  | $ | (35 | ) |
| State |  |  | 57 |  |  |  | 39 |  |
| Foreign |  |  | -- |  |  |  | 3 |  |
|  |  |  | 68 |  |  |  | 7 |  |
| Deferred income tax provision (benefit) |  |  | 199 |  |  |  | (321 | ) |
| Provision (benefit) for income taxes |  | $ | 267 |  |  | $ | (314 | ) |

[0001157523-12-004922:notes:4]
A
reconciliation of the U.S. Federal statutory income tax rate to our
actual effective tax rate on earnings before income taxes is as
follows (dollars in thousands):

[0001157523-12-004922:notes:5]
|  |  | For the Years Ended June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
|  |  | Amount |  |  | % of Pre-tax Income |  |  | Amount |  |  | % of Pre-tax Income |  |
| Tax at Federal statutory rate |  | $ | 868 |  |  |  | 34.0 | % |  | $ | 274 |  |  |  | 34.0 | % |
| Increases (decreases) in taxes resulting from: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Meals and entertainment |  |  | 56 |  |  |  | 2.2 | % |  |  | 51 |  |  |  | 6.3 | % |
| State income taxes, net of Federal income tax benefit |  |  | 39 |  |  |  | 1.5 | % |  |  | 26 |  |  |  | 3.2 | % |
| Foreign source income and taxes |  |  | (515 | ) |  |  | (20.2 | )% |  |  | 102 |  |  |  | 12.7 | % |
| Stock based compensation expense |  |  | 3 |  |  |  | 0.1 | % |  |  | 16 |  |  |  | 2.0 | % |
| Tax reserve reversal |  |  | (61 | ) |  |  | (2.4 | )% |  |  | (77 | ) |  |  | (9.5 | )% |
| R&D Credit refund |  |  | (81 | ) |  |  | (3.2 | )% |  |  | (708 | ) |  |  | (87.8 | )% |
| Other, net |  |  | (42 | ) |  |  | (1.6 | )% |  |  | 2 |  |  |  | 0.2 | % |
| Effective tax rate |  | $ | 267 |  |  |  | 10.4 | % |  | $ | (314 | ) |  |  | (38.9 | )% |

[0001157523-12-004922:notes:6]
Deferred
tax assets and deferred tax liabilities at June 30, 2012 and 2011
are as follows (in thousands):

[0001157523-12-004922:notes:7]
|  |  | Current Deferred Tax Assets (Liabilities) |  |  | Long-term Deferred Tax Assets (Liabilities) |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Accounts receivable |  | $ | 23 |  |  | $ | 19 |  |  | $ | -- |  |  | $ | -- |  |
| Inventories |  |  | 399 |  |  |  | 288 |  |  |  | 405 |  |  |  | 380 |  |
| Accrued Liabilities |  |  | 228 |  |  |  | 221 |  |  |  | -- |  |  |  | 35 |  |
| Stock based compensation expense |  |  | -- |  |  |  | -- |  |  |  | 137 |  |  |  | 137 |  |
| Goodwill |  |  | -- |  |  |  | -- |  |  |  | 1,875 |  |  |  | 2,077 |  |
| R&D credit |  |  | -- |  |  |  | -- |  |  |  | 225 |  |  |  | 163 |  |
| Property, plant and equipment |  |  | -- |  |  |  | -- |  |  |  | (624 | ) |  |  | (625 | ) |
| Other deferred tax liabilities |  |  | -- |  |  |  | -- |  |  |  | (256 | ) |  |  | (84 | ) |
|  |  |  | 650 |  |  |  | 528 |  |  |  | 1,762 |  |  |  | 2,083 |  |
| Valuation allowance |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Net deferred taxes |  | $ | 650 |  |  | $ | 528 |  |  | $ | 1,762 |  |  | $ | 2,083 |  |

[0001157523-12-004922:notes:8]
The
Company has identified its U.S. Federal income tax return and its
State return in New York as its major tax jurisdictions. The fiscal
2008 and forward years are still open for examination.

[0001157523-12-004922:notes:9]
During
the year ended June 30, 2011, the Company completed a research and
development credit study. The study included the years June 30,
2007 through June 30, 2011 to determine the amount of R&D
credits to which the Company is entitled. The Company filed amended
tax returns for these years to establish the credits and generated
an income tax benefit of $885,401. Due to the nature of the
credits, the Company established a reserve under ASC 740-10 of
$165,000.

[0001157523-12-004922:notes:10]
During
the year ending June 30, 2012 the Company decreased its reserve for
uncertain income tax positions by $39,000. As of June 30, 2012 the
Company has a long-term accrued income tax liability of $126,000.
The Company’s practice is to recognize interest and penalties
related to income tax matters in income tax expense and accrued
income taxes. As of June 30, 2012, the Company had accrued interest
totaling $0 and $126,000 of unrecognized net tax benefits that, if
recognized, would favorably affect the Company’s effective
income tax rate in any future period.

[0001157523-12-004922:notes:11]
A
reconciliation of the beginning and ending amount of unrecognized
tax benefits is as follows (in thousands):

[0001157523-12-004922:notes:12]
|  |  | Tax |  |  | Interest |  |  | Total |  |
| Balance of gross unrecognized tax benefits as of July 1, 2011 |  | $ | 165 |  |  | $ | -- |  |  | $ | 165 |  |
| Reductions to unrecognized tax benefits resulting from changes in reserve percentages |  |  | (39 | ) |  |  | -- |  |  |  | (39 | ) |
| Balance of gross unrecognized tax benefits as of June 30, 2012 |  | $ | 126 |  |  | $ | -- |  |  | $ | 126 |  |

[0001157523-12-004922:notes:13]
Napco
US plans to permanently reinvest a substantial portion of its
foreign earnings and as such has not provided US corporate taxes on
the permanently reinvested earnings.  As of June 30,
2012, the Company had no undistributed earnings of foreign
subsidiaries.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-12-004922:notes:14]
NOTE 3 - Inventories

[0001157523-12-004922:notes:15]
Inventories,
net of reserves are valued at lower of cost (first-in, first-out
method) or market. The Company regularly reviews parts and finished
goods inventories on hand and, when necessary, records a provision
for excess or obsolete inventories. The Company also regularly
reviews the period over which its inventories will be converted to
sales. Any inventories expected to convert to sales beyond 12
months from the balance sheet date are classified as
non-current.

[0001157523-12-004922:notes:16]
Inventories,
net of reserves consist of the following (in
thousands):

[0001157523-12-004922:notes:17]
|  |  | June 30, |  |
|  |  | 2012 |  |  | 2011 |  |
| Component parts |  | $ | 13,155 |  |  | $ | 14,014 |  |
| Work-in-process |  |  | 3,199 |  |  |  | 4,452 |  |
| Finished product |  |  | 6,928 |  |  |  | 5,721 |  |
|  |  | $ | 23,282 |  |  | $ | 24,187 |  |
| Classification of inventories, net of reserves: |  |
| Current |  | $ | 19,448 |  |  | $ | 19,986 |  |
| Non-current |  |  | 3,834 |  |  |  | 4,201 |  |
|  |  | $ | 23,282 |  |  | $ | 24,187 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001157523-12-004922:notes:18]
Outstanding
balances and interest rates as of June 30, 2012 and June 30, 2011
are as follows:

[0001157523-12-004922:notes:19]
|  |  | June 30, 2012 |  |  | June 30, 2011 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 7,757 |  |  |  | 3.1 | % |  | $ | 8,600 |  |  |  | 4.8 | % |
| Term loan |  |  | 12,500 |  |  |  | 3.1 | % |  |  | 15,177 |  |  |  | 4.8 | % |
| Total debt |  | $ | 20,257 |  |  |  | 3.1 | % |  | $ | 23,777 |  |  |  | 4.8 | % |


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001157523-12-004922:notes:20]
Segment
Reporting

[0001157523-12-004922:notes:21]
The
Company’s reportable operating segments are determined based
on the Company's management approach.  The management
approach is based on the way that the chief operating decision
maker organizes the segments within an enterprise for making
operating decisions and assessing performance. The Company's
results of operations are reviewed by the chief operating decision
maker on a consolidated basis and the Company operates in only one
segment.  The Company has presented required geographical
data in Note 11, and no additional segment data has been
presented.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001157523-12-004922:notes:22]
Changes
in intangible assets are as follows (in thousands):

[0001157523-12-004922:notes:23]
|  |  | June 30, 2012 |  |  | June 30, 2011 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |  | $ | 9,800 |  |  | $ | (3,584 | ) |  | $ | 6,216 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |  |  | 340 |  |  |  | (140 | ) |  |  | 200 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |  | $ | 16,040 |  |  | $ | (3,724 | ) |  | $ | 12,316 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-12-004922:notes:24]
NOTE 2 - Business and Credit Concentrations

[0001157523-12-004922:notes:25]
The
Company had one customer with an accounts receivable balance of 15%
and 17% of the Company’s accounts receivable at June 30, 2012
and 2011, respectively. Sales to any one customer did not exceed
10% of net sales in any of the past three fiscal
years.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-12-004922:notes:26]
Property,
plant and equipment consist of the following:

[0001157523-12-004922:notes:27]
|  |  | June 30, |  |  |  |  |
|  |  | 2012 |  |  | 2011 |  |  | Useful Life in Years |  |
|  |  | (in thousands) |  |  |  |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |  |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,748 |  |  |  | 6,636 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,317 |  |  |  | 2,287 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,107 |  |  |  | 18,642 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 38,359 |  |  |  | 37,752 |  |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 31,112 |  |  |  | 30,011 |  |  |  |  |  |
|  |  | $ | 7,247 |  |  | $ | 7,741 |  |  |  |  |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001157523-12-004922:notes:28]
Accounts
Receivable

[0001157523-12-004922:notes:29]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$200,000 and $255,000 and for returns and other allowances of
$1,184,000 and $1,455,000 as of June 30, 2012 and June 30, 2011,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-12-004922:notes:30]
NOTE 4 - Property, Plant, and Equipment

[0001157523-12-004922:notes:31]
Depreciation
and amortization expense on property, plant, and equipment was
approximately $1,101,000 and $1,102,000 in fiscal 2012 and 2011,
respectively.


## us-gaap:HealthCareEntitiesPolicyPolicyTextBlock

[0001157523-12-004922:notes:32]
Self-funded
Employee Health Benefit Plan

[0001157523-12-004922:notes:33]
Effective
March 2012, the Company converted its employee health benefit plan
from a self-insured plan to a fully-insured plan. The Company
recorded claims as they were paid and records an accrual for unpaid
claims based upon the date of service or date incurred. The Company
has accrued $50,000 at June 30, 2012 in connection with its
self-insured liability for any potential unreported
claims.


## us-gaap:SubsequentEventsPolicyPolicyTextBlock

[0001157523-12-004922:notes:34]
Principles
of Consolidation

[0001157523-12-004922:notes:35]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries, including those of Marks USA I, LLC
(“Marks”), a subsidiary which acquired substantially
all of the assets and certain liabilities of G. Marks Hardware,
Inc. acquired on August 18, 2008. All inter-company balances and
transactions have been eliminated in consolidation.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001157523-12-004922:notes:36]
Comprehensive
Income

[0001157523-12-004922:notes:37]
For
the fiscal years ended June 30, 2012 and 2011, the Company's
operations did not give rise to material items includable in
comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001157523-12-004922:notes:38]
Minimum
lease payments through the expiration dates of these leases, with
the exception of the land leases referred to below, are as
follows:

[0001157523-12-004922:notes:39]
| Year Ending June 30, |  | Amount |  |
| 2013 |  | $ | 39,000 |  |
| 2014 |  |  | 16,000 |  |
| 2015 |  |  | 6,000 |  |
| 2016 |  |  | 1,000 |  |
| Total |  | $ | 62,000 |  |


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001157523-12-004922:notes:40]
Shipping
and Handling Revenues and Costs

[0001157523-12-004922:notes:41]
The
Company records the amount billed to customers in net sales
($584,000 and $474,000 in fiscal years 2012 and 2011, respectively)
and classifies the costs associated with these revenues in cost of
sales ($1,090,000 and $1,023,000 in fiscal years 2012 and 2011,
respectively).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-12-004922:notes:42]
NOTE 8 - Stock Options

[0001157523-12-004922:notes:43]
In
December 2002, the stockholders approved the 2002 Employee Stock
Option Plan (the 2002 Plan).  The 2002 Plan authorizes
the granting of awards, the exercise of which would allow up to an
aggregate of 1,836,000 shares of the Company's common stock to be
acquired by the holders of such awards.  Under the 2002
Plan, the Company may grant stock options, which are intended to
qualify as incentive stock options (ISOs), to key
employees.  Any plan participant who is granted ISOs and
possesses more than 10% of the voting rights of the Company's
outstanding common stock must be granted an option with a price of
at least 110% of the fair market value on the date of
grant.

[0001157523-12-004922:notes:44]
Under
the 2002 Plan, stock options have been granted to key employees
with a term of 10 years at an exercise price equal to the fair
market value on the date of grant and are exercisable in whole or
in part at 20% per year from the date of grant.  At June
30, 2012, 1,471,480 stock options were granted, 364,520 stock
options were available for grant, and 1,380,140 stock options were
exercisable under this plan.

[0001157523-12-004922:notes:45]
No
options were granted during fiscal 2012 or 2011.

[0001157523-12-004922:notes:46]
The
following table reflects activity under the 2002 Plans for the
fiscal years ended June 30,:

[0001157523-12-004922:notes:47]
|  |  | 2012 |  |  | 2011 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of year |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Exercisable, end of year |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,372,140 |  |  | $ | 2.93 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 1,066,760 |  |  |  |  |  |  | $ | 1,097,191 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 1,066,760 |  |  |  |  |  |  | $ | 1,097,191 |  |  |  |  |  |

[0001157523-12-004922:notes:48]
No
options were exercised during fiscal 2012 or 2011. Therefore, cash
received from option exercises for each of fiscal years 2012 and
2011 was $0 and the actual tax benefit realized for the tax
deductions from option exercises totaled $0 for both fiscal 2012
and 2011.

[0001157523-12-004922:notes:49]
The
following table summarizes information about stock options
outstanding under the 2002 Plan at June 30, 2012:

[0001157523-12-004922:notes:50]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding at June 30, 2012 |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable at June 30, 2012 |  |  | Weighted average exercise price |  |
| $ | 0.72 - $ 4.00 |  |  |  | 1,014,390 |  |  |  | 1.1 |  |  |  | 1.89 |  |  |  | 1,014,390 |  |  |  | 1.89 |  |
| $ | 4.01 - $ 7.50 |  |  |  | 328,250 |  |  |  | 4.5 |  |  |  | 5.29 |  |  |  | 328,250 |  |  |  | 5.29 |  |
| $ | 7.51 - $11.16 |  |  |  | 37,500 |  |  |  | 3.7 |  |  |  | 11.16 |  |  |  | 37,500 |  |  |  | 11.16 |  |
|  |  |  |  |  | 1,380,140 |  |  |  | 2.0 |  |  |  | 2.95 |  |  |  | 1,380,140 |  |  |  | 2.95 |  |

[0001157523-12-004922:notes:51]
As
of June 30, 2012, there was no unearned stock-based compensation
cost related to non-vested share-based compensation arrangements
granted under the 2002 Plan. The total fair value of the options
vested during fiscal 2012 under the 2002 Plan was
$28,920.

[0001157523-12-004922:notes:52]
In
September 2000, the stockholders approved a 10 year extension of
the already existing 1990 non-employee stock option plan (the 2000
Plan) to encourage non-employee directors and consultants of the
Company to invest in the Company's stock. This plan expired in
September 2010.  No further options may be granted under
the 2000 Plan. The 2000 Plan provided for the granting of
non-qualified stock options, the exercise of which would allow up
to an aggregate of 270,000 shares of the Company's common stock to
be acquired by the holders of the stock options.  The
2000 Plan provided that the option price will not be less than 100%
of the fair market value of the stock at the date of
grant.  Outstanding options are exercisable at 20% per
year and expire five years after the date of
grant.  Compensation cost was recognized for the fair
value of the options granted to non-employee directors and
consultants as of the date of grant.

[0001157523-12-004922:notes:53]
The
following table reflects activity under the 2000 Plan for the
fiscal years ended June,:

[0001157523-12-004922:notes:54]
|  |  | 2012 |  |  | 2011 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of year |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of year |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |

[0001157523-12-004922:notes:55]
As
of June 30, 2012, there was no unearned stock-based compensation
cost related to non-vested share-based compensation arrangements
granted under the 2000 Plan. The total fair value of the options
vested during fiscal 2012 under the 2002 Plan was $0.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-12-004922:notes:56]
Revenue
Recognition

[0001157523-12-004922:notes:57]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001157523-12-004922:notes:58]
The
following represents selected consolidated geographical data for
and as of the fiscal years ended June 30, 2012 and
2011:

[0001157523-12-004922:notes:59]
Financial Information Relating to Domestic and Foreign
Operations

[0001157523-12-004922:notes:60]
|  |  | 2012 |  |  | 2011 |  |
|  |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |
| Domestic |  | $ | 67,311 |  |  | $ | 66,793 |  |
| Foreign |  |  | 3,617 |  |  |  | 4,599 |  |
| Total Net Sales |  | $ | 70,928 |  |  | $ | 71,392 |  |
| Identifiable assets: |  |  |  |  |  |  |  |  |
| United States |  | $ | 50,838 |  |  | $ | 54,426 |  |
| Dominican Republic (2) |  |  | 13,912 |  |  |  | 14,342 |  |
| Other foreign countries |  |  | 0 |  |  |  | 27 |  |
| Total Identifiable Assets |  | $ | 64,750 |  |  | $ | 68,795 |  |

[0001157523-12-004922:notes:61]
(1)
All of the Company's sales originate in the United
States and are shipped primarily from the Company's facilities in
the United States. There were no sales into any one foreign country
in excess of 10% of total Net Sales.

[0001157523-12-004922:notes:62]
(2)
Consists primarily of inventories (2012 = $9,866,000; 2011 =
$9,955,000) and fixed assets (2012 = $3,936,000; 2011 = $4,189,000)
located at the Company's principal manufacturing facility in the
Dominican Republic.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001157523-12-004922:notes:63]
Recently
Issued Accounting Standards

[0001157523-12-004922:notes:64]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

[0001157523-12-004922:notes:65]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:IncomeTaxPolicyTextBlock

[0001157523-12-004922:notes:66]
Income
Taxes

[0001157523-12-004922:notes:67]
Deferred
tax assets and liabilities are recognized for the future tax
consequences attributable to temporary differences between the
financial statement carrying amounts of existing assets and
liabilities and their respective tax bases. Deferred tax assets and
liabilities are measured using enacted tax rates expected to apply
to taxable income in the years in which those temporary differences
are expected to be recovered or settled. The effect on deferred tax
assets and liabilities of a change in tax rates is recognized in
income in the period that includes the enactment date. Deferred
income tax expense represents the change during the period in the
deferred tax assets and deferred tax liabilities. The components of
the deferred tax assets and liabilities are individually classified
as current and non-current based on their characteristics. Deferred
tax assets are reduced by a valuation allowance when, in the
opinion of management, it is more likely than not that some portion
or all of the deferred tax assets will not be realized. The Company
measures and recognizes the tax implications of positions taken or
expected to be taken in its tax returns on an ongoing
basis.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-12-004922:notes:68]
NOTE 10 - Commitments and Contingencies

[0001157523-12-004922:notes:69]
Leases

[0001157523-12-004922:notes:70]
The
Company is committed under various operating leases, which do not
extend beyond fiscal 2016.  Minimum lease payments
through the expiration dates of these leases, with the exception of
the land leases referred to below, are as follows:

[0001157523-12-004922:notes:71]
Rent
expense, with the exception of the land lease referred to below,
totaled approximately $51,000 and $71,000 for the fiscal years
ended June 30, 2012 and 2011, respectively.

[0001157523-12-004922:notes:72]
Land
Lease

[0001157523-12-004922:notes:73]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic, at an annual cost of
approximately $288,000, on which the Company's principal production
facility is located.

[0001157523-12-004922:notes:74]
Litigation

[0001157523-12-004922:notes:75]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the settlement of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.

[0001157523-12-004922:notes:76]
Employment
Agreements

[0001157523-12-004922:notes:77]
As of June
30, 2012, the Company was obligated under one employment agreement
and one severance agreement. The employment agreement is with the
Company’s Chief Executive Officer. The employment agreement
provides for an annual salary of $587,000 as adjusted for
inflation, incentive compensation as may be approved by the Board
of Directors from time to time and a termination payment in an
amount up to 299% of the average of the prior five calendar year's
compensation, subject to certain limitations, as defined in the
agreement. The employment agreement renews annually in August
unless either party gives the other notice of non-renewal at least
six months prior to the end of the applicable term.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001157523-12-004922:notes:78]
Long-Lived
Assets

[0001157523-12-004922:notes:79]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. An impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001157523-12-004922:notes:80]
Foreign
Currency

[0001157523-12-004922:notes:81]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal year-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the years ended June 30, 2012 and
2011.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001157523-12-004922:notes:82]
Earnings
Per Share

[0001157523-12-004922:notes:83]
Basic
net income per common share (Basic EPS) is computed by dividing net
income by the weighted average number of common shares
outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

[0001157523-12-004922:notes:84]
The
following provides a reconciliation of information used in
calculating the per share amounts for the fiscal years ended June
30 (in thousands, except per share data):

[0001157523-12-004922:notes:85]
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | 2,286 |  |  | $ | 1,121 |  |  |  | 19,096 |  |  |  | 19,096 |  |  | $ | 0.12 |  |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 207 |  |  |  | 80 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 2,286 |  |  | $ | 1,121 |  |  |  | 19,303 |  |  |  | 19,176 |  |  | $ | 0.12 |  |  | $ | 0.06 |  |

[0001157523-12-004922:notes:86]
Options
to purchase 649,348 and 583,350 shares of common stock for the
fiscal years ended June 30, 2012 and 2011, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.


## us-gaap:InventoryPolicyTextBlock

[0001157523-12-004922:notes:87]
Inventories

[0001157523-12-004922:notes:88]
Inventories
are valued at the lower of cost or fair market value, with cost
being determined on the first-in, first-out (FIFO) method. The
reported net value of inventory includes finished saleable
products, work-in-process and raw materials that will be sold or
used in future periods. Inventory costs include raw materials,
direct labor and overhead. The Company’s overhead expenses
are applied based, in part, upon estimates of the proportion of
those expenses that are related to procuring and storing raw
materials as compared to the manufacture and assembly of finished
products. These proportions, the method of their application, and
the resulting overhead included in ending inventory, are based in
part on subjective estimates and actual results could differ from
those estimates.

[0001157523-12-004922:notes:89]
In
addition, the Company records an inventory obsolescence reserve,
which represents the difference between the cost of the inventory
and its estimated market value, based on various product sales
projections. This reserve is calculated using an estimated
obsolescence percentage applied to the inventory based on age,
historical trends, requirements to support forecasted sales, and
the ability to find alternate applications of its raw materials and
to convert finished product into alternate versions of the same
product to better match customer demand.  There is
inherent professional judgment and subjectivity made by both
production and engineering members of management in determining the
estimated obsolescence percentage.   For the fiscal
years 2012 and 2011, charges and balances in these reserves
amounted to $504,000 and $3,038,000; and $694,000 and $2,534,000,
respectively. In addition, and as necessary, the Company may
establish specific reserves for future known or anticipated
events.

[0001157523-12-004922:notes:90]
The
Company also regularly reviews the period over which its
inventories will be converted to sales. Any inventories
expected to convert to sales beyond 12 months from the balance
sheet date are classified as non-current.


## us-gaap:LongTermDebtTextBlock

[0001157523-12-004922:notes:91]
NOTE 7 - Long-Term Debt

[0001157523-12-004922:notes:92]
As
of June 30, 2012, long-term debt consisted of a revolving credit
facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commences on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

[0001157523-12-004922:notes:93]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the
“Agreement”).  Prior to closing on June 29,
2012, $8,600,000 was outstanding under the existing $11,100,000
revolving credit facility and $12,500,000 was outstanding under the
existing term loan. The Agreement amended and restated the previous
revolving credit facility and term loan and provides for a
revolving credit facility of $11,000,000 (the “Revolving
Credit Facility”) which expires in June 2017 and two term
loans, one for $6,000,000 which expires in June 2019, and one for
$6,500,000 which expires in June 2017 (the “Term
Loans”). Repayment of the Terms Loans commences on September
30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal,
quarterly payments of $75,000 and the remaining balance of
$3,900,000 due on or before the expiration date. The $6,500,000
Term Loan is being repaid in 20 equal, quarterly payments of
$325,000. The Agreement also provides for a LIBOR-based interest
rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of
outstanding debt to EBITDA, which is to be measured and adjusted
quarterly, a prime rate-based option of the prime rate plus 0.25%
and other terms and conditions as more fully described in the
Agreement. In addition, the Agreement provides for availability
under the Revolving Credit Facility to be limited to the lesser of
$11,000,000 or the result of a borrowing base formula based upon
the Company’s Accounts Receivables and Inventory values net
of certain deductions. The Company’s obligations under the
Agreement continue to be secured by all of its assets, including
but not limited to, deposit accounts, accounts receivable,
inventory, the Company’s corporate headquarters in
Amityville, NY, equipment and fixtures and intangible assets. In
addition, the Company’s wholly-owned subsidiaries, with the
exception of the Company’s foreign subsidiaries, have issued
guarantees and pledges of all of their assets to secure the
Company’s obligations under the Agreement. All of the
outstanding common stock of the Company’s domestic
subsidiaries and 65% of the common stock of the Company’s
foreign subsidiaries has been pledged to secure the Company’s
obligations under the Agreement.

[0001157523-12-004922:notes:94]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-12-004922:notes:95]
Property,
Plant, and Equipment

[0001157523-12-004922:notes:96]
Property,
plant, and equipment are carried at cost less accumulated
depreciation. Expenditures for maintenance and repairs are charged
to expense as incurred; costs of major renewals and improvements
are capitalized. At the time property and equipment are retired or
otherwise disposed of, the cost and accumulated depreciation are
eliminated from the asset and accumulated depreciation accounts and
the profit or loss on such disposition is reflected in
income.

[0001157523-12-004922:notes:97]
Depreciation
is recorded over the estimated service lives of the related assets
using primarily the straight-line method.  Amortization
of leasehold improvements is calculated by using the straight-line
method over the estimated useful life of the asset or lease term,
whichever is shorter.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-12-004922:notes:98]
Cash
and Cash Equivalents

[0001157523-12-004922:notes:99]
Cash
and cash equivalents include approximately $460,000 and $960,000 of
short-term time deposits at June 30, 2012 and 2011,
respectively.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of June 30, 2012 and 2011.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001157523-12-004922:notes:100]
NOTE 5 – Acquisition of Business

[0001157523-12-004922:notes:101]
On
August 18, 2008, the Company acquired substantially all of the
assets and business of Marks for $25.2 million, the repayment of $1
million of bank debt and the assumption of current liabilities. The
Marks business involves the manufacturing and distribution of
door-locking devices. The Company funded the acquisition with a
term loan from its lenders, which has since been amended as
described in Note 7.

[0001157523-12-004922:notes:102]
The
intangible assets acquired, other than the Marks tradename, are
being amortized over their estimated useful lives of twenty years
(customer relationships) and seven years (non-compete agreement).
The weighted average amortization period of these assets is 19.6
years. The Marks trade name was deemed to have an indefinite life.
At the conclusion of the quarter ended June 30, 2011, the Company
performed its annual impairment evaluation and determined that its
intangible asset relating to its Marks tradename, was partially
impaired. Accordingly, in the quarter ended June 30, 2011 the
Company recorded an impairment charge of $400,000 which represented
the excess book value of this intangible asset over its current
valuation.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-12-004922:notes:103]
NOTE 1 - Nature of Business and Summary of Significant Accounting
Policies

[0001157523-12-004922:notes:104]
Nature
of Business

[0001157523-12-004922:notes:105]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic locking devices, intrusion and fire alarms and building
access control systems. These products are used for commercial,
residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.

[0001157523-12-004922:notes:106]
Accounting
Estimates

[0001157523-12-004922:notes:107]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, goodwill and
other intangible assets and income taxes.  Actual results
could differ from those estimates.

[0001157523-12-004922:notes:108]
Intangible
Assets

[0001157523-12-004922:notes:109]
Certain
intangible assets determined to have indefinite lives are not
amortized but are tested for impairment at least annually.
Intangible assets with definite lives are amortized over their
useful lives. Intangible assets are reviewed for impairment at
least annually at the Company’s fiscal year end of June 30 or
more often whenever there is an indication that the carrying amount
may not be recovered.

[0001157523-12-004922:notes:110]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life. At the conclusion of the quarter ended June 30,
2011, the Company performed its annual impairment evaluation and
determined that its intangible asset relating to its Marks trade
name was partially impaired. Accordingly, in the quarter ended June
30, 2011 the Company recorded an impairment charge of $400,000
which represented the excess book value of this intangible asset
over its current valuation.

[0001157523-12-004922:notes:111]
Amortization
expense for intangible assets subject to amortization was
approximately $1,065,000 and $1,154,000 for the years ended June
30, 2012 and 2011, respectively. Amortization expense for each of
the next five years is estimated to be as follows: 2013 - $917,000;
2014 - $781,000; 2015 - $667,000; 2016 - $529,000 and 2017 -
$441,000. The weighted average amortization period for intangible
assets was 15.8 years and 16.7 years at June 30, 2012 and
2011, respectively.

[0001157523-12-004922:notes:112]
Sales
Returns and Other Allowances

[0001157523-12-004922:notes:113]
The
Company analyzes sales returns and is able to make reasonable and
reliable estimates of product returns based on the Company’s
past history. Estimates for sales returns are based on several
factors including actual returns and based on expected return data
communicated to it by its customers. Accordingly, the Company
believes that its historical returns analysis is an accurate basis
for its allowance for sales returns. Actual results could differ
from those estimates.

[0001157523-12-004922:notes:114]
Advertising
and Promotional Costs

[0001157523-12-004922:notes:115]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the fiscal years ended June 30, 2012 and 2011 was
$1,081,000 and $792,000, respectively.

[0001157523-12-004922:notes:116]
Research
and Development Costs

[0001157523-12-004922:notes:117]
Research
and development costs incurred by the Company are charged to
expense in the year incurred.  Company-sponsored research
and development costs of $4,264,000 and $4,392,000 were charged to
expense for the fiscal years ended June
30, 2012 and 2011, respectively, and are included in "Cost of
Sales" in the consolidated statements of operations.

[0001157523-12-004922:notes:118]
Stock-Based
Compensation

[0001157523-12-004922:notes:119]
The
Company has established two share incentive programs as discussed
in Note 8.

[0001157523-12-004922:notes:120]
Stock-based
compensation cost is measured at the grant date based on the fair
value of the award and is recognized as expense on a straight-line
basis over the vesting period. Determining the fair value of
share-based awards at the grant date requires assumptions and
judgments about expected volatility and forfeiture rates, among
other factors.

[0001157523-12-004922:notes:121]
Stock-based
compensation costs of $8,000 and $66,000 were recognized for fiscal
years 2012 and 2011, respectively. The effect on both Basic and
Diluted Earnings per share was $0.00 for fiscal years 2012 and
2011.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-12-004922:notes:122]
NOTE 9 - 401(k) Plan

[0001157523-12-004922:notes:123]
The
Company maintains two 401(k) plans (“the Napco Plan”
and “the Marks Plan”) that cover all U.S. non-union
employees with one or more years of service and is qualified under
Sections 401(a) and 401(k) of the Internal Revenue Code. Company
contributions to this plan are discretionary and totaled $41,000
and $0 for the years ended June 30, 2012 and 2011. The Marks Plan
was adopted by the Company subsequent to the Marks acquisition in
August 2008 and provides for discretionary matching contributions.
Company contributions to this plan were $3,000 and $0 for the years
ended June 30, 2012 and 2011, respectively.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-12-004922:notes:124]
NOTE 11 - Geographical Data

[0001157523-12-004922:notes:125]
The
Company is engaged in one major line of business: the development,
manufacture, and distribution of security alarm products and door
security devices for commercial and residential
use.  Sales to unaffiliated customers are primarily
shipped from the United States. The Company has customers worldwide
with major concentrations in North America, Europe, and South
America.
