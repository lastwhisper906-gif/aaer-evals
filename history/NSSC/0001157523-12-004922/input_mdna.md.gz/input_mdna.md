# NSSC MD&A — 0001157523-12-004922


## mdna

[0001157523-12-004922:mdna:1]
ITEM 7:  MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF  OPERATIONS.

[0001157523-12-004922:mdna:2]
Overview

[0001157523-12-004922:mdna:3]
The Company is a diversified manufacturer of security products, encompassing intrusion and fire alarms, building access control systems and electronic locking devices. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 5% and 6% of our revenues for the fiscal years ended June 30, 2012 and 2011 respectively.

[0001157523-12-004922:mdna:4]
The Company owns and operates manufacturing facilities in Amityville, New York and the Dominican Republic. A significant portion of our operating costs are fixed, and do not fluctuate with changes in production levels or utilization of our manufacturing capacity. As production levels rise and factory utilization increases, the fixed costs are spread over increased output, which should improve profit margins. Conversely, when production levels decline our fixed costs are spread over reduced levels, thereby decreasing margins.

[0001157523-12-004922:mdna:5]
The security products market is characterized by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of revenues to research and development (R&D) on an annual basis. Products resulting from our R&D investments in fiscal 2011 did not contribute materially to revenue during this fiscal year, but should benefit the Company over future years. In general, the new products introduced by the Company are initially shipped in limited quantities, and increase over time. Prices and manufacturing costs tend to decline over time as products and technologies mature.

[0001157523-12-004922:mdna:6]
Economic and Other Factors

[0001157523-12-004922:mdna:7]
Since October 2008, the U.S. and international economies have experienced a significant downturn and continue to be at depressed levels. In the event that the U.S. or international financial markets erode further, our revenue, profit and cash-flow levels could be materially adversely affected in future periods. If the worldwide economic downturn worsens, many of our current or potential future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products. Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. Furthermore, the ongoing downturn and economic uncertainty makes it difficult for us to forecast our revenues.

[0001157523-12-004922:mdna:8]
Seasonality

[0001157523-12-004922:mdna:9]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Further deterioration of the current economic conditions may also affect this trend.

[0001157523-12-004922:mdna:10]
Critical Accounting Policies and Estimates

[0001157523-12-004922:mdna:11]
The discussion and analysis of our financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in conformity with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenues and expenses reported in those financial statements. These judgments can be subjective and complex, and consequently actual results could differ from those estimates. Critical estimates include management's judgments associated with revenue recognition, reserves for sales returns and allowances, concentration of credit risk, inventories, goodwill and other intangible assets and income taxes.

[0001157523-12-004922:mdna:12]
Revenue Recognition

[0001157523-12-004922:mdna:13]
Revenues from merchandise sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of sale. We report our sales levels on a net sales basis, which is computed by deducting from gross sales the amount of actual returns received and an amount established for anticipated returns and other allowances.

[0001157523-12-004922:mdna:14]
Our sales return accrual is a subjective critical estimate that has a direct impact on reported net sales and income. This accrual is calculated based on a history of gross sales and actual sales returns, as well as management's estimate of anticipated returns and allowances. As a percentage of gross sales, sales returns, rebates and allowances were 6% and 7% for fiscal years ended June 30, 2012 and 2011, respectively.

[0001157523-12-004922:mdna:15]
Concentration of Credit Risk

[0001157523-12-004922:mdna:16]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance.

[0001157523-12-004922:mdna:17]
The Company had one customer with an accounts receivable balance of 15% and 17% of the Company’s accounts receivable at June 30, 2012 and 2011, respectively. Sales to this customer did not exceed 10% of net sales in any of the past three fiscal years.

[0001157523-12-004922:mdna:18]
In the ordinary course of business, we have established a reserve for doubtful accounts and customer deductions in the amount of $200,000 and $255,000 as of June 30, 2012 and 2011, respectively. The decrease from fiscal 2011 to 2012 was due to the Company writing off certain receivables during fiscal 2012 which had been reserved for as of June 30, 2011.  Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical trends.

[0001157523-12-004922:mdna:19]
Inventories

[0001157523-12-004922:mdna:20]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and approximations and actual results could differ from those estimates.

[0001157523-12-004922:mdna:21]
In addition, the Company records an inventory obsolescence reserve, which represents the difference between the cost of the inventory and its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand.  There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.   For the fiscal years 2012 and 2011, net charges and balances in these reserves amounted to $504,000 and $3,038,000; and $694,000 and $2,534,000, respectively. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events.

[0001157523-12-004922:mdna:22]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001157523-12-004922:mdna:23]
Goodwill and Other Intangible Assets

[0001157523-12-004922:mdna:24]
The Company evaluates its Goodwill and Other Intangible Assets for impairment at least on an annual basis. Those intangible assets that are classified as goodwill or as other intangibles with indefinite lives are not amortized.

[0001157523-12-004922:mdna:25]
Impairment testing is performed in two steps: (i) the Company determines impairment by comparing the fair value of a reporting unit with its carrying value, and (ii) if there is impairment, the Company measures the amount of impairment loss by comparing the implied fair value of goodwill and other intangible assets with the carrying amount of that goodwill and other intangible assets.

[0001157523-12-004922:mdna:26]
At the conclusion of the fiscal 2012, the Company performed its annual impairment evaluation and determined that its intangible assets were not impaired.

[0001157523-12-004922:mdna:27]
At the conclusion of the fiscal 2011, the Company performed its annual impairment evaluation and determined that its intangible asset relating to its Marks trade name was partially impaired. Accordingly, in the quarter ended June 30, 2011 the Company recorded an impairment charge of $400,000 which represented the excess book value of this intangible asset over its current valuation.

[0001157523-12-004922:mdna:28]
Self-funded Employee Health Benefit Plan

[0001157523-12-004922:mdna:29]
Effective March 2012, the Company converted its employee health benefit plan from a self-insured plan to a fully-insured plan. The Company recorded claims as they were paid and records an accrual for unpaid claims based upon the date of service or date incurred. The Company has accrued $50,000 at June 30, 2012 in connection with its self-insured liability for any potential unreported claims.

[0001157523-12-004922:mdna:30]
Income Taxes

[0001157523-12-004922:mdna:31]
The Company has identified its U.S. Federal income tax return and its State return in New York as its major tax jurisdictions. The fiscal 2008 and forward years are still open for examination.

[0001157523-12-004922:mdna:32]
During the year ended June 30, 2011, the Company completed a research and development credit study.  The study included the years June 30, 2007 through June 30, 2011 to determine the amount of R&D credits to which the Company is entitled.  The Company filed amended tax returns for these years to establish the credits and generated an income tax benefit of $885,401.  Due to the nature of the credits, the Company established a reserve under ASC 740-10 of $165,000.

[0001157523-12-004922:mdna:33]
During the year ending June 30, 2012 the Company decreased its reserve for uncertain income tax positions by $39,000. As of June 30, 2012 the Company has a long-term accrued income tax liability of $126,000. The Company’s practice is to recognize interest and penalties related to income tax matters in income tax expense and accrued income taxes. As of June 30, 2012, the Company had accrued interest totaling $0 and $126,000 of unrecognized net tax benefits that, if recognized, would favorably affect the Company’s effective income tax rate in any future period.

[0001157523-12-004922:mdna:34]
For the year ended June 30, 2012, the Company recognized a net income tax benefit of $39,000.

[0001157523-12-004922:mdna:35]
A reconciliation of the U.S. Federal statutory income tax rate to our actual effective tax rate on earnings before income taxes for fiscal 2012 is as follows (dollars in thousands):

[0001157523-12-004922:mdna:36]
|  |  | Amount |  |  | % of Pre-tax Income |  |
| Tax at Federal statutory rate |  | $ | 868 |  |  |  | 34.0 | % |
| Increases (decreases) in taxes resulting from: |  |  |  |  |  |  |  |  |
| Meals and entertainment |  |  | 56 |  |  |  | 2.2 | % |
| State income taxes, net of Federal income tax benefit |  |  | 39 |  |  |  | 1.5 | % |
| Foreign source income and taxes |  |  | (515 | ) |  |  | (20.2 | )% |
| Stock based compensation expense |  |  | 3 |  |  |  | 0.1 | % |
| Tax reserve reversal |  |  | (61 | ) |  |  | (2.4 | )% |
| R&D Credit Refund |  |  | (81 | ) |  |  | (3.2 | )% |
| Other, net |  |  | (42 | ) |  |  | (1.6 | )% |
| Effective tax rate |  | $ | 267 |  |  |  | 10.4 | % |

[0001157523-12-004922:mdna:37]
Liquidity and Capital Resources

[0001157523-12-004922:mdna:38]
The Company's cash on hand combined with proceeds from operating activities during fiscal 2012 were adequate to meet the Company's capital expenditure needs and debt obligations. The Company's primary internal source of liquidity is the cash flow generated from operations. The primary source of external financing is a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017. As of June 30, 2012 $7,757,000 was outstanding under this revolving line of credit. As of June 30, 2012, the Company's unused sources of funds consisted principally of $2,979,000 in cash and $3,243,000 available under its revolving line of credit.

[0001157523-12-004922:mdna:39]
On June 29, 2012, the Company entered into a Third Amended and Restated Credit Agreement with the Company, as the Borrower, and HSBC Bank USA, National Association as Lender, Administrative Agent and Collateral Agent (the “Agreement”).  Prior to closing on June 29, 2012, $8,600,000 was outstanding under the existing $11,100,000 revolving credit facility and $12,500,000 was outstanding under the existing term loan. The Agreement amended and restated the previous revolving credit facility and term loan and provides for a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commences on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. The Agreement also provides for a LIBOR-based interest rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus 0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and 65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001157523-12-004922:mdna:40]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-12-004922:mdna:41]
Management believes that current working capital and cash flows from operations as well as borrowing availability under the revolving line of credit described above will be sufficient to fund the Company's operations through at least the first quarter of fiscal 2014.

[0001157523-12-004922:mdna:42]
The Company takes into consideration a number of factors in measuring its liquidity, including the ratios set forth below:

[0001157523-12-004922:mdna:43]
|  | As of June 30, |
|  | 2012 | 2011 |
| Current Ratio | 4.9 to 1 | 3.2 to 1 |
| Sales to Receivables | 4.3 to 1 | 4.0 to 1 |
| Total debt to equity | .54 to 1 | .67 to 1 |

[0001157523-12-004922:mdna:44]
As of June 30, 2012, the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business. On April 26, 1993, the Company's foreign subsidiary entered into a 99-year land lease of approximately 4 acres of land in the Dominican Republic, at an annual cost of approximately $288,000.

[0001157523-12-004922:mdna:45]
On August 18, 2008, the Company, pursuant to an Asset Purchase Agreement with Marks, acquired substantially all of the assets and business for $25 million, the repayment of $1 million of bank debt and the assumption of current liabilities. The Marks business involves the manufacturing and distribution of door-locking devices.  The Company funded the acquisition with a term loan from its lenders, which was amended in June 2012 as described above. The acquisition was accounted for as a purchase and was valued based on management’s estimate of the fair value of the assets acquired and liabilities assumed.

[0001157523-12-004922:mdna:46]
Working Capital. Working capital increased by $3,020,000 to $32,205,000 at June 30, 2012 from $29,185,000 at June 30, 2011. Working capital is calculated by deducting Current Liabilities from Current Assets.

[0001157523-12-004922:mdna:47]
Accounts Receivable. Accounts Receivable decreased by $1,232,000 to $16,408,000 at June 30, 2012 as compared $17,640,000 at June 30, 2011. The decrease in Accounts Receivable was due primarily to a decrease of $736,000 in net sales in the quarter ended June 30, 2012 as compared to the quarter ended June 30, 2011 as well as the Company granting less extended payment terms to its customers for the same period.

[0001157523-12-004922:mdna:48]
Inventories. Inventories, which include both current and non-current portions, decreased by $905,000 to $23,282,000 at June 30, 2012 as compared to $24,187,000 at June 30, 2011.  The decrease was due primarily to the Company’s improved production planning and forecasting as well as an increase of $504,000 to the inventory reserve.

[0001157523-12-004922:mdna:49]
Accounts Payable and Accrued Expenses. Accounts payable and accrued expenses decreased by $2,421,000 to $6,566,000 as of June 30, 2012 as compared to $8,987,000 at June 30, 2011.  This decrease is primarily due to decreased purchases of raw materials during the quarter ended June 30, 2012 as compared to June 30, 2011.

[0001157523-12-004922:mdna:50]
Off-Balance Sheet Arrangements

[0001157523-12-004922:mdna:51]
The Company does not maintain any off-balance sheet arrangements.

[0001157523-12-004922:mdna:52]
Contractual Obligations

[0001157523-12-004922:mdna:53]
The following table summarizes the Company's contractual obligations by fiscal year:

[0001157523-12-004922:mdna:54]
|  |  | Payments due by period: |  |
| Contractual obligations |  | Total |  |  | Less than 1 year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Long-term debt obligations |  | $ | 20,257,000 |  |  | $ | 1,600,000 |  |  | $ | 3,200,000 |  |  | $ | 10,957,000 |  |  | $ | 4,500,000 |  |
| Land lease (80 years remaining) (1) |  |  | 23,040,000 |  |  |  | 288,000 |  |  |  | 576,000 |  |  |  | 576,000 |  |  |  | 21,600,000 |  |
| Operating lease obligations |  |  | 62,000 |  |  |  | 39,000 |  |  |  | 22,000 |  |  |  | 1,000 |  |  |  | - |  |
| Other long-term obligations (employment agreement) (1) |  |  | 587,000 |  |  |  | 587,000 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 43,946,000 |  |  | $ | 2,514,000 |  |  | $ | 3,798,000 |  |  | $ | 11,534,000 |  |  | $ | 26,100,000 |  |

[0001157523-12-004922:mdna:55]
| (1) | See footnote 10 to the accompanying consolidated financial statements. |

[0001157523-12-004922:mdna:56]
Results of Operations

[0001157523-12-004922:mdna:57]
Fiscal 2012 Compared to Fiscal 2011

[0001157523-12-004922:mdna:58]
|  |  | Fiscal year ended June 30, |
|  |  | 2012 |  |  | 2011 |  |  | % Increase/ (decrease) |
| Net sales |  | $ | 70,928 |  |  | $ | 71,392 |  |  |  | (0.6 | )% |
| Gross profit |  |  | 21,152 |  |  |  | 20,101 |  |  |  | 5.2 | % |
| Gross profit as a % of net sales |  |  | 29.8 | % |  |  | 28.2 | % |  |  | 5.7 | % |
| Selling, general and administrative |  |  | 17,341 |  |  |  | 17,188 |  |  |  | 0.9 | % |
| Selling, general and administrative as a % of net sales |  |  | 24.4 | % |  |  | 24.1 | % |  |  | 1.2 | % |
| Impairment of goodwill and other intangibles |  |  | 0 |  |  |  | 400 |  |  |  | (100.0 | )% |
| Income from operations |  |  | 3,811 |  |  |  | 2,513 |  |  |  | 51.7 | % |
| Interest expense, net |  |  | 1,149 |  |  |  | 1,660 |  |  |  | (30.8 | )% |
| Other expense, net |  |  | 109 |  |  |  | 46 |  |  |  | 137.0 | % |
| Provision (benefit) for income taxes |  |  | 267 |  |  |  | (314 | ) |  |  | 185.0 | % |
| Net income |  |  | 2,286 |  |  |  | 1,121 |  |  |  | 103.9 | % |

[0001157523-12-004922:mdna:59]
Net sales in fiscal 2012 remained relatively constant at $70,928,000 as compared to $71,392,000 in fiscal 2011. Sales was affected primarily by decreased sales of the Company’s Marks brand door-locking products ($2,981,000) and foreign sales of the Company’s intrusion products ($982,000) and was partially offset by increases in the Company’s domestic intrusion products ($1,773,000), Alarm Lock brand door locking products ($1,405,000), and access control products ($321,000).

[0001157523-12-004922:mdna:60]
The Company's gross profit increased by $1,051,000 to $21,152,000 or 29.8% of net sales in fiscal 2012 as compared to $20,101,000 or 28.2% of net sales in fiscal 2011. Gross profit and gross profit as a percentage of net sales was primarily affected by a positive shift in product mix in fiscal 2012 as well as reductions in overhead expenses resulting from increases in efficiency in the Company’s production planning, procurement and manufacturing processes.

[0001157523-12-004922:mdna:61]
Selling, general and administrative expenses as a percentage of net sales increased to 24.4% in fiscal 2012 from 24.1% in fiscal 2011. Selling, general and administrative expenses for fiscal 2012 remained relatively constant at $17,341,000 as compared to $17,188,000 in fiscal 2011.  The increase as a percentage of sales resulted primarily from the slight increase in expenses as well as the slight decrease in net sales.

[0001157523-12-004922:mdna:62]
Interest expense for fiscal 2012 decreased by $511,000 to $1,149,000 from $1,660,000 for the same period a year ago.  The decrease in interest expense is primarily the result of the decrease in interest rates charged by the Company’s primary banks as well as the Company’s reduction of its outstanding borrowings under its revolving line of credit and its term loan.

[0001157523-12-004922:mdna:63]
Other expenses increased $63,000 to $109,000 in fiscal 2012 as compared to $46,000 in fiscal 2011.

[0001157523-12-004922:mdna:64]
The Company’s provision for income taxes for fiscal 2012 increased by $581,000 to a provision of $267,000 as compared to a benefit of $314,000 for the same period a year ago. The increase in the income taxes from fiscal 2011 to fiscal 2012 resulted primarily from the increase in income before income taxes as well as a benefit of recognizing multiple years of R&D tax credits in fiscal 2011.

[0001157523-12-004922:mdna:65]
Net income for fiscal 2012 increased by $1,165,000 to $2,286,000 as compared to $1,121,000 in fiscal 2011. This resulted primarily from the items discussed above as well as an impairment charge of $400,000 recorded in fiscal 2011 relating to intangible assets.

[0001157523-12-004922:mdna:66]
Forward-looking Information
