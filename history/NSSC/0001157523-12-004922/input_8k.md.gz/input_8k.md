# NSSC 8-K — 0001157523-12-000774 filed 2012-02-15

## item codes, every 8-K on or before 2012-09-21

- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2012-09-21

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-000774:8k_2_02:1]
EX-99.1
2
a50168904_ex991.htm
EXHIBIT 99.1

[0001157523-12-000774:8k_2_02:2]
Exhibit 99.1

[0001157523-12-000774:8k_2_02:3]
NAPCO
      Reports Results for Three and Six Months Ended December 31, 2011

[0001157523-12-000774:8k_2_02:4]
-
      Management to Host Conference Call Today at 11AM –

[0001157523-12-000774:8k_2_02:5]
AMITYVILLE, N.Y.--(BUSINESS WIRE)--February 13, 2012--NAPCO Security
      Technologies, Inc., (NASDAQ:NSSC), one of the world’s leading
      suppliers of high performance electronic security equipment for over 40
      years, today announced financial results for the second quarter and
      first six months ended December 31, 2011.

[0001157523-12-000774:8k_2_02:6]
Highlights:

[0001157523-12-000774:8k_2_02:7]
Net sales for the second quarter remained constant at $17,617,000 as
      compared to $17,608,000 a year ago.

[0001157523-12-000774:8k_2_02:8]
Adjusted EBITDA* for the second quarter increased $290,000, or
      25%, to $1,437,000 as compared to $1,147,000 for the same period a year
      ago (see table attached). For the six months ended December 31,
      2011 Adjusted EBITDA* increased $576,000, or 46%, to $1,841,000 from
      $1,265,000 for the same period a year ago.

[0001157523-12-000774:8k_2_02:9]
Net income for the second quarter increased $152,000 or 97% to
      $309,000, or $0.02 per share, as compared to $157,000, or $0.01, per
      share for the same period a year ago. Net income for the six months
      ended December 31, 2011 increased $1,119,000 to $142,000, or $0.01 per
      share, as compared to $(977,000), or $(0.05), per share for the same
      period a year ago. Per share results are based on 19,256,000 and
      19,176,000 fully diluted weighted average shares for the three and six
      months ended December 31, 2011, respectively, and 19,096,000 fully
      diluted weighted average shares for both the three and six months ended
      December 31, 2010.

[0001157523-12-000774:8k_2_02:10]
Cash generated by operating activities was approximately $0.4 million
      for the three months ended December 31, 2011 as compared to $1.0 million
      for the same period a year ago.

[0001157523-12-000774:8k_2_02:11]
Debt, net of cash, has been reduced by $16.2 million from $35.9
      million to $19.7 million since acquiring Marks USA in August of 2008.

[0001157523-12-000774:8k_2_02:12]
Gross Profit for the three months ended December 31, 2011 was
      $4,895,000, an increase of 4% compared to $4,690,000 for same period a
      year ago. Gross Profit for the six months ended December 31, 2011 was
      $9,051,000, an increase of 12% compared to $8,113,000 for same period a
      year ago.

[0001157523-12-000774:8k_2_02:13]
Selling, general and administrative expenses for the three months ended
      December 31, 2011 decreased by 4% to $4,000,000 as compared to
      $4,159,000 for the same quarter a year ago. Selling, general and
      administrative expenses remained constant at $8,298,000 and $8,299,000
      for the six months ended December 31, 2011 and 2010, respectively.

[0001157523-12-000774:8k_2_02:14]
Operating income for the three months ended December 31, 2011 increased
      by $364,000, or 69%, to $895,000 as compared to $531,000 for the same
      quarter a year ago. Operating income for the six months ended December
      31, 2011 increased by $939,000 to $753,000 as compared to $(186,000) for
      the same period a year ago.

[0001157523-12-000774:8k_2_02:15]
Richard Soloway, Chairman and President, stated, “Our second quarter
      concluded with sales holding steady from last year while we reduced
      overhead expenses, increasing our profitability even as we sustained
      ongoing investment in Research and Development. Historically, our
      quarters get seasonally stronger as the fiscal year progresses. We
      continue to reduce our outstanding debt, paying down $1.8 million in the
      first six months of this fiscal year, resulting in reduced interest
      expense.”

[0001157523-12-000774:8k_2_02:16]
Mr. Soloway added, “The rollout and education process of launching our
      new products is progressing nicely and is being well received by the
      many thousands of dealers and distributors in our sales channel. This
      endeavor of generating awareness, trial and subsequent adoption is
      underway with our Gemini Commercial™ integrated fire and intrusion
      product platform, our Networx™ wireless locking system and our recurring
      revenue products, featuring the iSeeVideo™ remote viewing system as well
      as the Starlink 2™ wireless GSM communicator. We are optimistic that
      these products will add sales volume to the legacy products for which
      the Company is so well known.”

[0001157523-12-000774:8k_2_02:17]
Mr. Soloway concluded, “The past few years have been challenging for all
      companies. NAPCO has risen to this challenge and we are a stronger, more
      stream-lined and better company as a reward for our efforts. We have
      reduced expenses while still bringing new and exciting products to the
      security market. With continued vigilance, we see a strong upside to the
      Company’s future as economic conditions improve and revenue from the
      aforementioned new products increases.”

[0001157523-12-000774:8k_2_02:18]
NAPCO will host a conference call for the investment community
      today, February 13, 2012, at 11:00 AM ET. Interested parties may
      participate in the call by dialing (877) 407-8291; international callers
      dial (201) 689-8345 about 5-10 minutes prior to 11:00 AM ET. The
      conference call will also be available on replay starting at 1:00 PM ET
      on February 13, 2012 and ending on February 27, 2012. For the replay,
      please dial (877) 660-6853 (replay account # 332, replay conference
      #388361). The access number for the replay for international callers is
      (201) 612-7415 (replay account # 332, replay conference #388361).

[0001157523-12-000774:8k_2_02:19]
About NAPCO Security Technologies, Inc.

[0001157523-12-000774:8k_2_02:20]
NAPCO Security Technologies, Inc. is one of the world's leading
      manufacturers of technologically advanced electronic security equipment
      including intrusion and fire alarm systems, access control and door
      locking systems. The Company consists of NAPCO plus three wholly-owned
      subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. The
      products are installed by security professionals worldwide in
      commercial, industrial, institutional, residential and government
      applications. NAPCO products have earned a reputation for technical
      excellence, reliability and innovation, poising the Company for growth
      in the rapidly expanding electronic security market, a multi-billion
      dollar market.

[0001157523-12-000774:8k_2_02:21]
For additional information on NAPCO, please visit the Company's web site
      at www.napcosecurity.com.

[0001157523-12-000774:8k_2_02:22]
This press release contains forward-looking statements that involve
      numerous risks and uncertainties. Actual results, performance or
      achievements could differ materially from those anticipated in such
      forward-looking statements as a result of certain factors, including
      those set forth in the Company's filings with the Securities and
      Exchange Commission.

[0001157523-12-000774:8k_2_02:23]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| ASSETS | December 31, 2011 |  |  |  | June 30, 2011 |
|  | (unaudited) |  |  |  | (audited) |
|  | (In thousands except share data) |
| CURRENT ASSETS |  |  |  |  |  |
| Cash and cash equivalents | $ | 2,254 |  |  |  |  | $ | 3,077 |  |
| Accounts receivable, net of reserves |  | 14,410 |  |  |  |  |  | 17,640 |  |
| Inventories |  | 21,085 |  |  |  |  |  | 19,986 |  |
| Prepaid expenses and other current assets |  | 761 |  |  |  |  |  | 950 |  |
| Income tax receivable |  | 78 |  |  |  |  |  | -- |  |
| Deferred income taxes |  | 543 |  |  |  |  |  | 528 |  |
| Total Current Assets |  | 39,131 |  |  |  |  |  | 42,181 |  |
| Inventories - non-current, net |  | 4,528 |  |  |  |  |  | 4,201 |  |
| Deferred income taxes |  | 1,992 |  |  |  |  |  | 2,083 |  |
| Property, plant and equipment, net |  | 7,432 |  |  |  |  |  | 7,741 |  |
| Intangible assets, net |  | 11,783 |  |  |  |  |  | 12,316 |  |
| Other assets |  | 292 |  |  |  |  |  | 273 |  |
| TOTAL ASSETS | $ | 65,158 |  |  |  |  | $ | 68,795 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |
| Current maturities of long-term debt | $ | 12,172 |  | * |  |  | $ | 3,572 |  |
| Accounts payable |  | 4,400 |  |  |  |  |  | 4,649 |  |
| Accrued expenses |  | 1,731 |  |  |  |  |  | 2,553 |  |
| Income tax payable |  | -- |  |  |  |  |  | 437 |  |
| Accrued salaries and wages |  | 1,337 |  |  |  |  |  | 1,785 |  |
| Total Current Liabilities |  | 19,640 |  |  |  |  |  | 12,996 |  |
| Long-term debt, net of current maturities |  | 9,819 |  |  |  |  |  | 20,205 |  |
| Accrued income taxes |  | 120 |  |  |  |  |  | 165 |  |
| Total Liabilities |  | 29,579 |  |  |  |  |  | 33,366 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 20,095,713 shares issued; 19,095,713 shares outstanding |  | 201 |  |  |  |  |  | 201 |  |
| Additional paid-in capital |  | 14,080 |  |  |  |  |  | 14,072 |  |
| Retained earnings |  | 26,913 |  |  |  |  |  | 26,771 |  |
|  |  | 41,194 |  |  |  |  |  | 41,044 |  |
| Less: Treasury Stock, at cost (1,000,000 shares) |  | (5,615 | ) |  |  |  |  | (5,615 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  | 35,579 |  |  |  |  |  | 35,429 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY | $ | 65,158 |  |  |  |  | $ | 68,795 |  |

[0001157523-12-000774:8k_2_02:24]
* Our existing revolving line of credit expires in August 2012.
      Accordingly, we have classified its balance as a current liability as of
      December 31, 2011. We plan to refinance or extend this line prior to its
      expiration date.

[0001157523-12-000774:8k_2_02:25]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (Unaudited) |
|  |  | Three months ended December 31, |  | Six months ended December 31, |
|  |  |  | 2011 |  |  | 2010 |  |  |  | 2011 |  |  |  | 2010 |  |
|  |  | (In thousands, except share and per share data) |
| Net sales |  | $ | 17,617 |  | $ | 17,608 |  |  | $ | 33,820 |  |  | $ | 32,935 |  |
| Cost of sales |  |  | 12,722 |  |  | 12,918 |  |  |  | 24,769 |  |  |  | 24,822 |  |
| Gross Profit |  |  | 4,895 |  |  | 4,690 |  |  |  | 9,051 |  |  |  | 8,113 |  |
| Selling, general, and administrative expenses |  |  | 4,000 |  |  | 4,159 |  |  |  | 8,298 |  |  |  | 8,299 |  |
| Operating Income (Loss) |  |  | 895 |  |  | 531 |  |  |  | 753 |  |  |  | (186 | ) |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 298 |  |  | 411 |  |  |  | 602 |  |  |  | 1,005 |  |
| Other, net |  |  | 13 |  |  | 14 |  |  |  | 27 |  |  |  | 28 |  |
|  |  |  | 311 |  |  | 425 |  |  |  | 629 |  |  |  | 1,033 |  |
| Income (Loss) before Provision (Benefit) for Income Taxes |  |  | 584 |  |  | 106 |  |  |  | 124 |  |  |  | (1,219 | ) |
| Provision (Benefit) for income taxes |  |  | 275 |  |  | (51 | ) |  |  | (18 | ) |  |  | (242 | ) |
| Net Income (Loss) |  | $ | 309 |  | $ | 157 |  |  | $ | 142 |  |  | $ | (977 | ) |
| Income (Loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  | $ | 0.01 |  |  | $ | 0.01 |  |  | $ | (0.05 | ) |
| Diluted |  | $ | 0.02 |  | $ | 0.01 |  |  | $ | 0.01 |  |  | $ | (0.05 | ) |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,096,000 |  |  | 19,096,000 |  |  |  | 19,096,000 |  |  |  | 19,096,000 |  |
| Diluted |  |  | 19,256,000 |  |  | 19,096,000 |  |  |  | 19,176,000 |  |  |  | 19,096,000 |  |

[0001157523-12-000774:8k_2_02:26]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (Unaudited) |
|  | Six months ended December 31, |
|  |  | 2011 |  |  |  | 2010 |  |
|  | (in thousands) |
| CASH FLOWS FROM OPERATING ACTIVITIES |  |  |  |
| Net Income (Loss) | $ | 142 |  |  | $ | (977 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization |  | 1,080 |  |  |  | 1,128 |  |
| Provision for doubtful accounts |  | (5 | ) |  |  | (65 | ) |
| Deferred income taxes |  | 76 |  |  |  | 170 |  |
| Stock based compensation expense |  | 8 |  |  |  | 38 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable |  | 3,235 |  |  |  | 4,069 |  |
| Inventories |  | (1,425 | ) |  |  | (431 | ) |
| Prepaid expenses and other current assets |  | 189 |  |  |  | 172 |  |
| Income tax receivable |  | (78 | ) |  |  | (423 | ) |
| Other assets |  | (46 | ) |  |  | 5 |  |
| Accounts payable and accrued expenses |  | (2,002 | ) |  |  | (2,470 | ) |
| Net Cash Provided by Operating Activities |  | 1,174 |  |  |  | 1,216 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES |  |  |  |
| Purchases of property, plant, and equipment |  | (211 | ) |  |  | (282 | ) |
| Net Cash Used in Investing Activities |  | (211 | ) |  |  | (282 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES |  |  |  |
| Principal payments on long-term debt |  | (1,786 | ) |  |  | (3,679 | ) |
| Net Cash Used in Financing Activities |  | (1,786 | ) |  |  | (3,679 | ) |
| Net Decrease in Cash and Cash Equivalents |  | (823 | ) |  |  | (2,745 | ) |
| CASH AND CASH EQUIVALENTS - Beginning |  | 3,077 |  |  |  | 5,522 |  |
| CASH AND CASH EQUIVALENTS - Ending | $ | 2,254 |  |  | $ | 2,777 |  |
| SUPPLEMENTAL CASH FLOW INFORMATION |  |  |  |
| Interest paid, net | $ | 750 |  |  | $ | 942 |  |
| Income taxes paid | $ | 467 |  |  | $ | 5 |  |

[0001157523-12-000774:8k_2_02:27]
| NAPCO SECURITY TECHNOLOGIES, INC. |
| NON-GAAP MEASURES OF PERFORMANCE* (Unaudited) |
| (in thousands) |
|  |  | 3 months ended December 31, |  |  | 6 months ended December 31, |
|  |  |  | 2011 |  | 2010 |  |  |  |  | 2011 |  |  | 2010 |  |
| Net income (loss) (GAAP) |  | $ | 309 | $ | 157 |  |  |  | $ | 142 |  | $ | (977 | ) |
| Add back provision (benefit) for income taxes |  |  | 275 |  | (51 | ) |  |  |  | (18 | ) |  | (242 | ) |
| Add back interest and other expense |  |  | 311 |  | 425 |  |  |  |  | 629 |  |  | 1,033 |  |
| Operating income (loss) (GAAP) |  |  | 895 |  | 531 |  |  |  |  | 753 |  |  | (186 | ) |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 267 |  | 288 |  |  |  |  | 533 |  |  | 576 |  |
| Add back stock-based compensation expense |  |  | 1 |  | 15 |  |  |  |  | 8 |  |  | 38 |  |
| Add back costs relating to Marks acquisition and consolidation |  |  | -- |  | -- |  |  |  |  | -- |  |  | 216 |  |
| Add back costs associated with waivers and amendments to credit facilities |  |  | -- |  | 34 |  |  |  |  | -- |  |  | 69 |  |
| Adjusted non-GAAP operating income |  |  | 1,163 |  | 868 |  |  |  |  | 1,294 |  |  | 713 |  |
| Add back depreciation |  |  | 274 |  | 279 |  |  |  |  | 547 |  |  | 552 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,437 | $ | 1,147 |  |  |  | $ | 1,841 |  | $ | 1,265 |  |

[0001157523-12-000774:8k_2_02:28]
* Non-GAAP Information. Certain non-GAAP measures are included in this
      press release, including EBITDA, non-GAAP operating income and Adjusted
      EBITDA. We define EBITDA as GAAP net income (loss) plus income tax
      expense (benefit), net interest expense and depreciation and
      amortization expense. Non-GAAP operating income does not include
      impairment of goodwill, amortization of intangibles, restructuring
      charges, stock-based compensation expense and other infrequent or
      unusual charges. These non-GAAP measures are provided to enhance the
      user’s overall understanding of our financial performance. By excluding
      these charges our non-GAAP results provide information to management and
      investors that is useful in assessing NAPCO’s core operating performance
      and in comparing our results of operations on a consistent basis from
      period to period. The presentation of this information is not meant to
      be a substitute for the corresponding financial measures prepared in
      accordance with generally accepted accounting principles. Investors are
      encouraged to review the reconciliation of GAAP to non-GAAP financial
      measures included in the above.

[0001157523-12-000774:8k_2_02:29]
CONTACT:
INVESTOR INQUIRIES:
Wolfe Axelrod Associates
Donald
      Weinberger, 212-370-4500
don@wolfeaxelrod.com
or
Hayden
      IR
Brett Maas, 646-536-7331
brett@haydenir.com
or
James
      Carbonara, Regional Vice President
646-755-7412
917-340-1339 (cell)
james@haydenir.com
or
NAPCO:
Richard
      Soloway, CEO
631-842-9400, ext. 120
rsoloway@napcosecurity.com
or
Kevin
      Buchel, CFO
631-842-9400, ext. 120
kbuchel@napcosecurity.com
