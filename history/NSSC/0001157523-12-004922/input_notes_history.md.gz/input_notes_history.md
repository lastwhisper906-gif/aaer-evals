# NSSC note change history — 0001157523-12-000715 → 0001157523-12-002854


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-05-14):
[0001157523-12-002854:note_history:1]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the periods ended March 31, 2012 are not necessarily
indicative of results that may be expected for any other interim
period or for the full year.
  (was, 2012-02-13, similarity 0.9832):
[0001157523-12-000715:note_history:1]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the periods ended December 31, 2011 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

- changed (2012-05-14):
[0001157523-12-002854:note_history:2]
In
the ordinary course of business, the Company has established a
reserve for doubtful accounts and customer deductions in the amount
of $255,000 as of March 31, 2012 and June 30, 2011. The
Company’s reserve for doubtful accounts is a subjective
critical estimate that has a direct impact on reported net
earnings. This reserve is based upon the evaluation of accounts
receivable agings, specific exposures and historical
trends.
  (was, 2012-02-13, similarity 0.9481):
[0001157523-12-000715:note_history:2]
In
the ordinary course of business, the Company has established a
reserve for doubtful accounts and customer deductions in the amount
of $250,000 and $255,000 as of December 31, 2011 and June 30, 2011,
respectively. The Company’s reserve for doubtful accounts is
a subjective critical estimate that has a direct impact on reported
net earnings. This reserve is based upon the evaluation of accounts
receivable agings, specific exposures and historical
trends.

- changed (2012-05-14):
[0001157523-12-002854:note_history:3]
The
Company had one customer with an accounts receivable balance that
represents 17% of the Company’s accounts receivable at March
31, 2012 and June 30, 2011.  Sales to this customer did
not exceed 10% of net sales in any of the past three fiscal
years.
  (was, 2012-02-13, similarity 0.9281):
[0001157523-12-000715:note_history:3]
The
Company had one customer with an accounts receivable balance that
represents 16% of the Company’s accounts receivable at
December 31, 2011 and 17% at June 30, 2011.  Sales to
this customer did not exceed 10% of net sales in any of the past
three fiscal years.

- changed (2012-05-14):
[0001157523-12-002854:note_history:4]
Long-Lived
and Intangible Assets
  (was, 2012-02-13, similarity 0.6939):
[0001157523-12-000715:note_history:4]
Intangible
Assets

- changed (2012-05-14):
[0001157523-12-002854:note_history:5]
|  |  | March 31, 2012 |  |  | June 30, 2011 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,347 | ) |  | $ | 5,453 |  |  | $ | 9,800 |  |  | $ | (3,584 | ) |  | $ | 6,216 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (176 | ) |  |  | 164 |  |  |  | 340 |  |  |  | (140 | ) |  |  | 200 |  |
| Trademark |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (4,523 | ) |  | $ | 11,517 |  |  | $ | 16,040 |  |  | $ | (3,724 | ) |  | $ | 12,316 |  |
  (was, 2012-02-13, similarity 0.9889):
[0001157523-12-000715:note_history:5]
|  |  | December 31, 2011 |  |  | June 30, 2011 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,093 | ) |  | $ | 5,707 |  |  | $ | 9,800 |  |  | $ | (3,584 | ) |  | $ | 6,216 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (164 | ) |  |  | 176 |  |  |  | 340 |  |  |  | (140 | ) |  |  | 200 |  |
| Trademark |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (4,257 | ) |  | $ | 11,783 |  |  | $ | 16,040 |  |  | $ | (3,724 | ) |  | $ | 12,316 |  |

- changed (2012-05-14):
[0001157523-12-002854:note_history:6]
Amortization
expense for intangible assets was approximately $266,000 and
$288,000 for the three months ended March 31, 2012 and 2011,
respectively. Amortization expense for intangible assets was
approximately $799,000 and $865,000 for the nine months ended March
31, 2012 and 2011, respectively. Amortization expense for each of
the next five years is estimated to be as follows: 2012 -
$1,065,000; 2013 - $917,000; and 2014 - $781,000; 2015 - $667,000
and 2016 - $529,000. The weighted average amortization period for
intangible assets was 16.0 years and 16.7 years at March
31, 2012 and June 30, 2011, respectively.
  (was, 2012-02-13, similarity 0.8868):
[0001157523-12-000715:note_history:6]
Amortization
expense for intangible assets subject to amortization was
approximately $266,000 and $288,000 for the three months ended
December 31, 2011 and 2010, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$533,000 and $577,000 for the six months ended December 31, 2011
and 2010, respectively. Amortization expense for each of the next
five years is estimated to be as follows: 2012 - $1,065,000; 2013 -
$917,000; and 2014 - $781,000; 2015 - $667,000 and 2016 - $529,000.
The weighted average amortization period for intangible assets was
16.2 years and 16.7 years at December 31, 2011 and June
30, 2011, respectively.

- changed (2012-05-14):
[0001157523-12-002854:note_history:7]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the condensed consolidated statements
of operations and are expensed as incurred.  Advertising
expense for the three months ended March 31, 2012 and 2011 was
$388,000 and $62,000, respectively. Advertising expense for the
nine months ended March 31, 2012 and 2011 was $871,000 and
$423,000, respectively. The increase for the three months ended
March 31, 2012 is due to the timing of a tradeshow that occurred in
March 2012 plus increased spending on media and printed
advertising. Last year, the same tradeshow occurred in the quarter
ended June 30, 2011. The increase for the nine months ended March
31, 2012 is due to increased spending on tradeshows and media and
printed advertising.
  (was, 2012-02-13, similarity 0.7762):
[0001157523-12-000715:note_history:7]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the condensed consolidated statements
of operations and are expensed as incurred.  Advertising
expense for the three months ended December 31, 2011 and 2010 was
$232,000 and $270,000, respectively. Advertising expense for the
six months ended December 31, 2011 and 2010 was $483,000 and
$361,000, respectively. The decrease for the three months ended
December 31, 2011 is due to the timing of a tradeshow that occurred
in September 2011 as partially offset by increased spending on this
tradeshow in the current fiscal year as well as on media and
printed advertising. Last year, the same tradeshow occurred in the
quarter ended December 31, 2010. The increase for the six months
ended December 31, 2011 is due to increased spending on tradeshows
and media and printed advertising.

- changed (2012-05-14):
[0001157523-12-002854:note_history:8]
Research
and development costs are included in "Cost of Sales" in the
condensed consolidated statements of operations and are expensed as
incurred. Research and development expense for the three months
ended March 31, 2012 and 2011 was $1,094,000 and $935,000,
respectively. Research and development expense for the nine months
ended March 31, 2012 and 2011 was $3,134,000 and $3,420,000,
respectively.
  (was, 2012-02-13, similarity 0.9144):
[0001157523-12-000715:note_history:8]
Research
and development costs are included in "Cost of Sales" in the
condensed consolidated statements of operations and are expensed as
incurred. Research and development expense for the three months
ended December 31, 2011 and 2010 was $1,009,000 and $1,218,000,
respectively. Research and development expense for the six months
ended December 31, 2011 and 2010 was $2,040,000 and $2,485,000,
respectively.

- changed (2012-05-14):
[0001157523-12-002854:note_history:9]
During
the three and nine months ended March 31, 2012 no stock options
were granted or exercised under its 2002 Employee Incentive Stock
Option Plan or under its 2000 Non-employee Incentive Stock Option
Plan.
  (was, 2012-02-13, similarity 0.9646):
[0001157523-12-000715:note_history:9]
During
the three and six months ended December 31, 2011 no stock options
were granted or exercised under its 2002 Employee Incentive Stock
Option Plan or under its 2000 Non-employee Incentive Stock Option
Plan.

- changed (2012-05-14):
[0001157523-12-002854:note_history:10]
Employee Health Benefit Plan
  (was, 2012-02-13, similarity 0.8235):
[0001157523-12-000715:note_history:10]
Self-funded
Employee Health Benefit Plan

- added (2012-05-14):
[0001157523-12-002854:note_history:11]
Effective March 1, 2012, the Company converted its employee health
benefit plan from a self-insured plan back to a fully-insured plan
due to the significant amounts of medical claims incurred. The
Company feels that the significant claim levels will continue and
that the cost of a fully-insured plan will be less than that of the
self-insured plan.

- added (2012-05-14):
[0001157523-12-002854:note_history:12]
As of January 31, 2012 (the termination date of this insurance
policy) and at June 30, 2011, the aggregate limit of claims to be
self-insured was approximately $1,372,000 and $1,409,000,
respectively. Claims submitted after January 31, 2012 for services
performed prior to the commencement of the fully-insured plan on
March 1, 2012 are not covered by this insurance policy and are to
be paid by the Company. Since March 1, 2012, the Company has
incurred approximately $200,000 in these uninsured, run-out claims
in addition to the premiums incurred for the fully-insured benefit
policy. In connection with these self-insured liabilities, the
Company has accrued $296,000 and $150,000 as of March 31, 2012 and
June 30, 2011, respectively.

- changed (2012-05-14):
[0001157523-12-002854:note_history:13]
In
May 2011, the FASB amended its authoritative guidance related
to fair value measurements to provide a consistent definition and
measurement of fair value, as well as similar disclosure
requirements between U.S. GAAP and International Financial
Reporting Standards.  This guidance clarifies the application
of existing fair value measurement and expands the existing
disclosure requirements.  This guidance became effective for
the Company’s fiscal 2012 third quarter.  This guidance did not
have a material impact on the Company’s results of
operations, financial position or cash flows.
  (was, 2012-02-13, similarity 0.9406):
[0001157523-12-000715:note_history:13]
In
May 2011, the FASB amended its authoritative guidance related
to fair value measurements to provide a consistent definition and
measurement of fair value, as well as similar disclosure
requirements between U.S. GAAP and International Financial
Reporting Standards.  This guidance clarifies the application
of existing fair value measurement and expands the existing
disclosure requirements.  This guidance becomes effective for
the Company’s fiscal 2012 third quarter.  This guidance is not
expected to have a material impact on the Company’s results
of operations, financial position or cash flows, but may require
additional disclosures.

- removed (2012-05-14):
[0001157523-12-000715:note_history:14]
Long-Lived
Assets

- removed (2012-05-14):
[0001157523-12-000715:note_history:15]
Effective
February 1, 2011, the Company converted its employee health benefit
plan from a fully-insured plan to a self-insured plan. The Company
made this change due, primarily, to significant increases in health
insurance costs over the past few years. Under this arrangement,
the Company engaged a plan administrator to process claims and
purchased an insurance policy that covers claims over a certain
aggregate amount over the plan year. The aggregate limit is based
on the number of employees enrolled in the plan. As of December 31,
2011 and June 30, 2011, the aggregate limit of claims to be
self-insured was approximately $1,374,000 and $1,409,000,
respectively. The Company records claims as they are paid and
records an accrual for unpaid claims based upon the date of service
or date incurred. In connection with this self-insured liability,
the Company has accrued $227,000 and $150,000 as of December 31,
2011 and June 30, 2011, respectively.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-05-14):
[0001157523-12-002854:note_history:16]
As
of March 31, 2012 and June 30, 2011, long-term debt consisted of a
revolving credit loan facility of $11,100,000, of which $8,600,000
was outstanding as of March 31, 2012 and June 30, 2011, as well as
a term loan with a remaining balance of $12,498,000 and $15,177,000
as of March 31, 2012 and June 30, 2011, respectively, as described
further below. The term loan is being repaid in 19 quarterly
installments of $893,000 each which commenced in December 2008, and
a final payment of $8,033,000 due in August 2013. The revolving
line of credit expires in August 2012 and any outstanding
borrowings are to be repaid or refinanced on or before that
time.
  (was, 2012-02-13, similarity 0.6027):
[0001157523-12-000715:note_history:16]
As
of December 31, 2011 and June 30, 2011, long-term debt consisted of
a revolving credit loan facility of $11,100,000 as well as a term
loan with a remaining balance of $13,391,000 and $15,177,000,
respectively, as described further below. The term loan is being
repaid in 19 quarterly installments of $893,000 each which
commenced in December 2008, and a final payment of $8,033,000 due
in August 2013. The revolving line of credit expires in August 2012
and any outstanding borrowings are to be repaid or refinanced on or
before that time. The Company intends to refinance or extend the
revolving line of credit prior to the expiration date. However, the
revolving credit loan has been classified as a current liability
until such time that the Company might renew or extend the facility
because the expiration date currently falls within one year of the
balance sheet date of December 31, 2011.

- added (2012-05-14):
[0001157523-12-002854:note_history:17]
The
Company intends to extend the revolving line of credit and the term
loan prior to the expiration dates and has signed a term sheet
relating to an extension with its primary bank in May 2012.
However, because there is no guarantee that this agreement will
close, the revolving credit loan has been classified as a current
liability until such time that the Company consummates a renewal or
extension of the facility because the expiration date currently
falls within one year of the balance sheet date of March 31,
2012.

- changed (2012-05-14):
[0001157523-12-002854:note_history:18]
Outstanding
balances and interest rates as of March 31, 2012 and June 30, 2011
are as follows:
  (was, 2012-02-13, similarity 0.9474):
[0001157523-12-000715:note_history:18]
Outstanding
balances and interest rates as of December 31, 2011 and June 30,
2011 are as follows:

- changed (2012-05-14):
[0001157523-12-002854:note_history:19]
|  |  | March 31, 2012 |  |  | June 30, 2011 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 8,600 |  |  |  | 4.87 | % |  | $ | 8,600 |  |  |  | 4.82 | % |
| Term loan |  |  | 12,498 |  |  |  | 4.86 | % |  |  | 15,177 |  |  |  | 4.82 | % |
| Total debt |  | $ | 21,098 |  |  |  | 4.86 | % |  | $ | 23,777 |  |  |  | 4.82 | % |
  (was, 2012-02-13, similarity 0.9825):
[0001157523-12-000715:note_history:19]
|  |  | December 31, 2011 |  |  | June 30, 2011 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 8,600 |  |  |  | 4.90 | % |  | $ | 8,600 |  |  |  | 4.82 | % |
| Term loan |  |  | 13,391 |  |  |  | 4.93 | % |  |  | 15,177 |  |  |  | 4.82 | % |
| Total debt |  | $ | 21,991 |  |  |  | 4.92 | % |  | $ | 23,777 |  |  |  | 4.82 | % |
