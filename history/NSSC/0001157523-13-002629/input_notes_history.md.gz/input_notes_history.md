# NSSC note change history — 0001157523-13-000703 → 0001157523-13-002629


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-05-13):
[0001157523-13-002629:note_history:1]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $14,000 and $12,000 for the three months ended
March 31, 2013 and 2012, respectively and $37,000 and $38,000
for the nine months ended March 31, 2013 and 2012,
respectively.
  (was, 2013-02-12, similarity 0.7776):
[0001157523-13-000703:note_history:1]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $12,000 and $13,000 for each of the three months
ended December 31, 2012 and 2011, respectively and $23,000 and
$26,000 for each of the six months ended December 31, 2012 and
2011, respectively.

- changed (2013-05-13):
[0001157523-13-002629:note_history:2]
As
of March 31, 2013, the Company was obligated under two employment
agreements and one severance agreement.  The employment
agreements are with the Company’s Chief Executive Officer
(“the CEO”) and Senior Vice President of Sales and
Marketing (“the SVP”). The employment agreement with
the CEO provides for an annual salary of $587,000, as adjusted for
inflation; incentive compensation as may be approved by the Board
of Directors from time to time and a termination payment in an
amount up to 299% of the average of the prior five calendar year's
compensation, subject to certain limitations, as defined in the
agreement.  The employment agreement renews annually in
August unless either party gives the other notice of non-renewal at
least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.
  (was, 2013-02-12, similarity 0.9937):
[0001157523-13-000703:note_history:2]
As
of December 31, 2012, the Company was obligated under two
employment agreements and one severance agreement.  The
employment agreements are with the Company’s Chief Executive
Officer (“the CEO”) and Senior Vice President of Sales
and Marketing (“the SVP”). The employment agreement
with the CEO provides for an annual salary of $587,000, as adjusted
for inflation; incentive compensation as may be approved by the
Board of Directors from time to time and a termination payment in
an amount up to 299% of the average of the prior five calendar
year's compensation, subject to certain limitations, as defined in
the agreement.  The employment agreement renews annually
in August unless either party gives the other notice of non-renewal
at least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-05-13):
[0001157523-13-002629:note_history:3]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended March 31, 2013 are not necessarily
indicative of results that may be expected for any other interim
period or for the full year.
  (was, 2013-02-12, similarity 0.9831):
[0001157523-13-000703:note_history:3]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended December 31, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

- changed (2013-05-13):
[0001157523-13-002629:note_history:4]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries. All inter-company balances and transactions have been
eliminated in consolidation.
  (was, 2013-02-12, similarity 0.7201):
[0001157523-13-000703:note_history:4]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries, including those of Marks USA I, LLC
(“Marks”), a subsidiary which acquired substantially
all of the assets and certain liabilities of G. Marks Hardware Inc.
on August 18, 2008. All inter-company balances and transactions
have been eliminated in consolidation.

- changed (2013-05-13):
[0001157523-13-002629:note_history:5]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at March 31, 2013 and June 30, 2012.  The
Company considers all highly liquid investments with original
maturities of three months or less to be cash
equivalents.  The Company has cash balances in banks in
excess of the maximum amount insured by the FDIC and other
international agencies as of March 31, 2013 and June 30,
2012.
  (was, 2013-02-12, similarity 0.9662):
[0001157523-13-000703:note_history:5]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at December 31, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of December 31, 2012 and June 30,
2012.

- changed (2013-05-13):
[0001157523-13-002629:note_history:6]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,045,000 and $1,184,000 as of March 31, 2013 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.
  (was, 2013-02-12, similarity 0.9883):
[0001157523-13-000703:note_history:6]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,075,000 and $1,184,000 as of December 31, 2012 and June 30,
2012, respectively.  Our reserves for doubtful accounts
and for returns and other allowances are subjective critical
estimates that have a direct impact on reported net earnings. These
reserves are based upon the evaluation of accounts receivable
agings, specific exposures, sales levels and historical
trends.

- changed (2013-05-13):
[0001157523-13-002629:note_history:7]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets recorded at
fair value on the date of acquisition. The intangible assets are
amortized over their estimated useful lives of twenty years
(customer relationships) and seven years (non-compete agreement).
The Marks USA trade name was deemed to have an indefinite
life.
  (was, 2013-02-12, similarity 0.9419):
[0001157523-13-000703:note_history:7]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life.

- changed (2013-05-13):
[0001157523-13-002629:note_history:8]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,252 | ) |  | $ | 4,548 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (225 | ) |  |  | 115 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,477 | ) |  | $ | 10,563 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |
  (was, 2013-02-12, similarity 0.9889):
[0001157523-13-000703:note_history:8]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,035 | ) |  | $ | 4,765 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (213 | ) |  |  | 127 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,248 | ) |  | $ | 10,792 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

- changed (2013-05-13):
[0001157523-13-002629:note_history:9]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
March 31, 2013 and 2012, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$688,000 and $799,000 for the nine months ended March 31, 2013 and
2012, respectively. Amortization expense for each of the next five
fiscal years is estimated to be as follows: 2013 - $917,000; 2014 -
$781,000; 2015 - $667,000; 2016 - $529,000 and 2017 - $441,000. The
weighted average amortization period for intangible assets was 15.1
years and 15.8 years at March 31, 2013 and June 30, 2012,
respectively.
  (was, 2013-02-12, similarity 0.9346):
[0001157523-13-000703:note_history:9]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
December 31, 2012 and 2011, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$459,000 and $533,000 for the six months ended December 31, 2012
and 2011, respectively. Amortization expense for each of the next
five fiscal years is estimated to be as follows: 2013 - $917,000;
2014 - $781,000; 2015 - $667,000; 2016 - $529,000 and 2017 -
$441,000. The weighted average amortization period for intangible
assets was 15.3 years and 15.8 years at December 31, 2012 and
June 30, 2012, respectively.

- added (2013-05-13):
[0001157523-13-002629:note_history:10]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended March 31, 2013 and 2012 was
$124,000 and $388,000, respectively. Advertising expense for the
nine months ended March 31, 2013 and 2012 was $847,000 and
$871,000, respectively. The decrease for the three months resulted
primarily from the timing of a major tradeshow. Last year this
tradeshow occurred during the quarter ended March 31, 2012 while
this year the same tradeshow occurred subsequent to March 31, 2013.
For the nine months, this decrease was partially offset by
increased expenditures on another major tradeshow and media
advertising as compared to the same period a year ago.

- changed (2013-05-13):
[0001157523-13-002629:note_history:11]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended March 31, 2013 and 2012 was
$1,187,000 and $1,094,000, respectively. Company-sponsored research
and development expense for the nine months ended March 31, 2013
and 2012 was $3,842,000 and $3,134,000, respectively. The increases
for the three and nine months was due primarily to expenses
relating to development of the Company’s iBridge™
tablet computer/touch screen keypad.
  (was, 2013-02-12, similarity 0.906):
[0001157523-13-000703:note_history:11]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended December 31, 2012 and 2011was
$1,319,000 and $1,009,000, respectively. Company-sponsored research
and development expense for the six months ended December 31, 2012
and 2011was $2,655,000 and $2,040,000, respectively. The increases
for the three and six months was due primarily to expenses relating
to development of the Company’s iBridge™ tablet
computer/touch screen keypad.

- changed (2013-05-13):
[0001157523-13-002629:note_history:12]
Net
Income (Loss) Per Share
  (was, 2013-02-12, similarity 0.92):
[0001157523-13-000703:note_history:12]
Income
(Loss) Per Share

- changed (2013-05-13):
[0001157523-13-002629:note_history:13]
|  |  | Three Months Ended March 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,296 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 123 |  |  |  | 313 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,419 |  |  |  | 19,409 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
  (was, 2013-02-12, similarity 0.989):
[0001157523-13-000703:note_history:13]
|  |  | Three Months Ended December 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,154 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 342 |  |  |  | 160 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,496 |  |  |  | 19,256 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |

- changed (2013-05-13):
[0001157523-13-002629:note_history:14]
Options
to purchase 395,750 shares of common stock for the three months
ended March 31, 2013 and 2012 were not included in the computation
of Diluted EPS because their inclusion would be
anti-dilutive.  These options were still outstanding at
the end of the respective periods.
  (was, 2013-02-12, similarity 0.9031):
[0001157523-13-000703:note_history:14]
Options
to purchase 395,750 and 1,250,280 shares of common stock for the
three months ended December 31, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.

- changed (2013-05-13):
[0001157523-13-002629:note_history:15]
|  |  | Nine Months Ended March 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,096 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 157 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,253 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
  (was, 2013-02-12, similarity 0.9847):
[0001157523-13-000703:note_history:15]
|  |  | Six Months Ended December 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | (299 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 80 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,176 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |

- changed (2013-05-13):
[0001157523-13-002629:note_history:16]
Options
to purchase 672,740 and 733,880 shares of common stock for the nine
months ended March 31, 2013 and 2012, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.
  (was, 2013-02-12, similarity 0.9149):
[0001157523-13-000703:note_history:16]
Options
to purchase 681,140 and 1,330,210 shares of common stock for the
six months ended December 31, 2012 and 2011, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.

- added (2013-05-13):
[0001157523-13-002629:note_history:17]
There
were no stock-based compensation costs for the three months ended
March 31, 2013 and 2012. Stock-based compensation costs of $0 and
$8,000 were recognized for the nine months ended March 31, 2013 and
2012, respectively.

- changed (2013-05-13):
[0001157523-13-002629:note_history:18]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and nine months ended March 31, 2013 and
2012.
  (was, 2013-02-12, similarity 0.9442):
[0001157523-13-000703:note_history:18]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and six months ended December 31, 2012
and 2011.

- changed (2013-05-13):
[0001157523-13-002629:note_history:19]
For
the three and nine months ended March 31, 2013 and 2012, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.
  (was, 2013-02-12, similarity 0.9197):
[0001157523-13-000703:note_history:19]
For
the three and six months ended December 31, 2012 and 2011, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

- changed (2013-05-13):
[0001157523-13-002629:note_history:20]
The
Company records the amount billed to customers in net sales
($118,000 and $159,000 for the three months ended March 31, 2013
and 2012, respectively, and $367,000 and $434,000 for the nine
months ended March 31, 2013 and 2012, respectively) and classifies
the costs associated with these revenues in cost of sales ($266,000
and $267,000 for the three months ended March 31, 2013 and 2012,
respectively, and $748,000 and $824,000 for the nine months ended
March 31, 2013 and 2012, respectively).
  (was, 2013-02-12, similarity 0.8541):
[0001157523-13-000703:note_history:20]
The
Company records the amount billed to customers in net sales
($128,000 and $139,000 for the three months ended December 31, 2012
and 2011, respectively, and $249,000 and $275,000 for the six
months ended December 31, 2012 and 2011, respectively) and
classifies the costs associated with these revenues in cost of
sales ($259,000 and $293,000 for the three months ended December
31, 2012 and 2011, respectively, and $482,000 and $557,000 for the
six months ended December 31, 2012 and 2011,
respectively).

- removed (2013-05-13):
[0001157523-13-000703:note_history:21]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended December 31, 2012 and 2011 was
$294,000 and $232,000, respectively. Advertising expense for the
six months ended December 31, 2012 and 2011 was $721,000 and
$483,000, respectively. The increase for the three months resulted
primarily from increased media advertising during the three months
ended December 31, 2012 as compared to the same period a year ago.
The increase for the six months resulted primarily from increased
expenditures on a major tradeshow and additional media advertising
during the six months ended December 31, 2012 as compared to the
same period a year ago.

- removed (2013-05-13):
[0001157523-13-000703:note_history:22]
Stock-based
compensation costs of $0 and $1,000 were recognized for the three
months ended December 31, 2012 and 2011, respectively. Stock-based
compensation costs of $0 and $7,000 were recognized for the six
months ended December 31, 2012 and 2011, respectively.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-05-13):
[0001157523-13-002629:note_history:23]
As
of March 31, 2013, long-term debt consisted of a revolving credit
facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.
  (was, 2013-02-12, similarity 0.9875):
[0001157523-13-000703:note_history:23]
As
of December 31, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

- changed (2013-05-13):
[0001157523-13-002629:note_history:24]
Outstanding
balances and interest rates as of March 31, 2013 and June 30, 2012
are as follows (dollars in thousands):
  (was, 2013-02-12, similarity 0.9585):
[0001157523-13-000703:note_history:24]
Outstanding
balances and interest rates as of December 31, 2012 and June 30,
2012 are as follows (dollars in thousands):

- changed (2013-05-13):
[0001157523-13-002629:note_history:25]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,300 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 16,800 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
  (was, 2013-02-12, similarity 0.9825):
[0001157523-13-000703:note_history:25]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,700 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 17,200 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-05-13):
[0001157523-13-002629:note_history:26]
Outstanding
balances and interest rates as of March 31, 2013 and June 30, 2012
are as follows (dollars in thousands):
  (was, 2013-02-12, similarity 0.9585):
[0001157523-13-000703:note_history:26]
Outstanding
balances and interest rates as of December 31, 2012 and June 30,
2012 are as follows (dollars in thousands):

- changed (2013-05-13):
[0001157523-13-002629:note_history:27]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,300 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 16,800 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
  (was, 2013-02-12, similarity 0.9825):
[0001157523-13-000703:note_history:27]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,700 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 17,200 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
