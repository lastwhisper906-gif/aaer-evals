# NSSC MD&A — 0001157523-13-002629


## mdna

[0001157523-13-002629:mdna:1]
[same as prior period, unchanged from 0001157523-13-000703:mdna:1]

[0001157523-13-002629:mdna:2]
[same as prior period, unchanged from 0001157523-13-000703:mdna:2]

[0001157523-13-002629:mdna:3]
[same as prior period, unchanged from 0001157523-13-000703:mdna:3]

[0001157523-13-002629:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 6% of our revenues for both of the nine month periods ended March 31, 2013 and 2012.

[0001157523-13-002629:mdna:5]
[same as prior period, unchanged from 0001157523-13-000703:mdna:5]

[0001157523-13-002629:mdna:6]
[same as prior period, unchanged from 0001157523-13-000703:mdna:6]

[0001157523-13-002629:mdna:7]
[same as prior period, unchanged from 0001157523-13-000703:mdna:7]

[0001157523-13-002629:mdna:8]
[same as prior period, unchanged from 0001157523-13-000703:mdna:8]

[0001157523-13-002629:mdna:9]
[same as prior period, unchanged from 0001157523-13-000703:mdna:9]

[0001157523-13-002629:mdna:10]
[same as prior period, unchanged from 0001157523-13-000703:mdna:10]

[0001157523-13-002629:mdna:11]
[same as prior period, unchanged from 0001157523-13-000703:mdna:11]

[0001157523-13-002629:mdna:12]
[same as prior period, unchanged from 0001157523-13-000703:mdna:12]

[0001157523-13-002629:mdna:13]
[same as prior period, unchanged from 0001157523-13-000703:mdna:13]

[0001157523-13-002629:mdna:14]
[same as prior period, unchanged from 0001157523-13-000703:mdna:14]

[0001157523-13-002629:mdna:15]
[same as prior period, unchanged from 0001157523-13-000703:mdna:15]

[0001157523-13-002629:mdna:16]
[same as prior period, unchanged from 0001157523-13-000703:mdna:16]

[0001157523-13-002629:mdna:17]
[same as prior period, unchanged from 0001157523-13-000703:mdna:17]

[0001157523-13-002629:mdna:18]
[same as prior period, unchanged from 0001157523-13-000703:mdna:18]

[0001157523-13-002629:mdna:19]
[same as prior period, unchanged from 0001157523-13-000703:mdna:19]

[0001157523-13-002629:mdna:20]
[same as prior period, unchanged from 0001157523-13-000703:mdna:20]

[0001157523-13-002629:mdna:21]
[same as prior period, unchanged from 0001157523-13-000703:mdna:21]

[0001157523-13-002629:mdna:22]
|  |  | Three months ended March 31, (dollars in thousands) |  |  | Nine months ended March 31, (dollars in thousands) |  |
|  |  | 2013 |  |  | 2012 |  |  | % Increase/ (decrease) |  |  | 2013 |  |  | 2012 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 17,163 |  |  | $ | 17,236 |  |  |  | (0.4 | )% |  | $ | 49,591 |  |  | $ | 51,056 |  |  |  | (2.9 | )% |
| Gross profit |  |  | 4,652 |  |  |  | 5,064 |  |  |  | (8.1 | )% |  |  | 13,429 |  |  |  | 14,115 |  |  |  | (4.9 | )% |
| Gross profit as a % of net sales |  |  | 27.1 | % |  |  | 29.4 | % |  |  | (2.3 | )% |  |  | 27.1 | % |  |  | 27.6 | % |  |  | (0.5 | )% |
| Selling, general and administrative |  |  | 4,394 |  |  |  | 4,375 |  |  |  | 0.4 | % |  |  | 13,216 |  |  |  | 12,673 |  |  |  | 4.3 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 25.6 | % |  |  | 25.4 | % |  |  | 0.2 | % |  |  | 26.6 | % |  |  | 24.8 | % |  |  | 1.8 | % |
| Operating income |  |  | 258 |  |  |  | 689 |  |  |  | (62.6 | )% |  |  | 213 |  |  |  | 1,442 |  |  |  | (85.2 | )% |
| Interest expense, net |  |  | 122 |  |  |  | 287 |  |  |  | (57.5 | )% |  |  | 440 |  |  |  | 889 |  |  |  | (50.5 | )% |
| Other expense |  |  | 3 |  |  |  | 15 |  |  |  | (80.0 | )% |  |  | 10 |  |  |  | 42 |  |  |  | (76.2 | )% |
| Provision (benefit) for income taxes |  |  | 22 |  |  |  | 84 |  |  |  | (73.8 | )% |  |  | (49 | ) |  |  | 66 |  |  |  | (174.2 | )% |
| Net income (loss) |  |  | 111 |  |  |  | 303 |  |  |  | (63.4 | )% |  |  | (188 | ) |  |  | 445 |  |  |  | (142.2 | )% |

[0001157523-13-002629:mdna:23]
Sales for the three months ended March 31, 2013 remained relatively constant at $17,163,000 as compared to $17,236,000 for the same period a year ago. Sales for the nine months ended March 31, 2013 decreased by 3% to $49,591,000 as compared to $51,056,000 for the same period a year ago. Sales for the three months reflected decreased sales in the Company’s intrusion ($1,164,000) and access control ($177,000) products as partially offset by an increase in the Company’s door-locking products ($1,268,000). The decrease in sales for the nine months was primarily due to decreased sales in the Company’s intrusion ($2,888,000) and access control ($368,000) products as partially offset by an increase in the Company’s door-locking products ($1,791,000). The decrease in sales of intrusion products for the three and nine months was due primarily to several intrusion customers reducing their inventory levels as well as decreased demand from one of the Company’s large intrusion dealers. Sales for the nine months and to a lesser extent the three months were also negatively impacted by the storm known as Superstorm Sandy, which devastated portions of the Caribbean and the Mid-Atlantic and Northeastern United States with lesser impacts in the Southeastern and Midwestern states and Eastern Canada.

[0001157523-13-002629:mdna:24]
Gross profit for the three months ended March 31, 2013 decreased to $4,652,000 or 27.1% of sales as compared to $5,064,000 or 29.4% of sales for the same period a year ago. Gross profit for the nine months ended March 31, 2013 decreased to $13,429,000 or 27.1% of sales as compared to $14,115,000 or 27.6% of sales for the same period a year ago. The decrease in gross profit for the three and nine months was primarily due to increased expenditures on Research and Development primarily relating to the Company’s iBridge tablet-style keypad and related applications as well as a one-time payment by the Company of $175,000 as settlement of a product licensing dispute. The increases in Research and Development were $93,000 and $708,000 for the three and nine months ended March 31, 2013, respectively, as compared to the same periods a year ago. The decrease in gross profit for the nine months was also due to the decrease in sales for the nine months ended March 31, 2013 as compared to the same period a year ago.

[0001157523-13-002629:mdna:25]
[same as prior period, unchanged from 0001157523-13-000703:mdna:25]

[0001157523-13-002629:mdna:26]
Selling, general and administrative expenses for the three months ended March 31, 2013 remained relatively constant at  $4,394,000, or 25.6% of sales, as compared to $4,375,000, or 25.4% of sales a year ago. Selling, general and administrative expenses for the nine months ended March 31, 2013 increased by $543,000 to $13,216,000, or 26.6% of sales, as compared to $12,673,000, or 24.8% of sales a year ago.

[0001157523-13-002629:mdna:27]
Selling, general and administrative expenses for the three months reflected increased expenses relating to additional sales personnel and advertising and were offset by the timing of a major tradeshow.  Last year this tradeshow occurred during the quarter ended March 31, 2012 while this year the same tradeshow occurred subsequent to March 31, 2013. In addition, the increase in Selling, general and administrative expenses for the nine months was due primarily to these factors as well as to increased expenditures relating to a tradeshow that occurred in the first six months of fiscal years 2013 and 2012.

[0001157523-13-002629:mdna:28]
Interest expense, net for the three months ended March 31, 2013 decreased by $165,000 to $122,000 as compared to $287,000 for the same period a year ago. Interest expense, net for the nine months ended March 31, 2013 decreased by $449,000 to $440,000 as compared to $889,000 for the same period a year ago. The decrease in interest expense for the three and nine months ended March 31, 2013 resulted from lower interest rates charged by the Company’s bank as well as lower outstanding debt in the current period.

[0001157523-13-002629:mdna:29]
The Company’s provision for income taxes for the three months ended March 31, 2013 decreased by $62,000 to $22,000 as compared to $84,000 for the same period a year ago. The Company’s provision for income taxes for the nine months ended March 31, 2013 decreased by $115,000 to a benefit of $(49,000) as compared to a provision of $66,000 for the same period a year ago. The change in the provision (benefit) for income taxes was caused primarily by the changes in consolidated net income as well as the change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations for the three and nine months ended March 31, 2013 as compared to the same periods a year ago. As a result, the Company’s effective rate for income tax was 17% and 22% for the three months ended March 31, 2013 and 2012, respectively, and 21% and 13% for the nine months ended March 31, 2013 and 2012, respectively.

[0001157523-13-002629:mdna:30]
Net income decreased by $192,000 to $111,000 or $0.01 per diluted share for the three months ended March 31, 2013 as compared to $303,000 or $0.02 per diluted share for the same period a year ago. Net income decreased by $633,000 to a loss of $(188,000) or $(0.01) per diluted share for the nine months ended March 31, 2013 as compared to $445,000 or $0.02 per diluted share for the same period a year ago. The changes for the three and nine months ended March 31, 2013 were primarily due to the items as described above.

[0001157523-13-002629:mdna:31]
[same as prior period, unchanged from 0001157523-13-000703:mdna:30]

[0001157523-13-002629:mdna:32]
During the nine months ended March 31, 2013 the Company utilized all of its cash from operations ($2,971,000) and a portion of its cash on hand at June 30, 2012 ($1,237,000 of $2,979,000) to repay outstanding debt ($3,457,000), purchase treasury stock ($435,000) and purchase property, plant and equipment ($316,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-13-002629:mdna:33]
Accounts Receivable at March 31, 2013 decreased $1,876,000 to $14,532,000 as compared to $16,408,000 at June 30, 2012.  This decrease is primarily the result of the lower sales volume during the quarter ended March 31, 2013 as compared to the quarter ended June 30, 2012, which is typically the Company’s highest.

[0001157523-13-002629:mdna:34]
Inventories at March 31, 2013 decreased $854,000 to $22,428,000 as compared to $23,282,000 at June 30, 2012. This decrease is primarily the result of earlier and more accurate forecasting of product demand from the Company’s customers. Non-current inventories increased by $1,295,000 to $5,129,000 at March 31, 2013 from $3,834,000 at June 30, 2012. This increase was due to shifts made in the Company’s forecast of demand by product line.

[0001157523-13-002629:mdna:35]
Accounts payable and accrued expenses decreased $868,000 to $5,698,000 as of March 31, 2013 as compared to $6,566,000 at June 30, 2012.  This decrease is due primarily to the reduction in inventory discussed above.

[0001157523-13-002629:mdna:36]
As of March 31, 2013, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. The Company’s long-term debt is described more fully in Note 7 to the condensed consolidated financial statements.

[0001157523-13-002629:mdna:37]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-13-002629:mdna:38]
As of March 31, 2013 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
