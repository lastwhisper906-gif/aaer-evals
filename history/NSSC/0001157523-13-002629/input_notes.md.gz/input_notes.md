# NSSC notes — 0001157523-13-002629


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001157523-13-002629:notes:1]
[same as prior period, unchanged from 0001157523-13-000703:notes:1]

[0001157523-13-002629:notes:2]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended March 31, 2013 are not necessarily
indicative of results that may be expected for any other interim
period or for the full year.

[0001157523-13-002629:notes:3]
[same as prior period, unchanged from 0001157523-13-000703:notes:3]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-13-002629:notes:4]
[same as prior period, unchanged from 0001157523-13-000703:notes:4]

[0001157523-13-002629:notes:5]
[same as prior period, unchanged from 0001157523-13-000703:notes:5]


## us-gaap:InventoryPolicyTextBlock

[0001157523-13-002629:notes:6]
[same as prior period, unchanged from 0001157523-13-000703:notes:6]

[0001157523-13-002629:notes:7]
[same as prior period, unchanged from 0001157523-13-000703:notes:7]

[0001157523-13-002629:notes:8]
[same as prior period, unchanged from 0001157523-13-000703:notes:8]


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001157523-13-002629:notes:9]
[same as prior period, unchanged from 0001157523-13-000703:notes:9]

[0001157523-13-002629:notes:10]
The
Company’s reportable operating segments are determined based
on the Company's management approach.  The management
approach is based on the way that the chief operating decision
maker organizes the segments within an enterprise for making
operating decisions and assessing performance. The Company's
results of operations are reviewed by the chief operating decision
maker on a consolidated basis and the Company operates in only one
segment.  The Company has presented required geographical
data in Note 11, and no additional segment data has been
presented.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-13-002629:notes:11]
[same as prior period, unchanged from 0001157523-13-000703:notes:11]

[0001157523-13-002629:notes:12]
[same as prior period, unchanged from 0001157523-13-000703:notes:12]

[0001157523-13-002629:notes:13]
[same as prior period, unchanged from 0001157523-13-000703:notes:13]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-13-002629:notes:14]
[same as prior period, unchanged from 0001157523-13-000703:notes:14]

[0001157523-13-002629:notes:15]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at March 31, 2013 and June 30, 2012.  The
Company considers all highly liquid investments with original
maturities of three months or less to be cash
equivalents.  The Company has cash balances in banks in
excess of the maximum amount insured by the FDIC and other
international agencies as of March 31, 2013 and June 30,
2012.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001157523-13-002629:notes:16]
Recently
Issued Accounting Standards

[0001157523-13-002629:notes:17]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

[0001157523-13-002629:notes:18]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-13-002629:notes:19]
[same as prior period, unchanged from 0001157523-13-000703:notes:23]

[0001157523-13-002629:notes:20]
The
Company had one customer with an accounts receivable balance equal
to 11% of the Company’s accounts receivable at March 31, 2013
and 15% at June 30, 2012. Sales to any one customer did not exceed
10% of net sales in any of the past three fiscal
years.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001157523-13-002629:notes:21]
NOTE 8 – Stockholders’ Equity
Transactions

[0001157523-13-002629:notes:22]
During
the first nine months of fiscal 2013 certain employees
exercised incentive stock options under the Company’s 2002
Plan totaling 729,000 shares. No incentive stock options were
exercised during the three months ended March 31, 2013. The
exercises were completed as cashless exercises as allowed for under
the 2002 Plan, where the exercise shares are issued by the Company
in exchange for shares of the Company’s common stock that are
owned by the optionees. The number of shares surrendered by the
optionees are based upon the per share price on the effective date
of the option exercise. In addition, the Company repurchased
128,588 shares of its Common Stock from its Chief Executive
Officer, Richard Soloway. The purchase price was $3.38 per share,
the previous business day’s closing price on NASDAQ, for an
aggregate purchase price of $434,627. The repurchase was to fund
Mr. Soloway’s tax liability associated with the exercise of
675,000 options granted to him under the 2002 Plan. The repurchase
was approved by the Board of Directors of the Company, including
all of the independent directors. Mr. Soloway’s exercises
resulted in a tax benefit to the Company of $114,000 which is
included in Additional Paid-in Capital.

[0001157523-13-002629:notes:23]
The
following table reflects the activity of these equity transactions
for the nine months ended March 31, 2013 (dollars in
thousands):

[0001157523-13-002629:notes:24]
|  |  | Common Stock |  |  |  |  |  | Treasury Stock |  |
|  |  | Number of Shares Issued |  |  | Amount |  |  | Additional Paid-in Capital |  |  | Number of Shares |  |  | Amount |  |
| BALANCE June 30, 2012 |  |  | 20,095,713 |  |  | $ | 201 |  |  | $ | 14,080 |  |  |  | (1,000,000 | ) |  | $ | (5,615 | ) |
| Options exercised |  |  | 729,000 |  |  |  | 7 |  |  |  | 1,364 |  |  |  | -- |  |  |  | -- |  |
| Shares surrendered and cancelled under option exercise |  |  | (27,900 | ) |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Shares surrendered and held in Treasury under option exercise |  |  | -- |  |  |  | -- |  |  |  |  |  |  |  | (371,890 | ) |  |  | (1,257 | ) |
| Shares repurchased and held in Treasury |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | (128,588 | ) |  |  | (435 | ) |
| BALANCE March 31, 2013 |  |  | 20,796,813 |  |  | $ | 208 |  |  | $ | 15,444 |  |  |  | (1,500,478 | ) |  | $ | (7,307 | ) |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-13-002629:notes:25]
NOTE 9 - 401(k) Plan

[0001157523-13-002629:notes:26]
The
Company maintains a 401(k) plan (“the Plan”) that
covers all U.S. non-union employees with one or more years of
service and is qualified under Sections 401(a) and 401(k) of the
Internal Revenue Code. Company contributions to this plan are
discretionary and totaled $27,000 and $19,000 and $73,000 and
$19,000 for the three and nine months ended March 31, 2013 and
2012, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-13-002629:notes:27]
[same as prior period, unchanged from 0001157523-13-000703:notes:31]

[0001157523-13-002629:notes:28]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |  | Useful Life in Years |  |
|  |  | (in thousands) |  |  |  |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |  |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,783 |  |  |  | 6,748 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,324 |  |  |  | 2,317 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,380 |  |  |  | 19,107 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 38,674 |  |  |  | 38,359 |  |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 31,881 |  |  |  | 31,112 |  |  |  |  |  |
|  |  | $ | 6,793 |  |  | $ | 7,247 |  |  |  |  |  |


## us-gaap:ScheduleOfEarningsPerShareReconciliationTableTextBlock

[0001157523-13-002629:notes:29]
[same as prior period, unchanged from 0001157523-13-000703:notes:33]

[0001157523-13-002629:notes:30]
|  |  | Three Months Ended March 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,296 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 123 |  |  |  | 313 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,419 |  |  |  | 19,409 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |

[0001157523-13-002629:notes:31]
Options
to purchase 395,750 shares of common stock for the three months
ended March 31, 2013 and 2012 were not included in the computation
of Diluted EPS because their inclusion would be
anti-dilutive.  These options were still outstanding at
the end of the respective periods.

[0001157523-13-002629:notes:32]
|  |  | Nine Months Ended March 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,096 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 157 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,253 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-13-002629:notes:33]
[same as prior period, unchanged from 0001157523-13-000703:notes:37]

[0001157523-13-002629:notes:34]
[same as prior period, unchanged from 0001157523-13-000703:notes:38]

[0001157523-13-002629:notes:35]
[same as prior period, unchanged from 0001157523-13-000703:notes:39]

[0001157523-13-002629:notes:36]
[same as prior period, unchanged from 0001157523-13-000703:notes:40]

[0001157523-13-002629:notes:37]
[same as prior period, unchanged from 0001157523-13-000703:notes:41]

[0001157523-13-002629:notes:38]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries. All inter-company balances and transactions have been
eliminated in consolidation.

[0001157523-13-002629:notes:39]
[same as prior period, unchanged from 0001157523-13-000703:notes:43]

[0001157523-13-002629:notes:40]
[same as prior period, unchanged from 0001157523-13-000703:notes:44]

[0001157523-13-002629:notes:41]
[same as prior period, unchanged from 0001157523-13-000703:notes:45]

[0001157523-13-002629:notes:42]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,045,000 and $1,184,000 as of March 31, 2013 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.

[0001157523-13-002629:notes:43]
[same as prior period, unchanged from 0001157523-13-000703:notes:47]

[0001157523-13-002629:notes:44]
[same as prior period, unchanged from 0001157523-13-000703:notes:48]

[0001157523-13-002629:notes:45]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets recorded at
fair value on the date of acquisition. The intangible assets are
amortized over their estimated useful lives of twenty years
(customer relationships) and seven years (non-compete agreement).
The Marks USA trade name was deemed to have an indefinite
life.

[0001157523-13-002629:notes:46]
[same as prior period, unchanged from 0001157523-13-000703:notes:50]

[0001157523-13-002629:notes:47]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,252 | ) |  | $ | 4,548 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (225 | ) |  |  | 115 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,477 | ) |  | $ | 10,563 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

[0001157523-13-002629:notes:48]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
March 31, 2013 and 2012, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$688,000 and $799,000 for the nine months ended March 31, 2013 and
2012, respectively. Amortization expense for each of the next five
fiscal years is estimated to be as follows: 2013 - $917,000; 2014 -
$781,000; 2015 - $667,000; 2016 - $529,000 and 2017 - $441,000. The
weighted average amortization period for intangible assets was 15.1
years and 15.8 years at March 31, 2013 and June 30, 2012,
respectively.

[0001157523-13-002629:notes:49]
[same as prior period, unchanged from 0001157523-13-000703:notes:53]

[0001157523-13-002629:notes:50]
[same as prior period, unchanged from 0001157523-13-000703:notes:54]

[0001157523-13-002629:notes:51]
[same as prior period, unchanged from 0001157523-13-000703:notes:55]

[0001157523-13-002629:notes:52]
[same as prior period, unchanged from 0001157523-13-000703:notes:56]

[0001157523-13-002629:notes:53]
[same as prior period, unchanged from 0001157523-13-000703:notes:57]

[0001157523-13-002629:notes:54]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended March 31, 2013 and 2012 was
$124,000 and $388,000, respectively. Advertising expense for the
nine months ended March 31, 2013 and 2012 was $847,000 and
$871,000, respectively. The decrease for the three months resulted
primarily from the timing of a major tradeshow. Last year this
tradeshow occurred during the quarter ended March 31, 2012 while
this year the same tradeshow occurred subsequent to March 31, 2013.
For the nine months, this decrease was partially offset by
increased expenditures on another major tradeshow and media
advertising as compared to the same period a year ago.

[0001157523-13-002629:notes:55]
[same as prior period, unchanged from 0001157523-13-000703:notes:59]

[0001157523-13-002629:notes:56]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended March 31, 2013 and 2012 was
$1,187,000 and $1,094,000, respectively. Company-sponsored research
and development expense for the nine months ended March 31, 2013
and 2012 was $3,842,000 and $3,134,000, respectively. The increases
for the three and nine months was due primarily to expenses
relating to development of the Company’s iBridge™
tablet computer/touch screen keypad.

[0001157523-13-002629:notes:57]
[same as prior period, unchanged from 0001157523-13-000703:notes:61]

[0001157523-13-002629:notes:58]
[same as prior period, unchanged from 0001157523-13-000703:notes:62]

[0001157523-13-002629:notes:59]
Net
Income (Loss) Per Share

[0001157523-13-002629:notes:60]
[same as prior period, unchanged from 0001157523-13-000703:notes:64]

[0001157523-13-002629:notes:61]
Options
to purchase 672,740 and 733,880 shares of common stock for the nine
months ended March 31, 2013 and 2012, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.

[0001157523-13-002629:notes:62]
[same as prior period, unchanged from 0001157523-13-000703:notes:66]

[0001157523-13-002629:notes:63]
[same as prior period, unchanged from 0001157523-13-000703:notes:67]

[0001157523-13-002629:notes:64]
[same as prior period, unchanged from 0001157523-13-000703:notes:68]

[0001157523-13-002629:notes:65]
There
were no stock-based compensation costs for the three months ended
March 31, 2013 and 2012. Stock-based compensation costs of $0 and
$8,000 were recognized for the nine months ended March 31, 2013 and
2012, respectively.

[0001157523-13-002629:notes:66]
[same as prior period, unchanged from 0001157523-13-000703:notes:70]

[0001157523-13-002629:notes:67]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and nine months ended March 31, 2013 and
2012.

[0001157523-13-002629:notes:68]
[same as prior period, unchanged from 0001157523-13-000703:notes:72]

[0001157523-13-002629:notes:69]
For
the three and nine months ended March 31, 2013 and 2012, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

[0001157523-13-002629:notes:70]
[same as prior period, unchanged from 0001157523-13-000703:notes:74]

[0001157523-13-002629:notes:71]
The
Company records the amount billed to customers in net sales
($118,000 and $159,000 for the three months ended March 31, 2013
and 2012, respectively, and $367,000 and $434,000 for the nine
months ended March 31, 2013 and 2012, respectively) and classifies
the costs associated with these revenues in cost of sales ($266,000
and $267,000 for the three months ended March 31, 2013 and 2012,
respectively, and $748,000 and $824,000 for the nine months ended
March 31, 2013 and 2012, respectively).


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-13-002629:notes:72]
[same as prior period, unchanged from 0001157523-13-000703:notes:76]

[0001157523-13-002629:notes:73]
Depreciation
and amortization expense on property, plant, and equipment was
approximately $262,000 and $278,000 for the three months ended
March 31, 2013 and 2012, respectively and $769,000 and $797,000 for
the nine months ended March 31, 2013 and 2012,
respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-13-002629:notes:74]
NOTE 5 - Income Taxes

[0001157523-13-002629:notes:75]
[same as prior period, unchanged from 0001157523-13-000703:notes:79]

[0001157523-13-002629:notes:76]
The
Company does not expect that our unrecognized tax benefits will
significantly change within the next twelve months. We file a
consolidated U.S. income tax return and tax returns in certain
state and local and foreign jurisdictions. As of March 31, 2013 we
remain subject to examination in all tax jurisdictions for all
relevant jurisdictional statutes for fiscal years 2008 and
thereafter.

[0001157523-13-002629:notes:77]
The
Company has identified its U.S. Federal income tax return and its
State return in New York as its major tax jurisdictions. During the
three and nine months ended March 31, 2013 the Company increased
its reserve for uncertain income tax positions by $28,000. As a
result, as of March 31, 2013 and June 30, 2012 the Company has a
long-term accrued income tax liability of $154,000 and $126,000,
respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-13-002629:notes:78]
[same as prior period, unchanged from 0001157523-13-000703:notes:82]

[0001157523-13-002629:notes:79]
[same as prior period, unchanged from 0001157523-13-000703:notes:83]

[0001157523-13-002629:notes:80]
[same as prior period, unchanged from 0001157523-13-000703:notes:84]

[0001157523-13-002629:notes:81]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
| Component parts |  | $ | 12,696 |  |  | $ | 13,155 |  |
| Work-in-process |  |  | 3,074 |  |  |  | 3,199 |  |
| Finished product |  |  | 6,658 |  |  |  | 6,928 |  |
|  |  | $ | 22,428 |  |  | $ | 23,282 |  |

[0001157523-13-002629:notes:82]
| Classification of inventories, net of reserves: |  |
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
| Current |  | $ | 17,299 |  |  | $ | 19,448 |  |
| Non-current |  |  | 5,129 |  |  |  | 3,834 |  |
|  |  | $ | 22,428 |  |  | $ | 23,282 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001157523-13-002629:notes:83]
Outstanding
balances and interest rates as of March 31, 2013 and June 30, 2012
are as follows (dollars in thousands):

[0001157523-13-002629:notes:84]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,300 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 16,800 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-13-002629:notes:85]
NOTE 10 - Commitments and Contingencies

[0001157523-13-002629:notes:86]
Leases

[0001157523-13-002629:notes:87]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $14,000 and $12,000 for the three months ended
March 31, 2013 and 2012, respectively and $37,000 and $38,000
for the nine months ended March 31, 2013 and 2012,
respectively.

[0001157523-13-002629:notes:88]
Land
Lease

[0001157523-13-002629:notes:89]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic at an annual cost of
$288,000, on which the Company's principal production facility is
located.

[0001157523-13-002629:notes:90]
Litigation

[0001157523-13-002629:notes:91]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the settlement of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.

[0001157523-13-002629:notes:92]
Employment
Agreements

[0001157523-13-002629:notes:93]
As
of March 31, 2013, the Company was obligated under two employment
agreements and one severance agreement.  The employment
agreements are with the Company’s Chief Executive Officer
(“the CEO”) and Senior Vice President of Sales and
Marketing (“the SVP”). The employment agreement with
the CEO provides for an annual salary of $587,000, as adjusted for
inflation; incentive compensation as may be approved by the Board
of Directors from time to time and a termination payment in an
amount up to 299% of the average of the prior five calendar year's
compensation, subject to certain limitations, as defined in the
agreement.  The employment agreement renews annually in
August unless either party gives the other notice of non-renewal at
least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-13-002629:notes:94]
NOTE 7 - Stock Options

[0001157523-13-002629:notes:95]
[same as prior period, unchanged from 0001157523-13-000703:notes:100]

[0001157523-13-002629:notes:96]
Under
the 2012 Plan, stock options may be granted to valued employees
with a term of up to 10 years at an exercise price equal to or
greater than the fair market value on the date of grant and are
exercisable in whole or in part at 20% per year beginning on the
date of grant. An option granted under the 2012 Plan shall vest in
full upon a “change in control” as defined in the 2012
Plan. At March 31, 2013, no stock options were granted or
exercisable and 950,000 stock options were available for grant
under this plan.

[0001157523-13-002629:notes:97]
[same as prior period, unchanged from 0001157523-13-000703:notes:102]

[0001157523-13-002629:notes:98]
Under
the 2012 Non-Employee Plan, stock options may be granted with a
term of up to 10 years at an exercise price equal to or greater
than the fair market value on the date of grant and are exercisable
in whole or in part at 20% per year beginning on the date of grant.
An option granted under the 2012 Non-Employee Plan shall vest in
full upon a “change in control” as defined in the 2012
Non-Employee Plan. At March 31, 2013, no stock options were granted
or exercisable and 50,000 stock options were available for grant
under this plan.

[0001157523-13-002629:notes:99]
[same as prior period, unchanged from 0001157523-13-000703:notes:104]

[0001157523-13-002629:notes:100]
[same as prior period, unchanged from 0001157523-13-000703:notes:105]

[0001157523-13-002629:notes:101]
No
options were granted under the 2002 Plan during the three or nine
months ended March 31, 2013 or 2012.

[0001157523-13-002629:notes:102]
The
following table reflects activity under the 2002 Plan for the nine
months ended March 31,

[0001157523-13-002629:notes:103]
|  |  | 2013 |  |  | 2012 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | 729,000 |  |  |  | 1.85 |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Exercisable, end of period |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 1,301,000 |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 578,000 |  |  |  |  |  |  | $ | 1,259,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 578,000 |  |  |  |  |  |  | $ | 1,259,000 |  |  |  |  |  |

[0001157523-13-002629:notes:104]
729,000
options were exercised during the nine months ended March 31, 2013
and no options were exercised during the nine months ended March
31, 2012. These exercises were paid for with 399,790 shares of the
Company’s common stock, 27,900 of which were retired upon
receipt. Cash  received from option exercises for each of
the nine months ended March 31, 2013 and 2012 was $0 and the actual
tax benefit realized for the tax deductions from option exercises
totaled $114,000 and $0 for these periods,
respectively.

[0001157523-13-002629:notes:105]
The
following table summarizes information about stock options
outstanding under the 2002 Plan at March 31, 2013:

[0001157523-13-002629:notes:106]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding at March 31, 2013 |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable at March 31, 2013 |  |  | Weighted average exercise price |  |
| $1.62 - $4.00 |  |  |  | 285,390 |  |  |  | 0.8 |  |  | $ | 1.97 |  |  |  | 285,390 |  |  | $ | 1.97 |  |
| $4.01 - $7.50 |  |  |  | 328,250 |  |  |  | 3.8 |  |  |  | 5.29 |  |  |  | 328,250 |  |  |  | 5.29 |  |
| $7.51 - $11.16 |  |  |  | 37,500 |  |  |  | 3.0 |  |  |  | 11.16 |  |  |  | 37,500 |  |  |  | 11.16 |  |
|  |  |  |  |  | 651,140 |  |  |  | 2.4 |  |  | $ | 4.18 |  |  |  | 651,140 |  |  | $ | 4.18 |  |

[0001157523-13-002629:notes:107]
As
of March 31, 2013, there was no unearned stock-based compensation
cost related to non-vested share-based compensation arrangements
granted under the 2002 Plan. All options outstanding under the 2002
Plan were vested as of the beginning of the current period;
therefore, the total fair value of the options vested during the
nine months ended March 31, 2013 under the 2002 Plan was
$0.

[0001157523-13-002629:notes:108]
[same as prior period, unchanged from 0001157523-13-000703:notes:113]

[0001157523-13-002629:notes:109]
The
following table reflects activity under the 2000 Plan for the nine
months ended March 31,

[0001157523-13-002629:notes:110]
|  |  | 2013 |  |  | 2012 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |

[0001157523-13-002629:notes:111]
As
of March 31, 2013, there was no unearned stock-based compensation
cost related to non-vested share-based compensation arrangements
granted under the 2000 Plan. All options outstanding under the 2000
Plan were vested as of the beginning of the current period;
therefore, the total fair value of the options vested during the
nine months ended March 31, 2013 under the 2000 Plan was
$0.


## us-gaap:LongTermDebtTextBlock

[0001157523-13-002629:notes:112]
NOTE 6 - Long-Term Debt

[0001157523-13-002629:notes:113]
As
of March 31, 2013, long-term debt consisted of a revolving credit
facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

[0001157523-13-002629:notes:114]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, N.Y., equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.

[0001157523-13-002629:notes:115]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-13-002629:notes:116]
NOTE 11 - Geographical Data

[0001157523-13-002629:notes:117]
[same as prior period, unchanged from 0001157523-13-000703:notes:122]

[0001157523-13-002629:notes:118]
The
following represents selected consolidated geographical
data:

[0001157523-13-002629:notes:119]
|  |  | Three Months ended March 31, |  |  | Nine Months ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 16,174 |  |  | $ | 16,423 |  |  | $ | 46,543 |  |  | $ | 48,330 |  |
| Foreign |  |  | 989 |  |  |  | 813 |  |  |  | 3,048 |  |  |  | 2,726 |  |
| Total Net Sales |  | $ | 17,163 |  |  | $ | 17,236 |  |  | $ | 49,591 |  |  | $ | 51,056 |  |
|  |  | As of |  |  |  |  |  |  |  |  |  |
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |  |  |  |  |  |  |  |  |
| Identifiable assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 47,105 |  |  | $ | 50,838 |  |  |  |  |  |  |  |  |  |
| Dominican Republic (2) |  |  | 12,761 |  |  |  | 13,912 |  |  |  |  |  |  |  |  |  |
| Total Identifiable Assets |  | $ | 59,866 |  |  | $ | 64,750 |  |  |  |  |  |  |  |  |  |

[0001157523-13-002629:notes:120]
[same as prior period, unchanged from 0001157523-13-000703:notes:123]

[0001157523-13-002629:notes:121]
(2)
Consists primarily of inventories (March 31, 2013 = $8,962,000;
June 30, 2012 = $9,866,000) and fixed assets (March 31, 2013 =
$3,675,000; June 30, 2012 = $3,936,000) located at the Company's
principal manufacturing facility in the Dominican
Republic.
