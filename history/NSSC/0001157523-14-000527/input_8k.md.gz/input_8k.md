# NSSC 8-K — 0001157523-14-000521 filed 2014-02-10

## item codes, every 8-K on or before 2014-02-10

- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2014-02-10

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-14-000521:8k_2_02:1]
EX-99.1
2
a50801228ex99_1.htm
EXHIBIT 99.1

[0001157523-14-000521:8k_2_02:2]
a50801228ex99_1.htm

[0001157523-14-000521:8k_2_02:3]
Exhibit 99.1

[0001157523-14-000521:8k_2_02:4]
NAPCO Reports 7% Revenue Growth for the Three Months,

[0001157523-14-000521:8k_2_02:5]
10% Growth for the Six Months ended December 31, 2013

[0001157523-14-000521:8k_2_02:6]
-Q2 Net Income Increases 173%, Six Months Level Increases $790,000-

[0001157523-14-000521:8k_2_02:7]
-Highest Q2 Revenue and Net Income Levels in Five Years-

[0001157523-14-000521:8k_2_02:8]
- Management to Host Conference Call Today at 11 a.m. -

[0001157523-14-000521:8k_2_02:9]
AMITYVILLE, N.Y., February 10, 2014--NAPCO Security Technologies, Inc. (Nasdaq: NSSC), one of the world's leading solutions providers and manufacturers of high-technology electronic intrusion security, connected home, video and fire systems, as well as enterprise-class access control and door locking products, for over 30 years, today announced financial results for its second fiscal quarter ended December 31, 2013.

[0001157523-14-000521:8k_2_02:10]
Highlights:

[0001157523-14-000521:8k_2_02:11]
| ● | Net sales for the second quarter were $18.4 million, an increase of 7% over last years second quarter and the highest Q2 revenue in five years. Net sales for the six months were $35.6 million, up 10% from $32.4 million for the comparable period last year. |

[0001157523-14-000521:8k_2_02:12]
| ● | Recurring revenue for the second quarter and six months increased 115% and 113% respectively and grew sequentially by 30%. |

[0001157523-14-000521:8k_2_02:13]
| ● | Gross margin improved 70 basis points to 27.7% for the quarter as compared to 27.0% for the same period last year. Gross margin for the six months improved 130 basis points to 28.4% as compared to 27.1% for the comparable period a year ago. |

[0001157523-14-000521:8k_2_02:14]
| ● | Adjusted EBITDA (*see table attached) for the second quarter increased 23% to $1.0 million compared to $843,000 last year and was up 90% for the six months to $1.8 million compared to $929,000 in the comparable year ago period. Q2 Adjusted EBITDA was the highest level in five years. |

[0001157523-14-000521:8k_2_02:15]
| ● | Net Income for the second quarter increased 173% to $368,000 compared to $135,000 last year and was up $790,000 to $491,000 for the six month period. Q2 net income was at its highest level in five years. |

[0001157523-14-000521:8k_2_02:16]
| ● | Debt, net of cash, has been reduced by $26.2 million from $35.9 million to $9.7 million since acquiring Marks in August of 2008, with $3.5 million of this reduction occurring during the first half of this fiscal year. As a result of the lower debt levels and lower interest rates, net interest expense for the six months decreased by $87,000 or 27% to $231,000 as compared to $318,000 for the comparable period last year. |

[0001157523-14-000521:8k_2_02:17]
| ● | Earnings per Share (Diluted) rose 100% to $0.02 from $0.01 for the second quarter. Diluted EPS for the six months was $0.03 compared to $(0.02) for the six months last year, a swing of $0.05 per share. |

[0001157523-14-000521:8k_2_02:18]
Richard Soloway, Chairman and President stated, “Increasing demand for ‘Connected Home’ and school security products are helping to drive improved financial performance, contributing to top- and bottom-line Q2 results not seen in five years. In addition, our subscription-based service product lines, which deliver recurring revenue income streams, continue to show impressive and accelerating growth. Our iBridge™ Connected Home, iSee Video™ remote video and StarLink™ wireless communicator product lines are all vibrantly growing in activations and market penetration and we are capitalizing on the increasing consumer interest in broadband, internet-based, remote control home automation. We are making steady progress in educating and training our dealer network, and as consumer demand for these connected solutions increases, our dealers are increasingly turning to NAPCO for solutions.”

[0001157523-14-000521:8k_2_02:19]
“Simultaneously, 2013 saw the unfortunate, seemingly all too frequent, occurrence of shooting events and violent attacks in schools, universities and colleges, as well as public venues such as malls and workplaces,” continued Mr. Soloway. “It has been NAPCO Security Technologies’ mission to play a leadership role in providing effective product locking, access control, and surveillance solutions to this pressing problem. During Q2, we continued the execution of Project LocDown™, a cross-divisional initiative which uniquely positions Marks USA LocDown™ intruder locks, Alarm Lock’s Networx™ wireless locks and Continental Access Control’s card access systems in providing a totally integrated access control and lock-down solution, to address active-shooter threats in the educational community. We have experienced a strong acceleration in sales to the education vertical market.”

[0001157523-14-000521:8k_2_02:20]
Mr. Soloway concluded, “The building blocks for aggressive, sustainable growth, going forward, are in place at NAPCO to maintain our leadership position in mature markets as well as establish ourselves as key players with outstanding products in new ones. With a balanced product portfolio consisting of multiple recurring revenue sources, Connected Home services, and a formidable presence in high gross margin, commercial security solutions, addressing rapidly growing sectors such as education, the Company is well-positioned for substantive future growth, and we believe the best is yet to come.”

[0001157523-14-000521:8k_2_02:21]
Financial Results

[0001157523-14-000521:8k_2_02:22]
Revenues for the three months ended December 31, 2013 increased 7% to $18.4 million, as compared to $17.2 million for the same period one year ago. Revenues for the six months ended December 31, 2013 increased 10% to $35.6 million, as compared to $32.4 million for the same period one year ago.

[0001157523-14-000521:8k_2_02:23]
Selling, general and administrative expenses for the second quarter increased $260,000 to $4.5 million from $4.3 million for the same period in fiscal 2013. Selling, general and administrative expenses for the six months increased $502,000 to $9.3 million from $8.8 million for the same period in fiscal 2013. Operating income for the second quarter was $534,000, representing an increase of $180,000 to $534,000 compared to $354,000 for the same period last year. Operating income for the six months was $796,000, representing appositive swing of $841,000 to $796,000 compared to a loss of $(45,000) for the same period last year.

[0001157523-14-000521:8k_2_02:24]
Adjusted EBITDA* for the second quarter increased $194,000, to $1.0 million as compared to $843,000 for the same period last year (*see table attached). Adjusted EBITDA* for the six months increased $836,000, to $1.8 million as compared to $929,000 for the same period last year (*see table attached).

[0001157523-14-000521:8k_2_02:25]
Net income for the quarter increased by $233,000 to $368,000 or $0.02 per share as compared to $135,000 or $0.01 per share for the same period last year. Net income for the six months was $491,000 or $0.03 per share, representing a positive swing of $790,000 compared to a loss of $(299,000) or $(0.02) per share for the same period last year.

[0001157523-14-000521:8k_2_02:26]
Balance Sheet Summary

[0001157523-14-000521:8k_2_02:27]
At December 31, 2013, the Company had $3.4 million in cash and cash equivalents, an increase of $150,000 compared to $3.2 million at June 30, 2013. NAPCO had working capital of $30.8 million as compared with working capital of $33.2 million at June 30, 2013. Current ratio was 4.8:1 as compared to 4.9:1 at June 30, 2013. Debt, net of cash, was $9.7 million at December 31, 2013, a decrease of $3.5 million compared to $13.2 million as of June 30, 2013.

[0001157523-14-000521:8k_2_02:28]
Conference Call Information

[0001157523-14-000521:8k_2_02:29]
Management will conduct a conference call at 11 a.m. today, February 10, 2014. Interested parties may participate in the call by dialing 1-877-941-4774 or for international callers, 1-480-629-9760, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m. ET on February 10, 2014 and ending on February 17, 2014. For the replay, please dial 1-877-870-5176 domestically, or 1-858-384-5517 for international callers, and use the replay access code, 4667663.

[0001157523-14-000521:8k_2_02:30]
In addition, the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=107815 http://public.viavid.com/index.php?id=107815.

[0001157523-14-000521:8k_2_02:31]
About NAPCO Security Technologies, Inc.

[0001157523-14-000521:8k_2_02:32]
NAPCO Security Technologies, Inc. is one of the world's leading manufacturers and solutions providers of high-technology electronic security, connected home, video, fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for  innovation, technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001157523-14-000521:8k_2_02:33]
Safe Harbor Statement

[0001157523-14-000521:8k_2_02:34]
This press release contains forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the Securities and Exchange Commission.

[0001157523-14-000521:8k_2_02:35]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,379 |  |  | $ | 3,229 |  |
| Accounts receivable, net of reserves and allowances |  |  | 13,704 |  |  |  | 18,211 |  |
| Inventories |  |  | 19,788 |  |  |  | 18,471 |  |
| Prepaid expenses and other current assets |  |  | 1,369 |  |  |  | 1,219 |  |
| Income tax receivable |  |  | -- |  |  |  | 64 |  |
| Deferred income taxes |  |  | 681 |  |  |  | 642 |  |
| Total Current Assets |  |  | 38,921 |  |  |  | 41,836 |  |
| Inventories - non-current |  |  | 3,226 |  |  |  | 3,436 |  |
| Deferred income taxes |  |  | 1,541 |  |  |  | 1,526 |  |
| Property, plant and equipment, net |  |  | 6,512 |  |  |  | 6,586 |  |
| Intangible assets, net |  |  | 9,943 |  |  |  | 10,334 |  |
| Other assets |  |  | 179 |  |  |  | 185 |  |
| TOTAL ASSETS |  | $ | 60,322 |  |  | $ | 63,903 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,030 |  |  |  | 3,318 |  |
| Accrued expenses |  |  | 1,857 |  |  |  | 2,093 |  |
| Accrued salaries and wages |  |  | 1,597 |  |  |  | 1,604 |  |
| Accrued income taxes |  |  | 22 |  |  |  | -- |  |
| Total Current Liabilities |  |  | 8,106 |  |  |  | 8,615 |  |
| Long-term debt, net of current maturities |  |  | 11,500 |  |  |  | 14,800 |  |
| Accrued income taxes |  |  | 164 |  |  |  | 153 |  |
| Total Liabilities |  |  | 19,770 |  |  |  | 23,568 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,038,443 and 20,796,813 shares issued; and 19,408,276 and 19,296,335 shares outstanding, respectively |  |  | 210 |  |  |  | 208 |  |
| Additional paid-in capital |  |  | 15,818 |  |  |  | 15,356 |  |
| Retained earnings |  |  | 32,568 |  |  |  | 32,078 |  |
|  |  |  | 48,596 |  |  |  | 47,642 |  |
| Less: Treasury Stock, at cost (1,630,167 and 1,500,478 shares, respectively) |  |  | (8,044 | ) |  |  | (7,307 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 40,552 |  |  |  | 40,335 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 60,322 |  |  | $ | 63,903 |  |

[0001157523-14-000521:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited) |  |
|  |  | Three months ended December 31, |  |  | Six months ended December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 18,353 |  |  | $ | 17,212 |  |  | $ | 35,592 |  |  | $ | 32,428 |  |
| Cost of sales |  |  | 13,272 |  |  |  | 12,571 |  |  |  | 25,472 |  |  |  | 23,651 |  |
| Gross Profit |  |  | 5,081 |  |  |  | 4,641 |  |  |  | 10,120 |  |  |  | 8,777 |  |
| Selling, general, and administrative expenses |  |  | 4,547 |  |  |  | 4,287 |  |  |  | 9,324 |  |  |  | 8,822 |  |
| Operating Income (Loss) |  |  | 534 |  |  |  | 354 |  |  |  | 796 |  |  |  | (45 | ) |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 110 |  |  |  | 141 |  |  |  | 231 |  |  |  | 318 |  |
| Other, net |  |  | 4 |  |  |  | 4 |  |  |  | 7 |  |  |  | 7 |  |
| Income (Loss) before Income Taxes |  |  | 420 |  |  |  | 209 |  |  |  | 558 |  |  |  | (370 | ) |
| Provision (benefit) for income taxes |  |  | 52 |  |  |  | 74 |  |  |  | 67 |  |  |  | (71 | ) |
| Net Income (Loss) |  | $ | 368 |  |  | $ | 135 |  |  | $ | 491 |  |  | $ | (299 | ) |
| Net Income (Loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  |  | $ | 0.01 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |
| Diluted |  | $ | 0.02 |  |  | $ | 0.01 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,408,000 |  |  |  | 19,154,000 |  |  |  | 19,366,000 |  |  |  | 19,125,000 |  |
| Diluted |  |  | 19,444,000 |  |  |  | 19,496,000 |  |  |  | 19,393,000 |  |  |  | 19,125,000 |  |

[0001157523-14-000521:8k_2_02:37]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |  |
|  |  | Three months ended December 31, |  |  | Six months ended December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands) |  |
| Net income (loss) |  | $ | 368 |  |  | $ | 135 |  |  | $ | 491 |  |  | $ | (299 | ) |
| Add back provision (benefit) for income taxes |  |  | 52 |  |  |  | 74 |  |  |  | 67 |  |  |  | (71 | ) |
| Add back interest and other expense |  |  | 114 |  |  |  | 145 |  |  |  | 238 |  |  |  | 325 |  |
| Operating income (loss) (GAAP) |  |  | 534 |  |  |  | 354 |  |  |  | 796 |  |  |  | (45 | ) |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 195 |  |  |  | 229 |  |  |  | 391 |  |  |  | 459 |  |
| Add back change to inventory reserve |  |  | 75 |  |  |  | -- |  |  |  | 125 |  |  |  | -- |  |
| Add back stock-based compensation expense |  |  | 6 |  |  |  | -- |  |  |  | 7 |  |  |  | -- |  |
| Adjusted non-GAAP operating income |  |  | 810 |  |  |  | 583 |  |  |  | 1,319 |  |  |  | 414 |  |
| Add back depreciation and other amortization |  |  | 227 |  |  |  | 260 |  |  |  | 446 |  |  |  | 515 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,037 |  |  | $ | 843 |  |  | $ | 1,765 |  |  | $ | 929 |  |

[0001157523-14-000521:8k_2_02:38]
* Non-GAAP Information. Certain non-GAAP measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not include impairment of goodwill, amortization of intangibles, changes to inventory reserves, restructuring charges, stock-based compensation expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial measures included in the above.

[0001157523-14-000521:8k_2_02:39]
INVESTOR INQUIRIES:

[0001157523-14-000521:8k_2_02:40]
Brett Maas

[0001157523-14-000521:8k_2_02:41]
Hayden IR

[0001157523-14-000521:8k_2_02:42]
(646) 536-7331

[0001157523-14-000521:8k_2_02:43]
brett@haydenir.com

[0001157523-14-000521:8k_2_02:44]
Peter Seltzberg, Regional Vice-President

[0001157523-14-000521:8k_2_02:45]
Hayden IR

[0001157523-14-000521:8k_2_02:46]
(646) 415-8972

[0001157523-14-000521:8k_2_02:47]
peter@haydenir.com
