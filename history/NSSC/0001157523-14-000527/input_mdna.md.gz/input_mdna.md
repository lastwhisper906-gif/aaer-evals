# NSSC MD&A — 0001157523-14-000527


## mdna

[0001157523-14-000527:mdna:1]
[same as prior period, unchanged from 0001157523-13-005478:mdna:1]

[0001157523-14-000527:mdna:2]
[same as prior period, unchanged from 0001157523-13-005478:mdna:2]

[0001157523-14-000527:mdna:3]
[same as prior period, unchanged from 0001157523-13-005478:mdna:3]

[0001157523-14-000527:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 5% and 6% of our revenues for both of the six month periods ended December 31, 2013 and 2012, respectively.

[0001157523-14-000527:mdna:5]
[same as prior period, unchanged from 0001157523-13-005478:mdna:5]

[0001157523-14-000527:mdna:6]
[same as prior period, unchanged from 0001157523-13-005478:mdna:6]

[0001157523-14-000527:mdna:7]
[same as prior period, unchanged from 0001157523-13-005478:mdna:7]

[0001157523-14-000527:mdna:8]
[same as prior period, unchanged from 0001157523-13-005478:mdna:8]

[0001157523-14-000527:mdna:9]
[same as prior period, unchanged from 0001157523-13-005478:mdna:9]

[0001157523-14-000527:mdna:10]
[same as prior period, unchanged from 0001157523-13-005478:mdna:10]

[0001157523-14-000527:mdna:11]
[same as prior period, unchanged from 0001157523-13-005478:mdna:11]

[0001157523-14-000527:mdna:12]
[same as prior period, unchanged from 0001157523-13-005478:mdna:12]

[0001157523-14-000527:mdna:13]
[same as prior period, unchanged from 0001157523-13-005478:mdna:13]

[0001157523-14-000527:mdna:14]
[same as prior period, unchanged from 0001157523-13-005478:mdna:14]

[0001157523-14-000527:mdna:15]
[same as prior period, unchanged from 0001157523-13-005478:mdna:15]

[0001157523-14-000527:mdna:16]
[same as prior period, unchanged from 0001157523-13-005478:mdna:16]

[0001157523-14-000527:mdna:17]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with accounts receivable balance that comprised 13% of the Company’s accounts receivable at December 31, 2013 and two customers that aggregated 22% at June 30, 2013. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.

[0001157523-14-000527:mdna:18]
In the ordinary course of business, we have established a reserve for doubtful accounts and customer deductions in the amount of $230,000 and $220,000 as of December 31, 2013 and June 30, 2013, respectively. Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical or anticipated events.

[0001157523-14-000527:mdna:19]
[same as prior period, unchanged from 0001157523-13-005478:mdna:19]

[0001157523-14-000527:mdna:20]
[same as prior period, unchanged from 0001157523-13-005478:mdna:20]

[0001157523-14-000527:mdna:21]
[same as prior period, unchanged from 0001157523-13-005478:mdna:21]

[0001157523-14-000527:mdna:22]
[same as prior period, unchanged from 0001157523-13-005478:mdna:22]

[0001157523-14-000527:mdna:23]
[same as prior period, unchanged from 0001157523-13-005478:mdna:23]

[0001157523-14-000527:mdna:24]
[same as prior period, unchanged from 0001157523-13-005478:mdna:24]

[0001157523-14-000527:mdna:25]
[same as prior period, unchanged from 0001157523-13-005478:mdna:25]

[0001157523-14-000527:mdna:26]
[same as prior period, unchanged from 0001157523-13-005478:mdna:26]

[0001157523-14-000527:mdna:27]
|  |  | Three months ended December 31, (dollars in thousands) |  |  | Six months ended December 31, 2013 (dollars in thousands) |  |
|  |  | 2013 |  |  | 2012 |  |  | % Increase/ (decrease) |  |  | 2013 |  |  | 2012 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 18,353 |  |  | $ | 17,212 |  |  |  | 6.6 | % |  | $ | 35,592 |  |  | $ | 32,428 |  |  |  | 9.8 | % |
| Gross profit |  |  | 5,081 |  |  |  | 4,641 |  |  |  | 9.5 | % |  |  | 10,120 |  |  |  | 8,777 |  |  |  | 15.3 | % |
| Gross profit as a % of net sales |  |  | 27.7 | % |  |  | 27.0 | % |  |  | 2.6 | % |  |  | 28.4 | % |  |  | 27.1 | % |  |  | 4.8 | % |
| Selling, general and administrative |  |  | 4,547 |  |  |  | 4,287 |  |  |  | 6.1 | % |  |  | 9,324 |  |  |  | 8,822 |  |  |  | 5.7 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 24.8 | % |  |  | 24.9 | % |  |  | (0.4 | )% |  |  | 26.2 | % |  |  | 27.2 | % |  |  | (3.7 | )% |
| Operating income (loss) |  |  | 534 |  |  |  | 354 |  |  |  | 50.8 | % |  |  | 796 |  |  |  | (45 | ) |  |  | 1,868.9 | % |
| Interest expense, net |  |  | 110 |  |  |  | 141 |  |  |  | (22.0 | )% |  |  | 231 |  |  |  | 318 |  |  |  | (27.4 | )% |
| Other expense |  |  | 4 |  |  |  | 4 |  |  |  | -- | % |  |  | 7 |  |  |  | 7 |  |  |  | -- | % |
| Provision (benefit) for income taxes |  |  | 52 |  |  |  | 74 |  |  |  | (29.7 | )% |  |  | 67 |  |  |  | (71 | ) |  |  | 194.4 | % |
| Net income (loss) |  |  | 368 |  |  |  | 135 |  |  |  | 172.6 | % |  |  | 491 |  |  |  | (299 | ) |  |  | 264.2 | % |

[0001157523-14-000527:mdna:28]
Sales for the three months ended December 31, 2013 increased 7% to $18,353,000 as compared to $17,212,000 for the same period a year ago. Sales for the six months ended December 31, 2013 increased 10% to $35,592,000 as compared to $32,428,000 for the same period a year ago. The increase in sales for the three months ended December 31, 2013 was due primarily to increased sales in the Company’s door-locking products ($1,241,000) and access control ($187,000) products as partially offset by a decrease in intrusion products ($286,000). The increase in sales for the six months ended December 31, 2013 was due primarily to increased sales in the Company’s door-locking products ($2,524,000) and access control ($906,000) products as partially offset by a decrease in intrusion products ($266,000). The increase in sales of door-locking products for the three and six months was due primarily to general increased demand for the Company’s door-locking products. The increase in sales of access control products for the six months was due primarily to a large order of $1,734,000 received from a major university in the quarter ended June 30, 2013. The Company shipped $1,127,000 of this order in the quarter ended June 30, 2013 and completed delivery of the remaining $607,000 during the first three months of fiscal 2014. Intrusion sales were impacted by a temporary delay in processing orders from a large distributor.

[0001157523-14-000527:mdna:29]
Gross profit for the three months ended December 31, 2013 increased to $5,081,000 or 27.7% of sales as compared to $4,641,000 or 27.0% of sales for the same period a year ago. Gross profit for the six months ended December 31, 2013 increased to $10,120,000 or 28.4% of sales as compared to $8,777,000 or 27.1% of sales for the same period a year ago. The increase in gross profit for the three and six months was primarily due to the aforementioned increase in net sales, a positive shift in product mix to the Company’s door-locking products and a reduction in research and development costs as a result of the completion of development of the Company’s iBridge product line.

[0001157523-14-000527:mdna:30]
Selling, general and administrative expenses for the three months ended December 31, 2013 increased by $260,000 to $4,547,000 from $4,287,000 for the same period a year ago.  Selling, general and administrative expenses for the six months ended December 31, 2013 increased by $502,000 to $9,324,000 from $8,822,000 for the same period a year ago.  Selling, general and administrative expenses as a percentage of net sales decreased to 24.8% for the three months ended December 31, 2013 from 24.9% for the same period a year ago. Selling, general and administrative expenses as a percentage of net sales decreased to 26.2% for the six months ended December 31, 2013 from 27.2% for the same period a year ago. The increase in dollars for the three and six months was due primarily from the addition of selling personnel.

[0001157523-14-000527:mdna:31]
Interest expense, net for the three months ended December 31, 2013 decreased by $31,000 to $110,000 as compared to $141,000 for the same period a year ago. Interest expense, net for the six months ended December 31, 2013 decreased by $87,000 to $231,000 as compared to $318,000 for the same period a year ago. The decreases in interest expense for the three and six months ended December 31, 2013 resulted from lower average outstanding debt during those periods as compared to the same periods a year ago.

[0001157523-14-000527:mdna:32]
The Company’s provision for income taxes for the three months ended December 31, 2013 decreased by $22,000 to $52,000 as compared to $74,000 for the same period a year ago. The Company’s provision for income taxes for the six months ended December 31, 2013 increased by $138,000 to a provision of $67,000 as compared to a benefit of $71,000 for the same period a year ago. The changes in the provision for income taxes were caused primarily by the increase in income before income taxes as well as a change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations for the three and six months ended December 31, 2013 as compared to the same periods a year ago. As a result, the Company’s effective rate for income tax was 12% and 35% for the three months ended December 31, 2013 and 2012, respectively and 12% and 19% for the six months ended December 31, 2013 and 2012, respectively.

[0001157523-14-000527:mdna:33]
Net income increased by $233,000 to $368,000 or $0.02 per diluted share for the three months ended December 31, 2013 as compared to $135,000 or $0.01 per diluted share for the same period a year ago. Net income increased by $790,000 to $491,000 or $0.03 per diluted share for the six months ended December 31, 2013 as compared to a loss of $(299,000) or $(0.02) per diluted share for the same period a year ago. The changes for the three and six months ended December 31, 2013 were primarily due to the items as described above.

[0001157523-14-000527:mdna:34]
[same as prior period, unchanged from 0001157523-13-005478:mdna:34]

[0001157523-14-000527:mdna:35]
During the six months ended December 31, 2013 the Company utilized a portion of its cash from operations ($3,951,000 of $4,096,000) to repay outstanding debt ($3,300,000), purchase treasury stock ($285,000) and purchase property, plant and equipment ($366,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-14-000527:mdna:36]
Accounts Receivable at December 31, 2013 decreased $4,507,000 to $13,704,000 as compared to $18,211,000 at June 30, 2013.  This decrease is primarily the result of the lower sales volume during the quarter ended December 31, 2013 as compared to the quarter ended June 30, 2013, which is typically the Company’s highest.

[0001157523-14-000527:mdna:37]
Inventories at December 31, 2013 increased $1,107,000 to $23,014,000 as compared to $21,907,000 at June 30, 2013. This increase is primarily the result of the Company keeping additional inventory of recently introduced products, level-loading its production facility in the Dominican Republic as well as the higher sales levels in the quarter ended June 30, 2013 as compared to the quarter ended December 31, 2013.

[0001157523-14-000527:mdna:38]
Accounts payable and accrued expenses decreased $531,000 to $6,484,000 as of December 31, 2013 as compared to $7,015,000 at June 30, 2013.  This decrease is due primarily to lower production levels during the quarter ended December 31, 2013 as compared to the quarter ended June 30, 2013.

[0001157523-14-000527:mdna:39]
As of December 31, 2013, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. As of December 31, 2013, the Company had $3,000,000 in outstanding borrowings and $8,000,000 in availability under the Revolving Credit Facility. The Company’s long-term debt is described more fully in Note 6 to the condensed consolidated financial statements.

[0001157523-14-000527:mdna:40]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-14-000527:mdna:41]
As of December 31, 2013 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
