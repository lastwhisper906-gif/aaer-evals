# NSSC notes — 0001157523-14-000527


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-14-000527:notes:1]
[same as prior period, unchanged from 0001157523-13-005478:notes:1]

[0001157523-14-000527:notes:2]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |  | Useful Life in Years |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |  |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,836 |  |  |  | 6,794 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,367 |  |  |  | 2,328 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,716 |  |  |  | 19,431 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 39,106 |  |  |  | 38,740 |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 32,594 |  |  |  | 32,154 |  |  |  |  |
|  |  | $ | 6,512 |  |  | $ | 6,586 |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-14-000527:notes:3]
[same as prior period, unchanged from 0001157523-13-005478:notes:3]

[0001157523-14-000527:notes:4]
Depreciation
 and amortization expense on property, plant, and equipment was
 $223,000 and $256,000 for the three months ended December 31, 2013
 and 2012, respectively and $440,000 and $507,000 for the six months
 ended December 31, 2013 and 2012, respectively.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001157523-14-000527:notes:5]
[same as prior period, unchanged from 0001157523-13-005478:notes:5]

[0001157523-14-000527:notes:6]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($121,000 and $128,000 in the three months
 ended December 31, 2013 and 2012, respectively and $252,000 and
 $249,000 in the six months ended December 31, 2013 and 2012,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($221,000 and $259,000 in the three
 months ended December 31, 2013 and 2012, respectively and $463,000
 and $482,000 in the six months ended December 31, 2013 and 2012,
 respectively).


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-14-000527:notes:7]
[same as prior period, unchanged from 0001157523-13-005478:notes:7]

[0001157523-14-000527:notes:8]
[same as prior period, unchanged from 0001157523-13-005478:notes:8]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001157523-14-000527:notes:9]
[same as prior period, unchanged from 0001157523-13-005478:notes:9]

[0001157523-14-000527:notes:10]
[same as prior period, unchanged from 0001157523-13-005478:notes:10]


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001157523-14-000527:notes:11]
[same as prior period, unchanged from 0001157523-13-005478:notes:11]

[0001157523-14-000527:notes:12]
For
 the six months ended December 31, 2013 and 2012 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.


## us-gaap:IncomeTaxPolicyTextBlock

[0001157523-14-000527:notes:13]
[same as prior period, unchanged from 0001157523-13-005478:notes:13]

[0001157523-14-000527:notes:14]
[same as prior period, unchanged from 0001157523-13-005478:notes:14]


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-14-000527:notes:15]
[same as prior period, unchanged from 0001157523-13-005478:notes:15]

[0001157523-14-000527:notes:16]
The
 Company had one customer with accounts receivable balance that
 comprised 13% of the Company’s accounts receivable at
 December 31, 2013 and two customers that aggregated 22% at June 30,
 2013. Sales to any one customer did not exceed 10% of net sales in
 any of the past two fiscal years.


## us-gaap:ReceivablesPolicyTextBlock

[0001157523-14-000527:notes:17]
[same as prior period, unchanged from 0001157523-13-005478:notes:17]

[0001157523-14-000527:notes:18]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $230,000 and $220,000 and for returns and other allowances of
 $870,000 and $1,055,000 as of December 31, 2013 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-14-000527:notes:19]
[same as prior period, unchanged from 0001157523-13-005478:notes:19]

[0001157523-14-000527:notes:20]
Inventories,
 net of reserves are valued at lower of cost (first-in, first-out
 method) or market. The Company regularly reviews parts and finished
 goods inventories on hand and, when necessary, records a provision
 for excess or obsolete inventories. The balance in these reserves
 was $3,517,000 and $3,392,000 as of December 31, 2013 and June 30,
 2013, respectively. The Company also regularly reviews the period
 over which its inventories will be converted to sales. Any
 inventories expected to convert to sales beyond 12 months from
 the balance sheet date are classified as non-current.

[0001157523-14-000527:notes:21]
[same as prior period, unchanged from 0001157523-13-005478:notes:21]

[0001157523-14-000527:notes:22]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
| Component parts |  | $ | 13,775 |  |  | $ | 13,112 |  |
| Work-in-process |  |  | 3,282 |  |  |  | 3,125 |  |
| Finished product |  |  | 5,957 |  |  |  | 5,670 |  |
|  |  | $ | 23,014 |  |  | $ | 21,907 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |  |
| Current |  | $ | 19,788 |  |  | $ | 18,471 |  |
| Non-current |  |  | 3,226 |  |  |  | 3,436 |  |
|  |  | $ | 23,014 |  |  | $ | 21,907 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001157523-14-000527:notes:23]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended
 December 31 (in thousands, except per share data):

[0001157523-14-000527:notes:24]
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 368 |  |  | $ | 135 |  |  |  | 19,408 |  |  |  | 19,154 |  |  | $ | 0.02 |  |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 36 |  |  |  | 342 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 368 |  |  | $ | 135 |  |  |  | 19,444 |  |  |  | 19,496 |  |  | $ | 0.02 |  |  | $ | 0.01 |  |

[0001157523-14-000527:notes:25]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the six months ended December
 31 (in thousands, except per share data):

[0001157523-14-000527:notes:26]
|  |  | Net Income (Loss) |  |  | Weighted Average Shares |  |  | Net Income (Loss) per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 491 |  |  | $ | (299 | ) |  |  | 19,366 |  |  |  | 19,125 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 27 |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 491 |  |  | $ | (299 | ) |  |  | 19,393 |  |  |  | 19,125 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |


## us-gaap:LongTermDebtTextBlock

[0001157523-14-000527:notes:27]
NOTE 6 - Long-Term Debt

[0001157523-14-000527:notes:28]
As
 of December 31, 2013, long-term debt consisted of a revolving
 credit facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000.

[0001157523-14-000527:notes:29]
Outstanding
 balances and interest rates as of December 31, 2013 and June 30,
 2013 are as follows:

[0001157523-14-000527:notes:30]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,100 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,100 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |

[0001157523-14-000527:notes:31]
The
 Revolving Credit Facility and Term Loans (collectively the
 “Agreement”) also provide for a LIBOR-based interest
 rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of
 outstanding debt to EBITDA, which is to be measured and adjusted
 quarterly, a prime rate-based option of the prime rate plus 0.25%
 and other terms and conditions as more fully described in the
 Agreement. In addition, the Agreement provides for availability
 under the Revolving Credit Facility to be limited to the lesser of
 $11,000,000 or the result of a borrowing base formula based upon
 the Company’s Accounts Receivables and Inventory values net
 of certain deductions. The Company’s obligations under the
 Agreement continue to be secured by all of its assets, including
 but not limited to, deposit accounts, accounts receivable,
 inventory, the Company’s corporate headquarters in
 Amityville, NY, equipment and fixtures and intangible assets. In
 addition, the Company’s wholly-owned subsidiaries, with the
 exception of the Company’s foreign subsidiaries, have issued
 guarantees and pledges of all of their assets to secure the
 Company’s obligations under the Agreement. All of the
 outstanding common stock of the Company’s domestic
 subsidiaries and 65% of the common stock of the Company’s
 foreign subsidiaries has been pledged to secure the Company’s
 obligations under the Agreement.

[0001157523-14-000527:notes:32]
The
 Agreement contains various restrictions and covenants including,
 among others, restrictions on payment of dividends, restrictions on
 borrowings and compliance with certain financial ratios, as defined
 in the Agreement.


## us-gaap:InventoryPolicyTextBlock

[0001157523-14-000527:notes:33]
[same as prior period, unchanged from 0001157523-13-005478:notes:31]

[0001157523-14-000527:notes:34]
[same as prior period, unchanged from 0001157523-13-005478:notes:32]

[0001157523-14-000527:notes:35]
[same as prior period, unchanged from 0001157523-13-005478:notes:33]

[0001157523-14-000527:notes:36]
[same as prior period, unchanged from 0001157523-13-005478:notes:34]


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-14-000527:notes:37]
[same as prior period, unchanged from 0001157523-13-005478:notes:35]

[0001157523-14-000527:notes:38]
[same as prior period, unchanged from 0001157523-13-005478:notes:36]

[0001157523-14-000527:notes:39]
[same as prior period, unchanged from 0001157523-13-005478:notes:37]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-14-000527:notes:40]
[same as prior period, unchanged from 0001157523-13-005478:notes:38]

[0001157523-14-000527:notes:41]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at December 31, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of December 31, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-14-000527:notes:42]
[same as prior period, unchanged from 0001157523-13-005478:notes:40]

[0001157523-14-000527:notes:43]
[same as prior period, unchanged from 0001157523-13-005478:notes:41]

[0001157523-14-000527:notes:44]
[same as prior period, unchanged from 0001157523-13-005478:notes:42]

[0001157523-14-000527:notes:45]
[same as prior period, unchanged from 0001157523-13-005478:notes:43]

[0001157523-14-000527:notes:46]
[same as prior period, unchanged from 0001157523-13-005478:notes:44]

[0001157523-14-000527:notes:47]
[same as prior period, unchanged from 0001157523-13-005478:notes:45]

[0001157523-14-000527:notes:48]
[same as prior period, unchanged from 0001157523-13-005478:notes:46]

[0001157523-14-000527:notes:49]
[same as prior period, unchanged from 0001157523-13-005478:notes:47]

[0001157523-14-000527:notes:50]
[same as prior period, unchanged from 0001157523-13-005478:notes:48]

[0001157523-14-000527:notes:51]
[same as prior period, unchanged from 0001157523-13-005478:notes:49]

[0001157523-14-000527:notes:52]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 December 31, 2013 due to their short-term maturities; Long-Term
 Debt: The carrying amount of the Company’s long-term debt,
 including the current portion, at December 31, 2013 in the amount
 of $13,100,000 approximates fair value.

[0001157523-14-000527:notes:53]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at December 31, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of December 31, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

[0001157523-14-000527:notes:54]
[same as prior period, unchanged from 0001157523-13-005478:notes:51]

[0001157523-14-000527:notes:55]
[same as prior period, unchanged from 0001157523-13-005478:notes:52]

[0001157523-14-000527:notes:56]
[same as prior period, unchanged from 0001157523-13-005478:notes:53]

[0001157523-14-000527:notes:57]
[same as prior period, unchanged from 0001157523-13-005478:notes:54]

[0001157523-14-000527:notes:58]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,836 | ) |  | $ | 3,964 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (261 | ) |  |  | 79 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,097 | ) |  | $ | 9,943 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |

[0001157523-14-000527:notes:59]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 December 31, 2013 and 2012, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $391,000 and $459,000 for the six months ended December 31, 2013
 and 2012, respectively. Amortization expense for each of the next
 five fiscal years is estimated to be as follows: 2014 - $781,000;
 2015 - $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 -
 $371,000. The weighted average amortization period for intangible
 assets was 14.4 years and 15.3 years at December 31, 2013 and
 2012, respectively.

[0001157523-14-000527:notes:60]
[same as prior period, unchanged from 0001157523-13-005478:notes:57]

[0001157523-14-000527:notes:61]
[same as prior period, unchanged from 0001157523-13-005478:notes:58]

[0001157523-14-000527:notes:62]
[same as prior period, unchanged from 0001157523-13-005478:notes:59]

[0001157523-14-000527:notes:63]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended December 31, 2013 and 2012 was
 $247,000 and $294,000, respectively. Advertising expense for the
 six months ended December 31, 2013 and 2012 was $612,000 and
 $721,000, respectively.

[0001157523-14-000527:notes:64]
[same as prior period, unchanged from 0001157523-13-005478:notes:61]

[0001157523-14-000527:notes:65]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended December 31, 2013 and 2012 was
 $1,252,000 and $1,319,000, respectively. Company-sponsored research
 and development expense for the six months ended December 31, 2013
 and 2012 was $2,538,000 and $2,655,000, respectively.

[0001157523-14-000527:notes:66]
[same as prior period, unchanged from 0001157523-13-005478:notes:63]

[0001157523-14-000527:notes:67]
[same as prior period, unchanged from 0001157523-13-005478:notes:64]

[0001157523-14-000527:notes:68]
Options
 to purchase 131,402 and 395,750 shares of common stock for the
 three months ended December 31, 2013 and 2012, respectively, were
 not included in the computation of Diluted EPS because their
 inclusion would be anti-dilutive.  These options were
 still outstanding at the end of the respective
 periods.

[0001157523-14-000527:notes:69]
Options
 to purchase 199,759 and 681,140 shares of common stock for the six
 months ended December 31, 2013 and 2012, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

[0001157523-14-000527:notes:70]
[same as prior period, unchanged from 0001157523-13-005478:notes:66]

[0001157523-14-000527:notes:71]
[same as prior period, unchanged from 0001157523-13-005478:notes:67]

[0001157523-14-000527:notes:72]
[same as prior period, unchanged from 0001157523-13-005478:notes:68]

[0001157523-14-000527:notes:73]
Stock-based
 compensation costs of $6 and $0 were recognized for the three
 months ended December 31, 2013 and 2012, respectively and $7 and $0
 for the six months ended December 31, 2013 and 2012, respectively
 .

[0001157523-14-000527:notes:74]
[same as prior period, unchanged from 0001157523-13-005478:notes:70]

[0001157523-14-000527:notes:75]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the six months ended December 31, 2013 and 2012.

[0001157523-14-000527:notes:76]
[same as prior period, unchanged from 0001157523-13-005478:notes:72]

[0001157523-14-000527:notes:77]
[same as prior period, unchanged from 0001157523-13-005478:notes:73]

[0001157523-14-000527:notes:78]
Recently
 Issued Accounting Standards

[0001157523-14-000527:notes:79]
[same as prior period, unchanged from 0001157523-13-005478:notes:75]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-14-000527:notes:80]
[same as prior period, unchanged from 0001157523-13-005478:notes:77]

[0001157523-14-000527:notes:81]
The
 Company maintains a 401(k) plan (“the Plan”) that
 covers all U.S. non-union employees with one or more years of
 service and is qualified under Sections 401(a) and 401(k) of the
 Internal Revenue Code. Company contributions to this plan are
 discretionary and totaled $25,000 and $23,000 for the three months
 ended December 31, 2013 and 2012, respectively and $51,000 and
 $44,000 for the six months ended December 31, 2013 and 2012,
 respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001157523-14-000527:notes:82]
[same as prior period, unchanged from 0001157523-13-005478:notes:79]

[0001157523-14-000527:notes:83]
During
 the six months ended December 31, 2013, certain employees exercised
 incentive stock options under the Company’s 2002 Plan
 totaling 326,800 shares. 324,100 of these exercises were completed
 as cashless exercises as allowed for under the 2002 Plan, where the
 exercise shares are issued by the Company in exchange for shares of
 the Company’s common stock that are owned by the optionees.
 The number of shares surrendered by the optionees are based upon
 the per share price on the effective date of the option exercise.
 In addition, the Company repurchased 50,000 shares of its Common
 Stock from its Chief Executive Officer (“CEO”). The
 purchase price was $5.70 per share, the previous business
 day’s closing price on NASDAQ, for an aggregate purchase
 price of $285,000. The repurchase was to fund the CEO’s tax
 liability associated with the exercise of 135,000 options granted
 to him under the 2002 Plan. The repurchase was approved by the
 Board of Directors of the Company, including all of the independent
 directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-14-000527:notes:84]
[same as prior period, unchanged from 0001157523-13-005478:notes:82]

[0001157523-14-000527:notes:85]
[same as prior period, unchanged from 0001157523-13-005478:notes:83]

[0001157523-14-000527:notes:86]
The
 Company does not expect that our unrecognized tax benefits will
 significantly change within the next twelve months. We file a
 consolidated U.S. income tax return and tax returns in certain
 state and local and foreign jurisdictions. As of December 30, 2013
 we remain subject to examination in all tax jurisdictions for all
 relevant jurisdictional statutes for fiscal years 2008 and
 thereafter.

[0001157523-14-000527:notes:87]
The
 Company has identified its U.S. Federal income tax return and its
 State return in New York as its major tax jurisdictions. During the
 six months ended December 31, 2013 the Company increased its
 reserve for uncertain income tax positions by $11,000. As a result,
 as of December 31, 2013 and June 30, 2013 the Company has a
 long-term accrued income tax liability of $164,000 and $153,000,
 respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-14-000527:notes:88]
[same as prior period, unchanged from 0001157523-13-005478:notes:86]

[0001157523-14-000527:notes:89]
[same as prior period, unchanged from 0001157523-13-005478:notes:87]

[0001157523-14-000527:notes:90]
Under
 the 2012 Employee Plan, stock options may be granted to valued
 employees with a term of up to 10 years at an exercise price equal
 to or greater than the fair market value on the date of grant and
 are exercisable, in whole or in part, at 20% per year beginning on
 the date of grant. An option granted under this plan shall vest in
 full upon a “change in control” as defined in the plan.
 At December 31, 2013, 78,500 stock options were granted, 15,700
 stock options were exercisable and 871,500 stock options were
 available for grant under this plan.

[0001157523-14-000527:notes:91]
[same as prior period, unchanged from 0001157523-13-005478:notes:89]

[0001157523-14-000527:notes:92]
[same as prior period, unchanged from 0001157523-13-005478:notes:90]

[0001157523-14-000527:notes:93]
The
 following table reflects activity under the 2012 Employee Plan for
 the six months ended December 31, 2013:

[0001157523-14-000527:notes:94]
|  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | -- |  |  | $ | -- |  |
| Granted |  |  | 78,500 |  |  |  | 5.73 |  |
| Terminated |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 78,500 |  |  | $ | 5.73 |  |
| Exercisable, end of period |  |  | 15,700 |  |  | $ | 5.73 |  |
| Weighted average fair value at grant date of options granted |  | $ | 3.84 |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 44,120 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 8,824 |  |  |  |  |  |

[0001157523-14-000527:notes:95]
The
 following table summarizes information about stock options
 outstanding under the 2012 Employee Plan at December 31,
 2013:

[0001157523-14-000527:notes:96]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable |  |  | Weighted average exercise price |  |
| $ 4.00 - $ 7.00 |  |  |  | 78,500 |  |  |  | 9.8 |  |  | $ | 5.73 |  |  |  | 15,700 |  |  | $ | 5.73 |  |
|  |  |  |  | 78,500 |  |  |  | 9.8 |  |  | $ | 5.73 |  |  |  | 15,700 |  |  | $ | 5.73 |  |

[0001157523-14-000527:notes:97]
As
 of December 31, 2013, there was $297,000 of unearned stock-based
 compensation cost related to share-based compensation arrangements
 granted under the 2012 Employee Plan. The total fair value of the
 options vesting during the three and six months ended December 31,
 2013 under this plan was $37,000 and $60,000,
 respectively.

[0001157523-14-000527:notes:98]
[same as prior period, unchanged from 0001157523-13-005478:notes:96]

[0001157523-14-000527:notes:99]
Under
 the 2012 Non-Employee Plan, stock options may be granted with a
 term of up to 10 years at an exercise price equal to or greater
 than the fair market value on the date of grant and are exercisable
 in whole or in part at 20% per year beginning on the date of grant.
 An option granted under this plan shall vest in full upon a
 “change in control” as defined in the plan. At December
 31, 2013, 25,000 stock options were granted, 5,000 stock options
 were exercisable and 25,000 stock options were available for grant
 under this plan.

[0001157523-14-000527:notes:100]
The
 following table reflects activity under the 2012 Non-Employee Plan
 for the six months ended December 31, 2013:

[0001157523-14-000527:notes:101]
|  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | -- |  |  | $ | -- |  |
| Granted |  |  | 25,000 |  |  |  | 4.88 |  |
| Terminated |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 25,000 |  |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 5,000 |  |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  | $ | 3.30 |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 35,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 7,000 |  |  |  |  |  |

[0001157523-14-000527:notes:102]
The
 following table summarizes information about stock options
 outstanding under the 2012 Non-Employee Plan at December 31,
 2013:

[0001157523-14-000527:notes:103]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable |  |  | Weighted average exercise price |  |
| $ 4.00 - $ 5.00 |  |  |  | 25,000 |  |  |  | 9.7 |  |  | $ | 4.88 |  |  |  | 5,000 |  |  | $ | 4.88 |  |
|  |  |  |  | 25,000 |  |  |  | 9.7 |  |  | $ | 4.88 |  |  |  | 5,000 |  |  | $ | 4.88 |  |

[0001157523-14-000527:notes:104]
As
 of December 31, 2013, there was $80,000 of unearned stock-based
 compensation cost related to share-based compensation arrangements
 granted under the 2012 Employee Plan. The total fair value of the
 options vesting during the three and six months ended December 31,
 2013 under this plan was $17,000 and $0, respectively.

[0001157523-14-000527:notes:105]
[same as prior period, unchanged from 0001157523-13-005478:notes:102]

[0001157523-14-000527:notes:106]
Under
 the 2002 Employee Plan, stock options have been granted to key
 employees with a term of 10 years at an exercise price equal to the
 fair market value on the date of grant and are exercisable in whole
 or in part at 20% per year from the date of grant.  At
 December 31, 2013, 1,471,480 stock options were granted, 294,100
 stock options were exercisable and no further stock options were
 available for grant under this plan. No options were granted under
 this plan during the six months ended December 31,
 2012.

[0001157523-14-000527:notes:107]
The
 following table reflects activity under the 2002 Employee plan for
 the six months ended December 31,:

[0001157523-14-000527:notes:108]
|  |  | 2013 |  |  | 2012 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated/Lapsed |  |  | (30,240 | ) |  |  | 1.74 |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | (326,800 | ) |  |  | 2.70 |  |  |  | (27,000 | ) |  |  | 1.76 |  |
| Outstanding, end of period |  |  | 294,100 |  |  | $ | 6.07 |  |  |  | 1,353,140 |  |  | $ | 2.95 |  |
| Exercisable, end of period |  |  | 294,100 |  |  | $ | 6.07 |  |  |  | 1,353,140 |  |  | $ | 2.95 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 854,000 |  |  |  |  |  |  | $ | 36,000 |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 254,000 |  |  |  |  |  |  | $ | 1,459,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 254,000 |  |  |  |  |  |  | $ | 1,459,000 |  |  |  |  |  |

[0001157523-14-000527:notes:109]
326,800
 and 27,000 stock options were exercised during the six months ended
 December 31, 2013 and 2012, respectively. 324,100 of the 326,800
 exercises were settled by exchanging 164,859 shares of the
 Company’s common stock of which 85,170 was retired upon
 receipt. The 27,000 exercise was settled by exchanging 13,807
 shares of the Company’s common stock, which was retired upon
 receipt. Cash received from option exercises was $5,103 and $0 for
 the six months ended December 31, 2013 and 2012, respectively, and
 the actual tax benefit realized for the tax deductions from option
 exercises was $0 for each of these periods.

[0001157523-14-000527:notes:110]
The
 following table summarizes information about stock options
 outstanding under the 2002 Employee Plan at December 31,
 2013:

[0001157523-14-000527:notes:111]
|  |  |  | Options outstanding and exerciseable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |
| $ 1.62 - $ 4.00 |  |  |  | 28,350 |  |  |  | 0.2 |  |  | $ | 1.90 |  |
| $ 4.01 - $ 7.50 |  |  |  | 228,250 |  |  |  | 2.3 |  |  |  | 5.75 |  |
| $ 7.51 - $11.16 |  |  |  | 37,500 |  |  |  | 2.2 |  |  |  | 11.16 |  |
|  |  |  |  | 294,100 |  |  |  | 2.1 |  |  | $ | 6.07 |  |

[0001157523-14-000527:notes:112]
[same as prior period, unchanged from 0001157523-13-005478:notes:109]

[0001157523-14-000527:notes:113]
The
 following table reflects activity under the 2000 Non-employee Plan
 for the six months ended December 31,

[0001157523-14-000527:notes:114]
|  |  | 2013 |  |  | 2012 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated/Lapsed |  |  | (30,000 | ) |  |  | 5.03 |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | -- |  |  | $ | -- |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of period |  |  | -- |  |  | $ | -- |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-14-000527:notes:115]
NOTE 10 - Commitments and Contingencies

[0001157523-14-000527:notes:116]
Leases

[0001157523-14-000527:notes:117]
The
 Company is committed under various operating leases, not including
 the land lease discussed below, which do not extend beyond fiscal
 2016.

[0001157523-14-000527:notes:118]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $9,000 and $12,000 for the three months ended
 December 31, 2013 and 2012, respectively and $18,000 and $23,000
 for the six months ended December 31, 2013 and 2012,
 respectively.

[0001157523-14-000527:notes:119]
Land
 Lease

[0001157523-14-000527:notes:120]
On
 April 26, 1993, one of the Company's foreign subsidiaries entered
 into a 99 year lease, expiring in 2092, for approximately four
 acres of land in the Dominican Republic at an annual cost of
 $288,000, on which the Company's principal production facility is
 located.

[0001157523-14-000527:notes:121]
Litigation

[0001157523-14-000527:notes:122]
In
 the normal course of business, the Company is a party to claims
 and/or litigation. Management believes that the settlement of such
 claims and/or litigation, considered in the aggregate, will not
 have a material adverse effect on the Company's financial position
 and results of operations.

[0001157523-14-000527:notes:123]
Employment
 Agreements

[0001157523-14-000527:notes:124]
As
 of June 30, 2013, the Company was obligated under two employment
 agreements and one severance agreement.  The employment
 agreements are with the Company’s CEO and Senior Vice
 President of Sales and Marketing (“the SVP”). The
 employment agreement with the CEO provides for an annual salary of
 $587,000, as adjusted for inflation; incentive compensation as may
 be approved by the Board of Directors from time to time and a
 termination payment in an amount up to 299% of the average of the
 prior five calendar year's compensation, subject to certain
 limitations, as defined in the agreement.  The employment
 agreement renews annually in August unless either party gives the
 other notice of non-renewal at least six months prior to the end of
 the applicable term. The employment agreement with the SVP expires
 in October 2014 and provides for an annual salary of $274,400 and,
 if terminated by the Company without cause, severance of nine
 months’ salary and continued company-sponsored health
 insurance for six months from the date of termination. The
 severance agreement provides for payments equal to nine months of
 salary and six months of health insurance in the event of a
 non-voluntary termination of employment without cause.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-14-000527:notes:125]
[same as prior period, unchanged from 0001157523-13-005478:notes:122]

[0001157523-14-000527:notes:126]
[same as prior period, unchanged from 0001157523-13-005478:notes:123]

[0001157523-14-000527:notes:127]
[same as prior period, unchanged from 0001157523-13-005478:notes:124]

[0001157523-14-000527:notes:128]
| Financial Information Relating to Domestic and Foreign Operations |  |
|  |  | Three months ended December 31, |  |  | Six months ended December 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
|  |  | (in thousands) |  |  | (in thousands) |  |
| Sales to external customers (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 17,593 |  |  | $ | 16,105 |  |  | $ | 33,887 |  |  | $ | 30,370 |  |
| Foreign |  |  | 760 |  |  |  | 1,107 |  |  |  | 1,705 |  |  |  | 2,058 |  |
| Total Net Sales |  | $ | 18,353 |  |  | $ | 17,212 |  |  | $ | 35,592 |  |  | $ | 32,428 |  |
| Identifiable assets: |  | December 31, 2013 |  |  | June 30, 2013 |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 47,686 |  |  | $ | 51,141 |  |  |  |  |  |  |  |  |  |
| Dominican Republic (2) |  |  | 12,636 |  |  |  | 12,763 |  |  |  |  |  |  |  |  |  |
| Total Identifiable Assets |  | $ | 60,322 |  |  | $ | 63,903 |  |  |  |  |  |  |  |  |  |

[0001157523-14-000527:notes:129]
[same as prior period, unchanged from 0001157523-13-005478:notes:126]

[0001157523-14-000527:notes:130]
(2)
 Consists primarily of inventories (December 31, 2013 = $8,982; June
 30, 2013 = $9,105) and fixed assets (December 31, 2013 = $3,550;
 June 30, 2013 = $3,546) located at the Company's principal
 manufacturing facility in the Dominican Republic.
