# NSSC note change history — 0001157523-13-005478 → 0001157523-14-000527


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-02-10):
[0001157523-14-000527:note_history:1]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $9,000 and $12,000 for the three months ended
 December 31, 2013 and 2012, respectively and $18,000 and $23,000
 for the six months ended December 31, 2013 and 2012,
 respectively.
  (was, 2013-11-12, similarity 0.8173):
[0001157523-13-005478:note_history:1]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $9,000 and $13,000 for the three months ended
 September 30, 2013 and 2012, respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-02-10):
[0001157523-14-000527:note_history:2]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 December 31, 2013 due to their short-term maturities; Long-Term
 Debt: The carrying amount of the Company’s long-term debt,
 including the current portion, at December 31, 2013 in the amount
 of $13,100,000 approximates fair value.
  (was, 2013-11-12, similarity 0.987):
[0001157523-13-005478:note_history:2]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 September 30, 2013 due to their short-term maturities; Long-Term
 Debt: The carrying amount of the Company’s long-term debt,
 including the current portion, at September 30, 2013 in the amount
 of $13,500,000 approximates fair value.

- changed (2014-02-10):
[0001157523-14-000527:note_history:3]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at December 31, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of December 31, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.
  (was, 2013-11-12, similarity 0.9858):
[0001157523-13-005478:note_history:3]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at September 30, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of September 30, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

- changed (2014-02-10):
[0001157523-14-000527:note_history:4]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $230,000 and $220,000 and for returns and other allowances of
 $870,000 and $1,055,000 as of December 31, 2013 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.
  (was, 2013-11-12, similarity 0.9926):
[0001157523-13-005478:note_history:4]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $230,000 and $220,000 and for returns and other allowances of
 $815,000 and $1,055,000 as of September 30, 2013 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.

- changed (2014-02-10):
[0001157523-14-000527:note_history:5]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,836 | ) |  | $ | 3,964 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (261 | ) |  |  | 79 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,097 | ) |  | $ | 9,943 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |
  (was, 2013-11-12, similarity 0.9933):
[0001157523-13-005478:note_history:5]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,653 | ) |  | $ | 4,147 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (249 | ) |  |  | 91 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,902 | ) |  | $ | 10,138 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |

- added (2014-02-10):
[0001157523-14-000527:note_history:6]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 December 31, 2013 and 2012, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $391,000 and $459,000 for the six months ended December 31, 2013
 and 2012, respectively. Amortization expense for each of the next
 five fiscal years is estimated to be as follows: 2014 - $781,000;
 2015 - $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 -
 $371,000. The weighted average amortization period for intangible
 assets was 14.4 years and 15.3 years at December 31, 2013 and
 2012, respectively.

- changed (2014-02-10):
[0001157523-14-000527:note_history:7]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended December 31, 2013 and 2012 was
 $247,000 and $294,000, respectively. Advertising expense for the
 six months ended December 31, 2013 and 2012 was $612,000 and
 $721,000, respectively.
  (was, 2013-11-12, similarity 0.8411):
[0001157523-13-005478:note_history:7]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended September 30, 2013 and 2012 was
 $365,000 and $427,000, respectively.

- changed (2014-02-10):
[0001157523-14-000527:note_history:8]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended December 31, 2013 and 2012 was
 $1,252,000 and $1,319,000, respectively. Company-sponsored research
 and development expense for the six months ended December 31, 2013
 and 2012 was $2,538,000 and $2,655,000, respectively.
  (was, 2013-11-12, similarity 0.8229):
[0001157523-13-005478:note_history:8]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended September 30, 2013 and 2012 was
 $1,286,000 and $1,336,000, respectively.

- changed (2014-02-10):
[0001157523-14-000527:note_history:9]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended
 December 31 (in thousands, except per share data):
  (was, 2013-11-12, similarity 0.9856):
[0001157523-13-005478:note_history:9]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended
 September 30 (in thousands, except per share data):

- added (2014-02-10):
[0001157523-14-000527:note_history:10]
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 368 |  |  | $ | 135 |  |  |  | 19,408 |  |  |  | 19,154 |  |  | $ | 0.02 |  |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 36 |  |  |  | 342 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 368 |  |  | $ | 135 |  |  |  | 19,444 |  |  |  | 19,496 |  |  | $ | 0.02 |  |  | $ | 0.01 |  |

- changed (2014-02-10):
[0001157523-14-000527:note_history:11]
Options
 to purchase 131,402 and 395,750 shares of common stock for the
 three months ended December 31, 2013 and 2012, respectively, were
 not included in the computation of Diluted EPS because their
 inclusion would be anti-dilutive.  These options were
 still outstanding at the end of the respective
 periods.
  (was, 2013-11-12, similarity 0.9877):
[0001157523-13-005478:note_history:11]
Options
 to purchase 268,116 and 1,383,140 shares of common stock for the
 three months ended September 30, 2013 and 2012, respectively, were
 not included in the computation of Diluted EPS because their
 inclusion would be anti-dilutive.  These options were
 still outstanding at the end of the respective
 periods.

- added (2014-02-10):
[0001157523-14-000527:note_history:12]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the six months ended December
 31 (in thousands, except per share data):

- added (2014-02-10):
[0001157523-14-000527:note_history:13]
Options
 to purchase 199,759 and 681,140 shares of common stock for the six
 months ended December 31, 2013 and 2012, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

- changed (2014-02-10):
[0001157523-14-000527:note_history:14]
Stock-based
 compensation costs of $6 and $0 were recognized for the three
 months ended December 31, 2013 and 2012, respectively and $7 and $0
 for the six months ended December 31, 2013 and 2012, respectively
 .
  (was, 2013-11-12, similarity 0.7524):
[0001157523-13-005478:note_history:14]
Stock-based
 compensation costs of $1 and $0 were recognized for the three
 months ended September 30, 2013 and 2012,
 respectively.

- added (2014-02-10):
[0001157523-14-000527:note_history:15]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the six months ended December 31, 2013 and 2012.

- added (2014-02-10):
[0001157523-14-000527:note_history:16]
For
 the six months ended December 31, 2013 and 2012 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.

- changed (2014-02-10):
[0001157523-14-000527:note_history:17]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($121,000 and $128,000 in the three months
 ended December 31, 2013 and 2012, respectively and $252,000 and
 $249,000 in the six months ended December 31, 2013 and 2012,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($221,000 and $259,000 in the three
 months ended December 31, 2013 and 2012, respectively and $463,000
 and $482,000 in the six months ended December 31, 2013 and 2012,
 respectively).
  (was, 2013-11-12, similarity 0.7507):
[0001157523-13-005478:note_history:17]
The
 Company records the amount billed to customers in net sales
 ($131,000 and $121,000 in the three months ended September 30, 2013
 and 2012, respectively) and classifies the costs associated with
 these revenues in cost of sales ($242,000 and $223,000 in the three
 months ended September 30, 2013 and 2012,
 respectively).

- removed (2014-02-10):
[0001157523-13-005478:note_history:18]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $230,000 for the three months ended
 September 30, 2013 and 2012, respectively. Amortization expense for
 each of the next five fiscal years is estimated to be as follows:
 2014 - $781,000; 2015 - $667,000; 2016 - $529,000; 2017 - $441,000
 and 2018 - $371,000. The weighted average amortization period for
 intangible assets was 14.6 years and 15.5 years at September
 30, 2013 and 2012, respectively.

- removed (2014-02-10):
[0001157523-13-005478:note_history:19]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at average exchange rates
 prevailing during the fiscal year.  The realized and
 unrealized gains and losses associated with foreign currency
 translation, as well as related other comprehensive income, were
 not material for the three months ended September 30, 2013 and
 2012.

- removed (2014-02-10):
[0001157523-13-005478:note_history:20]
For
 the three months ended September 30, 2013 and 2012, the Company's
 operations did not give rise to material items includable in
 comprehensive income, which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.

- removed (2014-02-10):
[0001157523-13-005478:note_history:21]
In
 July 2012, the FASB amended its authoritative guidance related to
 testing indefinite-lived intangible assets for impairment.
  Under the revised guidance, entities testing their
 indefinite-lived intangible assets for impairment have the option
 of performing a qualitative assessment before performing further
 impairment testing.  If entities determine, on the basis of
 qualitative factors, that it is more-likely-than-not that the asset
 is impaired, a quantitative test is required.  The guidance
 became effective in the beginning of the Company’s fiscal
 2014.  The adoption of this guidance did not have an impact on
 the Company’s consolidated financial statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-10):
[0001157523-14-000527:note_history:22]
As
 of December 31, 2013, long-term debt consisted of a revolving
 credit facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000.
  (was, 2013-11-12, similarity 0.9933):
[0001157523-13-005478:note_history:22]
As
 of September 30, 2013, long-term debt consisted of a revolving
 credit facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000.

- changed (2014-02-10):
[0001157523-14-000527:note_history:23]
Outstanding
 balances and interest rates as of December 31, 2013 and June 30,
 2013 are as follows:
  (was, 2013-11-12, similarity 0.9714):
[0001157523-13-005478:note_history:23]
Outstanding
 balances and interest rates as of September 30, 2013 and June 30,
 2013 are as follows:

- changed (2014-02-10):
[0001157523-14-000527:note_history:24]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,100 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,100 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
  (was, 2013-11-12, similarity 0.9889):
[0001157523-13-005478:note_history:24]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,500 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,500 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-10):
[0001157523-14-000527:note_history:25]
Outstanding
 balances and interest rates as of December 31, 2013 and June 30,
 2013 are as follows:
  (was, 2013-11-12, similarity 0.9714):
[0001157523-13-005478:note_history:25]
Outstanding
 balances and interest rates as of September 30, 2013 and June 30,
 2013 are as follows:

- changed (2014-02-10):
[0001157523-14-000527:note_history:26]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,100 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,100 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
  (was, 2013-11-12, similarity 0.9889):
[0001157523-13-005478:note_history:26]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,500 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,500 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
