# NSSC 8-K — 0001144204-16-123444 filed 2016-09-09

## item codes, every 8-K on or before 2016-11-07

- 2016-09-09 0001144204-16-123444 — 2.02, 9.01
- 2016-07-01 0001144204-16-111270 — 1.01
- 2016-05-10 0001144204-16-100142 — 2.02, 9.01
- 2015-12-14 0001144204-15-070760 — 5.07
- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2016-11-07

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-16-123444:8k_2_02:1]
EX-99.1
2
v448602_ex99-1.htm
EXHIBIT 99.1

[0001144204-16-123444:8k_2_02:2]
Exhibit 99.1

[0001144204-16-123444:8k_2_02:3]
NAPCO
Announces Fourth Quarter and Fiscal Year 2016 Results

[0001144204-16-123444:8k_2_02:4]
- Record Annual Sales of $82.5 Million -

[0001144204-16-123444:8k_2_02:5]
- Record Quarterly Sales of $24.1 Million
-

[0001144204-16-123444:8k_2_02:6]
- Record Quarterly Net income of $3.4 Million
or $0.18 Per Share -

[0001144204-16-123444:8k_2_02:7]
- Annual Net Income Increases 19% to $5.8
Million or $0.31 Per Share -

[0001144204-16-123444:8k_2_02:8]
- Management to Host Conference Call Today
at 11 a.m. –

[0001144204-16-123444:8k_2_02:9]
AMITYVILLE, N.Y., Sept. 6, 2016 /PRNewswire/ -- NAPCO Security
Technologies, Inc. (NasdaqGS: NSSC), one of the world's leading solutions providers and manufacturers of high tech electronic intrusion
security, IoT connected home, video and fire systems, as well as enterprise-class access control and door locking products, today
announced financial results for its fourth quarter and fiscal year ended June 30, 2016.

[0001144204-16-123444:8k_2_02:10]
Highlights:

[0001144204-16-123444:8k_2_02:11]
|  | · | Net sales for the fiscal year were a record $82.5 million, up 6% from the same period last year. Net sales for the fourth quarter were a record $24.1 million, up 5% from the same quarter last year. |

[0001144204-16-123444:8k_2_02:12]
|  | · | Recurring revenue for the fiscal year and fourth quarter increased 63% and 68%, respectively, and grew sequentially by 14%. |

[0001144204-16-123444:8k_2_02:13]
|  | · | Income before taxes for fiscal 2016 increased 21% to $6.1 million from $5.1 million a year ago. |

[0001144204-16-123444:8k_2_02:14]
|  | · | Earnings per share (diluted) for the fiscal year increased 24% to $0.31, as compared to $0.25 for the same period a year ago. Earnings per share (diluted) for the fourth quarter was $0.18, as compared to $0.18 last year. |

[0001144204-16-123444:8k_2_02:15]
|  | · | Cash flows from operating activities for fiscal 2016 were a record high of $9.2 million, increasing by 136% versus fiscal 2015. |

[0001144204-16-123444:8k_2_02:16]
|  | · | Debt, net of cash decreased $7.4 million to $1.0 million in fiscal 2016 and has been reduced by $34.9 million from $35.9 million since acquiring Marks in August of 2008. |

[0001144204-16-123444:8k_2_02:17]
Richard Soloway, Chairman and President, said, "On the
heels of a strong fiscal 2015, we have delivered an even stronger fiscal 2016, with record-setting sales, net income and operating
cash flows. Even more impressive is that this was the fifth consecutive quarter of record-breaking revenue. These gains were the
direct result of strength in our electronic door locking systems, as well as recurring revenue generated from our StarLink®
and iBridge® product lines."

[0001144204-16-123444:8k_2_02:18]
Mr. Soloway continued, "Our recurring revenue businesses
continued to deliver solid and consistent growth, with a sales increase of 63% for the 2016 fiscal year. StarLink alarm communicators,
both in AT&T 3G/4G and Verizon CDMA versions, garnered substantial market share increases, as they provided a superior solution
as replacements for aging 2G communicators, and as primary alarm communicators on new installations. The beginning of calendar
2016 also saw the highly successful and well-received launch of our StarLink Fire and commercial communicators. These introductions
solidly position NAPCO in the lucrative fire alarm communicator category, which should see rapid future growth as fire systems
reporting through increasingly obsolete traditional phone lines switch over to more advanced wireless technology."

[0001144204-16-123444:8k_2_02:19]
"Another recurring revenue addition to the StarLink wireless
communicator product family, which was showcased at ISC West and will be launched this Fall, is StarLink Connect, a universal cellular
solution that can be installed on tens of millions of existing and newly-installed alarm systems and gives consumers control of
a variety of connected home services. This IoT product provides alarm dealers with the ability to communicate alarm signals, program
systems wirelessly, and supply customers with a mobile application to operate alarms and many of the iBridge connected home services,
such as lighting control, energy management, remote video camera viewing and recording, as well as locking control, from any smart
device."

[0001144204-16-123444:8k_2_02:20]
Mr. Soloway added, "NAPCO takes pride in protecting colleges,
universities and K-12 schools, across our country, with its broad, integrated line of security products, which uniquely offer superior
product solutions. Our Company has played a leadership role in augmenting school safety and security preparedness by creating the
proprietary School Access-control Vulnerability Index, or SAVI, audit system. SAVI quantitatively measures a school's security
level in the form of an index and takes an active approach in training security dealers and end-user school officials on how to
significantly reduce or prevent a mass incident. Sales have increased considerably for our school security products through our
advanced wireless locking and access control solutions, marketed by our Alarm Lock, Marks and Continental Divisions and our high-technology
alarm and communication systems from our NAPCO Division."

[0001144204-16-123444:8k_2_02:21]
"Due to the strong growth opportunities in school security,
we have hired a well-known expert in the field, Mr. Byron Thurmond, formerly of the Houston, Texas Independent School District,
the 7th largest school system in the U. S. In conjunction with this appointment,  we have created a nationwide School Safety
Sales Division, which is reporting directly to him. Our growth and profit from this business vertical, which is comprised of more
than 100,000 K-12 schools and 10,000 higher-education institutions, should be greatly enhanced with this dedicated division."

[0001144204-16-123444:8k_2_02:22]
Mr. Soloway concluded, "We have great confidence that we
are well-positioned for vibrant, sustainable growth for the future and look forward to fiscal 2017.  Our significant market
presence in product categories that generate recurring revenue, advanced access control and locking products and IoT Connected
Home product entries, bodes well for continued growth of our topline sales. We believe that in today's world the need for innovative
security solutions has never been greater and NAPCO, as a unique "pure play" public company within the security sector,
offers shareholders a great opportunity to leverage our future successes."

[0001144204-16-123444:8k_2_02:23]
Fiscal 2016 Results

[0001144204-16-123444:8k_2_02:24]
Net sales for the three months ended June 30, 2016 increased
5% to a record $24.1 million, as compared to $23.0 million for the same period one year ago. Net sales for the year ended June
30, 2016 increased 6% to a record $82.5 million, as compared to $77.8 million for the same period one year ago. Selling, general
and administrative expenses for the quarter were $5.9 million, or 24.4% of sales, as compared to $5.9 million, or 25.6 % of sales,
for the same period in 2015. Selling, general and administrative expenses for the fiscal year were $21.3 million, or 25.8 % of
sales, as compared to $20.8 million, or 26.7% of sales, for the same period in 2015. The increase was due primarily to additional
sales staff and advertising expenditures to support ongoing product introductions.

[0001144204-16-123444:8k_2_02:25]
Operating income for the three months ended June 30, 2016 increased
8% to $3.8 million as compared to $3.5 million for the same quarter a year ago. Operating income for the fiscal year ended June
30, 2016 increased 20% to $6.3 million as compared to $5.3 million for the same period a year ago. Adjusted EBITDA* for the three
months ended June 30, 2016 increased 7 % to $4.1 million, or $0.22 per share, as compared to $3.9 million or $0.20 per share for
the same quarter last year. Adjusted EBITDA* for the fiscal year ended June 30, 2016 increased 13% to $7.8 million, or $0.42 per
share, as compared to $7.0 million, or $0.36 per share, for the same period a year ago (*see table attached).

[0001144204-16-123444:8k_2_02:26]
Net income for the three months ended June 30, 2016 increased
3%, to a record $3.4 million, or $0.18 per share, as compared to $3.3 million, or $0.18 per share, for the same quarter last year.
Net income for the fiscal year ended June 30, 2016 increased 19%, to $5.8 million, or $0.31 per share, as compared to $4.8 million,
or $0.25 per share, for the same period last year.

[0001144204-16-123444:8k_2_02:27]
Balance Sheet Summary

[0001144204-16-123444:8k_2_02:28]
At June 30, 2016, the Company had $3.8 million in cash and cash
equivalents, as compared to $2.3 million at June 30, 2015. NAPCO had working capital of $36.9 million as compared with working
capital of $35.6 million at June 30, 2015. Current ratio was 5.1:1 at June 30, 2016 and 4.8:1 at June 30, 2015. Debt, net of cash,
was $1.0 million at June 30, 2016 and $8.4 at June 30, 2015.

[0001144204-16-123444:8k_2_02:29]
NAPCO Security Technologies, Inc. Annual Meeting of Stockholders

[0001144204-16-123444:8k_2_02:30]
NAPCO Security Technologies, Inc. annual meeting is set for
December 13, 2016, for shareholders of record as of October 25, 2016.

[0001144204-16-123444:8k_2_02:31]
Conference Call Information: Management will conduct a conference
call at 11 a.m. ET today, September 6, 2016. Interested parties may participate in the call by dialing 1-877-407-4018 or for international
callers, 1-201-689-8471, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on
replay starting at 2 p.m. ET on September 6, 2016 and ending on September 13, 2016 at 11:59 p.m. ET. For the replay, please dial
1-877-870-5176 domestically, or 1-858-384-5517 for international callers, and use the replay access code 13644638. In addition,
the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=121005.

[0001144204-16-123444:8k_2_02:32]
About NAPCO Security Technologies, Inc.

[0001144204-16-123444:8k_2_02:33]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security, including recurring revenue, connected home, video,
fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected
home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville,
New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial, institutional,
residential and government applications. NAPCO products have earned a reputation for innovation, technical excellence and
reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security market. For
additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-16-123444:8k_2_02:34]
Safe Harbor Statement

[0001144204-16-123444:8k_2_02:35]
This press release contains forward-looking statements that
involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated
in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the
Securities and Exchange Commission

[0001144204-16-123444:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONSOLIDATED BALANCE SHEETS |
| June 30, 2016 and 2015 |
| (In Thousands) |
| ASSETS |

[0001144204-16-123444:8k_2_02:37]
|  |  | 2016 |  |  | 2015 |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,805 |  |  | $ | 2,346 |  |
| Accounts receivable, net of reserves and allowances |  |  | 19,012 |  |  |  | 17,994 |  |
| Inventories |  |  | 21,428 |  |  |  | 22,757 |  |
| Prepaid expenses and other current assets |  |  | 936 |  |  |  | 1,046 |  |
| Deferred income taxes |  |  | 703 |  |  |  | 880 |  |
| Total Current Assets |  |  | 45,884 |  |  |  | 45,023 |  |
| Inventories - non-current |  |  | 3,909 |  |  |  | 4,113 |  |
| Deferred income taxes |  |  | 436 |  |  |  | 634 |  |
| Property, plant and equipment, net |  |  | 6,049 |  |  |  | 6,234 |  |
| Intangible assets, net |  |  | 8,357 |  |  |  | 8,886 |  |
| Other assets |  |  | 134 |  |  |  | 147 |  |
| TOTAL ASSETS |  | $ | 64,769 |  |  | $ | 65,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 300 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 4,328 |  |  |  | 3,954 |  |
| Accrued expenses |  |  | 1,893 |  |  |  | 1,624 |  |
| Accrued salaries and wages |  |  | 2,467 |  |  |  | 2,250 |  |
| Accrued income taxes |  |  | 8 |  |  |  | 5 |  |
| Total Current Liabilities |  |  | 8,996 |  |  |  | 9,433 |  |
| Long-term debt, net of current maturities |  |  | 4,500 |  |  |  | 9,100 |  |
| Total Liabilities |  |  | 13,496 |  |  |  | 18,533 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 21,049,243 shares issued; and 18,786,893 and 18,966,028 shares outstanding, respectively |  |  | 211 |  |  |  | 210 |  |
| Additional paid-in capital |  |  | 16,622 |  |  |  | 16,133 |  |
| Retained earnings |  |  | 46,172 |  |  |  | 40,399 |  |
|  |  |  | 63,005 |  |  |  | 56,742 |  |
| Less: Treasury Stock, at cost (2,329,850 and 2,083,215 shares, respectively) |  |  | (11,732 | ) |  |  | (10,238 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 51,273 |  |  |  | 46,504 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 64,769 |  |  | $ | 65,037 |  |

[0001144204-16-123444:8k_2_02:38]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONSOLIDATED STATEMENTS OF INCOME |

[0001144204-16-123444:8k_2_02:39]
|  |  | Three months ended June 30, |  |  | Twelve months ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 24,059 |  |  | $ | 22,961 |  |  | $ | 82,513 |  |  | $ | 77,762 |  |
| Cost of sales |  |  | 14,421 |  |  |  | 13,618 |  |  |  | 54,929 |  |  |  | 51,715 |  |
| Gross Profit |  |  | 9,638 |  |  |  | 9,343 |  |  |  | 27,584 |  |  |  | 26,047 |  |
| Selling, general, and administrative expenses |  |  | 5,882 |  |  |  | 5,881 |  |  |  | 21,261 |  |  |  | 20,766 |  |
| Operating Income |  |  | 3,756 |  |  |  | 3,462 |  |  |  | 6,323 |  |  |  | 5,281 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 40 |  |  |  | 54 |  |  |  | 179 |  |  |  | 215 |  |
| Other, net |  |  | (10 | ) |  |  | 3 |  |  |  | -- |  |  |  | 5 |  |
|  |  |  | 30 |  |  |  | 57 |  |  |  | 179 |  |  |  | 220 |  |
| Income before Provision for Income Taxes |  |  | 3,726 |  |  |  | 3,405 |  |  |  | 6,144 |  |  |  | 5,061 |  |
| Provision for income taxes |  |  | 288 |  |  |  | 65 |  |  |  | 371 |  |  |  | 216 |  |
| Net Income |  | $ | 3,438 |  |  | $ | 3,340 |  |  | $ | 5,773 |  |  | $ | 4,845 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.18 |  |  | $ | 0.18 |  |  | $ | 0.31 |  |  | $ | 0.25 |  |
| Diluted |  | $ | 0.18 |  |  | $ | 0.18 |  |  | $ | 0.31 |  |  | $ | 0.25 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,787,000 |  |  |  | 18,979,000 |  |  |  | 18,874,000 |  |  |  | 19,164,000 |  |
| Diluted |  |  | 18,804,000 |  |  |  | 18,989,000 |  |  |  | 18,894,000 |  |  |  | 19,169,000 |  |

[0001144204-16-123444:8k_2_02:40]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONSOLIDATED STATEMENTS OF CASH FLOWS |
| Years Ended June 30, 2016 and 2015 (In Thousands) |

[0001144204-16-123444:8k_2_02:41]
|  |  | 2016 |  |  | 2015 |  |
| CASH FLOWS FROM OPERATING ACTIVITIES |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,773 |  |  | $ | 4,845 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,420 |  |  |  | 1,570 |  |
| Charge to obsolescence reserve |  |  | (455 | ) |  |  | (472 | ) |
| Provision for doubtful accounts |  |  | (30 | ) |  |  | 66 |  |
| Deferred income taxes |  |  | 375 |  |  |  | 230 |  |
| Non-cash stock based compensation expense |  |  | 103 |  |  |  | 101 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (988 | ) |  |  | (1,156 | ) |
| Inventories |  |  | 1,988 |  |  |  | (1,388 | ) |
| Prepaid expenses and other current assets |  |  | 110 |  |  |  | (57 | ) |
| Income tax receivable |  |  | -- |  |  |  | 121 |  |
| Other assets |  |  | -- |  |  |  | 6 |  |
| Accounts payable, accrued expenses, accrued salaries and wages, accrued income taxes |  |  | 864 |  |  |  | 21 |  |
| Net Cash Provided by Operating Activities |  |  | 9,160 |  |  |  | 3,887 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES |  |  |  |  |  |  |  |  |
| Purchases of property, plant, and equipment |  |  | (693 | ) |  |  | (730 | ) |
| Net Cash Used in Investing Activities |  |  | (693 | ) |  |  | (730 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt |  |  | (5,900 | ) |  |  | (1,600 | ) |
| Proceeds from long-term debt |  |  | -- |  |  |  | 500 |  |
| Cash paid for purchase of treasury stock |  |  | (1,108 | ) |  |  | (2,194 | ) |
| Net Cash Used in Financing Activities |  |  | (7,008 | ) |  |  | (3,294 | ) |
| Net Change in Cash and Cash Equivalents |  |  | 1,459 |  |  |  | (137 | ) |
| CASH AND CASH EQUIVALENTS - Beginning |  |  | 2,346 |  |  |  | 2,483 |  |
| CASH AND CASH EQUIVALENTS - Ending |  | $ | 3,805 |  |  | $ | 2,346 |  |
| SUPPLEMENTAL CASH FLOW INFORMATION |  |  |  |  |  |  |  |  |
| Interest paid, net |  | $ | 184 |  |  | $ | 215 |  |
| Income taxes paid |  | $ | -- |  |  | $ | 29 |  |
| Surrender of Common Shares |  | $ | 54 |  |  | $ | -- |  |

[0001144204-16-123444:8k_2_02:42]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |

[0001144204-16-123444:8k_2_02:43]
|  |  | Three months ended June 30, |  |  | Twelve months ended June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (In thousands) |  |
| Net income |  | $ | 3,438 |  |  | $ | 3,340 |  |  | $ | 5,773 |  |  | $ | 4,845 |  |
| Add back provision for income taxes |  |  | 288 |  |  |  | 65 |  |  |  | 371 |  |  |  | 216 |  |
| Add back interest and other expense |  |  | 30 |  |  |  | 57 |  |  |  | 179 |  |  |  | 220 |  |
| Operating income (GAAP) |  |  | 3,756 |  |  |  | 3,462 |  |  |  | 6,323 |  |  |  | 5,281 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 131 |  |  |  | 166 |  |  |  | 529 |  |  |  | 666 |  |
| Add back stock-based compensation expense |  |  | 11 |  |  |  | -- |  |  |  | 103 |  |  |  | 100 |  |
| Adjusted non-GAAP operating income |  |  | 3,898 |  |  |  | 3,628 |  |  |  | 6,955 |  |  |  | 6,047 |  |
| Add back depreciation and other amortization |  |  | 251 |  |  |  | 260 |  |  |  | 891 |  |  |  | 904 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 4,149 |  |  | $ | 3,888 |  |  | $ | 7,846 |  |  | $ | 6,951 |  |
| Adjusted EBITDA per Diluted Share |  | $ | 0.22 |  |  | $ | 0.20 |  |  | $ | 0.42 |  |  | $ | 0.36 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,804,000 |  |  |  | 18,989,000 |  |  |  | 18,894,000 |  |  |  | 19,169,000 |  |

[0001144204-16-123444:8k_2_02:44]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-16-123444:8k_2_02:45]
Contacts:

[0001144204-16-123444:8k_2_02:46]
Patrick McKillop

[0001144204-16-123444:8k_2_02:47]
Director of Investor Relations

[0001144204-16-123444:8k_2_02:48]
NAPCO Security Technologies, Inc.

[0001144204-16-123444:8k_2_02:49]
OP: 800-645-9445 x 374

[0001144204-16-123444:8k_2_02:50]
CP: 516-404-3597

[0001144204-16-123444:8k_2_02:51]
pmckillop@napcosecurity.com

[0001144204-16-123444:8k_2_02:52]
Three Part Advisors

[0001144204-16-123444:8k_2_02:53]
Jeff Elliott

[0001144204-16-123444:8k_2_02:54]
972-423-7070

[0001144204-16-123444:8k_2_02:55]
jelliott@threepa.com
