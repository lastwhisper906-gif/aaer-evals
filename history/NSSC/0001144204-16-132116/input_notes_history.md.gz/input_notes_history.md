# NSSC note change history — 0001144204-16-100496 → 0001144204-16-132116


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001144204-16-132116:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $7,000 for the three months ended September 30, 2016 and 2015, respectively.
  (was, 2016-05-10, similarity 0.7866):
[0001144204-16-100496:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $7,000 for the three months ended March 31, 2016 and 2015, respectively and $20,000 and $23,000 for the nine months ended March 31, 2016 and 2015, respectively.

- changed (2016-11-07):
[0001144204-16-132116:note_history:2]
As of September 30, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2017 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.
  (was, 2016-05-10, similarity 0.9374):
[0001144204-16-100496:note_history:2]
As of March 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-11-07):
[0001144204-16-132116:note_history:3]
Principles of Consolidation

- changed (2016-11-07):
[0001144204-16-132116:note_history:4]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2016 in the amount of $3,925,000 approximates fair value.
  (was, 2016-05-10, similarity 0.974):
[0001144204-16-100496:note_history:4]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2016 in the amount of $7,500,000 approximates fair value.

- added (2016-11-07):
[0001144204-16-132116:note_history:5]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2016 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2016 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2016-11-07):
[0001144204-16-132116:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $140,000 and $145,000 and for returns and other allowances of $1,186,000 and $1,255,000 as of September 30, 2016 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.
  (was, 2016-05-10, similarity 0.9819):
[0001144204-16-100496:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $135,000 and $175,000 and for returns and other allowances of $975,000 and $1,260,000 as of March 31, 2016 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- changed (2016-11-07):
[0001144204-16-132116:note_history:7]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,453) |  | $ | 2,347 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,453) |  | $ | 8,247 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |
  (was, 2016-05-10, similarity 0.8886):
[0001144204-16-100496:note_history:7]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,212) |  | $ | 2,588 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,552) |  | $ | 8,488 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

- changed (2016-11-07):
[0001144204-16-132116:note_history:8]
Amortization expense for intangible assets subject to amortization was approximately $110,000 and $137,000 for the three months ended September 30, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.9 years and  12.9 years at September 30, 2016 and 2015, respectively.
  (was, 2016-05-10, similarity 0.8124):
[0001144204-16-100496:note_history:8]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended March 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $398,000 and $500,000 for the nine months ended March 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.3 years and  13.3 years at March 31, 2016 and 2015, respectively.

- changed (2016-11-07):
[0001144204-16-132116:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
  (was, 2016-05-10, similarity 0.9249):
[0001144204-16-100496:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.

- changed (2016-11-07):
[0001144204-16-132116:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  9% and 7% for the three months ended September 30, 2016 and 2015, respectively.
  (was, 2016-05-10, similarity 0.8878):
[0001144204-16-100496:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  6% and 8% for the three months ended March 31, 2016 and 2015, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the nine months ended March 31, 2016 and 2015, respectively.

- changed (2016-11-07):
[0001144204-16-132116:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2016 and 2015 was $674,000 and $558,000, respectively.
  (was, 2016-05-10, similarity 0.8317):
[0001144204-16-100496:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2016 and 2015 was $259,000 and $172,000, respectively. Advertising expense for the nine months ended March 31, 2016 and 2015 was $1,328,000 and $1,028,000, respectively.

- changed (2016-11-07):
[0001144204-16-132116:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2016 and 2015 was $1,628,000 and $1,489,000, respectively.
  (was, 2016-05-10, similarity 0.8101):
[0001144204-16-100496:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2016 and 2015 was $1,513,000 and $1,350,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2016 and 2015 was $4,521,000 and $3,995,000, respectively.

- changed (2016-11-07):
[0001144204-16-132116:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):
  (was, 2016-05-10, similarity 0.9709):
[0001144204-16-100496:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

- changed (2016-11-07):
[0001144204-16-132116:note_history:14]
Options to purchase 0 and  170,000 shares of common stock for the three months ended September 30, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2016-05-10, similarity 0.9754):
[0001144204-16-100496:note_history:14]
Options to purchase  165,615 and  262,000 shares of common stock for the three months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2016-11-07):
[0001144204-16-132116:note_history:15]
Stock-based compensation costs of $33,000 and $32,000 was recognized for the three months ended September 30, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended September 30, 2016 and 2015.

- changed (2016-11-07):
[0001144204-16-132116:note_history:16]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2016 and 2015.
  (was, 2016-05-10, similarity 0.9426):
[0001144204-16-100496:note_history:16]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2016 and 2015.

- added (2016-11-07):
[0001144204-16-132116:note_history:17]
For the three months ended September 30, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2016-11-07):
[0001144204-16-132116:note_history:18]
The Company records the amount billed to customers for shipping and handling in net sales ($139,000 and $131,000 in the three months ended September 30, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($216,000 in each of the three months ended September 30, 2016 and 2015).
  (was, 2016-05-10, similarity 0.6364):
[0001144204-16-100496:note_history:18]
The Company records the amount billed to customers for shipping and handling in net sales ($109,000 and $117,000 in the three months ended March 31, 2016 and 2015, respectively and $365,000 and $374,000 in the nine months ended March 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($232,000 and $211,000 in the three months ended March 31, 2016 and 2015, respectively and $673,000 and $692,000 in the nine months ended March 31, 2016 and 2015, respectively).

- changed (2016-11-07):
[0001144204-16-132116:note_history:19]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We have evaluated the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.
  (was, 2016-05-10, similarity 0.8904):
[0001144204-16-100496:note_history:19]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s quarter ended September 30, 2016. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

- removed (2016-11-07):
[0001144204-16-100496:note_history:20]
NOTE 1 - Nature of Business and Summary of Significant Accounting Policies

- removed (2016-11-07):
[0001144204-16-100496:note_history:21]
Basis of Presentation

- removed (2016-11-07):
[0001144204-16-100496:note_history:22]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2016 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2016 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

- removed (2016-11-07):
[0001144204-16-100496:note_history:23]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

- removed (2016-11-07):
[0001144204-16-100496:note_history:24]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,903 |  |  | 19,225 |  | $ | 0.12 |  | $ | 0.08 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 20 |  |  | 4 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,923 |  |  | 19,229 |  | $ | 0.12 |  | $ | 0.08 |  |

- removed (2016-11-07):
[0001144204-16-100496:note_history:25]
Options to purchase  147,038 and  258,583 shares of common stock for the nine months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- removed (2016-11-07):
[0001144204-16-100496:note_history:26]
No stock-based compensation costs were recognized for three months ended March 31, 2016 or 2015. Stock-based compensation costs of $92,000 and $101,000 were recognized for nine months ended March 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2016 and 2015.

- removed (2016-11-07):
[0001144204-16-100496:note_history:27]
For the three and nine months ended March 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-11-07):
[0001144204-16-132116:note_history:28]
As of September 30, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 and one loan for $6,000,000 which expires in June 2019 (the “Term Loan”). The Revolving Credit Facility had an expiration date of June 2017 which was extended to June 2021 at the end of fiscal 2016. Repayment of the Term Loan commenced on September 30, 2012. The Term Loan is being repaid with 28 equal, quarterly payments of $75,000 plus any additional payments made at the Company’s discretion with the remaining balance of $1,100,000 due on or before the expiration date.

- changed (2016-11-07):
[0001144204-16-132116:note_history:29]
Outstanding balances and interest rates as of September 30, 2016 and June 30, 2016 are as follows:
  (was, 2016-05-10, similarity 0.9419):
[0001144204-16-100496:note_history:29]
Outstanding balances and interest rates as of March 31, 2016 and June 30, 2015 are as follows:

- changed (2016-11-07):
[0001144204-16-132116:note_history:30]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loans |  |  | 1,925 |  |  | 1.7 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,925 |  |  | 1.7 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2016-05-10, similarity 0.9792):
[0001144204-16-100496:note_history:30]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,500 |  |  | 1.9 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,500 |  |  | 1.9 | % | $ | 10,700 |  |  | 1.7 | % |

- removed (2016-11-07):
[0001144204-16-100496:note_history:31]
As of March 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001144204-16-132116:note_history:32]
Outstanding balances and interest rates as of September 30, 2016 and June 30, 2016 are as follows:
  (was, 2016-05-10, similarity 0.9419):
[0001144204-16-100496:note_history:32]
Outstanding balances and interest rates as of March 31, 2016 and June 30, 2015 are as follows:

- changed (2016-11-07):
[0001144204-16-132116:note_history:33]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loans |  |  | 1,925 |  |  | 1.7 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,925 |  |  | 1.7 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2016-05-10, similarity 0.9792):
[0001144204-16-100496:note_history:33]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,500 |  |  | 1.9 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,500 |  |  | 1.9 | % | $ | 10,700 |  |  | 1.7 | % |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-11-07):
[0001144204-16-132116:note_history:34]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
  (was, 2016-05-10, similarity 0.9249):
[0001144204-16-100496:note_history:34]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.
