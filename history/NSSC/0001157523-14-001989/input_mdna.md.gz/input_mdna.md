# NSSC MD&A — 0001157523-14-001989


## mdna

[0001157523-14-001989:mdna:1]
[same as prior period, unchanged from 0001157523-14-000527:mdna:1]

[0001157523-14-001989:mdna:2]
[same as prior period, unchanged from 0001157523-14-000527:mdna:2]

[0001157523-14-001989:mdna:3]
[same as prior period, unchanged from 0001157523-14-000527:mdna:3]

[0001157523-14-001989:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 5% and 6% of our revenues for both of the nine month periods ended March 31, 2014 and 2013, respectively.

[0001157523-14-001989:mdna:5]
[same as prior period, unchanged from 0001157523-14-000527:mdna:5]

[0001157523-14-001989:mdna:6]
[same as prior period, unchanged from 0001157523-14-000527:mdna:6]

[0001157523-14-001989:mdna:7]
[same as prior period, unchanged from 0001157523-14-000527:mdna:7]

[0001157523-14-001989:mdna:8]
[same as prior period, unchanged from 0001157523-14-000527:mdna:8]

[0001157523-14-001989:mdna:9]
[same as prior period, unchanged from 0001157523-14-000527:mdna:9]

[0001157523-14-001989:mdna:10]
[same as prior period, unchanged from 0001157523-14-000527:mdna:10]

[0001157523-14-001989:mdna:11]
[same as prior period, unchanged from 0001157523-14-000527:mdna:11]

[0001157523-14-001989:mdna:12]
[same as prior period, unchanged from 0001157523-14-000527:mdna:12]

[0001157523-14-001989:mdna:13]
[same as prior period, unchanged from 0001157523-14-000527:mdna:13]

[0001157523-14-001989:mdna:14]
[same as prior period, unchanged from 0001157523-14-000527:mdna:14]

[0001157523-14-001989:mdna:15]
[same as prior period, unchanged from 0001157523-14-000527:mdna:15]

[0001157523-14-001989:mdna:16]
[same as prior period, unchanged from 0001157523-14-000527:mdna:16]

[0001157523-14-001989:mdna:17]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with accounts receivable balance that comprised 12% of the Company’s accounts receivable at March 31, 2014 and two customers that aggregated 22% at June 30, 2013. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.

[0001157523-14-001989:mdna:18]
In the ordinary course of business, we have established a reserve for doubtful accounts and customer deductions in the amount of $180,000 and $220,000 as of March 31, 2014 and June 30, 2013, respectively. Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical or anticipated events.

[0001157523-14-001989:mdna:19]
[same as prior period, unchanged from 0001157523-14-000527:mdna:19]

[0001157523-14-001989:mdna:20]
[same as prior period, unchanged from 0001157523-14-000527:mdna:20]

[0001157523-14-001989:mdna:21]
[same as prior period, unchanged from 0001157523-14-000527:mdna:21]

[0001157523-14-001989:mdna:22]
[same as prior period, unchanged from 0001157523-14-000527:mdna:22]

[0001157523-14-001989:mdna:23]
[same as prior period, unchanged from 0001157523-14-000527:mdna:23]

[0001157523-14-001989:mdna:24]
[same as prior period, unchanged from 0001157523-14-000527:mdna:24]

[0001157523-14-001989:mdna:25]
[same as prior period, unchanged from 0001157523-14-000527:mdna:25]

[0001157523-14-001989:mdna:26]
[same as prior period, unchanged from 0001157523-14-000527:mdna:26]

[0001157523-14-001989:mdna:27]
|  |  | Three months ended March 31, (dollars in thousands) |  |  | Nine months ended March 31, 2013 (dollars in thousands) |  |
|  |  | 2014 |  |  | 2013 |  |  | % Increase/ (decrease) |  |  | 2014 |  |  | 2013 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 17,272 |  |  | $ | 17,163 |  |  |  | 0.6 | % |  | $ | 52,864 |  |  | $ | 49,591 |  |  |  | 6.6 | % |
| Gross profit |  |  | 5,317 |  |  |  | 4,652 |  |  |  | 14.3 | % |  |  | 15,437 |  |  |  | 13,429 |  |  |  | 15.0 | % |
| Gross profit as a % of net sales |  |  | 30.8 | % |  |  | 27.1 | % |  |  | 13.7 | % |  |  | 29.2 | % |  |  | 27.1 | % |  |  | 7.7 | % |
| Selling, general and administrative |  |  | 4,568 |  |  |  | 4,413 |  |  |  | 3.5 | % |  |  | 13,944 |  |  |  | 13,269 |  |  |  | 5.1 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 26.4 | % |  |  | 25.7 | % |  |  | 2.7 | % |  |  | 26.4 | % |  |  | 26.8 | % |  |  | (1.5 | )% |
| Operating income |  |  | 749 |  |  |  | 239 |  |  |  | 213.4 | % |  |  | 1,493 |  |  |  | 160 |  |  |  | 833.1 | % |
| Interest expense, net |  |  | 59 |  |  |  | 103 |  |  |  | (42.7 | )% |  |  | 239 |  |  |  | 387 |  |  |  | (38.2 | )% |
| Other expense |  |  | 4 |  |  |  | 3 |  |  |  | 33.3 | % |  |  | 10 |  |  |  | 10 |  |  |  | -- | % |
| Provision (benefit) for income taxes |  |  | 36 |  |  |  | 22 |  |  |  | 63.6 | % |  |  | 103 |  |  |  | (49 | ) |  |  | 310.2 | % |
| Net income (loss) |  |  | 650 |  |  |  | 111 |  |  |  | 485.6 | % |  |  | 1,141 |  |  |  | (188 | ) |  |  | 706.9 | % |

[0001157523-14-001989:mdna:28]
Sales for the three months ended March 31, 2014 increased by $109,000 to $17,272,000 as compared to $17,163,000 for the same period a year ago. Sales for the nine months ended March 31, 2014 increased by $3,273,000 to $52,864,000 as compared to $49,591,000 for the same period a year ago. The increase in sales for the three months ended March 31, 2014 was due primarily to increased sales in the Company’s access control products ($519,000) and door-locking products ($275,000) as partially offset by a decrease in intrusion products ($685,000). The increase in sales for the nine months ended March 31, 2014 was due primarily to increased sales in the Company’s door-locking products ($2,799,000) and access control ($1,425,000) products as partially offset by a decrease in intrusion products ($951,000). The increase in sales of door-locking products for the three and nine months was due primarily to general increased demand for the Company’s door-locking products. The increase in sales of access control products for the three and nine months was due primarily to general increased demand. In addition, the increase in the nine months was also due to a large order of $1,734,000 received from a major university in the quarter ended June 30, 2013. The Company shipped $1,127,000 of this order in the quarter ended June 30, 2013 and completed delivery of the remaining $607,000 during the first three months of fiscal 2014. Intrusion sales were impacted by several severe winter storms in the northeast and central states with most of the disruption occurring in the residential market.

[0001157523-14-001989:mdna:29]
Gross profit for the three months ended March 31, 2014 increased to $5,317,000 or 30.8% of sales as compared to $4,652,000 or 27.1% of sales for the same period a year ago. Gross profit for the nine months ended March 31, 2014 increased to $15,437,000 or 29.2% of sales as compared to $13,429,000 or 27.1% of sales for the same period a year ago. The increase in gross profit for the three and nine months was primarily due to the aforementioned increase in net sales and a positive shift in product mix to the Company’s door-locking and access control products.

[0001157523-14-001989:mdna:30]
Selling, general and administrative expenses for the three months ended March 31, 2014 increased by $155,000 to $4,568,000 from 4,413,000 for the same period a year ago.  Selling, general and administrative expenses for the nine months ended March 31, 2014 increased by $675,000 to $13,944,000 from $13,269,000 for the same period a year ago.  Selling, general and administrative expenses as a percentage of net sales increased to 26.4% for the three months ended March 31, 2014 from 25.7% for the same period a year ago. Selling, general and administrative expenses as a percentage of net sales decreased to 26.4% for the nine months ended March 31, 2014 from 26.8% for the same period a year ago. The increase in dollars for the three and nine months was due primarily from the addition of selling personnel.

[0001157523-14-001989:mdna:31]
Interest expense, net for the three months ended March 31, 2014 decreased by $44,000 to $59,000 as compared to $103,000 for the same period a year ago. Interest expense, net for the nine months ended March 31, 2014 decreased by $148,000 to $239,000 as compared to $387,000 for the same period a year ago. The decreases in interest expense for the three and nine months ended March 31, 2014 resulted from lower average outstanding debt and lower interest rates during those periods as compared to the same periods a year ago.

[0001157523-14-001989:mdna:32]
The Company’s provision for income taxes for the three months ended March 31, 2014 increased by $14,000 to $36,000 as compared to $22,000 for the same period a year ago. The Company’s provision for income taxes for the nine months ended March 31, 2014 increased by $152,000 to a provision of $103,000 as compared to a benefit of $49,000 for the same period a year ago. The changes in the provision for income taxes were caused primarily by the increase in income before income taxes as well as a change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations for the three and nine months ended March 31, 2014 as compared to the same periods a year ago. As a result, the Company’s effective rate for income tax was 5% and 17% for the three months ended March 31, 2014 and 2013, respectively and 8% and 21% for the nine months ended March 31, 2014 and 2013, respectively.

[0001157523-14-001989:mdna:33]
Net income increased by $539,000 to $650,000 or $0.03 per diluted share for the three months ended March 31, 2014 as compared to $111,000 or $0.01 per diluted share for the same period a year ago. Net income increased by $1,329,000 to $1,141,000 or $0.06 per diluted share for the nine months ended March 31, 2014 as compared to a loss of $(188,000) or $(0.01) per diluted share for the same period a year ago. The changes for the three and nine months ended March 31, 2014 were primarily due to the items as described above.

[0001157523-14-001989:mdna:34]
[same as prior period, unchanged from 0001157523-14-000527:mdna:34]

[0001157523-14-001989:mdna:35]
During the nine months ended March 31, 2014 the Company utilized its cash from operations ($4,268,000) and a portion of its cash on-hand as of June 30, 2013 ($829,000 of $3,229,000) to repay outstanding debt ($4,200,000), purchase treasury stock ($285,000) and purchase property, plant and equipment ($612,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-14-001989:mdna:36]
22

[0001157523-14-001989:mdna:37]
Accounts Receivable at March 31, 2014 decreased $3,998,000 to $14,213,000 as compared to $18,211,000 at June 30, 2013.  This decrease is primarily the result of the lower sales volume during the quarter ended March 31, 2014 as compared to the quarter ended June 30, 2013, which is typically the Company’s highest.

[0001157523-14-001989:mdna:38]
Inventories at March 31, 2014 increased $2,365,000 to $24,272,000 as compared to $21,907,000 at June 30, 2013. This increase is primarily the result of the Company keeping additional inventory of recently introduced products, level-loading its production facility in the Dominican Republic as well as the higher sales levels in the quarter ended June 30, 2013 as compared to the quarter ended March 31, 2014.

[0001157523-14-001989:mdna:39]
Accounts payable and accrued expenses increased $229,000 to $7,244,000 as of March 31, 2014 as compared to $7,015,000 at June 30, 2013. The increase was due primarily more purchases of component parts in the month of March 2014 as compared to the month of June 2013.

[0001157523-14-001989:mdna:40]
As of March 31, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. As of March 31, 2014, the Company had $2,500,000 in outstanding borrowings and $8,500,000 in availability under the Revolving Credit Facility. In January 2014 the Company and its lender amended the Revolving Credit Facility and Term Loans to allow for a lower LIBOR-based interest rate option of 1.5% as compared to 2.0% provided for previously. All other terms and conditions remain the same. The Company’s long-term debt is described more fully in Note 6 to the condensed consolidated financial statements.

[0001157523-14-001989:mdna:41]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-14-001989:mdna:42]
As of March 31, 2014 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
