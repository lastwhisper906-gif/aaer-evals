# NSSC notes — 0001157523-14-001989


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-14-001989:notes:1]
[same as prior period, unchanged from 0001157523-14-000527:notes:1]

[0001157523-14-001989:notes:2]
|  |  | March 31, 2014 |  |  | June 30, 2013 |  |  | Useful Life in Years |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |  |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,873 |  |  |  | 6,794 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,416 |  |  |  | 2,328 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,877 |  |  |  | 19,431 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 39,353 |  |  |  | 38,740 |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 32,836 |  |  |  | 32,154 |  |  |  |  |
|  |  | $ | 6,517 |  |  | $ | 6,586 |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-14-001989:notes:3]
[same as prior period, unchanged from 0001157523-14-000527:notes:3]

[0001157523-14-001989:notes:4]
Depreciation
 and amortization expense on property, plant, and equipment was
 $242,000 and $262,000 for the three months ended March 31, 2014 and
 2013, respectively and $682,000 and $769,000 for the nine months
 ended March 31, 2014 and 2013, respectively.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001157523-14-001989:notes:5]
[same as prior period, unchanged from 0001157523-14-000527:notes:5]

[0001157523-14-001989:notes:6]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($131,000 and $118,000 in the three months
 ended March 31, 2014 and 2013, respectively and $383,000 and
 $367,000 in the nine months ended March 31, 2014 and 2013,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($241,000 and $266,000 in the three
 months ended March 31, 2014 and 2013, respectively and $704,000 and
 $748,000 in the nine months ended March 31, 2014 and 2013,
 respectively).


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-14-001989:notes:7]
[same as prior period, unchanged from 0001157523-14-000527:notes:7]

[0001157523-14-001989:notes:8]
[same as prior period, unchanged from 0001157523-14-000527:notes:8]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001157523-14-001989:notes:9]
[same as prior period, unchanged from 0001157523-14-000527:notes:9]

[0001157523-14-001989:notes:10]
[same as prior period, unchanged from 0001157523-14-000527:notes:10]


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001157523-14-001989:notes:11]
[same as prior period, unchanged from 0001157523-14-000527:notes:11]

[0001157523-14-001989:notes:12]
For
 the nine months ended March 31, 2014 and 2013 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.


## us-gaap:IncomeTaxPolicyTextBlock

[0001157523-14-001989:notes:13]
[same as prior period, unchanged from 0001157523-14-000527:notes:13]

[0001157523-14-001989:notes:14]
[same as prior period, unchanged from 0001157523-14-000527:notes:14]


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-14-001989:notes:15]
[same as prior period, unchanged from 0001157523-14-000527:notes:15]

[0001157523-14-001989:notes:16]
The
 Company had one customer with accounts receivable balance that
 comprised 12% of the Company’s accounts receivable at March
 31, 2014 and two customers that aggregated 22% at June 30, 2013.
 Sales to any one customer did not exceed 10% of net sales in any of
 the past two fiscal years.


## us-gaap:ReceivablesPolicyTextBlock

[0001157523-14-001989:notes:17]
[same as prior period, unchanged from 0001157523-14-000527:notes:17]

[0001157523-14-001989:notes:18]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $180,000 and $220,000 and for returns and other allowances of
 $865,000 and $1,055,000 as of March 31, 2014 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-14-001989:notes:19]
[same as prior period, unchanged from 0001157523-14-000527:notes:19]

[0001157523-14-001989:notes:20]
Inventories,
 net of reserves are valued at lower of cost (first-in, first-out
 method) or market. The Company regularly reviews parts and finished
 goods inventories on hand and, when necessary, records a provision
 for excess or obsolete inventories. The balance in these reserves
 was $3,642,000 and $3,392,000 as of March 31, 2014 and June 30,
 2013, respectively. The Company also regularly reviews the period
 over which its inventories will be converted to sales. Any
 inventories expected to convert to sales beyond 12 months from
 the balance sheet date are classified as non-current.

[0001157523-14-001989:notes:21]
[same as prior period, unchanged from 0001157523-14-000527:notes:21]

[0001157523-14-001989:notes:22]
|  |  | March 31, 2014 |  |  | June 30, 2013 |  |
| Component parts |  | $ | 14,528 |  |  | $ | 13,112 |  |
| Work-in-process |  |  | 3,462 |  |  |  | 3,125 |  |
| Finished product |  |  | 6,282 |  |  |  | 5,670 |  |
|  |  | $ | 24,272 |  |  | $ | 21,907 |  |
| Classification of inventories, net of reserves: |  |
| Current |  | $ | 21,474 |  |  | $ | 18,471 |  |
| Non-current |  |  | 2,798 |  |  |  | 3,436 |  |
|  |  | $ | 24,272 |  |  | $ | 21,907 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001157523-14-001989:notes:23]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended March
 31 (in thousands, except per share data):

[0001157523-14-001989:notes:24]
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Basic EPS |  | $ | 650 |  |  | $ | 111 |  |  |  | 19,416 |  |  |  | 19,296 |  |  | $ | 0.03 |  |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 55 |  |  |  | 123 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 650 |  |  | $ | 111 |  |  |  | 19,471 |  |  |  | 19,419 |  |  | $ | 0.03 |  |  | $ | 0.01 |  |

[0001157523-14-001989:notes:25]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the nine months ended March
 31 (in thousands, except per share data):

[0001157523-14-001989:notes:26]
|  |  | Net Income (Loss) |  |  | Weighted Average Shares |  |  | Net Income (Loss) per Share |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Basic EPS |  | $ | 1,141 |  |  | $ | (188 | ) |  |  | 19,382 |  |  |  | 19,181 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 37 |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 1,141 |  |  | $ | (188 | ) |  |  | 19,419 |  |  |  | 19,181 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |


## us-gaap:LongTermDebtTextBlock

[0001157523-14-001989:notes:27]
NOTE 6 - Long-Term Debt

[0001157523-14-001989:notes:28]
As
 of March 31, 2014, long-term debt consisted of a revolving credit
 facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000. In January 2014
 the Company and its lender amended the Revolving Credit Facility
 and Term Loans to allow for a lower LIBOR-based interest rate
 option of 1.5% as compared to 2.0% provided for previously. All
 other terms and conditions remain the same.

[0001157523-14-001989:notes:29]
Outstanding
 balances and interest rates as of March 31, 2014 and June 30, 2013
 are as follows:

[0001157523-14-001989:notes:30]
|  | March 31, 2014 |  | June 30, 2013 |
|  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit | $ 2,500 |  | 1.7% |  | $ 5,500 |  | 2.5% |
| Term loans | 9,700 |  | 1.7% |  | 10,900 |  | 2.5% |
| Total debt | $ 12,200 |  | 1.7% |  | $ 16,400 |  | 2.5% |

[0001157523-14-001989:notes:31]
The
 Revolving Credit Facility and Term Loans (collectively the
 “Agreement”) also provide for a LIBOR-based interest
 rate option of LIBOR plus 1.5% to 2.75%, depending on the ratio of
 outstanding debt to EBITDA, which is to be measured and adjusted
 quarterly, a prime rate-based option of the prime rate plus 0.25%
 and other terms and conditions as more fully described in the
 Agreement. In addition, the Agreement provides for availability
 under the Revolving Credit Facility to be limited to the lesser of
 $11,000,000 or the result of a borrowing base formula based upon
 the Company’s Accounts Receivables and Inventory values net
 of certain deductions. The Company’s obligations under the
 Agreement continue to be secured by all of its assets, including
 but not limited to, deposit accounts, accounts receivable,
 inventory, the Company’s corporate headquarters in
 Amityville, NY, equipment and fixtures and intangible assets. In
 addition, the Company’s wholly-owned subsidiaries, with the
 exception of the Company’s foreign subsidiaries, have issued
 guarantees and pledges of all of their assets to secure the
 Company’s obligations under the Agreement. All of the
 outstanding common stock of the Company’s domestic
 subsidiaries and 65% of the common stock of the Company’s
 foreign subsidiaries has been pledged to secure the Company’s
 obligations under the Agreement.

[0001157523-14-001989:notes:32]
The
 Agreement contains various restrictions and covenants including,
 among others, restrictions on payment of dividends, restrictions on
 borrowings and compliance with certain financial ratios, as defined
 in the Agreement.


## us-gaap:InventoryPolicyTextBlock

[0001157523-14-001989:notes:33]
[same as prior period, unchanged from 0001157523-14-000527:notes:33]

[0001157523-14-001989:notes:34]
[same as prior period, unchanged from 0001157523-14-000527:notes:34]

[0001157523-14-001989:notes:35]
[same as prior period, unchanged from 0001157523-14-000527:notes:35]

[0001157523-14-001989:notes:36]
[same as prior period, unchanged from 0001157523-14-000527:notes:36]


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-14-001989:notes:37]
[same as prior period, unchanged from 0001157523-14-000527:notes:37]

[0001157523-14-001989:notes:38]
[same as prior period, unchanged from 0001157523-14-000527:notes:38]

[0001157523-14-001989:notes:39]
[same as prior period, unchanged from 0001157523-14-000527:notes:39]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-14-001989:notes:40]
[same as prior period, unchanged from 0001157523-14-000527:notes:40]

[0001157523-14-001989:notes:41]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at March 31, 2014 and June 30, 2013.  The
 Company considers all highly liquid investments with original
 maturities of three months or less to be cash
 equivalents.  The Company has cash balances in banks in
 excess of the maximum amount insured by the FDIC and other
 international agencies as of March 31, 2014 and June 30, 2013. The
 Company has historically not experienced any credit losses with
 balances in excess of FDIC limits


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-14-001989:notes:42]
[same as prior period, unchanged from 0001157523-14-000527:notes:42]

[0001157523-14-001989:notes:43]
[same as prior period, unchanged from 0001157523-14-000527:notes:43]

[0001157523-14-001989:notes:44]
[same as prior period, unchanged from 0001157523-14-000527:notes:44]

[0001157523-14-001989:notes:45]
[same as prior period, unchanged from 0001157523-14-000527:notes:45]

[0001157523-14-001989:notes:46]
[same as prior period, unchanged from 0001157523-14-000527:notes:46]

[0001157523-14-001989:notes:47]
[same as prior period, unchanged from 0001157523-14-000527:notes:47]

[0001157523-14-001989:notes:48]
The
 unaudited condensed consolidated financial statements of Napco
 Security Technologies, Inc and Subsidiaries (the
 “Company”), including these notes, have been prepared
 by the Company in accordance with U.S. generally accepted
 accounting principles (“GAAP”) for interim financial
 information and pursuant to the rules and regulations promulgated
 by the U.S. Securities and Exchange Commission (the
 “SEC”). Accordingly, certain information and
 disclosures normally included in financial statements prepared in
 accordance with GAAP have been omitted or condensed. However, in
 the opinion of management, all adjustments (consisting of normal
 recurring accruals) considered necessary for a fair presentation
 have been included. These unaudited condensed consolidated
 financial statements should be read in conjunction with the
 Company’s audited consolidated financial statements for the
 year ended June 30, 2013 and the notes thereto included in the
 Company’s Annual Report on Form 10-K filed with the SEC on
 September 17, 2013. Results of consolidated operations for the
 interim periods are not necessarily indicative of a full
 year’s operating results. The unaudited condensed
 consolidated financial statements herein include the accounts of
 the Company and its wholly owned subsidiaries. All material
 inter-company accounts and transactions have been eliminated.
 Certain
 prior period amounts relating to credit card fees have been
 reclassified for consistency with the current period presentation.
 The reclassification did not have an impact on the Balance Sheets,
 Statement of Cash Flows or reported Net income (loss) for any
 period.

[0001157523-14-001989:notes:49]
[same as prior period, unchanged from 0001157523-14-000527:notes:49]

[0001157523-14-001989:notes:50]
[same as prior period, unchanged from 0001157523-14-000527:notes:50]

[0001157523-14-001989:notes:51]
[same as prior period, unchanged from 0001157523-14-000527:notes:51]

[0001157523-14-001989:notes:52]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 March 31, 2014 due to their short-term maturities; Long-Term Debt:
 The carrying amount of the Company’s long-term debt,
 including the current portion, at March 31, 2014 in the amount of
 $12,200,000 approximates fair value.

[0001157523-14-001989:notes:53]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at March 31, 2014 and June 30, 2013.  The
 Company considers all highly liquid investments with original
 maturities of three months or less to be cash
 equivalents.  The Company has cash balances in banks in
 excess of the maximum amount insured by the FDIC and other
 international agencies as of March 31, 2014 and June 30, 2013. The
 Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

[0001157523-14-001989:notes:54]
[same as prior period, unchanged from 0001157523-14-000527:notes:54]

[0001157523-14-001989:notes:55]
[same as prior period, unchanged from 0001157523-14-000527:notes:55]

[0001157523-14-001989:notes:56]
[same as prior period, unchanged from 0001157523-14-000527:notes:56]

[0001157523-14-001989:notes:57]
[same as prior period, unchanged from 0001157523-14-000527:notes:57]

[0001157523-14-001989:notes:58]
|  |  | March 31, 2014 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (6,019 | ) |  | $ | 3,781 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (273 | ) |  |  | 67 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,292 | ) |  | $ | 9,748 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |

[0001157523-14-001989:notes:59]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 March 31, 2014 and 2013, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $586,000 and $688,000 for the nine months ended March 31, 2014 and
 2013, respectively. Amortization expense for each of the next five
 fiscal years is estimated to be as follows: 2014 - $781,000; 2015 -
 $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 - $371,000. The
 weighted average amortization period for intangible assets was 14.1
 years and 15.1 years at March 31, 2014 and 2013,
 respectively.

[0001157523-14-001989:notes:60]
[same as prior period, unchanged from 0001157523-14-000527:notes:60]

[0001157523-14-001989:notes:61]
[same as prior period, unchanged from 0001157523-14-000527:notes:61]

[0001157523-14-001989:notes:62]
[same as prior period, unchanged from 0001157523-14-000527:notes:62]

[0001157523-14-001989:notes:63]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended March 31, 2014 and 2013 was
 $189,000 and $124,000, respectively. Advertising expense for the
 nine months ended March 31, 2014 and 2013 was $801,000 and
 $847,000, respectively.

[0001157523-14-001989:notes:64]
[same as prior period, unchanged from 0001157523-14-000527:notes:64]

[0001157523-14-001989:notes:65]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended March 31, 2014 and 2013 was
 $1,275,000 and $1,187,000, respectively. Company-sponsored research
 and development expense for the nine months ended March 31, 2014
 and 2013 was $3,813,000 and $3,842,000, respectively.

[0001157523-14-001989:notes:66]
[same as prior period, unchanged from 0001157523-14-000527:notes:66]

[0001157523-14-001989:notes:67]
[same as prior period, unchanged from 0001157523-14-000527:notes:67]

[0001157523-14-001989:notes:68]
Options
 to purchase 37,500 and 395,750 shares of common stock for the three
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

[0001157523-14-001989:notes:69]
Options
 to purchase 145,673 and 672,740 shares of common stock for the nine
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

[0001157523-14-001989:notes:70]
[same as prior period, unchanged from 0001157523-14-000527:notes:70]

[0001157523-14-001989:notes:71]
[same as prior period, unchanged from 0001157523-14-000527:notes:71]

[0001157523-14-001989:notes:72]
[same as prior period, unchanged from 0001157523-14-000527:notes:72]

[0001157523-14-001989:notes:73]
Stock-based
 compensation costs of $10,000 and $0 were recognized for the three
 months ended March 31, 2014 and 2013, respectively and $17,000 and
 $0 for the nine months ended March 31, 2014 and 2013,
 respectively.

[0001157523-14-001989:notes:74]
[same as prior period, unchanged from 0001157523-14-000527:notes:74]

[0001157523-14-001989:notes:75]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the nine months ended March 31, 2014 and 2013.

[0001157523-14-001989:notes:76]
[same as prior period, unchanged from 0001157523-14-000527:notes:76]

[0001157523-14-001989:notes:77]
[same as prior period, unchanged from 0001157523-14-000527:notes:77]

[0001157523-14-001989:notes:78]
Recently
 Issued Accounting Standards

[0001157523-14-001989:notes:79]
In
 July 2013, the FASB issued authoritative guidance that
 requires an entity to present an unrecognized tax benefit, or a
 portion of an unrecognized tax benefit, in the financial statements
 as a reduction to a deferred tax asset for a net operating loss
 (“NOL”) carry-forward, a similar tax loss, or a tax
 credit carry-forward.  If either (i) an NOL
 carry-forward, a similar tax loss, or tax credit carry-forward is
 not available as of the reporting date under the governing tax law
 to settle taxes that would result from the disallowance of the tax
 position or (ii) the entity does not intend to use the
 deferred tax asset for this purpose (provided that the tax law
 permits a choice), an entity should present an unrecognized tax
 benefit in the financial statements as a liability and should not
 net the unrecognized tax benefit with a deferred tax asset. 
 This guidance becomes effective prospectively for unrecognized tax
 benefits that exist as of the Company’s fiscal 2015 first
 quarter, with retrospective application and early adoption
 permitted.  The Company is currently evaluating the timing of
 adoption and the impact of this balance sheet presentation guidance
 but does not expect it to have a significant impact on the
 Company’s consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-14-001989:notes:80]
[same as prior period, unchanged from 0001157523-14-000527:notes:80]

[0001157523-14-001989:notes:81]
The
 Company maintains a 401(k) plan (“the Plan”) that
 covers all U.S. non-union employees with one or more years of
 service and is qualified under Sections 401(a) and 401(k) of the
 Internal Revenue Code. Company contributions to this plan are
 discretionary and totaled $26,000 and $27,000 for the three months
 ended March 31, 2014 and 2013, respectively and $77,000 and $73,000
 for the nine months ended March 31, 2014 and 2013,
 respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001157523-14-001989:notes:82]
[same as prior period, unchanged from 0001157523-14-000527:notes:82]

[0001157523-14-001989:notes:83]
During
 the nine months ended March 31, 2014, certain employees exercised
 incentive stock options under the Company’s 2002 Plan
 totaling 337,600 shares. 324,100 of these exercises were completed
 as cashless exercises as allowed for under the 2002 Plan, where the
 exercise shares are issued by the Company in exchange for shares of
 the Company’s common stock that are owned by the optionees.
 The number of shares surrendered by the optionees are based upon
 the per share price on the effective date of the option exercise.
 In addition, the Company repurchased 50,000 shares of its Common
 Stock from its Chief Executive Officer (“CEO”). The
 purchase price was $5.70 per share, the previous business
 day’s closing price on NASDAQ, for an aggregate purchase
 price of $285,000. The repurchase was to fund the CEO’s tax
 liability associated with the exercise of 135,000 options granted
 to him under the 2002 Plan. The repurchase was approved by the
 Board of Directors of the Company, including all of the independent
 directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-14-001989:notes:84]
[same as prior period, unchanged from 0001157523-14-000527:notes:84]

[0001157523-14-001989:notes:85]
The
 provision for income taxes represents Federal, foreign, and state
 and local income taxes. The effective rate differs from statutory
 rates due to the effect of state and local income taxes, tax rates
 in foreign jurisdictions, tax benefit of R&D credits and
 certain nondeductible expenses. Our effective tax rate will change
 from quarter to quarter based on recurring and non-recurring
 factors including, but not limited to, the geographical mix of
 earnings, enacted tax legislation, and state and local income
 taxes. In addition, changes in judgment from the evaluation of new
 information resulting in the recognition, de-recognition or
 re-measurement of a tax position taken in a prior annual period is
 recognized separately in the quarter of the change.

[0001157523-14-001989:notes:86]
The
 Company does not expect that our unrecognized tax benefits will
 significantly change within the next twelve months. We file a
 consolidated U.S. income tax return and tax returns in certain
 state and local and foreign jurisdictions. As of March 31, 2014 we
 remain subject to examination in all tax jurisdictions for all
 relevant jurisdictional statutes for fiscal years 2008 and
 thereafter.

[0001157523-14-001989:notes:87]
The
 Company has identified its U.S. Federal income tax return and its
 State return in New York as its major tax jurisdictions. During the
 nine months ended March 31, 2014 the Company increased its reserve
 for uncertain income tax positions by $16,000. As a result, as of
 March 31, 2014 and June 30, 2013 the Company has a long-term
 accrued income tax liability of $169,000 and $153,000,
 respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-14-001989:notes:88]
[same as prior period, unchanged from 0001157523-14-000527:notes:88]

[0001157523-14-001989:notes:89]
[same as prior period, unchanged from 0001157523-14-000527:notes:89]

[0001157523-14-001989:notes:90]
Under
 the 2012 Employee Plan, stock options may be granted to valued
 employees with a term of up to 10 years at an exercise price equal
 to or greater than the fair market value on the date of grant and
 are exercisable, in whole or in part, at 20% per year beginning on
 the date of grant. An option granted under this plan shall vest in
 full upon a “change in control” as defined in the plan.
 At March 31, 2014, 78,500 stock options were granted, 15,700 stock
 options were exercisable and 871,500 stock options were available
 for grant under this plan.

[0001157523-14-001989:notes:91]
[same as prior period, unchanged from 0001157523-14-000527:notes:91]

[0001157523-14-001989:notes:92]
Risk-free
 interest
 rates                                   2.7%

[0001157523-14-001989:notes:93]
Expected
 lives                                          10
 years

[0001157523-14-001989:notes:94]
Expected
 volatility                                          57%

[0001157523-14-001989:notes:95]
Expected
 dividend
 yields                                  0%

[0001157523-14-001989:notes:96]
The
 following table reflects activity under the 2012 Employee Plan for
 the nine months ended March 31, 2014:

[0001157523-14-001989:notes:97]
|  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | -- |  |  | $ | -- |  |
| Granted |  |  | 78,500 |  |  |  | 5.73 |  |
| Terminated |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 78,500 |  |  | $ | 5.73 |  |
| Exercisable, end of period |  |  | 15,700 |  |  | $ | 5.73 |  |
| Weighted average fair value at grant date of options granted |  | $ | 3.84 |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 85,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 17,000 |  |  |  |  |  |

[0001157523-14-001989:notes:98]
The
 following table summarizes information about stock options
 outstanding under the 2012 Employee Plan at March 31,
 2014:

[0001157523-14-001989:notes:99]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable |  |  | Weighted average exercise price |  |
| $4.00 - $ 7.00 |  |  |  | 78,500 |  |  | 9.6 |  |  | $ | 5.73 |  |  |  | 15,700 |  |  | $ | 5.73 |  |
|  |  |  |  |  | 78,500 |  |  | 9.6 |  |  | $ | 5.73 |  |  |  | 15,700 |  |  | $ | 5.73 |  |

[0001157523-14-001989:notes:100]
As
 of March 31, 2014, there was $289,000 of unearned stock-based
 compensation cost related to share-based compensation arrangements
 granted under the 2012 Employee Plan. There were no options granted
 during the three months ended March 31,2014. The total fair value
 of the options vesting during the three and nine months ended March
 31, 2014 under this plan was $0 and $60,000,
 respectively.

[0001157523-14-001989:notes:101]
[same as prior period, unchanged from 0001157523-14-000527:notes:98]

[0001157523-14-001989:notes:102]
Under
 the 2012 Non-Employee Plan, stock options may be granted with a
 term of up to 10 years at an exercise price equal to or greater
 than the fair market value on the date of grant and are exercisable
 in whole or in part at 20% per year beginning on the date of grant.
 An option granted under this plan shall vest in full upon a
 “change in control” as defined in the plan. At March
 31, 2014, 25,000 stock options were granted, 5,000 stock options
 were exercisable and 25,000 stock options were available for grant
 under this plan.

[0001157523-14-001989:notes:103]
The
 following table reflects activity under the 2012 Non-Employee Plan
 for the nine months ended March 31, 2014:

[0001157523-14-001989:notes:104]
|  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | -- |  |  | $ | -- |  |
| Granted |  |  | 25,000 |  |  |  | 4.88 |  |
| Terminated |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 25,000 |  |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 5,000 |  |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  | $ | 3.30 |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 48,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 10,000 |  |  |  |  |  |

[0001157523-14-001989:notes:105]
The
 following table summarizes information about stock options
 outstanding under the 2012 Non-Employee Plan at March 31,
 2014:

[0001157523-14-001989:notes:106]
|  |  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable |  |  | Weighted average exercise price |  |
| $4.00 - $ 5.00 |  |  |  | 25,000 |  |  | 9.4 |  |  | $ | 4.88 |  |  |  | 5,000 |  |  | $ | 4.88 |  |
|  |  |  |  |  | 25,000 |  |  | 9.4 |  |  | $ | 4.88 |  |  |  | 5,000 |  |  | $ | 4.88 |  |

[0001157523-14-001989:notes:107]
As
 of March 31, 2014, there was $78,000 of unearned stock-based
 compensation cost related to share-based compensation arrangements
 granted under the 2012 Non-Employee Plan. There were no options
 granted during the three months ended March 31,2014. The total fair
 value of the options vesting during the three and nine months ended
 March 31, 2014 under this plan was $0, and
 $17,000 respectively.

[0001157523-14-001989:notes:108]
[same as prior period, unchanged from 0001157523-14-000527:notes:105]

[0001157523-14-001989:notes:109]
Under
 the 2002 Employee Plan, stock options have been granted to key
 employees with a term of 10 years at an exercise price equal to the
 fair market value on the date of grant and are exercisable in whole
 or in part at 20% per year from the date of grant.  At
 March 31, 2014, 1,471,480 stock options had been granted, 265,750
 stock options were exercisable and no further stock options were
 available for grant under this plan after the plans expiration in
 October 2012.

[0001157523-14-001989:notes:110]
The
 following table reflects activity under the 2002 Employee plan for
 the nine months ended March 31,:

[0001157523-14-001989:notes:111]
|  |  | 2014 |  |  | 2013 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated/Lapsed |  |  | (47,790 | ) |  |  | 1.74 |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | (337,600 | ) |  |  | 2.70 |  |  |  | (729,000 | ) |  |  | 1.85 |  |
| Outstanding, end of period |  |  | 265,750 |  |  | $ | 6.07 |  |  |  | 651,140 |  |  | $ | 4.18 |  |
| Exercisable, end of period |  |  | 265,750 |  |  | $ | 6.07 |  |  |  | 651,140 |  |  | $ | 4.18 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 1,399,000 |  |  |  |  |  |  | $ | 1,301,000 |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 244,000 |  |  |  |  |  |  | $ | 578,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 244,000 |  |  |  |  |  |  | $ | 578,000 |  |  |  |  |  |

[0001157523-14-001989:notes:112]
337,600
 and 729,000 stock options were exercised during the nine months
 ended March 31, 2014 and 2013, respectively. 324,100 of the 337,600
 stock options exercised were settled by exchanging 164,859 shares
 of the Company’s common stock of which 85,170 was retired
 upon receipt. The 27,000 exercise was settled by exchanging 13,807
 shares of the Company’s common stock, which was retired upon
 receipt. Cash received from option exercises was $25,650 and $0 for
 the nine months ended March 31, 2014 and 2013, respectively, and
 the actual tax benefit realized for the tax deductions from option
 exercises was $0 for each of these periods.

[0001157523-14-001989:notes:113]
[same as prior period, unchanged from 0001157523-14-000527:notes:110]

[0001157523-14-001989:notes:114]
|  |  |  | Options outstanding and exercisable |  |
| Range of exercise prices |  |  | Number outstanding |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |
| $4.01 - $ 7.50 |  |  |  | 228,250 |  |  | 2.1 |  |  |  | 5.75 |  |
| $7.51 - $11.16 |  |  |  | 37,500 |  |  | 2.0 |  |  |  | 11.16 |  |
|  |  |  |  |  | 265,750 |  |  | 2.1 |  |  | $ | 6.51 |  |

[0001157523-14-001989:notes:115]
[same as prior period, unchanged from 0001157523-14-000527:notes:112]

[0001157523-14-001989:notes:116]
The
 following table reflects activity under the 2000 Non-employee Plan
 for the nine months ended March 31,

[0001157523-14-001989:notes:117]
|  |  | 2014 |  |  | 2013 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated/Lapsed |  |  | (30,000 | ) |  |  | 5.03 |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | -- |  |  | $ | -- |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of period |  |  | -- |  |  | $ | -- |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-14-001989:notes:118]
NOTE 10 - Commitments and Contingencies

[0001157523-14-001989:notes:119]
Leases

[0001157523-14-001989:notes:120]
The
 Company is committed under various operating leases, not including
 the land lease discussed below, which do not extend beyond fiscal
 2016.

[0001157523-14-001989:notes:121]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $7,000 and $14,000 for the three months ended
 March 31, 2014 and 2013, respectively and $25,000 and $37,000 for
 the nine months ended March 31, 2014 and 2013,
 respectively.

[0001157523-14-001989:notes:122]
Land
 Lease

[0001157523-14-001989:notes:123]
On
 April 26, 1993, one of the Company's foreign subsidiaries entered
 into a 99 year lease, expiring in 2092, for approximately four
 acres of land in the Dominican Republic at an annual cost of
 $288,000, on which the Company's principal production facility is
 located.

[0001157523-14-001989:notes:124]
Litigation

[0001157523-14-001989:notes:125]
In
 the normal course of business, the Company is a party to claims
 and/or litigation. Management believes that the settlement of such
 claims and/or litigation, considered in the aggregate, will not
 have a material adverse effect on the Company's financial position
 and results of operations.

[0001157523-14-001989:notes:126]
Employment
 Agreements

[0001157523-14-001989:notes:127]
As
 of June 30, 2013, the Company was obligated under two employment
 agreements and one severance agreement.  The employment
 agreements are with the Company’s CEO and Senior Vice
 President of Sales and Marketing (“the SVP”). The
 employment agreement with the CEO provides for an annual salary of
 $587,000, as adjusted for inflation; incentive compensation as may
 be approved by the Board of Directors from time to time and a
 termination payment in an amount up to 299% of the average of the
 prior five calendar year's compensation, subject to certain
 limitations, as defined in the agreement.  The employment
 agreement renews annually in August unless either party gives the
 other notice of non-renewal at least six months prior to the end of
 the applicable term. The employment agreement with the SVP expires
 in October 2014 and provides for an annual salary of $274,400 and,
 if terminated by the Company without cause, severance of nine
 months’ salary and continued company-sponsored health
 insurance for six months from the date of termination. The
 severance agreement provides for payments equal to nine months of
 salary and six months of health insurance in the event of a
 non-voluntary termination of employment without cause.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-14-001989:notes:128]
[same as prior period, unchanged from 0001157523-14-000527:notes:125]

[0001157523-14-001989:notes:129]
[same as prior period, unchanged from 0001157523-14-000527:notes:126]

[0001157523-14-001989:notes:130]
[same as prior period, unchanged from 0001157523-14-000527:notes:127]

[0001157523-14-001989:notes:131]
| Financial Information Relating to Domestic and Foreign Operations |  |
|  |  | Three months ended March 31, |  |  | Nine months ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (in thousands) |  |  | (in thousands) |  |  |  |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 16,299 |  |  | $ | 16,174 |  |  | $ | 50,186 |  |  | $ | 46,543 |  |
| Foreign |  |  | 973 |  |  |  | 989 |  |  |  | 2,678 |  |  |  | 3,048 |  |
| Total Net Sales |  | $ | 17,272 |  |  | $ | 17,163 |  |  | $ | 52,864 |  |  | $ | 49,591 |  |
| Identifiable assets: |  | March 31, 2014 |  |  | June 30, 2013 |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 47,807 |  |  | $ | 51,141 |  |  |  |  |  |  |  |  |  |
| Dominican Republic (2) |  |  | 13,039 |  |  |  | 12,763 |  |  |  |  |  |  |  |  |  |
| Total Identifiable Assets |  | $ | 60,846 |  |  | $ | 63,903 |  |  |  |  |  |  |  |  |  |

[0001157523-14-001989:notes:132]
[same as prior period, unchanged from 0001157523-14-000527:notes:129]

[0001157523-14-001989:notes:133]
(2)
 Consists primarily of inventories (March 31, 2014 = $9,356; June
 30, 2013 = $9,105) and fixed assets (March 31, 2014 = $3,522; June
 30, 2013 = $3,546) located at the Company's principal manufacturing
 facility in the Dominican Republic.
