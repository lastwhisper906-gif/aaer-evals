# NSSC note change history — 0001157523-14-000527 → 0001157523-14-001989


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001157523-14-001989:note_history:1]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $7,000 and $14,000 for the three months ended
 March 31, 2014 and 2013, respectively and $25,000 and $37,000 for
 the nine months ended March 31, 2014 and 2013,
 respectively.
  (was, 2014-02-10, similarity 0.8671):
[0001157523-14-000527:note_history:1]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $9,000 and $12,000 for the three months ended
 December 31, 2013 and 2012, respectively and $18,000 and $23,000
 for the six months ended December 31, 2013 and 2012,
 respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001157523-14-001989:note_history:2]
The
 unaudited condensed consolidated financial statements of Napco
 Security Technologies, Inc and Subsidiaries (the
 “Company”), including these notes, have been prepared
 by the Company in accordance with U.S. generally accepted
 accounting principles (“GAAP”) for interim financial
 information and pursuant to the rules and regulations promulgated
 by the U.S. Securities and Exchange Commission (the
 “SEC”). Accordingly, certain information and
 disclosures normally included in financial statements prepared in
 accordance with GAAP have been omitted or condensed. However, in
 the opinion of management, all adjustments (consisting of normal
 recurring accruals) considered necessary for a fair presentation
 have been included. These unaudited condensed consolidated
 financial statements should be read in conjunction with the
 Company’s audited consolidated financial statements for the
 year ended June 30, 2013 and the notes thereto included in the
 Company’s Annual Report on Form 10-K filed with the SEC on
 September 17, 2013. Results of consolidated operations for the
 interim periods are not necessarily indicative of a full
 year’s operating results. The unaudited condensed
 consolidated financial statements herein include the accounts of
 the Company and its wholly owned subsidiaries. All material
 inter-company accounts and transactions have been eliminated.
 Certain
 prior period amounts relating to credit card fees have been
 reclassified for consistency with the current period presentation.
 The reclassification did not have an impact on the Balance Sheets,
 Statement of Cash Flows or reported Net income (loss) for any
 period.
  (was, 2014-02-10, similarity 0.9085):
[0001157523-14-000527:note_history:2]
The
 unaudited condensed consolidated financial statements of Napco
 Security Technologies, Inc and Subsidiaries (the
 “Company”), including these notes, have been prepared
 by the Company in accordance with U.S. generally accepted
 accounting principles (“GAAP”) for interim financial
 information and pursuant to the rules and regulations promulgated
 by the U.S. Securities and Exchange Commission (the
 “SEC”). Accordingly, certain information and
 disclosures normally included in financial statements prepared in
 accordance with GAAP have been omitted or condensed. However, in
 the opinion of management, all adjustments (consisting of normal
 recurring accruals) considered necessary for a fair presentation
 have been included. These unaudited condensed consolidated
 financial statements should be read in conjunction with the
 Company’s audited consolidated financial statements for the
 year ended June 30, 2013 and the notes thereto included in the
 Company’s Annual Report on Form 10-K filed with the SEC on
 September 17, 2013. Results of consolidated operations for the
 interim periods are not necessarily indicative of a full
 year’s operating results. The unaudited condensed
 consolidated financial statements herein include the accounts of
 the Company and its wholly owned subsidiaries. All material
 inter-company accounts and transactions have been
 eliminated.

- changed (2014-05-07):
[0001157523-14-001989:note_history:3]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 March 31, 2014 due to their short-term maturities; Long-Term Debt:
 The carrying amount of the Company’s long-term debt,
 including the current portion, at March 31, 2014 in the amount of
 $12,200,000 approximates fair value.
  (was, 2014-02-10, similarity 0.9757):
[0001157523-14-000527:note_history:3]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 December 31, 2013 due to their short-term maturities; Long-Term
 Debt: The carrying amount of the Company’s long-term debt,
 including the current portion, at December 31, 2013 in the amount
 of $13,100,000 approximates fair value.

- changed (2014-05-07):
[0001157523-14-001989:note_history:4]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at March 31, 2014 and June 30, 2013.  The
 Company considers all highly liquid investments with original
 maturities of three months or less to be cash
 equivalents.  The Company has cash balances in banks in
 excess of the maximum amount insured by the FDIC and other
 international agencies as of March 31, 2014 and June 30, 2013. The
 Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.
  (was, 2014-02-10, similarity 0.9734):
[0001157523-14-000527:note_history:4]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at December 31, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of December 31, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

- changed (2014-05-07):
[0001157523-14-001989:note_history:5]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $180,000 and $220,000 and for returns and other allowances of
 $865,000 and $1,055,000 as of March 31, 2014 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.
  (was, 2014-02-10, similarity 0.9883):
[0001157523-14-000527:note_history:5]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $230,000 and $220,000 and for returns and other allowances of
 $870,000 and $1,055,000 as of December 31, 2013 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.

- changed (2014-05-07):
[0001157523-14-001989:note_history:6]
|  |  | March 31, 2014 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (6,019 | ) |  | $ | 3,781 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (273 | ) |  |  | 67 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,292 | ) |  | $ | 9,748 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |
  (was, 2014-02-10, similarity 0.9875):
[0001157523-14-000527:note_history:6]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,836 | ) |  | $ | 3,964 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (261 | ) |  |  | 79 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,097 | ) |  | $ | 9,943 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |

- changed (2014-05-07):
[0001157523-14-001989:note_history:7]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 March 31, 2014 and 2013, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $586,000 and $688,000 for the nine months ended March 31, 2014 and
 2013, respectively. Amortization expense for each of the next five
 fiscal years is estimated to be as follows: 2014 - $781,000; 2015 -
 $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 - $371,000. The
 weighted average amortization period for intangible assets was 14.1
 years and 15.1 years at March 31, 2014 and 2013,
 respectively.
  (was, 2014-02-10, similarity 0.9338):
[0001157523-14-000527:note_history:7]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 December 31, 2013 and 2012, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $391,000 and $459,000 for the six months ended December 31, 2013
 and 2012, respectively. Amortization expense for each of the next
 five fiscal years is estimated to be as follows: 2014 - $781,000;
 2015 - $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 -
 $371,000. The weighted average amortization period for intangible
 assets was 14.4 years and 15.3 years at December 31, 2013 and
 2012, respectively.

- changed (2014-05-07):
[0001157523-14-001989:note_history:8]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended March 31, 2014 and 2013 was
 $189,000 and $124,000, respectively. Advertising expense for the
 nine months ended March 31, 2014 and 2013 was $801,000 and
 $847,000, respectively.
  (was, 2014-02-10, similarity 0.914):
[0001157523-14-000527:note_history:8]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended December 31, 2013 and 2012 was
 $247,000 and $294,000, respectively. Advertising expense for the
 six months ended December 31, 2013 and 2012 was $612,000 and
 $721,000, respectively.

- changed (2014-05-07):
[0001157523-14-001989:note_history:9]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended March 31, 2014 and 2013 was
 $1,275,000 and $1,187,000, respectively. Company-sponsored research
 and development expense for the nine months ended March 31, 2014
 and 2013 was $3,813,000 and $3,842,000, respectively.
  (was, 2014-02-10, similarity 0.9283):
[0001157523-14-000527:note_history:9]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended December 31, 2013 and 2012 was
 $1,252,000 and $1,319,000, respectively. Company-sponsored research
 and development expense for the six months ended December 31, 2013
 and 2012 was $2,538,000 and $2,655,000, respectively.

- changed (2014-05-07):
[0001157523-14-001989:note_history:10]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended March
 31 (in thousands, except per share data):
  (was, 2014-02-10, similarity 0.9738):
[0001157523-14-000527:note_history:10]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended
 December 31 (in thousands, except per share data):

- changed (2014-05-07):
[0001157523-14-001989:note_history:11]
Options
 to purchase 37,500 and 395,750 shares of common stock for the three
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.
  (was, 2014-02-10, similarity 0.9771):
[0001157523-14-000527:note_history:11]
Options
 to purchase 131,402 and 395,750 shares of common stock for the
 three months ended December 31, 2013 and 2012, respectively, were
 not included in the computation of Diluted EPS because their
 inclusion would be anti-dilutive.  These options were
 still outstanding at the end of the respective
 periods.

- changed (2014-05-07):
[0001157523-14-001989:note_history:12]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the nine months ended March
 31 (in thousands, except per share data):
  (was, 2014-02-10, similarity 0.9588):
[0001157523-14-000527:note_history:12]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the six months ended December
 31 (in thousands, except per share data):

- changed (2014-05-07):
[0001157523-14-001989:note_history:13]
Options
 to purchase 145,673 and 672,740 shares of common stock for the nine
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.
  (was, 2014-02-10, similarity 0.9149):
[0001157523-14-000527:note_history:13]
Options
 to purchase 199,759 and 681,140 shares of common stock for the six
 months ended December 31, 2013 and 2012, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

- changed (2014-05-07):
[0001157523-14-001989:note_history:14]
Stock-based
 compensation costs of $10,000 and $0 were recognized for the three
 months ended March 31, 2014 and 2013, respectively and $17,000 and
 $0 for the nine months ended March 31, 2014 and 2013,
 respectively.
  (was, 2014-02-10, similarity 0.9362):
[0001157523-14-000527:note_history:14]
Stock-based
 compensation costs of $6 and $0 were recognized for the three
 months ended December 31, 2013 and 2012, respectively and $7 and $0
 for the six months ended December 31, 2013 and 2012, respectively
 .

- changed (2014-05-07):
[0001157523-14-001989:note_history:15]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the nine months ended March 31, 2014 and 2013.
  (was, 2014-02-10, similarity 0.943):
[0001157523-14-000527:note_history:15]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the six months ended December 31, 2013 and 2012.

- changed (2014-05-07):
[0001157523-14-001989:note_history:16]
For
 the nine months ended March 31, 2014 and 2013 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.
  (was, 2014-02-10, similarity 0.9167):
[0001157523-14-000527:note_history:16]
For
 the six months ended December 31, 2013 and 2012 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.

- changed (2014-05-07):
[0001157523-14-001989:note_history:17]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($131,000 and $118,000 in the three months
 ended March 31, 2014 and 2013, respectively and $383,000 and
 $367,000 in the nine months ended March 31, 2014 and 2013,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($241,000 and $266,000 in the three
 months ended March 31, 2014 and 2013, respectively and $704,000 and
 $748,000 in the nine months ended March 31, 2014 and 2013,
 respectively).
  (was, 2014-02-10, similarity 0.8607):
[0001157523-14-000527:note_history:17]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($121,000 and $128,000 in the three months
 ended December 31, 2013 and 2012, respectively and $252,000 and
 $249,000 in the six months ended December 31, 2013 and 2012,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($221,000 and $259,000 in the three
 months ended December 31, 2013 and 2012, respectively and $463,000
 and $482,000 in the six months ended December 31, 2013 and 2012,
 respectively).

- changed (2014-05-07):
[0001157523-14-001989:note_history:18]
In
 July 2013, the FASB issued authoritative guidance that
 requires an entity to present an unrecognized tax benefit, or a
 portion of an unrecognized tax benefit, in the financial statements
 as a reduction to a deferred tax asset for a net operating loss
 (“NOL”) carry-forward, a similar tax loss, or a tax
 credit carry-forward.  If either (i) an NOL
 carry-forward, a similar tax loss, or tax credit carry-forward is
 not available as of the reporting date under the governing tax law
 to settle taxes that would result from the disallowance of the tax
 position or (ii) the entity does not intend to use the
 deferred tax asset for this purpose (provided that the tax law
 permits a choice), an entity should present an unrecognized tax
 benefit in the financial statements as a liability and should not
 net the unrecognized tax benefit with a deferred tax asset. 
 This guidance becomes effective prospectively for unrecognized tax
 benefits that exist as of the Company’s fiscal 2015 first
 quarter, with retrospective application and early adoption
 permitted.  The Company is currently evaluating the timing of
 adoption and the impact of this balance sheet presentation guidance
 but does not expect it to have a significant impact on the
 Company’s consolidated financial statements.
  (was, 2014-02-10, similarity 0.9984):
[0001157523-14-000527:note_history:18]
In
 July 2013, the FASB issued authoritative guidance that
 requires an entity to present an unrecognized tax benefit, or a
 portion of an unrecognized tax benefit, in the financial statements
 as a reduction to a deferred tax asset for a net operating loss
 (“NOL”) carryforward, a similar tax loss, or a tax
 credit carryforward.  If either (i) an NOL carryforward,
 a similar tax loss, or tax credit carryforward is not available as
 of the reporting date under the governing tax law to settle taxes
 that would result from the disallowance of the tax position or
 (ii) the entity does not intend to use the deferred tax asset
 for this purpose (provided that the tax law permits a choice), an
 entity should present an unrecognized tax benefit in the financial
 statements as a liability and should not net the unrecognized tax
 benefit with a deferred tax asset.  This guidance becomes
 effective prospectively for unrecognized tax benefits that exist as
 of the Company’s fiscal 2015 first quarter, with
 retrospective application and early adoption permitted.  The
 Company is currently evaluating the timing of adoption and the
 impact of this balance sheet presentation guidance but does not
 expect it to have a significant impact on the Company’s
 consolidated financial statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001157523-14-001989:note_history:19]
As
 of March 31, 2014, long-term debt consisted of a revolving credit
 facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000. In January 2014
 the Company and its lender amended the Revolving Credit Facility
 and Term Loans to allow for a lower LIBOR-based interest rate
 option of 1.5% as compared to 2.0% provided for previously. All
 other terms and conditions remain the same.
  (was, 2014-02-10, similarity 0.7994):
[0001157523-14-000527:note_history:19]
As
 of December 31, 2013, long-term debt consisted of a revolving
 credit facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000.

- changed (2014-05-07):
[0001157523-14-001989:note_history:20]
Outstanding
 balances and interest rates as of March 31, 2014 and June 30, 2013
 are as follows:
  (was, 2014-02-10, similarity 0.9474):
[0001157523-14-000527:note_history:20]
Outstanding
 balances and interest rates as of December 31, 2013 and June 30,
 2013 are as follows:

- added (2014-05-07):
[0001157523-14-001989:note_history:21]
|  | March 31, 2014 |  | June 30, 2013 |
|  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit | $ 2,500 |  | 1.7% |  | $ 5,500 |  | 2.5% |
| Term loans | 9,700 |  | 1.7% |  | 10,900 |  | 2.5% |
| Total debt | $ 12,200 |  | 1.7% |  | $ 16,400 |  | 2.5% |

- removed (2014-05-07):
[0001157523-14-000527:note_history:22]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,100 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,100 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001157523-14-001989:note_history:23]
Outstanding
 balances and interest rates as of March 31, 2014 and June 30, 2013
 are as follows:
  (was, 2014-02-10, similarity 0.9474):
[0001157523-14-000527:note_history:23]
Outstanding
 balances and interest rates as of December 31, 2013 and June 30,
 2013 are as follows:

- added (2014-05-07):
[0001157523-14-001989:note_history:24]
|  | March 31, 2014 |  | June 30, 2013 |
|  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit | $ 2,500 |  | 1.7% |  | $ 5,500 |  | 2.5% |
| Term loans | 9,700 |  | 1.7% |  | 10,900 |  | 2.5% |
| Total debt | $ 12,200 |  | 1.7% |  | $ 16,400 |  | 2.5% |

- removed (2014-05-07):
[0001157523-14-000527:note_history:25]
|  |  | December 31, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,100 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,100 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
