# NSSC 8-K — 0001157523-14-001990 filed 2014-05-07

## item codes, every 8-K on or before 2014-05-07

- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2014-05-07

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-14-001990:8k_2_02:1]
EX-99.1
2
a50860564ex99_1.htm
EXHIBIT 99.1

[0001157523-14-001990:8k_2_02:2]
a50860564ex99_1.htm

[0001157523-14-001990:8k_2_02:3]
Exhibit 99.1

[0001157523-14-001990:8k_2_02:4]
NAPCO Reports Financial Results for the Three and Nine Months Ended March 31, 2014

[0001157523-14-001990:8k_2_02:5]
-Q3 Net Income Increases 486% -

[0001157523-14-001990:8k_2_02:6]
- Revenue Growth 7% for the Nine Months ended March 31, 2014-

[0001157523-14-001990:8k_2_02:7]
- Residential Intrusion Sales Impacted by Harsh Winter-

[0001157523-14-001990:8k_2_02:8]
- Management to Host Conference Call Today at 11 a.m. -

[0001157523-14-001990:8k_2_02:9]
AMITYVILLE, N.Y., May 5, 2014 -- NAPCO Security Technologies, Inc. (Nasdaq: NSSC), one of the world's leading solutions providers and manufacturers of high-technology electronic intrusion security, connected home, video and fire systems, as well as enterprise-class access control and door locking products, for over 30 years, today announced financial results for its third fiscal quarter ended March 31, 2014.

[0001157523-14-001990:8k_2_02:10]
Highlights:

[0001157523-14-001990:8k_2_02:11]
| ● | Net sales for the third quarter were $17.2 million, an increase of 1% over last year’s third quarter. Net sales for the nine months were $52.9 million, up 7% from $49.6 million for the comparable period last year. |

[0001157523-14-001990:8k_2_02:12]
| ● | Recurring revenue for the third quarter and nine months increased 95% and 94% respectively and grew sequentially by 11%. |

[0001157523-14-001990:8k_2_02:13]
| ● | Gross margin improved 370 basis points to 30.8% for the quarter as compared to 27.1% for the same period last year, due to a more favorable sales mix. Gross margin for the nine months improved 210 basis points to 29.2% as compared to 27.1% for the comparable period a year ago. |

[0001157523-14-001990:8k_2_02:14]
| ● | Adjusted EBITDA (*see table attached) for the third quarter increased 81% to $1.3 million compared to $733,000 last year and was up 87% for the nine months to $3.0 million compared to $1.6 million in the comparable year ago period. |

[0001157523-14-001990:8k_2_02:15]
| ● | Net Income for the third quarter increased 486% to $650,000 compared to $111,000 last year and was up $1.3 million to $1.1 million for the nine month period. |

[0001157523-14-001990:8k_2_02:16]
| ● | Debt, net of cash, has been reduced by $26.1 million from $35.9 million to $9.8 million since acquiring Marks in August of 2008, with $3.4 million of this reduction occurring during the first nine months of this fiscal year. As a result of the lower debt levels and lower interest rates, net interest expense for the nine months decreased by $148,000 or 38% to $239,000 as compared to $387,000 for the comparable period last year. |

[0001157523-14-001990:8k_2_02:17]
| ● | Earnings per Share (Diluted) rose 300% to $0.03 from $0.01 for the third quarter. Diluted EPS for the nine months was $0.06 compared to $(0.01) for the nine months last year, a swing of $0.07 per share. |

[0001157523-14-001990:8k_2_02:18]
Richard Soloway, NAPCO’s Chairman and President, stated, “In the quarter we saw a healthy increase in our gross margins, Adjusted EBITDA, and net income.  This was due in large part to a more favorable sales mix, with greater contributions from recurring StarLink and i-Bridge revenue as well as access control and locking products, which carry the highest margins of our product portfolio. While our top line growth was negatively impacted by harsh winter weather, which we estimate cost us roughly $1.5 million in revenues in the quarter, we believe this positive sales mix trend should continue to benefit our results going forward. As the severe weather abates and we move into our seasonally strongest quarter, our fiscal fourth quarter, we should see a return to top-line growth. Our multi-pronged effort to accelerate our revenue growth, focused on high-profile markets such as school security and the ‘Connected Home’, are picking up steam. Interest from dealers, including unprecedented levels of inquiries at major trade shows, is on the upswing and suggests to us that we are on the right path. We expect that our exceptional products, technology, and commitment to new growth-related initiatives will result in the higher levels of profitability, cash flow, and value for our shareholders.”

[0001157523-14-001990:8k_2_02:19]
Mr. Soloway continued, “Our rollout of Project LocDown™, our school security initiative, delivered significant new business in the growing education vertical. The program provides training and certification of security integrators, leveraging proven subject matter expertise and thought leadership to help these integrators systematically and professionally evaluate school’s security programs. Then, these certified experts can recommend and sell solutions, notably from NAPCO’s Marks, Alarm Lock and Continental Access Control Divisions, to address any vulnerabilities. Sales of Starlink™ 3G/4G Radios have continued to increase due in part to a market need to replace an estimated two million 2G radios over the next few years as service providers begin to ‘sunset the older service. NAPCO’s Starlink Radio Service is one of the building blocks of recurring, subscription-based income that we have positioned NAPCO to take advantage of for growth. More and more households are eliminating their land lines and relying solely on their cellular phone service. This requires an alternate solution such as NAPCO’s Starlink Radio Service for communicating with the monitoring company.”

[0001157523-14-001990:8k_2_02:20]
“Another key recurring revenue source for the Company, is iBridge™ Connected Home Services,” continued Mr. Soloway. “Consumer interest in controlling their security systems, thermostats, lighting, video cameras and entry locks, via smart phones and tablets, as part of a ‘Connected Home’ continues to accelerate, and we are seeing sales of NAPCO’s professional iBridge Connected Home product line grow with this demand. We launched the iBridge Connected Home Dealer Program at ISC West, North America’s largest security industry trade show. This program will target the thousands of independent security dealers in the U.S. interested in marketing the iBridge Connected Home Brand and receiving connected home automation-specific training, marketing and sales support needed to take advantage of this burgeoning product category.”

[0001157523-14-001990:8k_2_02:21]
Financial Results

[0001157523-14-001990:8k_2_02:22]
Revenues for the three months ended March 31, 2014 increased 1% to $17.3 million, as compared to $17.2 million for the same period one year ago. The severe weather impacted consumer spending and installation schedules, and had a particularly pronounced impact on NAPCO’s Intrusion and Fire Alarm Division. Revenues for the nine months ended March 31, 2014 increased 7% to $52.9 million, as compared to $49.6 million for the same period one year ago.

[0001157523-14-001990:8k_2_02:23]
Selling, general and administrative expenses for the third quarter increased $155,000 to $4.6 million from $4.4 million for the same period in fiscal 2013. Selling, general and administrative expenses for the nine months increased $675,000 to $13.9 million from $13.3 million for the same period in fiscal 2013. Operating income for the third quarter was $749,000, representing an increase of $510,000 compared to $239,000 for the same period last year. Operating income for the nine months was $1.5 million, representing an increase of $1.3 million compared to $160,000 for the same period last year.

[0001157523-14-001990:8k_2_02:24]
Adjusted EBITDA* for the third quarter increased $592,000, to $1.3 million or $0.07 per share as compared to $733,000 or $0.04 per share for the same period last year (*see table attached). Adjusted EBITDA* for the nine months increased $1.4 million to $3.0 million or $0.15 per share as compared to $1.6 million or $0.08 per share for the same period last year (*see table attached).

[0001157523-14-001990:8k_2_02:25]
Net income for the quarter increased by $539,000 to $650,000 or $0.03 per share as compared to $111,000 or $0.01 per share for the same period last year. Net income for the nine months was $1,141,000 or $0.06 per share, representing a positive swing of $1.3 million as compared to a loss of $(188,000) or $(0.01) per share for the same period last year.

[0001157523-14-001990:8k_2_02:26]
Balance Sheet Summary

[0001157523-14-001990:8k_2_02:27]
At March 31, 2014, the Company had $2.4 million in cash and cash equivalents, compared to $3.2 million at June 30, 2013. NAPCO had working capital of $31.2 million as compared with working capital of $33.2 million at June 30, 2013. Current ratio was 4.5:1 as compared to 4.9:1 at June 30, 2013. Debt, net of cash, was $9.8 million at March 31, 2014, a decrease of $3.4 million compared to $13.2 million as of June 30, 2013.

[0001157523-14-001990:8k_2_02:28]
Conference Call Information

[0001157523-14-001990:8k_2_02:29]
Management will conduct a conference call at 11 a.m. today, May 5, 2014. Interested parties may participate in the call by dialing 1-877-941-4774 or for international callers, 1-480-629-9760, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m. ET on February 10, 2014 and ending on February 17, 2014. For the replay, please dial 1-877-870-5176 domestically, or 1-858-384-5517 for international callers, and use the replay access code, 4667663.

[0001157523-14-001990:8k_2_02:30]
In addition, the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=107815.

[0001157523-14-001990:8k_2_02:31]
About NAPCO Security Technologies, Inc.

[0001157523-14-001990:8k_2_02:32]
NAPCO Security Technologies, Inc. is one of the world's leading manufacturers and solutions providers of high-technology electronic security, connected home, video, fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for  innovation, technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001157523-14-001990:8k_2_02:33]
Safe Harbor Statement

[0001157523-14-001990:8k_2_02:34]
This press release contains forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the Securities and Exchange Commission.

[0001157523-14-001990:8k_2_02:35]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
|  |  | March 31, 2014 |  | June 30, 2013 |
|  |  | (unaudited) |  | (audited) |
| ASSETS |  | (in thousands, except for share data) |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,425 |  |  | $ | 3,229 |  |
| Accounts receivable, net of reserves and allowances |  |  | 14,213 |  |  |  | 18,211 |  |
| Inventories |  |  | 21,474 |  |  |  | 18,471 |  |
| Prepaid expenses and other current assets |  |  | 1,228 |  |  |  | 1,219 |  |
| Income tax receivable |  |  | -- |  |  |  | 64 |  |
| Deferred income taxes |  |  | 738 |  |  |  | 642 |  |
| Total Current Assets |  |  | 40,078 |  |  |  | 41,836 |  |
| Inventories - non-current |  |  | 2,798 |  |  |  | 3,436 |  |
| Deferred income taxes |  |  | 1,533 |  |  |  | 1,526 |  |
| Property, plant and equipment, net |  |  | 6,517 |  |  |  | 6,586 |  |
| Intangible assets, net |  |  | 9,748 |  |  |  | 10,334 |  |
| Other assets |  |  | 172 |  |  |  | 185 |  |
| TOTAL ASSETS |  | $ | 60,846 |  |  | $ | 63,903 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 4,001 |  |  |  | 3,318 |  |
| Accrued expenses |  |  | 1,489 |  |  |  | 2,093 |  |
| Accrued salaries and wages |  |  | 1,652 |  |  |  | 1,604 |  |
| Accrued income taxes |  |  | 102 |  |  |  | -- |  |
| Total Current Liabilities |  |  | 8,844 |  |  |  | 8,615 |  |
| Long-term debt, net of current maturities |  |  | 10,600 |  |  |  | 14,800 |  |
| Accrued income taxes |  |  | 169 |  |  |  | 153 |  |
| Total Liabilities |  |  | 19,613 |  |  |  | 23,568 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 20,796,813 shares issued; and 19,419,076 and 19,296,335 shares outstanding, respectively |  |  | 210 |  |  |  | 208 |  |
| Additional paid-in capital |  |  | 15,848 |  |  |  | 15,356 |  |
| Retained earnings |  |  | 33,219 |  |  |  | 32,078 |  |
|  |  |  | 49,277 |  |  |  | 47,642 |  |
| Less: Treasury Stock, at cost (1,630,167 and 1,500,478 shares, respectively) |  |  | (8,044 | ) |  |  | (7,307 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 41,233 |  |  |  | 40,335 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 60,846 |  |  | $ | 63,903 |  |

[0001157523-14-001990:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited) |
|  |  | Three months ended March 31, |  | Nine months ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 17,272 |  |  | $ | 17,163 |  |  | $ | 52,864 |  |  | $ | 49,591 |  |
| Cost of sales |  |  | 11,955 |  |  |  | 12,511 |  |  |  | 37,427 |  |  |  | 36,162 |  |
| Gross Profit |  |  | 5,317 |  |  |  | 4,652 |  |  |  | 15,437 |  |  |  | 13,429 |  |
| Selling, general, and administrative expenses |  |  | 4,568 |  |  |  | 4,413 |  |  |  | 13,944 |  |  |  | 13,269 |  |
| Operating Income |  |  | 749 |  |  |  | 239 |  |  |  | 1,493 |  |  |  | 160 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 59 |  |  |  | 103 |  |  |  | 239 |  |  |  | 387 |  |
| Other, net |  |  | 4 |  |  |  | 3 |  |  |  | 10 |  |  |  | 10 |  |
| Income (Loss) before Income Taxes |  |  | 686 |  |  |  | 133 |  |  |  | 1,244 |  |  |  | (237 | ) |
| Provision (benefit) for income taxes |  |  | 36 |  |  |  | 22 |  |  |  | 103 |  |  |  | (49 | ) |
| Net Income (Loss) |  | $ | 650 |  |  | $ | 111 |  |  | $ | 1,141 |  |  | $ | (188 | ) |
| Net Income (Loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.03 |  |  | $ | 0.01 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |
| Diluted |  | $ | 0.03 |  |  | $ | 0.01 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,416,000 |  |  |  | 19,296,000 |  |  |  | 19,382,000 |  |  |  | 19,181,000 |  |
| Diluted |  |  | 19,471,000 |  |  |  | 19,419,000 |  |  |  | 19,419,000 |  |  |  | 19,181,000 |  |

[0001157523-14-001990:8k_2_02:37]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |
|  |  | Three months ended March 31, |  | Nine months ended March 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Net income (loss) |  | $ | 650 |  |  | $ | 111 |  |  | $ | 1,141 |  |  | $ | (188 | ) |
| Add back provision (benefit) for income taxes |  |  | 36 |  |  |  | 22 |  |  |  | 103 |  |  |  | (49 | ) |
| Add back interest and other expense |  |  | 63 |  |  |  | 106 |  |  |  | 249 |  |  |  | 397 |  |
| Operating income (GAAP) |  |  | 749 |  |  |  | 239 |  |  |  | 1,493 |  |  |  | 160 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 195 |  |  |  | 229 |  |  |  | 586 |  |  |  | 688 |  |
| Add back change to inventory reserve |  |  | 125 |  |  |  | -- |  |  |  | 250 |  |  |  | -- |  |
| Add back stock-based compensation expense |  |  | 11 |  |  |  | -- |  |  |  | 17 |  |  |  | -- |  |
| Adjusted non-GAAP operating income |  |  | 1,080 |  |  |  | 468 |  |  |  | 2,346 |  |  |  | 848 |  |
| Add back depreciation and other amortization |  |  | 245 |  |  |  | 265 |  |  |  | 691 |  |  |  | 779 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,325 |  |  | $ | 733 |  |  | $ | 3,037 |  |  | $ | 1,627 |  |
| Adjusted EBITDA per Diluted Share |  | $ | 0.07 |  |  | $ | 0.04 |  |  | $ | 0.15 |  |  | $ | 0.08 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 19,471,000 |  |  |  | 19,419,000 |  |  |  | 19,419,000 |  |  |  | 19,181,000 |  |

[0001157523-14-001990:8k_2_02:38]
* Non-GAAP Information. Certain non-GAAP measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not include impairment of goodwill, amortization of intangibles, changes to inventory reserves, restructuring charges, stock-based compensation expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial measures included in the above.

[0001157523-14-001990:8k_2_02:39]
INVESTOR INQUIRIES:

[0001157523-14-001990:8k_2_02:40]
Brett Maas

[0001157523-14-001990:8k_2_02:41]
Hayden IR

[0001157523-14-001990:8k_2_02:42]
(646) 536-7331

[0001157523-14-001990:8k_2_02:43]
brett@haydenir.com

[0001157523-14-001990:8k_2_02:44]
Peter Seltzberg, Regional Vice-President

[0001157523-14-001990:8k_2_02:45]
Hayden IR

[0001157523-14-001990:8k_2_02:46]
(646) 415-8972

[0001157523-14-001990:8k_2_02:47]
peter@haydenir.com
