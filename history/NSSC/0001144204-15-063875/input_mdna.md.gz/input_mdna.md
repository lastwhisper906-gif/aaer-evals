# NSSC MD&A — 0001144204-15-063875


## mdna

[0001144204-15-063875:mdna:1]
Item 2.  
Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001144204-15-063875:mdna:2]
Management’s Discussion and Analysis
of Financial Condition and Results of Operations

[0001144204-15-063875:mdna:3]
|  | 16 |  |

[0001144204-15-063875:mdna:4]
Overview

[0001144204-15-063875:mdna:5]
The Company is a diversified manufacturer of security products,
encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products
for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International
sales accounted for approximately 3% and 4% of our revenues for the three months ended September 30, 2015 and 2014, respectively.

[0001144204-15-063875:mdna:6]
The Company owns and operates manufacturing
facilities in Amityville, New York and the Dominican Republic. A significant portion of our operating costs are fixed, and do
not fluctuate with changes in production levels or utilization of our manufacturing capacity. As production levels rise and factory
utilization increases, the fixed costs are spread over increased output, which should improve profit margins. Conversely, when
production levels decline our fixed costs are spread over reduced levels, thereby decreasing margins.

[0001144204-15-063875:mdna:7]
The security products market is characterized
by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of revenues
to research and development (R&D) on an annual basis. The Company does not expect products resulting from our R&D investments
in fiscal 2015 or thereafter to contribute materially to revenue during this fiscal year, but should benefit the Company over
future years. In general, the new products introduced by the Company are initially shipped in limited quantities, and increase
over time. Prices and manufacturing costs tend to decline over time as products and technologies mature.

[0001144204-15-063875:mdna:8]
Economic and Other Factors

[0001144204-15-063875:mdna:9]
We are subject to the effects of general economic
and market conditions. In the event that the U.S. or international economic conditions deteriorate, our revenue, profit and cash-flow
levels could be materially adversely affected in future periods. In the event of such deterioration, many of our current or potential
future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products.
Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. If such events
do occur, they may result in our expenses being too high in relation to our revenues and cash flows.

[0001144204-15-063875:mdna:10]
Seasonality

[0001144204-15-063875:mdna:11]
The Company's fiscal year begins on July 1
and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore
sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced
in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing
and construction markets. Deterioration of the current economic conditions may also affect this trend.

[0001144204-15-063875:mdna:12]
Critical Accounting Policies and Estimates

[0001144204-15-063875:mdna:13]
The Company's significant accounting policies
are fully described in Note 1 to the Company's consolidated financial statements included in its 2015 Annual Report on Form 10-K.  Management
believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in
the preparation of its consolidated financial statements.

[0001144204-15-063875:mdna:14]
Revenue Recognition

[0001144204-15-063875:mdna:15]
The Company recognizes revenue when the following criteria
are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product
or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured.
Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms
of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale.
The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of
actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001144204-15-063875:mdna:16]
The Company analyzes sales returns and is able to make
reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are
based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly,
the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results
could differ from those estimates.

[0001144204-15-063875:mdna:17]
|  | 17 |  |

[0001144204-15-063875:mdna:18]
Concentration of Credit Risk

[0001144204-15-063875:mdna:19]
An entity is more vulnerable to
concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through
diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration,
and vary in significance. The Company had one customer with an accounts receivable balance that comprised

[0001144204-15-063875:mdna:20]
|  | 18 |  |

[0001144204-15-063875:mdna:21]
% of the Company’s
accounts receivable at September 30, 2015 and 22% of the Company’s accounts receivable at June 30, 2015. Sales to any one
customer did not exceed 10% of net sales in the three months ended September 30, 2015 or 2014.

[0001144204-15-063875:mdna:22]
In the ordinary course of business,
we have established a reserve for doubtful accounts and customer deductions in the amount of $100,000 and $175,000 as of September
30, 2015 and June 30, 2015, respectively. Our reserve for doubtful accounts is a subjective critical estimate that has a direct
impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and
historical or anticipated events.

[0001144204-15-063875:mdna:23]
Inventories

[0001144204-15-063875:mdna:24]
Inventories are valued at the lower of cost or fair
market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes
finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include
raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of
the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly
of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory,
are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-15-063875:mdna:25]
In addition, the Company records
an inventory obsolescence reserve, which represents the difference between the cost of the inventory and its estimated market
value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied
to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate
applications of its raw materials and to convert finished product into alternate versions of the same product to better match
customer demand. There is inherent professional judgment and subjectivity made by both production and engineering members of management
in determining the estimated obsolescence percentage. In addition, and as necessary, the Company may establish specific reserves
for future known or anticipated events. The Company also regularly reviews the period over which its inventories will be converted
to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001144204-15-063875:mdna:26]
Intangible Assets

[0001144204-15-063875:mdna:27]
The Company evaluates its Intangible
Assets for impairment at least on an annual basis and will evaluate them earlier if there are indicators of a potential impairment.
Those intangible assets that are classified as goodwill or as other intangibles with indefinite lives are not amortized. Impairment
testing is performed in two steps: (i) the Company determines if there is impairment by comparing the fair value of a reporting
unit with its carrying value, and (ii) if there is impairment, the Company measures the amount of impairment loss by comparing
the implied fair value of intangible assets with the carrying amount of the intangible assets.

[0001144204-15-063875:mdna:28]
Income Taxes

[0001144204-15-063875:mdna:29]
The Company has identified the
United States and New York State as its major tax jurisdictions. The fiscal 2012 and forward years are still open for examination.

[0001144204-15-063875:mdna:30]
For the three months ended September
30, 2015, the Company recognized a net income tax expense of $46,000. During the three months ending September 30, 2015 there
was no change in the Company’s reserve for uncertain income tax positions. The Company’s practice is to recognize
interest and penalties related to income tax matters in income tax expense and accrued income taxes. As of September 30, 2015,
the Company had accrued interest totaling $0 and $102,000 of unrecognized net tax benefits that, if recognized, would favorably
affect the Company’s effective income tax rate in any future period. The Company uses the flow through method to account
for investment tax credits earned on eligible research and development expenditures. Under this method, the investment tax credits
are recognized as a reduction to income tax expense.

[0001144204-15-063875:mdna:31]
Deferred tax assets and liabilities
are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying
amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using
enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered
or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that
includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and
deferred tax liabilities. The components of the deferred tax assets and liabilities are individually classified as current and
non-current based on their characteristics. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management,
it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and
recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.

[0001144204-15-063875:mdna:32]
18

[0001144204-15-063875:mdna:33]
Results of Operations

[0001144204-15-063875:mdna:34]
|  |  | Three months ended September 30, (dollars in thousands) |  |
|  |  | 2015 |  |  | 2014 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 18,149 |  |  | $ | 17,336 |  |  |  | 4.7 | % |
| Gross profit |  |  | 5,637 |  |  |  | 5,255 |  |  |  | 7.3 | % |
| Gross profit as a % of net sales |  |  | 31.1 | % |  |  | 30.3 | % |  |  | 2.6 | % |
| Selling, general and administrative |  |  | 5,313 |  |  |  | 5,009 |  |  |  | 6.1 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 29.3 | % |  |  | 28.9 | % |  |  | 1.4 | % |
| Operating income |  |  | 324 |  |  |  | 246 |  |  |  | 31.7 | % |
| Interest expense, net |  |  | 49 |  |  |  | 55 |  |  |  | (10.9 | )% |
| Other (income) expense |  |  | 4 |  |  |  | (5 | ) |  |  | 180.0 | % |
| (Benefit) provision for income taxes |  |  | (44 | ) |  |  | 37 |  |  |  | (118.9 | )% |
| Net income |  |  | 315 |  |  |  | 159 |  |  |  | 98.1 | % |

[0001144204-15-063875:mdna:35]
Sales for the three months ended September
30, 2015 increased by $813,000 to $18,149,000 as compared to $17,336,000 for the same period a year ago. The increase in sales
for the three months ended September 30, 2015 was due primarily to increased sales of the Company’s door-locking products
($955,000) and intrusion products ($14,000) as partially offset by decreased sales of access control products ($156,000). Sales
of the Company’s door-locking products increased primarily from an increase in domestic installations of the Company’s
digital lock products.

[0001144204-15-063875:mdna:36]
Gross profit for the three months ended September
30, 2015 increased to $5,637,000 or 31.1% of sales as compared to $5,255,000 or 30.3% of sales for the same period a year ago.
The increase in gross profit for the three months was primarily due to increased sales as well as a continued positive shift in
product mix to the Company’s door-locking products.

[0001144204-15-063875:mdna:37]
Selling, general and administrative expenses
for the three months ended September 30, 2015 increased by $304,000 to $5,313,000 from $5,009,000 for the same period a year ago.
Selling, general and administrative expenses as a percentage of net sales increased to 29.3% for the three months ended September
30, 2015 from 28.9% for the same period a year ago. The increase in dollars and as a percentage of sales for the three months
was due primarily from the addition of selling personnel and increased advertising.

[0001144204-15-063875:mdna:38]
Interest expense, net for the three months
ended September 30, 2015 decreased by $6,000 to $49,000 as compared to $55,000 for the same period a year ago. The decrease in
interest expense for the three months ended September 30, 2015 resulted from lower average outstanding debt during the current
periods as compared to the same periods a year ago.

[0001144204-15-063875:mdna:39]
The Company’s provision for income taxes
for the three months ended September 30, 2015 decreased by $81,000 to a benefit of $46,000 as compared to a provision of $37,000
for the same period a year ago. The change in the provision for income taxes for the three months was caused primarily by the
reversal of a liability that is no longer required relating to foreign source income as partially offset by the increase in income
before income taxes as compared to the same period a year ago. As a result, the Company’s effective rate for income tax
was (16)% and

[0001144204-15-063875:mdna:40]
|  | 19 |  |

[0001144204-15-063875:mdna:41]
% for the three months ended September 30,

[0001144204-15-063875:mdna:42]
|  | 20 |  |

[0001144204-15-063875:mdna:43]
15 and 2014, respectively.

[0001144204-15-063875:mdna:44]
Net income increased by $156,000 to $315,000
or $0.02 per diluted share for the three months ended September 30, 2015 as compared to $159,000 or $0.01 per diluted share for
the same period a year ago. The change in net income for the three months ended September 30, 2015 was primarily due to the items
as described above.

[0001144204-15-063875:mdna:45]
Liquidity and Capital Resources

[0001144204-15-063875:mdna:46]
During the three months ended September 30,
2015 the Company utilized a portion of its cash from operations ($1,627,000 of $2,087,000) to repay outstanding debt ($1,400,000),
purchase treasury stock ($94,000) and purchase property, plant and equipment ($133,000). The Company believes its current working
capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations
through the next twelve months.

[0001144204-15-063875:mdna:47]
19

[0001144204-15-063875:mdna:48]
Accounts Receivable at September 30, 2015
decreased $2,725,000 to $15,269,000 as compared to $17,994,000 at June 30, 2015. This decrease is primarily the result of the
lower sales volume during the quarter ended September 30, 2015 as compared to the quarter ended June 30, 2015, which is typically
the Company’s highest.

[0001144204-15-063875:mdna:49]
Inventories at September 30, 2015 increased
$910,000 to $27,780,000 as compared to $26,870,000 at June 30, 2015. This increase is primarily the result of the Company level-loading
its production facility in the Dominican Republic, whereas the Company’s sales are typically highest in the fourth quarter.

[0001144204-15-063875:mdna:50]
Accounts payable and accrued expenses decreased $476,000 to $7,359,000
as of September 30, 2015 as compared to $7,833,000 at June 30, 2015.

[0001144204-15-063875:mdna:51]
As of September 30, 2015, long-term debt consisted
of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two
term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term
Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28
equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000
Term Loan is being repaid in 20 equal, quarterly payments of $325,000. As of September 30, 2015, the Company had $2,000,000 in
outstanding borrowings and $9,000,000 in availability under the Revolving Credit Facility. The Company’s long-term debt
is described more fully in Note 6 to the condensed consolidated financial statements.

[0001144204-15-063875:mdna:52]
The agreements contain various restrictions
and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain
financial ratios, as defined in the restated agreement.

[0001144204-15-063875:mdna:53]
As of September 30, 2015
the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the
normal course of business.
