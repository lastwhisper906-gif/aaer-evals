# NSSC 8-K — 0001144204-15-063858 filed 2015-11-09

## item codes, every 8-K on or before 2015-11-09

- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2015-11-09

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-15-063858:8k_2_02:1]
EX-99.1
2
v424136_ex99-1.htm
EXHIBIT 99.1

[0001144204-15-063858:8k_2_02:2]
Exhibit 99.1

[0001144204-15-063858:8k_2_02:3]
NAPCO Announces Results for First Quarter
Ended September 30, 2015

[0001144204-15-063858:8k_2_02:4]
-Record First Quarter Revenue of $18.1 Million-

[0001144204-15-063858:8k_2_02:5]
-Q1 Alarm Division Recurring Revenues Grow 38%-

[0001144204-15-063858:8k_2_02:6]
-Management to Host Conference Call Today at 11 a.m.-

[0001144204-15-063858:8k_2_02:7]
AMITYVILLE, N.Y., Nov. 9, 2015 /PRNewswire/ -- NAPCO Security
Technologies, Inc. (NSSC), one of the world's leading solutions providers and manufacturers
of high-technology electronic intrusion security (including recurring, service fee revenue), connected home, video and fire systems,
as well as enterprise-class access control and door locking products, today announced financial results for its first fiscal quarter
ended September 30, 2015.

[0001144204-15-063858:8k_2_02:8]
Highlights:

[0001144204-15-063858:8k_2_02:9]
|  | · | Net sales were a first quarter record at $18.1 million, up 5% from the same quarter last year. |

[0001144204-15-063858:8k_2_02:10]
|  | · | Sales of the Company's door-locking products increased 8% in the first quarter as compared to the same quarter a year ago. |

[0001144204-15-063858:8k_2_02:11]
|  | · | Alarm Division recurring revenue for the first quarter increased 38% and grew sequentially by 10%. |

[0001144204-15-063858:8k_2_02:12]
|  | · | Net Income for the quarter increased by 98% to $315,000 as compared to $159,000 last year. |

[0001144204-15-063858:8k_2_02:13]
|  | · | Earnings per share (diluted) for the first quarter was $0.02 as compared to $0.01 for the same quarter last year. |

[0001144204-15-063858:8k_2_02:14]
|  | · | Debt, net of cash, has been reduced by $29.4 million from $35.9 million to $6.5 million since acquiring Marks in August of 2008. |

[0001144204-15-063858:8k_2_02:15]
Richard Soloway, Chairman and President stated, "NAPCO
generated record revenue and almost doubled net income in a quarter that was highlighted by the strong growth of our locking solutions
and our continued expansion into the recurring revenue-driven alarm communicator market. In door locking, we are benefitting from
the construction boom in multi-family housing, particularly luxury apartment buildings, which are driving demand for super-premium
architectural hardware.

[0001144204-15-063858:8k_2_02:16]
"We also continue to see strong interest for our products
designed for campus security. Our innovative Alarm Lock, Marks and Continental Access Control products, many of which were specifically
designed by our Company for school applications, increasingly fit the needs of both K-12 and college/university educational institutions.
NAPCO has the ability to play a significant role in protecting schools against active shooter events, which unfortunately have
become too commonplace, with our innovative locking and access control solutions. Our school vertical specific Project LocDown,
which incorporates our School Access-control Vulnerability Index (S.A.V.I.) and audit system, takes a holistic and active approach
in training security dealers and end-user school officials on how to significantly reduce mass shooting incidents."

[0001144204-15-063858:8k_2_02:17]
Mr. Soloway added, "In the first quarter, we introduced
our latest recurring revenue product, the StarLink commercial intrusion and fire alarm communicator. The newest addition to the
family of StarLink™ 3G/4G and Verizon CDMA alarm communicators helped drive growth of 38% year-over-year for our subscription-based,
recurring revenue services. Demand for these products remains high as alarm dealers continue to use our radios to replace both
older 2G communicators that have been rendered obsolete as service providers convert to newer technology and as a means to communicate
alarm signals where a traditional phone line is no longer available. This recent launch of StarLink expands the Company's footprint
nicely and well-positions NAPCO to take advantage of the lucrative commercial alarm communication business, which comprises approximately
50% of the alarm market."

[0001144204-15-063858:8k_2_02:18]
"Looking ahead, we are excited about NAPCO's trajectory
as we progress through fiscal year 2016. We are continuing to see strong interest across our product lineup as well as recognizing
the benefits of our investments in higher-margin recurring revenue products and services. Overall, we are well-positioned to continue
creating value for shareholders through improving gross margins and great earnings power," Mr. Soloway concluded.

[0001144204-15-063858:8k_2_02:19]
Financial Results

[0001144204-15-063858:8k_2_02:20]
Net Sales for the three months ended September 30, 2015 increased
5% to a record $18.1 million, as compared to $17.3 million for the same period one year ago. Selling, general and administrative
expenses for the quarter were $5.3 million, or 29.3% of sales, as compared to $5.0 million, or 28.9% of sales, for the same period
in 2014. The increase was due primarily to additional sales staff and advertising expenditures to support ongoing product introductions.

[0001144204-15-063858:8k_2_02:21]
Operating income for the three months ended September 30, 2015
increased 32% to $324,000 as compared to $246,000 for the same quarter a year ago. Adjusted EBITDA* for the three months ended
September 30, 2015 decreased 5% to $700,000 or $0.04 per diluted share as compared to $736,000 or $0.04 per diluted share for the
same quarter last year. (*see table attached).

[0001144204-15-063858:8k_2_02:22]
Net income for the three months ended September 30, 2015 increased
98%, to $315,000 or $0.02 per share as compared to $159,000 or $0.01 per share for the same quarter last year.

[0001144204-15-063858:8k_2_02:23]
Balance Sheet Summary

[0001144204-15-063858:8k_2_02:24]
At September 30, 2015, the Company had $2.8 million in cash
and cash equivalents an increase of $0.5 million compared to $2.3 million at June 30, 2015. NAPCO had working capital of $34.2
million as compared with working capital of $35.6 million at June 30, 2015. Current ratio was 4.8:1 at September 30, 2015 and at
June 30, 2015. Debt, net of cash, was $6.5 million at September 30, 2015 and $8.4 at June 30, 2015.

[0001144204-15-063858:8k_2_02:25]
NAPCO Security Technologies, Inc. Annual Meeting of Stockholders

[0001144204-15-063858:8k_2_02:26]
NAPCO Security Technologies, Inc. annual meeting is set for
December 9, 2015, for shareholders of record as of November 5, 2015.

[0001144204-15-063858:8k_2_02:27]
Conference Call Information

[0001144204-15-063858:8k_2_02:28]
Management will conduct a conference call at 11 a.m. today,
November 9, 2015. Interested parties may participate in the call by dialing 1-877-407-4018 or for international callers, 1-201-689-8471,
about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m.
ET on November 9, 2015 and ending on November 16, 2015 at 11:59 p.m. ET. For the replay, please dial 1-877-870-5176 domestically,
or 1-858-384-5517 for international callers, and use the replay access code 13624340. In addition, the call will be webcast and
will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=116048.

[0001144204-15-063858:8k_2_02:29]
About NAPCO Security Technologies, Inc.

[0001144204-15-063858:8k_2_02:30]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security, including recurring revenue, connected home, video,
fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO,
its security and connected home segment, plus three wholly-owned subsidiaries: Alarm
Lock, Continental Instruments, and Marks USA.
Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in
commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for innovation,
technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic
security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-15-063858:8k_2_02:31]
Safe Harbor Statement

[0001144204-15-063858:8k_2_02:32]
This press release contains forward-looking statements that
involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated
in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the
Securities and Exchange Commission.

[0001144204-15-063858:8k_2_02:33]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
|  |  | September 30, 2015 |  |  | June 30, 2015 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,806 |  |  | $ | 2,346 |  |
| Accounts receivable, net of reserves and allowances |  |  | 15,269 |  |  |  | 17,994 |  |
| Inventories |  |  | 23,168 |  |  |  | 22,757 |  |
| Prepaid expenses and other current assets |  |  | 957 |  |  |  | 1,046 |  |
| Income tax receivable |  |  | 24 |  |  |  | -- |  |
| Deferred income taxes |  |  | 900 |  |  |  | 880 |  |
| Total Current Assets |  |  | 43,124 |  |  |  | 45,023 |  |
| Inventories - non-current |  |  | 4,612 |  |  |  | 4,113 |  |
| Deferred income taxes |  |  | 625 |  |  |  | 634 |  |
| Property, plant and equipment, net |  |  | 6,162 |  |  |  | 6,234 |  |
| Intangible assets, net |  |  | 8,749 |  |  |  | 8,886 |  |
| Other assets |  |  | 144 |  |  |  | 147 |  |
| TOTAL ASSETS |  | $ | 63,416 |  |  | $ | 65,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,468 |  |  |  | 3,954 |  |
| Accrued expenses |  |  | 1,528 |  |  |  | 1,624 |  |
| Accrued salaries and wages |  |  | 2,363 |  |  |  | 2,250 |  |
| Accrued income taxes |  |  | -- |  |  |  | 5 |  |
| Total Current Liabilities |  |  | 8,959 |  |  |  | 9,433 |  |
| Long-term debt, net of current maturities |  |  | 7,700 |  |  |  | 9,100 |  |
| Total Liabilities |  |  | 16,659 |  |  |  | 18,533 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 21,049,243 shares issued; and 18,949,936 and 18,966,028 shares outstanding, respectively |  |  | 210 |  |  |  | 210 |  |
| Additional paid-in capital |  |  | 16,165 |  |  |  | 16,133 |  |
| Retained earnings |  |  | 40,714 |  |  |  | 40,399 |  |
|  |  |  | 56,089 |  |  |  | 56,742 |  |
| Less: Treasury Stock, at cost (2,099,307 and 2,083,215 shares, respectively) |  |  | (10,332 | ) |  |  | (10,238 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 46,757 |  |  |  | 46,504 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 63,416 |  |  | $ | 65,037 |  |

[0001144204-15-063858:8k_2_02:34]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME (unaudited) |
|  |  | Three months ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 18,149 |  |  | $ | 17,336 |  |
| Cost of sales |  |  | 12,512 |  |  |  | 12,081 |  |
| Gross Profit |  |  | 5,637 |  |  |  | 5,255 |  |
| Selling, general, and administrative expenses |  |  | 5,313 |  |  |  | 5,009 |  |
| Operating Income |  |  | 324 |  |  |  | 246 |  |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 49 |  |  |  | 55 |  |
| Other, net |  |  | 4 |  |  |  | (5 | ) |
| Income before (Benefit) Provision for Income Taxes |  |  | 271 |  |  |  | 196 |  |
| (Benefit) Provision for Income Taxes |  |  | (44 | ) |  |  | 37 |  |
| Net Income |  | $ | 315 |  |  | $ | 159 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.02 |  |  | $ | 0.01 |  |
| Diluted |  | $ | 0.02 |  |  | $ | 0.01 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,965,000 |  |  |  | 19,412,000 |  |
| Diluted |  |  | 18,986,000 |  |  |  | 19,412,000 |  |

[0001144204-15-063858:8k_2_02:35]
| NAPCO SECURITY TECHNOLOGIES, INC. |
| NON-GAAP MEASURES OF PERFORMANCE* (Unaudited) |
| (in thousands) |
|  |  | Three months ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net income (GAAP) |  | $ | 315 |  |  | $ | 159 |  |
| Add back (Benefit) Provision for Income Taxes |  |  | (44 | ) |  |  | 37 |  |
| Add back interest and other expense |  |  | 53 |  |  |  | 124 |  |
| Operating Income (GAAP) |  |  | 324 |  |  |  | 320 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 137 |  |  |  | 196 |  |
| Add back stock-based compensation expense |  |  | 32 |  |  |  | 1 |  |
| Adjusted non-GAAP operating income |  |  | 493 |  |  |  | 517 |  |
| Add back depreciation and other amortization |  |  | 207 |  |  |  | 219 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 700 |  |  | $ | 736 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.04 |  |  | $ | 0.04 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,986,000 |  |  |  | 19,412,000 |  |

[0001144204-15-063858:8k_2_02:36]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-15-063858:8k_2_02:37]
Contacts:

[0001144204-15-063858:8k_2_02:38]
Investor Relations

[0001144204-15-063858:8k_2_02:39]
KCSA Strategic Communications

[0001144204-15-063858:8k_2_02:40]
Todd Fromer / Phil Carlson

[0001144204-15-063858:8k_2_02:41]
212-896-1215 / 1233

[0001144204-15-063858:8k_2_02:42]
napco@kcsa.com
