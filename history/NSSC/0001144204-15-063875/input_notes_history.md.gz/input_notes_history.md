# NSSC note change history — 0001144204-15-029330 → 0001144204-15-063875


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001144204-15-063875:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended September 30, 2015 and 2014, respectively.
  (was, 2015-05-11, similarity 0.7866):
[0001144204-15-029330:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended March 31, 2015 and 2014, respectively and $23,000 and $25,000 for the nine months ended March 31, 2015 and 2014, respectively.

- changed (2015-11-09):
[0001144204-15-063875:note_history:2]
As of September 30, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October  2016 and provides for an annual salary of $306,000, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.
  (was, 2015-05-11, similarity 0.9946):
[0001144204-15-029330:note_history:2]
As of March 31, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001144204-15-063875:note_history:3]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.
  (was, 2015-05-11, similarity 0.998):
[0001144204-15-029330:note_history:3]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

- added (2015-11-09):
[0001144204-15-063875:note_history:4]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2015 in the amount of $9,300,000 approximates fair value.

- added (2015-11-09):
[0001144204-15-063875:note_history:5]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

- changed (2015-11-09):
[0001144204-15-063875:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $100,000 and $175,000 and for returns and other allowances of $930,000 and $1,260,000 as of September 30, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2015-05-11, similarity 0.9872):
[0001144204-15-029330:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $175,000 and $180,000 and for returns and other allowances of $1,010,000 and $1,005,000 as of March 31, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- added (2015-11-09):
[0001144204-15-063875:note_history:7]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,951) |  | $ | 2,849 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,291) |  | $ | 8,749 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

- changed (2015-11-09):
[0001144204-15-063875:note_history:8]
Amortization expense for intangible assets subject to amortization was approximately $137,000 and $166,000 for the three months ended September 30, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.9 years and  13.7 years at September 30, 2015 and 2014, respectively.
  (was, 2015-05-11, similarity 0.817):
[0001144204-15-029330:note_history:8]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended March 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $500,000 and $586,000 for the nine months ended March 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.3 years and  14.1 years at March 31, 2015 and 2014, respectively.

- changed (2015-11-09):
[0001144204-15-063875:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
  (was, 2015-05-11, similarity 0.8955):
[0001144204-15-029330:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

- changed (2015-11-09):
[0001144204-15-063875:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the each of the three months ended September 30, 2015 and 2014, respectively.
  (was, 2015-05-11, similarity 0.8425):
[0001144204-15-029330:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% for the each of the three months ended March 31, 2015 and 2014. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2015 and 2014, respectively.

- changed (2015-11-09):
[0001144204-15-063875:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2015 and 2014 was $558,000 and $544,000, respectively.
  (was, 2015-05-11, similarity 0.6457):
[0001144204-15-029330:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2015 and 2014 was $172,000 and $189,000, respectively. Advertising expense for the nine months ended March 31, 2015 and 2014 was $1,028,000 and $801,000, respectively. The increase in Advertising and promotional costs for the nine months was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

- changed (2015-11-09):
[0001144204-15-063875:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2015 and 2014 was $1,489,000 and $1,311,000, respectively.
  (was, 2015-05-11, similarity 0.8113):
[0001144204-15-029330:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2015 and 2014 was $1,350,000 and $1,275,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2015 and 2014 was  3,995,000 and $3,813,000, respectively.

- changed (2015-11-09):
[0001144204-15-063875:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):
  (was, 2015-05-11, similarity 0.9709):
[0001144204-15-029330:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

- changed (2015-11-09):
[0001144204-15-063875:note_history:14]
|  |  | Net Income | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 | 2015 | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 315 |  | $ | 159 |  |  | 18,965 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 21 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 315 |  | $ | 159 |  |  | 18,986 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |
  (was, 2015-05-11, similarity 0.9875):
[0001144204-15-029330:note_history:14]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 395 |  | $ | 650 |  |  | 19,066 |  |  | 19,416 |  | $ | 0.02 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 7 |  |  | 55 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 395 |  | $ | 650 |  |  | 19,073 |  |  | 19,471 |  | $ | 0.02 |  | $ | 0.03 |  |

- changed (2015-11-09):
[0001144204-15-063875:note_history:15]
Options to purchase  170,000 and  145,500 shares of common stock for the three months ended September 30, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2015-05-11, similarity 0.9754):
[0001144204-15-029330:note_history:15]
Options to purchase  262,000 and  37,500 shares of common stock for the three months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2015-11-09):
[0001144204-15-063875:note_history:16]
Stock-based compensation costs of $32,000 and $33,000 were recognized for three months ended September 30, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2015 and 2014.
  (was, 2015-05-11, similarity 0.6549):
[0001144204-15-029330:note_history:16]
Stock-based compensation costs of $0 and $10,000 were recognized for three months ended March 31, 2015 and 2014, respectively. Stock-based compensation costs of $101,000 and $17,000 were recognized for nine months ended March 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2015 and 2014.

- changed (2015-11-09):
[0001144204-15-063875:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2015 and 2014.
  (was, 2015-05-11, similarity 0.9437):
[0001144204-15-029330:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or nine months ended March 31, 2015 and 2014.

- added (2015-11-09):
[0001144204-15-063875:note_history:18]
For the three months ended September 30, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2015-11-09):
[0001144204-15-063875:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($131,000 and $127,000 in the three months ended September 30, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($216,000 and $241,000 in the three months ended September 30, 2015 and 2014, respectively).
  (was, 2015-05-11, similarity 0.7757):
[0001144204-15-029330:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($117,000 and $131,000 in the three months ended March 31, 2015 and 2014, respectively, and $374,000 and $383,000 in the nine months ended March 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($211,000 and $241,000 in the three months ended March 31, 2015 and 2014, respectively, and $692,000 and $704,000 in the nine months ended March 31, 2015 and 2014, respectively).

- added (2015-11-09):
[0001144204-15-063875:note_history:20]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

- added (2015-11-09):
[0001144204-15-063875:note_history:21]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.

- removed (2015-11-09):
[0001144204-15-029330:note_history:22]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were - Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2015 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2015 in the amount of $10,600,000 approximates fair value.

- removed (2015-11-09):
[0001144204-15-029330:note_history:23]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2015 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2015 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

- removed (2015-11-09):
[0001144204-15-029330:note_history:24]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,666) |  | $ | 3,134 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (322) |  |  | 18 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,988) |  | $ | 9,052 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |

- removed (2015-11-09):
[0001144204-15-029330:note_history:25]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

- removed (2015-11-09):
[0001144204-15-029330:note_history:26]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,225 |  |  | 19,382 |  | $ | 0.08 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 4 |  |  | 37 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,229 |  |  | 19,419 |  | $ | 0.08 |  | $ | 0.06 |  |

- removed (2015-11-09):
[0001144204-15-029330:note_history:27]
Options to purchase  258,583 and  145,673 shares of common stock for the nine months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- removed (2015-11-09):
[0001144204-15-029330:note_history:28]
For the three and nine months ended March 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- removed (2015-11-09):
[0001144204-15-029330:note_history:29]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers (Topic 606),” which is the new comprehensive revenue recognition standard that will supersede all existing revenue recognition guidance under U.S. GAAP. The standard’s core principle is that a company will recognize revenue when it transfers promised goods or services to a customer in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services. ASU 2014-09 is effective for annual and interim periods beginning on or after December 15, 2016, and early adoption is not permitted. Entities will have the option of using either a full retrospective approach or a modified approach to adopt the guidance. The Company is currently evaluating the impact of adopting this guidance.

- removed (2015-11-09):
[0001144204-15-029330:note_history:30]
In July 2013, the FASB issued authoritative guidance that requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a net operating loss (“NOL”) carry-forward, a similar tax loss, or a tax credit carry-forward.  If either (i) an NOL carry-forward, a similar tax loss, or tax credit carry-forward is not available as of the reporting date under the governing tax law to settle taxes that would result from the disallowance of the tax position or (ii) the entity does not intend to use the deferred tax asset for this purpose (provided that the tax law permits a choice), an entity should present an unrecognized tax benefit in the financial statements as a liability and should not net the unrecognized tax benefit with a deferred tax asset.  This guidance became effective for unrecognized tax benefits that exist as of the Company’s fiscal 2015 first quarter.  The guidance did not have an impact on the Company’s consolidated financial statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001144204-15-063875:note_history:31]
As of September 30, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.
  (was, 2015-05-11, similarity 0.9865):
[0001144204-15-029330:note_history:31]
As of March 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

- changed (2015-11-09):
[0001144204-15-063875:note_history:32]
Outstanding balances and interest rates as of September 30, 2015 and June 30, 2015 are as follows:
  (was, 2015-05-11, similarity 0.9419):
[0001144204-15-029330:note_history:32]
Outstanding balances and interest rates as of March 31, 2015 and June 30, 2014 are as follows:

- changed (2015-11-09):
[0001144204-15-063875:note_history:33]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 7,300 |  |  | 1.7 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 9,300 |  |  | 1.7 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2015-05-11, similarity 0.9792):
[0001144204-15-029330:note_history:33]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,100 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 10,600 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001144204-15-063875:note_history:34]
Outstanding balances and interest rates as of September 30, 2015 and June 30, 2015 are as follows:
  (was, 2015-05-11, similarity 0.9419):
[0001144204-15-029330:note_history:34]
Outstanding balances and interest rates as of March 31, 2015 and June 30, 2014 are as follows:

- changed (2015-11-09):
[0001144204-15-063875:note_history:35]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 7,300 |  |  | 1.7 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 9,300 |  |  | 1.7 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2015-05-11, similarity 0.9792):
[0001144204-15-029330:note_history:35]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,100 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 10,600 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-11-09):
[0001144204-15-063875:note_history:36]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
  (was, 2015-05-11, similarity 0.8955):
[0001144204-15-029330:note_history:36]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
