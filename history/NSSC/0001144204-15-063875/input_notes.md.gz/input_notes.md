# NSSC notes — 0001144204-15-063875


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-15-063875:notes:1]
[same as prior period, unchanged from 0001144204-15-029330:notes:105]

[0001144204-15-063875:notes:2]
[same as prior period, unchanged from 0001144204-15-029330:notes:106]

[0001144204-15-063875:notes:3]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-15-063875:notes:4]
[same as prior period, unchanged from 0001144204-15-029330:notes:108]

[0001144204-15-063875:notes:5]
[same as prior period, unchanged from 0001144204-15-029330:notes:109]

[0001144204-15-063875:notes:6]
Basis of Presentation

[0001144204-15-063875:notes:7]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2015 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 10, 2015. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated.

[0001144204-15-063875:notes:8]
[same as prior period, unchanged from 0001144204-15-029330:notes:110]

[0001144204-15-063875:notes:9]
[same as prior period, unchanged from 0001144204-15-029330:notes:111]

[0001144204-15-063875:notes:10]
[same as prior period, unchanged from 0001144204-15-029330:notes:112]

[0001144204-15-063875:notes:11]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2015 in the amount of $9,300,000 approximates fair value.

[0001144204-15-063875:notes:12]
Cash and Cash Equivalents

[0001144204-15-063875:notes:13]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

[0001144204-15-063875:notes:14]
Accounts receivable is stated net of the reserves for doubtful accounts of $100,000 and $175,000 and for returns and other allowances of $930,000 and $1,260,000 as of September 30, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

[0001144204-15-063875:notes:15]
Inventories

[0001144204-15-063875:notes:16]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-15-063875:notes:17]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.

[0001144204-15-063875:notes:18]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001144204-15-063875:notes:19]
Property, Plant, and Equipment

[0001144204-15-063875:notes:20]
Property, plant, and equipment are carried at cost less accumulated depreciation. Expenditures for maintenance and repairs are charged to expense as incurred; costs of major renewals and improvements are capitalized. At the time property and equipment are retired or otherwise disposed of, the cost and accumulated depreciation are eliminated from the asset and accumulated depreciation accounts and the profit or loss on such disposition is reflected in income.

[0001144204-15-063875:notes:21]
Depreciation is recorded over the estimated service lives of the related assets using primarily the straight-line method. Amortization of leasehold improvements is calculated by using the straight-line method over the estimated useful life of the asset or lease term, whichever is shorter.

[0001144204-15-063875:notes:22]
[same as prior period, unchanged from 0001144204-15-029330:notes:114]

[0001144204-15-063875:notes:23]
[same as prior period, unchanged from 0001144204-15-029330:notes:115]

[0001144204-15-063875:notes:24]
[same as prior period, unchanged from 0001144204-15-029330:notes:116]

[0001144204-15-063875:notes:25]
Changes in intangible assets are as follows (in thousands):

[0001144204-15-063875:notes:26]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,951) |  | $ | 2,849 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,291) |  | $ | 8,749 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

[0001144204-15-063875:notes:27]
Amortization expense for intangible assets subject to amortization was approximately $137,000 and $166,000 for the three months ended September 30, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.9 years and  13.7 years at September 30, 2015 and 2014, respectively.

[0001144204-15-063875:notes:28]
Long-Lived Assets

[0001144204-15-063875:notes:29]
Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets in question may not be recoverable. Impairment would be recorded in circumstances where undiscounted cash flows expected to be generated by an asset are less than the carrying value of that asset.

[0001144204-15-063875:notes:30]
Revenue Recognition

[0001144204-15-063875:notes:31]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001144204-15-063875:notes:32]
[same as prior period, unchanged from 0001144204-15-029330:notes:118]

[0001144204-15-063875:notes:33]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the each of the three months ended September 30, 2015 and 2014, respectively.

[0001144204-15-063875:notes:34]
[same as prior period, unchanged from 0001144204-15-029330:notes:120]

[0001144204-15-063875:notes:35]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2015 and 2014 was $558,000 and $544,000, respectively.

[0001144204-15-063875:notes:36]
[same as prior period, unchanged from 0001144204-15-029330:notes:122]

[0001144204-15-063875:notes:37]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2015 and 2014 was $1,489,000 and $1,311,000, respectively.

[0001144204-15-063875:notes:38]
Income Taxes

[0001144204-15-063875:notes:39]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. The components of the deferred tax assets and liabilities are individually classified as current and non-current based on their characteristics. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.

[0001144204-15-063875:notes:40]
Net Income Per Share

[0001144204-15-063875:notes:41]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.

[0001144204-15-063875:notes:42]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

[0001144204-15-063875:notes:43]
|  |  | Net Income | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 | 2015 | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 315 |  | $ | 159 |  |  | 18,965 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 21 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 315 |  | $ | 159 |  |  | 18,986 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |

[0001144204-15-063875:notes:44]
Options to purchase  170,000 and  145,500 shares of common stock for the three months ended September 30, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-15-063875:notes:45]
[same as prior period, unchanged from 0001144204-15-029330:notes:124]

[0001144204-15-063875:notes:46]
[same as prior period, unchanged from 0001144204-15-029330:notes:125]

[0001144204-15-063875:notes:47]
[same as prior period, unchanged from 0001144204-15-029330:notes:126]

[0001144204-15-063875:notes:48]
Stock-based compensation costs of $32,000 and $33,000 were recognized for three months ended September 30, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2015 and 2014.

[0001144204-15-063875:notes:49]
Foreign Currency

[0001144204-15-063875:notes:50]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2015 and 2014.

[0001144204-15-063875:notes:51]
Comprehensive Income

[0001144204-15-063875:notes:52]
For the three months ended September 30, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

[0001144204-15-063875:notes:53]
Segment Reporting

[0001144204-15-063875:notes:54]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11, and no additional segment data has been presented.

[0001144204-15-063875:notes:55]
Shipping and Handling Revenues and Costs

[0001144204-15-063875:notes:56]
The Company records the amount billed to customers for shipping and handling in net sales ($131,000 and $127,000 in the three months ended September 30, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($216,000 and $241,000 in the three months ended September 30, 2015 and 2014, respectively).

[0001144204-15-063875:notes:57]
Recently Issued Accounting Standards

[0001144204-15-063875:notes:58]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-15-063875:notes:59]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-15-063875:notes:60]
[same as prior period, unchanged from 0001144204-15-029330:notes:128]

[0001144204-15-063875:notes:61]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  18% of the Company’s accounts receivable at September 30, 2015 and  22% of the Company’s accounts receivable at June 30, 2015. Sales to any one customer did not exceed  10% of net sales in the three months ended September 30, 2015 or 2014.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-15-063875:notes:62]
[same as prior period, unchanged from 0001144204-15-029330:notes:130]

[0001144204-15-063875:notes:63]
[same as prior period, unchanged from 0001144204-15-029330:notes:131]

[0001144204-15-063875:notes:64]
Inventories, net of reserves consist of the following (in thousands):

[0001144204-15-063875:notes:65]
|  |  | September |  | June 30, |  |
|  |  | 30, 2015 |  | 2015 |  |
| Component parts |  | $ | 15,546 |  | $ | 15,037 |  |
| Work-in-process |  |  | 4,276 |  |  | 4,136 |  |
| Finished product |  |  | 7,958 |  |  | 7,697 |  |
|  |  | $ | 27,780 |  | $ | 26,870 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 23,168 |  | $ | 22,757 |  |
| Non-current |  |  | 4,612 |  |  | 4,113 |  |
|  |  | $ | 27,780 |  | $ | 26,870 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001144204-15-063875:notes:66]
Property, plant and equipment consist of the following (in thousands):

[0001144204-15-063875:notes:67]
|  |  | September |  | June 30, |  |  |  |
|  |  | 30, 2015 |  | 2015 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 7,023 |  |  | 7,002 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,484 |  |  | 2,478 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 20,535 |  |  | 20,429 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 294 |  |  | 294 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 40,151 |  |  | 40,018 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 33,989 |  |  | 33,784 |  |  |  |
|  |  | $ | 6,162 |  | $ | 6,234 |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-15-063875:notes:68]
[same as prior period, unchanged from 0001144204-15-029330:notes:1]

[0001144204-15-063875:notes:69]
Depreciation and amortization expense on property, plant, and equipment was $205,000 and $202,000 for the three months ended September 30, 2015 and 2014, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-15-063875:notes:70]
[same as prior period, unchanged from 0001144204-15-029330:notes:5]

[0001144204-15-063875:notes:71]
The provision for income taxes represents Federal, foreign, and state and local income taxes. The effective rate differs from statutory rates due to the effect of state and local income taxes, tax rates in foreign jurisdictions, tax benefit of R&D credits and certain nondeductible expenses. Our effective tax rate will change from quarter to quarter based on recurring and non-recurring factors including, but not limited to, the geographical mix of earnings, enacted tax legislation, and state and local income taxes. In addition, changes in judgment from the evaluation of new information resulting in the recognition de-recognition or re-measurement of a tax position taken in a prior annual period is recognized separately in the quarter of the change.

[0001144204-15-063875:notes:72]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of September 30, 2015 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2012 and thereafter.

[0001144204-15-063875:notes:73]
The Company has identified its U.S. Federal income tax return and its State return in New York as its major tax jurisdictions.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-15-063875:notes:74]
[same as prior period, unchanged from 0001144204-15-029330:notes:43]

[0001144204-15-063875:notes:75]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the three months ended September 30, 2015 the Company repurchased  16,092 shares of its outstanding common stock for a weighted average price of $5.87 per share. These repurchased shares are included in the Company’s Treasury Stock as of September 30, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-15-063875:notes:76]
[same as prior period, unchanged from 0001144204-15-029330:notes:45]

[0001144204-15-063875:notes:77]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $28,000 and $26,000 for the three months ended September 30, 2015 and 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-15-063875:notes:78]
NOTE 10 - Commitments and Contingencies

[0001144204-15-063875:notes:79]
Leases

[0001144204-15-063875:notes:80]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2016.

[0001144204-15-063875:notes:81]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended September 30, 2015 and 2014, respectively.

[0001144204-15-063875:notes:82]
Land Lease

[0001144204-15-063875:notes:83]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-15-063875:notes:84]
Litigation

[0001144204-15-063875:notes:85]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-15-063875:notes:86]
Employment Agreements

[0001144204-15-063875:notes:87]
As of September 30, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October  2016 and provides for an annual salary of $306,000, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-15-063875:notes:88]
[same as prior period, unchanged from 0001144204-15-029330:notes:57]

[0001144204-15-063875:notes:89]
[same as prior period, unchanged from 0001144204-15-029330:notes:58]

[0001144204-15-063875:notes:90]
[same as prior period, unchanged from 0001144204-15-029330:notes:59]

[0001144204-15-063875:notes:91]
|  |  | Three months ended September 30, |  |
|  |  | 2015 |  | 2014 |  |
|  |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |
| Domestic |  | $ | 17,557 |  | $ | 16,572 |  |
| Foreign |  |  | 592 |  |  | 764 |  |
| Total Net Sales |  | $ | 18,149 |  | $ | 17,336 |  |

[0001144204-15-063875:notes:92]
|  |  | September 30, |  |  |  |
| Identifiable assets: |  | 2015 |  | June 30, 2015 |  |
| United States |  | $ | 49,217 |  | $ | 50,998 |  |
| Dominican Republic (2) |  |  | 14,199 |  |  | 14,039 |  |
| Total Identifiable Assets |  | $ | 63,416 |  | $ | 65,037 |  |

[0001144204-15-063875:notes:93]
[same as prior period, unchanged from 0001144204-15-029330:notes:62]

[0001144204-15-063875:notes:94]
(2) Consists primarily of inventories (September 30, 2015 = $10,735, June 30, 2015 = $10,546) and fixed assets (September 30, 2015 = $3,301, June 30, 2015 = $3,347) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:LongTermDebtTextBlock

[0001144204-15-063875:notes:95]
NOTE 6 - Long-Term Debt

[0001144204-15-063875:notes:96]
As of September 30, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001144204-15-063875:notes:97]
Outstanding balances and interest rates as of September 30, 2015 and June 30, 2015 are as follows:

[0001144204-15-063875:notes:98]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 7,300 |  |  | 1.7 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 9,300 |  |  | 1.7 | % | $ | 10,700 |  |  | 1.7 | % |

[0001144204-15-063875:notes:99]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-15-063875:notes:100]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-15-063875:notes:101]
[same as prior period, unchanged from 0001144204-15-029330:notes:15]

[0001144204-15-063875:notes:102]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended September 30, 2015 and 2014, the Company recorded non-cash compensation expense of $32,000 ($.00 per basic and diluted share) and $33,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-15-063875:notes:103]
[same as prior period, unchanged from 0001144204-15-029330:notes:17]

[0001144204-15-063875:notes:104]
In December 2012, the stockholders approved the 2012 Employee Stock Option Plan (the 2012 Employee Plan). The 2012 Employee Plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  950,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options, which are intended to qualify as incentive stock options (ISOs), to valued employees.  Any plan participant who is granted ISOs and possesses more than 10% of the voting rights of the Company's outstanding common stock must be granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-15-063875:notes:105]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2015,  112,500 stock options were granted,  29,500 stock options were exercisable and  837,500 stock options were available for grant under this plan.

[0001144204-15-063875:notes:106]
[same as prior period, unchanged from 0001144204-15-029330:notes:20]

[0001144204-15-063875:notes:107]
[same as prior period, unchanged from 0001144204-15-029330:notes:21]

[0001144204-15-063875:notes:108]
The following table reflects activity under the 2012 Plan for the three months ended September 30,:

[0001144204-15-063875:notes:109]
|  |  | 2015 |  | 2014 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 112,500 |  | $ | 5.30 |  |  | 78,500 |  | $ | 5.73 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (15,000) |  |  | — |  |  | (10,000) |  |  | 4.88 |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 97,500 |  | $ | 5.46 |  |  | 68,500 |  | $ | 5.86 |  |
| Exercisable, end of period |  |  | 29,500 |  | $ | 5.33 |  |  | 18,700 |  | $ | 5.65 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 69,000 |  |  |  |  | $ | — |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 24,000 |  |  |  |  | $ | — |  |  |  |  |

[0001144204-15-063875:notes:110]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at September 30, 2015:

[0001144204-15-063875:notes:111]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  | Weighted average |  |  |  |  |  |  |
| Range of |  | Number |  | remaining |  | Weighted average |  | Number |  | Weighted average |  |
| exercise prices |  | outstanding |  | contractual life |  | exercise price |  | exercisable |  | exercise price |  |
|  | $4.29-$6.31 |  |  | 97,500 |  |  | 8.4 |  | $ | 5.46 |  |  | 29,500 |  | $ | 5.33 |  |
|  |  |  |  | 97,500 |  |  | 8.4 |  | $ | 5.46 |  |  | 29,500 |  | $ | 5.33 |  |

[0001144204-15-063875:notes:112]
As of September 30, 2015, there was $210,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during the three months ended September 30, 2015. The total fair value of the options vesting during each of the three months ended September 30, 2015 and 2014 under this plan was $16,000.

[0001144204-15-063875:notes:113]
[same as prior period, unchanged from 0001144204-15-029330:notes:27]

[0001144204-15-063875:notes:114]
[same as prior period, unchanged from 0001144204-15-029330:notes:28]

[0001144204-15-063875:notes:115]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2015,  35,000 stock options were granted,  17,000 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-15-063875:notes:116]
The following table reflects activity under the 2012 Non-Employee Plan for the three months ended September 30,:

[0001144204-15-063875:notes:117]
|  |  | 2015 |  | 2014 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 17,000 |  | $ | 4.82 |  |  | 10,000 |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 46,000 |  |  |  |  | $ | — |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 21,000 |  |  |  |  | $ | — |  |  |  |  |

[0001144204-15-063875:notes:118]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at September 30, 2015:

[0001144204-15-063875:notes:119]
|  |  |  | Options outstanding |  | Options exercisable |  |
|  |  |  | Weighted average |  | Weighted |  |  | Weighted |  |
| Range of |  | Number |  | remaining |  | average exercise |  | Number |  | average exercise |  |
| exercise prices |  | outstanding |  | contractual life |  | price |  | exercisable |  | price |  |
|  | $4.37 - $4.88 |  |  | 35,000 |  |  | 8.3 |  | $ | 4.73 |  |  | 17,000 |  | $ | 4.82 |  |
|  |  |  |  | 35,000 |  |  | 8.3 |  | $ | 4.73 |  |  | 17,000 |  | $ | 4.82 |  |

[0001144204-15-063875:notes:120]
As of September 30, 2015, there was $56,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three months ended September 30, 2015. The total fair value of the options vesting during the three months ended September 30, 2015 and 2014 under this plan was $16,500 and $17,000, respectively.

[0001144204-15-063875:notes:121]
[same as prior period, unchanged from 0001144204-15-029330:notes:35]

[0001144204-15-063875:notes:122]
[same as prior period, unchanged from 0001144204-15-029330:notes:36]

[0001144204-15-063875:notes:123]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At September 30, 2015,  1,471,480 stock options had been granted and  264,750 stock options were exercisable. No further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-15-063875:notes:124]
The following table reflects activity under the 2002 Employee plan for the three months ended September 30,:

[0001144204-15-063875:notes:125]
|  |  | 2015 |  | 2014 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 208,500 |  | $ | 6.86 |  |  | 265,750 |  | $ | 6.51 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | (1,000) |  |  | 6.02 |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 208,500 |  | $ | 6.86 |  |  | 264,750 |  | $ | 6.51 |  |
| Exercisable, end of period |  |  | 208,500 |  | $ | 6.86 |  |  | 264,750 |  | $ | 6.51 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 37,000 |  |  |  |  | $ | — |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 37,000 |  |  |  |  | $ | — |  |  |  |  |

[0001144204-15-063875:notes:126]
No stock options were exercised during the three months ended September 30, 2015 and 2014. No cash was received from option exercises during the three months ended September 30, 2015 and 2014 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-15-063875:notes:127]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at September 30, 2015:

[0001144204-15-063875:notes:128]
|  |  |  | Options outstanding and exercisable |  |
| Range of |  | Number |  | Weighted average |  | Weighted average |  |
| exercise prices |  | outstanding |  | remaining contractual life |  | exercise price |  |
| $ | 5.22-$6.62 |  |  | 171,000 |  |  | 0.9 |  | $ | 5.92 |  |
| $ | 11.16 |  |  | 37,500 |  |  | 0.5 |  |  | 11.16 |  |
|  |  |  |  | 208,500 |  |  | 0.8 |  | $ | 6.86 |  |
