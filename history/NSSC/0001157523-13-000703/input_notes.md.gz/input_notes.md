# NSSC notes — 0001157523-13-000703


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001157523-13-000703:notes:1]
[same as prior period, unchanged from 0001157523-12-006021:notes:13]

[0001157523-13-000703:notes:2]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended December 31, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

[0001157523-13-000703:notes:3]
[same as prior period, unchanged from 0001157523-12-006021:notes:15]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-13-000703:notes:4]
[same as prior period, unchanged from 0001157523-12-006021:notes:46]

[0001157523-13-000703:notes:5]
[same as prior period, unchanged from 0001157523-12-006021:notes:47]


## us-gaap:InventoryPolicyTextBlock

[0001157523-13-000703:notes:6]
[same as prior period, unchanged from 0001157523-12-006021:notes:75]

[0001157523-13-000703:notes:7]
[same as prior period, unchanged from 0001157523-12-006021:notes:76]

[0001157523-13-000703:notes:8]
[same as prior period, unchanged from 0001157523-12-006021:notes:77]


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001157523-13-000703:notes:9]
[same as prior period, unchanged from 0001157523-12-006021:notes:16]

[0001157523-13-000703:notes:10]
The
Company’s reportable operating segments are determined based
on the Company's management approach.  The management
approach is based on the way that the chief operating decision
maker organizes the segments within an enterprise for making
operating decisions and assessing performance. The Company's
results of operations are reviewed by the chief operating decision
maker on a consolidated basis and the Company operates in only one
segment.  The Company has presented required geographical
data in Note 12, and no additional segment data has been
presented.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-13-000703:notes:11]
[same as prior period, unchanged from 0001157523-12-006021:notes:82]

[0001157523-13-000703:notes:12]
[same as prior period, unchanged from 0001157523-12-006021:notes:83]

[0001157523-13-000703:notes:13]
[same as prior period, unchanged from 0001157523-12-006021:notes:84]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-13-000703:notes:14]
[same as prior period, unchanged from 0001157523-12-006021:notes:85]

[0001157523-13-000703:notes:15]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at December 31, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of December 31, 2012 and June 30,
2012.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001157523-13-000703:notes:16]
NOTE 5 - Acquisition of Business

[0001157523-13-000703:notes:17]
[same as prior period, unchanged from 0001157523-12-006021:notes:88]


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001157523-13-000703:notes:18]
[same as prior period, unchanged from 0001157523-12-006021:notes:48]

[0001157523-13-000703:notes:19]
|  |  | Three Months ended December 31, |  |  | Six Months ended December 31, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 16,105 |  |  | $ | 16,578 |  |  | $ | 30,370 |  |  | $ | 31,907 |  |
| Foreign |  |  | 1,107 |  |  |  | 1,039 |  |  |  | 2,058 |  |  |  | 1,913 |  |
| Total Net Sales |  | $ | 17,212 |  |  | $ | 17,617 |  |  | $ | 32,428 |  |  | $ | 33,820 |  |
|  |  | As of |  |  |  |  |  |  |  |  |  |
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |  |  |  |  |  |  |  |  |
| Identifiable assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 47,892 |  |  | $ | 50,838 |  |  |  |  |  |  |  |  |  |
| Dominican Republic (2) |  |  | 13,135 |  |  |  | 13,912 |  |  |  |  |  |  |  |  |  |
| Total Identifiable Assets |  | $ | 61,027 |  |  | $ | 64,750 |  |  |  |  |  |  |  |  |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001157523-13-000703:notes:20]
Recently
Issued Accounting Standards

[0001157523-13-000703:notes:21]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

[0001157523-13-000703:notes:22]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-13-000703:notes:23]
[same as prior period, unchanged from 0001157523-12-006021:notes:20]

[0001157523-13-000703:notes:24]
The
Company had one customer with an accounts receivable balance 11% of
the Company’s accounts receivable at December 31, 2012 and
15% at June 30, 2012. Sales to any one customer did not exceed 10%
of net sales in any of the past three fiscal years.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001157523-13-000703:notes:25]
NOTE 9 – Stockholders’ Equity
Transactions

[0001157523-13-000703:notes:26]
During the three and six months
ended December 31, 2012 certain employees exercised incentive stock
options under the Company’s 2002 Plan totaling 702,000 and
729,000 shares, respectively. The exercises were completed as
cashless exercises as allowed for under the 2002 Plan, where the
exercise shares are issued by the Company in exchange for shares of
the Company’s common stock that are owned by the optionees.
The number of shares surrendered by the optionees are based upon
the per share price on the effective date of the option exercise.
In addition, the Company repurchased 128,588 shares of its Common
Stock from its Chief Executive Officer, Richard Soloway. The
purchase price was $3.38 per share, the previous business
day’s closing price on NASDAQ, for an aggregate purchase
price of $434,627. The repurchase was to fund Mr. Soloway’s
tax liability associated with the exercise of 675,000 options
granted to him under the 2002 Plan. The repurchase was approved by
the Board of Directors of the Company, including all of the
independent directors. Mr. Soloway’s exercises resulted in a
tax benefit to the Company of $118,000 which is included in
Additional Paid-in Capital.

[0001157523-13-000703:notes:27]
The
following table reflects the activity of these equity transactions
for the three and six months ended December 31, 2012 (dollars in
thousands):

[0001157523-13-000703:notes:28]
|  |  | Common Stock |  |  |  |  |  | Treasury Stock |  |
|  |  | Number of Shares Issued |  |  | Amount |  |  | Additional Paid-in Capital |  |  | Number of Shares |  |  | Amount |  |
| BALANCE June 30, 2012 |  |  | 20,095,713 |  |  | $ | 201 |  |  | $ | 14,080 |  |  |  | (1,000,000 | ) |  | $ | (5,615 | ) |
| Options exercised |  |  | 27,000 |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Shares surrendered and cancelled under option exercise |  |  | (13,807 | ) |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| BALANCE September 30, 2012 |  |  | 20,108,906 |  |  | $ | 201 |  |  | $ | 14,080 |  |  |  | (1,000,000 | ) |  | $ | (5,615 | ) |
| Options exercised |  |  | 702,000 |  |  |  | 7 |  |  |  | 1,369 |  |  |  | -- |  |  |  | -- |  |
| Shares surrendered and cancelled under option exercise |  |  | (14,093 | ) |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Shares surrendered and held in Treasury under option exercise |  |  | -- |  |  |  | -- |  |  |  |  |  |  |  | (371,890 | ) |  |  | (1,257 | ) |
| Shares repurchased and held in Treasury |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | (128,588 | ) |  |  | (435 | ) |
| BALANCE December 31, 2012 |  |  | 20,796,813 |  |  | $ | 208 |  |  | $ | 15,449 |  |  |  | (1,500,478 | ) |  | $ | (7,307 | ) |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-13-000703:notes:29]
NOTE 10 - 401(k) Plan

[0001157523-13-000703:notes:30]
The
Company maintains two 401(k) plans (“the Napco Plan”
and “the Marks Plan”) that cover all U.S. non-union
employees with one or more years of service and is qualified under
Sections 401(a) and 401(k) of the Internal Revenue Code. Company
contributions to this plan are discretionary and totaled $23,000
and $0 and $44,000 and $0 for the three and six months ended
December 31, 2012 and 2011, respectively. The Marks Plan was
adopted by the Company subsequent to the Marks acquisition in
August 2008 and provides for discretionary matching contributions.
Company contributions to this plan were $1,000 and $0 and $2,000
and $0 for the three and six months ended December 31, 2012 and
2011, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-13-000703:notes:31]
[same as prior period, unchanged from 0001157523-12-006021:notes:22]

[0001157523-13-000703:notes:32]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |  | Useful Life in Years |  |
|  |  | (in thousands) |  |  |  |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |  |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,765 |  |  |  | 6,748 |  |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,324 |  |  |  | 2,317 |  |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,306 |  |  |  | 19,107 |  |  | 7 to 10 |  |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |  |
|  |  |  | 38,582 |  |  |  | 38,359 |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 31,619 |  |  |  | 31,112 |  |  |  |  |
|  |  | $ | 6,963 |  |  | $ | 7,247 |  |  |  |  |


## us-gaap:ScheduleOfEarningsPerShareReconciliationTableTextBlock

[0001157523-13-000703:notes:33]
The
following provides a reconciliation of information used in
calculating the per share amounts (in thousands, except per share
data):

[0001157523-13-000703:notes:34]
|  |  | Three Months Ended December 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,154 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 342 |  |  |  | 160 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,496 |  |  |  | 19,256 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |

[0001157523-13-000703:notes:35]
Options
to purchase 395,750 and 1,250,280 shares of common stock for the
three months ended December 31, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.

[0001157523-13-000703:notes:36]
|  |  | Six Months Ended December 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | (299 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 80 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,176 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-13-000703:notes:37]
[same as prior period, unchanged from 0001157523-12-006021:notes:89]

[0001157523-13-000703:notes:38]
[same as prior period, unchanged from 0001157523-12-006021:notes:90]

[0001157523-13-000703:notes:39]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic door-locking devices, intrusion and fire alarms and
building access control systems. These products are used for
commercial, residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.

[0001157523-13-000703:notes:40]
[same as prior period, unchanged from 0001157523-12-006021:notes:92]

[0001157523-13-000703:notes:41]
Principles
of Consolidation

[0001157523-13-000703:notes:42]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries, including those of Marks USA I, LLC
(“Marks”), a subsidiary which acquired substantially
all of the assets and certain liabilities of G. Marks Hardware Inc.
on August 18, 2008. All inter-company balances and transactions
have been eliminated in consolidation.

[0001157523-13-000703:notes:43]
[same as prior period, unchanged from 0001157523-12-006021:notes:93]

[0001157523-13-000703:notes:44]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, intangible
assets and income taxes.  Actual results could differ
from those estimates.

[0001157523-13-000703:notes:45]
Accounts
Receivable

[0001157523-13-000703:notes:46]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,075,000 and $1,184,000 as of December 31, 2012 and June 30,
2012, respectively.  Our reserves for doubtful accounts
and for returns and other allowances are subjective critical
estimates that have a direct impact on reported net earnings. These
reserves are based upon the evaluation of accounts receivable
agings, specific exposures, sales levels and historical
trends.

[0001157523-13-000703:notes:47]
[same as prior period, unchanged from 0001157523-12-006021:notes:95]

[0001157523-13-000703:notes:48]
[same as prior period, unchanged from 0001157523-12-006021:notes:96]

[0001157523-13-000703:notes:49]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life.

[0001157523-13-000703:notes:50]
Changes
in intangible assets are as follows (in thousands):

[0001157523-13-000703:notes:51]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,035 | ) |  | $ | 4,765 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (213 | ) |  |  | 127 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,248 | ) |  | $ | 10,792 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

[0001157523-13-000703:notes:52]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
December 31, 2012 and 2011, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$459,000 and $533,000 for the six months ended December 31, 2012
and 2011, respectively. Amortization expense for each of the next
five fiscal years is estimated to be as follows: 2013 - $917,000;
2014 - $781,000; 2015 - $667,000; 2016 - $529,000 and 2017 -
$441,000. The weighted average amortization period for intangible
assets was 15.3 years and 15.8 years at December 31, 2012 and
June 30, 2012, respectively.

[0001157523-13-000703:notes:53]
Long-Lived
Assets

[0001157523-13-000703:notes:54]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. Impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.

[0001157523-13-000703:notes:55]
[same as prior period, unchanged from 0001157523-12-006021:notes:99]

[0001157523-13-000703:notes:56]
[same as prior period, unchanged from 0001157523-12-006021:notes:100]

[0001157523-13-000703:notes:57]
[same as prior period, unchanged from 0001157523-12-006021:notes:101]

[0001157523-13-000703:notes:58]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended December 31, 2012 and 2011 was
$294,000 and $232,000, respectively. Advertising expense for the
six months ended December 31, 2012 and 2011 was $721,000 and
$483,000, respectively. The increase for the three months resulted
primarily from increased media advertising during the three months
ended December 31, 2012 as compared to the same period a year ago.
The increase for the six months resulted primarily from increased
expenditures on a major tradeshow and additional media advertising
during the six months ended December 31, 2012 as compared to the
same period a year ago.

[0001157523-13-000703:notes:59]
[same as prior period, unchanged from 0001157523-12-006021:notes:103]

[0001157523-13-000703:notes:60]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended December 31, 2012 and 2011was
$1,319,000 and $1,009,000, respectively. Company-sponsored research
and development expense for the six months ended December 31, 2012
and 2011was $2,655,000 and $2,040,000, respectively. The increases
for the three and six months was due primarily to expenses relating
to development of the Company’s iBridge™ tablet
computer/touch screen keypad.

[0001157523-13-000703:notes:61]
Income
Taxes

[0001157523-13-000703:notes:62]
Deferred
tax assets and liabilities are recognized for the future tax
consequences attributable to temporary differences between the
financial statement carrying amounts of existing assets and
liabilities and their respective tax bases. Deferred tax assets and
liabilities are measured using enacted tax rates expected to apply
to taxable income in the years in which those temporary differences
are expected to be recovered or settled. The effect on deferred tax
assets and liabilities of a change in tax rates is recognized in
income in the period that includes the enactment date. Deferred
income tax expense represents the change during the period in the
deferred tax assets and deferred tax liabilities. The components of
the deferred tax assets and liabilities are individually classified
as current and non-current based on their characteristics. Deferred
tax assets are reduced by a valuation allowance when, in the
opinion of management, it is more likely than not that some portion
or all of the deferred tax assets will not be realized. The Company
measures and recognizes the tax implications of positions taken or
expected to be taken in its tax returns on an ongoing
basis.

[0001157523-13-000703:notes:63]
Income
(Loss) Per Share

[0001157523-13-000703:notes:64]
Basic
net income (loss) per common share (Basic EPS) is computed by
dividing net income (loss) by the weighted average number of common
shares outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

[0001157523-13-000703:notes:65]
Options
to purchase 681,140 and 1,330,210 shares of common stock for the
six months ended December 31, 2012 and 2011, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.

[0001157523-13-000703:notes:66]
[same as prior period, unchanged from 0001157523-12-006021:notes:105]

[0001157523-13-000703:notes:67]
[same as prior period, unchanged from 0001157523-12-006021:notes:106]

[0001157523-13-000703:notes:68]
[same as prior period, unchanged from 0001157523-12-006021:notes:107]

[0001157523-13-000703:notes:69]
Stock-based
compensation costs of $0 and $1,000 were recognized for the three
months ended December 31, 2012 and 2011, respectively. Stock-based
compensation costs of $0 and $7,000 were recognized for the six
months ended December 31, 2012 and 2011, respectively.

[0001157523-13-000703:notes:70]
Foreign
Currency

[0001157523-13-000703:notes:71]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and six months ended December 31, 2012
and 2011.

[0001157523-13-000703:notes:72]
Comprehensive
Income

[0001157523-13-000703:notes:73]
For
the three and six months ended December 31, 2012 and 2011, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

[0001157523-13-000703:notes:74]
Shipping
and Handling Revenues and Costs

[0001157523-13-000703:notes:75]
The
Company records the amount billed to customers in net sales
($128,000 and $139,000 for the three months ended December 31, 2012
and 2011, respectively, and $249,000 and $275,000 for the six
months ended December 31, 2012 and 2011, respectively) and
classifies the costs associated with these revenues in cost of
sales ($259,000 and $293,000 for the three months ended December
31, 2012 and 2011, respectively, and $482,000 and $557,000 for the
six months ended December 31, 2012 and 2011,
respectively).


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-13-000703:notes:76]
[same as prior period, unchanged from 0001157523-12-006021:notes:26]

[0001157523-13-000703:notes:77]
Depreciation
and amortization expense on property, plant, and equipment was
approximately $256,000 and $262,000 for the three months ended
December 31, 2012 and 2011, respectively and $507,000 and $520,000
for the six months ended December 31, 2012 and 2011,
respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-13-000703:notes:78]
[same as prior period, unchanged from 0001157523-12-006021:notes:1]

[0001157523-13-000703:notes:79]
[same as prior period, unchanged from 0001157523-12-006021:notes:2]

[0001157523-13-000703:notes:80]
The
Company does not expect that our unrecognized tax benefits will
significantly change within the next twelve months. We file a
consolidated U.S. income tax return and tax returns in certain
state and local and foreign jurisdictions. As of December 31, 2012
we remain subject to examination in all tax jurisdictions for all
relevant jurisdictional statutes for fiscal years 2008 and
thereafter.

[0001157523-13-000703:notes:81]
The
Company has identified its U.S. Federal income tax return and its
State return in New York as its major tax jurisdictions. During the
six months ended December 31, 2012 there was no change in the
Company’s reserve for uncertain income tax positions. As a
result, as of December 31, 2012 and June 30, 2012 the Company has a
long-term accrued income tax liability of $126,000.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-13-000703:notes:82]
[same as prior period, unchanged from 0001157523-12-006021:notes:7]

[0001157523-13-000703:notes:83]
[same as prior period, unchanged from 0001157523-12-006021:notes:8]

[0001157523-13-000703:notes:84]
[same as prior period, unchanged from 0001157523-12-006021:notes:9]

[0001157523-13-000703:notes:85]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
| Component parts |  | $ | 13,123 |  |  | $ | 13,155 |  |
| Work-in-process |  |  | 3,192 |  |  |  | 3,199 |  |
| Finished product |  |  | 6,911 |  |  |  | 6,928 |  |
|  |  | $ | 23,226 |  |  | $ | 23,282 |  |

[0001157523-13-000703:notes:86]
Classification
of inventories, net of reserves:

[0001157523-13-000703:notes:87]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
| Current |  | $ | 17,909 |  |  | $ | 19,448 |  |
| Non-current |  |  | 5,317 |  |  |  | 3,834 |  |
|  |  | $ | 23,226 |  |  | $ | 23,282 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001157523-13-000703:notes:88]
Outstanding
balances and interest rates as of December 31, 2012 and June 30,
2012 are as follows (dollars in thousands):

[0001157523-13-000703:notes:89]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,700 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 17,200 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-13-000703:notes:90]
NOTE 11 - Commitments and Contingencies

[0001157523-13-000703:notes:91]
Leases

[0001157523-13-000703:notes:92]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $12,000 and $13,000 for each of the three months
ended December 31, 2012 and 2011, respectively and $23,000 and
$26,000 for each of the six months ended December 31, 2012 and
2011, respectively.

[0001157523-13-000703:notes:93]
Land
Lease

[0001157523-13-000703:notes:94]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic at an annual cost of
$288,000, on which the Company's principal production facility is
located.

[0001157523-13-000703:notes:95]
Litigation

[0001157523-13-000703:notes:96]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the settlement of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.

[0001157523-13-000703:notes:97]
Employment
Agreements

[0001157523-13-000703:notes:98]
As
of December 31, 2012, the Company was obligated under two
employment agreements and one severance agreement.  The
employment agreements are with the Company’s Chief Executive
Officer (“the CEO”) and Senior Vice President of Sales
and Marketing (“the SVP”). The employment agreement
with the CEO provides for an annual salary of $587,000, as adjusted
for inflation; incentive compensation as may be approved by the
Board of Directors from time to time and a termination payment in
an amount up to 299% of the average of the prior five calendar
year's compensation, subject to certain limitations, as defined in
the agreement.  The employment agreement renews annually
in August unless either party gives the other notice of non-renewal
at least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-13-000703:notes:99]
[same as prior period, unchanged from 0001157523-12-006021:notes:32]

[0001157523-13-000703:notes:100]
In
December 2012, the stockholders approved the 2012 Employee Stock
Option Plan (the 2012 Plan).  The 2012 Plan authorizes
the granting of awards, the exercise of which would allow up to an
aggregate of 950,000 shares of the Company's common stock to be
acquired by the holders of such awards.  Under the 2012
Plan, the Company may grant stock options, which are intended to
qualify as incentive stock options (ISOs), to valued
employees.  Any plan participant who is granted ISOs and
possesses more than 10% of the voting rights of the Company's
outstanding common stock must be granted an option with a price of
at least 110% of the fair market value on the date of
grant.

[0001157523-13-000703:notes:101]
Under
the 2012 Plan, stock options may be granted to valued employees
with a term of up to 10 years at an exercise price equal to or
greater than the fair market value on the date of grant and are
exercisable in whole or in part at 20% per year beginning on the
date of grant. An option granted under the 2012 Plan shall vest in
full upon a “change in control” as defined in the 2012
Plan. At December 31, 2012, no stock options were granted or
exercisable and 950,000 stock options were available for grant
under this plan.

[0001157523-13-000703:notes:102]
In
December 2012, the stockholders approved the 2012 Non-Employee
Stock Option Plan (the 2012 Non-Employee Plan).  The 2012
Non-Employee Plan authorizes the granting of awards, the exercise
of which would allow up to an aggregate of 50,000 shares of the
Company's common stock to be acquired by the holders of such
awards.  Under the 2012 Non-Employee Plan, the Company
may grant stock options to non-employee directors and consultants
to the Company and its subsidiaries.

[0001157523-13-000703:notes:103]
Under
the 2012 Non-Employee Plan, stock options may be granted with a
term of up to 10 years at an exercise price equal to or greater
than the fair market value on the date of grant and are exercisable
in whole or in part at 20% per year beginning on the date of grant.
An option granted under the 2012 Non-Employee Plan shall vest in
full upon a “change in control” as defined in the 2012
Non-Employee Plan. At December 31, 2012, no stock options were
granted or exercisable and 50,000 stock options were available for
grant under this plan.

[0001157523-13-000703:notes:104]
In
December 2002, the stockholders approved the 2002 Employee Stock
Option Plan (the 2002 Plan).  The 2002 Plan expired in
October 2012. The 2002 Plan authorized the granting of awards, the
exercise of which would allow up to an aggregate of 1,836,000
shares of the Company's common stock to be acquired by the holders
of such awards.  Under the 2002 Plan, the Company may
have granted stock options, which were intended to qualify as
incentive stock options (ISOs), to key employees.  Any
plan participant who was granted ISOs and possessed more than 10%
of the voting rights of the Company's outstanding common stock must
have been granted an option with a price of at least 110% of the
fair market value on the date of grant.

[0001157523-13-000703:notes:105]
Under
the 2002 Plan, stock options have been granted to key employees
with a term of 10 years at an exercise price equal to the fair
market value on the date of grant and are exercisable in whole or
in part at 20% per year from the date of grant.  At
December 31, 2012, 1,471,480 stock options were granted, 651,140
stock options were exercisable and no stock options were available
for grant under this plan.

[0001157523-13-000703:notes:106]
No
options were granted under the 2002 Plan during the three or six
months ended December 31, 2012 or 2011.

[0001157523-13-000703:notes:107]
The
following table reflects activity under the 2002 Plan for the six
months ended December 31,

[0001157523-13-000703:notes:108]
|  |  | 2012 |  |  | 2011 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | 729,000 |  |  |  | 1.85 |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Exercisable, end of period |  |  | 651,140 |  |  | $ | 4.18 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 1,301,000 |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 476,000 |  |  |  |  |  |  | $ | 600,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 476,000 |  |  |  |  |  |  | $ | 600,000 |  |  |  |  |  |

[0001157523-13-000703:notes:109]
729,000
options were exercised during the six months ended December 31,
2012 and no options were exercised during the six months ended
December 31, 2011. These exercises were paid for with 399,790
shares of the Company’s common stock, 27,900 of which were
retired upon receipt. Cash  received from option
exercises for each of the six months ended December 31, 2012 and
2011 was $0 and the actual tax benefit realized for the tax
deductions from option exercises totaled $119,000 and $0 for these
periods, respectively.

[0001157523-13-000703:notes:110]
The
following table summarizes information about stock options
outstanding under the 2002 Plan at December 31, 2012:

[0001157523-13-000703:notes:111]
|  |  | Options outstanding |  |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding at December 31, 2012 |  |  | Weighted average remaining contractual life |  |  | Weighted average exercise price |  |  | Number exercisable at December 31, 2012 |  |  | Weighted average exercise price |  |
| $ 1.62 - $ 4.00 |  |  | 285,390 |  |  |  | 1.1 |  |  | $ | 1.97 |  |  |  | 285,390 |  |  | $ | 1.97 |  |
| $ 4.01 - $ 7.50 |  |  | 328,250 |  |  |  | 4.0 |  |  |  | 5.29 |  |  |  | 328,250 |  |  |  | 5.29 |  |
| $ 7.51 - $ 11.16 |  |  | 37,500 |  |  |  | 3.2 |  |  |  | 11.16 |  |  |  | 37,500 |  |  |  | 11.16 |  |
|  |  |  | 651,140 |  |  |  | 2.7 |  |  | $ | 4.18 |  |  |  | 651,140 |  |  | $ | 4.18 |  |

[0001157523-13-000703:notes:112]
As
of December 31, 2012, there was no unearned stock-based
compensation cost related to non-vested share-based compensation
arrangements granted under the 2002 Plan. All options outstanding
under the 2002 Plan were vested as of the beginning of the current
period; therefore, the total fair value of the options vested
during the six months ended December 31, 2012 under the 2002 Plan
was $0.

[0001157523-13-000703:notes:113]
[same as prior period, unchanged from 0001157523-12-006021:notes:42]

[0001157523-13-000703:notes:114]
The
following table reflects activity under the 2000 Plan for the six
months ended December 31,

[0001157523-13-000703:notes:115]
|  |  | 2012 |  |  | 2011 |  |
|  |  | Options |  |  | Weighted average exercise price |  |  | Options |  |  | Weighted average exercise price |  |
| Outstanding, beginning of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |

[0001157523-13-000703:notes:116]
As of December 31, 2012, there was
no unearned stock-based compensation cost related to non-vested
share-based compensation arrangements granted under the 2000 Plan.
All options outstanding under the 2000 Plan were vested as of the
beginning of the current period; therefore, the total fair value of
the options vested during the six months ended December 31, 2012
under the 2000 Plan was $0.


## us-gaap:LongTermDebtTextBlock

[0001157523-13-000703:notes:117]
NOTE 7 - Long-Term Debt

[0001157523-13-000703:notes:118]
As
of December 31, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

[0001157523-13-000703:notes:119]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, N.Y., equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.

[0001157523-13-000703:notes:120]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-13-000703:notes:121]
NOTE 12 - Geographical Data

[0001157523-13-000703:notes:122]
[same as prior period, unchanged from 0001157523-12-006021:notes:112]

[0001157523-13-000703:notes:123]
(1)
All of the Company's sales originate in the United States and are
shipped primarily from the Company's facilities in the United
States. There were no sales into any one foreign country in excess
of 10% of total Net Sales.

[0001157523-13-000703:notes:124]
(2)
Consists primarily of inventories (December 31, 2012 = $9,253,000;
June 30, 2012 = $9,866,000) and fixed assets (December 31, 2012 =
$3,796,000; June 30, 2012 = $3,936,000) located at the Company's
principal manufacturing facility in the Dominican
Republic.
