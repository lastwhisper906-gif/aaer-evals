# NSSC 8-K — 0001157523-12-006019 filed 2012-11-13

## item codes, every 8-K on or before 2013-02-12

- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2013-02-12

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-006019:8k_2_02:1]
EX-99.1
2
a50476425ex99_1.htm
EXHIBIT 99.1

[0001157523-12-006019:8k_2_02:2]
a50476425ex99_1.htm

[0001157523-12-006019:8k_2_02:3]
Exhibit 99.1

[0001157523-12-006019:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001157523-12-006019:8k_2_02:5]
NAPCO Reports Results For Three Months Ended September 30, 2012

[0001157523-12-006019:8k_2_02:6]
-Management to Host Conference Call Today at 11AM-

[0001157523-12-006019:8k_2_02:7]
AMITYVILLE, N.Y., Nov. 12, 2012 -- NAPCO Security Technologies, Inc., (NASDAQ: NSSC), one of the world's leading suppliers of high performance electronic security equipment for over 30 years, today announced financial results for its first fiscal quarter ended September 30, 2012.

[0001157523-12-006019:8k_2_02:8]
Highlights:

[0001157523-12-006019:8k_2_02:9]
| ● | Net sales for the quarter decreased by 6% to $15.2 million from $16.2 million a year ago. However, management expects revenue and profitability in this fiscal year to increase compared to last year due to three main reasons: |

[0001157523-12-006019:8k_2_02:10]
| o | The decrease in revenue this quarter was due to a few customers in a single division rebalancing inventory levels. Management believes this to be temporary, and anticipates improvement before the end of the fiscal year, based on increased sell through and product demand, compared to last year. |

[0001157523-12-006019:8k_2_02:11]
| o | The Marks Division revenue decline last year offset revenue growth in all of NAPCO's other divisions. However Marks sales increased year over year in Q1 and management expects this trend to continue and believes such sales reached a bottom in fiscal 2012. |

[0001157523-12-006019:8k_2_02:12]
| o | Sales of NAPCO's high-margin commercial locking division and recurring revenue products continued to grow and increased versus a year ago. |

[0001157523-12-006019:8k_2_02:13]
| ● | Gross margins increased to 27.2% compared to 25.6%, on $1 million less in revenue year over year. This is a direct reflection of increased sales from higher margin commercial locking and recurring revenue products. |

[0001157523-12-006019:8k_2_02:14]
| ● | Cash generated by operating activities increased 100% to $1.6 million for the three months ended September 30, 2012, compared to $800,000 for the three months ended September 30, 2011. |

[0001157523-12-006019:8k_2_02:15]
| ● | Debt, net of cash, has been reduced by $20.1 million from $35.9 million to $15.8 million since acquiring Marks in August of 2008. $2.2 million of this reduction occurred in the first quarter. Debt repayment in Q1 increased 144% compared to repayment for the same period in the prior year, which was $900,000. |

[0001157523-12-006019:8k_2_02:16]
| ● | As a result of the lower debt levels and reductions in interest rates, net interest expense for the quarter decreased by $127,000 or 42% to $177,000 as compared to $304,000 for the same period a year ago. |

[0001157523-12-006019:8k_2_02:17]
Richard Soloway, Chairman and President, stated, "In the first quarter of fiscal 2013, NAPCO saw year-over-year increases in demand and sell-through by dealers, but this progress was temporarily masked in our revenue reporting, due to a few customers that lowered inventory levels in Q1. Historically, NAPCO customers that have lowered inventory levels when demand is rising replenish inventories within a few quarters. We expect that to be the case this year. The investments we have made in product development and marketing, coupled with modest improvements in the housing sector have resulted in improvement for our Marks division, and we expect this trend to continue. High-margin commercial lock and recurring revenue product sales increased, bolstering our expectation that we will see sales for this fiscal year improve compared to last year. Our gross margin also improved over last year's first quarter due primarily to this more favorable product mix. As a result, we expect the higher margins to drive improved profitability for this year compared to last year."

[0001157523-12-006019:8k_2_02:18]
Mr. Soloway continued, "NAPCO continues to streamline its balance sheet and strengthen liquidity. While the first quarter is typically our lightest as far as revenues, we reduced the days outstanding in our receivables, continued leveraging our assets in the Dominican Republic, generating $1.6 million in positive cash from operations. We used this cash to continue reductions in our revolving line of credit and term loans, which were reduced by over $2 million this quarter alone."

[0001157523-12-006019:8k_2_02:19]
Mr. Soloway added, "The two major strategic initiatives, of increasing our presence in the high-margin, commercial security sector and the aggressive marketing of an increasing number of SaaS-based, recurring revenue generating product lines, are progressing nicely. The introduction of NAPCO's award-winning Gemini Commercial Fire and Intrusion Systems, Alarm Lock's Networx Wireless Locking System and Continental Access Control's new Fusion 2.9 integration software, provide numerous unique security solutions in the growing, highly profitable commercial environment. Product entries that provide the Company with recurring monthly income such as Starlink 2™ wireless GSM alarm communicator, iSeeVideo™ remote video viewing system and Gemini My Remote Keypad, the product that allows consumers to control their security system from any broadband device, all continue to grow in market penetration. The next major augmentation to our SaaS (Software as a Service)-based suite of revenue generating products, will be that of iBridge™ remote services. Utilizing advanced Z-Wave technology, this product entry will allow consumers to control their thermostats, lighting or home entry locks, from any internet enabled device. Apps are provided free-of-charge, as part of the service, so that consumers can operate all of their services from any iPhone, Blackberry or Droid operating system based smart phone. We expect iBridge to launch before the end of the calendar year, and to further accelerate sales of recurring revenue products like iSee video which interface with iBridge and can be cross sold."

[0001157523-12-006019:8k_2_02:20]
Fiscal First Quarter 2013 Results

[0001157523-12-006019:8k_2_02:21]
Revenue for the for the three months ended September 30, 2012 decreased 6% to $15.2 million, compared to $16.2 million for the same period a year ago. Operating income for the three months ended September 30, 2012 decreased by $257,000 to an operating loss of $(399,000) as compared to a loss of $(142,000) for the same period a year ago. Selling, general and administrative expenses for the quarter increased by $237,000 to $4.5 million as compared to $4.3 million for the same period a year ago. The increase was due primarily to increased tradeshow expenditures and additional sales staff. These investments negatively impacted NAPCO's EBITDA, net and operating income lines in Q1, seasonally the Company's lowest quarter. However, these investments made in Q1, are important to deliver sustained growth in the Marks and high-margin commercial locking divisions. Adjusted EBITDA* for the three months ended September 30, 2012 decreased $319,000, or 79%, to $85,000 as compared to $404,000 for the same period a year ago (*see table attached). Net income for the three months ended September 30, 2012 decreased by $267,000, or 160%, to a loss of $(434,000) or $(0.02) per share as compared to a loss of $(167,000) or $(0.01) per share for the same period a year ago. Net income was impacted by a reduction in the benefit for income taxes of $148,000.

[0001157523-12-006019:8k_2_02:22]
Mr. Soloway concluded, "We are looking forward to another highly productive and successful year in fiscal 2013. Our strong balance sheet and cash flows allow us the flexibility to continue to bring innovative, state-of-the-art security products from concept to market at a rapid pace. As the economy, particularly the construction markets, improve, we feel that NAPCO is poised for exciting times ahead."

[0001157523-12-006019:8k_2_02:23]
Conference Call Information

[0001157523-12-006019:8k_2_02:24]
Management will conduct a conference call at 11 a.m. today, November 12, 2012 to discuss first quarter results. Interested parties may participate in the call by dialing 877-407-8291; international callers dial 201-689-8345 about 5-10 minutes prior to 11 a.m. ET. The conference call will also be available on replay starting at 1 p.m. ET on November 12, 2012 and ending on November 26, 2012. For the replay, please dial 877-660-6853 (replay conference #403083). The access number for the replay for international callers is 201-612-7415 (replay conference #403083).

[0001157523-12-006019:8k_2_02:25]
About NAPCO Security Technologies, Inc.

[0001157523-12-006019:8k_2_02:26]
NAPCO Security Technologies, Inc. is one of the world's leading manufacturers of technologically advanced electronic security equipment including intrusion and fire alarm systems, access control and door locking systems. The Company consists of NAPCO plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. The products are installed by security professionals worldwide in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for technical excellence, reliability and innovation, poising the Company for growth in the rapidly expanding electronic security market, a multi-billion dollar market.

[0001157523-12-006019:8k_2_02:27]
For additional information on NAPCO, please visit the Company's web site at www.napcosecurity.com.

[0001157523-12-006019:8k_2_02:28]
This press release contains forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the Securities and Exchange Commission.

[0001157523-12-006019:8k_2_02:29]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
|  |  | September 30, 2012 |  |  | June 30, 2012 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,327 |  |  | $ | 2,979 |  |
| Accounts receivable, net of reserves and allowances |  |  | 14,549 |  |  |  | 16,408 |  |
| Inventories |  |  | 18,698 |  |  |  | 19,448 |  |
| Prepaid expenses and other current assets |  |  | 989 |  |  |  | 964 |  |
| Income tax receivable |  |  | 137 |  |  |  | -- |  |
| Deferred income taxes |  |  | 657 |  |  |  | 650 |  |
| Total Current Assets |  |  | 37,357 |  |  |  | 40,449 |  |
| Inventories - non-current |  |  | 4,735 |  |  |  | 3,834 |  |
| Deferred income taxes |  |  | 1,718 |  |  |  | 1,762 |  |
| Property, plant and equipment, net |  |  | 7,060 |  |  |  | 7,247 |  |
| Intangible assets, net |  |  | 11,021 |  |  |  | 11,251 |  |
| Other assets |  |  | 227 |  |  |  | 207 |  |
| TOTAL ASSETS |  | $ | 62,118 |  |  | $ | 64,750 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,707 |  |  |  | 3,163 |  |
| Accrued expenses |  |  | 1,345 |  |  |  | 1,814 |  |
| Accrued salaries and wages |  |  | 1,551 |  |  |  | 1,589 |  |
| Accrued income taxes |  |  | -- |  |  |  | 78 |  |
| Total Current Liabilities |  |  | 8,203 |  |  |  | 8,244 |  |
| Long-term debt, net of current maturities |  |  | 16,500 |  |  |  | 18,657 |  |
| Accrued income taxes |  |  | 126 |  |  |  | 126 |  |
| Total Liabilities |  |  | 24,829 |  |  |  | 27,027 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 20,108,906 and 20,095,713 shares issued; and 19,108,906 and 19,095,713 shares outstanding, respectively |  |  | 201 |  |  |  | 201 |  |
| Additional paid-in capital |  |  | 14,080 |  |  |  | 14,080 |  |
| Retained earnings |  |  | 28,623 |  |  |  | 29,057 |  |
|  |  |  | 42,904 |  |  |  | 43,338 |  |
| Less: Treasury Stock, at cost (1,000,000 shares) |  |  | (5,615 | ) |  |  | (5,615 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 37,289 |  |  |  | 37,723 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 62,118 |  |  | $ | 64,750 |  |

[0001157523-12-006019:8k_2_02:30]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited) |  |
|  |  | Three months ended September 30, |
|  |  | 2012 |  | 2011 |
|  |  | (In thousands, except share and per share data) |
| Net sales |  | $ | 15,216 |  |  | $ | 16,203 |  |
| Cost of sales |  |  | 11,080 |  |  |  | 12,047 |  |
| Gross Profit |  |  | 4,136 |  |  |  | 4,156 |  |
| Selling, general, and administrative expenses |  |  | 4,535 |  |  |  | 4,298 |  |
| Operating Loss |  |  | (399 | ) |  |  | (142 | ) |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 177 |  |  |  | 304 |  |
| Other, net |  |  | 3 |  |  |  | 14 |  |
|  |  |  | 180 |  |  |  | 318 |  |
| Loss before Benefit for Income Taxes |  |  | (579 | ) |  |  | (460 | ) |
| Benefit for income taxes |  |  | 145 |  |  |  | 293 |  |
| Net Loss |  | $ | (434 | ) |  | $ | (167 | ) |

[0001157523-12-006019:8k_2_02:31]
Loss per share:

[0001157523-12-006019:8k_2_02:32]
| Basic |  | $ | (0.02 | ) |  | $ | (0.01 | ) |
| Diluted |  | $ | (0.02 | ) |  | $ | (0.01 | ) |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,097,000 |  |  |  | 19,096,000 |  |
| Diluted |  |  | 19,097,000 |  |  |  | 19,096,000 |  |

[0001157523-12-006019:8k_2_02:33]
| NAPCO SECURITY TECHNOLOGIES, INC. |  |
| NON-GAAP MEASURES OF PERFORMANCE* (Unaudited) |  |
| (in thousands) |  |
|  | 3 months ended September 30, |
|  | 2012 | 2011 |
| Net loss (GAAP) | $ | (434 | ) |  |  | $ | (167 | ) |
| Add back benefit for income taxes |  | (145 | ) |  |  |  | (293 | ) |
| Add back interest and other expense |  | 180 |  |  |  |  | 318 |  |
| Operating Loss (GAAP) |  | (399 | ) |  |  |  | (142 | ) |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  | 230 |  |  |  |  | 266 |  |
| Add back stock-based compensation expense |  | - |  |  |  |  | 7 |  |
| Adjusted non-GAAP operating (loss) income |  | (169 | ) |  |  |  | 131 |  |
| Add back depreciation and other amortization |  | 254 |  |  |  |  | 273 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) | $ | 85 |  |  |  | $ | 404 |  |

[0001157523-12-006019:8k_2_02:34]
* Non-GAAP Information. Certain non-GAAP measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not include impairment of goodwill, amortization of intangibles, changes to inventory reserves, restructuring charges, stock-based compensation expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial measures included in the above.

[0001157523-12-006019:8k_2_02:35]
INVESTOR INQUIRIES:

[0001157523-12-006019:8k_2_02:36]
Brett Maas

[0001157523-12-006019:8k_2_02:37]
Hayden IR

[0001157523-12-006019:8k_2_02:38]
(646) 536-7331

[0001157523-12-006019:8k_2_02:39]
brett@haydenir.com

[0001157523-12-006019:8k_2_02:40]
James Carbonara, Regional Vice-President

[0001157523-12-006019:8k_2_02:41]
Hayden IR

[0001157523-12-006019:8k_2_02:42]
(646) 755-7412

[0001157523-12-006019:8k_2_02:43]
james@haydenir.com

[0001157523-12-006019:8k_2_02:44]
Donald Weinberger

[0001157523-12-006019:8k_2_02:45]
Wolfe Axelrod Weinberger Assoc. LLC

[0001157523-12-006019:8k_2_02:46]
(212) 370-4500; (212) 370-4505 fax

[0001157523-12-006019:8k_2_02:47]
don@wolfeaxelrod.com
