# NSSC 10-Q controls and the auditor's report


## item_4_controls

[0001157523-13-000703:item_4_controls:1]
ITEM 4:  Controls and Procedures

[0001157523-13-000703:item_4_controls:2]
We maintain disclosure controls and procedures that are designed to ensure that information required to be disclosed in our Exchange Act reports is recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms, and that such information is accumulated and communicated to our management to allow timely decisions regarding required disclosure.  Management necessarily applied its judgment in assessing the costs and benefits of such controls and procedures, which, by their nature, can provide only reasonable assurance regarding management's control objectives.

[0001157523-13-000703:item_4_controls:3]
At the conclusion of the period ended December 31, 2012, we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures. Based upon that evaluation, the Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective at December 31, 2012.

[0001157523-13-000703:item_4_controls:4]
During the second quarter of fiscal 2013, there were no changes in the Company's internal controls over financial reporting that have materially affected, or are reasonably likely to materially affect, the Company's internal controls over financial reporting.

[0001157523-13-000703:item_4_controls:5]
21
