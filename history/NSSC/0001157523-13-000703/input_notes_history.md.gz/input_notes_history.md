# NSSC note change history — 0001157523-12-006021 → 0001157523-13-000703


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-02-12):
[0001157523-13-000703:note_history:1]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $12,000 and $13,000 for each of the three months
ended December 31, 2012 and 2011, respectively and $23,000 and
$26,000 for each of the six months ended December 31, 2012 and
2011, respectively.
  (was, 2012-11-13, similarity 0.6536):
[0001157523-12-006021:note_history:1]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $13,000 for each of  the three months ended
September 30, 2012  and 2011.

- changed (2013-02-12):
[0001157523-13-000703:note_history:2]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic at an annual cost of
$288,000, on which the Company's principal production facility is
located.
  (was, 2012-11-13, similarity 0.8889):
[0001157523-12-006021:note_history:2]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic, at an annual cost of
approximately $288,000, on which the Company's principal production
facility is located.

- changed (2013-02-12):
[0001157523-13-000703:note_history:3]
As
of December 31, 2012, the Company was obligated under two
employment agreements and one severance agreement.  The
employment agreements are with the Company’s Chief Executive
Officer (“the CEO”) and Senior Vice President of Sales
and Marketing (“the SVP”). The employment agreement
with the CEO provides for an annual salary of $587,000, as adjusted
for inflation; incentive compensation as may be approved by the
Board of Directors from time to time and a termination payment in
an amount up to 299% of the average of the prior five calendar
year's compensation, subject to certain limitations, as defined in
the agreement.  The employment agreement renews annually
in August unless either party gives the other notice of non-renewal
at least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.
  (was, 2012-11-13, similarity 0.6555):
[0001157523-12-006021:note_history:3]
As
of September 30, 2012, the Company was obligated under one
employment agreement and one severance agreement.  The
employment agreement is with the Company’s Chief Executive
Officer. The employment agreement provides for an annual salary of
$587,000 as adjusted for inflation, incentive compensation as may
be approved by the Board of Directors from time to time and a
termination payment in an amount up to 299% of the average of the
prior five calendar year's compensation, subject to certain
limitations, as defined in the agreement.  The employment
agreement renews annually in August unless either party gives the
other notice of non-renewal at least six months prior to the end of
the applicable term.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-02-12):
[0001157523-13-000703:note_history:4]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic door-locking devices, intrusion and fire alarms and
building access control systems. These products are used for
commercial, residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.
  (was, 2012-11-13, similarity 0.9944):
[0001157523-12-006021:note_history:4]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic locking devices, intrusion and fire alarms and building
access control systems. These products are used for commercial,
residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.

- changed (2013-02-12):
[0001157523-13-000703:note_history:5]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended December 31, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.
  (was, 2012-11-13, similarity 0.991):
[0001157523-12-006021:note_history:5]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended September 30, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

- changed (2013-02-12):
[0001157523-13-000703:note_history:6]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, intangible
assets and income taxes.  Actual results could differ
from those estimates.
  (was, 2012-11-13, similarity 0.986):
[0001157523-12-006021:note_history:6]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, goodwill and
other intangible assets and income taxes.  Actual results
could differ from those estimates.

- changed (2013-02-12):
[0001157523-13-000703:note_history:7]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at December 31, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of December 31, 2012 and June 30,
2012.
  (was, 2012-11-13, similarity 0.982):
[0001157523-12-006021:note_history:7]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at September 30, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of September 30, 2012 and June 30,
2012.

- changed (2013-02-12):
[0001157523-13-000703:note_history:8]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,075,000 and $1,184,000 as of December 31, 2012 and June 30,
2012, respectively.  Our reserves for doubtful accounts
and for returns and other allowances are subjective critical
estimates that have a direct impact on reported net earnings. These
reserves are based upon the evaluation of accounts receivable
agings, specific exposures, sales levels and historical
trends.
  (was, 2012-11-13, similarity 0.8972):
[0001157523-12-006021:note_history:8]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$200,000 and for returns and other allowances of $1,010,000 and
$1,184,000 as of September 30, 2012 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.

- changed (2013-02-12):
[0001157523-13-000703:note_history:9]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life.
  (was, 2012-11-13, similarity 0.6684):
[0001157523-12-006021:note_history:9]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life. At the conclusion of the quarter ended June 30,
2011, the Company performed its annual impairment evaluation and
determined that its intangible asset relating to its Marks trade
name was partially impaired. Accordingly, in the quarter ended June
30, 2011 the Company recorded an impairment charge of $400,000
which represented the excess book value of this intangible asset
over its current valuation.

- changed (2013-02-12):
[0001157523-13-000703:note_history:10]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,035 | ) |  | $ | 4,765 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (213 | ) |  |  | 127 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,248 | ) |  | $ | 10,792 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |
  (was, 2012-11-13, similarity 0.8062):
[0001157523-12-006021:note_history:10]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,818 | ) |  | $ | 4,982 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (201 | ) |  |  | 139 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,019 | ) |  | $ | 11,021 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

- added (2013-02-12):
[0001157523-13-000703:note_history:11]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
December 31, 2012 and 2011, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$459,000 and $533,000 for the six months ended December 31, 2012
and 2011, respectively. Amortization expense for each of the next
five fiscal years is estimated to be as follows: 2013 - $917,000;
2014 - $781,000; 2015 - $667,000; 2016 - $529,000 and 2017 -
$441,000. The weighted average amortization period for intangible
assets was 15.3 years and 15.8 years at December 31, 2012 and
June 30, 2012, respectively.

- changed (2013-02-12):
[0001157523-13-000703:note_history:12]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. Impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.
  (was, 2012-11-13, similarity 0.9955):
[0001157523-12-006021:note_history:12]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. An impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.

- added (2013-02-12):
[0001157523-13-000703:note_history:13]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended December 31, 2012 and 2011 was
$294,000 and $232,000, respectively. Advertising expense for the
six months ended December 31, 2012 and 2011 was $721,000 and
$483,000, respectively. The increase for the three months resulted
primarily from increased media advertising during the three months
ended December 31, 2012 as compared to the same period a year ago.
The increase for the six months resulted primarily from increased
expenditures on a major tradeshow and additional media advertising
during the six months ended December 31, 2012 as compared to the
same period a year ago.

- changed (2013-02-12):
[0001157523-13-000703:note_history:14]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended December 31, 2012 and 2011was
$1,319,000 and $1,009,000, respectively. Company-sponsored research
and development expense for the six months ended December 31, 2012
and 2011was $2,655,000 and $2,040,000, respectively. The increases
for the three and six months was due primarily to expenses relating
to development of the Company’s iBridge™ tablet
computer/touch screen keypad.
  (was, 2012-11-13, similarity 0.6229):
[0001157523-12-006021:note_history:14]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended September 30, 2012 and 2011was
$1,336,000 and $1,031,000, respectively. The increase was due
primarily to expenses relating to development of the
Company’s iBridge™ tablet computer/touch screen
keypad.

- changed (2013-02-12):
[0001157523-13-000703:note_history:15]
Income
(Loss) Per Share
  (was, 2012-11-13, similarity 0.6341):
[0001157523-12-006021:note_history:15]
Earnings
Per Share

- added (2013-02-12):
[0001157523-13-000703:note_history:16]
Basic
net income (loss) per common share (Basic EPS) is computed by
dividing net income (loss) by the weighted average number of common
shares outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

- changed (2013-02-12):
[0001157523-13-000703:note_history:17]
|  |  | Three Months Ended December 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,154 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 342 |  |  |  | 160 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 135 |  |  | $ | 309 |  |  |  | 19,496 |  |  |  | 19,256 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
  (was, 2012-11-13, similarity 0.6046):
[0001157523-12-006021:note_history:17]
|  |  | Three Months Ended September 30, |  |  |  |
|  |  | Net Loss |  | Weighted Average Shares |  | Net Loss per Share |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Basic EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |

- changed (2013-02-12):
[0001157523-13-000703:note_history:18]
Options
to purchase 395,750 and 1,250,280 shares of common stock for the
three months ended December 31, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.
  (was, 2012-11-13, similarity 0.9877):
[0001157523-12-006021:note_history:18]
Options
to purchase 1,383,140 and 1,410,140 shares of common stock for the
three months ended September 30, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.

- added (2013-02-12):
[0001157523-13-000703:note_history:19]
|  |  | Six Months Ended December 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Basic EPS |  | $ | (299 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 80 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | 142 |  |  |  | 19,125 |  |  |  | 19,176 |  |  | $ | (0.02 | ) |  | $ | 0.01 |  |

- added (2013-02-12):
[0001157523-13-000703:note_history:20]
Options
to purchase 681,140 and 1,330,210 shares of common stock for the
six months ended December 31, 2012 and 2011, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.

- changed (2013-02-12):
[0001157523-13-000703:note_history:21]
Stock-based
compensation costs of $0 and $1,000 were recognized for the three
months ended December 31, 2012 and 2011, respectively. Stock-based
compensation costs of $0 and $7,000 were recognized for the six
months ended December 31, 2012 and 2011, respectively.
  (was, 2012-11-13, similarity 0.6555):
[0001157523-12-006021:note_history:21]
Stock-based
compensation costs of $0 and $7,000 were recognized for the three
months ended September 30, 2012 and 2011,
respectively.

- changed (2013-02-12):
[0001157523-13-000703:note_history:22]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and six months ended December 31, 2012
and 2011.
  (was, 2012-11-13, similarity 0.9402):
[0001157523-12-006021:note_history:22]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal year-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three months ended September 30, 2012 and
2011.

- added (2013-02-12):
[0001157523-13-000703:note_history:23]
For
the three and six months ended December 31, 2012 and 2011, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

- changed (2013-02-12):
[0001157523-13-000703:note_history:24]
The
Company records the amount billed to customers in net sales
($128,000 and $139,000 for the three months ended December 31, 2012
and 2011, respectively, and $249,000 and $275,000 for the six
months ended December 31, 2012 and 2011, respectively) and
classifies the costs associated with these revenues in cost of
sales ($259,000 and $293,000 for the three months ended December
31, 2012 and 2011, respectively, and $482,000 and $557,000 for the
six months ended December 31, 2012 and 2011,
respectively).
  (was, 2012-11-13, similarity 0.7756):
[0001157523-12-006021:note_history:24]
The
Company records the amount billed to customers in net sales
($121,000 and $136,000 for the three months ended September 30,
2012 and 2011, respectively) and classifies the costs associated
with these revenues in cost of sales ($223,000 and $264,000 for the
three months ended September 30, 2012 and 2011,
respectively).

- removed (2013-02-12):
[0001157523-12-006021:note_history:25]
Amortization
expense for intangible assets subject to amortization was
approximately $230,000 and $266,000 for the three months ended
September 30, 2012 and 2011, respectively. Amortization expense for
each of the next five fiscal years is estimated to be as follows:
2013 - $917,000; 2014 - $781,000; 2015 - $667,000; 2016 - $529,000
and 2017 - $441,000. The weighted average amortization period for
intangible assets was 15.5 years and 15.8 years at September
30, 2012 and June 30, 2012, respectively.

- removed (2013-02-12):
[0001157523-12-006021:note_history:26]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended September 30, 2012 and 2011 was
$427,000 and $251,000, respectively. This increase resulted
primarily from increased expenditures on a major tradeshow and
additional media advertising during the 3 months ended September
30, 2012 as compared to the same period a year ago.

- removed (2013-02-12):
[0001157523-12-006021:note_history:27]
Basic
net income per common share (Basic EPS) is computed by dividing net
income by the weighted average number of common shares
outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

- removed (2013-02-12):
[0001157523-12-006021:note_history:28]
For
the three months ended September 30, 2012 and 2011, the Company's
operations did not give rise to material items includable in
comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-02-12):
[0001157523-13-000703:note_history:29]
As
of December 31, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.
  (was, 2012-11-13, similarity 0.9933):
[0001157523-12-006021:note_history:29]
As
of September 30, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

- changed (2013-02-12):
[0001157523-13-000703:note_history:30]
Outstanding
balances and interest rates as of December 31, 2012 and June 30,
2012 are as follows (dollars in thousands):
  (was, 2012-11-13, similarity 0.9774):
[0001157523-12-006021:note_history:30]
Outstanding
balances and interest rates as of September 30, 2012 and June 30,
2012 are as follows (dollars in thousands):

- changed (2013-02-12):
[0001157523-13-000703:note_history:31]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,700 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 17,200 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
  (was, 2012-11-13, similarity 0.8857):
[0001157523-12-006021:note_history:31]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit |  | $ | 6,000 |  |  |  | 3.1 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 12,100 |  |  |  | 3.1 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 18,100 |  |  |  | 3.1 | % |  | $ | 20,257 |  |  |  | 3.1 | % |

- changed (2013-02-12):
[0001157523-13-000703:note_history:32]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, N.Y., equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.
  (was, 2012-11-13, similarity 0.9988):
[0001157523-12-006021:note_history:32]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, NY, equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-02-12):
[0001157523-13-000703:note_history:33]
Outstanding
balances and interest rates as of December 31, 2012 and June 30,
2012 are as follows (dollars in thousands):
  (was, 2012-11-13, similarity 0.9774):
[0001157523-12-006021:note_history:33]
Outstanding
balances and interest rates as of September 30, 2012 and June 30,
2012 are as follows (dollars in thousands):

- changed (2013-02-12):
[0001157523-13-000703:note_history:34]
|  |  | December 31, 2012 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,700 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 17,200 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
  (was, 2012-11-13, similarity 0.8857):
[0001157523-12-006021:note_history:34]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit |  | $ | 6,000 |  |  |  | 3.1 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 12,100 |  |  |  | 3.1 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 18,100 |  |  |  | 3.1 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
