# NSSC MD&A — 0001157523-13-000703


## mdna

[0001157523-13-000703:mdna:1]
[same as prior period, unchanged from 0001157523-12-006021:mdna:1]

[0001157523-13-000703:mdna:2]
[same as prior period, unchanged from 0001157523-12-006021:mdna:2]

[0001157523-13-000703:mdna:3]
[same as prior period, unchanged from 0001157523-12-006021:mdna:3]

[0001157523-13-000703:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 6% of our revenues for both of the six month periods ended December 31, 2012 and 2011.

[0001157523-13-000703:mdna:5]
[same as prior period, unchanged from 0001157523-12-006021:mdna:5]

[0001157523-13-000703:mdna:6]
[same as prior period, unchanged from 0001157523-12-006021:mdna:6]

[0001157523-13-000703:mdna:7]
[same as prior period, unchanged from 0001157523-12-006021:mdna:7]

[0001157523-13-000703:mdna:8]
[same as prior period, unchanged from 0001157523-12-006021:mdna:8]

[0001157523-13-000703:mdna:9]
[same as prior period, unchanged from 0001157523-12-006021:mdna:9]

[0001157523-13-000703:mdna:10]
[same as prior period, unchanged from 0001157523-12-006021:mdna:10]

[0001157523-13-000703:mdna:11]
[same as prior period, unchanged from 0001157523-12-006021:mdna:11]

[0001157523-13-000703:mdna:12]
The Company's significant accounting policies are fully described in Note 1 to the Company's consolidated financial statements included in its 2012 Annual Report on Form 10-K.  Management believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in the preparation of its consolidated financial statements.

[0001157523-13-000703:mdna:13]
[same as prior period, unchanged from 0001157523-12-006021:mdna:13]

[0001157523-13-000703:mdna:14]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001157523-13-000703:mdna:15]
[same as prior period, unchanged from 0001157523-12-006021:mdna:15]

[0001157523-13-000703:mdna:16]
[same as prior period, unchanged from 0001157523-12-006021:mdna:16]

[0001157523-13-000703:mdna:17]
[same as prior period, unchanged from 0001157523-12-006021:mdna:17]

[0001157523-13-000703:mdna:18]
[same as prior period, unchanged from 0001157523-12-006021:mdna:18]

[0001157523-13-000703:mdna:19]
[same as prior period, unchanged from 0001157523-12-006021:mdna:19]

[0001157523-13-000703:mdna:20]
[same as prior period, unchanged from 0001157523-12-006021:mdna:20]

[0001157523-13-000703:mdna:21]
[same as prior period, unchanged from 0001157523-12-006021:mdna:21]

[0001157523-13-000703:mdna:22]
|  |  | Three months ended December 31, (dollars in thousands) |  |  | Six months ended December 31, (dollars in thousands) |  |
|  |  | 2012 |  |  | 2011 |  |  | % Increase/ (decrease) |  |  | 2012 |  |  | 2011 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 17,212 |  |  | $ | 17,617 |  |  |  | (2.3 | )% |  | $ | 32,428 |  |  | $ | 33,820 |  |  |  | (4.1 | )% |
| Gross profit |  |  | 4,641 |  |  |  | 4,895 |  |  |  | (5.2 | )% |  |  | 8,777 |  |  |  | 9,051 |  |  |  | (3.0 | )% |
| Gross profit as a % of net sales |  |  | 27.0 | % |  |  | 27.8 | % |  |  | (2.9 | )% |  |  | 27.1 | % |  |  | 26.8 | % |  |  | 1.1 | % |
| Selling, general and administrative |  |  | 4,287 |  |  |  | 4,000 |  |  |  | 7.2 | % |  |  | 8,822 |  |  |  | 8,298 |  |  |  | 6.3 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 24.9 | % |  |  | 22.7 | % |  |  | 9.7 | % |  |  | 27.2 | % |  |  | 24.5 | % |  |  | 11.0 | % |
| Operating income (loss) |  |  | 354 |  |  |  | 895 |  |  |  | (60.4 | )% |  |  | (45 | ) |  |  | 753 |  |  |  | (106.0 | )% |
| Interest expense, net |  |  | 141 |  |  |  | 298 |  |  |  | (52.7 | )% |  |  | 318 |  |  |  | 602 |  |  |  | (47.2 | )% |
| Other expense |  |  | 4 |  |  |  | 13 |  |  |  | (69.2 | )% |  |  | 7 |  |  |  | 27 |  |  |  | (74.1 | )% |
| Provision (benefit) for income taxes |  |  | 74 |  |  |  | 275 |  |  |  | (73.1 | )% |  |  | (71 | ) |  |  | (18 | ) |  |  | 294.4 | % |
| Net income (loss) |  |  | 135 |  |  |  | 309 |  |  |  | (56.3 | )% |  |  | (299 | ) |  |  | 142 |  |  |  | (310.6 | )% |

[0001157523-13-000703:mdna:23]
Sales for the three months ended December 31, 2012 decreased by 2% to $17,212,000 as compared to $17,617,000 for the same period a year ago. Sales for the six months ended December 31, 2012 decreased by 4% to $32,428,000 as compared to $33,820,000 for the same period a year ago. The decrease in sales for the three months was primarily due to decreased sales in the Company’s intrusion ($666,000) and access control ($21,000) products as partially offset by an increase in the Company’s door-locking products ($282,000). The decrease in sales for the six months was primarily due to decreased sales in the Company’s intrusion ($1,725,000) and access control ($191,000) products as partially offset by an increase in the Company’s door-locking products ($524,000). The decrease in sales of intrusion products for the three and six months was due primarily to several intrusion customers reducing their inventory levels. Sales were also negatively impacted by the Superstorm Sandy, which devastated portions of the Caribbean and the Mid-Atlantic and Northeastern United States with lesser impacts in the Southeastern and Midwestern states and Eastern Canada.

[0001157523-13-000703:mdna:24]
Gross profit for the three months ended December 31, 2012 decreased to $4,641,000 or 27.0% of sales as compared to $4,895,000 or 27.8% of sales for the same period a year ago. Gross profit for the six months ended December 31, 2012 decreased to $8,777,000 or 27.1% of sales as compared to $9,051,000 or 26.8% of sales for the same period a year ago. The decrease in Gross profit for the three months was primarily due to the decrease in sales as well as increased expenditures on Research and Development primarily relating to the Company’s iBridge tablet-style keypad and related applications. The increases in Research and Development were $310,000 and $615,000 for the three and six months ended December 31, 2012, respectively, as compared to the same periods a year ago. The iBridge products are expected to be released in the spring of 2013.

[0001157523-13-000703:mdna:25]
19

[0001157523-13-000703:mdna:26]
Selling, general and administrative expenses for the three months ended December 31, 2012 increased by $287,000 to $4,287,000, or 24.9% of sales, as compared to $4,000,000, or 22.7% of sales a year ago. Selling, general and administrative expenses for the six months ended December 31, 2012 increased by $524,000 to $8,822,000, or 27.2% of sales, as compared to $8,298,000, or 24.5% of sales a year ago. The increase in Selling, general and administrative expenses for the three and six months was due primarily to additional sales personnel and increased advertising and tradeshow expenditures.

[0001157523-13-000703:mdna:27]
Interest expense, net for the three months ended December 31, 2012 decreased by $157,000 to $141,000 as compared to $298,000 for the same period a year ago. Interest expense, net for the six months ended December 31, 2012 decreased by $284,000 to $318,000 as compared to $602,000 for the same period a year ago. The decrease in interest expense for the three and six months ended December 31, 2012 resulted from lower interest rates charged by the Company’s bank as well as lower outstanding debt in the current period.

[0001157523-13-000703:mdna:28]
The Company’s provision for income taxes for the three months ended December 31, 2012 decreased by $201,000 to $74,000 as compared to $275,000 for the same period a year ago. The Company’s benefit for income taxes for the six months ended December 31, 2012 increased by $53,000 to a benefit of $71,000 as compared to a benefit of $18,000 for the same period a year ago. The change in the provision for income taxes was caused primarily by the changes in consolidated net income as well as the change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations for the three and six months ended December 31, 2012 as compared to the same periods a year ago. As a result, the Company’s effective rate for income tax was 35% and 47% for the three months ended December 31, 2012 and 2011, respectively, and 19% and (15)% for the six months ended December 31, 2012 and 2011, respectively.

[0001157523-13-000703:mdna:29]
Net income decreased by $174,000 to $135,000 or $0.01 per diluted share for the three months ended December 31, 2012 as compared to $309,000 or $0.02 per diluted share for the same period a year ago. Net income decreased by $441,000 to a loss of $(299,000) or $(0.02) per diluted share for the six months ended December 31, 2012 as compared to $142,000 or $0.01 per diluted share for the same period a year ago. The changes for the three and six months ended December 31, 2012 were primarily due to the items as described above.

[0001157523-13-000703:mdna:30]
[same as prior period, unchanged from 0001157523-12-006021:mdna:29]

[0001157523-13-000703:mdna:31]
During the six months ended December 31, 2012 the Company utilized all of its cash from operations ($2,995,000) and a portion of its cash on hand at June 30, 2012 ($721,000 of $2,979,000) to repay outstanding debt ($3,057,000), purchase treasury stock ($435,000) and purchase property, plant and equipment ($224,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-13-000703:mdna:32]
Accounts Receivable at December 31, 2012 decreased $2,520,000 to $13,888,000 as compared to $16,408,000 at June 30, 2012.  This decrease is primarily the result of the lower sales volume during the quarter ended December 31, 2012 as compared to the quarter ended June 30, 2012, which is typically the Company’s highest.

[0001157523-13-000703:mdna:33]
Inventories at December 31, 2012 remained relatively constant at $23,226,000 as compared to $23,282,000 at June 30, 2012.

[0001157523-13-000703:mdna:34]
Accounts payable and accrued expenses remained relatively constant at $6,593,000 as of December 31, 2012 as compared to $6,566,000 at June 30, 2012.

[0001157523-13-000703:mdna:35]
As of December 31, 2012, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. The Company’s long-term debt is described more fully in Note 7 to the condensed consolidated financial statements.

[0001157523-13-000703:mdna:36]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-13-000703:mdna:37]
As of December 31, 2012 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
