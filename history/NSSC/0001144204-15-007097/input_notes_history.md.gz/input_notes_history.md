# NSSC note change history — 0001144204-14-066571 → 0001144204-15-007097


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001144204-15-007097:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $9,000 and $9,000 for the three months ended December 31, 2014 and 2013, respectively and $16,000 and $18,000 for the six months ended December 31, 2014 and 2013, respectively.
  (was, 2014-11-10, similarity 0.8173):
[0001144204-14-066571:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $9,000 for the three months ended September 30, 2014 and 2013, respectively.

- changed (2015-02-09):
[0001144204-15-007097:note_history:2]
As of December 31, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.
  (was, 2014-11-10, similarity 0.9972):
[0001144204-14-066571:note_history:2]
As of September 30, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001144204-15-007097:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2014 in the amount of $11,000,000 approximates fair value.
  (was, 2014-11-10, similarity 0.987):
[0001144204-14-066571:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2014 in the amount of $11,400,000 approximates fair value.

- changed (2015-02-09):
[0001144204-15-007097:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits
  (was, 2014-11-10, similarity 0.9857):
[0001144204-14-066571:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2015-02-09):
[0001144204-15-007097:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $160,000 and $180,000 and for returns and other allowances of $1,040,000 and $1,005,000 as of December 31, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2014-11-10, similarity 0.9926):
[0001144204-14-066571:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $165,000 and $180,000 and for returns and other allowances of $840,000 and $1,005,000 as of September 30, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- added (2015-02-09):
[0001144204-15-007097:note_history:6]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,511) |  | $ | 3,289 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (310) |  |  | 30 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,821) |  | $ | 9,219 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |

- added (2015-02-09):
[0001144204-15-007097:note_history:7]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended December 31, 2014 and 2013, respectively. Amortization expense for intangible assets subject to amortization was approximately $333,000 and $391,000 for the six months ended December 31, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.5 years and  14.4 years at December 31, 2014 and 2013, respectively.

- changed (2015-02-09):
[0001144204-15-007097:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 6% for the three months ended December 31, 2014 and 2013, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2014 and 2013, respectively.
  (was, 2014-11-10, similarity 0.8918):
[0001144204-14-066571:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% and 7% for the three months ended September 30, 2014 and 2013, respectively.

- added (2015-02-09):
[0001144204-15-007097:note_history:9]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2014 and 2013 was $312,000 and $247,000, respectively. Advertising expense for the six months ended December 31, 2014 and 2013 was $856,000 and $612,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

- changed (2015-02-09):
[0001144204-15-007097:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2014 and 2013 was $1,335,000 and $1,252,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2014 and 2013 was $2,653,000 and $2,538,000, respectively.
  (was, 2014-11-10, similarity 0.8184):
[0001144204-14-066571:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2014 and 2013 was $1,307,000 and $1,286,000, respectively.

- changed (2015-02-09):
[0001144204-15-007097:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):
  (was, 2014-11-10, similarity 0.9856):
[0001144204-14-066571:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

- added (2015-02-09):
[0001144204-15-007097:note_history:12]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 951 |  | $ | 368 |  |  | 19,188 |  |  | 19,408 |  | $ | 0.05 |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 1 |  |  | 36 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 951 |  | $ | 368 |  |  | 19,189 |  |  | 19,444 |  | $ | 0.05 |  | $ | 0.02 |  |

- changed (2015-02-09):
[0001144204-15-007097:note_history:13]
Options to purchase  368,250 and  131,402 shares of common stock for the three months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2014-11-10, similarity 0.9877):
[0001144204-14-066571:note_history:13]
Options to purchase  145,500 and  268,116 shares of common stock for the three months ended September 30, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2015-02-09):
[0001144204-15-007097:note_history:14]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- added (2015-02-09):
[0001144204-15-007097:note_history:15]
Options to purchase  256,875 and  199,759 shares of common stock for the six months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2015-02-09):
[0001144204-15-007097:note_history:16]
Stock-based compensation costs of $68,000 and $6,000 were recognized for three months ended December 31, 2014 and 2013, respectively. Stock-based compensation costs of $101,000 and $7,000 were recognized for six months ended December 31, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2014 and 2013.
  (was, 2014-11-10, similarity 0.6643):
[0001144204-14-066571:note_history:16]
Stock-based compensation costs of $33,000 and $1,000 were recognized for three months ended September 30, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2014 and 2013.

- changed (2015-02-09):
[0001144204-15-007097:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or six months ended December 31, 2014 and 2013.
  (was, 2014-11-10, similarity 0.9532):
[0001144204-14-066571:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2014 and 2013.

- added (2015-02-09):
[0001144204-15-007097:note_history:18]
For the three and six months ended December 31, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2015-02-09):
[0001144204-15-007097:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($130,000 and $121,000 in the three months ended December 31, 2014 and 2013, respectively, and $257,000 and $252,000 in the six months ended December 31, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($240,000 and $221,000 in the three months ended December 31, 2014 and 2013, respectively, and $481,000 and $463,000 in the six months ended December 31, 2014 and 2013, respectively).
  (was, 2014-11-10, similarity 0.792):
[0001144204-14-066571:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($127,000 and $131,000 in the three months ended September 30, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($241,000 and $242,000 in the three months ended September 30, 2014 and 2013, respectively).

- removed (2015-02-09):
[0001144204-14-066571:note_history:20]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,357) |  | $ | 3,443 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (297) |  |  | 43 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,654) |  | $ | 9,386 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |

- removed (2015-02-09):
[0001144204-14-066571:note_history:21]
Amortization expense for intangible assets subject to amortization was approximately $166,000 and $195,000 for the three months ended September 30, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.7 years and  14.6 years at September 30, 2014 and 2013, respectively.

- removed (2015-02-09):
[0001144204-14-066571:note_history:22]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2014 and 2013 was $544,000 and $365,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

- removed (2015-02-09):
[0001144204-14-066571:note_history:23]
For the three months ended September 30, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001144204-15-007097:note_history:24]
As of December 31, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.
  (was, 2014-11-10, similarity 0.9933):
[0001144204-14-066571:note_history:24]
As of September 30, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal,  quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal,  quarterly payments of $325,000.

- changed (2015-02-09):
[0001144204-15-007097:note_history:25]
Outstanding balances and interest rates as of December 31, 2014 and June 30, 2014 are as follows:
  (was, 2014-11-10, similarity 0.9714):
[0001144204-14-066571:note_history:25]
Outstanding balances and interest rates as of September 30, 2014 and June 30, 2014 are as follows:

- changed (2015-02-09):
[0001144204-15-007097:note_history:26]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding | Interest Rate |  | Outstanding | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,500 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,000 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2014-11-10, similarity 0.9809):
[0001144204-14-066571:note_history:26]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,900 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,400 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-09):
[0001144204-15-007097:note_history:27]
Outstanding balances and interest rates as of December 31, 2014 and June 30, 2014 are as follows:
  (was, 2014-11-10, similarity 0.9714):
[0001144204-14-066571:note_history:27]
Outstanding balances and interest rates as of September 30, 2014 and June 30, 2014 are as follows:

- changed (2015-02-09):
[0001144204-15-007097:note_history:28]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding | Interest Rate |  | Outstanding | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,500 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,000 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2014-11-10, similarity 0.9809):
[0001144204-14-066571:note_history:28]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,900 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,400 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
