# NSSC notes — 0001144204-15-007097


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-15-007097:notes:1]
[same as prior period, unchanged from 0001144204-14-066571:notes:1]

[0001144204-15-007097:notes:2]
[same as prior period, unchanged from 0001144204-14-066571:notes:2]

[0001144204-15-007097:notes:3]
|  |  | December |  | June 30, |  |  |  |
|  |  | 31, 2014 |  | 2014 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 6,957 |  |  | 6,906 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,451 |  |  | 2,427 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 20,100 |  |  | 19,974 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 288 |  |  | 288 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 39,611 |  |  | 39,410 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 33,305 |  |  | 33,016 |  |  |  |
|  |  | $ | 6,306 |  | $ | 6,394 |  |  |  |

[0001144204-15-007097:notes:4]
Depreciation and amortization expense on property, plant, and equipment was $210,000 and $223,000 for the three months ended December 31, 2014 and 2013, respectively and $412,000 and $440,000 for the six months ended December 31, 2014 and 2013, respectively


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-15-007097:notes:5]
[same as prior period, unchanged from 0001144204-14-066571:notes:5]

[0001144204-15-007097:notes:6]
[same as prior period, unchanged from 0001144204-14-066571:notes:6]

[0001144204-15-007097:notes:7]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of December 31, 2014 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2008 and thereafter.

[0001144204-15-007097:notes:8]
The Company has identified its U.S. Federal income tax return and its State return in New York as its major tax jurisdictions. As of December 31, 2014 and June 30, 2014 the Company has a long-term accrued income tax liability of $190,000 and $169,000, respectively.


## us-gaap:LongTermDebtTextBlock

[0001144204-15-007097:notes:9]
NOTE 6 - Long-Term Debt

[0001144204-15-007097:notes:10]
As of December 31, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001144204-15-007097:notes:11]
Outstanding balances and interest rates as of December 31, 2014 and June 30, 2014 are as follows:

[0001144204-15-007097:notes:12]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding | Interest Rate |  | Outstanding | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,500 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,000 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |

[0001144204-15-007097:notes:13]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-15-007097:notes:14]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-15-007097:notes:15]
[same as prior period, unchanged from 0001144204-14-066571:notes:15]

[0001144204-15-007097:notes:16]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended December 31, 2014 and 2013, the Company recorded non-cash compensation expense of $67,000 ($.00 per basic and diluted share) and $6,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation. For the six months ended December 31, 2014 and 2013, the Company recorded non-cash compensation expense of $101,000 ($.01 per basic and diluted share) and $7,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-15-007097:notes:17]
2012 Employee Stock Option Plan

[0001144204-15-007097:notes:18]
In December 2012, the stockholders approved the 2012 Employee Stock Option Plan (the 2012 Employee Plan). The 2012 Employee Plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  950,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options, which are intended to qualify as incentive stock options (ISOs), to valued employees. Any plan participant who is granted ISOs and possesses more than 10% of the voting rights of the Company's outstanding common stock must be granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-15-007097:notes:19]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2014,  112,500 stock options were granted,  27,500 stock options were exercisable and  837,500 stock options were available for grant under this plan.

[0001144204-15-007097:notes:20]
The fair value of each option granted during fiscal 2014 was estimated on the date of grant using the Black-Scholes option-pricing model with the following weighted average assumptions:

[0001144204-15-007097:notes:21]
| Risk-free interest rates |  | 2.3 | % |
| Expected lives |  | 10 years |  |
| Expected volatility |  | 54 | % |
| Expected dividend yields |  | 0 | % |

[0001144204-15-007097:notes:22]
The following table reflects activity under the 2012 Plan for the six months ended December 31,:

[0001144204-15-007097:notes:23]
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 78,500 |  | $ | 5.73 |  |  | — |  | $ | — |  |
| Granted |  |  | 44,000 |  |  | 4.43 |  |  | 78,500 |  |  | 5.73 |  |
| Terminated/Lapsed |  |  | (10,000) |  |  | 4.88 |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 112,500 |  | $ | 5.30 |  |  | 78,500 |  | $ | 5.73 |  |
| Exercisable, end of period |  |  | 27,500 |  | $ | 5.26 |  |  | 15,700 |  | $ | 5.73 |  |
| Weighted average fair value at grant date of options granted |  | $ | 2.82 |  |  |  |  | $ | 3.84 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 13,000 |  |  |  |  | $ | 44,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 3,000 |  |  |  |  | $ | 9,000 |  |  |  |  |

[0001144204-15-007097:notes:24]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at December 31, 2014:

[0001144204-15-007097:notes:25]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  |  |  |  |  |  |  |  |  |  |
| Range of |  | Number |  | remaining |  | Weighted average |  | Number |  | Weighted average |  |
| exercise prices |  | outstanding |  | contractual life |  | exercise price |  | exercisable |  | exercise price |  |
| $ 4.88 - $ 6.31 |  |  | 112,500 |  |  | 9.2 |  | $ | 5.30 |  |  | 27,500 |  | $ | 5.26 |  |
|  |  |  | 112,500 |  |  | 9.2 |  | $ | 5.30 |  |  | 27,500 |  | $ | 5.26 |  |

[0001144204-15-007097:notes:26]
As of December 31, 2014, there was $260,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan.  44,000 options were granted during the three and six months ended December 31, 2014. The total fair value of the options vesting during the three and six months ended December 31, 2014 and 2013 under this plan was $25,000 and $37,000, respectively and $41,000 and $60,000, respectively.

[0001144204-15-007097:notes:27]
2012 Non-Employee Stock Option Plan

[0001144204-15-007097:notes:28]
[same as prior period, unchanged from 0001144204-14-066571:notes:24]

[0001144204-15-007097:notes:29]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2014,  35,000 stock options were granted,  12,000 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-15-007097:notes:30]
The following table reflects activity under the 2012 Non-Employee Plan for the six months ended December 31,:

[0001144204-15-007097:notes:31]
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 25,000 |  | $ | 4.88 |  |  | — |  | $ | — |  |
| Granted |  |  | 10,000 |  |  | 4.37 |  |  | 25,000 |  |  | 4.88 |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 12,000 |  | $ | 4.80 |  |  | 5,000 |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  | $ | 2.86 |  |  |  |  | $ | 3.30 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 3,000 |  |  |  |  | $ | 35,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 1,000 |  |  |  |  | $ | 7,000 |  |  |  |  |

[0001144204-15-007097:notes:32]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at December 31, 2014:

[0001144204-15-007097:notes:33]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  |  | Weighted average |  | Weighted |  |  |  |  | Weighted |  |
| Range of |  | Number |  | remaining |  | average exercise |  | Number |  | average exercise |  |
| exercise prices |  | outstanding |  | contractual life |  | price |  | exercisable |  | price |  |
| $4.37 - $ 4.88 |  |  | 35,000 |  |  | 9.0 |  | $ | 4.73 |  |  | 12,000 |  | $ | 4.80 |  |
|  |  |  | 35,000 |  |  | 9.0 |  | $ | 4.73 |  |  | 12,000 |  | $ | 4.80 |  |

[0001144204-15-007097:notes:34]
As of December 31, 2014, there was $72,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan.   10,000 options were granted during the three and six months ended December 31, 2014. The total fair value of the options vesting during each of the three and six month periods ended December 31, 2014 and 2013 under this plan was $6,000 and $17,000, respectively and $22,000 and $17,000, respectively.

[0001144204-15-007097:notes:35]
2002 Employee Stock Option Plan

[0001144204-15-007097:notes:36]
[same as prior period, unchanged from 0001144204-14-066571:notes:31]

[0001144204-15-007097:notes:37]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At December 31, 2014,  1,471,480 stock options had been granted,  264,750 stock options were exercisable and no further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-15-007097:notes:38]
The following table reflects activity under the 2002 Employee plan for the six months ended December 31,:

[0001144204-15-007097:notes:39]
|  |  | 2014 |  | 2013 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 265,750 |  | $ | 6.51 |  |  | 651,140 |  | $ | 4.18 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (1,000) |  |  | 6.02 |  |  | (30,240) |  |  | 1.74 |  |
| Exercised |  |  | — |  |  | — |  |  | (326,800) |  |  | 2.70 |  |
| Outstanding, end of period |  |  | 264,750 |  | $ | 6.51 |  |  | 294,100 |  | $ | 6.07 |  |
| Exercisable, end of period |  |  | 264,750 |  | $ | 6.51 |  |  | 294,100 |  | $ | 6.07 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  | $ | 854,000 |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | — |  |  |  |  | $ | 254,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | — |  |  |  |  | $ | 254,000 |  |  |  |  |

[0001144204-15-007097:notes:40]
0 and  326,800 stock options were exercised during the six months ended December 31, 2014 and 2013, respectively.  324,100 of the 326,800 stock options exercised during the six months ended December 31, 2013 were settled by exchanging  164,859 shares of the Company’s common stock of which  85,170 was retired upon receipt. Cash received from option exercises was $0 and $5,000 for the six months ended December 31, 2014 and 2013, respectively, and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-15-007097:notes:41]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at December 31, 2014:

[0001144204-15-007097:notes:42]
|  |  | Options outstanding and exercisable |  |
| Range of |  | Number |  | Weighted average |  | Weighted average |  |
| exercise prices |  | outstanding |  | remaining contractual life |  | exercise price |  |
| $ 5.22 - $ 6.62 |  |  | 227,250 |  |  | 1.3 |  | $ | 5.75 |  |
| $11.16 |  |  | 37,500 |  |  | 1.2 |  |  | 11.16 |  |
|  |  |  | 264,750 |  |  | 1.3 |  | $ | 6.51 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-15-007097:notes:43]
[same as prior period, unchanged from 0001144204-14-066571:notes:38]

[0001144204-15-007097:notes:44]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the six months ended December 31, 2014 the Company repurchased  304,186 shares of its outstanding common stock for a weighted average price of $4.55 per share. These repurchased shares are included in the Company’s Treasury Stock as of December 31, 2014.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-15-007097:notes:45]
[same as prior period, unchanged from 0001144204-14-066571:notes:40]

[0001144204-15-007097:notes:46]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $41,000 and $25,000 for the three months ended December 31, 2014 and 2013, respectively and $67,000 and $51,000 for the six months ended December 31, 2014 and 2013, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-15-007097:notes:47]
NOTE 10 - Commitments and Contingencies

[0001144204-15-007097:notes:48]
Leases

[0001144204-15-007097:notes:49]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2016.

[0001144204-15-007097:notes:50]
Rent expense, with the exception of the land lease referred to below, totaled approximately $9,000 and $9,000 for the three months ended December 31, 2014 and 2013, respectively and $16,000 and $18,000 for the six months ended December 31, 2014 and 2013, respectively.

[0001144204-15-007097:notes:51]
Land Lease

[0001144204-15-007097:notes:52]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-15-007097:notes:53]
Litigation

[0001144204-15-007097:notes:54]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-15-007097:notes:55]
Employment Agreements

[0001144204-15-007097:notes:56]
As of December 31, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-15-007097:notes:57]
[same as prior period, unchanged from 0001144204-14-066571:notes:124]

[0001144204-15-007097:notes:58]
The Company is engaged in one major line of business: the development, manufacture, and distribution of access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. Sales to unaffiliated customers are primarily shipped from the United States. The Company has customers worldwide with major concentrations in North America.

[0001144204-15-007097:notes:59]
Financial Information Relating to Domestic and Foreign Operations

[0001144204-15-007097:notes:60]
|  |  | Three months ended December 31, |  | Six months ended December 31, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
|  |  | (in thousands) |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 18,876 |  | $ | 17,593 |  | $ | 35,448 |  | $ | 33,887 |  |
| Foreign |  |  | 695 |  |  | 760 |  |  | 1,459 |  |  | 1,705 |  |
| Total Net Sales |  | $ | 19,571 |  | $ | 18,353 |  | $ | 36,907 |  | $ | 35,592 |  |

[0001144204-15-007097:notes:61]
|  |  | December 31, |  |  |  |
| Identifiable assets: |  | 2014 |  | June 30, 2014 |  |
| United States |  | $ | 47,553 |  | $ | 49,529 |  |
| Dominican Republic (2) |  |  | 14,127 |  |  | 13,835 |  |
| Total Identifiable Assets |  | $ | 61,680 |  | $ | 63,364 |  |

[0001144204-15-007097:notes:62]
(1) All of the Company's sales originate in the United States and are shipped primarily from the Company's facilities in the United States. There were no sales into any one foreign country in excess of 10% of total Net Sales.

[0001144204-15-007097:notes:63]
(2) Consists primarily of inventories (December 31, 2014 = $10,477; June 30, 2014 = $10,216) and fixed assets (December 31, 2014 = $3,425; June 30, 2014 = $3,475) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001144204-15-007097:notes:64]
Basis of Presentation

[0001144204-15-007097:notes:65]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated. Certain prior period amounts relating to credit card fees have been reclassified for consistency with the current period presentation. The reclassification did not have an impact on the Balance Sheets, Statement of Cash Flows or reported Net income (loss) for any period.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-15-007097:notes:66]
[same as prior period, unchanged from 0001144204-14-066571:notes:52]

[0001144204-15-007097:notes:67]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits


## us-gaap:ReceivablesPolicyTextBlock

[0001144204-15-007097:notes:68]
[same as prior period, unchanged from 0001144204-14-066571:notes:54]

[0001144204-15-007097:notes:69]
Accounts receivable is stated net of the reserves for doubtful accounts of $160,000 and $180,000 and for returns and other allowances of $1,040,000 and $1,005,000 as of December 31, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.


## us-gaap:InventoryPolicyTextBlock

[0001144204-15-007097:notes:70]
[same as prior period, unchanged from 0001144204-14-066571:notes:56]

[0001144204-15-007097:notes:71]
[same as prior period, unchanged from 0001144204-14-066571:notes:57]

[0001144204-15-007097:notes:72]
[same as prior period, unchanged from 0001144204-14-066571:notes:58]

[0001144204-15-007097:notes:73]
[same as prior period, unchanged from 0001144204-14-066571:notes:59]


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-15-007097:notes:74]
[same as prior period, unchanged from 0001144204-14-066571:notes:60]

[0001144204-15-007097:notes:75]
[same as prior period, unchanged from 0001144204-14-066571:notes:61]

[0001144204-15-007097:notes:76]
[same as prior period, unchanged from 0001144204-14-066571:notes:62]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001144204-15-007097:notes:77]
[same as prior period, unchanged from 0001144204-14-066571:notes:63]

[0001144204-15-007097:notes:78]
[same as prior period, unchanged from 0001144204-14-066571:notes:64]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-15-007097:notes:79]
[same as prior period, unchanged from 0001144204-14-066571:notes:65]

[0001144204-15-007097:notes:80]
[same as prior period, unchanged from 0001144204-14-066571:notes:66]


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-15-007097:notes:81]
[same as prior period, unchanged from 0001144204-14-066571:notes:67]

[0001144204-15-007097:notes:82]
[same as prior period, unchanged from 0001144204-14-066571:notes:68]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-15-007097:notes:83]
[same as prior period, unchanged from 0001144204-14-066571:notes:69]

[0001144204-15-007097:notes:84]
[same as prior period, unchanged from 0001144204-14-066571:notes:70]

[0001144204-15-007097:notes:85]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

[0001144204-15-007097:notes:86]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 951 |  | $ | 368 |  |  | 19,188 |  |  | 19,408 |  | $ | 0.05 |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 1 |  |  | 36 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 951 |  | $ | 368 |  |  | 19,189 |  |  | 19,444 |  | $ | 0.05 |  | $ | 0.02 |  |

[0001144204-15-007097:notes:87]
Options to purchase  368,250 and  131,402 shares of common stock for the three months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-15-007097:notes:88]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

[0001144204-15-007097:notes:89]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 1,110 |  | $ | 491 |  |  | 19,304 |  |  | 19,366 |  | $ | 0.06 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | — |  |  | 27 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,110 |  | $ | 491 |  |  | 19,304 |  |  | 19,393 |  | $ | 0.06 |  | $ | 0.03 |  |

[0001144204-15-007097:notes:90]
Options to purchase  256,875 and  199,759 shares of common stock for the six months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-15-007097:notes:91]
[same as prior period, unchanged from 0001144204-14-066571:notes:74]

[0001144204-15-007097:notes:92]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or six months ended December 31, 2014 and 2013.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001144204-15-007097:notes:93]
[same as prior period, unchanged from 0001144204-14-066571:notes:76]

[0001144204-15-007097:notes:94]
For the three and six months ended December 31, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001144204-15-007097:notes:95]
[same as prior period, unchanged from 0001144204-14-066571:notes:78]

[0001144204-15-007097:notes:96]
[same as prior period, unchanged from 0001144204-14-066571:notes:79]


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001144204-15-007097:notes:97]
[same as prior period, unchanged from 0001144204-14-066571:notes:80]

[0001144204-15-007097:notes:98]
The Company records the amount billed to customers for shipping and handling in net sales ($130,000 and $121,000 in the three months ended December 31, 2014 and 2013, respectively, and $257,000 and $252,000 in the six months ended December 31, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($240,000 and $221,000 in the three months ended December 31, 2014 and 2013, respectively, and $481,000 and $463,000 in the six months ended December 31, 2014 and 2013, respectively).


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001144204-15-007097:notes:99]
Recently Issued Accounting Standards

[0001144204-15-007097:notes:100]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers (Topic 606),” which is the new comprehensive revenue recognition standard that will supersede all existing revenue recognition guidance under U.S. GAAP. The standard’s core principle is that a company will recognize revenue when it transfers promised goods or services to a customer in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services. ASU 2014-09 is effective for annual and interim periods beginning on or after December 15, 2016, and early adoption is not permitted. Entities will have the option of using either a full retrospective approach or a modified approach to adopt the guidance. The Company is currently evaluating the impact of adopting this guidance.

[0001144204-15-007097:notes:101]
In July 2013, the FASB issued authoritative guidance that requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a net operating loss (“NOL”) carry-forward, a similar tax loss, or a tax credit carry-forward.  If either (i) an NOL carry-forward, a similar tax loss, or tax credit carry-forward is not available as of the reporting date under the governing tax law to settle taxes that would result from the disallowance of the tax position or (ii) the entity does not intend to use the deferred tax asset for this purpose (provided that the tax law permits a choice), an entity should present an unrecognized tax benefit in the financial statements as a liability and should not net the unrecognized tax benefit with a deferred tax asset.  This guidance became effective for unrecognized tax benefits that exist as of the Company’s fiscal 2015 first quarter.  The guidance did not have an impact on the Company’s consolidated financial statements.


## nssc:ScheduleOfIntangibleAssetsTableTextBlock

[0001144204-15-007097:notes:102]
[same as prior period, unchanged from 0001144204-14-066571:notes:85]

[0001144204-15-007097:notes:103]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,511) |  | $ | 3,289 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (310) |  |  | 30 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,821) |  | $ | 9,219 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |


## nssc:InventoryTableTextBlock

[0001144204-15-007097:notes:104]
[same as prior period, unchanged from 0001144204-14-066571:notes:87]

[0001144204-15-007097:notes:105]
|  |  | December |  | June 30, |  |
|  |  | 31, 2014 |  | 2014 |  |
| Component parts |  | $ | 15,929 |  | $ | 15,268 |  |
| Work-in-process |  |  | 3,789 |  |  | 3,632 |  |
| Finished product |  |  | 6,375 |  |  | 6,110 |  |
|  |  | $ | 26,093 |  | $ | 25,010 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 22,238 |  | $ | 21,443 |  |
| Non-current |  |  | 3,855 |  |  | 3,567 |  |
|  |  | $ | 26,093 |  | $ | 25,010 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-15-007097:notes:106]
[same as prior period, unchanged from 0001144204-14-066571:notes:95]

[0001144204-15-007097:notes:107]
[same as prior period, unchanged from 0001144204-14-066571:notes:96]

[0001144204-15-007097:notes:108]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-15-007097:notes:109]
[same as prior period, unchanged from 0001144204-14-066571:notes:98]

[0001144204-15-007097:notes:110]
[same as prior period, unchanged from 0001144204-14-066571:notes:99]

[0001144204-15-007097:notes:111]
[same as prior period, unchanged from 0001144204-14-066571:notes:102]

[0001144204-15-007097:notes:112]
[same as prior period, unchanged from 0001144204-14-066571:notes:103]

[0001144204-15-007097:notes:113]
[same as prior period, unchanged from 0001144204-14-066571:notes:104]

[0001144204-15-007097:notes:114]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2014 in the amount of $11,000,000 approximates fair value.

[0001144204-15-007097:notes:115]
[same as prior period, unchanged from 0001144204-14-066571:notes:106]

[0001144204-15-007097:notes:116]
[same as prior period, unchanged from 0001144204-14-066571:notes:107]

[0001144204-15-007097:notes:117]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of twenty years (customer relationships) and seven years (non-compete agreement). The Marks trade name was deemed to have an indefinite life.

[0001144204-15-007097:notes:118]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended December 31, 2014 and 2013, respectively. Amortization expense for intangible assets subject to amortization was approximately $333,000 and $391,000 for the six months ended December 31, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.5 years and  14.4 years at December 31, 2014 and 2013, respectively.

[0001144204-15-007097:notes:119]
[same as prior period, unchanged from 0001144204-14-066571:notes:110]

[0001144204-15-007097:notes:120]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 6% for the three months ended December 31, 2014 and 2013, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2014 and 2013, respectively.

[0001144204-15-007097:notes:121]
[same as prior period, unchanged from 0001144204-14-066571:notes:112]

[0001144204-15-007097:notes:122]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2014 and 2013 was $312,000 and $247,000, respectively. Advertising expense for the six months ended December 31, 2014 and 2013 was $856,000 and $612,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

[0001144204-15-007097:notes:123]
[same as prior period, unchanged from 0001144204-14-066571:notes:114]

[0001144204-15-007097:notes:124]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2014 and 2013 was $1,335,000 and $1,252,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2014 and 2013 was $2,653,000 and $2,538,000, respectively.

[0001144204-15-007097:notes:125]
[same as prior period, unchanged from 0001144204-14-066571:notes:116]

[0001144204-15-007097:notes:126]
[same as prior period, unchanged from 0001144204-14-066571:notes:117]

[0001144204-15-007097:notes:127]
[same as prior period, unchanged from 0001144204-14-066571:notes:118]

[0001144204-15-007097:notes:128]
Stock-based compensation costs of $68,000 and $6,000 were recognized for three months ended December 31, 2014 and 2013, respectively. Stock-based compensation costs of $101,000 and $7,000 were recognized for six months ended December 31, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2014 and 2013.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-15-007097:notes:129]
[same as prior period, unchanged from 0001144204-14-066571:notes:120]

[0001144204-15-007097:notes:130]
The Company had two customers with accounts receivable balance that aggregated  23% of the Company’s accounts receivable at December 31, 2014. The Company had one customer with an accounts receivable balance that comprised  12% of the Company’s accounts receivable at June 30, 2014. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-15-007097:notes:131]
[same as prior period, unchanged from 0001144204-14-066571:notes:122]

[0001144204-15-007097:notes:132]
[same as prior period, unchanged from 0001144204-14-066571:notes:123]
