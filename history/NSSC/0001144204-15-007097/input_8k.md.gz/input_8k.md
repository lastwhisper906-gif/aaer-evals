# NSSC 8-K — 0001144204-14-067288 filed 2014-11-12

## item codes, every 8-K on or before 2015-02-09

- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2015-02-09

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-14-067288:8k_2_02:1]
EX-99.1
2
v393943_ex99-1.htm
EXHIBIT 99.1

[0001144204-14-067288:8k_2_02:2]
Exhibit 99.1

[0001144204-14-067288:8k_2_02:3]
NAPCO
Announces Results for First Quarter Ended September 30, 2014

[0001144204-14-067288:8k_2_02:4]
-Revenue of $17.3 Million-

[0001144204-14-067288:8k_2_02:5]
-Net Income Increases 29%-

[0001144204-14-067288:8k_2_02:6]
-Management to Host Conference Call Today
at 11 a.m.-

[0001144204-14-067288:8k_2_02:7]
AMITYVILLE, N.Y., Nov. 10, 2014 /PRNewswire/
-- NAPCO Security Technologies, Inc. (NSSC), one of the world's leading solutions providers and manufacturers of high-technology
electronic intrusion security, connected home, video and fire systems, as well as enterprise-class access control and door locking
products, today announced financial results for its first fiscal quarter ended September 30, 2014.

[0001144204-14-067288:8k_2_02:8]
Highlights:

[0001144204-14-067288:8k_2_02:9]
|  | · | Net sales for the first quarter were $17.3 million, up 1% from the same quarter last year. Last year’s sales included a large custom access control system order for a major university. |

[0001144204-14-067288:8k_2_02:10]
|  | · | Sales of the Company's door-locking products, including LocDown™ products, grew 4% in the first quarter as compared to the same period a year ago, representing the ninth consecutive quarter of growth of these products. |

[0001144204-14-067288:8k_2_02:11]
|  | · | Alarm Division recurring revenue for the first quarter increased 82% and grew sequentially by 13%. |

[0001144204-14-067288:8k_2_02:12]
|  | · | Gross margin improved 110 basis points to 30.3% for the quarter as compared to 29.2% for the same period last year. |

[0001144204-14-067288:8k_2_02:13]
|  | · | Income before taxes for the first quarter increased by 42% to $196,000 as compared to $138,000 last year. |

[0001144204-14-067288:8k_2_02:14]
|  | · | Earnings per share (diluted) for the first quarter remained constant at $0.01 as compared to the same quarter a year ago. |

[0001144204-14-067288:8k_2_02:15]
|  | · | Debt, net of cash, has been reduced by $28.2 million from $35.9 million to $7.7 million since acquiring Marks in August of 2008, with $1.6 million of this reduction occurring in the first three months of this fiscal year. The net debt of $7.7 million is the lowest level in eight years. |

[0001144204-14-067288:8k_2_02:16]
Richard Soloway, Chairman and President, said, “Our focus
on selling higher margin products with recurring revenue streams helped us deliver solid results to our bottom line during the
seasonally slow fiscal first quarter. Our improved gross margin during what has historically been our weakest sales quarter highlights
the operating leverage in our business and underscores our earnings potential as we move into seasonally stronger quarters. This
is particularly encouraging in light of the strong interest we are seeing for our integrated locking and access control solutions,
which provide end-user customers with some of the most cost-effective, advanced security systems on the market. During the quarter,
our Continental division signed a contract with a large Midwestern university to provide its campus with an integrated access-locking
solution as part of the first phase of a campus-wide project. The fact that prominent educational institutions with large physical
infrastructures continue to turn to NAPCO to make their students, faculty and administrators safer is a testament to the traction
we are gaining in this fast-growing segment of the security market.”

[0001144204-14-067288:8k_2_02:17]
Mr. Soloway added: “In addition,
other new product lines with recurring revenue streams continue to perform well. Activations of our Starlink™ 3G/4G Communicators
grew 41% sequentially this past quarter as alarm dealers replace 2G radios ahead of that network shutting down in 2017. Our dealer
network is also responding positively to the launch of the iBridge Connected Home Dealer Program, which allows consumers to control
their security systems, video, cameras, thermostats, entry locks and lighting remotely using a smartphone, PC or tablet.”

[0001144204-14-067288:8k_2_02:18]
Mr. Soloway concluded: “The momentum
we’re building across the Company should enable us to accelerate sales growth throughout the year as new products gain awareness
among our large distribution and dealer network and we enter seasonally stronger quarters for our core products. We continue to
remain keenly focused on building shareholder value and strengthening our balance sheet by steadily reducing debt and buying back
our shares. ”

[0001144204-14-067288:8k_2_02:19]
Financial Results

[0001144204-14-067288:8k_2_02:20]
Net Sales for the three months ended September
30, 2014 increased 1% to $17.3 million, as compared to $17.2 million for the same period one year ago. Revenue in the first quarter
of last year included part of a large custom access control system order for a major university. Selling, general and administrative
expenses for the quarter were $5.0 million, or 28.9% of sales, as compared to $4.8 million, or 27.8% of sales, for the same period
in 2014. The increase was due primarily to additional sales staff and advertising expenditures to support ongoing product introductions.

[0001144204-14-067288:8k_2_02:21]
Operating income for the three months ended
September 30, 2014 remained relatively constant at $246,000 as compared to $240,000 for the same period a year ago. Adjusted EBITDA*
for the three months ended September 30, 2014 remained relatively constant at $651,000 as compared to $656,000 for the same period
a year ago (*see table attached).

[0001144204-14-067288:8k_2_02:22]
Net income for the three months ended September
30, 2014 increased 29%, to $159,000 or $0.01 per share as compared to $123,000 or $0.01 per share for the same period last year.

[0001144204-14-067288:8k_2_02:23]
Balance Sheet Summary

[0001144204-14-067288:8k_2_02:24]
At September 30, 2014, the Company had
$3.7 million in cash and cash equivalents an increase of $1.2 million compared to $2.5 million at June 30, 2014. NAPCO had working
capital of $33.0 million as compared with working capital of $33.4 million at June 30, 2014. Current ratio was 4.6:1 at both September
30, 2014 and June 30, 2014. Debt, net of cash, was $7.7 million at September 30, 2014, a decrease of $1.6 million compared to $9.3
million as of June 30, 2014.

[0001144204-14-067288:8k_2_02:25]
Conference Call Information

[0001144204-14-067288:8k_2_02:26]
Management will conduct a conference call
at 11 a.m. today, November 10, 2014. Interested parties may participate in the call by dialing 1-877-407-4018 or for international
callers, 1-201-689-8471 about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on
replay starting at 2 p.m. ET on November 10, 2014 and ending on November 17, 2014 at 11:59 p.m. ET. For the replay, please dial
1-877-870-5176 domestically, or 1-858-384-5517 for international callers, and use the replay access code 13593982. In addition,
the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=111596.

[0001144204-14-067288:8k_2_02:27]
About NAPCO Security Technologies, Inc.

[0001144204-14-067288:8k_2_02:28]
NAPCO Security Technologies, Inc. is one
of the world's leading solutions providers and manufacturers of high-technology electronic security, connected home, video, fire
alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected home
segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville,
New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial, institutional,
residential and government applications. NAPCO products have earned a reputation for innovation, technical excellence and
reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security market. For
additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-14-067288:8k_2_02:29]
Safe Harbor Statement

[0001144204-14-067288:8k_2_02:30]
This press release contains forward-looking
statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from
those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's
filings with the Securities and Exchange Commission.

[0001144204-14-067288:8k_2_02:31]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS (audited) |
|  |  | September 30, 2014 |  |  | June 30, 2014 |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,741 |  |  | $ | 2,483 |  |
| Accounts receivable, net of reserves and allowances |  |  | 13,930 |  |  |  | 16,904 |  |
| Inventories |  |  | 22,767 |  |  |  | 21,443 |  |
| Prepaid expenses and other current assets |  |  | 849 |  |  |  | 989 |  |
| Income tax receivable |  |  | 169 |  |  |  | 121 |  |
| Deferred income taxes |  |  | 757 |  |  |  | 739 |  |
| Total Current Assets |  |  | 42,213 |  |  |  | 42,679 |  |
| Inventories - non-current |  |  | 3,653 |  |  |  | 3,567 |  |
| Deferred income taxes |  |  | 932 |  |  |  | 1,005 |  |
| Property, plant and equipment, net |  |  | 6,295 |  |  |  | 6,394 |  |
| Intangible assets, net |  |  | 9,386 |  |  |  | 9,552 |  |
| Other assets |  |  | 158 |  |  |  | 167 |  |
| TOTAL ASSETS |  | $ | 62,637 |  |  | $ | 63,364 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,846 |  |  |  | 4,082 |  |
| Accrued expenses |  |  | 1,829 |  |  |  | 1,737 |  |
| Accrued salaries and wages |  |  | 1,958 |  |  |  | 1,824 |  |
| Total Current Liabilities |  |  | 9,233 |  |  |  | 9,243 |  |
| Long-term debt, net of current maturities |  |  | 9,800 |  |  |  | 10,200 |  |
| Accrued income taxes |  |  | 169 |  |  |  | 169 |  |
| Total Liabilities |  |  | 19,202 |  |  |  | 19,612 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 20,049,243 shares issued; and 19,311,520 and 19,419,076 shares outstanding, respectively |  |  | 210 |  |  |  | 210 |  |
| Additional paid-in capital |  |  | 16,065 |  |  |  | 16,032 |  |
| Retained earnings |  |  | 35,713 |  |  |  | 35,554 |  |
|  |  |  | 51,988 |  |  |  | 51,796 |  |
| Less: Treasury Stock, at cost (1,737,723 and 1,630,167 shares, respectively) |  |  | (8,553 | ) |  |  | (8,044 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 43,435 |  |  |  | 43,752 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 62,637 |  |  | $ | 63,364 |  |

[0001144204-14-067288:8k_2_02:32]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME (audited) |
|  |  | Three months ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 17,336 |  |  | $ | 17,239 |  |
| Cost of sales |  |  | 12,081 |  |  |  | 12,200 |  |
| Gross Profit |  |  | 5,255 |  |  |  | 5,039 |  |
| Selling, general, and administrative expenses |  |  | 5,009 |  |  |  | 4,799 |  |
| Operating Income |  |  | 246 |  |  |  | 240 |  |
| Other expense (income) : |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 55 |  |  |  | 99 |  |
| Other, net |  |  | (5 | ) |  |  | 3 |  |
| Income before Income Taxes |  |  | 196 |  |  |  | 138 |  |
| Provision for income taxes |  |  | 37 |  |  |  | 15 |  |
| Net Income |  | $ | 159 |  |  | $ | 123 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.01 |  |  | $ | 0.01 |  |
| Diluted |  | $ | 0.01 |  |  | $ | 0.01 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,412,000 |  |  |  | 19,323,000 |  |
| Diluted |  |  | 19,412,000 |  |  |  | 19,341,000 |  |

[0001144204-14-067288:8k_2_02:33]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |
|  |  | Three months ended September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (In thousands except share data) |  |
| Net income |  | $ | 159 |  |  | $ | 123 |  |
| Add back provision for income taxes |  |  | 37 |  |  |  | 15 |  |
| Add back interest and other expense |  |  | 50 |  |  |  | 102 |  |
| Operating income (GAAP) |  |  | 246 |  |  |  | 240 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 166 |  |  |  | 195 |  |
| Add back stock-based compensation expense |  |  | 33 |  |  |  | 1 |  |
| Adjusted non-GAAP operating income |  |  | 445 |  |  |  | 436 |  |
| Add back depreciation and other amortization |  |  | 206 |  |  |  | 220 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 651 |  |  | $ | 656 |  |
| Adjusted EBITDA per Diluted Share |  | $ | 0.03 |  |  | $ | 0.03 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 19,412,000 |  |  |  | 19,341,000 |  |

[0001144204-14-067288:8k_2_02:34]
* Non-GAAP Information. Certain non-GAAP
measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA
as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP
operating income does not include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation
expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding
of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that
is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from
period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures
prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of
GAAP to non-GAAP financial measures included in the above.

[0001144204-14-067288:8k_2_02:35]
Contacts:

[0001144204-14-067288:8k_2_02:36]
Investor Relations

[0001144204-14-067288:8k_2_02:37]
KCSA Strategic Communications

[0001144204-14-067288:8k_2_02:38]
Todd Fromer / Phil Carlson

[0001144204-14-067288:8k_2_02:39]
212-896-1215 / 1233

[0001144204-14-067288:8k_2_02:40]
napco@kcsa.com

[0001144204-14-067288:8k_2_02:41]
Media

[0001144204-14-067288:8k_2_02:42]
KCSA Strategic Communications

[0001144204-14-067288:8k_2_02:43]
Jon Goldberg / Dixon Moretz

[0001144204-14-067288:8k_2_02:44]
212-896-1282 / 1251

[0001144204-14-067288:8k_2_02:45]
napco@kcsa.com
