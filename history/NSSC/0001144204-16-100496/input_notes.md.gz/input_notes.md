# NSSC notes — 0001144204-16-100496


## nssc:ScheduleOfIntangibleAssetsTableTextBlock

[0001144204-16-100496:notes:1]
Changes in intangible assets are as follows (in thousands):

[0001144204-16-100496:notes:2]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,212) |  | $ | 2,588 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,552) |  | $ | 8,488 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001144204-16-100496:notes:3]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

[0001144204-16-100496:notes:4]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 1,044 |  | $ | 395 |  |  | 18,811 |  |  | 19,066 |  | $ | 0.06 |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 17 |  |  | 7 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,044 |  | $ | 395 |  |  | 18,828 |  |  | 19,073 |  | $ | 0.06 |  | $ | 0.02 |  |

[0001144204-16-100496:notes:5]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

[0001144204-16-100496:notes:6]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,903 |  |  | 19,225 |  | $ | 0.12 |  | $ | 0.08 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 20 |  |  | 4 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,923 |  |  | 19,229 |  | $ | 0.12 |  | $ | 0.08 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001144204-16-100496:notes:7]
Basis of Presentation

[0001144204-16-100496:notes:8]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2015 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 10, 2015. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-16-100496:notes:9]
Cash and Cash Equivalents

[0001144204-16-100496:notes:10]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2016 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2016 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.


## us-gaap:ReceivablesPolicyTextBlock

[0001144204-16-100496:notes:11]
Accounts Receivable

[0001144204-16-100496:notes:12]
Accounts receivable is stated net of the reserves for doubtful accounts of $135,000 and $175,000 and for returns and other allowances of $975,000 and $1,260,000 as of March 31, 2016 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.


## us-gaap:InventoryPolicyTextBlock

[0001144204-16-100496:notes:13]
Inventories

[0001144204-16-100496:notes:14]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-16-100496:notes:15]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.

[0001144204-16-100496:notes:16]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-16-100496:notes:17]
Property, Plant, and Equipment

[0001144204-16-100496:notes:18]
Property, plant, and equipment are carried at cost less accumulated depreciation. Expenditures for maintenance and repairs are charged to expense as incurred; costs of major renewals and improvements are capitalized. At the time property and equipment are retired or otherwise disposed of, the cost and accumulated depreciation are eliminated from the asset and accumulated depreciation accounts and the profit or loss on such disposition is reflected in income.

[0001144204-16-100496:notes:19]
Depreciation is recorded over the estimated service lives of the related assets using primarily the straight-line method. Amortization of leasehold improvements is calculated by using the straight-line method over the estimated useful life of the asset or lease term, whichever is shorter.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001144204-16-100496:notes:20]
Long-Lived Assets

[0001144204-16-100496:notes:21]
Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets in question may not be recoverable. Impairment would be recorded in circumstances where undiscounted cash flows expected to be generated by an asset are less than the carrying value of that asset.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-16-100496:notes:22]
Revenue Recognition

[0001144204-16-100496:notes:23]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-16-100496:notes:24]
Income Taxes

[0001144204-16-100496:notes:25]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. The components of the deferred tax assets and liabilities are individually classified as current and non-current based on their characteristics. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-16-100496:notes:26]
Net Income Per Share

[0001144204-16-100496:notes:27]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.

[0001144204-16-100496:notes:28]
Options to purchase  165,615 and  262,000 shares of common stock for the three months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-16-100496:notes:29]
Options to purchase  147,038 and  258,583 shares of common stock for the nine months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-16-100496:notes:30]
Foreign Currency

[0001144204-16-100496:notes:31]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2016 and 2015.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001144204-16-100496:notes:32]
Comprehensive Income

[0001144204-16-100496:notes:33]
For the three and nine months ended March 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001144204-16-100496:notes:34]
Segment Reporting

[0001144204-16-100496:notes:35]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11, and no additional segment data has been presented.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001144204-16-100496:notes:36]
Shipping and Handling Revenues and Costs

[0001144204-16-100496:notes:37]
The Company records the amount billed to customers for shipping and handling in net sales ($109,000 and $117,000 in the three months ended March 31, 2016 and 2015, respectively and $365,000 and $374,000 in the nine months ended March 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($232,000 and $211,000 in the three months ended March 31, 2016 and 2015, respectively and $673,000 and $692,000 in the nine months ended March 31, 2016 and 2015, respectively).


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-16-100496:notes:38]
[same as prior period, unchanged from 0001144204-16-078240:notes:65]

[0001144204-16-100496:notes:39]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  25% of the Company’s accounts receivable at March 31, 2016 and  22% of the Company’s accounts receivable at June 30, 2015. Net sales to this customer were  13% and  11% of net sales in the three months ended March 31, 2016 and 2015, respectively. Net sales to this customer were  12% of net sales in each of the nine months ended March 31, 2016 and March 31, 2015.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-16-100496:notes:40]
[same as prior period, unchanged from 0001144204-16-078240:notes:67]

[0001144204-16-100496:notes:41]
[same as prior period, unchanged from 0001144204-16-078240:notes:68]

[0001144204-16-100496:notes:42]
[same as prior period, unchanged from 0001144204-16-078240:notes:69]

[0001144204-16-100496:notes:43]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
| Component parts |  | $ | 14,238 |  | $ | 15,037 |  |
| Work-in-process |  |  | 3,915 |  |  | 4,136 |  |
| Finished product |  |  | 7,289 |  |  | 7,697 |  |
|  |  | $ | 25,442 |  | $ | 26,870 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 20,631 |  | $ | 22,757 |  |
| Non-current |  |  | 4,811 |  |  | 4,113 |  |
|  |  | $ | 25,442 |  | $ | 26,870 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-16-100496:notes:44]
[same as prior period, unchanged from 0001144204-16-078240:notes:71]

[0001144204-16-100496:notes:45]
[same as prior period, unchanged from 0001144204-16-078240:notes:72]

[0001144204-16-100496:notes:46]
|  |  | March 31, 2016 |  | June 30, 2015 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 7,031 |  |  | 7,002 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,531 |  |  | 2,478 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 20,777 |  |  | 20,429 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 294 |  |  | 294 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 40,448 |  |  | 40,018 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 34,415 |  |  | 33,784 |  |  |  |
|  |  | $ | 6,033 |  | $ | 6,234 |  |  |  |

[0001144204-16-100496:notes:47]
Depreciation and amortization expense on property, plant, and equipment was $217,000 and $222,000 for the three months ended March 31, 2016 and 2015, respectively and $631,000 and $634,000 for the nine months ended March 31, 2016 and 2015, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-16-100496:notes:48]
[same as prior period, unchanged from 0001144204-16-078240:notes:75]

[0001144204-16-100496:notes:49]
[same as prior period, unchanged from 0001144204-16-078240:notes:76]

[0001144204-16-100496:notes:50]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of March 31, 2016 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2012 and thereafter.

[0001144204-16-100496:notes:51]
[same as prior period, unchanged from 0001144204-16-078240:notes:78]


## us-gaap:LongTermDebtTextBlock

[0001144204-16-100496:notes:52]
NOTE 6 - Long-Term Debt

[0001144204-16-100496:notes:53]
As of March 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001144204-16-100496:notes:54]
Outstanding balances and interest rates as of March 31, 2016 and June 30, 2015 are as follows:

[0001144204-16-100496:notes:55]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,500 |  |  | 1.9 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,500 |  |  | 1.9 | % | $ | 10,700 |  |  | 1.7 | % |

[0001144204-16-100496:notes:56]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-16-100496:notes:57]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-16-100496:notes:58]
[same as prior period, unchanged from 0001144204-16-078240:notes:85]

[0001144204-16-100496:notes:59]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended March 31, 2016 and 2015, the Company recorded no non-cash compensation expense relating to stock-based compensation. For the nine months ended March 31, 2016 and 2015, the Company recorded non-cash compensation expense of $92,000 ($.00 per basic and diluted share) and $101,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-16-100496:notes:60]
[same as prior period, unchanged from 0001144204-16-078240:notes:87]

[0001144204-16-100496:notes:61]
[same as prior period, unchanged from 0001144204-16-078240:notes:88]

[0001144204-16-100496:notes:62]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2016,  97,500 stock options were granted,  52,700 stock options were exercisable and  852,500 stock options were available for grant under this plan.

[0001144204-16-100496:notes:63]
The following table reflects activity under the 2012 Plan for the nine months ended March 31,:

[0001144204-16-100496:notes:64]
|  |  | 2016 |  | 2015 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 112,500 |  | $ | 5.30 |  |  | 78,500 |  | $ | 5.73 |  |
| Granted |  |  | — |  |  | — |  |  | 44,000 |  |  | 4.43 |  |
| Terminated/Lapsed |  |  | (15,000) |  |  | 4.29 |  |  | (10,000) |  |  | 4.88 |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 97,500 |  | $ | 5.46 |  |  | 112,500 |  | $ | 5.30 |  |
| Exercisable, end of period |  |  | 52,700 |  | $ | 5.56 |  |  | 27,500 |  | $ | 5.26 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 2.82 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 80,000 |  |  |  |  | $ | 78,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 38,000 |  |  |  |  | $ | 19,000 |  |  |  |  |

[0001144204-16-100496:notes:65]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at March 31, 2016:

[0001144204-16-100496:notes:66]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  |  |  |  |  |  |  |
| Range of |  | Number |  | remaining |  | Weighted average |  | Number |  | Weighted average |  |
| exercise prices |  | outstanding |  | contractual life |  | exercise price |  | exercisable |  | exercise price |  |
| $4.29-$6.31 |  |  | 97,500 |  |  | 7.9 |  | $ | 5.46 |  |  | 52,700 |  | $ | 5.56 |  |
|  |  |  | 97,500 |  |  | 7.9 |  | $ | 5.46 |  |  | 52,700 |  | $ | 5.56 |  |

[0001144204-16-100496:notes:67]
As of March 31, 2016, there was $157,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during the three or nine months ended March 31, 2016. No options vested during the either of the three months ended March 31, 2016 and 2015. The total fair value of the options vesting during the nine months ended March 31, 2016 and 2015 under this plan was $109,600 and $41,000, respectively.

[0001144204-16-100496:notes:68]
[same as prior period, unchanged from 0001144204-16-078240:notes:95]

[0001144204-16-100496:notes:69]
[same as prior period, unchanged from 0001144204-16-078240:notes:96]

[0001144204-16-100496:notes:70]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2016,  35,000 stock options were granted,  19,000 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-16-100496:notes:71]
The following table reflects activity under the 2012 Non-Employee Plan for the nine months ended March 31,:

[0001144204-16-100496:notes:72]
|  |  | 2016 |  | 2015 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Granted |  |  | — |  |  | — |  |  | 10,000 |  |  | 4.37 |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 35,000 |  | $ | 4.73 |  |  | 35,000 |  | $ | 4.73 |  |
| Exercisable, end of period |  |  | 19,000 |  | $ | 4.77 |  |  | 12,000 |  | $ | 4.80 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 2.86 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 53,000 |  |  |  |  | $ | 37,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 28,000 |  |  |  |  | $ | 12,000 |  |  |  |  |

[0001144204-16-100496:notes:73]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at March 31, 2016:

[0001144204-16-100496:notes:74]
|  |  | Options outstanding |  | Options exercisable |  |
|  |  |  |  | Weighted average |  | Weighted |  |  |  | Weighted |  |
| Range of |  | Number |  | remaining |  | average exercise |  | Number |  | average exercise |  |
| exercise prices |  | outstanding |  | contractual life |  | price |  | exercisable |  | price |  |
| $4.37 - $4.88 |  |  | 35,000 |  |  | 7.8 |  | $ | 4.73 |  |  | 19,000 |  | $ | 4.77 |  |
|  |  |  | 35,000 |  |  | 7.8 |  | $ | 4.73 |  |  | 19,000 |  | $ | 4.77 |  |

[0001144204-16-100496:notes:75]
As of March 31, 2016, there was $50,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three or nine months ended March 31, 2016. No options vested during the either of the three months ended March 31, 2016 and 2015. The total fair value of the options vesting during each of the nine months ended March 31, 2016 and 2015 under this plan was $22,000.

[0001144204-16-100496:notes:76]
[same as prior period, unchanged from 0001144204-16-078240:notes:103]

[0001144204-16-100496:notes:77]
[same as prior period, unchanged from 0001144204-16-078240:notes:104]

[0001144204-16-100496:notes:78]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At March 31, 2016,  1,471,480 stock options had been granted and  140,000 stock options were exercisable. No further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-16-100496:notes:79]
The following table reflects activity under the 2002 Employee plan for the nine months ended March 31,:

[0001144204-16-100496:notes:80]
|  |  | 2016 |  | 2015 |  |
|  |  |  |  | Weighted average |  |  |  | Weighted average |  |
|  |  | Options |  | exercise price |  | Options |  | exercise price |  |
| Outstanding, beginning of year |  |  | 208,500 |  | $ | 6.86 |  |  | 265,750 |  | $ | 6.51 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (38,500) |  |  | 11.03 |  |  | (57,250) |  |  | 5.24 |  |
| Exercised |  |  | (67,500) |  |  | 5.73 |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 102,500 |  | $ | 6.04 |  |  | 208,500 |  | $ | 6.86 |  |
| Exercisable, end of period |  |  | 102,500 |  | $ | 6.04 |  |  | 208,500 |  | $ | 6.86 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 98,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 31,000 |  |  |  |  | $ | 10,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 31,000 |  |  |  |  | $ | 10,000 |  |  |  |  |

[0001144204-16-100496:notes:81]
No stock options were exercised during either of the three months ended March 31, 2016 and 2015.  67,500 and 0 stock options were exercised during the nine months ended March 31, 2016 and 2015, respectively. All of the  67,500 exercises were settled by exchanging  53,868 shares of the Company’s common stock which were placed into Treasury Stock. No cash was received from option exercises during the three or nine months ended March 31, 2016 and 2015 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-16-100496:notes:82]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at March 31, 2016:

[0001144204-16-100496:notes:83]
|  |  | Options outstanding and exercisable |  |
| Range of |  | Number |  | Weighted average |  | Weighted average |  |
| exercise prices |  | outstanding |  | remaining contractual life |  | exercise price |  |
| $5.35 - $6.62 |  |  | 102,500 |  |  | 0.9 |  |  | 6.04 |  |
|  |  |  | 102,500 |  |  | 0.9 |  | $ | 6.04 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-16-100496:notes:84]
[same as prior period, unchanged from 0001144204-16-078240:notes:111]

[0001144204-16-100496:notes:85]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the nine months ended March 31, 2016 the Company repurchased  192,767 shares of its outstanding common stock for a weighted average price of $5.73 per share. These repurchased shares are included in the Company’s Treasury Stock as of March 31, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-16-100496:notes:86]
[same as prior period, unchanged from 0001144204-16-078240:notes:113]

[0001144204-16-100496:notes:87]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $26,000 and $27,000 for the three months ended March 31, 2016 and 2015, respectively, and $81,000 and $93,000 for the nine months ended March 31, 2016 and 2015, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-16-100496:notes:88]
NOTE 10 - Commitments and Contingencies

[0001144204-16-100496:notes:89]
Leases

[0001144204-16-100496:notes:90]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2020.

[0001144204-16-100496:notes:91]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $7,000 for the three months ended March 31, 2016 and 2015, respectively and $20,000 and $23,000 for the nine months ended March 31, 2016 and 2015, respectively.

[0001144204-16-100496:notes:92]
Land Lease

[0001144204-16-100496:notes:93]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-16-100496:notes:94]
Litigation

[0001144204-16-100496:notes:95]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-16-100496:notes:96]
Employment Agreements

[0001144204-16-100496:notes:97]
As of March 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-16-100496:notes:98]
[same as prior period, unchanged from 0001144204-16-078240:notes:125]

[0001144204-16-100496:notes:99]
[same as prior period, unchanged from 0001144204-16-078240:notes:126]

[0001144204-16-100496:notes:100]
[same as prior period, unchanged from 0001144204-16-078240:notes:127]

[0001144204-16-100496:notes:101]
|  |  | Three months ended March 31, |  | Nine months ended March 31, |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
|  |  | (in thousands) |  | (in thousands) |  |  |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 19,229 |  | $ | 17,076 |  | $ | 56,515 |  | $ | 52,523 |  |
| Foreign |  |  | 579 |  |  | 818 |  |  | 1,939 |  |  | 2,278 |  |
| Total Net Sales |  | $ | 19,808 |  | $ | 17,894 |  | $ | 58,454 |  | $ | 54,801 |  |

[0001144204-16-100496:notes:102]
|  |  | March 31, |  | June 30, |  |
| Identifiable assets: |  | 2016 |  | 2015 |  |
| United States |  | $ | 49,249 |  | $ | 50,998 |  |
| Dominican Republic (2) |  |  | 13,150 |  |  | 14,039 |  |
| Total Identifiable Assets |  | $ | 62,399 |  | $ | 65,037 |  |

[0001144204-16-100496:notes:103]
[same as prior period, unchanged from 0001144204-16-078240:notes:130]

[0001144204-16-100496:notes:104]
(2) Consists primarily of inventories (March 31, 2016 = $9,666, June 30, 2015 = $10,546) and fixed assets (March 31, 2016 = $3,244, June 30, 2015 = $3,347) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-16-100496:notes:105]
[same as prior period, unchanged from 0001144204-16-078240:notes:1]

[0001144204-16-100496:notes:106]
[same as prior period, unchanged from 0001144204-16-078240:notes:2]

[0001144204-16-100496:notes:107]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-16-100496:notes:108]
[same as prior period, unchanged from 0001144204-16-078240:notes:4]

[0001144204-16-100496:notes:109]
[same as prior period, unchanged from 0001144204-16-078240:notes:5]

[0001144204-16-100496:notes:110]
[same as prior period, unchanged from 0001144204-16-078240:notes:8]

[0001144204-16-100496:notes:111]
[same as prior period, unchanged from 0001144204-16-078240:notes:9]

[0001144204-16-100496:notes:112]
[same as prior period, unchanged from 0001144204-16-078240:notes:10]

[0001144204-16-100496:notes:113]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2016 in the amount of $7,500,000 approximates fair value.

[0001144204-16-100496:notes:114]
[same as prior period, unchanged from 0001144204-16-078240:notes:23]

[0001144204-16-100496:notes:115]
[same as prior period, unchanged from 0001144204-16-078240:notes:24]

[0001144204-16-100496:notes:116]
[same as prior period, unchanged from 0001144204-16-078240:notes:25]

[0001144204-16-100496:notes:117]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended March 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $398,000 and $500,000 for the nine months ended March 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.3 years and  13.3 years at March 31, 2016 and 2015, respectively.

[0001144204-16-100496:notes:118]
[same as prior period, unchanged from 0001144204-16-078240:notes:33]

[0001144204-16-100496:notes:119]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  6% and 8% for the three months ended March 31, 2016 and 2015, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the nine months ended March 31, 2016 and 2015, respectively.

[0001144204-16-100496:notes:120]
[same as prior period, unchanged from 0001144204-16-078240:notes:35]

[0001144204-16-100496:notes:121]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2016 and 2015 was $259,000 and $172,000, respectively. Advertising expense for the nine months ended March 31, 2016 and 2015 was $1,328,000 and $1,028,000, respectively.

[0001144204-16-100496:notes:122]
[same as prior period, unchanged from 0001144204-16-078240:notes:37]

[0001144204-16-100496:notes:123]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2016 and 2015 was $1,513,000 and $1,350,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2016 and 2015 was $4,521,000 and $3,995,000, respectively.

[0001144204-16-100496:notes:124]
[same as prior period, unchanged from 0001144204-16-078240:notes:49]

[0001144204-16-100496:notes:125]
[same as prior period, unchanged from 0001144204-16-078240:notes:50]

[0001144204-16-100496:notes:126]
[same as prior period, unchanged from 0001144204-16-078240:notes:51]

[0001144204-16-100496:notes:127]
No stock-based compensation costs were recognized for three months ended March 31, 2016 or 2015. Stock-based compensation costs of $92,000 and $101,000 were recognized for nine months ended March 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2016 and 2015.

[0001144204-16-100496:notes:128]
Recently Issued Accounting Standards

[0001144204-16-100496:notes:129]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance becomes effective for the Company’s fiscal 2018 first quarter, with early adoption permitted, and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective, or prospective).  The Company is currently evaluating the impact of applying this guidance on its consolidated financial statements.

[0001144204-16-100496:notes:130]
In February 2016, the FASB issued authoritative guidance that requires lessees to account for most leases on their balance sheets with the liability being equal to the present value of the lease payments.  The right-of-use asset will be based on the lease liability adjusted for certain costs such as direct costs.  Lease expense will be recognized similar to current accounting guidance with operating leases resulting in a straight-line expense and financing leases resulting in a front-loaded expense similar to the current accounting for capital leases.  This guidance becomes effective for the Company’s fiscal 2020 first quarter, with early adoption permitted.  This guidance must be adopted using a modified retrospective transition approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements, and provides for certain practical expedients.  The Company is currently evaluating the timing, impact and method of applying this guidance on its consolidated financial statements.

[0001144204-16-100496:notes:131]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s quarter ended September 30, 2016. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-16-100496:notes:132]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-16-100496:notes:133]
[same as prior period, unchanged from 0001144204-16-078240:notes:64]
