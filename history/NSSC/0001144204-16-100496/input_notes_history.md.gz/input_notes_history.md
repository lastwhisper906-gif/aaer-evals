# NSSC note change history — 0001144204-16-078240 → 0001144204-16-100496


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0001144204-16-100496:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $7,000 for the three months ended March 31, 2016 and 2015, respectively and $20,000 and $23,000 for the nine months ended March 31, 2016 and 2015, respectively.
  (was, 2016-02-01, similarity 0.8671):
[0001144204-16-078240:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $8,000 and $9,000 for the three months ended December 31, 2015 and 2014, respectively and $15,000 and $16,000 for the six months ended December 31, 2015 and 2014, respectively.

- changed (2016-05-10):
[0001144204-16-100496:note_history:2]
As of March 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.
  (was, 2016-02-01, similarity 0.9965):
[0001144204-16-078240:note_history:2]
As of December 31, 2015, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0001144204-16-100496:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2016 in the amount of $7,500,000 approximates fair value.
  (was, 2016-02-01, similarity 0.9758):
[0001144204-16-078240:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2015 in the amount of $7,900,000 approximates fair value.

- changed (2016-05-10):
[0001144204-16-100496:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2016 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2016 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.
  (was, 2016-02-01, similarity 0.9734):
[0001144204-16-078240:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

- changed (2016-05-10):
[0001144204-16-100496:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $135,000 and $175,000 and for returns and other allowances of $975,000 and $1,260,000 as of March 31, 2016 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2016-02-01, similarity 0.9883):
[0001144204-16-078240:note_history:5]
Accounts receivable is stated net of the reserves for doubtful accounts of $90,000 and $175,000 and for returns and other allowances of $995,000 and $1,260,000 as of December 31, 2015 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- changed (2016-05-10):
[0001144204-16-100496:note_history:6]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,212) |  | $ | 2,588 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,552) |  | $ | 8,488 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |
  (was, 2016-02-01, similarity 0.9859):
[0001144204-16-078240:note_history:6]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,082) |  | $ | 2,718 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,422) |  | $ | 8,618 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

- changed (2016-05-10):
[0001144204-16-100496:note_history:7]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended March 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $398,000 and $500,000 for the nine months ended March 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.3 years and  13.3 years at March 31, 2016 and 2015, respectively.
  (was, 2016-02-01, similarity 0.9338):
[0001144204-16-078240:note_history:7]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended December 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $268,000 and $333,000 for the six months ended December 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.6 years and  13.5 years at December 31, 2015 and 2014, respectively.

- changed (2016-05-10):
[0001144204-16-100496:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  6% and 8% for the three months ended March 31, 2016 and 2015, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the nine months ended March 31, 2016 and 2015, respectively.
  (was, 2016-02-01, similarity 0.8621):
[0001144204-16-078240:note_history:8]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the six months ended December 31, 2015 and 2014, respectively.

- changed (2016-05-10):
[0001144204-16-100496:note_history:9]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2016 and 2015 was $259,000 and $172,000, respectively. Advertising expense for the nine months ended March 31, 2016 and 2015 was $1,328,000 and $1,028,000, respectively.
  (was, 2016-02-01, similarity 0.914):
[0001144204-16-078240:note_history:9]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2015 and 2014 was $510,000 and $312,000, respectively. Advertising expense for the six months ended December 31, 2015 and 2014 was $1,068,000 and $856,000, respectively.

- changed (2016-05-10):
[0001144204-16-100496:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2016 and 2015 was $1,513,000 and $1,350,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2016 and 2015 was $4,521,000 and $3,995,000, respectively.
  (was, 2016-02-01, similarity 0.9268):
[0001144204-16-078240:note_history:10]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2015 and 2014 was $1,519,000 and $1,335,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2015 and 2014 was $3,008,000 and $2,653,000, respectively.

- changed (2016-05-10):
[0001144204-16-100496:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):
  (was, 2016-02-01, similarity 0.9738):
[0001144204-16-078240:note_history:11]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

- changed (2016-05-10):
[0001144204-16-100496:note_history:12]
Options to purchase  165,615 and  262,000 shares of common stock for the three months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2016-02-01, similarity 0.9771):
[0001144204-16-078240:note_history:12]
Options to purchase  106,000 and  368,250 shares of common stock for the three months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2016-05-10):
[0001144204-16-100496:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):
  (was, 2016-02-01, similarity 0.9588):
[0001144204-16-078240:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- changed (2016-05-10):
[0001144204-16-100496:note_history:14]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,903 |  |  | 19,225 |  | $ | 0.12 |  | $ | 0.08 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 20 |  |  | 4 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 2,335 |  | $ | 1,505 |  |  | 18,923 |  |  | 19,229 |  | $ | 0.12 |  | $ | 0.08 |  |
  (was, 2016-02-01, similarity 0.9975):
[0001144204-16-078240:note_history:14]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,948 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,971 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |

- changed (2016-05-10):
[0001144204-16-100496:note_history:15]
Options to purchase  147,038 and  258,583 shares of common stock for the nine months ended March 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2016-02-01, similarity 0.9149):
[0001144204-16-078240:note_history:15]
Options to purchase  137,750 and  256,875 shares of common stock for the six months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2016-05-10):
[0001144204-16-100496:note_history:16]
No stock-based compensation costs were recognized for three months ended March 31, 2016 or 2015. Stock-based compensation costs of $92,000 and $101,000 were recognized for nine months ended March 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2016 and 2015.

- changed (2016-05-10):
[0001144204-16-100496:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and nine months ended March 31, 2016 and 2015.
  (was, 2016-02-01, similarity 0.9442):
[0001144204-16-078240:note_history:17]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2015 and 2014.

- changed (2016-05-10):
[0001144204-16-100496:note_history:18]
For the three and nine months ended March 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.
  (was, 2016-02-01, similarity 0.9197):
[0001144204-16-078240:note_history:18]
For the three and six months ended December 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2016-05-10):
[0001144204-16-100496:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($109,000 and $117,000 in the three months ended March 31, 2016 and 2015, respectively and $365,000 and $374,000 in the nine months ended March 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($232,000 and $211,000 in the three months ended March 31, 2016 and 2015, respectively and $673,000 and $692,000 in the nine months ended March 31, 2016 and 2015, respectively).
  (was, 2016-02-01, similarity 0.8607):
[0001144204-16-078240:note_history:19]
The Company records the amount billed to customers for shipping and handling in net sales ($125,000 and $130,000 in the three months ended December 31, 2015 and 2014, respectively and $256,000 and $257,000 in the six months ended December 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($225,000 and $240,000 in the three months ended December 31, 2015 and 2014, respectively and $441,000 and $481,000 in the six months ended December 31, 2015 and 2014, respectively).

- added (2016-05-10):
[0001144204-16-100496:note_history:20]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance becomes effective for the Company’s fiscal 2018 first quarter, with early adoption permitted, and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective, or prospective).  The Company is currently evaluating the impact of applying this guidance on its consolidated financial statements.

- added (2016-05-10):
[0001144204-16-100496:note_history:21]
In February 2016, the FASB issued authoritative guidance that requires lessees to account for most leases on their balance sheets with the liability being equal to the present value of the lease payments.  The right-of-use asset will be based on the lease liability adjusted for certain costs such as direct costs.  Lease expense will be recognized similar to current accounting guidance with operating leases resulting in a straight-line expense and financing leases resulting in a front-loaded expense similar to the current accounting for capital leases.  This guidance becomes effective for the Company’s fiscal 2020 first quarter, with early adoption permitted.  This guidance must be adopted using a modified retrospective transition approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements, and provides for certain practical expedients.  The Company is currently evaluating the timing, impact and method of applying this guidance on its consolidated financial statements.

- removed (2016-05-10):
[0001144204-16-078240:note_history:22]
Stock-based compensation costs of $60,000 and $68,000 were recognized for three months ended December 31, 2015 and 2014, respectively. Stock-based compensation costs of $92,000 and $101,000 were recognized for six months ended December 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2015 and 2014.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0001144204-16-100496:note_history:23]
As of March 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.
  (was, 2016-02-01, similarity 0.9874):
[0001144204-16-078240:note_history:23]
As of December 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

- changed (2016-05-10):
[0001144204-16-100496:note_history:24]
Outstanding balances and interest rates as of March 31, 2016 and June 30, 2015 are as follows:
  (was, 2016-02-01, similarity 0.9474):
[0001144204-16-078240:note_history:24]
Outstanding balances and interest rates as of December 31, 2015 and June 30, 2015 are as follows:

- changed (2016-05-10):
[0001144204-16-100496:note_history:25]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,500 |  |  | 1.9 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,500 |  |  | 1.9 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2016-02-01, similarity 0.9809):
[0001144204-16-078240:note_history:25]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,900 |  |  | 1.8 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,900 |  |  | 1.8 | % | $ | 10,700 |  |  | 1.7 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0001144204-16-100496:note_history:26]
Outstanding balances and interest rates as of March 31, 2016 and June 30, 2015 are as follows:
  (was, 2016-02-01, similarity 0.9474):
[0001144204-16-078240:note_history:26]
Outstanding balances and interest rates as of December 31, 2015 and June 30, 2015 are as follows:

- changed (2016-05-10):
[0001144204-16-100496:note_history:27]
|  |  | March 31, 2016 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,500 |  |  | 1.9 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,500 |  |  | 1.9 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2016-02-01, similarity 0.9809):
[0001144204-16-078240:note_history:27]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,900 |  |  | 1.8 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,900 |  |  | 1.8 | % | $ | 10,700 |  |  | 1.7 | % |
