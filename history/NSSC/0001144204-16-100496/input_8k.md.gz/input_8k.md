# NSSC 8-K — 0001144204-16-100142 filed 2016-05-10

## item codes, every 8-K on or before 2016-05-10

- 2016-05-10 0001144204-16-100142 — 2.02, 9.01
- 2015-12-14 0001144204-15-070760 — 5.07
- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2016-05-10

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-16-100142:8k_2_02:1]
EX-99.1
2
v439380_ex99-1.htm
EXHIBIT 99.1

[0001144204-16-100142:8k_2_02:2]
Exhibit 99.1

[0001144204-16-100142:8k_2_02:3]
NAPCO
Announces Record Third Quarter Results for the Period Ended March 31, 2016

[0001144204-16-100142:8k_2_02:4]
-Revenue Increased 11% to a Third Quarter
Record of $19.8 Million -

[0001144204-16-100142:8k_2_02:5]
-Net Income Surged by 164%-

[0001144204-16-100142:8k_2_02:6]
-Alarm Division Recurring Revenues Grew
42% in Q3-

[0001144204-16-100142:8k_2_02:7]
-Management to Host Conference Call Today at 11 a.m. ET-

[0001144204-16-100142:8k_2_02:8]
AMITYVILLE, N.Y., May 9, 2016 -- NAPCO Security Technologies,
Inc. (NasdaqGS: NSSC), one of the world's leading solutions providers and manufacturers of high tech electronic intrusion security,
IoT connected home, video and fire systems, as well as enterprise-class access control and door locking products, today announced
financial results for its third fiscal quarter ended March 31,2016.

[0001144204-16-100142:8k_2_02:9]
Financial Highlights:

[0001144204-16-100142:8k_2_02:10]
|  | · | Net sales were a third quarter record of $19.8 million, up 11% from the same quarter last year; fourth consecutive record breaking quarterly sales. |

[0001144204-16-100142:8k_2_02:11]
|  | · | Sales of Alarm products increased 31% in the third quarter as compared to the same quarter a year ago. |

[0001144204-16-100142:8k_2_02:12]
|  | · | Alarm Division recurring monthly revenue (“RMR”) for the third quarter increased 42% compared to the same quarter a year ago and grew 10% sequentially. |

[0001144204-16-100142:8k_2_02:13]
|  | · | Net Income for the quarter increased 164% to $1,044,000 as compared to the same quarter a year ago. |

[0001144204-16-100142:8k_2_02:14]
|  | · | Earnings per share (diluted) for the third quarter was $0.06 as compared to $0.02 for the same quarter last year. |

[0001144204-16-100142:8k_2_02:15]
|  | · | Debt, net of cash, has been reduced from $36 million to $4 million since financing the Marks acquisition in August of 2008. |

[0001144204-16-100142:8k_2_02:16]
Richard Soloway, Chairman and President,
commented, “We continue to drive record quarterly sales through our strategy of marketing innovative security products aimed
at high-growth vertical markets, such as School Safety and IoT connected home. As a result, this third quarter’s 11% sales
increase to $19.8 million will mark our fourth consecutive record-breaking sales quarter. This growth is partially attributable
to a 42% surge in subscription-based RMR from our base StarLink 3G/4G, Verizon CDMA and commercial fire and intrusion alarm communicators.”

[0001144204-16-100142:8k_2_02:17]
As recently highlighted at the International
Security Conference & Exhibition ("ISC West"), the largest security industry trade show in the U.S., we announced
the addition of innovative new product entries to our successful line of StarLink® alarm and now IoT communicators. With the
launch of our new StarLink Connect product, consumers are able to control a suite of connected home, IoT services, such as alarm
system, lighting, thermostat, video camera and locking control, all via our cellular communicators.

[0001144204-16-100142:8k_2_02:18]
Also showcased at ISC West, with great
potential for generating future RMR, was the introduction of our new CA4K™ Enterprise Class Access & Video Software Platform.
This new platform provides NAPCO’s Continental Access Control division with an entry into the lucrative Hosted Services category
and enables us to provide access control as a service, to both our integrator and end-user customers, utilizing cloud-based computing.
This new access control service solution enables Continental to generate considerable levels of RMR.”

[0001144204-16-100142:8k_2_02:19]
Mr. Soloway continued, “NAPCO’s suite
of LockDown™ access control systems continues to play a significant role in protecting K-12 and college/university educational
institutions across the U.S. Integrating and networking products from our Alarm Lock, Marks and Continental divisions enable us
to wirelessly control access to and within schools, provide video monitoring and activate lock-down in seconds. To aid the School
Safety vertical in augmenting security preparedness, we created a proprietary School Access-control Vulnerability Index, or SAVI,
audit system. SAVI quantitatively measures a school’s security level in the form of an index and takes an active approach
in training security dealers and end-user school officials on how to significantly reduce or prevent a mass incident.”

[0001144204-16-100142:8k_2_02:20]
Mr. Soloway concluded, “The third quarter
was a continuation of our plan to field unique product entries in growing and profitable markets, with a special emphasis on driving
considerable levels of RMR. We will continue to build toward this vision, which bodes well for a promising future of sales and
profit growth.”

[0001144204-16-100142:8k_2_02:21]
Financial Results

[0001144204-16-100142:8k_2_02:22]
Net Sales for the three months ended March
31, 2016 increased 11% to a third quarter record of $19.8 million, as compared to $17.9 million for the same period one year ago.
Net sales for the nine months ended March 31, 2016 increased 7% to $58.4 million, as compared to $54.8 million for the same period
a year ago. Selling, general and administrative expenses for the quarter were $4.9 million, or 24.7% of sales, as compared to $4.9
million, or 27.2% of sales, for the same period last year. Selling, general and administrative expenses for the nine months ended
March 31, 2016 were $15.4 million, or 26.3% of sales, as compared to $14.9 million, or 27.2% of sales, for the same period a year
ago.

[0001144204-16-100142:8k_2_02:23]
Operating income for the three months ended March 31, 2016 increased
155% to $1,217,000, as compared to $477,000 for the third quarter of 2015. Operating income for the nine months ended March 31,
2016 increased 41% to $2,567,000, as compared to $1,819,000 for the same period a year ago. Adjusted EBITDA* for the three months
ended March 31, 2016 increased 80% to $1.6 million, or $0.08 per diluted share, as compared to $0.9 million, or $0.05 per diluted
share, for the third quarter of 2015. Adjusted EBITDA for the nine months ended March 31, 2016 increased 21% to $3.7 million, or
$0.20 per diluted share, as compared to $3.1 million, or $0.16 per diluted share, for the same period last year (*see table attached).

[0001144204-16-100142:8k_2_02:24]
Net income for the three months ended March 31, 2016 increased
164%, to $1,044,000, or $0.06 per share, as compared to $395,000, or $0.02 per share, for the same quarter last year. Net income
for the nine months ended March 31, 2016 increased 55% to $2.3 million, or $0.12 per diluted share, as compared to $1.5 million,
or $0.08 per diluted share, for the same period a year ago.

[0001144204-16-100142:8k_2_02:25]
Balance Sheet Summary

[0001144204-16-100142:8k_2_02:26]
At March 31, 2016, the Company had $3.3 million in cash and
cash equivalents, an increase of $1.0 million compared to $2.3 million at June 30, 2015. NAPCO had working capital of $34.1 million
as compared with working capital of $35.6 million at June 30, 2015. Current ratio was 5.3:1 at March 31, 2016 and 4.8:1 at June
30, 2015. Debt, net of cash, was $4.2 million at March 31, 2016 and $8.4 million at June 30, 2015.

[0001144204-16-100142:8k_2_02:27]
Conference Call Information

[0001144204-16-100142:8k_2_02:28]
Management will conduct a conference call at 11 a.m. ET today,
May 9, 2016. Interested parties may participate in the call by dialing 1-877-407-4018 or for international callers, 1-201-689-8471,
about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m.
ET on May 9, 2016 and ending on May 16, 2016 at 11:59 p.m. ET. For the replay, please dial 1-877-870-5176 domestically, or 1-858-384-5517
for international callers, and use the replay access code 13634983. In addition, the call will be webcast and will be available
on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=119088.

[0001144204-16-100142:8k_2_02:29]
About NAPCO Security Technologies, Inc.

[0001144204-16-100142:8k_2_02:30]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security (including recurring service fee revenue), IoT connected
home, video, fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and
IoT connected home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered
in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial,
institutional, residential and government applications. NAPCO products have earned a reputation for innovation, technical
excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security
market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-16-100142:8k_2_02:31]
Safe Harbor Statement

[0001144204-16-100142:8k_2_02:32]
This press release contains forward-looking statements that
involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated
in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the
Securities and Exchange Commission

[0001144204-16-100142:8k_2_02:33]
Contacts:

[0001144204-16-100142:8k_2_02:34]
Patrick McKillop

[0001144204-16-100142:8k_2_02:35]
Director of Investor Relations

[0001144204-16-100142:8k_2_02:36]
NAPCO Security Technologies, Inc.

[0001144204-16-100142:8k_2_02:37]
OP: 800-645-9445 x 374

[0001144204-16-100142:8k_2_02:38]
CP: 516-404-3597

[0001144204-16-100142:8k_2_02:39]
pmckillop@napcosecurity.com

[0001144204-16-100142:8k_2_02:40]
KCSA Strategic Communications

[0001144204-16-100142:8k_2_02:41]
Garth Russell / Todd Fromer

[0001144204-16-100142:8k_2_02:42]
OP: 212-896-1250 / 1215

[0001144204-16-100142:8k_2_02:43]
napco@kcsa.com

[0001144204-16-100142:8k_2_02:44]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-16-100142:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001144204-16-100142:8k_2_02:46]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,294 |  |  | $ | 2,346 |  |
| Accounts receivable, net of reserves and allowances |  |  | 16,137 |  |  |  | 17,994 |  |
| Inventories |  |  | 20,631 |  |  |  | 22,757 |  |
| Prepaid expenses and other current assets |  |  | 1,170 |  |  |  | 1,046 |  |
| Deferred income taxes |  |  | 857 |  |  |  | 880 |  |
| Total Current Assets |  |  | 42,089 |  |  |  | 45,023 |  |
| Inventories - non-current |  |  | 4,811 |  |  |  | 4,113 |  |
| Deferred income taxes |  |  | 818 |  |  |  | 634 |  |
| Property, plant and equipment, net |  |  | 6,033 |  |  |  | 6,234 |  |
| Intangible assets, net |  |  | 8,488 |  |  |  | 8,886 |  |
| Other assets |  |  | 160 |  |  |  | 147 |  |
| TOTAL ASSETS |  | $ | 62,399 |  |  | $ | 65,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 925 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,203 |  |  |  | 3,954 |  |
| Accrued expenses |  |  | 1,523 |  |  |  | 1,624 |  |
| Accrued salaries and wages |  |  | 2,097 |  |  |  | 2,250 |  |
| Accrued income taxes |  |  | 253 |  |  |  | 5 |  |
| Total Current Liabilities |  |  | 8,001 |  |  |  | 9,433 |  |
| Long-term debt, net of current maturities |  |  | 6,575 |  |  |  | 9,100 |  |
| Total Liabilities |  |  | 14,576 |  |  |  | 18,533 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,116,743 and 21,049,243 shares issued; and 18,786,893 and 18,966,028 shares outstanding, respectively |  |  | 211 |  |  |  | 210 |  |
| Additional paid-in capital |  |  | 16,611 |  |  |  | 16,133 |  |
| Retained earnings |  |  | 42,734 |  |  |  | 40,399 |  |
|  |  |  | 59,556 |  |  |  | 56,742 |  |
| Less: Treasury Stock, at cost (2,329,850 and 2,083,215 shares, respectively) |  |  | (11,733 | ) |  |  | (10,238 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 47,823 |  |  |  | 46,504 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 62,399 |  |  | $ | 65,037 |  |

[0001144204-16-100142:8k_2_02:47]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-16-100142:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME (unaudited)

[0001144204-16-100142:8k_2_02:49]
|  |  | Three Months ended March 31, |  |  | Nine Months ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Sales |  | $ | 19,808 |  |  | $ | 17,894 |  |  | $ | 58,454 |  |  | $ | 54,801 |  |
| Cost of sales |  |  | 13,700 |  |  |  | 12,548 |  |  |  | 40,508 |  |  |  | 38,097 |  |
| Gross Profit |  |  | 6,108 |  |  |  | 5,346 |  |  |  | 17,946 |  |  |  | 16,704 |  |
| Selling, general and administrative expenses |  |  | 4,891 |  |  |  | 4,869 |  |  |  | 15,379 |  |  |  | 14,885 |  |
| Operating income |  |  | 1,217 |  |  |  | 477 |  |  |  | 2,567 |  |  |  | 1,819 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest |  |  | 45 |  |  |  | 52 |  |  |  | 139 |  |  |  | 161 |  |
| Other, net |  |  | 3 |  |  |  | 4 |  |  |  | 10 |  |  |  | 2 |  |
| Income before taxes |  |  | 1,169 |  |  |  | 421 |  |  |  | 2,418 |  |  |  | 1,656 |  |
| Income tax expense |  |  | 125 |  |  |  | 26 |  |  |  | 83 |  |  |  | 151 |  |
| Net income |  | $ | 1,044 |  |  | $ | 395 |  |  | $ | 2,335 |  |  | $ | 1,505 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.06 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | 0.08 |  |
| Diluted |  | $ | 0.06 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | 0.08 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,811,000 |  |  |  | 19,066,000 |  |  |  | 18,903,000 |  |  |  | 19,225,000 |  |
| Diluted |  |  | 18,828,000 |  |  |  | 19,073,000 |  |  |  | 18,923,000 |  |  |  | 19,229,000 |  |

[0001144204-16-100142:8k_2_02:50]
NAPCO SECURITY TECHNOLOGIES, INC.

[0001144204-16-100142:8k_2_02:51]
NON-GAAP MEASURES OF PERFORMANCE* (Unaudited)

[0001144204-16-100142:8k_2_02:52]
(in thousands)

[0001144204-16-100142:8k_2_02:53]
|  |  | Three months ended March 31, |  |  | Nine months ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net income (GAAP) |  | $ | 1,044 |  |  | $ | 395 |  |  | $ | 2,335 |  |  | $ | 1,505 |  |
| Add back provision for income taxes |  |  | 125 |  |  |  | 26 |  |  |  | 83 |  |  |  | 151 |  |
| Add back interest and other expense |  |  | 48 |  |  |  | 56 |  |  |  | 149 |  |  |  | 163 |  |
| Operating Income (GAAP) |  |  | 1,217 |  |  |  | 477 |  |  |  | 2,567 |  |  |  | 1,819 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 131 |  |  |  | 167 |  |  |  | 398 |  |  |  | 500 |  |
| Add back stock-based compensation expense |  |  | -- |  |  |  | -- |  |  |  | 92 |  |  |  | 101 |  |
| Adjusted non-GAAP operating income |  |  | 1,348 |  |  |  | 644 |  |  |  | 3,057 |  |  |  | 2,420 |  |
| Add back depreciation and other amortization |  |  | 219 |  |  |  | 226 |  |  |  | 640 |  |  |  | 643 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,567 |  |  | $ | 870 |  |  | $ | 3,697 |  |  | $ | 3,063 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.08 |  |  | $ | 0.05 |  |  | $ | 0.20 |  |  | $ | 0.16 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,828,000 |  |  |  | 19,073,000 |  |  |  | 18,923,000 |  |  |  | 19,229,000 |  |

[0001144204-16-100142:8k_2_02:54]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.
