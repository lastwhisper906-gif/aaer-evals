# NSSC 8-K — 0001157523-13-002669 filed 2013-05-14

## item codes, every 8-K on or before 2013-09-17

- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2013-09-17

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-13-002669:8k_2_02:1]
EX-99.1
2
a50631216ex99-1.htm
EXHIBIT 99.1

[0001157523-13-002669:8k_2_02:2]
a50631216ex99-1.htm

[0001157523-13-002669:8k_2_02:3]
Exhibit 99.1

[0001157523-13-002669:8k_2_02:4]
NAPCO Reports Financial Results for Three and Nine Months Ended March 31, 2013

[0001157523-13-002669:8k_2_02:5]
-Recurring Revenue Increases; Installations of StarLink2™ Radios up 20% Sequentially-

[0001157523-13-002669:8k_2_02:6]
-Management to Host Conference Call Today at 11 a.m. ET-

[0001157523-13-002669:8k_2_02:7]
AMITYVILLE, N.Y., May 13, 2013  -- NAPCO Security Technologies, Inc. (NSSC), one of the world's leading suppliers of high performance electronic security equipment for over 30 years, today announced financial results for its third fiscal quarter ended March 31, 2013.

[0001157523-13-002669:8k_2_02:8]
Highlights:

[0001157523-13-002669:8k_2_02:9]
| · | Net sales for the quarter were $17.2 million, unchanged from the year-ago period. Gains from door-locking product revenues were offset by decreases in revenues from intrusion products and, to a lesser, extent, access control products. |
| · | Sales within the Marks brand of products grew 29% in the quarter, representing the third consecutive quarter of growth in this unit. |
| · | Sales of NAPCO's high-margin commercial locking division and recurring revenue products delivered continued growth versus a year ago with StarLink2 recurring revenues increasing 20%, sequentially. |
| · | Year-to-date (nine month) gross margins were relatively flat compared to last year (27.1% vs. 27.6%) despite $1.5 million in lower revenues due to weakness in the intrusion division and an incremental $700,000 in R&D investment in the current year. |
| · | Debt, net of cash, has been reduced by $21.0 million from $35.9 million to $14.9 million since acquiring Marks in August of 2008. $2.4 million of this reduction occurred in the past nine months. |
| · | As a result of the lower debt levels and reductions in interest rates, net interest expense for the nine months decreased by $449,000 or 51% to $440,000 as compared to $889,000 for the same period a year ago. |

[0001157523-13-002669:8k_2_02:10]
Richard Soloway, Chairman and President, stated, "For the third consecutive quarter, our Marks product line delivered a quarter of solid growth and is recovering nicely. We saw an up tick in our high-margin commercial locking division revenues as well as increases in recurring revenue from installations of StarLink2™. These gains, however, were offset by lower revenue from the Intrusion product line as demand from distributors remains temporarily subdued, owing to continued effects of 'Superstorm Sandy' in some of our key markets, the consolidation of a few large intrusion distributors and decreased demand from one of our large intrusion dealers. NAPCO's StarLink2™ wireless GSM alarm communicator continued to grow sales again this quarter, fueling the steady growth of products, which provide NAPCO with recurring revenue income. There is a strong and growing trend in the industry to install GSM-equipped signal communication versus traditional wired phone lines. We are seeing this same focus on technology in all areas of our industry and it is a primary reason we continue to invest heavily in research and development to deliver the next generation of technology-driven security products. For example, iBridge™ and iRemote™ comprise a suite of recurring revenue services, allowing consumers to remotely control their security systems, video cameras, thermostats, door locking, and lighting remotely from any smart phone or PC. Home automation is driving demand for this series of products and we are poised to benefit from this trend.

[0001157523-13-002669:8k_2_02:11]
"Looking ahead, we expect our investments in next generation access control technology to contribute to our revenues beginning in the June quarter.  In particular, we are pleased to announce that iBridge™ product shipments to dealers have now begun, and based on growing interest from distributors and installers, we expect solid sequential growth from this technologically advanced product throughout the remainder of this year and beyond. As iBridge™ begins to contribute to our Intrusion division's sales, combined with continued strength in our locking division and expected growth in our access control segment, we expect to deliver top-line growth, which should ultimately translate to even faster bottom-line expansion. As we move into the fourth fiscal quarter, historically our strongest quarter of the year, our optimism remains strong as we have the right products, supported by best-in-class technology, and the advantage of a low-cost manufacturing capability."

[0001157523-13-002669:8k_2_02:12]
Mr. Soloway concluded, "Subsequent to the end of the quarter, Continental Access Control booked a significant contract with a major university to install and integrate over 1,500 Networx wireless locks to enhance campus security and provide state-of-the-art access control. This sale, which represents the largest single order ever for Continental Access Control, and is among the largest in the history of our Company, validates our commitment to serving this important segment and we believe this could be the first of several in this growing market. We secured this contract, based on superior technology, our ability to deliver it quickly and also our ability to customize the product to meet the university's exacting architectural specifications. We are hard at work to deliver as much of this as possible in the fourth quarter, and we expect additional orders from other universities who are looking to improve on-campus security using state-of-the-art technology. As a recognized leader, we are well positioned to meet this demand."

[0001157523-13-002669:8k_2_02:13]
Fiscal Third Quarter 2013 Results

[0001157523-13-002669:8k_2_02:14]
Revenues for the three months ended March 31, 2013 were $17.2 million, unchanged compared to the same period one year ago. Revenue for the nine months ended March 31, 2013 decreased 3% to $49.6 million, compared to $51.1 million for the same period a year ago.

[0001157523-13-002669:8k_2_02:15]
Selling, general and administrative expenses for the quarter were $4.4 million, unchanged from the same period in 2012. Selling, general and administrative expenses for the nine months ended March 31, 2013 increased by $543,000 to $13.2 million, compared to $12.7 million last year. The increase was due primarily to additional sales staff, tradeshow and advertising expenditures. These investments, along with the increased expenditures in research and development, impacted NAPCO's EBITDA, as well as net and operating income, in the current periods.

[0001157523-13-002669:8k_2_02:16]
Operating income for the quarter decreased by $431,000 to $258,000 as compared to $689,000 for the same period a year ago. Operating income for the nine months decreased by $1.2 million to $213,000 as compared to $1.4 million in the same period last year.

[0001157523-13-002669:8k_2_02:17]
Adjusted EBITDA* for the three months ended March 31, 2013 decreased $493,000, or 40%, to $752,000 as compared to $1.2 million for the same period a year ago (*see table attached). Adjusted EBITDA* for the nine months ended March 31, 2013 decreased $1.4 million, or 46%, to $1.7 million as compared to $3.1 million for the same period a year ago (*see table attached).

[0001157523-13-002669:8k_2_02:18]
Net income for the quarter decreased by $192,000, or 63%, to $111,000 or $0.01 per share as compared to $303,000 or $0.02 per share for the same period last year. Net income for the nine months decreased by $633,000 to a loss of $(188,000) or $(0.01) per share as compared to net income of $445,000 or $0.02 per share for the same period last year.

[0001157523-13-002669:8k_2_02:19]
Conference Call Information

[0001157523-13-002669:8k_2_02:20]
Management will conduct a conference call at 11 a.m. today, May 13, 2013 to discuss third quarter results. Interested parties may participate in the call by dialing 877-941-4774 or for international callers, 480-629-9760, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m. ET on May 13, 2013 and ending on May 20, 2013. For the replay, please dial 877-870-5176 domestically, or 858-384-5517 for international callers, and use the replay access code, 4618377.

[0001157523-13-002669:8k_2_02:21]
In addition, the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=104662.

[0001157523-13-002669:8k_2_02:22]
About NAPCO Security Technologies, Inc.

[0001157523-13-002669:8k_2_02:23]
NAPCO Security Technologies, Inc. is one of the world's leading manufacturers of technologically advanced electronic security equipment including intrusion and fire alarm systems, access control and door locking systems. The Company consists of NAPCO plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. The products are installed by security professionals worldwide in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for technical excellence, reliability and innovation, poising the Company for growth in the rapidly expanding electronic security market, a multi-billion dollar market.

[0001157523-13-002669:8k_2_02:24]
For additional information on NAPCO, please visit the Company's web site at www.napcosecurity.com.

[0001157523-13-002669:8k_2_02:25]
This press release contains forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the Securities and Exchange Commission.

[0001157523-13-002669:8k_2_02:26]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,856 |  |  | $ | 2,979 |  |
| Accounts receivable, net of reserves and allowances |  |  | 14,532 |  |  |  | 16,408 |  |
| Inventories |  |  | 17,299 |  |  |  | 19,448 |  |
| Prepaid expenses and other current assets |  |  | 949 |  |  |  | 964 |  |
| Income tax receivable |  |  | 33 |  |  |  | -- |  |
| Deferred income taxes |  |  | 650 |  |  |  | 650 |  |
| Total Current Assets |  |  | 35,319 |  |  |  | 40,449 |  |
| Inventories - non-current |  |  | 5,129 |  |  |  | 3,834 |  |
| Deferred income taxes |  |  | 1,874 |  |  |  | 1,762 |  |
| Property, plant and equipment, net |  |  | 6,793 |  |  |  | 7,247 |  |
| Intangible assets, net |  |  | 10,563 |  |  |  | 11,251 |  |
| Other assets |  |  | 188 |  |  |  | 207 |  |
| TOTAL ASSETS |  | $ | 59,866 |  |  | $ | 64,750 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,224 |  |  |  | 3,163 |  |
| Accrued expenses |  |  | 1,054 |  |  |  | 1,814 |  |
| Accrued salaries and wages |  |  | 1,420 |  |  |  | 1,589 |  |
| Accrued income taxes |  |  | -- |  |  |  | 78 |  |
| Total Current Liabilities |  |  | 7,298 |  |  |  | 8,244 |  |
| Long-term debt, net of current maturities |  |  | 15,200 |  |  |  | 18,657 |  |
| Accrued income taxes |  |  | 154 |  |  |  | 126 |  |
| Total Liabilities |  |  | 22,652 |  |  |  | 27,027 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 20,796,813 and 20,095,713 shares issued; and 19,296,335 and 19,095,713 shares outstanding, respectively |  |  | 208 |  |  |  | 201 |  |
| Additional paid-in capital |  |  | 15,444 |  |  |  | 14,080 |  |
| Retained earnings |  |  | 28,869 |  |  |  | 29,057 |  |
|  |  |  | 44,521 |  |  |  | 43,338 |  |
| Less: Treasury Stock, at cost (1,500,478 and 1,000,000 shares, respectively) |  |  | (7,307 | ) |  |  | (5,615 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 37,214 |  |  |  | 37,723 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 59,866 |  |  | $ | 64,750 |  |

[0001157523-13-002669:8k_2_02:27]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited) |
|  |  | Three months ended March 31, |  |  | Nine months ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 17,163 |  |  | $ | 17,236 |  |  | $ | 49,591 |  |  | $ | 51,056 |  |
| Cost of sales |  |  | 12,511 |  |  |  | 12,172 |  |  |  | 36,153 |  |  |  | 36,941 |  |
| Gross Profit |  |  | 4,652 |  |  |  | 5,064 |  |  |  | 13,429 |  |  |  | 14,115 |  |
| Selling, general, and administrative expenses |  |  | 4,394 |  |  |  | 4,375 |  |  |  | 13,216 |  |  |  | 12,673 |  |
| Operating Income |  |  | 258 |  |  |  | 689 |  |  |  | 213 |  |  |  | 1,442 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 122 |  |  |  | 287 |  |  |  | 440 |  |  |  | 889 |  |
| Other, net |  |  | 3 |  |  |  | 15 |  |  |  | 10 |  |  |  | 42 |  |
|  |  |  | 125 |  |  |  | 302 |  |  |  | 450 |  |  |  | 931 |  |
| Income (Loss) before Provision (Benefit) for Income Taxes |  |  | 133 |  |  |  | 387 |  |  |  | (237 | ) |  |  | 511 |  |
| Provision (benefit)for income taxes |  |  | 22 |  |  |  | 84 |  |  |  | (49 | ) |  |  | 66 |  |
| Net Income (Loss) |  | $ | 111 |  |  | $ | 303 |  |  | $ | (188 | ) |  | $ | 445 |  |
| Net Income (Loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.01 |  |  | $ | 0.02 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
| Diluted |  | $ | 0.01 |  |  | $ | 0.02 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,296,000 |  |  |  | 19,096,000 |  |  |  | 19,181,000 |  |  |  | 19,096,000 |  |
| Diluted |  |  | 19,419,000 |  |  |  | 19,409,000 |  |  |  | 19,181,000 |  |  |  | 19,253,000 |  |

[0001157523-13-002669:8k_2_02:28]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |
|  |  | Three months ended March 31, |  |  | Nine months ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands) |  |
| Net income (loss) |  | $ | 111 |  |  | $ | 303 |  |  | $ | (188 | ) |  | $ | 445 |  |
| Add back provision (benefit) for income taxes |  |  | 22 |  |  |  | 84 |  |  |  | (49 | ) |  |  | 66 |  |
| Add back interest and other expense |  |  | 125 |  |  |  | 302 |  |  |  | 450 |  |  |  | 931 |  |
| Operating income (GAAP) |  |  | 258 |  |  |  | 689 |  |  |  | 213 |  |  |  | 1,442 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 229 |  |  |  | 266 |  |  |  | 688 |  |  |  | 799 |  |
| Add back stock-based compensation expense |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 8 |  |
| Adjusted non-GAAP operating income |  |  | 487 |  |  |  | 955 |  |  |  | 901 |  |  |  | 2,249 |  |
| Add back depreciation and other amortization |  |  | 265 |  |  |  | 290 |  |  |  | 779 |  |  |  | 839 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 752 |  |  | $ | 1,245 |  |  | $ | 1,680 |  |  | $ | 3,088 |  |

[0001157523-13-002669:8k_2_02:29]
* Non-GAAP Information. Certain non-GAAP measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not include impairment of goodwill, amortization of intangibles, changes to inventory reserves, restructuring charges, stock-based compensation expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial measures included in the above.

[0001157523-13-002669:8k_2_02:30]
INVESTOR INQUIRIES:

[0001157523-13-002669:8k_2_02:31]
Brett Maas

[0001157523-13-002669:8k_2_02:32]
Hayden IR

[0001157523-13-002669:8k_2_02:33]
(646) 536-7331

[0001157523-13-002669:8k_2_02:34]
brett@haydenir.com

[0001157523-13-002669:8k_2_02:35]
Peter Seltzberg, Regional Vice-President

[0001157523-13-002669:8k_2_02:36]
Hayden IR

[0001157523-13-002669:8k_2_02:37]
(646) 415-8972

[0001157523-13-002669:8k_2_02:38]
peter@haydenir.com

[0001157523-13-002669:8k_2_02:39]
Donald Weinberger

[0001157523-13-002669:8k_2_02:40]
Wolfe Axelrod Weinberger Assoc. LLC

[0001157523-13-002669:8k_2_02:41]
(212) 370-4500; (212) 370-4505 fax

[0001157523-13-002669:8k_2_02:42]
don@wolfeaxelrod.com
