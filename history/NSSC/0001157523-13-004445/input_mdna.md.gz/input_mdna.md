# NSSC MD&A — 0001157523-13-004445


## mdna

[0001157523-13-004445:mdna:1]
ITEM 7:  MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001157523-13-004445:mdna:2]
Overview

[0001157523-13-004445:mdna:3]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 6% and 5% of our revenues for the fiscal years ended June 30, 2013 and 2012 respectively. The increase in international sales was attributable to increased sales of the Company’s door-locking devices into Canada.

[0001157523-13-004445:mdna:4]
The Company owns and operates manufacturing facilities in Amityville, New York and the Dominican Republic. A significant portion of our operating costs are fixed, and do not fluctuate with changes in production levels or utilization of our manufacturing capacity. As production levels rise and factory utilization increases, the fixed costs are spread over increased output, which should improve profit margins. Conversely, when production levels decline our fixed costs are spread over reduced levels, thereby decreasing margins.

[0001157523-13-004445:mdna:5]
The security products market is characterized by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of annual revenues to research and development (R&D). The Company does not expect products resulting from our R&D investments in fiscal 2013 to contribute materially to revenue during this fiscal year, but should benefit the Company in future years. In general, the new products introduced by the Company are initially shipped in limited quantities, and increase over time. Prices and manufacturing costs tend to decline over time as products and technologies mature.

[0001157523-13-004445:mdna:6]
Economic and Other Factors

[0001157523-13-004445:mdna:7]
We are subject to the effects of general economic and market conditions. In the event that the U.S. or international economic conditions deteriorate, our revenue, profit and cash-flow levels could be materially adversely affected in future periods. In the event of such deterioration, many of our current or potential future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products. Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. If such events do occur, they may result in our expenses being too high in relation to our revenues and cash flows.

[0001157523-13-004445:mdna:8]
Seasonality

[0001157523-13-004445:mdna:9]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products during the spring and early summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Deterioration of the current economic conditions may also affect this seasonality.

[0001157523-13-004445:mdna:10]
Critical Accounting Policies and Estimates

[0001157523-13-004445:mdna:11]
The Company's significant accounting policies are fully described in Note 1 to the Company's consolidated financial statements included in its 2013 Annual Report on Form 10-K.  Management believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in the preparation of its consolidated financial statements.

[0001157523-13-004445:mdna:12]
Revenue Recognition

[0001157523-13-004445:mdna:13]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001157523-13-004445:mdna:14]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 6% for each of the fiscal years ended June 30, 2013 and 2012.

[0001157523-13-004445:mdna:15]
Concentration of Credit Risk

[0001157523-13-004445:mdna:16]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance.

[0001157523-13-004445:mdna:17]
The Company had two customers with accounts receivable balances that aggregated 22% of the Company’s accounts receivable at June 30, 2013 and one customer with an accounts receivable balance of 15% at June 30, 2012. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.

[0001157523-13-004445:mdna:18]
In the ordinary course of business, we have established a reserve for doubtful accounts and customer deductions in the amount of $220,000 and $200,000 as of June 30, 2013 and 2012, respectively. Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical or anticipated events.

[0001157523-13-004445:mdna:19]
Inventories

[0001157523-13-004445:mdna:20]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001157523-13-004445:mdna:21]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand.  In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage. For the fiscal years 2013 and 2012, net charges and balances in these reserves amounted to $354,000 and $3,392,000; and $504,000 and $3,038,000, respectively.

[0001157523-13-004445:mdna:22]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001157523-13-004445:mdna:23]
Intangible Assets

[0001157523-13-004445:mdna:24]
The Company evaluates its Intangible Assets for impairment at least on an annual basis. Those intangible assets that are classified as goodwill or as other intangibles with indefinite lives are not amortized.

[0001157523-13-004445:mdna:25]
Impairment testing is performed in two steps: (i) the Company determines impairment by comparing the fair value of a reporting unit with its carrying value, and (ii) if there is impairment, the Company measures the amount of impairment loss by comparing the implied fair value of intangible assets with the carrying amount of the intangible assets.

[0001157523-13-004445:mdna:26]
At the conclusion of the fiscal 2013, the Company performed its annual impairment evaluation and determined that its intangible assets were not impaired.

[0001157523-13-004445:mdna:27]
Income Taxes

[0001157523-13-004445:mdna:28]
The Company has identified the United States and New York State as its major tax jurisdictions. The fiscal 2008 and forward years are still open for examination.

[0001157523-13-004445:mdna:29]
During the year ending June 30, 2013 the Company increased its reserve for uncertain income tax positions by $27,000. As of June 30, 2013 the Company has a long-term accrued income tax liability of $153,000. The Company’s practice is to recognize interest and penalties related to income tax matters in income tax expense and accrued income taxes. As of June 30, 2013, the Company had accrued interest totaling $0 and $153,000 of unrecognized net tax benefits that, if recognized, would favorably affect the Company’s effective income tax rate in any future period.

[0001157523-13-004445:mdna:30]
For the year ended June 30, 2013, the Company recognized a net income tax expense of $187,000.

[0001157523-13-004445:mdna:31]
A reconciliation of the U.S. Federal statutory income tax rate to our actual effective tax rate on earnings before income taxes for fiscal 2013 is as follows (dollars in thousands):

[0001157523-13-004445:mdna:32]
|  |  | Amount |  |  | % of Pre-tax Income |
| Tax at the U.S. Federal statutory rate |  | $ | 1,091 |  |  |  | 34.0 | % |
| Increases (decreases) in taxes resulting from: |  |  |  |  |  |  |  |  |
| Meals and entertainment |  |  | 59 |  |  |  | 1.8 | % |
| State income taxes, net of Federal income tax benefit |  |  | 21 |  |  |  | 0.6 | % |
| Foreign source income not subject to tax |  |  | (740 | ) |  |  | (23.0 | )% |
| R&D Credits |  |  | (221 | ) |  |  | (6.9 | )% |
| Other, net |  |  | (23 | ) |  |  | (0.7 | )% |
| Effective tax rate |  | $ | 187 |  |  |  | 5.8 | % |

[0001157523-13-004445:mdna:33]
Liquidity and Capital Resources

[0001157523-13-004445:mdna:34]
The Company's cash on hand as of June 30, 2012 combined with proceeds from operating activities during fiscal 2013 were adequate to meet the Company's capital expenditure needs and debt obligations during fiscal 2013. The Company's primary internal source of liquidity is the cash flow generated from operations. The primary source of external financing is a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017. As of June 30, 2013 $5,500,000 was outstanding under this revolving line of credit. As of June 30, 2013, the Company's unused sources of funds consisted principally of $3,229,000 in cash and $5,500,000 unused balance available under its revolving line of credit.

[0001157523-13-004445:mdna:35]
During the year ended June 30, 2013 the Company utilized its cash on hand at June 30, 2012 ($2,979,000) and a portion of its cash from operations ($1,696,000 of $4,899,000) to repay outstanding debt ($3,857,000), purchase treasury stock ($435,000) and purchase property, plant and equipment ($383,000).

[0001157523-13-004445:mdna:36]
As of June 30, 2013, long-term debt consisted of the Revolving Credit Facility and two term loans (collectively the “Agreement”), one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 with the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. The Agreement also provides for a LIBOR-based interest rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus 0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and 65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement. The Company’s long-term debt is described more fully in Note 6 to the consolidated financial statements.

[0001157523-13-004445:mdna:37]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.

[0001157523-13-004445:mdna:38]
The Company believes its current working capital, anticipated cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-13-004445:mdna:39]
The Company takes into consideration several factors in measuring its liquidity, including the ratios set forth below:

[0001157523-13-004445:mdna:40]
|  | As of June 30, |  |
|  | 2013 | 2012 |  |
| Current Ratio | 4.9 to 1 | 4.9 to 1 |  |
| Sales to Receivables | 3.9 to 1 | 4.3 to 1 |  |
| Total debt to equity | .41 to 1 | .54 to 1 |  |

[0001157523-13-004445:mdna:41]
As of June 30, 2013, the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business. On April 26, 1993, the Company's foreign subsidiary entered into a 99-year land lease of approximately 4 acres of land in the Dominican Republic, on which the Company’s principle manufacturing facility is located, at an annual cost of approximately $288,000.

[0001157523-13-004445:mdna:42]
Working Capital. Working capital increased by $1,016,000 to $33,221,000 at June 30, 2013 from $32,205,000 at June 30, 2012. Working capital is calculated by deducting Current Liabilities from Current Assets.

[0001157523-13-004445:mdna:43]
Accounts Receivable. Accounts Receivable increased by $1,803,000 to $18,211,000 at June 30, 2013 as compared $16,408,000 at June 30, 2012. The increase in Accounts Receivable was due primarily to an increase in sales for the quarter ended June 30, 2013 as compared to the same quarter a year ago.

[0001157523-13-004445:mdna:44]
Inventories. Inventories, which include both current and non-current portions, decreased by $1,375,000 to $21,907,000 at June 30, 2013 as compared to $23,282,000 at June 30, 2012.  The decrease was due primarily to the Company’s improved production planning and forecasting, an increase to the obsolescence reserve of $354,000 as well as the increase in sales for the quarter ended June 30, 2013 as described above.

[0001157523-13-004445:mdna:45]
Accounts Payable and Accrued Expenses. Accounts payable and accrued expenses increased by $449,000 to $7,015,000 as of June 30, 2013 as compared to $6,566,000 at June 30, 2012.  This increase is primarily due to increased purchases of raw materials to support increased sales during the quarter ended June 30, 2013 as compared to June 30, 2012.

[0001157523-13-004445:mdna:46]
Off-Balance Sheet Arrangements

[0001157523-13-004445:mdna:47]
The Company does not maintain any off-balance sheet arrangements.

[0001157523-13-004445:mdna:48]
Contractual Obligations

[0001157523-13-004445:mdna:49]
The following table summarizes the Company's contractual obligations by fiscal year:

[0001157523-13-004445:mdna:50]
|  |  | Payments due by period: |  |
| Contractual obligations |  | Total |  |  | Less than 1 year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Long-term debt obligations |  | $ | 16,400,000 |  |  | $ | 1,600,000 |  |  | $ | 3,200,000 |  |  | $ | 7,400,000 |  |  | $ | 4,200,000 |  |
| Land lease (80 years remaining) (1) |  |  | 22,752,000 |  |  |  | 288,000 |  |  |  | 576,000 |  |  |  | 576,000 |  |  |  | 21,312,000 |  |
| Operating lease obligations |  |  | 68,000 |  |  |  | 33,000 |  |  |  | 35,000 |  |  |  | -- |  |  |  | -- |  |
| Other long-term obligations (employment agreements) (1) |  |  | 987,000 |  |  |  | 914,000 |  |  |  | 73,000 |  |  |  | -- |  |  |  | -- |  |
| Total |  | $ | 40,207,000 |  |  | $ | 2,835,000 |  |  | $ | 3,884,000 |  |  | $ | 7,976,000 |  |  | $ | 25,512,000 |  |

[0001157523-13-004445:mdna:51]
| (1) | See footnote 10 to the accompanying consolidated financial statements. |

[0001157523-13-004445:mdna:52]
Results of Operations

[0001157523-13-004445:mdna:53]
Fiscal 2013 Compared to Fiscal 2012

[0001157523-13-004445:mdna:54]
|  |  | Fiscal year ended June 30, |
|  |  | 2013 |  | 2012 |  | % Increase/ (decrease) |
| Net sales |  | $ | 71,386 |  |  | $ | 70,928 |  |  |  | 0.6 | % |
| Gross profit |  |  | 21,724 |  |  |  | 21,152 |  |  |  | 2.7 | % |
| Gross profit as a % of net sales |  |  | 30.4 | % |  |  | 29.8 | % |  |  | 2.0 | % |
| Selling, general and administrative |  |  | 17,928 |  |  |  | 17,341 |  |  |  | 3.4 | % |
| Selling, general and administrative as a % of net sales |  |  | 25.1 | % |  |  | 24.4 | % |  |  | 2.9 | % |
| Income from operations |  |  | 3,796 |  |  |  | 3,811 |  |  |  | -- | % |
| Interest expense, net |  |  | 574 |  |  |  | 1,149 |  |  |  | (50.0 | )% |
| Other expense, net |  |  | 14 |  |  |  | 109 |  |  |  | (87.2 | )% |
| Provision for income taxes |  |  | 187 |  |  |  | 267 |  |  |  | (30.0 | )% |
| Net income |  |  | 3,021 |  |  |  | 2,286 |  |  |  | 32.2 | % |

[0001157523-13-004445:mdna:55]
Net sales in fiscal 2013 increased by $458,000 to $71,386,000 as compared to $70,928,000 in fiscal 2012. The increase in net sales was primarily due to increased sales of the Company’s Marks brand door-locking products ($2,265,000), access control products ($1,137,000) and Alarm Lock brand door-locking products ($443,000) and was partially offset by decreases in the Company’s intrusion products ($3,476,000). The decrease in intrusion products was due primarily to decreased sales to a large intrusion customer as well as a slight overall decrease in demand during the earlier quarters in fiscal 2013.

[0001157523-13-004445:mdna:56]
The Company's gross profit increased by $572,000 to $21,724,000 or 30.4% of net sales in fiscal 2013 as compared to $21,152,000 or 29.8% of net sales in fiscal 2012. Gross profit and gross profit as a percentage of net sales was primarily affected by a positive shift in product mix in fiscal 2013.

[0001157523-13-004445:mdna:57]
Selling, general and administrative expenses as a percentage of net sales increased to 25.1% in fiscal 2013 from 24.4% in fiscal 2012. Selling, general and administrative expenses for fiscal 2013 increased by $587,000 to $17,928,000 as compared to $17,341,000 in fiscal 2012.  The increases in dollars and as a percentage of sales resulted primarily from increases in selling wages and commissions as well as increased advertising and tradeshow expenditures. The Company increased expenditures in these areas in order to generate higher sales.

[0001157523-13-004445:mdna:58]
Interest expense for fiscal 2013 decreased by $575,000 to $574,000 from $1,149,000 for the same period a year ago.  The decrease in interest expense is primarily the result of the decrease in interest rates charged by the Company’s primary banks as well as the Company’s reduction of its outstanding borrowings under its revolving line of credit and its term loan.

[0001157523-13-004445:mdna:59]
Other expenses decreased $95,000 to $14,000 in fiscal 2013 as compared to $109,000 in fiscal 2012. The decrease in other expense was due primarily to expenses recorded in fiscal 2012 related to the amendment of the Company’s credit agreement in June 2012.

[0001157523-13-004445:mdna:60]
The Company’s provision for income taxes for fiscal 2013 decreased by $80,000 to $187,000 as compared to $267,000 for the same period a year ago. The decrease in income taxes from fiscal 2012 to fiscal 2013 resulted primarily from increased benefits generated by the Company’s foreign manufacturing subsidiaries whose profits are not subject to income taxes.

[0001157523-13-004445:mdna:61]
Net income for fiscal 2013 increased by $735,000 to $3,021,000 as compared to $2,286,000 in fiscal 2012. This resulted primarily from the items discussed above.

[0001157523-13-004445:mdna:62]
Forward-looking Information
