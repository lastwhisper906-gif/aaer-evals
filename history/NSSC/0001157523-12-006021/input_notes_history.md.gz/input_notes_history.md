# NSSC note change history — 0001157523-12-002854 → 0001157523-12-006021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2012-11-13):
[0001157523-12-006021:note_history:1]
NOTE 10 - Commitments and Contingencies

- added (2012-11-13):
[0001157523-12-006021:note_history:2]
Leases

- added (2012-11-13):
[0001157523-12-006021:note_history:3]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $13,000 for each of  the three months ended
September 30, 2012  and 2011.

- added (2012-11-13):
[0001157523-12-006021:note_history:4]
Land
Lease

- added (2012-11-13):
[0001157523-12-006021:note_history:5]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic, at an annual cost of
approximately $288,000, on which the Company's principal production
facility is located.

- added (2012-11-13):
[0001157523-12-006021:note_history:6]
Litigation

- added (2012-11-13):
[0001157523-12-006021:note_history:7]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the settlement of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.

- added (2012-11-13):
[0001157523-12-006021:note_history:8]
Employment
Agreements

- added (2012-11-13):
[0001157523-12-006021:note_history:9]
As
of September 30, 2012, the Company was obligated under one
employment agreement and one severance agreement.  The
employment agreement is with the Company’s Chief Executive
Officer. The employment agreement provides for an annual salary of
$587,000 as adjusted for inflation, incentive compensation as may
be approved by the Board of Directors from time to time and a
termination payment in an amount up to 299% of the average of the
prior five calendar year's compensation, subject to certain
limitations, as defined in the agreement.  The employment
agreement renews annually in August unless either party gives the
other notice of non-renewal at least six months prior to the end of
the applicable term.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2012-11-13):
[0001157523-12-002854:note_history:10]
7.)   
Commitments and
Contingencies

- removed (2012-11-13):
[0001157523-12-002854:note_history:11]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the resolution of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2012-11-13):
[0001157523-12-002854:note_history:12]
1.)  
Summary
of Significant Accounting Policies and Other
Disclosures

- removed (2012-11-13):
[0001157523-12-002854:note_history:13]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the periods ended March 31, 2012 are not necessarily
indicative of results that may be expected for any other interim
period or for the full year.

- removed (2012-11-13):
[0001157523-12-002854:note_history:14]
The
unaudited Condensed Consolidated Financial Statements should be
read in conjunction with the Consolidated Financial Statements and
related notes contained in the Company’s Annual Report on
Form 10-K for the year ended June 30, 2011. The accounting policies
used in preparing these unaudited Condensed Consolidated Financial
Statements are consistent with those described in the June 30, 2011
Consolidated Financial Statements. In addition, the Condensed
Consolidated Balance Sheet as of June 30, 2011 was derived from the
audited financial statements but does not include all disclosures
required by Generally Accepted Accounting Principles
(“GAAP”).

- removed (2012-11-13):
[0001157523-12-002854:note_history:15]
The
Condensed Consolidated Financial Statements include the accounts of
Napco Security Technologies, Inc. and all of its wholly-owned
subsidiaries. All inter-company balances and transactions have been
eliminated in consolidation.

- removed (2012-11-13):
[0001157523-12-002854:note_history:16]
The
Company's fiscal year begins on July 1 and ends on June 30.
Historically, the end users of the Company's products want to
install its products prior to the summer; therefore sales of its
products historically peak in the period April 1 through June 30,
the Company's fiscal fourth quarter, and are reduced in the period
July 1 through September 30, the Company's fiscal first quarter. In
addition, demand is affected by the housing and construction
markets.

- removed (2012-11-13):
[0001157523-12-002854:note_history:17]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with, among other things, revenue recognition, reserves
for sales returns and allowances, allowance for doubtful accounts,
concentration of credit risk, inventories, intangible assets and
income taxes. Actual results could differ from those
estimates.

- removed (2012-11-13):
[0001157523-12-002854:note_history:18]
Revenue
Recognition

- removed (2012-11-13):
[0001157523-12-002854:note_history:19]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.

- removed (2012-11-13):
[0001157523-12-002854:note_history:20]
Sales
Returns and Other Allowances

- removed (2012-11-13):
[0001157523-12-002854:note_history:21]
The
Company analyzes sales returns and is able to make reasonable and
reliable estimates of product returns based on the Company’s
past history. Estimates for sales returns are based on several
factors including actual returns and based on expected return data
communicated to it by its customers. Accordingly, the Company
believes that its historical returns analysis is an accurate basis
for its allowance for sales returns. Actual results could differ
from those estimates.

- removed (2012-11-13):
[0001157523-12-002854:note_history:22]
Allowance
for Doubtful Accounts

- removed (2012-11-13):
[0001157523-12-002854:note_history:23]
In
the ordinary course of business, the Company has established a
reserve for doubtful accounts and customer deductions in the amount
of $255,000 as of March 31, 2012 and June 30, 2011. The
Company’s reserve for doubtful accounts is a subjective
critical estimate that has a direct impact on reported net
earnings. This reserve is based upon the evaluation of accounts
receivable agings, specific exposures and historical
trends.

- removed (2012-11-13):
[0001157523-12-002854:note_history:24]
Business
Concentration and Credit Risk

- removed (2012-11-13):
[0001157523-12-002854:note_history:25]
An
entity is more vulnerable to concentrations of credit risk if it is
exposed to risk of loss greater than it would have had if it
mitigated its risk through diversification of customers. Such risks
of loss manifest themselves differently, depending on the nature of
the concentration, and vary in significance.

- removed (2012-11-13):
[0001157523-12-002854:note_history:26]
The
Company had one customer with an accounts receivable balance that
represents 17% of the Company’s accounts receivable at March
31, 2012 and June 30, 2011.  Sales to this customer did
not exceed 10% of net sales in any of the past three fiscal
years.

- removed (2012-11-13):
[0001157523-12-002854:note_history:27]
Inventories

- removed (2012-11-13):
[0001157523-12-002854:note_history:28]
Inventories
are valued at the lower of cost or fair market value, with cost
being determined on the first-in, first-out (FIFO) method. The
reported net value of inventory includes finished saleable
products, work-in-process and raw materials that will be sold or
used in future periods. Inventory costs include raw materials,
direct labor and overhead. The Company’s overhead expenses
are applied based, in part, upon estimates of the proportion of
those expenses that are related to procuring and storing raw
materials as compared to the manufacture and assembly of finished
products. These proportions, the method of their application, and
the resulting overhead included in ending inventory, are based in
part on subjective estimates and actual results could differ from
those estimates.

- removed (2012-11-13):
[0001157523-12-002854:note_history:29]
In
addition, the Company records an inventory obsolescence reserve,
which represents the difference between the cost of the inventory
and its estimated market value, based on various product sales
projections. This reserve is calculated using an estimated
obsolescence percentage applied to the inventory based on age,
historical trends, requirements to support forecasted sales, and
the ability to find alternate applications of its raw materials and
to convert finished product into alternate versions of the same
product to better match customer demand.  There is
inherent professional judgment and subjectivity made by both
production and engineering members of management in determining the
estimated obsolescence percentage. In addition, and as necessary,
the Company may establish specific reserves for future known or
anticipated events.  The Company also regularly reviews
the period over which its inventories will be converted to sales.
Any inventories expected to convert to sales beyond 12 months
from the balance sheet date are classified as
non-current.

- removed (2012-11-13):
[0001157523-12-002854:note_history:30]
Long-Lived
and Intangible Assets

- removed (2012-11-13):
[0001157523-12-002854:note_history:31]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. An impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.

- removed (2012-11-13):
[0001157523-12-002854:note_history:32]
Certain
intangible assets determined to have indefinite lives are not
amortized but are tested for impairment at least annually.
Intangible assets with definite lives are amortized over their
useful lives and are reviewed for impairment at least annually at
the Company’s fiscal year end of June 30 or more often
whenever there is an indication that the carrying amount may not be
recovered.

- removed (2012-11-13):
[0001157523-12-002854:note_history:33]
Changes
in intangible assets are as follows (in thousands):

- removed (2012-11-13):
[0001157523-12-002854:note_history:34]
|  |  | March 31, 2012 |  |  | June 30, 2011 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,347 | ) |  | $ | 5,453 |  |  | $ | 9,800 |  |  | $ | (3,584 | ) |  | $ | 6,216 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (176 | ) |  |  | 164 |  |  |  | 340 |  |  |  | (140 | ) |  |  | 200 |  |
| Trademark |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (4,523 | ) |  | $ | 11,517 |  |  | $ | 16,040 |  |  | $ | (3,724 | ) |  | $ | 12,316 |  |

- removed (2012-11-13):
[0001157523-12-002854:note_history:35]
Amortization
expense for intangible assets was approximately $266,000 and
$288,000 for the three months ended March 31, 2012 and 2011,
respectively. Amortization expense for intangible assets was
approximately $799,000 and $865,000 for the nine months ended March
31, 2012 and 2011, respectively. Amortization expense for each of
the next five years is estimated to be as follows: 2012 -
$1,065,000; 2013 - $917,000; and 2014 - $781,000; 2015 - $667,000
and 2016 - $529,000. The weighted average amortization period for
intangible assets was 16.0 years and 16.7 years at March
31, 2012 and June 30, 2011, respectively.

- removed (2012-11-13):
[0001157523-12-002854:note_history:36]
Income
Taxes

- removed (2012-11-13):
[0001157523-12-002854:note_history:37]
Deferred
tax assets and liabilities are recognized for the future tax
consequences attributable to temporary differences between the
financial statement carrying amounts of existing assets and
liabilities and their respective tax bases. Deferred tax assets and
liabilities are measured using enacted tax rates expected to apply
to taxable income in the years in which those temporary differences
are expected to be recovered or settled. The effect on deferred tax
assets and liabilities of a change in tax rates is recognized in
income in the period that includes the enactment date. Deferred
income tax expense represents the change during the period in the
deferred tax assets and deferred tax liabilities. The components of
the deferred tax assets and liabilities are individually classified
as current and non-current based on their characteristics. Deferred
tax assets are reduced by a valuation allowance when, in the
opinion of management, it is more likely than not that some portion
or all of the deferred tax assets will not be realized. The Company
measures and recognizes the tax implications of positions taken or
expected to be taken in its tax returns on an ongoing
basis.

- removed (2012-11-13):
[0001157523-12-002854:note_history:38]
Advertising
and Promotional Costs

- removed (2012-11-13):
[0001157523-12-002854:note_history:39]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the condensed consolidated statements
of operations and are expensed as incurred.  Advertising
expense for the three months ended March 31, 2012 and 2011 was
$388,000 and $62,000, respectively. Advertising expense for the
nine months ended March 31, 2012 and 2011 was $871,000 and
$423,000, respectively. The increase for the three months ended
March 31, 2012 is due to the timing of a tradeshow that occurred in
March 2012 plus increased spending on media and printed
advertising. Last year, the same tradeshow occurred in the quarter
ended June 30, 2011. The increase for the nine months ended March
31, 2012 is due to increased spending on tradeshows and media and
printed advertising.

- removed (2012-11-13):
[0001157523-12-002854:note_history:40]
Research
and Development Costs

- removed (2012-11-13):
[0001157523-12-002854:note_history:41]
Research
and development costs are included in "Cost of Sales" in the
condensed consolidated statements of operations and are expensed as
incurred. Research and development expense for the three months
ended March 31, 2012 and 2011 was $1,094,000 and $935,000,
respectively. Research and development expense for the nine months
ended March 31, 2012 and 2011 was $3,134,000 and $3,420,000,
respectively.

- removed (2012-11-13):
[0001157523-12-002854:note_history:42]
Stock
Options

- removed (2012-11-13):
[0001157523-12-002854:note_history:43]
During
the three and nine months ended March 31, 2012 no stock options
were granted or exercised under its 2002 Employee Incentive Stock
Option Plan or under its 2000 Non-employee Incentive Stock Option
Plan.

- removed (2012-11-13):
[0001157523-12-002854:note_history:44]
Employee Health Benefit Plan

- removed (2012-11-13):
[0001157523-12-002854:note_history:45]
Effective March 1, 2012, the Company converted its employee health
benefit plan from a self-insured plan back to a fully-insured plan
due to the significant amounts of medical claims incurred. The
Company feels that the significant claim levels will continue and
that the cost of a fully-insured plan will be less than that of the
self-insured plan.

- removed (2012-11-13):
[0001157523-12-002854:note_history:46]
As of January 31, 2012 (the termination date of this insurance
policy) and at June 30, 2011, the aggregate limit of claims to be
self-insured was approximately $1,372,000 and $1,409,000,
respectively. Claims submitted after January 31, 2012 for services
performed prior to the commencement of the fully-insured plan on
March 1, 2012 are not covered by this insurance policy and are to
be paid by the Company. Since March 1, 2012, the Company has
incurred approximately $200,000 in these uninsured, run-out claims
in addition to the premiums incurred for the fully-insured benefit
policy. In connection with these self-insured liabilities, the
Company has accrued $296,000 and $150,000 as of March 31, 2012 and
June 30, 2011, respectively.

- removed (2012-11-13):
[0001157523-12-002854:note_history:47]
Recent Accounting Pronouncements

- removed (2012-11-13):
[0001157523-12-002854:note_history:48]
In
June 2011, the FASB amended its authoritative guidance related
to the presentation of comprehensive income, requiring entities to
present items of net income and other comprehensive income either
in one continuous statement or in two separate consecutive
statements.  This guidance becomes effective for the
Company’s fiscal 2013 first quarter.  The Company is
currently evaluating the impact of adopting this guidance but
believes that it may result only in changes in the presentation of
its financial statements and will not have a material impact on the
Company’s results of operations, financial position or cash
flows.

- removed (2012-11-13):
[0001157523-12-002854:note_history:49]
In
May 2011, the FASB amended its authoritative guidance related
to fair value measurements to provide a consistent definition and
measurement of fair value, as well as similar disclosure
requirements between U.S. GAAP and International Financial
Reporting Standards.  This guidance clarifies the application
of existing fair value measurement and expands the existing
disclosure requirements.  This guidance became effective for
the Company’s fiscal 2012 third quarter.  This guidance did not
have a material impact on the Company’s results of
operations, financial position or cash flows.

- removed (2012-11-13):
[0001157523-12-002854:note_history:50]
In December 2010, the FASB amended its
authoritative guidance related to Step 1 of the goodwill impairment
test for reporting units with zero or negative carrying
amounts.  For those reporting units, an entity is required to
perform Step 2 of the goodwill impairment test if it is
more-likely-than-not that goodwill impairment exists.  In
determining whether it is more-likely-than-not that goodwill
impairment exists, consideration should be made as to whether there
are any adverse qualitative factors indicating that an impairment
may exist.  This guidance became effective for the
Company’s fiscal 2012 first quarter.  The adoption of
this standard did not have a material impact on the Company’s
consolidated financial statements.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2012-11-13):
[0001157523-12-006021:note_history:51]
NOTE 1 - Nature of Business and Summary of Significant Accounting
Policies

- added (2012-11-13):
[0001157523-12-006021:note_history:52]
Nature
of Business

- added (2012-11-13):
[0001157523-12-006021:note_history:53]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic locking devices, intrusion and fire alarms and building
access control systems. These products are used for commercial,
residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.

- added (2012-11-13):
[0001157523-12-006021:note_history:54]
The
Company's fiscal year begins on July 1 and ends on June 30.
Historically, the end users of the Company's products want to
install its products prior to the summer; therefore sales of its
products historically peak in the period April 1 through June 30,
the Company's fiscal fourth quarter, and are reduced in the period
July 1 through September 30, the Company's fiscal first quarter. In
addition, demand is affected by the housing and construction
markets.

- added (2012-11-13):
[0001157523-12-006021:note_history:55]
Significant
Accounting Policies

- added (2012-11-13):
[0001157523-12-006021:note_history:56]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended September 30, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

- added (2012-11-13):
[0001157523-12-006021:note_history:57]
The
unaudited Condensed Consolidated Financial Statements should be
read in conjunction with the Consolidated Financial Statements and
related notes contained in the Company’s Annual Report on
Form 10-K for the year ended June 30, 2012. The accounting policies
used in preparing these unaudited Condensed Consolidated Financial
Statements are consistent with those described in the June 30, 2012
Consolidated Financial Statements. In addition, the Condensed
Consolidated Balance Sheet as of June 30, 2012 was derived from the
audited financial statements but does not include all disclosures
required by Generally Accepted Accounting Principles
(“GAAP”).

- added (2012-11-13):
[0001157523-12-006021:note_history:58]
Principles
of Consolidation

- added (2012-11-13):
[0001157523-12-006021:note_history:59]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries, including those of Marks USA I, LLC
(“Marks”), a subsidiary which acquired substantially
all of the assets and certain liabilities of G. Marks Hardware Inc.
on August 18, 2008. All inter-company balances and transactions
have been eliminated in consolidation.

- added (2012-11-13):
[0001157523-12-006021:note_history:60]
Accounting
Estimates

- added (2012-11-13):
[0001157523-12-006021:note_history:61]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, goodwill and
other intangible assets and income taxes.  Actual results
could differ from those estimates.

- added (2012-11-13):
[0001157523-12-006021:note_history:62]
Cash
and Cash Equivalents

- added (2012-11-13):
[0001157523-12-006021:note_history:63]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at September 30, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of September 30, 2012 and June 30,
2012.

- added (2012-11-13):
[0001157523-12-006021:note_history:64]
Accounts
Receivable

- added (2012-11-13):
[0001157523-12-006021:note_history:65]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$200,000 and for returns and other allowances of $1,010,000 and
$1,184,000 as of September 30, 2012 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.

- added (2012-11-13):
[0001157523-12-006021:note_history:66]
Inventories

- added (2012-11-13):
[0001157523-12-006021:note_history:67]
Inventories
are valued at the lower of cost or fair market value, with cost
being determined on the first-in, first-out (FIFO) method. The
reported net value of inventory includes finished saleable
products, work-in-process and raw materials that will be sold or
used in future periods. Inventory costs include raw materials,
direct labor and overhead. The Company’s overhead expenses
are applied based, in part, upon estimates of the amounts of those
expenses that are related to procuring and storing raw materials
and of those related to the manufacture and assembly of finished
products. These proportions, the method of their application, and
the resulting overhead included in ending inventory, are based in
part on subjective estimates and actual results could differ from
those estimates.

- added (2012-11-13):
[0001157523-12-006021:note_history:68]
In
addition, the Company records an inventory obsolescence reserve,
which represents the difference between the cost of the inventory
and its estimated market value, based on various product sales
projections. This reserve is calculated using an estimated
obsolescence percentage applied to the inventory based on age,
historical trends, requirements to support forecasted sales, and
the ability to find alternate applications of its raw materials and
to convert finished product into alternate versions of the same
product to better match customer demand.  There is
inherent professional judgment and subjectivity made by both
production and engineering members of management in determining the
estimated obsolescence percentage. In addition, and as necessary,
the Company may establish specific reserves for future known or
anticipated events. The Company also regularly reviews the period
over which its inventories will be converted to sales. Any
inventories expected to convert to sales beyond 12 months from
the balance sheet date are classified as non-current.

- added (2012-11-13):
[0001157523-12-006021:note_history:69]
Property,
Plant, and Equipment

- added (2012-11-13):
[0001157523-12-006021:note_history:70]
Property,
plant, and equipment are carried at cost less accumulated
depreciation. Expenditures for maintenance and repairs are charged
to expense as incurred; costs of major renewals and improvements
are capitalized. At the time property and equipment are retired or
otherwise disposed of, the cost and accumulated depreciation are
eliminated from the asset and accumulated depreciation accounts and
the profit or loss on such disposition is reflected in
income.

- added (2012-11-13):
[0001157523-12-006021:note_history:71]
Depreciation
is recorded over the estimated service lives of the related assets
using primarily the straight-line method.  Amortization
of leasehold improvements is calculated by using the straight-line
method over the estimated useful life of the asset or lease term,
whichever is shorter.

- added (2012-11-13):
[0001157523-12-006021:note_history:72]
Intangible
Assets

- added (2012-11-13):
[0001157523-12-006021:note_history:73]
Certain
intangible assets determined to have indefinite lives are not
amortized but are tested for impairment at least annually.
Intangible assets with definite lives are amortized over their
useful lives. Intangible assets are reviewed for impairment at
least annually at the Company’s fiscal year end of June 30 or
more often whenever there is an indication that the carrying amount
may not be recovered.

- added (2012-11-13):
[0001157523-12-006021:note_history:74]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life. At the conclusion of the quarter ended June 30,
2011, the Company performed its annual impairment evaluation and
determined that its intangible asset relating to its Marks trade
name was partially impaired. Accordingly, in the quarter ended June
30, 2011 the Company recorded an impairment charge of $400,000
which represented the excess book value of this intangible asset
over its current valuation.

- added (2012-11-13):
[0001157523-12-006021:note_history:75]
Changes
in intangible assets are as follows (in thousands):

- added (2012-11-13):
[0001157523-12-006021:note_history:76]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,818 | ) |  | $ | 4,982 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (201 | ) |  |  | 139 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,019 | ) |  | $ | 11,021 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

- added (2012-11-13):
[0001157523-12-006021:note_history:77]
Amortization
expense for intangible assets subject to amortization was
approximately $230,000 and $266,000 for the three months ended
September 30, 2012 and 2011, respectively. Amortization expense for
each of the next five fiscal years is estimated to be as follows:
2013 - $917,000; 2014 - $781,000; 2015 - $667,000; 2016 - $529,000
and 2017 - $441,000. The weighted average amortization period for
intangible assets was 15.5 years and 15.8 years at September
30, 2012 and June 30, 2012, respectively.

- added (2012-11-13):
[0001157523-12-006021:note_history:78]
Long-Lived
Assets

- added (2012-11-13):
[0001157523-12-006021:note_history:79]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. An impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.

- added (2012-11-13):
[0001157523-12-006021:note_history:80]
Revenue
Recognition

- added (2012-11-13):
[0001157523-12-006021:note_history:81]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.

- added (2012-11-13):
[0001157523-12-006021:note_history:82]
Sales
Returns and Other Allowances

- added (2012-11-13):
[0001157523-12-006021:note_history:83]
The
Company analyzes sales returns and is able to make reasonable and
reliable estimates of product returns based on the Company’s
past history. Estimates for sales returns are based on several
factors including actual returns and based on expected return data
communicated to it by its customers. Accordingly, the Company
believes that its historical returns analysis is an accurate basis
for its allowance for sales returns. Actual results could differ
from those estimates.

- added (2012-11-13):
[0001157523-12-006021:note_history:84]
Advertising
and Promotional Costs

- added (2012-11-13):
[0001157523-12-006021:note_history:85]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended September 30, 2012 and 2011 was
$427,000 and $251,000, respectively. This increase resulted
primarily from increased expenditures on a major tradeshow and
additional media advertising during the 3 months ended September
30, 2012 as compared to the same period a year ago.

- added (2012-11-13):
[0001157523-12-006021:note_history:86]
Research
and Development Costs

- added (2012-11-13):
[0001157523-12-006021:note_history:87]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended September 30, 2012 and 2011was
$1,336,000 and $1,031,000, respectively. The increase was due
primarily to expenses relating to development of the
Company’s iBridge™ tablet computer/touch screen
keypad.

- added (2012-11-13):
[0001157523-12-006021:note_history:88]
Income
Taxes

- added (2012-11-13):
[0001157523-12-006021:note_history:89]
Deferred
tax assets and liabilities are recognized for the future tax
consequences attributable to temporary differences between the
financial statement carrying amounts of existing assets and
liabilities and their respective tax bases. Deferred tax assets and
liabilities are measured using enacted tax rates expected to apply
to taxable income in the years in which those temporary differences
are expected to be recovered or settled. The effect on deferred tax
assets and liabilities of a change in tax rates is recognized in
income in the period that includes the enactment date. Deferred
income tax expense represents the change during the period in the
deferred tax assets and deferred tax liabilities. The components of
the deferred tax assets and liabilities are individually classified
as current and non-current based on their characteristics. Deferred
tax assets are reduced by a valuation allowance when, in the
opinion of management, it is more likely than not that some portion
or all of the deferred tax assets will not be realized. The Company
measures and recognizes the tax implications of positions taken or
expected to be taken in its tax returns on an ongoing
basis.

- added (2012-11-13):
[0001157523-12-006021:note_history:90]
Earnings
Per Share

- added (2012-11-13):
[0001157523-12-006021:note_history:91]
Basic
net income per common share (Basic EPS) is computed by dividing net
income by the weighted average number of common shares
outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

- added (2012-11-13):
[0001157523-12-006021:note_history:92]
The
following provides a reconciliation of information used in
calculating the per share amounts (in thousands, except per share
data):

- added (2012-11-13):
[0001157523-12-006021:note_history:93]
|  |  | Three Months Ended September 30, |  |  |  |
|  |  | Net Loss |  | Weighted Average Shares |  | Net Loss per Share |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Basic EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |

- added (2012-11-13):
[0001157523-12-006021:note_history:94]
Options
to purchase 1,383,140 and 1,410,140 shares of common stock for the
three months ended September 30, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.

- added (2012-11-13):
[0001157523-12-006021:note_history:95]
Stock-Based
Compensation

- added (2012-11-13):
[0001157523-12-006021:note_history:96]
The
Company has established two share incentive programs as discussed
in Note 8.

- added (2012-11-13):
[0001157523-12-006021:note_history:97]
Stock-based
compensation cost is measured at the grant date based on the fair
value of the award and is recognized as expense on a straight-line
basis over the vesting period. Determining the fair value of
share-based awards at the grant date requires assumptions and
judgments about expected volatility and forfeiture rates, among
other factors.

- added (2012-11-13):
[0001157523-12-006021:note_history:98]
Stock-based
compensation costs of $0 and $7,000 were recognized for the three
months ended September 30, 2012 and 2011,
respectively.

- added (2012-11-13):
[0001157523-12-006021:note_history:99]
Foreign
Currency

- added (2012-11-13):
[0001157523-12-006021:note_history:100]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal year-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three months ended September 30, 2012 and
2011.

- added (2012-11-13):
[0001157523-12-006021:note_history:101]
Comprehensive
Income

- added (2012-11-13):
[0001157523-12-006021:note_history:102]
For
the three months ended September 30, 2012 and 2011, the Company's
operations did not give rise to material items includable in
comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

- added (2012-11-13):
[0001157523-12-006021:note_history:103]
Segment
Reporting

- added (2012-11-13):
[0001157523-12-006021:note_history:104]
The
Company’s reportable operating segments are determined based
on the Company's management approach.  The management
approach is based on the way that the chief operating decision
maker organizes the segments within an enterprise for making
operating decisions and assessing performance. The Company's
results of operations are reviewed by the chief operating decision
maker on a consolidated basis and the Company operates in only one
segment.  The Company has presented required geographical
data in Note 11, and no additional segment data has been
presented.

- added (2012-11-13):
[0001157523-12-006021:note_history:105]
Shipping
and Handling Revenues and Costs

- added (2012-11-13):
[0001157523-12-006021:note_history:106]
The
Company records the amount billed to customers in net sales
($121,000 and $136,000 for the three months ended September 30,
2012 and 2011, respectively) and classifies the costs associated
with these revenues in cost of sales ($223,000 and $264,000 for the
three months ended September 30, 2012 and 2011,
respectively).

- added (2012-11-13):
[0001157523-12-006021:note_history:107]
Recently
Issued Accounting Standards

- added (2012-11-13):
[0001157523-12-006021:note_history:108]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

- added (2012-11-13):
[0001157523-12-006021:note_history:109]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-11-13):
[0001157523-12-006021:note_history:110]
NOTE 7 - Long-Term Debt
  (was, 2012-05-14, similarity 0.75):
[0001157523-12-002854:note_history:110]
5.) 
  Long Term
Debt

- added (2012-11-13):
[0001157523-12-006021:note_history:111]
As
of September 30, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

- changed (2012-11-13):
[0001157523-12-006021:note_history:112]
Outstanding
balances and interest rates as of September 30, 2012 and June 30,
2012 are as follows (dollars in thousands):
  (was, 2012-05-14, similarity 0.8308):
[0001157523-12-002854:note_history:112]
Outstanding
balances and interest rates as of March 31, 2012 and June 30, 2011
are as follows:

- changed (2012-11-13):
[0001157523-12-006021:note_history:113]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit |  | $ | 6,000 |  |  |  | 3.1 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 12,100 |  |  |  | 3.1 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 18,100 |  |  |  | 3.1 | % |  | $ | 20,257 |  |  |  | 3.1 | % |
  (was, 2012-05-14, similarity 0.9465):
[0001157523-12-002854:note_history:113]
|  |  | March 31, 2012 |  |  | June 30, 2011 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 8,600 |  |  |  | 4.87 | % |  | $ | 8,600 |  |  |  | 4.82 | % |
| Term loan |  |  | 12,498 |  |  |  | 4.86 | % |  |  | 15,177 |  |  |  | 4.82 | % |
| Total debt |  | $ | 21,098 |  |  |  | 4.86 | % |  | $ | 23,777 |  |  |  | 4.82 | % |

- added (2012-11-13):
[0001157523-12-006021:note_history:114]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, NY, equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.

- added (2012-11-13):
[0001157523-12-006021:note_history:115]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.

- removed (2012-11-13):
[0001157523-12-002854:note_history:116]
As
of March 31, 2012 and June 30, 2011, long-term debt consisted of a
revolving credit loan facility of $11,100,000, of which $8,600,000
was outstanding as of March 31, 2012 and June 30, 2011, as well as
a term loan with a remaining balance of $12,498,000 and $15,177,000
as of March 31, 2012 and June 30, 2011, respectively, as described
further below. The term loan is being repaid in 19 quarterly
installments of $893,000 each which commenced in December 2008, and
a final payment of $8,033,000 due in August 2013. The revolving
line of credit expires in August 2012 and any outstanding
borrowings are to be repaid or refinanced on or before that
time.

- removed (2012-11-13):
[0001157523-12-002854:note_history:117]
The
Company intends to extend the revolving line of credit and the term
loan prior to the expiration dates and has signed a term sheet
relating to an extension with its primary bank in May 2012.
However, because there is no guarantee that this agreement will
close, the revolving credit loan has been classified as a current
liability until such time that the Company consummates a renewal or
extension of the facility because the expiration date currently
falls within one year of the balance sheet date of March 31,
2012.

- removed (2012-11-13):
[0001157523-12-002854:note_history:118]
On
October 28, 2010, the Company entered into a Second Amended and
Restated Credit Agreement Dated as of October 28, 2010 among the
Company, as the Borrower, Capital One, N.A., as a Lender and HSBC
Bank USA, National Association as Lender, Administrative Agent and
Collateral Agent (the “Second Amended
Agreement”).  The Second Amended Agreement amended
and restated the previous term loan and revolving credit facility
and provides for a term loan of $16,070,000 and a revolving credit
facility of $11,100,000.  The Second Amended Agreement
also provides for a LIBOR interest rate option of LIBOR plus 4.5%
in addition to the existing prime option of prime plus 4.0%. The
Company’s obligations under the Second Amended Agreement
continue to be secured by the Company's headquarters in Amityville,
New York, certain other assets and the common stock of the
Company's wholly-owned subsidiaries.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2012-11-13):
[0001157523-12-006021:note_history:119]
Outstanding
balances and interest rates as of September 30, 2012 and June 30,
2012 are as follows (dollars in thousands):

- added (2012-11-13):
[0001157523-12-006021:note_history:120]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit |  | $ | 6,000 |  |  |  | 3.1 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 12,100 |  |  |  | 3.1 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 18,100 |  |  |  | 3.1 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2012-11-13):
[0001157523-12-006021:note_history:121]
Revenue
Recognition

- added (2012-11-13):
[0001157523-12-006021:note_history:122]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.
