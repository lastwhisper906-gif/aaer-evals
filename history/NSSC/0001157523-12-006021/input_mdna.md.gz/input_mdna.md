# NSSC MD&A — 0001157523-12-006021


## mdna

[0001157523-12-006021:mdna:1]
[same as prior period, unchanged from 0001157523-12-002854:mdna:1]

[0001157523-12-006021:mdna:2]
[same as prior period, unchanged from 0001157523-12-002854:mdna:2]

[0001157523-12-006021:mdna:3]
[same as prior period, unchanged from 0001157523-12-002854:mdna:3]

[0001157523-12-006021:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 6% and 5% of our revenues for the three months ended September 30, 2012 and 2011, respectively.

[0001157523-12-006021:mdna:5]
[same as prior period, unchanged from 0001157523-12-002854:mdna:5]

[0001157523-12-006021:mdna:6]
The security products market is characterized by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of revenues to research and development (R&D) on an annual basis. The Company does not expect products resulting from our R&D investments in fiscal 2013 to contribute materially to revenue during this fiscal year, but should benefit the Company over future years. In general, the new products introduced by the Company are initially shipped in limited quantities, and increase over time. Prices and manufacturing costs tend to decline over time as products and technologies mature.

[0001157523-12-006021:mdna:7]
[same as prior period, unchanged from 0001157523-12-002854:mdna:7]

[0001157523-12-006021:mdna:8]
We are subject to the effects of general economic and market conditions. Since October 2008, the U.S. and international economies have experienced a significant downturn and continue to be at depressed levels. In the event that the U.S. or international financial markets erode further, our revenue, profit and cash-flow levels could be materially adversely affected in future periods. If the worldwide economic downturn worsens, many of our current or potential future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products. Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. Furthermore, the ongoing downturn and economic uncertainty makes it difficult for us to forecast our revenues.

[0001157523-12-006021:mdna:9]
[same as prior period, unchanged from 0001157523-12-002854:mdna:9]

[0001157523-12-006021:mdna:10]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Further deterioration of the current economic conditions may also affect this trend.

[0001157523-12-006021:mdna:11]
[same as prior period, unchanged from 0001157523-12-002854:mdna:11]

[0001157523-12-006021:mdna:12]
The Company's significant accounting policies are fully described in Note 1 to the Company's consolidated financial statements included in its June 30, 2012 Annual Report on Form 10-K.  Management believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in the preparation of its consolidated financial statements.

[0001157523-12-006021:mdna:13]
[same as prior period, unchanged from 0001157523-12-002854:mdna:13]

[0001157523-12-006021:mdna:14]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured.  Revenues from merchandise sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale.  The Company reports its sales levels on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001157523-12-006021:mdna:15]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates.

[0001157523-12-006021:mdna:16]
[same as prior period, unchanged from 0001157523-12-002854:mdna:16]

[0001157523-12-006021:mdna:17]
[same as prior period, unchanged from 0001157523-12-002854:mdna:17]

[0001157523-12-006021:mdna:18]
In addition, the Company records an inventory obsolescence reserve, which represents the difference between the cost of the inventory and its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand.  There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001157523-12-006021:mdna:19]
[same as prior period, unchanged from 0001157523-12-002854:mdna:19]

[0001157523-12-006021:mdna:20]
[same as prior period, unchanged from 0001157523-12-002854:mdna:20]

[0001157523-12-006021:mdna:21]
[same as prior period, unchanged from 0001157523-12-002854:mdna:22]

[0001157523-12-006021:mdna:22]
|  |  | Three months ended September 30, (dollars in thousands) |
|  |  | 2012 |  | 2011 |  | % Increase/ (decrease) |
| Net sales |  | $ | 15,216 |  |  | $ | 16,203 |  |  |  | (6.1 | )% |
| Gross profit |  |  | 4,136 |  |  |  | 4,156 |  |  |  | (0.5 | )% |
| Gross profit as a % of net sales |  |  | 27.2 | % |  |  | 25.6 | % |  |  | 6.3 | % |
| Selling, general and administrative |  |  | 4,535 |  |  |  | 4,298 |  |  |  | 5.5 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 29.8 | % |  |  | 26.5 | % |  |  | 12.5 | % |
| Operating loss |  |  | (399 | ) |  |  | (142 | ) |  |  | 181.0 | % |
| Interest expense, net |  |  | 177 |  |  |  | 304 |  |  |  | (41.8 | )% |
| Other expense (income) |  |  | 3 |  |  |  | 14 |  |  |  | (78.6 | )% |
| Benefit for income taxes |  |  | 145 |  |  |  | 293 |  |  |  | (50.5 | )% |
| Net loss |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 159.9 | % |

[0001157523-12-006021:mdna:23]
Sales for the three months ended September 30, 2012 decreased by 6% to $15,216,000 as compared to $16,203,000 for the same period a year ago. The decrease in sales for the three months was primarily due to decreased sales in the Company’s intrusion ($1,061,000) and access control ($170,000) products as partially offset by an increase in the Company’s door-locking products ($244,000). The decrease in sales of intrusion products was due primarily to several intrusion customers reducing their inventory levels.

[0001157523-12-006021:mdna:24]
Gross profit for the three months ended September 30, 2012 remained relatively constant at $4,136,000 or 27.2% of sales as compared to $4,156,000 or 25.6% of sales for the same period a year ago. The increase in Gross profit as a percentage of sales for the three months was primarily due to a more favorable product mix as well as to the Company’s ongoing reductions in its manufacturing overhead expenses.

[0001157523-12-006021:mdna:25]
Selling, general and administrative expenses for the three months ended September 30, 2012 increased by $237,000 to $4,535,000, or 29.8% of sales, as compared to $4,298,000, or 26.5% of sales a year ago. The increase in Selling, general and administrative expenses for the three months was due primarily to increased tradeshow expenditures and additional sales staff.

[0001157523-12-006021:mdna:26]
Interest expense, net for the three months ended September 30, 2012 decreased by $127,000 to $177,000 as compared to $304,000 for the same period a year ago. The decrease in interest expense for the three months ended September 30, 2012 resulted from lower interest rates charged by the Company’s bank as well as lower outstanding debt in the current period.

[0001157523-12-006021:mdna:27]
The Company’s benefit for income taxes for the three months ended September 30, 2012 decreased by $148,000 to a benefit of $145,000 as compared to a benefit of $293,000 for the same period a year ago. The change in the provision for income taxes was caused by the change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations in the three months ended September 30, 2012 as compared to the same periods a year ago. As a result, the Company’s effective rate for income tax was 25% and 64% for the three months ended September 30, 2012 and 2011, respectively.

[0001157523-12-006021:mdna:28]
Net loss increased by $267,000 to $(434,000) or $(0.02) per diluted share for the three months ended September 30, 2012 as compared to $(167,000) or $(0.01) per diluted share for the same period a year ago. The change for the three months ended September 30, 2012 was primarily due to the items as described above.

[0001157523-12-006021:mdna:29]
[same as prior period, unchanged from 0001157523-12-002854:mdna:31]

[0001157523-12-006021:mdna:30]
During the three months ended September 30, 2012 the Company utilized all of its cash from operations ($1,570,000) and a portion of its cash on hand at June 30, 2012 ($652,000 of $2,979,000) to repay outstanding debt ($2,157,000) and purchase property, plant and equipment ($65,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-12-006021:mdna:31]
Accounts Receivable at September 30, 2012 decreased $1,859,000 to $14,549,000 as compared to $16,408,000 at June 30, 2012.  This decrease is primarily the result of the lower sales volume during the quarter ended September 30, 2012 as compared to the quarter ended June 30, 2012, which is typically the Company’s highest.

[0001157523-12-006021:mdna:32]
Inventories at September 30, 2012 remained relatively constant at $23,433,000 as compared to $23,282,000 at June 30, 2012.

[0001157523-12-006021:mdna:33]
Accounts payable and accrued expenses remained relatively constant at $6,603,000 as of September 30, 2012 as compared to $6,566,000 at June 30, 2012.

[0001157523-12-006021:mdna:34]
As of September 30, 2012, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001157523-12-006021:mdna:35]
On June 29, 2012, the Company entered into a Third Amended and Restated Credit Agreement with the Company, as the Borrower, and HSBC Bank USA, National Association as Lender, Administrative Agent and Collateral Agent (the “Agreement”).  The Agreement amended and restated the previous revolving credit facility and term loan as described above. The Agreement also provides for a LIBOR-based interest rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus 0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and 65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001157523-12-006021:mdna:36]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-12-006021:mdna:37]
As of September 30, 2012 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
