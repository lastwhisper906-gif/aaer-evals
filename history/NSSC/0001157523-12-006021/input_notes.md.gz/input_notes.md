# NSSC notes — 0001157523-12-006021


## us-gaap:IncomeTaxDisclosureTextBlock

[0001157523-12-006021:notes:1]
NOTE 6 - Income Taxes

[0001157523-12-006021:notes:2]
[same as prior period, unchanged from 0001157523-12-002854:notes:64]

[0001157523-12-006021:notes:3]
The
Company does not expect that our unrecognized tax benefits will
significantly change within the next twelve months. We file a
consolidated U.S. income tax return and tax returns in certain
state and local and foreign jurisdictions. As of September 30, 2012
we remain subject to examination in all tax jurisdictions for all
relevant jurisdictional statutes for fiscal years 2008 and
thereafter.

[0001157523-12-006021:notes:4]
The
Company has identified its U.S. Federal income tax return and its
State return in New York as its major tax jurisdictions. During the
three months ended September 30, 2012 there was no change in the
Company’s reserve for uncertain income tax positions. As a
result, as of September 30, 2012 and June 30, 2012 the Company has
a long-term accrued income tax liability of $126,000.


## us-gaap:ConsolidationPolicyTextBlock

[0001157523-12-006021:notes:5]
Principles
of Consolidation

[0001157523-12-006021:notes:6]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries, including those of Marks USA I, LLC
(“Marks”), a subsidiary which acquired substantially
all of the assets and certain liabilities of G. Marks Hardware Inc.
on August 18, 2008. All inter-company balances and transactions
have been eliminated in consolidation.


## us-gaap:InventoryDisclosureTextBlock

[0001157523-12-006021:notes:7]
NOTE 3 - Inventories

[0001157523-12-006021:notes:8]
Inventories,
net of reserves are valued at lower of cost (first-in, first-out
method) or market. The Company regularly reviews parts and finished
goods inventories on hand and, when necessary, records a provision
for excess or obsolete inventories. The Company also regularly
reviews the period over which its inventories will be converted to
sales. Any inventories expected to convert to sales beyond 12
months from the balance sheet date are classified as
non-current.

[0001157523-12-006021:notes:9]
[same as prior period, unchanged from 0001157523-12-002854:notes:61]

[0001157523-12-006021:notes:10]
|  |  | September 30, 2012 |  | June 30, 2012 |
| Component parts |  | $ | 13,240 |  |  | $ | 13,155 |  |
| Work-in-process |  |  | 3,220 |  |  |  | 3,199 |  |
| Finished product |  |  | 6,973 |  |  |  | 6,928 |  |
|  |  | $ | 23,433 |  |  | $ | 23,282 |  |
| Classification of inventories, net of reserves: |  |
| Current |  | $ | 18,698 |  |  | $ | 19,448 |  |
| Non-current |  |  | 4,735 |  |  |  | 3,834 |  |
|  |  | $ | 23,433 |  |  | $ | 23,282 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001157523-12-006021:notes:11]
Outstanding
balances and interest rates as of September 30, 2012 and June 30,
2012 are as follows (dollars in thousands):

[0001157523-12-006021:notes:12]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit |  | $ | 6,000 |  |  |  | 3.1 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 12,100 |  |  |  | 3.1 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 18,100 |  |  |  | 3.1 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001157523-12-006021:notes:13]
Significant
Accounting Policies

[0001157523-12-006021:notes:14]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended September 30, 2012 are not
necessarily indicative of results that may be expected for any
other interim period or for the full year.

[0001157523-12-006021:notes:15]
The
unaudited Condensed Consolidated Financial Statements should be
read in conjunction with the Consolidated Financial Statements and
related notes contained in the Company’s Annual Report on
Form 10-K for the year ended June 30, 2012. The accounting policies
used in preparing these unaudited Condensed Consolidated Financial
Statements are consistent with those described in the June 30, 2012
Consolidated Financial Statements. In addition, the Condensed
Consolidated Balance Sheet as of June 30, 2012 was derived from the
audited financial statements but does not include all disclosures
required by Generally Accepted Accounting Principles
(“GAAP”).


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001157523-12-006021:notes:16]
Segment
Reporting

[0001157523-12-006021:notes:17]
The
Company’s reportable operating segments are determined based
on the Company's management approach.  The management
approach is based on the way that the chief operating decision
maker organizes the segments within an enterprise for making
operating decisions and assessing performance. The Company's
results of operations are reviewed by the chief operating decision
maker on a consolidated basis and the Company operates in only one
segment.  The Company has presented required geographical
data in Note 11, and no additional segment data has been
presented.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001157523-12-006021:notes:18]
Changes
in intangible assets are as follows (in thousands):

[0001157523-12-006021:notes:19]
|  |  | September 30, 2012 |  | June 30, 2012 |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (4,818 | ) |  | $ | 4,982 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (201 | ) |  |  | 139 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,019 | ) |  | $ | 11,021 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001157523-12-006021:notes:20]
NOTE 2 - Business and Credit Concentrations

[0001157523-12-006021:notes:21]
The
Company had two customers with accounts receivable balances that
aggregated 22% of the Company’s accounts receivable at
September 30, 2012. One of these customers had an accounts
receivable balance of 11% and 15% of the Company’s accounts
receivable at September 30, 2012 and June 30, 2012, respectively.
Sales to any one customer did not exceed 10% of net sales in any of
the past three fiscal years.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001157523-12-006021:notes:22]
Property,
plant and equipment consist of the following:

[0001157523-12-006021:notes:23]
|  |  | September 30, 2012 |  | June 30, 2012 |  | Useful Life in Years |
|  |  | (in thousands) |  |  |  |
| Land |  | $ | 904 |  |  | $ | 904 |  |  | -- |
| Buildings |  |  | 8,911 |  |  |  | 8,911 |  |  | 30 to 40 |  |
| Molds and dies |  |  | 6,757 |  |  |  | 6,748 |  |  | 3 to 5 |
| Furniture and fixtures |  |  | 2,320 |  |  |  | 2,317 |  |  | 5 to 10 |
| Machinery and equipment |  |  | 19,160 |  |  |  | 19,107 |  |  | 7 to 10 |
| Leasehold improvements |  |  | 372 |  |  |  | 372 |  |  | Shorter of the lease term or life of asset |
|  |  |  | 38,424 |  |  |  | 38,359 |  |  |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 31,364 |  |  |  | 31,112 |  |  |  |  |  |
|  |  | $ | 7,060 |  |  | $ | 7,247 |  |  |  |  |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001157523-12-006021:notes:24]
Accounts
Receivable

[0001157523-12-006021:notes:25]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$200,000 and for returns and other allowances of $1,010,000 and
$1,184,000 as of September 30, 2012 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001157523-12-006021:notes:26]
NOTE 4 - Property, Plant, and Equipment

[0001157523-12-006021:notes:27]
Depreciation
and amortization expense on property, plant, and equipment was
approximately $252,000 and $257,000 for the three months ended
September 30, 2012 and 2011, respectively.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001157523-12-006021:notes:28]
Comprehensive
Income

[0001157523-12-006021:notes:29]
For
the three months ended September 30, 2012 and 2011, the Company's
operations did not give rise to material items includable in
comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001157523-12-006021:notes:30]
Shipping
and Handling Revenues and Costs

[0001157523-12-006021:notes:31]
The
Company records the amount billed to customers in net sales
($121,000 and $136,000 for the three months ended September 30,
2012 and 2011, respectively) and classifies the costs associated
with these revenues in cost of sales ($223,000 and $264,000 for the
three months ended September 30, 2012 and 2011,
respectively).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001157523-12-006021:notes:32]
NOTE 8 - Stock Options

[0001157523-12-006021:notes:33]
[same as prior period, unchanged from 0001157523-12-002854:notes:68]

[0001157523-12-006021:notes:34]
Under
the 2002 Plan, stock options have been granted to key employees
with a term of 10 years at an exercise price equal to the fair
market value on the date of grant and are exercisable in whole or
in part at 20% per year from the date of grant.  At
September 30, 2012, 1,471,480 stock options were granted, 364,520
stock options were available for grant, and 1,353,140 stock options
were exercisable under this plan.

[0001157523-12-006021:notes:35]
No
options were granted during the three months ended September 30,
2012 or 2011.

[0001157523-12-006021:notes:36]
The
following table reflects activity under the 2002 Plan for the three
months ended September 30,

[0001157523-12-006021:notes:37]
|  |  | 2012 |  | 2011 |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |
| Outstanding, beginning of period |  |  | 1,380,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | 27,000 |  |  |  | 1.76 |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 1,353,140 |  |  | $ | 2.95 |  |  |  | 1,380,140 |  |  | $ | 2.95 |  |
| Exercisable, end of period |  |  | 1,353,140 |  |  | $ | 2.95 |  |  |  | 1,372,140 |  |  | $ | 2.93 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | 36,000 |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 1,459,000 |  |  |  |  |  |  | $ | 407,000 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 1,459,000 |  |  |  |  |  |  | $ | 407,000 |  |  |  |  |  |

[0001157523-12-006021:notes:38]
27,000
options were exercised during the three months ended September 30,
2012 and no options were exercised during the three months ended
September 30, 2011. This exercise was paid for with 13,807 shares
of the Company’s common stock which was retired upon receipt.
Cash  received from option exercises for each of the
three months ended September 30, 2012 and 2011 was $0 and the
actual tax benefit realized for the tax deductions from option
exercises totaled $0 for both of these periods.

[0001157523-12-006021:notes:39]
The
following table summarizes information about stock options
outstanding under the 2002 Plan at September 30, 2012:

[0001157523-12-006021:notes:40]
|  |  | Options outstanding |  | Options exercisable |
| Range of exercise prices |  | Number outstanding at September 30, 2012 |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable at September 30, 2012 |  | Weighted average exercise price |
| $ 0.72 - $ 4.00 |  | 987,390 |  | 0.8 |  | 1.89 |  | 987,390 |  | 1.89 |
| $ 4.01 - $ 7.50 |  | 328,250 |  | 4.3 |  | 5.29 |  | 328,250 |  | 5.29 |
| $ 7.51 - $11.16 |  | 37,500 |  | 3.5 |  | 11.16 |  | 37,500 |  | 11.16 |
|  |  | 1,353,140 |  | 1.7 |  | 2.97 |  | 1,353,140 |  | 2.97 |

[0001157523-12-006021:notes:41]
As
of September 30, 2012, there was no unearned stock-based
compensation cost related to non-vested share-based compensation
arrangements granted under the 2002 Plan. All options outstanding
under the 2002 Plan were vested as of the beginning of the current
period; therefore, the total fair value of the options vested
during the three months ended September 30, 2012 under the 2002
Plan was $0.

[0001157523-12-006021:notes:42]
In
September 2000, the stockholders approved a 10 year extension of
the already existing 1990 non-employee stock option plan (the 2000
Plan) to encourage non-employee directors and consultants of the
Company to invest in the Company's stock. This plan expired in
September 2010.  No further options may be granted under
the 2000 Plan. The 2000 Plan provided for the granting of
non-qualified stock options, the exercise of which would allow up
to an aggregate of 270,000 shares of the Company's common stock to
be acquired by the holders of the stock options.  The
2000 Plan provided that the option price will not be less than 100%
of the fair market value of the stock at the date of
grant.  Outstanding options are exercisable at 20% per
year and expire five years after the date of
grant.  Compensation cost was recognized for the fair
value of the options granted to non-employee directors and
consultants as of the date of grant.

[0001157523-12-006021:notes:43]
The
following table reflects activity under the 2000 Plan for the three
months ended September 30,

[0001157523-12-006021:notes:44]
|  |  | 2012 |  | 2011 |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |
| Outstanding, beginning of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Granted |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Terminated |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Exercised |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Outstanding, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Exercisable, end of period |  |  | 30,000 |  |  | $ | 5.03 |  |  |  | 30,000 |  |  | $ | 5.03 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  |  |  | n/a |  |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 0 |  |  |  |  |  |  | $ | 0 |  |  |  |  |  |

[0001157523-12-006021:notes:45]
As
of September 30, 2012, there was no unearned stock-based
compensation cost related to non-vested share-based compensation
arrangements granted under the 2000 Plan. All options outstanding
under the 2000 Plan were vested as of the beginning of the current
period; therefore, the total fair value of the options vested
during the three months ended September 30, 2012 under the 2000
Plan was $0.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001157523-12-006021:notes:46]
Revenue
Recognition

[0001157523-12-006021:notes:47]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001157523-12-006021:notes:48]
The
following represents selected consolidated geographical
data:

[0001157523-12-006021:notes:49]
| Financial Information Relating to Domestic and Foreign Operations (in thousands) |
|  |  | Three Months ended September 30, |
|  |  | 2012 |  | 2011 |
| Sales to external customers(1): |  |  |  |  |  |  |
| Domestic |  | $ | 14,265 |  |  | $ | 15,329 |  |
| Foreign |  |  | 951 |  |  |  | 874 |  |
| Total Net Sales |  | $ | 15,216 |  |  | $ | 16,203 |  |
|  |  | As of |
|  |  | September 30, 2012 |  | June 30, 2012 |
| Identifiable assets: |  |  |  |  |  |  |  |  |
| United States |  | $ | 48,324 |  |  | $ | 50,838 |  |
| Dominican Republic (2) |  |  | 13,794 |  |  |  | 13,912 |  |
| Total Identifiable Assets |  | $ | 62,118 |  |  | $ | 64,750 |  |

[0001157523-12-006021:notes:50]
(1)
All of the Company's sales originate in the United States and are
shipped primarily from the Company's facilities in the United
States. There were no sales into any one foreign country in excess
of 10% of total Net Sales.

[0001157523-12-006021:notes:51]
(2)
Consists primarily of inventories (September 30, 2012 = $9,926,000;
June 30, 2012 = $9,866,000) and fixed assets (September 30, 2012 =
$3,823,000; June 30, 2012 = $3,936,000) located at the Company's
principal manufacturing facility in the Dominican
Republic.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001157523-12-006021:notes:52]
Recently
Issued Accounting Standards

[0001157523-12-006021:notes:53]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

[0001157523-12-006021:notes:54]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:IncomeTaxPolicyTextBlock

[0001157523-12-006021:notes:55]
Income
Taxes

[0001157523-12-006021:notes:56]
Deferred
tax assets and liabilities are recognized for the future tax
consequences attributable to temporary differences between the
financial statement carrying amounts of existing assets and
liabilities and their respective tax bases. Deferred tax assets and
liabilities are measured using enacted tax rates expected to apply
to taxable income in the years in which those temporary differences
are expected to be recovered or settled. The effect on deferred tax
assets and liabilities of a change in tax rates is recognized in
income in the period that includes the enactment date. Deferred
income tax expense represents the change during the period in the
deferred tax assets and deferred tax liabilities. The components of
the deferred tax assets and liabilities are individually classified
as current and non-current based on their characteristics. Deferred
tax assets are reduced by a valuation allowance when, in the
opinion of management, it is more likely than not that some portion
or all of the deferred tax assets will not be realized. The Company
measures and recognizes the tax implications of positions taken or
expected to be taken in its tax returns on an ongoing
basis.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001157523-12-006021:notes:57]
NOTE 10 - Commitments and Contingencies

[0001157523-12-006021:notes:58]
Leases

[0001157523-12-006021:notes:59]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $13,000 for each of  the three months ended
September 30, 2012  and 2011.

[0001157523-12-006021:notes:60]
Land
Lease

[0001157523-12-006021:notes:61]
On
April 26, 1993, one of the Company's foreign subsidiaries entered
into a 99 year lease, expiring in 2092, for approximately four
acres of land in the Dominican Republic, at an annual cost of
approximately $288,000, on which the Company's principal production
facility is located.

[0001157523-12-006021:notes:62]
Litigation

[0001157523-12-006021:notes:63]
In
the normal course of business, the Company is a party to claims
and/or litigation. Management believes that the settlement of such
claims and/or litigation, considered in the aggregate, will not
have a material adverse effect on the Company's financial position
and results of operations.

[0001157523-12-006021:notes:64]
Employment
Agreements

[0001157523-12-006021:notes:65]
As
of September 30, 2012, the Company was obligated under one
employment agreement and one severance agreement.  The
employment agreement is with the Company’s Chief Executive
Officer. The employment agreement provides for an annual salary of
$587,000 as adjusted for inflation, incentive compensation as may
be approved by the Board of Directors from time to time and a
termination payment in an amount up to 299% of the average of the
prior five calendar year's compensation, subject to certain
limitations, as defined in the agreement.  The employment
agreement renews annually in August unless either party gives the
other notice of non-renewal at least six months prior to the end of
the applicable term.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001157523-12-006021:notes:66]
Long-Lived
Assets

[0001157523-12-006021:notes:67]
Long-lived
assets are reviewed for impairment whenever events or changes in
circumstances indicate that the carrying amount of the assets in
question may not be recoverable. An impairment would be recorded in
circumstances where undiscounted cash flows expected to be
generated by an asset are less than the carrying value of that
asset.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001157523-12-006021:notes:68]
Foreign
Currency

[0001157523-12-006021:notes:69]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal year-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three months ended September 30, 2012 and
2011.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001157523-12-006021:notes:70]
Earnings
Per Share

[0001157523-12-006021:notes:71]
Basic
net income per common share (Basic EPS) is computed by dividing net
income by the weighted average number of common shares
outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

[0001157523-12-006021:notes:72]
The
following provides a reconciliation of information used in
calculating the per share amounts (in thousands, except per share
data):

[0001157523-12-006021:notes:73]
|  |  | Three Months Ended September 30, |  |  |  |
|  |  | Net Loss |  | Weighted Average Shares |  | Net Loss per Share |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Basic EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (434 | ) |  | $ | (167 | ) |  |  | 19,097 |  |  |  | 19,096 |  |  | $ | (0.02 | ) |  | $ | (0.01 | ) |

[0001157523-12-006021:notes:74]
Options
to purchase 1,383,140 and 1,410,140 shares of common stock for the
three months ended September 30, 2012 and 2011, respectively, were
not included in the computation of Diluted EPS because their
inclusion would be anti-dilutive.  These options were
still outstanding at the end of the respective
periods.


## us-gaap:InventoryPolicyTextBlock

[0001157523-12-006021:notes:75]
Inventories

[0001157523-12-006021:notes:76]
Inventories
are valued at the lower of cost or fair market value, with cost
being determined on the first-in, first-out (FIFO) method. The
reported net value of inventory includes finished saleable
products, work-in-process and raw materials that will be sold or
used in future periods. Inventory costs include raw materials,
direct labor and overhead. The Company’s overhead expenses
are applied based, in part, upon estimates of the amounts of those
expenses that are related to procuring and storing raw materials
and of those related to the manufacture and assembly of finished
products. These proportions, the method of their application, and
the resulting overhead included in ending inventory, are based in
part on subjective estimates and actual results could differ from
those estimates.

[0001157523-12-006021:notes:77]
In
addition, the Company records an inventory obsolescence reserve,
which represents the difference between the cost of the inventory
and its estimated market value, based on various product sales
projections. This reserve is calculated using an estimated
obsolescence percentage applied to the inventory based on age,
historical trends, requirements to support forecasted sales, and
the ability to find alternate applications of its raw materials and
to convert finished product into alternate versions of the same
product to better match customer demand.  There is
inherent professional judgment and subjectivity made by both
production and engineering members of management in determining the
estimated obsolescence percentage. In addition, and as necessary,
the Company may establish specific reserves for future known or
anticipated events. The Company also regularly reviews the period
over which its inventories will be converted to sales. Any
inventories expected to convert to sales beyond 12 months from
the balance sheet date are classified as non-current.


## us-gaap:LongTermDebtTextBlock

[0001157523-12-006021:notes:78]
NOTE 7 - Long-Term Debt

[0001157523-12-006021:notes:79]
As
of September 30, 2012, long-term debt consisted of a revolving
credit facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

[0001157523-12-006021:notes:80]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, NY, equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.

[0001157523-12-006021:notes:81]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001157523-12-006021:notes:82]
Property,
Plant, and Equipment

[0001157523-12-006021:notes:83]
Property,
plant, and equipment are carried at cost less accumulated
depreciation. Expenditures for maintenance and repairs are charged
to expense as incurred; costs of major renewals and improvements
are capitalized. At the time property and equipment are retired or
otherwise disposed of, the cost and accumulated depreciation are
eliminated from the asset and accumulated depreciation accounts and
the profit or loss on such disposition is reflected in
income.

[0001157523-12-006021:notes:84]
Depreciation
is recorded over the estimated service lives of the related assets
using primarily the straight-line method.  Amortization
of leasehold improvements is calculated by using the straight-line
method over the estimated useful life of the asset or lease term,
whichever is shorter.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001157523-12-006021:notes:85]
Cash
and Cash Equivalents

[0001157523-12-006021:notes:86]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at September 30, 2012 and June 30,
2012.  The Company considers all highly liquid
investments with original maturities of three months or less to be
cash equivalents.  The Company has cash balances in banks
in excess of the maximum amount insured by the FDIC and other
international agencies as of September 30, 2012 and June 30,
2012.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001157523-12-006021:notes:87]
NOTE 5 – Acquisition of Business

[0001157523-12-006021:notes:88]
On
August 18, 2008, the Company acquired substantially all of the
assets and business of Marks for $25.2 million in cash, the
repayment of $1 million of bank debt and the assumption of current
liabilities. The Marks business involves the manufacturing and
distribution of door-locking devices. The Company funded the
acquisition with a term loan from its lenders, which has since been
amended as described in Note 7.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001157523-12-006021:notes:89]
NOTE 1 - Nature of Business and Summary of Significant Accounting
Policies

[0001157523-12-006021:notes:90]
Nature
of Business

[0001157523-12-006021:notes:91]
Napco
Security Technologies, Inc. and Subsidiaries (the "Company") is a
diversified manufacturer of security products, encompassing
electronic locking devices, intrusion and fire alarms and building
access control systems. These products are used for commercial,
residential, institutional, industrial and governmental
applications, and are sold worldwide principally to independent
distributors, dealers and installers of security
equipment.

[0001157523-12-006021:notes:92]
The
Company's fiscal year begins on July 1 and ends on June 30.
Historically, the end users of the Company's products want to
install its products prior to the summer; therefore sales of its
products historically peak in the period April 1 through June 30,
the Company's fiscal fourth quarter, and are reduced in the period
July 1 through September 30, the Company's fiscal first quarter. In
addition, demand is affected by the housing and construction
markets.

[0001157523-12-006021:notes:93]
Accounting
Estimates

[0001157523-12-006021:notes:94]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities and disclosure of
contingent gains and losses at the date of the financial statements
and the reported amounts of revenues and expenses during the
reporting period. Critical estimates include management's judgments
associated with revenue recognition, reserves for sales returns and
allowances, concentration of credit risk, inventories, goodwill and
other intangible assets and income taxes.  Actual results
could differ from those estimates.

[0001157523-12-006021:notes:95]
Intangible
Assets

[0001157523-12-006021:notes:96]
Certain
intangible assets determined to have indefinite lives are not
amortized but are tested for impairment at least annually.
Intangible assets with definite lives are amortized over their
useful lives. Intangible assets are reviewed for impairment at
least annually at the Company’s fiscal year end of June 30 or
more often whenever there is an indication that the carrying amount
may not be recovered.

[0001157523-12-006021:notes:97]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets with a fair
value of $16,440,000 on the date of acquisition. The intangible
assets are amortized over their estimated useful lives of twenty
years (customer relationships) and seven years (non-compete
agreement). The Marks USA trade name was deemed to have an
indefinite life. At the conclusion of the quarter ended June 30,
2011, the Company performed its annual impairment evaluation and
determined that its intangible asset relating to its Marks trade
name was partially impaired. Accordingly, in the quarter ended June
30, 2011 the Company recorded an impairment charge of $400,000
which represented the excess book value of this intangible asset
over its current valuation.

[0001157523-12-006021:notes:98]
Amortization
expense for intangible assets subject to amortization was
approximately $230,000 and $266,000 for the three months ended
September 30, 2012 and 2011, respectively. Amortization expense for
each of the next five fiscal years is estimated to be as follows:
2013 - $917,000; 2014 - $781,000; 2015 - $667,000; 2016 - $529,000
and 2017 - $441,000. The weighted average amortization period for
intangible assets was 15.5 years and 15.8 years at September
30, 2012 and June 30, 2012, respectively.

[0001157523-12-006021:notes:99]
Sales
Returns and Other Allowances

[0001157523-12-006021:notes:100]
The
Company analyzes sales returns and is able to make reasonable and
reliable estimates of product returns based on the Company’s
past history. Estimates for sales returns are based on several
factors including actual returns and based on expected return data
communicated to it by its customers. Accordingly, the Company
believes that its historical returns analysis is an accurate basis
for its allowance for sales returns. Actual results could differ
from those estimates.

[0001157523-12-006021:notes:101]
Advertising
and Promotional Costs

[0001157523-12-006021:notes:102]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended September 30, 2012 and 2011 was
$427,000 and $251,000, respectively. This increase resulted
primarily from increased expenditures on a major tradeshow and
additional media advertising during the 3 months ended September
30, 2012 as compared to the same period a year ago.

[0001157523-12-006021:notes:103]
Research
and Development Costs

[0001157523-12-006021:notes:104]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended September 30, 2012 and 2011was
$1,336,000 and $1,031,000, respectively. The increase was due
primarily to expenses relating to development of the
Company’s iBridge™ tablet computer/touch screen
keypad.

[0001157523-12-006021:notes:105]
Stock-Based
Compensation

[0001157523-12-006021:notes:106]
The
Company has established two share incentive programs as discussed
in Note 8.

[0001157523-12-006021:notes:107]
Stock-based
compensation cost is measured at the grant date based on the fair
value of the award and is recognized as expense on a straight-line
basis over the vesting period. Determining the fair value of
share-based awards at the grant date requires assumptions and
judgments about expected volatility and forfeiture rates, among
other factors.

[0001157523-12-006021:notes:108]
Stock-based
compensation costs of $0 and $7,000 were recognized for the three
months ended September 30, 2012 and 2011,
respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001157523-12-006021:notes:109]
NOTE 9 - 401(k) Plan

[0001157523-12-006021:notes:110]
The
Company maintains two 401(k) plans (“the Napco Plan”
and “the Marks Plan”) that cover all U.S. non-union
employees with one or more years of service and is qualified under
Sections 401(a) and 401(k) of the Internal Revenue Code. Company
contributions to this plan are discretionary and totaled $21,000
and $0 for the three months ended September 30, 2012 and 2011,
respectively. The Marks Plan was adopted by the Company subsequent
to the Marks acquisition in August 2008 and provides for
discretionary matching contributions. Company contributions to this
plan were $1,000 and $0 for the three months ended September 30,
2012 and 2011, respectively.


## nssc:GeographicalDataDisclosureTextBlock

[0001157523-12-006021:notes:111]
NOTE 11 - Geographical Data

[0001157523-12-006021:notes:112]
The
Company is engaged in one major line of business: the development,
manufacture, and distribution of security alarm products and door
security devices for commercial and residential
use.  Sales to unaffiliated customers are primarily
shipped from the United States. The Company has customers worldwide
with major concentrations in North America, Europe, and South
America.
