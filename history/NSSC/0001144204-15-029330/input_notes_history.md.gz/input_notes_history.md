# NSSC note change history — 0001144204-15-007097 → 0001144204-15-029330


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-11):
[0001144204-15-029330:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended March 31, 2015 and 2014, respectively and $23,000 and $25,000 for the nine months ended March 31, 2015 and 2014, respectively.
  (was, 2015-02-09, similarity 0.8671):
[0001144204-15-007097:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $9,000 and $9,000 for the three months ended December 31, 2014 and 2013, respectively and $16,000 and $18,000 for the six months ended December 31, 2014 and 2013, respectively.

- changed (2015-05-11):
[0001144204-15-029330:note_history:2]
As of March 31, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.
  (was, 2015-02-09, similarity 0.8531):
[0001144204-15-007097:note_history:2]
As of December 31, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-05-11):
[0001144204-15-029330:note_history:3]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

- changed (2015-05-11):
[0001144204-15-029330:note_history:4]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated.
  (was, 2015-02-09, similarity 0.905):
[0001144204-15-007097:note_history:4]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated. Certain prior period amounts relating to credit card fees have been reclassified for consistency with the current period presentation. The reclassification did not have an impact on the Balance Sheets, Statement of Cash Flows or reported Net income (loss) for any period.

- added (2015-05-11):
[0001144204-15-029330:note_history:5]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were - Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2015 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2015 in the amount of $10,600,000 approximates fair value.

- changed (2015-05-11):
[0001144204-15-029330:note_history:6]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2015 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2015 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.
  (was, 2015-02-09, similarity 0.9723):
[0001144204-15-007097:note_history:6]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2015-05-11):
[0001144204-15-029330:note_history:7]
Accounts receivable is stated net of the reserves for doubtful accounts of $175,000 and $180,000 and for returns and other allowances of $1,010,000 and $1,005,000 as of March 31, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2015-02-09, similarity 0.9883):
[0001144204-15-007097:note_history:7]
Accounts receivable is stated net of the reserves for doubtful accounts of $160,000 and $180,000 and for returns and other allowances of $1,040,000 and $1,005,000 as of December 31, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- changed (2015-05-11):
[0001144204-15-029330:note_history:8]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,666) |  | $ | 3,134 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (322) |  |  | 18 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,988) |  | $ | 9,052 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |
  (was, 2015-02-09, similarity 0.7975):
[0001144204-15-007097:note_history:8]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,511) |  | $ | 3,289 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (310) |  |  | 30 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,821) |  | $ | 9,219 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |

- changed (2015-05-11):
[0001144204-15-029330:note_history:9]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended March 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $500,000 and $586,000 for the nine months ended March 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.3 years and  14.1 years at March 31, 2015 and 2014, respectively.
  (was, 2015-02-09, similarity 0.9338):
[0001144204-15-007097:note_history:9]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended December 31, 2014 and 2013, respectively. Amortization expense for intangible assets subject to amortization was approximately $333,000 and $391,000 for the six months ended December 31, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.5 years and  14.4 years at December 31, 2014 and 2013, respectively.

- changed (2015-05-11):
[0001144204-15-029330:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% for the each of the three months ended March 31, 2015 and 2014. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2015 and 2014, respectively.
  (was, 2015-02-09, similarity 0.889):
[0001144204-15-007097:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 6% for the three months ended December 31, 2014 and 2013, respectively. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2014 and 2013, respectively.

- changed (2015-05-11):
[0001144204-15-029330:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2015 and 2014 was $172,000 and $189,000, respectively. Advertising expense for the nine months ended March 31, 2015 and 2014 was $1,028,000 and $801,000, respectively. The increase in Advertising and promotional costs for the nine months was due primarily to increased expenditures on media advertising as compared to the same period a year ago.
  (was, 2015-02-09, similarity 0.9225):
[0001144204-15-007097:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2014 and 2013 was $312,000 and $247,000, respectively. Advertising expense for the six months ended December 31, 2014 and 2013 was $856,000 and $612,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

- changed (2015-05-11):
[0001144204-15-029330:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2015 and 2014 was $1,350,000 and $1,275,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2015 and 2014 was  3,995,000 and $3,813,000, respectively.
  (was, 2015-02-09, similarity 0.9111):
[0001144204-15-007097:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2014 and 2013 was $1,335,000 and $1,252,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2014 and 2013 was $2,653,000 and $2,538,000, respectively.

- changed (2015-05-11):
[0001144204-15-029330:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):
  (was, 2015-02-09, similarity 0.9738):
[0001144204-15-007097:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

- changed (2015-05-11):
[0001144204-15-029330:note_history:14]
Options to purchase  262,000 and  37,500 shares of common stock for the three months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2015-02-09, similarity 0.9771):
[0001144204-15-007097:note_history:14]
Options to purchase  368,250 and  131,402 shares of common stock for the three months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2015-05-11):
[0001144204-15-029330:note_history:15]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):
  (was, 2015-02-09, similarity 0.9588):
[0001144204-15-007097:note_history:15]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- changed (2015-05-11):
[0001144204-15-029330:note_history:16]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,225 |  |  | 19,382 |  | $ | 0.08 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 4 |  |  | 37 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,229 |  |  | 19,419 |  | $ | 0.08 |  | $ | 0.06 |  |
  (was, 2015-02-09, similarity 0.9975):
[0001144204-15-007097:note_history:16]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 1,110 |  | $ | 491 |  |  | 19,304 |  |  | 19,366 |  | $ | 0.06 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | — |  |  | 27 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,110 |  | $ | 491 |  |  | 19,304 |  |  | 19,393 |  | $ | 0.06 |  | $ | 0.03 |  |

- changed (2015-05-11):
[0001144204-15-029330:note_history:17]
Options to purchase  258,583 and  145,673 shares of common stock for the nine months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2015-02-09, similarity 0.9149):
[0001144204-15-007097:note_history:17]
Options to purchase  256,875 and  199,759 shares of common stock for the six months ended December 31, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2015-05-11):
[0001144204-15-029330:note_history:18]
Stock-based compensation costs of $0 and $10,000 were recognized for three months ended March 31, 2015 and 2014, respectively. Stock-based compensation costs of $101,000 and $17,000 were recognized for nine months ended March 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2015 and 2014.
  (was, 2015-02-09, similarity 0.8117):
[0001144204-15-007097:note_history:18]
Stock-based compensation costs of $68,000 and $6,000 were recognized for three months ended December 31, 2014 and 2013, respectively. Stock-based compensation costs of $101,000 and $7,000 were recognized for six months ended December 31, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2014 and 2013.

- changed (2015-05-11):
[0001144204-15-029330:note_history:19]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or nine months ended March 31, 2015 and 2014.
  (was, 2015-02-09, similarity 0.9441):
[0001144204-15-007097:note_history:19]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or six months ended December 31, 2014 and 2013.

- changed (2015-05-11):
[0001144204-15-029330:note_history:20]
For the three and nine months ended March 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.
  (was, 2015-02-09, similarity 0.9197):
[0001144204-15-007097:note_history:20]
For the three and six months ended December 31, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2015-05-11):
[0001144204-15-029330:note_history:21]
The Company records the amount billed to customers for shipping and handling in net sales ($117,000 and $131,000 in the three months ended March 31, 2015 and 2014, respectively, and $374,000 and $383,000 in the nine months ended March 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($211,000 and $241,000 in the three months ended March 31, 2015 and 2014, respectively, and $692,000 and $704,000 in the nine months ended March 31, 2015 and 2014, respectively).
  (was, 2015-02-09, similarity 0.8614):
[0001144204-15-007097:note_history:21]
The Company records the amount billed to customers for shipping and handling in net sales ($130,000 and $121,000 in the three months ended December 31, 2014 and 2013, respectively, and $257,000 and $252,000 in the six months ended December 31, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($240,000 and $221,000 in the three months ended December 31, 2014 and 2013, respectively, and $481,000 and $463,000 in the six months ended December 31, 2014 and 2013, respectively).

- removed (2015-05-11):
[0001144204-15-007097:note_history:22]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

- removed (2015-05-11):
[0001144204-15-007097:note_history:23]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2014 in the amount of $11,000,000 approximates fair value.

- removed (2015-05-11):
[0001144204-15-007097:note_history:24]
Accounts Receivable


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-11):
[0001144204-15-029330:note_history:25]
As of March 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.
  (was, 2015-02-09, similarity 0.9874):
[0001144204-15-007097:note_history:25]
As of December 31, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

- changed (2015-05-11):
[0001144204-15-029330:note_history:26]
Outstanding balances and interest rates as of March 31, 2015 and June 30, 2014 are as follows:
  (was, 2015-02-09, similarity 0.9474):
[0001144204-15-007097:note_history:26]
Outstanding balances and interest rates as of December 31, 2014 and June 30, 2014 are as follows:

- changed (2015-05-11):
[0001144204-15-029330:note_history:27]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,100 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 10,600 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2015-02-09, similarity 0.9738):
[0001144204-15-007097:note_history:27]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding | Interest Rate |  | Outstanding | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,500 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,000 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |

- changed (2015-05-11):
[0001144204-15-029330:note_history:28]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.
  (was, 2015-02-09, similarity 0.9985):
[0001144204-15-007097:note_history:28]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-11):
[0001144204-15-029330:note_history:29]
Outstanding balances and interest rates as of March 31, 2015 and June 30, 2014 are as follows:
  (was, 2015-02-09, similarity 0.9474):
[0001144204-15-007097:note_history:29]
Outstanding balances and interest rates as of December 31, 2014 and June 30, 2014 are as follows:

- changed (2015-05-11):
[0001144204-15-029330:note_history:30]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,100 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 10,600 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2015-02-09, similarity 0.9738):
[0001144204-15-007097:note_history:30]
|  |  | December 31, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding | Interest Rate |  | Outstanding | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,500 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,000 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
