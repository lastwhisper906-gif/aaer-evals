# NSSC 8-K — 0001144204-15-007465 filed 2015-02-10

## item codes, every 8-K on or before 2015-05-11

- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2015-05-11

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-15-007465:8k_2_02:1]
EX-99.1
2
v401020_ex99-1.htm
EXHIBIT 99.1

[0001144204-15-007465:8k_2_02:2]
Exhibit 99.1

[0001144204-15-007465:8k_2_02:3]
NAPCO
Announces Results for Second Quarter Ended December 31, 2014

[0001144204-15-007465:8k_2_02:4]
-Record
Q2 and First Six Months Revenues of $19.6 and $36.9 Million-

[0001144204-15-007465:8k_2_02:5]
-Q2 Net Income Increases 158%-

[0001144204-15-007465:8k_2_02:6]
-Management to Host Conference Call Today at 11 a.m.-

[0001144204-15-007465:8k_2_02:7]
AMITYVILLE, N.Y., Feb. 9, 2015 /PRNewswire/ -- NAPCO Security
Technologies, Inc. (NASDAQ: NSSC), one of the world's leading solutions providers and manufacturers of high-technology electronic
intrusion security, connected home, video and fire systems, as well as enterprise-class access control and door locking products,
today announced financial results for its second fiscal quarter ended December 31, 2014.

[0001144204-15-007465:8k_2_02:8]
Highlights:

[0001144204-15-007465:8k_2_02:9]
|  | · | Record net sales for the second quarter of $19.6 million, up 7% from the same quarter last year. Record net sales for the first six months of $36.9 million, up 4% from the same period last year. |

[0001144204-15-007465:8k_2_02:10]
|  | · | Sales of the Company's access control products increased 23% in the second quarter as compared to the same quarter a year ago. Sales of these products increased 4% in the six months as compared to the same period a year ago. |

[0001144204-15-007465:8k_2_02:11]
|  | · | Sales of NAPCO's intrusion products increased 12% for the quarter and 6% for the six months ended December 31, 2014 as compared to the same periods last year. |

[0001144204-15-007465:8k_2_02:12]
|  | · | Alarm Division recurring revenue for the second quarter increased 53% and grew sequentially by 9%. Growth for the six months was 65% as compared to the same period last year. |

[0001144204-15-007465:8k_2_02:13]
|  | · | Gross margin for the quarter improved 350 basis points to 31.2% for the quarter as compared to 27.7% for the same quarter last year. Gross margin for the six months improved 240 basis points to 30.8% as compared to 28.4% for the same quarter last year. |

[0001144204-15-007465:8k_2_02:14]
|  | · | Income before taxes for the quarter increased by 147% to $1,039,000 as compared to $420,000 last year. Income before taxes for the six months increased by 121% to $1,235,000 as compared to $558,000 last year. |

[0001144204-15-007465:8k_2_02:15]
|  | · | Earnings per share (diluted) for the second quarter increased by 150% to $0.05 as compared to $0.02 for the same quarter a year ago. Earnings per share (diluted) for the six months increased by 100% to $0.06 as compared to $0.03 for the same quarter a year ago. |

[0001144204-15-007465:8k_2_02:16]
|  | · | During the six months ended December 31, 2014 NAPCO repurchased 304,186 shares of its common stock pursuant to a repurchase plan, which provides for repurchasing up to one million shares of the Company's common stock. |

[0001144204-15-007465:8k_2_02:17]
|  | · | Debt, net of cash, has been reduced by $26.6 million from $35.9 million to $9.3 million since acquiring Marks in August of 2008. |

[0001144204-15-007465:8k_2_02:18]
Richard Soloway, Chairman and President said, "This past
quarter's performance reflected exceptional synergies across the Company's Divisions and operational efforts. From the investments
we've made in driving our recurring revenue generating and high-margin product lines, to efficient improvements in our overall
gross margin, these have all come together to deliver a nice increase in both sales and profit."

[0001144204-15-007465:8k_2_02:19]
Mr. Soloway continued: "Our integrated access control and
wireless locking solution, marketed by our Continental and Alarm Lock Divisions, continues to drive exceptional sales growth in
the higher education vertical. Q2 was no exception, as we saw a large sale and installation of our integrated access control solution
sold to a major Midwestern college. This product solution has been a success because by combining traditional campus-wide access
control, with more cost-effective wireless locking access points, colleges and universities save thousands of dollars in installation
and hardware costs, while increasing a school's security level."

[0001144204-15-007465:8k_2_02:20]
"The innovative, new ArchiTech Networx™ Designer
Wireless Access Control Platform was launched this quarter. This product combines the capabilities of advanced, large-scale access
control with high-end, architecturally aesthetic wireless locking hardware. The product targets the multi-tenant building and luxury
office space markets where customers demand high-security access control with an institutional look. Our inaugural sale occurred
in December at a 400 unit apartment building in New Jersey."

[0001144204-15-007465:8k_2_02:21]
Mr. Soloway added: "Generating substantial subscription-based,
recurring monthly revenue for our Company, sales of Starlink™ 3G/4G Radios continue to build nicely, with an increase of
53% for the quarter. Alarm dealers are in the process of replacing older 2G radios, as service providers continue to decommission
these networks in favor of newer 3G/4G service. The NAPCO Intrusion Division will be expanding its market share and presence, in
the lucrative alarm communicator category, by launching a CDMA mobile protocol version of its Starlink radio, featuring Verizon
service."

[0001144204-15-007465:8k_2_02:22]
Mr. Soloway continued: "The Connected Home boom continues
to change the way people interact with their home systems, of all kinds, and the iBridge™ Connected Home Dealer Program targets
traditional alarm dealers who want to take advantage of this growing revolution. The first mass, security and connected home automation
dealer program of its kind, the program provides installation companies with home automation focused sales and technical training,
customized sales materials, web-page content, internet advertising and consumer leads. Impressive sales growth is being driven
on our iBridge Connected Home product line as we sign up more and more dealers onto the program."

[0001144204-15-007465:8k_2_02:23]
Mr. Soloway concluded: "We continue to demonstrate our
substantial earnings power and the ability to execute our strategy of rolling out new, recurring revenue products that reduce seasonality
in our business and drive a higher margin revenue mix. Our excellent second quarter performance is indicative of NAPCO's operating
leverage and gives us confidence as we move into the seasonally strong second half of the year."

[0001144204-15-007465:8k_2_02:24]
Financial Results

[0001144204-15-007465:8k_2_02:25]
Net Sales for the three months ended December 31, 2014 increased
7% to $19.6 million, as compared to $18.4 million for the same period one year ago. Net Sales for the six months ended December
31, 2014 increased 4% to $36.9 million, as compared to $35.6 million for the same period one year ago. Selling, general and administrative
expenses for the quarter were $5.0 million, or 25.6% of sales, as compared to $4.6 million, or 24.9% of sales, for the same period
in 2014. Selling, general and administrative expenses for the six months were $10.0 million, or 27.1% of sales, as compared to
$9.4 million, or 26.3% of sales, for the same period in 2014. The increase was due primarily to additional sales staff and advertising
expenditures to support ongoing product introductions.

[0001144204-15-007465:8k_2_02:26]
Operating income for the three months ended December 31, 2014
increased 117% to $1,096,000 as compared to $504,000 for the same quarter a year ago. Operating income for the six months ended
December 31, 2014 increased 80% to $1,342,000 as compared to $744,000 for the same period a year ago. Adjusted EBITDA* for the
three months ended December 31, 2014 increased 60% to $1,542,000 as compared to $962,000 for the same quarter last year. Adjusted
EBITDA* for the six months ended December 31, 2014 increased 34% to $2,193,000 as compared to $1,640,000 for the same period a
year ago (*see table attached).

[0001144204-15-007465:8k_2_02:27]
Net income for the three months ended December 31, 2014 increased
158%, to $951,000 or $0.05 per share as compared to 368, 000 or $0.02 per share for the same quarter last year. Net income for
the six months ended December 31, 2014 increased 126%, to $1,110,000 or $0.06 per share as compared to $491,000 or $0.03 per share
for the same quarter last year.

[0001144204-15-007465:8k_2_02:28]
Balance Sheet Summary

[0001144204-15-007465:8k_2_02:29]
At December 31, 2014, the Company had $1.7 million in cash and
cash equivalents a decrease of $0.8 million compared to $2.5 million at June 30, 2014. NAPCO had working capital of $32.7 million
as compared with working capital of $33.4 million at June 30, 2014. Current ratio was 4.8:1 at December 31, 2014 and 4.6:1 at June
30, 2014. Debt, net of cash, was $9.3 million at both December 31, 2014 and June 30, 2014.

[0001144204-15-007465:8k_2_02:30]
Conference Call Information

[0001144204-15-007465:8k_2_02:31]
Management will conduct a conference call at 11 a.m. today,
February 9, 2015. Interested parties may participate in the call by dialing 1-877-407-4018 or for international callers, 1-201-689-8471
about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on replay starting at 2 p.m.
ET on February 9, 2015 and ending on February 16, 2015 at 11:59 p.m. ET. For the replay, please dial 1-877-870-5176 domestically,
or 1-858-384-5517 for international callers, and use the replay access code 13599451. In addition, the call will be webcast and
will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/player/index.php?id=112676.

[0001144204-15-007465:8k_2_02:32]
About NAPCO Security Technologies, Inc.

[0001144204-15-007465:8k_2_02:33]
NAPCO Security Technologies, Inc. is one of the world's leading
solutions providers and manufacturers of high-technology electronic security, connected home, video, fire alarm, access control
and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected home segment, plus three wholly-owned
subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville, New York, its products are installed
by tens of thousands of security professionals worldwide in commercial, industrial, institutional, residential and government applications.
NAPCO products have earned a reputation for innovation, technical excellence and reliability, positioning the Company for
growth in the multi-billion dollar and rapidly expanding electronic security market. For additional information on NAPCO, please
visit the Company's web site at http://www.napcosecurity.com.

[0001144204-15-007465:8k_2_02:34]
Safe Harbor Statement

[0001144204-15-007465:8k_2_02:35]
This press release contains forward-looking statements that
involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated
in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the
Securities and Exchange Commission

[0001144204-15-007465:8k_2_02:36]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-15-007465:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001144204-15-007465:8k_2_02:38]
|  |  | December 31, 2014 |  |  | June 30, 2014 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,710 |  |  | $ | 2,483 |  |
| Accounts receivable, net of reserves and allowances |  |  | 15,352 |  |  |  | 16,904 |  |
| Inventories |  |  | 22,238 |  |  |  | 21,443 |  |
| Prepaid expenses and other current assets |  |  | 1,053 |  |  |  | 989 |  |
| Income tax receivable |  |  | 45 |  |  |  | 121 |  |
| Deferred income taxes |  |  | 781 |  |  |  | 739 |  |
| Total Current Assets |  |  | 41,179 |  |  |  | 42,679 |  |
| Inventories - non-current |  |  | 3,855 |  |  |  | 3,567 |  |
| Deferred income taxes |  |  | 965 |  |  |  | 1,005 |  |
| Property, plant and equipment, net |  |  | 6,306 |  |  |  | 6,394 |  |
| Intangible assets, net |  |  | 9,219 |  |  |  | 9,552 |  |
| Other assets |  |  | 156 |  |  |  | 167 |  |
| TOTAL ASSETS |  | $ | 61,680 |  |  | $ | 63,364 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 3,604 |  |  |  | 4,082 |  |
| Accrued expenses |  |  | 1,570 |  |  |  | 1,737 |  |
| Accrued salaries and wages |  |  | 1,743 |  |  |  | 1,824 |  |
| Total Current Liabilities |  |  | 8,517 |  |  |  | 9,243 |  |
| Long-term debt, net of current maturities |  |  | 9,400 |  |  |  | 10,200 |  |
| Accrued income taxes |  |  | 190 |  |  |  | 169 |  |
| Total Liabilities |  |  | 18,107 |  |  |  | 19,612 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 21,049,243 shares issued; and 19,114,520 and 19,419,076 shares outstanding, respectively |  |  | 210 |  |  |  | 210 |  |
| Additional paid-in capital |  |  | 16,133 |  |  |  | 16,032 |  |
| Retained earnings |  |  | 36,664 |  |  |  | 35,554 |  |
|  |  |  | 53,007 |  |  |  | 51,796 |  |
| Less: Treasury Stock, at cost (1,934,353 and 1,630,167 shares, respectively) |  |  | (9,434 | ) |  |  | (8,044 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 43,573 |  |  |  | 43,752 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 61,680 |  |  | $ | 63,364 |  |

[0001144204-15-007465:8k_2_02:39]
NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES

[0001144204-15-007465:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME (unaudited)

[0001144204-15-007465:8k_2_02:41]
|  |  | Three Months ended December 31, |  |  | Six Months ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Sales |  | $ | 19,571 |  |  | $ | 18,353 |  |  | $ | 36,907 |  |  | $ | 35,592 |  |
| Cost of sales |  |  | 13,468 |  |  |  | 13,272 |  |  |  | 25,549 |  |  |  | 25,472 |  |
| Gross Profit |  |  | 6,103 |  |  |  | 5,081 |  |  |  | 11,358 |  |  |  | 10,120 |  |
| Selling, general and administrative expenses |  |  | 5,007 |  |  |  | 4,577 |  |  |  | 10,016 |  |  |  | 9,376 |  |
| Operating income |  |  | 1,096 |  |  |  | 504 |  |  |  | 1,342 |  |  |  | 744 |  |
| Other expense (income): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest |  |  | 54 |  |  |  | 80 |  |  |  | 109 |  |  |  | 179 |  |
| Other, net |  |  | 3 |  |  |  | 4 |  |  |  | (2 | ) |  |  | 7 |  |
| Income before taxes |  |  | 1,039 |  |  |  | 420 |  |  |  | 1,235 |  |  |  | 558 |  |
| Income taxes |  |  | 88 |  |  |  | 52 |  |  |  | 125 |  |  |  | 67 |  |
| Net income |  | $ | 951 |  |  | $ | 368 |  |  | $ | 1,110 |  |  | $ | 491 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.02 |  |  | $ | 0.06 |  |  | $ | 0.03 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 0.02 |  |  | $ | 0.06 |  |  | $ | 0.03 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,188,000 |  |  |  | 19,408,000 |  |  |  | 19,304,000 |  |  |  | 19,366,000 |  |
| Diluted |  |  | 19,189,000 |  |  |  | 19,444,000 |  |  |  | 19,304,000 |  |  |  | 19,393,000 |  |

[0001144204-15-007465:8k_2_02:42]
NAPCO SECURITY TECHNOLOGIES, INC.

[0001144204-15-007465:8k_2_02:43]
NON-GAAP MEASURES OF PERFORMANCE* (Unaudited)

[0001144204-15-007465:8k_2_02:44]
(in thousands)

[0001144204-15-007465:8k_2_02:45]
|  |  | Three months ended December 31, |  |  | Six months ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net income (GAAP) |  | $ | 951 |  |  | $ | 368 |  |  | $ | 1,110 |  |  | $ | 491 |  |
| Add back provision for income taxes |  |  | 88 |  |  |  | 52 |  |  |  | 125 |  |  |  | 67 |  |
| Add back interest and other expense |  |  | 57 |  |  |  | 114 |  |  |  | 107 |  |  |  | 238 |  |
| Operating Income (GAAP) |  |  | 1,096 |  |  |  | 534 |  |  |  | 1,342 |  |  |  | 796 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 167 |  |  |  | 195 |  |  |  | 333 |  |  |  | 391 |  |
| Add back stock-based compensation expense |  |  | 68 |  |  |  | 6 |  |  |  | 101 |  |  |  | 7 |  |
| Adjusted non-GAAP operating income |  |  | 1,331 |  |  |  | 735 |  |  |  | 1,776 |  |  |  | 1,194 |  |
| Add back depreciation and other amortization |  |  | 211 |  |  |  | 227 |  |  |  | 417 |  |  |  | 446 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,542 |  |  | $ | 962 |  |  | $ | 2,193 |  |  | $ | 1,640 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.08 |  |  | $ | 0.05 |  |  | $ | 0.11 |  |  | $ | 0.08 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 19,189,000 |  |  |  | 19,444,000 |  |  |  | 19,304,000 |  |  |  | 19,393,000 |  |

[0001144204-15-007465:8k_2_02:46]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-15-007465:8k_2_02:47]
Contacts:

[0001144204-15-007465:8k_2_02:48]
Investor Relations

[0001144204-15-007465:8k_2_02:49]
KCSA Strategic Communications

[0001144204-15-007465:8k_2_02:50]
Todd Fromer / Phil Carlson

[0001144204-15-007465:8k_2_02:51]
212-896-1215 / 1233

[0001144204-15-007465:8k_2_02:52]
napco@kcsa.com

[0001144204-15-007465:8k_2_02:53]
Media

[0001144204-15-007465:8k_2_02:54]
KCSA Strategic Communications

[0001144204-15-007465:8k_2_02:55]
Jon Goldberg / Dixon Moretz

[0001144204-15-007465:8k_2_02:56]
212-896-1282 / 1251

[0001144204-15-007465:8k_2_02:57]
napco@kcsa.com
