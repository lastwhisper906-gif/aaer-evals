# NSSC notes — 0001144204-15-029330


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-15-029330:notes:1]
[same as prior period, unchanged from 0001144204-15-007097:notes:1]

[0001144204-15-029330:notes:2]
[same as prior period, unchanged from 0001144204-15-007097:notes:2]

[0001144204-15-029330:notes:3]
|  |  | March 31, 2015 |  | June 30, 2014 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 6,982 |  |  | 6,906 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,473 |  |  | 2,427 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 20,231 |  |  | 19,974 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 288 |  |  | 288 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 39,789 |  |  | 39,410 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 33,527 |  |  | 33,016 |  |  |  |
|  |  | $ | 6,262 |  | $ | 6,394 |  |  |  |

[0001144204-15-029330:notes:4]
Depreciation and amortization expense on property, plant, and equipment was $222,000 and $242,000 for the three months ended March 31, 2015 and 2014, respectively and $634,000 and $682,000 for the nine months ended March 31, 2015 and 2014, respectively


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-15-029330:notes:5]
[same as prior period, unchanged from 0001144204-15-007097:notes:5]

[0001144204-15-029330:notes:6]
[same as prior period, unchanged from 0001144204-15-007097:notes:6]

[0001144204-15-029330:notes:7]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of March 31, 2015 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2008 and thereafter.

[0001144204-15-029330:notes:8]
The Company has identified its U.S. Federal income tax return and its State return in New York as its major tax jurisdictions. As of March 31, 2015 and June 30, 2014 the Company has a long-term accrued income tax liability of $190,000 and $169,000, respectively.


## us-gaap:LongTermDebtTextBlock

[0001144204-15-029330:notes:9]
NOTE 6 - Long-Term Debt

[0001144204-15-029330:notes:10]
As of March 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001144204-15-029330:notes:11]
Outstanding balances and interest rates as of March 31, 2015 and June 30, 2014 are as follows:

[0001144204-15-029330:notes:12]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,100 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 10,600 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |

[0001144204-15-029330:notes:13]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-15-029330:notes:14]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-15-029330:notes:15]
[same as prior period, unchanged from 0001144204-15-007097:notes:15]

[0001144204-15-029330:notes:16]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended March 31, 2015 and 2014, the Company recorded non-cash compensation expense of $0 ($.00 per basic and diluted share) and $10,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation. For the nine months ended March 31, 2015 and 2014, the Company recorded non-cash compensation expense of $101,000 ($.01 per basic and diluted share) and $17,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-15-029330:notes:17]
[same as prior period, unchanged from 0001144204-15-007097:notes:17]

[0001144204-15-029330:notes:18]
[same as prior period, unchanged from 0001144204-15-007097:notes:18]

[0001144204-15-029330:notes:19]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2015,  112,500 stock options were granted,  27,500 stock options were exercisable and  837,500 stock options were available for grant under this plan.

[0001144204-15-029330:notes:20]
The fair value of each option granted during fiscal 2015 was estimated on the date of grant using the Black-Scholes option-pricing model with the following weighted average assumptions:

[0001144204-15-029330:notes:21]
[same as prior period, unchanged from 0001144204-15-007097:notes:21]

[0001144204-15-029330:notes:22]
The following table reflects activity under the 2012 Plan for the nine months ended March 31,:

[0001144204-15-029330:notes:23]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 78,500 |  | $ | 5.73 |  |  | — |  | $ | — |  |
| Granted |  |  | 44,000 |  |  | 4.43 |  |  | 78,500 |  |  | 5.73 |  |
| Terminated/Lapsed |  |  | (10,000) |  |  | 4.88 |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 112,500 |  | $ | 5.30 |  |  | 78,500 |  | $ | 5.73 |  |
| Exercisable, end of period |  |  | 27,500 |  | $ | 5.26 |  |  | 15,700 |  | $ | 5.73 |  |
| Weighted average fair value at grant date of options granted |  | $ | 2.82 |  |  |  |  | $ | 3.84 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 78,000 |  |  |  |  | $ | 85,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 19,000 |  |  |  |  | $ | 17,000 |  |  |  |  |

[0001144204-15-029330:notes:24]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at March 31, 2015:

[0001144204-15-029330:notes:25]
|  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $ 4.88 - $ 6.31 |  |  | 112,500 |  |  | 9.0 |  | $ | 5.30 |  |  | 27,500 |  | $ | 5.26 |  |
|  |  |  | 112,500 |  |  | 9.0 |  | $ | 5.30 |  |  | 27,500 |  | $ | 5.26 |  |

[0001144204-15-029330:notes:26]
As of March 31, 2015, there was $260,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during the three months ended March 31, 2015.  44,000 options were granted during the nine months ended March 31, 2015. The total fair value of the options vesting during the three months ended March 31, 2015 and 2014 under this plan was $0. The total fair value of the options vesting during the nine months ended March 31, 2015 and 2014 under this plan was $41,000 and $60,000, respectively.

[0001144204-15-029330:notes:27]
[same as prior period, unchanged from 0001144204-15-007097:notes:27]

[0001144204-15-029330:notes:28]
[same as prior period, unchanged from 0001144204-15-007097:notes:28]

[0001144204-15-029330:notes:29]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At March 31, 2015,  35,000 stock options were granted,  12,000 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-15-029330:notes:30]
The following table reflects activity under the 2012 Non-Employee Plan for the nine months ended March 31,:

[0001144204-15-029330:notes:31]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 25,000 |  | $ | 4.88 |  |  | — |  | $ | — |  |
| Granted |  |  | 10,000 |  |  | 4.37 |  |  | 25,000 |  |  | 4.88 |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 12,000 |  | $ | 4.80 |  |  | 5,000 |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  | $ | 2.86 |  |  |  |  | $ | 3.30 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 37,000 |  |  |  |  | $ | 48,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 12,000 |  |  |  |  | $ | 10,000 |  |  |  |  |

[0001144204-15-029330:notes:32]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at March 31, 2015:

[0001144204-15-029330:notes:33]
|  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $4.37 - $ 4.88 |  |  | 35,000 |  |  | 8.8 |  | $ | 4.73 |  |  | 12,000 |  | $ | 4.80 |  |
|  |  |  | 35,000 |  |  | 8.8 |  | $ | 4.73 |  |  | 12,000 |  | $ | 4.80 |  |

[0001144204-15-029330:notes:34]
As of March 31, 2015, there was $72,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three months ended March 31, 2015.  10,000 options were granted during the nine months ended March 31, 2014. The total fair value of the options vesting during the three months ended March 31, 2015 and 2014 under this plan was $0. The total fair value of the options vesting during the nine months ended March 31, 2015 and 2014 under this plan was $6,000 and $22,000, respectively.

[0001144204-15-029330:notes:35]
[same as prior period, unchanged from 0001144204-15-007097:notes:35]

[0001144204-15-029330:notes:36]
[same as prior period, unchanged from 0001144204-15-007097:notes:36]

[0001144204-15-029330:notes:37]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At March 31, 2015,  1,471,480 stock options had been granted,  264,750 stock options were exercisable and no further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-15-029330:notes:38]
The following table reflects activity under the 2002 Employee plan for the nine months ended March 31,:

[0001144204-15-029330:notes:39]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 265,750 |  | $ | 6.51 |  |  | 651,140 |  | $ | 4.18 |  |
| Granted |  |  | -- |  |  | -- |  |  | -- |  |  | -- |  |
| Terminated/Lapsed |  |  | (57,250) |  |  | 5.24 |  |  | (47,790) |  |  | 1.74 |  |
| Exercised |  |  | -- |  |  | -- |  |  | (337,600) |  |  | 2.70 |  |
| Outstanding, end of period |  |  | 208,500 |  | $ | 6.86 |  |  | 265,750 |  | $ | 6.07 |  |
| Exercisable, end of period |  |  | 208,000 |  | $ | 6.86 |  |  | 265,750 |  | $ | 6.07 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  | $ | 1,399,000 |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 10,000 |  |  |  |  | $ | 244,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 10,000 |  |  |  |  | $ | 244,000 |  |  |  |  |

[0001144204-15-029330:notes:40]
0 and  337,600 stock options were exercised during the nine months ended March 31, 2015 and 2014, respectively.  324,100 of the 337,600 stock options exercised during the nine months ended March 31, 2014 were settled by exchanging  164,859 shares of the Company’s common stock of which  85,170 was retired upon receipt. Cash received from option exercises was $0 and $25,650 for the nine months ended March 31, 2015 and 2014, respectively, and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-15-029330:notes:41]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at March 31, 2015:

[0001144204-15-029330:notes:42]
|  |  | Options outstanding and exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  |
| $ 5.22 - $ 6.62 |  |  | 227,250 |  | 1.4 |  | $ | 5.75 |  |
| $11.16 |  |  | 37,500 |  | 1.0 |  |  | 11.16 |  |
|  |  |  | 264,750 |  | 1.3 |  | $ | 6.51 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-15-029330:notes:43]
[same as prior period, unchanged from 0001144204-15-007097:notes:43]

[0001144204-15-029330:notes:44]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately 19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the nine months ended March 31, 2015 the Company repurchased 398,717 shares of its outstanding common stock for a weighted average price of $4.74 per share. These repurchased shares are included in the Company’s Treasury Stock as of March 31, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-15-029330:notes:45]
[same as prior period, unchanged from 0001144204-15-007097:notes:45]

[0001144204-15-029330:notes:46]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $27,000 and $26,000 for the three months ended March 31, 2015 and 2014, respectively and $93,000 and $77,000 for the nine months ended March 31, 2015 and 2014, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-15-029330:notes:47]
NOTE 10 - Commitments and Contingencies

[0001144204-15-029330:notes:48]
Leases

[0001144204-15-029330:notes:49]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2016.

[0001144204-15-029330:notes:50]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended March 31, 2015 and 2014, respectively and $23,000 and $25,000 for the nine months ended March 31, 2015 and 2014, respectively.

[0001144204-15-029330:notes:51]
Land Lease

[0001144204-15-029330:notes:52]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in 2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-15-029330:notes:53]
Litigation

[0001144204-15-029330:notes:54]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-15-029330:notes:55]
Employment Agreements

[0001144204-15-029330:notes:56]
As of March 31, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-15-029330:notes:57]
[same as prior period, unchanged from 0001144204-15-007097:notes:57]

[0001144204-15-029330:notes:58]
[same as prior period, unchanged from 0001144204-15-007097:notes:58]

[0001144204-15-029330:notes:59]
[same as prior period, unchanged from 0001144204-15-007097:notes:59]

[0001144204-15-029330:notes:60]
|  |  | Three months ended March 31, |  | Nine months ended March 31, |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
|  |  | (in thousands) |  | (in thousands) |  |  |  |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 17,076 |  | $ | 16,299 |  | $ | 52,523 |  | $ | 50,186 |  |
| Foreign |  |  | 818 |  |  | 973 |  |  | 2,278 |  |  | 2,678 |  |
| Total Net Sales |  | $ | 17,894 |  | $ | 17,272 |  | $ | 54,801 |  | $ | 52,864 |  |

[0001144204-15-029330:notes:61]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
| Identifiable assets: |  |  |  |  |  |  |  |
| United States |  | $ | 47,644 |  | $ | 49,529 |  |
| Dominican Republic (2) |  |  | 14,068 |  |  | 13,835 |  |
| Total Identifiable Assets |  | $ | 61,712 |  | $ | 63,364 |  |

[0001144204-15-029330:notes:62]
[same as prior period, unchanged from 0001144204-15-007097:notes:62]

[0001144204-15-029330:notes:63]
(2) Consists primarily of inventories (March 31, 2015 = $10,521; June 30, 2014 = $10,216) and fixed assets (March 31, 2015 = $3,345; June 30, 2014 = $3,475) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001144204-15-029330:notes:64]
[same as prior period, unchanged from 0001144204-15-007097:notes:64]

[0001144204-15-029330:notes:65]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-15-029330:notes:66]
[same as prior period, unchanged from 0001144204-15-007097:notes:66]

[0001144204-15-029330:notes:67]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at March 31, 2015 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of March 31, 2015 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

[0001144204-15-029330:notes:68]
Accounts receivable is stated net of the reserves for doubtful accounts of $175,000 and $180,000 and for returns and other allowances of $1,010,000 and $1,005,000 as of March 31, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.


## us-gaap:InventoryPolicyTextBlock

[0001144204-15-029330:notes:69]
[same as prior period, unchanged from 0001144204-15-007097:notes:70]

[0001144204-15-029330:notes:70]
[same as prior period, unchanged from 0001144204-15-007097:notes:71]

[0001144204-15-029330:notes:71]
[same as prior period, unchanged from 0001144204-15-007097:notes:72]

[0001144204-15-029330:notes:72]
[same as prior period, unchanged from 0001144204-15-007097:notes:73]


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-15-029330:notes:73]
[same as prior period, unchanged from 0001144204-15-007097:notes:74]

[0001144204-15-029330:notes:74]
[same as prior period, unchanged from 0001144204-15-007097:notes:75]

[0001144204-15-029330:notes:75]
[same as prior period, unchanged from 0001144204-15-007097:notes:76]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001144204-15-029330:notes:76]
[same as prior period, unchanged from 0001144204-15-007097:notes:77]

[0001144204-15-029330:notes:77]
[same as prior period, unchanged from 0001144204-15-007097:notes:78]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-15-029330:notes:78]
[same as prior period, unchanged from 0001144204-15-007097:notes:79]

[0001144204-15-029330:notes:79]
[same as prior period, unchanged from 0001144204-15-007097:notes:80]


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-15-029330:notes:80]
[same as prior period, unchanged from 0001144204-15-007097:notes:81]

[0001144204-15-029330:notes:81]
[same as prior period, unchanged from 0001144204-15-007097:notes:82]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-15-029330:notes:82]
[same as prior period, unchanged from 0001144204-15-007097:notes:83]

[0001144204-15-029330:notes:83]
[same as prior period, unchanged from 0001144204-15-007097:notes:84]

[0001144204-15-029330:notes:84]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended March 31 (in thousands, except per share data):

[0001144204-15-029330:notes:85]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 395 |  | $ | 650 |  |  | 19,066 |  |  | 19,416 |  | $ | 0.02 |  | $ | 0.03 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 7 |  |  | 55 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 395 |  | $ | 650 |  |  | 19,073 |  |  | 19,471 |  | $ | 0.02 |  | $ | 0.03 |  |

[0001144204-15-029330:notes:86]
Options to purchase  262,000 and  37,500 shares of common stock for the three months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-15-029330:notes:87]
The following provides a reconciliation of information used in calculating the per share amounts for the nine months ended March 31 (in thousands, except per share data):

[0001144204-15-029330:notes:88]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,225 |  |  | 19,382 |  | $ | 0.08 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 4 |  |  | 37 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,505 |  | $ | 1,141 |  |  | 19,229 |  |  | 19,419 |  | $ | 0.08 |  | $ | 0.06 |  |

[0001144204-15-029330:notes:89]
Options to purchase  258,583 and  145,673 shares of common stock for the nine months ended March 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-15-029330:notes:90]
[same as prior period, unchanged from 0001144204-15-007097:notes:91]

[0001144204-15-029330:notes:91]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three or nine months ended March 31, 2015 and 2014.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001144204-15-029330:notes:92]
[same as prior period, unchanged from 0001144204-15-007097:notes:93]

[0001144204-15-029330:notes:93]
For the three and nine months ended March 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001144204-15-029330:notes:94]
[same as prior period, unchanged from 0001144204-15-007097:notes:95]

[0001144204-15-029330:notes:95]
[same as prior period, unchanged from 0001144204-15-007097:notes:96]


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001144204-15-029330:notes:96]
[same as prior period, unchanged from 0001144204-15-007097:notes:97]

[0001144204-15-029330:notes:97]
The Company records the amount billed to customers for shipping and handling in net sales ($117,000 and $131,000 in the three months ended March 31, 2015 and 2014, respectively, and $374,000 and $383,000 in the nine months ended March 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($211,000 and $241,000 in the three months ended March 31, 2015 and 2014, respectively, and $692,000 and $704,000 in the nine months ended March 31, 2015 and 2014, respectively).


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001144204-15-029330:notes:98]
Recently Issued Accounting Standards

[0001144204-15-029330:notes:99]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers (Topic 606),” which is the new comprehensive revenue recognition standard that will supersede all existing revenue recognition guidance under U.S. GAAP. The standard’s core principle is that a company will recognize revenue when it transfers promised goods or services to a customer in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services. ASU 2014-09 is effective for annual and interim periods beginning on or after December 15, 2016, and early adoption is not permitted. Entities will have the option of using either a full retrospective approach or a modified approach to adopt the guidance. The Company is currently evaluating the impact of adopting this guidance.

[0001144204-15-029330:notes:100]
In July 2013, the FASB issued authoritative guidance that requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a net operating loss (“NOL”) carry-forward, a similar tax loss, or a tax credit carry-forward.  If either (i) an NOL carry-forward, a similar tax loss, or tax credit carry-forward is not available as of the reporting date under the governing tax law to settle taxes that would result from the disallowance of the tax position or (ii) the entity does not intend to use the deferred tax asset for this purpose (provided that the tax law permits a choice), an entity should present an unrecognized tax benefit in the financial statements as a liability and should not net the unrecognized tax benefit with a deferred tax asset.  This guidance became effective for unrecognized tax benefits that exist as of the Company’s fiscal 2015 first quarter.  The guidance did not have an impact on the Company’s consolidated financial statements.


## nssc:ScheduleOfIntangibleAssetsTableTextBlock

[0001144204-15-029330:notes:101]
[same as prior period, unchanged from 0001144204-15-007097:notes:102]

[0001144204-15-029330:notes:102]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,666) |  | $ | 3,134 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (322) |  |  | 18 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,988) |  | $ | 9,052 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |


## nssc:InventoryTableTextBlock

[0001144204-15-029330:notes:103]
[same as prior period, unchanged from 0001144204-15-007097:notes:104]

[0001144204-15-029330:notes:104]
|  |  | March 31, 2015 |  | June 30, 2014 |  |
| Component parts |  | $ | 16,416 |  | $ | 15,268 |  |
| Work-in-process |  |  | 3,905 |  |  | 3,632 |  |
| Finished product |  |  | 6,570 |  |  | 6,110 |  |
|  |  | $ | 26,891 |  | $ | 25,010 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 22,886 |  | $ | 21,443 |  |
| Non-current |  |  | 4,005 |  |  | 3,567 |  |
|  |  | $ | 26,891 |  | $ | 25,010 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-15-029330:notes:105]
[same as prior period, unchanged from 0001144204-15-007097:notes:106]

[0001144204-15-029330:notes:106]
[same as prior period, unchanged from 0001144204-15-007097:notes:107]

[0001144204-15-029330:notes:107]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-15-029330:notes:108]
[same as prior period, unchanged from 0001144204-15-007097:notes:109]

[0001144204-15-029330:notes:109]
[same as prior period, unchanged from 0001144204-15-007097:notes:110]

[0001144204-15-029330:notes:110]
[same as prior period, unchanged from 0001144204-15-007097:notes:111]

[0001144204-15-029330:notes:111]
[same as prior period, unchanged from 0001144204-15-007097:notes:112]

[0001144204-15-029330:notes:112]
[same as prior period, unchanged from 0001144204-15-007097:notes:113]

[0001144204-15-029330:notes:113]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were - Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of March 31, 2015 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at March 31, 2015 in the amount of $10,600,000 approximates fair value.

[0001144204-15-029330:notes:114]
[same as prior period, unchanged from 0001144204-15-007097:notes:115]

[0001144204-15-029330:notes:115]
[same as prior period, unchanged from 0001144204-15-007097:notes:116]

[0001144204-15-029330:notes:116]
[same as prior period, unchanged from 0001144204-15-007097:notes:117]

[0001144204-15-029330:notes:117]
Amortization expense for intangible assets subject to amortization was approximately $167,000 and $195,000 for the three months ended March 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $500,000 and $586,000 for the nine months ended March 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.3 years and  14.1 years at March 31, 2015 and 2014, respectively.

[0001144204-15-029330:notes:118]
[same as prior period, unchanged from 0001144204-15-007097:notes:119]

[0001144204-15-029330:notes:119]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% for the each of the three months ended March 31, 2015 and 2014. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the nine months ended March 31, 2015 and 2014, respectively.

[0001144204-15-029330:notes:120]
[same as prior period, unchanged from 0001144204-15-007097:notes:121]

[0001144204-15-029330:notes:121]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended March 31, 2015 and 2014 was $172,000 and $189,000, respectively. Advertising expense for the nine months ended March 31, 2015 and 2014 was $1,028,000 and $801,000, respectively. The increase in Advertising and promotional costs for the nine months was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

[0001144204-15-029330:notes:122]
[same as prior period, unchanged from 0001144204-15-007097:notes:123]

[0001144204-15-029330:notes:123]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended March 31, 2015 and 2014 was $1,350,000 and $1,275,000, respectively. Company-sponsored research and development expense for the nine months ended March 31, 2015 and 2014 was  3,995,000 and $3,813,000, respectively.

[0001144204-15-029330:notes:124]
[same as prior period, unchanged from 0001144204-15-007097:notes:125]

[0001144204-15-029330:notes:125]
[same as prior period, unchanged from 0001144204-15-007097:notes:126]

[0001144204-15-029330:notes:126]
[same as prior period, unchanged from 0001144204-15-007097:notes:127]

[0001144204-15-029330:notes:127]
Stock-based compensation costs of $0 and $10,000 were recognized for three months ended March 31, 2015 and 2014, respectively. Stock-based compensation costs of $101,000 and $17,000 were recognized for nine months ended March 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and nine months ended March 31, 2015 and 2014.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-15-029330:notes:128]
[same as prior period, unchanged from 0001144204-15-007097:notes:129]

[0001144204-15-029330:notes:129]
The Company had one customer with an accounts receivable balance that comprised  21% of the Company’s accounts receivable at March 31, 2015 and  12% of the Company’s accounts receivable at June 30, 2014. Sales to this customer comprised  12% of net sales in the nine months ended March 31, 2015.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-15-029330:notes:130]
[same as prior period, unchanged from 0001144204-15-007097:notes:131]

[0001144204-15-029330:notes:131]
[same as prior period, unchanged from 0001144204-15-007097:notes:132]
