# NSSC notes — 0001144204-16-078240


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-16-078240:notes:1]
[same as prior period, unchanged from 0001144204-15-063875:notes:1]

[0001144204-16-078240:notes:2]
[same as prior period, unchanged from 0001144204-15-063875:notes:2]

[0001144204-16-078240:notes:3]
[same as prior period, unchanged from 0001144204-15-063875:notes:3]

[0001144204-16-078240:notes:4]
[same as prior period, unchanged from 0001144204-15-063875:notes:4]

[0001144204-16-078240:notes:5]
[same as prior period, unchanged from 0001144204-15-063875:notes:5]

[0001144204-16-078240:notes:6]
[same as prior period, unchanged from 0001144204-15-063875:notes:6]

[0001144204-16-078240:notes:7]
[same as prior period, unchanged from 0001144204-15-063875:notes:7]

[0001144204-16-078240:notes:8]
[same as prior period, unchanged from 0001144204-15-063875:notes:8]

[0001144204-16-078240:notes:9]
[same as prior period, unchanged from 0001144204-15-063875:notes:9]

[0001144204-16-078240:notes:10]
[same as prior period, unchanged from 0001144204-15-063875:notes:10]

[0001144204-16-078240:notes:11]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2015 in the amount of $7,900,000 approximates fair value.

[0001144204-16-078240:notes:12]
[same as prior period, unchanged from 0001144204-15-063875:notes:12]

[0001144204-16-078240:notes:13]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

[0001144204-16-078240:notes:14]
Accounts Receivable

[0001144204-16-078240:notes:15]
Accounts receivable is stated net of the reserves for doubtful accounts of $90,000 and $175,000 and for returns and other allowances of $995,000 and $1,260,000 as of December 31, 2015 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

[0001144204-16-078240:notes:16]
[same as prior period, unchanged from 0001144204-15-063875:notes:15]

[0001144204-16-078240:notes:17]
[same as prior period, unchanged from 0001144204-15-063875:notes:16]

[0001144204-16-078240:notes:18]
[same as prior period, unchanged from 0001144204-15-063875:notes:17]

[0001144204-16-078240:notes:19]
[same as prior period, unchanged from 0001144204-15-063875:notes:18]

[0001144204-16-078240:notes:20]
[same as prior period, unchanged from 0001144204-15-063875:notes:19]

[0001144204-16-078240:notes:21]
[same as prior period, unchanged from 0001144204-15-063875:notes:20]

[0001144204-16-078240:notes:22]
[same as prior period, unchanged from 0001144204-15-063875:notes:21]

[0001144204-16-078240:notes:23]
[same as prior period, unchanged from 0001144204-15-063875:notes:22]

[0001144204-16-078240:notes:24]
[same as prior period, unchanged from 0001144204-15-063875:notes:23]

[0001144204-16-078240:notes:25]
[same as prior period, unchanged from 0001144204-15-063875:notes:24]

[0001144204-16-078240:notes:26]
[same as prior period, unchanged from 0001144204-15-063875:notes:25]

[0001144204-16-078240:notes:27]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,082) |  | $ | 2,718 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,422) |  | $ | 8,618 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

[0001144204-16-078240:notes:28]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended December 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $268,000 and $333,000 for the six months ended December 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.6 years and  13.5 years at December 31, 2015 and 2014, respectively.

[0001144204-16-078240:notes:29]
[same as prior period, unchanged from 0001144204-15-063875:notes:28]

[0001144204-16-078240:notes:30]
[same as prior period, unchanged from 0001144204-15-063875:notes:29]

[0001144204-16-078240:notes:31]
[same as prior period, unchanged from 0001144204-15-063875:notes:30]

[0001144204-16-078240:notes:32]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.

[0001144204-16-078240:notes:33]
[same as prior period, unchanged from 0001144204-15-063875:notes:32]

[0001144204-16-078240:notes:34]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the six months ended December 31, 2015 and 2014, respectively.

[0001144204-16-078240:notes:35]
[same as prior period, unchanged from 0001144204-15-063875:notes:34]

[0001144204-16-078240:notes:36]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2015 and 2014 was $510,000 and $312,000, respectively. Advertising expense for the six months ended December 31, 2015 and 2014 was $1,068,000 and $856,000, respectively.

[0001144204-16-078240:notes:37]
[same as prior period, unchanged from 0001144204-15-063875:notes:36]

[0001144204-16-078240:notes:38]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2015 and 2014 was $1,519,000 and $1,335,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2015 and 2014 was $3,008,000 and $2,653,000, respectively.

[0001144204-16-078240:notes:39]
[same as prior period, unchanged from 0001144204-15-063875:notes:38]

[0001144204-16-078240:notes:40]
[same as prior period, unchanged from 0001144204-15-063875:notes:39]

[0001144204-16-078240:notes:41]
[same as prior period, unchanged from 0001144204-15-063875:notes:40]

[0001144204-16-078240:notes:42]
[same as prior period, unchanged from 0001144204-15-063875:notes:41]

[0001144204-16-078240:notes:43]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

[0001144204-16-078240:notes:44]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 976 |  | $ | 951 |  |  | 18,931 |  |  | 19,188 |  | $ | 0.05 |  | $ | 0.05 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 26 |  |  | 1 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 976 |  | $ | 951 |  |  | 18,957 |  |  | 19,189 |  | $ | 0.05 |  | $ | 0.05 |  |

[0001144204-16-078240:notes:45]
Options to purchase  106,000 and  368,250 shares of common stock for the three months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-16-078240:notes:46]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

[0001144204-16-078240:notes:47]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,948 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,971 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |

[0001144204-16-078240:notes:48]
Options to purchase  137,750 and  256,875 shares of common stock for the six months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-16-078240:notes:49]
[same as prior period, unchanged from 0001144204-15-063875:notes:45]

[0001144204-16-078240:notes:50]
[same as prior period, unchanged from 0001144204-15-063875:notes:46]

[0001144204-16-078240:notes:51]
[same as prior period, unchanged from 0001144204-15-063875:notes:47]

[0001144204-16-078240:notes:52]
Stock-based compensation costs of $60,000 and $68,000 were recognized for three months ended December 31, 2015 and 2014, respectively. Stock-based compensation costs of $92,000 and $101,000 were recognized for six months ended December 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2015 and 2014.

[0001144204-16-078240:notes:53]
[same as prior period, unchanged from 0001144204-15-063875:notes:49]

[0001144204-16-078240:notes:54]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2015 and 2014.

[0001144204-16-078240:notes:55]
[same as prior period, unchanged from 0001144204-15-063875:notes:51]

[0001144204-16-078240:notes:56]
For the three and six months ended December 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

[0001144204-16-078240:notes:57]
[same as prior period, unchanged from 0001144204-15-063875:notes:53]

[0001144204-16-078240:notes:58]
[same as prior period, unchanged from 0001144204-15-063875:notes:54]

[0001144204-16-078240:notes:59]
[same as prior period, unchanged from 0001144204-15-063875:notes:55]

[0001144204-16-078240:notes:60]
The Company records the amount billed to customers for shipping and handling in net sales ($125,000 and $130,000 in the three months ended December 31, 2015 and 2014, respectively and $256,000 and $257,000 in the six months ended December 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($225,000 and $240,000 in the three months ended December 31, 2015 and 2014, respectively and $441,000 and $481,000 in the six months ended December 31, 2015 and 2014, respectively).

[0001144204-16-078240:notes:61]
Recently Issued Accounting Standards

[0001144204-16-078240:notes:62]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s quarter ended September 30, 2016. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-16-078240:notes:63]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-16-078240:notes:64]
[same as prior period, unchanged from 0001144204-15-063875:notes:59]


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-16-078240:notes:65]
[same as prior period, unchanged from 0001144204-15-063875:notes:60]

[0001144204-16-078240:notes:66]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  22% of the Company’s accounts receivable at December 31, 2015 and  22% of the Company’s accounts receivable at June 30, 2015. Sales to this customer were  13% of net sales in the three months ended December 31, 2015 and  11% of net sales in the six months ended December 31, 2015. Sales to any one customer did not exceed  10% of net sales in the three or six months ended December 31, 2014.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-16-078240:notes:67]
[same as prior period, unchanged from 0001144204-15-063875:notes:62]

[0001144204-16-078240:notes:68]
[same as prior period, unchanged from 0001144204-15-063875:notes:63]

[0001144204-16-078240:notes:69]
[same as prior period, unchanged from 0001144204-15-063875:notes:64]

[0001144204-16-078240:notes:70]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
| Component parts |  | $ | 14,806 |  | $ | 15,037 |  |
| Work-in-process |  |  | 4,072 |  |  | 4,136 |  |
| Finished product |  |  | 7,579 |  |  | 7,697 |  |
|  |  | $ | 26,457 |  | $ | 26,870 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 21,723 |  | $ | 22,757 |  |
| Non-current |  |  | 4,734 |  |  | 4,113 |  |
|  |  | $ | 26,457 |  | $ | 26,870 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-16-078240:notes:71]
[same as prior period, unchanged from 0001144204-15-063875:notes:68]

[0001144204-16-078240:notes:72]
Property, plant and equipment consist of the following (in thousands):

[0001144204-16-078240:notes:73]
|  |  | December31, 2015 |  | June 30, 2015 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 7,032 |  |  | 7,002 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,504 |  |  | 2,478 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 20,644 |  |  | 20,429 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 294 |  |  | 294 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 40,289 |  |  | 40,018 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 34,198 |  |  | 33,784 |  |  |  |
|  |  | $ | 6,091 |  | $ | 6,234 |  |  |  |

[0001144204-16-078240:notes:74]
Depreciation and amortization expense on property, plant, and equipment was $209,000 and $210,000 for the three months ended December 31, 2015 and 2014, respectively and $414,000 and $412,000 for the six months ended December 31, 2015 and 2014, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-16-078240:notes:75]
[same as prior period, unchanged from 0001144204-15-063875:notes:70]

[0001144204-16-078240:notes:76]
[same as prior period, unchanged from 0001144204-15-063875:notes:71]

[0001144204-16-078240:notes:77]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of December 31, 2015 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2012 and thereafter.

[0001144204-16-078240:notes:78]
[same as prior period, unchanged from 0001144204-15-063875:notes:73]


## us-gaap:LongTermDebtTextBlock

[0001144204-16-078240:notes:79]
NOTE 6 - Long-Term Debt

[0001144204-16-078240:notes:80]
As of December 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

[0001144204-16-078240:notes:81]
Outstanding balances and interest rates as of December 31, 2015 and June 30, 2015 are as follows:

[0001144204-16-078240:notes:82]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,900 |  |  | 1.8 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,900 |  |  | 1.8 | % | $ | 10,700 |  |  | 1.7 | % |

[0001144204-16-078240:notes:83]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-16-078240:notes:84]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-16-078240:notes:85]
[same as prior period, unchanged from 0001144204-15-063875:notes:101]

[0001144204-16-078240:notes:86]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended December 31, 2015 and 2014, the Company recorded non-cash compensation expense of $60,000 ($.00 per basic and diluted share) and $67,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation. For the six months ended December 31, 2015 and 2014, the Company recorded non-cash compensation expense of $92,000 ($.00 per basic and diluted share) and $101,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-16-078240:notes:87]
[same as prior period, unchanged from 0001144204-15-063875:notes:103]

[0001144204-16-078240:notes:88]
In December 2012, the stockholders approved the 2012 Employee Stock Option Plan (the 2012 Employee Plan). The 2012 Employee Plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  950,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options, which are intended to qualify as incentive stock options (ISOs), to valued employees. Any plan participant who is granted ISOs and possesses more than 10% of the voting rights of the Company's outstanding common stock must be granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-16-078240:notes:89]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2015,  112,500 stock options were granted,  53,500 stock options were exercisable and  837,500 stock options were available for grant under this plan.

[0001144204-16-078240:notes:90]
The following table reflects activity under the 2012 Plan for the six months ended December 31,:

[0001144204-16-078240:notes:91]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 112,500 |  | $ | 5.30 |  |  | 78,500 |  | $ | 5.73 |  |
| Granted |  |  | — |  |  | — |  |  | 44,000 |  |  | 4.43 |  |
| Terminated/Lapsed |  |  | (15,000) |  |  | 4.29 |  |  | (10,000) |  |  | 4.88 |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 97,500 |  | $ | 5.46 |  |  | 112,500 |  | $ | 5.30 |  |
| Exercisable, end of period |  |  | 53,500 |  | $ | 5.54 |  |  | 27,500 |  | $ | 5.26 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 2.82 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 61,000 |  |  |  |  | $ | 13,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 30,000 |  |  |  |  | $ | 3,000 |  |  |  |  |

[0001144204-16-078240:notes:92]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at December 31, 2015:

[0001144204-16-078240:notes:93]
|  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $4.29-$6.31 |  |  | 97,500 |  |  | 8.1 |  | $ | 5.46 |  |  | 53,500 |  | $ | 5.54 |  |
|  |  |  | 97,500 |  |  | 8.1 |  | $ | 5.46 |  |  | 53,500 |  | $ | 5.54 |  |

[0001144204-16-078240:notes:94]
As of December 31, 2015, there was $157,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. No options were granted during the three or six months ended December 31, 2015. The total fair value of the options vesting during the three months ended December 31, 2015 and 2014 under this plan was $93,600 and $25,000, respectively. The total fair value of the options vesting during the six months ended December 31, 2015 and 2014 under this plan was $109,600 and $41,000, respectively.

[0001144204-16-078240:notes:95]
[same as prior period, unchanged from 0001144204-15-063875:notes:113]

[0001144204-16-078240:notes:96]
[same as prior period, unchanged from 0001144204-15-063875:notes:114]

[0001144204-16-078240:notes:97]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2015,  35,000 stock options were granted,  19,000 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-16-078240:notes:98]
The following table reflects activity under the 2012 Non-Employee Plan for the six months ended December 31,:

[0001144204-16-078240:notes:99]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 35,000 |  | $ | 4.73 |  |  | 25,000 |  | $ | 4.88 |  |
| Granted |  |  | — |  |  | — |  |  | 10,000 |  |  | 4.37 |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 35,000 |  | $ | 4.73 |  |  | 35,000 |  | $ | 4.73 |  |
| Exercisable, end of period |  |  | 19,000 |  | $ | 4.77 |  |  | 12,000 |  | $ | 4.80 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 2.86 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 41,000 |  |  |  |  | $ | 3,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 21,000 |  |  |  |  | $ | 1,000 |  |  |  |  |

[0001144204-16-078240:notes:100]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at December 31, 2015:

[0001144204-16-078240:notes:101]
|  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $4.37 - $4.88 |  |  | 35,000 |  |  | 8.0 |  | $ | 4.73 |  |  | 19,000 |  | $ | 4.77 |  |
|  |  |  | 35,000 |  |  | 8.0 |  | $ | 4.73 |  |  | 19,000 |  | $ | 4.77 |  |

[0001144204-16-078240:notes:102]
As of December 31, 2015, there was $50,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the three or six months ended December 31, 2015. The total fair value of the options vesting during the each of the three months ended December 31, 2015 and 2014 under this plan was $6,000. The total fair value of the options vesting during each of the six months ended December 31, 2015 and 2014 under this plan was $22,000.

[0001144204-16-078240:notes:103]
[same as prior period, unchanged from 0001144204-15-063875:notes:121]

[0001144204-16-078240:notes:104]
[same as prior period, unchanged from 0001144204-15-063875:notes:122]

[0001144204-16-078240:notes:105]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At December 31, 2015,  1,471,480 stock options had been granted and  264,750 stock options were exercisable. No further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-16-078240:notes:106]
The following table reflects activity under the 2002 Employee plan for the six months ended December 31,:

[0001144204-16-078240:notes:107]
|  |  | 2015 |  | 2014 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 208,500 |  | $ | 6.86 |  |  | 265,750 |  | $ | 6.51 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (1,000) |  |  | 6.02 |  |  | (1,000) |  |  | 6.02 |  |
| Exercised |  |  | (67,500) |  |  | 5.73 |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 140,000 |  | $ | 7.41 |  |  | 264,750 |  | $ | 6.51 |  |
| Exercisable, end of period |  |  | 140,000 |  | $ | 7.41 |  |  | 264,750 |  | $ | 6.51 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 9,000 |  |  |  |  | $ | — |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 9,000 |  |  |  |  | $ | — |  |  |  |  |

[0001144204-16-078240:notes:108]
67,500 and 0 stock options were exercised during the three and six months ended December 31, 2015 and 2014, respectively. All of the  67,500 exercises were settled by exchanging  53,868 shares of the Company’s common stock which were placed into Treasury Stock. No cash was received from option exercises during the three or six months ended December 31, 2015 and 2014 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-16-078240:notes:109]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at December 31, 2015:

[0001144204-16-078240:notes:110]
|  |  | Options outstanding and exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  |
| $5.22-$6.62 |  |  | 102,500 |  |  | 1.2 |  | $ | 6.04 |  |
| $11.16 |  |  | 37,500 |  |  | 0.2 |  |  | 11.16 |  |
|  |  |  | 140,000 |  |  | 0.9 |  | $ | 7.41 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-16-078240:notes:111]
[same as prior period, unchanged from 0001144204-15-063875:notes:74]

[0001144204-16-078240:notes:112]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the six months ended December 31, 2015 the Company repurchased  116,224 shares of its outstanding common stock for a weighted average price of $5.90 per share. These repurchased shares are included in the Company’s Treasury Stock as of December 31, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-16-078240:notes:113]
[same as prior period, unchanged from 0001144204-15-063875:notes:76]

[0001144204-16-078240:notes:114]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $27,000 and $41,000 for the three months ended December 31, 2015 and 2014, respectively, and $55,000 and $67,000 for the six months ended December 31, 2015 and 2014, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-16-078240:notes:115]
NOTE 10 - Commitments and Contingencies

[0001144204-16-078240:notes:116]
Leases

[0001144204-16-078240:notes:117]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2020.

[0001144204-16-078240:notes:118]
Rent expense, with the exception of the land lease referred to below, totaled approximately $8,000 and $9,000 for the three months ended December 31, 2015 and 2014, respectively and $15,000 and $16,000 for the six months ended December 31, 2015 and 2014, respectively.

[0001144204-16-078240:notes:119]
Land Lease

[0001144204-16-078240:notes:120]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-16-078240:notes:121]
Litigation

[0001144204-16-078240:notes:122]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-16-078240:notes:123]
Employment Agreements

[0001144204-16-078240:notes:124]
As of December 31, 2015, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-16-078240:notes:125]
[same as prior period, unchanged from 0001144204-15-063875:notes:88]

[0001144204-16-078240:notes:126]
[same as prior period, unchanged from 0001144204-15-063875:notes:89]

[0001144204-16-078240:notes:127]
[same as prior period, unchanged from 0001144204-15-063875:notes:90]

[0001144204-16-078240:notes:128]
|  |  | Three months ended December 31, |  | Six months ended December 31, |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
|  |  | (in thousands) |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 19,729 |  | $ | 18,876 |  | $ | 37,286 |  | $ | 35,448 |  |
| Foreign |  |  | 768 |  |  | 695 |  |  | 1,360 |  |  | 1,459 |  |
| Total Net Sales |  | $ | 20,497 |  | $ | 19,571 |  | $ | 38,646 |  | $ | 36,907 |  |

[0001144204-16-078240:notes:129]
|  |  | December 31, 2015 |  | June 30, 2015 |  |  |  |  |  |  |
| Identifiable assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 47,929 |  | $ | 50,998 |  |  |  |  |  |  |
| Dominican Republic (2) |  |  | 13,531 |  |  | 14,039 |  |  |  |  |  |  |
| Total Identifiable Assets |  | $ | 61,460 |  | $ | 65,037 |  |  |  |  |  |  |

[0001144204-16-078240:notes:130]
[same as prior period, unchanged from 0001144204-15-063875:notes:93]

[0001144204-16-078240:notes:131]
(2) Consists primarily of inventories (December 31, 2015 = $10,070, June 30, 2015 = $10,546) and fixed assets (December 31, 2015 = $3,279, June 30, 2015 = $3,347) located at the Company's principal manufacturing facility in the Dominican Republic.
