# NSSC note change history — 0001144204-15-063875 → 0001144204-16-078240


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001144204-16-078240:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $8,000 and $9,000 for the three months ended December 31, 2015 and 2014, respectively and $15,000 and $16,000 for the six months ended December 31, 2015 and 2014, respectively.
  (was, 2015-11-09, similarity 0.8173):
[0001144204-15-063875:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $7,000 for the three months ended September 30, 2015 and 2014, respectively.

- changed (2016-02-01):
[0001144204-16-078240:note_history:2]
As of December 31, 2015, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2018 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions.
  (was, 2015-11-09, similarity 0.6448):
[0001144204-15-063875:note_history:2]
As of September 30, 2015, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October  2016 and provides for an annual salary of $306,000, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for nine months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001144204-16-078240:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2015 in the amount of $7,900,000 approximates fair value.
  (was, 2015-11-09, similarity 0.9871):
[0001144204-15-063875:note_history:3]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2015 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2015 in the amount of $9,300,000 approximates fair value.

- changed (2016-02-01):
[0001144204-16-078240:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.
  (was, 2015-11-09, similarity 0.9858):
[0001144204-15-063875:note_history:4]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2015 and June 30, 2015. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2015 and June 30, 2015. The Company has historically not experienced any credit losses with balances in excess of FDIC limits.

- added (2016-02-01):
[0001144204-16-078240:note_history:5]
Accounts Receivable

- changed (2016-02-01):
[0001144204-16-078240:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $90,000 and $175,000 and for returns and other allowances of $995,000 and $1,260,000 as of December 31, 2015 and June 30, 2015, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2015-11-09, similarity 0.9926):
[0001144204-15-063875:note_history:6]
Accounts receivable is stated net of the reserves for doubtful accounts of $100,000 and $175,000 and for returns and other allowances of $930,000 and $1,260,000 as of September 30, 2015 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.

- added (2016-02-01):
[0001144204-16-078240:note_history:7]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,082) |  | $ | 2,718 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,422) |  | $ | 8,618 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

- added (2016-02-01):
[0001144204-16-078240:note_history:8]
Amortization expense for intangible assets subject to amortization was approximately $131,000 and $167,000 for the three months ended December 31, 2015 and 2014, respectively. Amortization expense for intangible assets subject to amortization was approximately $268,000 and $333,000 for the six months ended December 31, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.6 years and  13.5 years at December 31, 2015 and 2014, respectively.

- changed (2016-02-01):
[0001144204-16-078240:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.
  (was, 2015-11-09, similarity 0.9549):
[0001144204-15-063875:note_history:9]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

- changed (2016-02-01):
[0001144204-16-078240:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the six months ended December 31, 2015 and 2014, respectively.
  (was, 2015-11-09, similarity 0.9561):
[0001144204-15-063875:note_history:10]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 7% and 8% for the each of the three months ended September 30, 2015 and 2014, respectively.

- changed (2016-02-01):
[0001144204-16-078240:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2015 and 2014 was $510,000 and $312,000, respectively. Advertising expense for the six months ended December 31, 2015 and 2014 was $1,068,000 and $856,000, respectively.
  (was, 2015-11-09, similarity 0.8411):
[0001144204-15-063875:note_history:11]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2015 and 2014 was $558,000 and $544,000, respectively.

- changed (2016-02-01):
[0001144204-16-078240:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2015 and 2014 was $1,519,000 and $1,335,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2015 and 2014 was $3,008,000 and $2,653,000, respectively.
  (was, 2015-11-09, similarity 0.8184):
[0001144204-15-063875:note_history:12]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2015 and 2014 was $1,489,000 and $1,311,000, respectively.

- changed (2016-02-01):
[0001144204-16-078240:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):
  (was, 2015-11-09, similarity 0.9856):
[0001144204-15-063875:note_history:13]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

- changed (2016-02-01):
[0001144204-16-078240:note_history:14]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 976 |  | $ | 951 |  |  | 18,931 |  |  | 19,188 |  | $ | 0.05 |  | $ | 0.05 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 26 |  |  | 1 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 976 |  | $ | 951 |  |  | 18,957 |  |  | 19,189 |  | $ | 0.05 |  | $ | 0.05 |  |
  (was, 2015-11-09, similarity 0.9875):
[0001144204-15-063875:note_history:14]
|  |  | Net Income | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 | 2015 | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 315 |  | $ | 159 |  |  | 18,965 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 21 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 315 |  | $ | 159 |  |  | 18,986 |  |  | 19,412 |  | $ | 0.02 |  | $ | 0.01 |  |

- changed (2016-02-01):
[0001144204-16-078240:note_history:15]
Options to purchase  106,000 and  368,250 shares of common stock for the three months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2015-11-09, similarity 0.9877):
[0001144204-15-063875:note_history:15]
Options to purchase  170,000 and  145,500 shares of common stock for the three months ended September 30, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2016-02-01):
[0001144204-16-078240:note_history:16]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- added (2016-02-01):
[0001144204-16-078240:note_history:17]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  |
| Basic EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,948 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,291 |  | $ | 1,110 |  |  | 18,971 |  |  | 19,304 |  | $ | 0.07 |  | $ | 0.06 |  |

- added (2016-02-01):
[0001144204-16-078240:note_history:18]
Options to purchase  137,750 and  256,875 shares of common stock for the six months ended December 31, 2015 and 2014, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- changed (2016-02-01):
[0001144204-16-078240:note_history:19]
Stock-based compensation costs of $60,000 and $68,000 were recognized for three months ended December 31, 2015 and 2014, respectively. Stock-based compensation costs of $92,000 and $101,000 were recognized for six months ended December 31, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2015 and 2014.
  (was, 2015-11-09, similarity 0.6643):
[0001144204-15-063875:note_history:19]
Stock-based compensation costs of $32,000 and $33,000 were recognized for three months ended September 30, 2015 and 2014, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2015 and 2014.

- changed (2016-02-01):
[0001144204-16-078240:note_history:20]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2015 and 2014.
  (was, 2015-11-09, similarity 0.952):
[0001144204-15-063875:note_history:20]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2015 and 2014.

- added (2016-02-01):
[0001144204-16-078240:note_history:21]
For the three and six months ended December 31, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2016-02-01):
[0001144204-16-078240:note_history:22]
The Company records the amount billed to customers for shipping and handling in net sales ($125,000 and $130,000 in the three months ended December 31, 2015 and 2014, respectively and $256,000 and $257,000 in the six months ended December 31, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($225,000 and $240,000 in the three months ended December 31, 2015 and 2014, respectively and $441,000 and $481,000 in the six months ended December 31, 2015 and 2014, respectively).
  (was, 2015-11-09, similarity 0.7941):
[0001144204-15-063875:note_history:22]
The Company records the amount billed to customers for shipping and handling in net sales ($131,000 and $127,000 in the three months ended September 30, 2015 and 2014, respectively) and classifies the costs associated with these revenues in cost of sales ($216,000 and $241,000 in the three months ended September 30, 2015 and 2014, respectively).

- added (2016-02-01):
[0001144204-16-078240:note_history:23]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s quarter ended September 30, 2016. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

- removed (2016-02-01):
[0001144204-15-063875:note_history:24]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  |  |  | Accumulated |  | Net book |  |  |  | Accumulated |  | Net book |  |
|  |  | Cost |  | amortization |  | value |  | Cost |  | amortization |  | value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,951) |  | $ | 2,849 |  | $ | 9,800 |  | $ | (6,820) |  | $ | 2,980 |  |
| Non-compete agreement |  |  | 340 |  |  | (340) |  |  | — |  |  | 340 |  |  | (334) |  |  | 6 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (7,291) |  | $ | 8,749 |  | $ | 16,040 |  | $ | (7,154) |  | $ | 8,886 |  |

- removed (2016-02-01):
[0001144204-15-063875:note_history:25]
Amortization expense for intangible assets subject to amortization was approximately $137,000 and $166,000 for the three months ended September 30, 2015 and 2014, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2016 - $529,000; 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000. The weighted average amortization period for intangible assets was  12.9 years and  13.7 years at September 30, 2015 and 2014, respectively.

- removed (2016-02-01):
[0001144204-15-063875:note_history:26]
For the three months ended September 30, 2015 and 2014, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001144204-16-078240:note_history:27]
As of December 31, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.
  (was, 2015-11-09, similarity 0.9933):
[0001144204-15-063875:note_history:27]
As of September 30, 2015, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000.

- changed (2016-02-01):
[0001144204-16-078240:note_history:28]
Outstanding balances and interest rates as of December 31, 2015 and June 30, 2015 are as follows:
  (was, 2015-11-09, similarity 0.9714):
[0001144204-15-063875:note_history:28]
Outstanding balances and interest rates as of September 30, 2015 and June 30, 2015 are as follows:

- changed (2016-02-01):
[0001144204-16-078240:note_history:29]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,900 |  |  | 1.8 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,900 |  |  | 1.8 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2015-11-09, similarity 0.988):
[0001144204-15-063875:note_history:29]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 7,300 |  |  | 1.7 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 9,300 |  |  | 1.7 | % | $ | 10,700 |  |  | 1.7 | % |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001144204-16-078240:note_history:30]
Outstanding balances and interest rates as of December 31, 2015 and June 30, 2015 are as follows:
  (was, 2015-11-09, similarity 0.9714):
[0001144204-15-063875:note_history:30]
Outstanding balances and interest rates as of September 30, 2015 and June 30, 2015 are as follows:

- changed (2016-02-01):
[0001144204-16-078240:note_history:31]
|  |  | December 31, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 5,900 |  |  | 1.8 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 7,900 |  |  | 1.8 | % | $ | 10,700 |  |  | 1.7 | % |
  (was, 2015-11-09, similarity 0.988):
[0001144204-15-063875:note_history:31]
|  |  | September 30, 2015 |  | June 30, 2015 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 3,000 |  |  | 1.7 | % |
| Term loans |  |  | 7,300 |  |  | 1.7 | % |  | 7,700 |  |  | 1.7 | % |
| Total debt |  | $ | 9,300 |  |  | 1.7 | % | $ | 10,700 |  |  | 1.7 | % |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-02-01):
[0001144204-16-078240:note_history:32]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of reserves established for sales returns and other allowances.
  (was, 2015-11-09, similarity 0.9549):
[0001144204-15-063875:note_history:32]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.
