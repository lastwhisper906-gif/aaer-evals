# NSSC MD&A — 0001157523-13-005478


## mdna

[0001157523-13-005478:mdna:1]
[same as prior period, unchanged from 0001157523-13-002629:mdna:1]

[0001157523-13-005478:mdna:2]
[same as prior period, unchanged from 0001157523-13-002629:mdna:2]

[0001157523-13-005478:mdna:3]
[same as prior period, unchanged from 0001157523-13-002629:mdna:3]

[0001157523-13-005478:mdna:4]
The Company is a diversified manufacturer of security products, encompassing electronic locking devices, intrusion and fire alarms and building access control systems. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment. International sales accounted for approximately 6% of our revenues for both of the three month periods ended September 30, 2013 and 2012.

[0001157523-13-005478:mdna:5]
[same as prior period, unchanged from 0001157523-13-002629:mdna:5]

[0001157523-13-005478:mdna:6]
The security products market is characterized by constant incremental innovation in product design and manufacturing technologies. Generally, the Company devotes 6-8% of revenues to research and development (R&D) on an annual basis. The Company does not expect products resulting from our R&D investments in fiscal 2014 to contribute materially to revenue during this fiscal year, but should benefit the Company over future years. In general, the new products introduced by the Company are initially shipped in limited quantities, and increase over time. Prices and manufacturing costs tend to decline over time as products and technologies mature.

[0001157523-13-005478:mdna:7]
[same as prior period, unchanged from 0001157523-13-002629:mdna:7]

[0001157523-13-005478:mdna:8]
We are subject to the effects of general economic and market conditions. In the event that the U.S. or international economic conditions deteriorate, our revenue, profit and cash-flow levels could be materially adversely affected in future periods. In the event of such deterioration, many of our current or potential future customers may experience serious cash flow problems and as a result may, modify, delay or cancel purchases of our products. Additionally, customers may not be able to pay, or may delay payment of, accounts receivable that are owed to us. If such events do occur, they may result in our expenses being too high in relation to our revenues and cash flows.

[0001157523-13-005478:mdna:9]
[same as prior period, unchanged from 0001157523-13-002629:mdna:9]

[0001157523-13-005478:mdna:10]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Deterioration of the current economic conditions may also affect this trend.

[0001157523-13-005478:mdna:11]
[same as prior period, unchanged from 0001157523-13-002629:mdna:11]

[0001157523-13-005478:mdna:12]
The Company's significant accounting policies are fully described in Note 1 to the Company's consolidated financial statements included in its 2013 Annual Report on Form 10-K.  Management believes the following critical accounting policies, among others, affect its more significant judgments and estimates used in the preparation of its consolidated financial statements.

[0001157523-13-005478:mdna:13]
[same as prior period, unchanged from 0001157523-13-002629:mdna:13]

[0001157523-13-005478:mdna:14]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001157523-13-005478:mdna:15]
[same as prior period, unchanged from 0001157523-13-002629:mdna:15]

[0001157523-13-005478:mdna:16]
Concentration of Credit Risk

[0001157523-13-005478:mdna:17]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had two customers with accounts receivable balances that aggregated 28% and 22% of the Company’s accounts receivable at September 30, 2013 and June 30, 2013, respectively. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.

[0001157523-13-005478:mdna:18]
In the ordinary course of business, we have established a reserve for doubtful accounts and customer deductions in the amount of $230,000 and $220,000 as of September 30, 2013 and June 30, 2013, respectively. Our reserve for doubtful accounts is a subjective critical estimate that has a direct impact on reported net earnings. This reserve is based upon the evaluation of accounts receivable agings, specific exposures and historical or anticipated events.

[0001157523-13-005478:mdna:19]
[same as prior period, unchanged from 0001157523-13-002629:mdna:16]

[0001157523-13-005478:mdna:20]
[same as prior period, unchanged from 0001157523-13-002629:mdna:17]

[0001157523-13-005478:mdna:21]
[same as prior period, unchanged from 0001157523-13-002629:mdna:18]

[0001157523-13-005478:mdna:22]
Intangible Assets

[0001157523-13-005478:mdna:23]
The Company evaluates its Intangible Assets for impairment at least on an annual basis. Those intangible assets that are classified as goodwill or as other intangibles with indefinite lives are not amortized. Impairment testing is performed in two steps: (i) the Company determines impairment by comparing the fair value of a reporting unit with its carrying value, and (ii) if there is impairment, the Company measures the amount of impairment loss by comparing the implied fair value of intangible assets with the carrying amount of the intangible assets.

[0001157523-13-005478:mdna:24]
[same as prior period, unchanged from 0001157523-13-002629:mdna:19]

[0001157523-13-005478:mdna:25]
[same as prior period, unchanged from 0001157523-13-002629:mdna:20]

[0001157523-13-005478:mdna:26]
[same as prior period, unchanged from 0001157523-13-002629:mdna:21]

[0001157523-13-005478:mdna:27]
|  |  | Three months ended September 30, (dollars in thousands) |  |
|  |  | 2013 |  |  | 2012 |  |  | % Increase/ (decrease) |  |
| Net sales |  | $ | 17,239 |  |  | $ | 15,216 |  |  |  | 13.3 | % |
| Gross profit |  |  | 5,039 |  |  |  | 4,136 |  |  |  | 21.8 | % |
| Gross profit as a % of net sales |  |  | 29.2 | % |  |  | 27.2 | % |  |  | 7.4 | % |
| Selling, general and administrative |  |  | 4,777 |  |  |  | 4,535 |  |  |  | 5.3 | % |
| Selling, general and administrative as a percentage of net sales |  |  | 27.7 | % |  |  | 29.8 | % |  |  | (7.0 | )% |
| Operating income (loss) |  |  | 262 |  |  |  | (399 | ) |  |  | 165.7 | % |
| Interest expense, net |  |  | 121 |  |  |  | 177 |  |  |  | (31.6 | )% |
| Other expense |  |  | 3 |  |  |  | 3 |  |  |  | -- | % |
| Provision (benefit) for income taxes |  |  | 15 |  |  |  | (145 | ) |  |  | 110.3 | % |
| Net income (loss) |  |  | 123 |  |  |  | (434 | ) |  |  | 128.3 | % |

[0001157523-13-005478:mdna:28]
Sales for the three months ended September 30, 2013 increased 13% to $17,239,000 as compared to $15,216,000 for the same period a year ago. In the increase in sales for the three months ended September 30, 2013 was due primarily to increased sales in the Company’s door-locking products ($1,283,000) and access control ($720,000) products. The increase in sales of door-locking products for the three months was due primarily to general increased demand for the Company’s door-locking products. The increase in the Company’s access control products was due primarily to a large order of $1,734,000 from a major university. The Company shipped $1,127,000 of this order during the quarter ended June 30, 2013 and completed delivery of the remaining $607,000 in during the quarter ended September 30, 2013.

[0001157523-13-005478:mdna:29]
Gross profit for the three months ended September 30, 2013 increased to $5,039,000 or 29.2% of sales as compared to $4,136,000 or 27.2% of sales for the same period a year ago. The increase in gross profit for the three months was primarily due to the aforementioned increase in net sales, a positive shift in product mix to the Company’s door-locking products and a $154,000 reduction in research and development costs as a result of the completion of development of the Company’s iBridge product line.

[0001157523-13-005478:mdna:30]
Selling, general and administrative expenses for the three months ended September 30, 2013 increased by $242,000 to $4,777,000 from $4,535,000 for the same period a year ago.  Selling, general and administrative expenses as a percentage of net sales decreased to 27.7% for the three months ended September 30, 2013 from 29.8% for the same period a year ago. The increase in dollars was due primarily from the addition of selling personnel.

[0001157523-13-005478:mdna:31]
Interest expense, net for the three months ended September 30, 2013 decreased by $56,000 to $121,000 as compared to $177,000 for the same period a year ago. The decrease in interest expense for the three months ended September 30, 2013 resulted from lower average outstanding debt during the three months ended September 30, 2013 as compared to the same period a year ago.

[0001157523-13-005478:mdna:32]
The Company’s provision for income taxes for the three months ended September 30, 2013 increased by $160,000 to a provision of $15,000 as compared to a benefit of $145,000 for the same period a year ago. The increase in the provision for income taxes was caused primarily by the increase in income before income taxes as well as a change in the proportion of the income before income taxes being generated by the Company’s U.S. operations to the loss being generated by non-taxable foreign operations for the three months ended September 30, 2013 as compared to the same period a year ago. As a result, the Company’s effective rate for income tax was 11% and 25% for the three months ended September 30, 2013 and 2012, respectively.

[0001157523-13-005478:mdna:33]
Net income increased by $557,000 to $123,000 or $0.01 per diluted share for the three months ended September 30, 2013 as compared to a loss of $(434,000) or $(0.02) per diluted share for the same period a year ago. The changes for the three months ended September 30, 2013 were primarily due to the items as described above.

[0001157523-13-005478:mdna:34]
[same as prior period, unchanged from 0001157523-13-002629:mdna:31]

[0001157523-13-005478:mdna:35]
During the three months ended September 30, 2013 the Company utilized a portion of its cash from operations ($3,305,000 of $3,782,000) to repay outstanding debt ($2,900,000), purchase treasury stock ($285,000) and purchase property, plant and equipment ($125,000). The Company believes its current working capital, cash flows from operations and its revolving credit agreement will be sufficient to fund the Company’s operations through the next twelve months.

[0001157523-13-005478:mdna:36]
Accounts Receivable at September 30, 2013 decreased $3,923,000 to $14,288,000 as compared to $18,211,000 at June 30, 2013.  This decrease is primarily the result of the lower sales volume during the quarter ended September 30, 2013 as compared to the quarter ended June 30, 2013, which is typically the Company’s highest.

[0001157523-13-005478:mdna:37]
Inventories at September 30, 2013 increased $1,520,000 to $23,427,000 as compared to $21,907,000 at June 30, 2013. This increase is primarily the result of the Company keeping additional inventory of recently introduced products as well as level-loading its production facility in the Dominican Republic.

[0001157523-13-005478:mdna:38]
Accounts payable and accrued expenses increased $879,000 to $7,894,000 as of September 30, 2013 as compared to $7,015,000 at June 30, 2013.  This increase is due primarily to the increase in inventory discussed above.

[0001157523-13-005478:mdna:39]
As of September 30, 2013, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Terms Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal, quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal, quarterly payments of $325,000. As of September 30, 2013, the Company had $3,000,000 in outstanding borrowings and $8,000,000 in availability under the Revolving Credit Facility. The Company’s long-term debt is described more fully in Note 6 to the condensed consolidated financial statements.

[0001157523-13-005478:mdna:40]
The agreements contain various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the restated agreement.

[0001157523-13-005478:mdna:41]
As of September 30, 2013 the Company had no material commitments for capital expenditures or inventory purchases other than purchase orders issued in the normal course of business.
