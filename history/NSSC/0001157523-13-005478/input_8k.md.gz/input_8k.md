# NSSC 8-K — 0001157523-13-005435 filed 2013-11-12

## item codes, every 8-K on or before 2013-11-12

- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2013-11-12

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-13-005435:8k_2_02:1]
EX-99.1
2
a50748421ex99_1.htm
EXHIBIT 99.1

[0001157523-13-005435:8k_2_02:2]
a50748421ex99_1.htm

[0001157523-13-005435:8k_2_02:3]
Exhibit 99.1

[0001157523-13-005435:8k_2_02:4]
NAPCO Reports Financial Results for Three Months Ended September 30, 2013

[0001157523-13-005435:8k_2_02:5]
-Q1 Revenue Increases 13%, Net Income Increases $557,000 -

[0001157523-13-005435:8k_2_02:6]
-Highest Q1 Levels in Five Years -

[0001157523-13-005435:8k_2_02:7]
Management to Host Conference Call Today at 11 a.m.

[0001157523-13-005435:8k_2_02:8]
AMITYVILLE, N.Y., November 11, 2013 -- NAPCO Security Technologies, Inc. (NASDAQ:NSSC), one of the world's leading suppliers of high performance electronic security equipment for over 30 years, today announced financial results for its first quarter ended September 30, 2013.

[0001157523-13-005435:8k_2_02:9]
Highlights:

[0001157523-13-005435:8k_2_02:10]
|  | ● | Net sales were $17.2 million, a 13% increase compared to last year and the highest Q1 revenue in five years. |

[0001157523-13-005435:8k_2_02:11]
|  | ● | Sales within the Marks brand of products grew 23% compared to last year, representing the fifth consecutive quarter of year-over-year growth in this unit. |

[0001157523-13-005435:8k_2_02:12]
|  | ● | StarLink recurring revenue for the quarter increased 110% as compared to last year and grew sequentially by 13% as demand for our recurring revenue producing wireless security communicator continues to accelerate. |

[0001157523-13-005435:8k_2_02:13]
|  | ● | Gross margin improved 200 basis points to 29.2% as compared to 27.2% for the same period last year. |

[0001157523-13-005435:8k_2_02:14]
|  | ● | Adjusted EBITDA (*see table attached) was $725,000, an increase of $640,000 over last year and the highest Q1 level in five years. |

[0001157523-13-005435:8k_2_02:15]
|  | ● | Net Income increased by $557,000 compared to last year to $123,000 which is the highest Q1 net income in five years. |

[0001157523-13-005435:8k_2_02:16]
|  | ● | NAPCO reduced its debt by $3.4 million during the quarter. Debt, net of cash, was $9.8 million as of September 30, 2013, a reduction of $26.1 million since acquiring Marks in August of 2008. |

[0001157523-13-005435:8k_2_02:17]
|  | ● | Net Cash Provided by Operating Activities increased 141% to $3.8 million as compared to $1.6 million a year ago. |

[0001157523-13-005435:8k_2_02:18]
Richard Soloway, Chairman and President stated, “NAPCO delivered another strong quarter with growth coming from each of our four major business Divisions; NAPCO Security & Fire, Alarm Lock Electronic Access Control Locking, Mark’s USA Architectural Hardware and Continental Enterprise-Class Access Control. Our efforts to develop, introduce and promote product lines which deliver recurring monthly revenue to the Company are paying off. In fact, the launch of the enhanced Starlink3™ 3G/4G Wireless Communicator has achieved record-setting levels of initial subscription activations for a product in this class. We are seeing accelerating demand for our StarLink product line. Additionally, other SaaS, subscription-based product lines, such as iBridge™ Connected Home Services and iSee Video™ Remote Video Services, continue to build solid growth, providing more predictability to our revenues and helping to reduce seasonality inherent in our business. The bottom line improvement demonstrates the leverage in our financial model at higher revenue levels as well as the impact of recurring revenue.”

[0001157523-13-005435:8k_2_02:19]
Mr. Soloway added, “Q1 saw the introduction of our Project LocDown™ cross-divisional initiative, which aims to bring a higher level of security and access control to K-12 schools, universities and public facilities where attacks by active shooters are a threat. The Company has launched the School Access-Control Vulnerability Index (S.A.V.I.), Audit and Dealer Certification Process to the industry and educational community. The program aims to have an industry-wide initiative whereby a school facility’s holistic security level can be quantitatively measured. This will help educational facilities identify and address vulnerabilities in access control points, and will provide administrators with authoritative, comprehensive recommendations for appropriate security systems. Our Marks USA LocDown™ intruder locks, Alarm Lock’s Networx™ wireless locks and Continental’s Access Control’s card access systems and software, provide a unique, end-to-end access control and lock-down solution to the education market, and we look forward to working with providers in adjacent technologies to advance this important educational initiative.”

[0001157523-13-005435:8k_2_02:20]
Mr. Soloway concluded, “Our primary objective for fiscal 2014 and beyond is to continue to work aggressively to gain market penetration and increase market share throughout each of our Divisions. Our strong balance sheet and cash flows allow us the flexibility to continue to bring innovative state-of-the-art security products to market at a rapid pace. Historically, our quarters get stronger as the fiscal year progresses. Fiscal 2014 is off to a good start and we believe we are well positioned to achieve increased revenue and profitability for this fiscal year and years to come.”

[0001157523-13-005435:8k_2_02:21]
Fiscal First Quarter 2014 Results

[0001157523-13-005435:8k_2_02:22]
Revenues for the three months ended September 30, 2013 increased 13% to $17.2 million, as compared to $15.2 million for the same period one year ago. The Company experienced growth in each of its four major divisions.

[0001157523-13-005435:8k_2_02:23]
Selling, general and administrative expenses for the first quarter increased $242,000 to $4.8 million from $4.5 million for the same period in fiscal 2013. Operating income for the first quarter was $262,000, representing a positive swing of $661,000 compared to a loss of $(399,000) for the same period last year. Adjusted EBITDA* for the first quarter increased $640,000, to $725,000 as compared to $85,000 for the same period last year (*see table attached).

[0001157523-13-005435:8k_2_02:24]
Net income for the quarter increased by $557,000 to $123,000 or $0.01 per share as compared to a loss of $(434,000) or $(0.02) per share for the same period last year.

[0001157523-13-005435:8k_2_02:25]
Balance Sheet Summary

[0001157523-13-005435:8k_2_02:26]
At September 30, 2013, the Company had $3.7 million in cash and cash equivalents an increase of $477,000 compared to $3.2 million at June 30, 2013. NAPCO had working capital of $30.5 million as compared with working capital of $33.2 million at June 30, 2013. Current ratio was 4.2:1 as compared to 4.9:1 at June 30, 2013. Debt, net of cash, was $9.8 million at September 30, 2013, a decrease of $3.4 million compared to $13.2 million as of June 30, 2013.

[0001157523-13-005435:8k_2_02:27]
Conference Call Information

[0001157523-13-005435:8k_2_02:28]
Management will conduct a conference call at 11 a.m. today, November 11, 2013. Interested parties may participate in the call by dialing 1-877-941-2068 or for international callers, 1-480-629-9712, about 5-10 minutes prior to the start time of 11:00 a.m. ET. The conference call will also be available on replay starting at 2:00 p.m. ET on November 11, 2013 and ending on November 18, 2013. For the replay, please dial 1-877-870-5176 domestically, or 1-858-384-5517 for international callers, and use the replay access code, 4646935.

[0001157523-13-005435:8k_2_02:29]
In addition, the call will be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=106542.

[0001157523-13-005435:8k_2_02:30]
About NAPCO Security Technologies, Inc.

[0001157523-13-005435:8k_2_02:31]
NAPCO Security Technologies, Inc. is one of the world's leading manufacturers of technologically advanced electronic security equipment including intrusion and fire alarm systems, access control and door locking systems. The Company consists of NAPCO plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. The products are installed by security professionals worldwide in commercial, industrial, institutional, residential and government applications. NAPCO products have earned a reputation for technical excellence, reliability and innovation, poising the Company for growth in the rapidly expanding electronic security market, a multi-billion dollar market.

[0001157523-13-005435:8k_2_02:32]
For additional information on NAPCO, please visit the Company's web site at www.napcosecurity.com.

[0001157523-13-005435:8k_2_02:33]
Safe Harbor Statement

[0001157523-13-005435:8k_2_02:34]
This press release contains forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's filings with the Securities and Exchange Commission.

[0001157523-13-005435:8k_2_02:35]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
|  |  | September 30, 2013 |  |  |  |  |
|  |  | (unaudited) |  |  | June 30, 2013 |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,706 |  |  | $ | 3,229 |  |
| Accounts receivable, net of reserves and allowances |  |  | 14,288 |  |  |  | 18,211 |  |
| Inventories |  |  | 20,041 |  |  |  | 18,471 |  |
| Prepaid expenses and other current assets |  |  | 1,242 |  |  |  | 1,219 |  |
| Income tax receivable |  |  | 23 |  |  |  | 64 |  |
| Deferred income taxes |  |  | 671 |  |  |  | 642 |  |
| Total Current Assets |  |  | 39,971 |  |  |  | 41,836 |  |
| Inventories - non-current |  |  | 3,386 |  |  |  | 3,436 |  |
| Deferred income taxes |  |  | 1,551 |  |  |  | 1,526 |  |
| Property, plant and equipment, net |  |  | 6,495 |  |  |  | 6,586 |  |
| Intangible assets, net |  |  | 10,138 |  |  |  | 10,334 |  |
| Other assets |  |  | 189 |  |  |  | 185 |  |
| TOTAL ASSETS |  | $ | 61,730 |  |  | $ | 63,903 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 4,162 |  |  |  | 3,318 |  |
| Accrued expenses |  |  | 1,780 |  |  |  | 2,093 |  |
| Accrued salaries and wages |  |  | 1,952 |  |  |  | 1,604 |  |
| Total Current Liabilities |  |  | 9,494 |  |  |  | 8,615 |  |
| Long-term debt, net of current maturities |  |  | 11,900 |  |  |  | 14,800 |  |
| Accrued income taxes |  |  | 157 |  |  |  | 153 |  |
| Total Liabilities |  |  | 21,551 |  |  |  | 23,568 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,038,443 and 20,796,813 shares issued; and 19,408,276 and 19,296,335 shares outstanding, respectively |  |  | 210 |  |  |  | 208 |  |
| Additional paid-in capital |  |  | 15,812 |  |  |  | 15,356 |  |
| Retained earnings |  |  | 32,201 |  |  |  | 32,078 |  |
|  |  |  | 48,223 |  |  |  | 47,642 |  |
| Less: Treasury Stock, at cost (1,603,167and 1,500,478 shares, respectively) |  |  | (8,044 | ) |  |  | (7,307 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 40,179 |  |  |  | 40,335 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 61,730 |  |  | $ | 63,903 |  |

[0001157523-13-005435:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (unaudited) |  |
|  |  | Three months ended September 30, |  |
|  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 17,239 |  |  | $ | 15,216 |  |
| Cost of sales |  |  | 12,200 |  |  |  | 11,080 |  |
| Gross Profit |  |  | 5,039 |  |  |  | 4,136 |  |
| Selling, general, and administrative expenses |  |  | 4,777 |  |  |  | 4,535 |  |
| Operating Income (Loss) |  |  | 262 |  |  |  | (399 | ) |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 121 |  |  |  | 177 |  |
| Other, net |  |  | 3 |  |  |  | 3 |  |
| Income (loss) before Income Taxes |  |  | 138 |  |  |  | (579 | ) |
| Income tax expense (benefit) |  |  | 15 |  |  |  | (145 | ) |
| Net Income (Loss) |  | $ | 123 |  |  | $ | (434 | ) |
| Net Income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.01 |  |  | $ | (0.02 | ) |
| Diluted |  | $ | 0.01 |  |  | $ | (0.02 | ) |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,323,000 |  |  |  | 19,097,000 |  |
| Diluted |  |  | 19,341,000 |  |  |  | 19,097,000 |  |

[0001157523-13-005435:8k_2_02:37]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |  |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |  |
|  |  | Three months ended September 30, |  |
|  |  | 2013 |  |  | 2012 |  |
|  |  | (In thousands) |  |
| Net income (loss) |  | $ | 123 |  |  | $ | (434 | ) |
| Add back income taxes expense (benefit) |  |  | 15 |  |  |  | (145 | ) |
| Add back interest and other expense |  |  | 124 |  |  |  | 180 |  |
| Operating income (loss) (GAAP) |  |  | 262 |  |  |  | (399 | ) |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 195 |  |  |  | 230 |  |
| Add back change to inventory reserve |  |  | 50 |  |  |  | -- |  |
| Add back stock-based compensation expense |  |  | 1 |  |  |  | -- |  |
| Adjusted non-GAAP operating income (loss) |  |  | 508 |  |  |  | (169 | ) |
| Add back depreciation and other amortization |  |  | 217 |  |  |  | 254 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 725 |  |  | $ | 85 |  |

[0001157523-13-005435:8k_2_02:38]
* Non-GAAP Information. Certain non-GAAP measures are included in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not include impairment of goodwill, amortization of intangibles, changes to inventory reserves, restructuring charges, stock-based compensation expense and other infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period. The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial measures included in the above.

[0001157523-13-005435:8k_2_02:39]
INVESTOR INQUIRIES:

[0001157523-13-005435:8k_2_02:40]
Brett Maas

[0001157523-13-005435:8k_2_02:41]
Hayden IR

[0001157523-13-005435:8k_2_02:42]
(646) 536-7331

[0001157523-13-005435:8k_2_02:43]
brett@haydenir.com

[0001157523-13-005435:8k_2_02:44]
Peter Seltzberg, Regional Vice-President

[0001157523-13-005435:8k_2_02:45]
Hayden IR

[0001157523-13-005435:8k_2_02:46]
(646) 415-8972

[0001157523-13-005435:8k_2_02:47]
peter@haydenir.com
