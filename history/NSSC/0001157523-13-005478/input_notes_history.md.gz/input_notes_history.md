# NSSC note change history — 0001157523-13-002629 → 0001157523-13-005478


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2013-11-12):
[0001157523-13-005478:note_history:1]
The
 Company is committed under various operating leases, not including
 the land lease discussed below, which do not extend beyond fiscal
 2016.

- changed (2013-11-12):
[0001157523-13-005478:note_history:2]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $9,000 and $13,000 for the three months ended
 September 30, 2013 and 2012, respectively.
  (was, 2013-05-13, similarity 0.6861):
[0001157523-13-002629:note_history:2]
The
Company is committed under various operating leases. Rent expense,
with the exception of the land lease referred to below, totaled
approximately $14,000 and $12,000 for the three months ended
March 31, 2013 and 2012, respectively and $37,000 and $38,000
for the nine months ended March 31, 2013 and 2012,
respectively.

- changed (2013-11-12):
[0001157523-13-005478:note_history:3]
As
 of June 30, 2013, the Company was obligated under two employment
 agreements and one severance agreement.  The employment
 agreements are with the Company’s CEO and Senior Vice
 President of Sales and Marketing (“the SVP”). The
 employment agreement with the CEO provides for an annual salary of
 $587,000, as adjusted for inflation; incentive compensation as may
 be approved by the Board of Directors from time to time and a
 termination payment in an amount up to 299% of the average of the
 prior five calendar year's compensation, subject to certain
 limitations, as defined in the agreement.  The employment
 agreement renews annually in August unless either party gives the
 other notice of non-renewal at least six months prior to the end of
 the applicable term. The employment agreement with the SVP expires
 in October 2014 and provides for an annual salary of $274,400 and,
 if terminated by the Company without cause, severance of nine
 months’ salary and continued company-sponsored health
 insurance for six months from the date of termination. The
 severance agreement provides for payments equal to nine months of
 salary and six months of health insurance in the event of a
 non-voluntary termination of employment without cause.
  (was, 2013-05-13, similarity 0.8858):
[0001157523-13-002629:note_history:3]
As
of March 31, 2013, the Company was obligated under two employment
agreements and one severance agreement.  The employment
agreements are with the Company’s Chief Executive Officer
(“the CEO”) and Senior Vice President of Sales and
Marketing (“the SVP”). The employment agreement with
the CEO provides for an annual salary of $587,000, as adjusted for
inflation; incentive compensation as may be approved by the Board
of Directors from time to time and a termination payment in an
amount up to 299% of the average of the prior five calendar year's
compensation, subject to certain limitations, as defined in the
agreement.  The employment agreement renews annually in
August unless either party gives the other notice of non-renewal at
least six months prior to the end of the applicable term. The
employment agreement with the SVP provides for an annual salary of
$274,400 and, if terminated by the Company without cause, severance
of nine months’ salary and continued company-sponsored health
insurance for six months from the date of termination.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001157523-13-005478:note_history:4]
Nature of Business:
  (was, 2013-05-13, similarity 0.973):
[0001157523-13-002629:note_history:4]
Nature
of Business

- changed (2013-11-12):
[0001157523-13-005478:note_history:5]
Significant Accounting Policies:
  (was, 2013-05-13, similarity 0.9841):
[0001157523-13-002629:note_history:5]
Significant
Accounting Policies

- added (2013-11-12):
[0001157523-13-005478:note_history:6]
Basis
 of Presentation

- added (2013-11-12):
[0001157523-13-005478:note_history:7]
The
 unaudited condensed consolidated financial statements of Napco
 Security Technologies, Inc and Subsidiaries (the
 “Company”), including these notes, have been prepared
 by the Company in accordance with U.S. generally accepted
 accounting principles (“GAAP”) for interim financial
 information and pursuant to the rules and regulations promulgated
 by the U.S. Securities and Exchange Commission (the
 “SEC”). Accordingly, certain information and
 disclosures normally included in financial statements prepared in
 accordance with GAAP have been omitted or condensed. However, in
 the opinion of management, all adjustments (consisting of normal
 recurring accruals) considered necessary for a fair presentation
 have been included. These unaudited condensed consolidated
 financial statements should be read in conjunction with the
 Company’s audited consolidated financial statements for the
 year ended June 30, 2013 and the notes thereto included in the
 Company’s Annual Report on Form 10-K filed with the SEC on
 September 17, 2013. Results of consolidated operations for the
 interim periods are not necessarily indicative of a full
 year’s operating results. The unaudited condensed
 consolidated financial statements herein include the accounts of
 the Company and its wholly owned subsidiaries. All material
 inter-company accounts and transactions have been
 eliminated.

- added (2013-11-12):
[0001157523-13-005478:note_history:8]
Fair
 Value of Financial Instruments

- added (2013-11-12):
[0001157523-13-005478:note_history:9]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 September 30, 2013 due to their short-term maturities; Long-Term
 Debt: The carrying amount of the Company’s long-term debt,
 including the current portion, at September 30, 2013 in the amount
 of $13,500,000 approximates fair value.

- added (2013-11-12):
[0001157523-13-005478:note_history:10]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at September 30, 2013 and June 30,
 2013.  The Company considers all highly liquid
 investments with original maturities of three months or less to be
 cash equivalents.  The Company has cash balances in banks
 in excess of the maximum amount insured by the FDIC and other
 international agencies as of September 30, 2013 and June 30, 2013.
 The Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

- changed (2013-11-12):
[0001157523-13-005478:note_history:11]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $230,000 and $220,000 and for returns and other allowances of
 $815,000 and $1,055,000 as of September 30, 2013 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.
  (was, 2013-05-13, similarity 0.9872):
[0001157523-13-002629:note_history:11]
Accounts
receivable is stated net of the reserves for doubtful accounts of
$220,000 and $200,000 and for returns and other allowances of
$1,045,000 and $1,184,000 as of March 31, 2013 and June 30, 2012,
respectively.  Our reserves for doubtful accounts and for
returns and other allowances are subjective critical estimates that
have a direct impact on reported net earnings. These reserves are
based upon the evaluation of accounts receivable agings, specific
exposures, sales levels and historical trends.

- changed (2013-11-12):
[0001157523-13-005478:note_history:12]
Inventories
 are valued at the lower of cost or fair market value, with cost
 being determined on the first-in, first-out (FIFO) method. The
 reported net value of inventory includes finished saleable
 products, work-in-process and raw materials that will be sold or
 used in future periods. Inventory costs include raw materials,
 direct labor and overhead. The Company’s overhead expenses
 are applied based, in part, upon estimates of the proportion of
 those expenses that are related to procuring and storing raw
 materials as compared to the manufacture and assembly of finished
 products. These proportions, the method of their application, and
 the resulting overhead included in ending inventory, are based in
 part on subjective estimates and actual results could differ from
 those estimates.
  (was, 2013-05-13, similarity 0.9735):
[0001157523-13-002629:note_history:12]
Inventories
are valued at the lower of cost or fair market value, with cost
being determined on the first-in, first-out (FIFO) method. The
reported net value of inventory includes finished saleable
products, work-in-process and raw materials that will be sold or
used in future periods. Inventory costs include raw materials,
direct labor and overhead. The Company’s overhead expenses
are applied based, in part, upon estimates of the amounts of those
expenses that are related to procuring and storing raw materials
and of those related to the manufacture and assembly of finished
products. These proportions, the method of their application, and
the resulting overhead included in ending inventory, are based in
part on subjective estimates and actual results could differ from
those estimates.

- added (2013-11-12):
[0001157523-13-005478:note_history:13]
In
 addition, the Company records an inventory obsolescence reserve,
 which represents any excess of the cost of the inventory over its
 estimated market value, based on various product sales projections.
 This reserve is calculated using an estimated obsolescence
 percentage applied to the inventory based on age, historical
 trends, requirements to support forecasted sales, and the ability
 to find alternate applications of its raw materials and to convert
 finished product into alternate versions of the same product to
 better match customer demand.  In addition, and as
 necessary, the Company may establish specific reserves for future
 known or anticipated events. There is inherent professional
 judgment and subjectivity made by both production and engineering
 members of management in determining the estimated obsolescence
 percentage.

- added (2013-11-12):
[0001157523-13-005478:note_history:14]
The
 Company also regularly reviews the period over which its
 inventories will be converted to sales. Any inventories
 expected to convert to sales beyond 12 months from the balance
 sheet date are classified as non-current.

- changed (2013-11-12):
[0001157523-13-005478:note_history:15]
Intangible
 assets determined to have indefinite lives are not amortized but
 are tested for impairment at least annually. Intangible assets with
 definite lives are amortized over their useful lives. Intangible
 assets are reviewed for impairment at least annually at the
 Company’s fiscal year end of June 30 or more often whenever
 there is an indication that the carrying amount may not be
 recovered.
  (was, 2013-05-13, similarity 0.99):
[0001157523-13-002629:note_history:15]
Certain
intangible assets determined to have indefinite lives are not
amortized but are tested for impairment at least annually.
Intangible assets with definite lives are amortized over their
useful lives. Intangible assets are reviewed for impairment at
least annually at the Company’s fiscal year end of June 30 or
more often whenever there is an indication that the carrying amount
may not be recovered.

- changed (2013-11-12):
[0001157523-13-005478:note_history:16]
The
 Company’s acquisition of substantially all of the assets and
 certain liabilities of G. Marks Hardware Inc. (“Marks
 USA”) in August 2008 included intangible assets recorded at
 fair value on the date of acquisition. The intangible assets are
 amortized over their estimated useful lives of twenty years
 (customer relationships) and seven years (non-compete agreement).
 The Marks USA trade name was deemed to have an indefinite
 life.
  (was, 2013-05-13, similarity 0.9474):
[0001157523-13-002629:note_history:16]
The
Company’s acquisition of substantially all of the assets and
certain liabilities of Marks included intangible assets recorded at
fair value on the date of acquisition. The intangible assets are
amortized over their estimated useful lives of twenty years
(customer relationships) and seven years (non-compete agreement).
The Marks USA trade name was deemed to have an indefinite
life.

- changed (2013-11-12):
[0001157523-13-005478:note_history:17]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,653 | ) |  | $ | 4,147 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (249 | ) |  |  | 91 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,902 | ) |  | $ | 10,138 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |
  (was, 2013-05-13, similarity 0.7466):
[0001157523-13-002629:note_history:17]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Other intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (5,252 | ) |  | $ | 4,548 |  |  | $ | 9,800 |  |  | $ | (4,601 | ) |  | $ | 5,199 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (225 | ) |  |  | 115 |  |  |  | 340 |  |  |  | (188 | ) |  |  | 152 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (5,477 | ) |  | $ | 10,563 |  |  | $ | 16,040 |  |  | $ | (4,789 | ) |  | $ | 11,251 |  |

- changed (2013-11-12):
[0001157523-13-005478:note_history:18]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $230,000 for the three months ended
 September 30, 2013 and 2012, respectively. Amortization expense for
 each of the next five fiscal years is estimated to be as follows:
 2014 - $781,000; 2015 - $667,000; 2016 - $529,000; 2017 - $441,000
 and 2018 - $371,000. The weighted average amortization period for
 intangible assets was 14.6 years and 15.5 years at September
 30, 2013 and 2012, respectively.
  (was, 2013-05-13, similarity 0.7947):
[0001157523-13-002629:note_history:18]
Amortization
expense for intangible assets subject to amortization was
approximately $229,000 and $266,000 for the three months ended
March 31, 2013 and 2012, respectively. Amortization expense for
intangible assets subject to amortization was approximately
$688,000 and $799,000 for the nine months ended March 31, 2013 and
2012, respectively. Amortization expense for each of the next five
fiscal years is estimated to be as follows: 2013 - $917,000; 2014 -
$781,000; 2015 - $667,000; 2016 - $529,000 and 2017 - $441,000. The
weighted average amortization period for intangible assets was 15.1
years and 15.8 years at March 31, 2013 and June 30, 2012,
respectively.

- changed (2013-11-12):
[0001157523-13-005478:note_history:19]
The
 Company recognizes revenue when the following criteria are met: (i)
 persuasive evidence of an agreement exists, (ii) there is a fixed
 and determinable price for the Company's product, (iii) shipment
 and passage of title occurs, and (iv) collectability is reasonably
 assured. Revenues from product sales are recorded at the time the
 product is shipped or delivered to the customer pursuant to the
 terms of the sale. The Company reports its sales on a net sales
 basis, with net sales being computed by deducting from gross sales
 the amount of actual sales returns and other allowances and the
 amount of reserves established for anticipated sales returns and
 other allowances.
  (was, 2013-05-13, similarity 0.9817):
[0001157523-13-002629:note_history:19]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.

- added (2013-11-12):
[0001157523-13-005478:note_history:20]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended September 30, 2013 and 2012 was
 $365,000 and $427,000, respectively.

- added (2013-11-12):
[0001157523-13-005478:note_history:21]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended September 30, 2013 and 2012 was
 $1,286,000 and $1,336,000, respectively.

- changed (2013-11-12):
[0001157523-13-005478:note_history:22]
Basic
 net income (loss) per common share (Basic EPS) is computed by
 dividing net income by the weighted average number of common shares
 outstanding.  Diluted net income (loss) per common share
 (Diluted EPS) is computed by dividing net income by the weighted
 average number of common shares and dilutive common share
 equivalents and convertible securities then
 outstanding.
  (was, 2013-05-13, similarity 0.9084):
[0001157523-13-002629:note_history:22]
Basic
net income (loss) per common share (Basic EPS) is computed by
dividing net income (loss) by the weighted average number of common
shares outstanding.  Diluted net income per common share
(Diluted EPS) is computed by dividing net income by the weighted
average number of common shares and dilutive common share
equivalents and convertible securities then
outstanding.

- changed (2013-11-12):
[0001157523-13-005478:note_history:23]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended
 September 30 (in thousands, except per share data):
  (was, 2013-05-13, similarity 0.8738):
[0001157523-13-002629:note_history:23]
The
following provides a reconciliation of information used in
calculating the per share amounts (in thousands, except per share
data):

- changed (2013-11-12):
[0001157523-13-005478:note_history:24]
|  |  | Net Income (Loss) |  |  | Weighted Average Shares |  |  | Net Income (Loss) per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 123 |  |  | $ | (434 | ) |  |  | 19,323 |  |  |  | 19,097 |  |  | $ | 0.01 |  |  | $ | (0.02 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 18 |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 123 |  |  | $ | (434 | ) |  |  | 19,341 |  |  |  | 19,097 |  |  | $ | 0.01 |  |  | $ | (0.02 | ) |
  (was, 2013-05-13, similarity 0.7802):
[0001157523-13-002629:note_history:24]
|  |  | Nine Months Ended March 31, |  |
|  |  | Net (Loss) Income |  |  | Weighted Average Shares |  |  | Net (Loss) Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,096 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | -- |  |  |  | 157 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | (188 | ) |  | $ | 445 |  |  |  | 19,181 |  |  |  | 19,253 |  |  | $ | (0.01 | ) |  | $ | 0.02 |  |

- changed (2013-11-12):
[0001157523-13-005478:note_history:25]
Options
 to purchase 268,116 and 1,383,140 shares of common stock for the
 three months ended September 30, 2013 and 2012, respectively, were
 not included in the computation of Diluted EPS because their
 inclusion would be anti-dilutive.  These options were
 still outstanding at the end of the respective
 periods.
  (was, 2013-05-13, similarity 0.9101):
[0001157523-13-002629:note_history:25]
Options
to purchase 672,740 and 733,880 shares of common stock for the nine
months ended March 31, 2013 and 2012, respectively, were not
included in the computation of Diluted EPS because their inclusion
would be anti-dilutive.  These options were still
outstanding at the end of the respective periods.

- changed (2013-11-12):
[0001157523-13-005478:note_history:26]
The
 Company has established share incentive programs as discussed in
 Note 7.
  (was, 2013-05-13, similarity 0.974):
[0001157523-13-002629:note_history:26]
The
Company has established two share incentive programs as discussed
in Note 8.

- added (2013-11-12):
[0001157523-13-005478:note_history:27]
Stock-based
 compensation costs of $1 and $0 were recognized for the three
 months ended September 30, 2013 and 2012,
 respectively.

- changed (2013-11-12):
[0001157523-13-005478:note_history:28]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at average exchange rates
 prevailing during the fiscal year.  The realized and
 unrealized gains and losses associated with foreign currency
 translation, as well as related other comprehensive income, were
 not material for the three months ended September 30, 2013 and
 2012.
  (was, 2013-05-13, similarity 0.9426):
[0001157523-13-002629:note_history:28]
All
assets and liabilities of foreign subsidiaries are translated into
U.S. Dollars at fiscal period-end exchange rates.  Income
and expense items are translated at average exchange rates
prevailing during the fiscal year.  The realized and
unrealized gains and losses associated with foreign currency
translation, as well as related other comprehensive income, were
not material for the three and nine months ended March 31, 2013 and
2012.

- added (2013-11-12):
[0001157523-13-005478:note_history:29]
For
 the three months ended September 30, 2013 and 2012, the Company's
 operations did not give rise to material items includable in
 comprehensive income, which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.

- changed (2013-11-12):
[0001157523-13-005478:note_history:30]
The
 Company records the amount billed to customers in net sales
 ($131,000 and $121,000 in the three months ended September 30, 2013
 and 2012, respectively) and classifies the costs associated with
 these revenues in cost of sales ($242,000 and $223,000 in the three
 months ended September 30, 2013 and 2012,
 respectively).
  (was, 2013-05-13, similarity 0.6098):
[0001157523-13-002629:note_history:30]
The
Company records the amount billed to customers in net sales
($118,000 and $159,000 for the three months ended March 31, 2013
and 2012, respectively, and $367,000 and $434,000 for the nine
months ended March 31, 2013 and 2012, respectively) and classifies
the costs associated with these revenues in cost of sales ($266,000
and $267,000 for the three months ended March 31, 2013 and 2012,
respectively, and $748,000 and $824,000 for the nine months ended
March 31, 2013 and 2012, respectively).

- added (2013-11-12):
[0001157523-13-005478:note_history:31]
In
 July 2013, the FASB issued authoritative guidance that
 requires an entity to present an unrecognized tax benefit, or a
 portion of an unrecognized tax benefit, in the financial statements
 as a reduction to a deferred tax asset for a net operating loss
 (“NOL”) carryforward, a similar tax loss, or a tax
 credit carryforward.  If either (i) an NOL carryforward,
 a similar tax loss, or tax credit carryforward is not available as
 of the reporting date under the governing tax law to settle taxes
 that would result from the disallowance of the tax position or
 (ii) the entity does not intend to use the deferred tax asset
 for this purpose (provided that the tax law permits a choice), an
 entity should present an unrecognized tax benefit in the financial
 statements as a liability and should not net the unrecognized tax
 benefit with a deferred tax asset.  This guidance becomes
 effective prospectively for unrecognized tax benefits that exist as
 of the Company’s fiscal 2015 first quarter, with
 retrospective application and early adoption permitted.  The
 Company is currently evaluating the timing of adoption and the
 impact of this balance sheet presentation guidance but does not
 expect it to have a significant impact on the Company’s
 consolidated financial statements.

- changed (2013-11-12):
[0001157523-13-005478:note_history:32]
In
 July 2012, the FASB amended its authoritative guidance related to
 testing indefinite-lived intangible assets for impairment.
  Under the revised guidance, entities testing their
 indefinite-lived intangible assets for impairment have the option
 of performing a qualitative assessment before performing further
 impairment testing.  If entities determine, on the basis of
 qualitative factors, that it is more-likely-than-not that the asset
 is impaired, a quantitative test is required.  The guidance
 became effective in the beginning of the Company’s fiscal
 2014.  The adoption of this guidance did not have an impact on
 the Company’s consolidated financial statements.
  (was, 2013-05-13, similarity 0.8775):
[0001157523-13-002629:note_history:32]
In
July 2012, the FASB amended its authoritative guidance related to
testing indefinite-lived intangible assets for impairment.
 Under the revised guidance, entities testing their
indefinite-lived intangible assets for impairment have the option
of performing a qualitative assessment before performing further
impairment testing.  If entities determine, on the basis of
qualitative factors, that it is more-likely-than-not that the asset
is impaired, a quantitative test is required.  The guidance
becomes effective in the beginning of the Company’s fiscal
2014, with early adoption permitted.  The Company is currently
evaluating the timing of adopting this guidance which is not
expected to have an impact on the Company’s consolidated
financial statements.

- removed (2013-11-12):
[0001157523-13-002629:note_history:33]
The
accompanying Condensed Consolidated Financial Statements are
unaudited. In management’s opinion, all adjustments
(consisting of only normal recurring accruals) necessary for a fair
presentation have been made.   The results of
operations for the period ended March 31, 2013 are not necessarily
indicative of results that may be expected for any other interim
period or for the full year.

- removed (2013-11-12):
[0001157523-13-002629:note_history:34]
The
unaudited Condensed Consolidated Financial Statements should be
read in conjunction with the Consolidated Financial Statements and
related notes contained in the Company’s Annual Report on
Form 10-K for the year ended June 30, 2012. The accounting policies
used in preparing these unaudited Condensed Consolidated Financial
Statements are consistent with those described in the June 30, 2012
Consolidated Financial Statements. In addition, the Condensed
Consolidated Balance Sheet as of June 30, 2012 was derived from the
audited financial statements but does not include all disclosures
required by Generally Accepted Accounting Principles
(“GAAP”).

- removed (2013-11-12):
[0001157523-13-002629:note_history:35]
Principles
of Consolidation

- removed (2013-11-12):
[0001157523-13-002629:note_history:36]
The
consolidated financial statements include the accounts of Napco
Security Technologies, Inc. and all of its wholly-owned
subsidiaries. All inter-company balances and transactions have been
eliminated in consolidation.

- removed (2013-11-12):
[0001157523-13-002629:note_history:37]
Cash
and cash equivalents include approximately $460,000 of short-term
time deposits at March 31, 2013 and June 30, 2012.  The
Company considers all highly liquid investments with original
maturities of three months or less to be cash
equivalents.  The Company has cash balances in banks in
excess of the maximum amount insured by the FDIC and other
international agencies as of March 31, 2013 and June 30,
2012.

- removed (2013-11-12):
[0001157523-13-002629:note_history:38]
In
addition, the Company records an inventory obsolescence reserve,
which represents the difference between the cost of the inventory
and its estimated market value, based on various product sales
projections. This reserve is calculated using an estimated
obsolescence percentage applied to the inventory based on age,
historical trends, requirements to support forecasted sales, and
the ability to find alternate applications of its raw materials and
to convert finished product into alternate versions of the same
product to better match customer demand.  There is
inherent professional judgment and subjectivity made by both
production and engineering members of management in determining the
estimated obsolescence percentage. In addition, and as necessary,
the Company may establish specific reserves for future known or
anticipated events. The Company also regularly reviews the period
over which its inventories will be converted to sales. Any
inventories expected to convert to sales beyond 12 months from
the balance sheet date are classified as non-current.

- removed (2013-11-12):
[0001157523-13-002629:note_history:39]
Advertising
and promotional costs are included in "Selling, General and
Administrative" expenses in the consolidated statements of
operations and are expensed as incurred.  Advertising
expense for the three months ended March 31, 2013 and 2012 was
$124,000 and $388,000, respectively. Advertising expense for the
nine months ended March 31, 2013 and 2012 was $847,000 and
$871,000, respectively. The decrease for the three months resulted
primarily from the timing of a major tradeshow. Last year this
tradeshow occurred during the quarter ended March 31, 2012 while
this year the same tradeshow occurred subsequent to March 31, 2013.
For the nine months, this decrease was partially offset by
increased expenditures on another major tradeshow and media
advertising as compared to the same period a year ago.

- removed (2013-11-12):
[0001157523-13-002629:note_history:40]
Research
and development costs incurred by the Company are charged to
expense in the year incurred and are included in "Cost of Sales" in
the consolidated statements of
operations.  Company-sponsored research and development
expense for the three months ended March 31, 2013 and 2012 was
$1,187,000 and $1,094,000, respectively. Company-sponsored research
and development expense for the nine months ended March 31, 2013
and 2012 was $3,842,000 and $3,134,000, respectively. The increases
for the three and nine months was due primarily to expenses
relating to development of the Company’s iBridge™
tablet computer/touch screen keypad.

- removed (2013-11-12):
[0001157523-13-002629:note_history:41]
|  |  | Three Months Ended March 31, |  |
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Basic EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,296 |  |  |  | 19,096 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 123 |  |  |  | 313 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 111 |  |  | $ | 303 |  |  |  | 19,419 |  |  |  | 19,409 |  |  | $ | 0.01 |  |  | $ | 0.02 |  |

- removed (2013-11-12):
[0001157523-13-002629:note_history:42]
Options
to purchase 395,750 shares of common stock for the three months
ended March 31, 2013 and 2012 were not included in the computation
of Diluted EPS because their inclusion would be
anti-dilutive.  These options were still outstanding at
the end of the respective periods.

- removed (2013-11-12):
[0001157523-13-002629:note_history:43]
There
were no stock-based compensation costs for the three months ended
March 31, 2013 and 2012. Stock-based compensation costs of $0 and
$8,000 were recognized for the nine months ended March 31, 2013 and
2012, respectively.

- removed (2013-11-12):
[0001157523-13-002629:note_history:44]
For
the three and nine months ended March 31, 2013 and 2012, the
Company's operations did not give rise to material items includable
in comprehensive income, which were not already included in net
income.  Accordingly, the Company's comprehensive income
approximates its net income for all periods presented.

- removed (2013-11-12):
[0001157523-13-002629:note_history:45]
In
September 2011, the FASB amended its authoritative guidance related
to testing goodwill for impairment.  Under the revised
guidance, entities testing goodwill for impairment have the option
of performing a qualitative assessment before performing Step 1 of
the goodwill impairment test.  If entities determine, on the
basis of qualitative factors, that the fair value of the reporting
unit is more-likely-than-not less than the carrying amount, the
two-step impairment test would be required.  This guidance
becomes effective in the beginning of the Company’s fiscal
2013, with early adoption permitted.  The Company is not
adopting this guidance early, and it does not expect the guidance
to have an impact on the Company’s consolidated financial
statements.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001157523-13-005478:note_history:46]
As
 of September 30, 2013, long-term debt consisted of a revolving
 credit facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000.
  (was, 2013-05-13, similarity 0.9865):
[0001157523-13-002629:note_history:46]
As
of March 31, 2013, long-term debt consisted of a revolving credit
facility of $11,000,000 (the “Revolving Credit
Facility”) which expires in June 2017 and two term loans, one
for $6,000,000 which expires in June 2019, and one for $6,500,000
which expires in June 2017 (the “Term Loans”).
Repayment of the Terms Loans commenced on September 30, 2012. The
$6,000,000 Term Loan is being repaid with 28 equal, quarterly
payments of $75,000 and the remaining balance of $3,900,000 due on
or before the expiration date. The $6,500,000 Term Loan is being
repaid in 20 equal, quarterly payments of $325,000.

- changed (2013-11-12):
[0001157523-13-005478:note_history:47]
Outstanding
 balances and interest rates as of September 30, 2013 and June 30,
 2013 are as follows:
  (was, 2013-05-13, similarity 0.8308):
[0001157523-13-002629:note_history:47]
Outstanding
balances and interest rates as of March 31, 2013 and June 30, 2012
are as follows (dollars in thousands):

- changed (2013-11-12):
[0001157523-13-005478:note_history:48]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,500 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,500 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
  (was, 2013-05-13, similarity 0.981):
[0001157523-13-002629:note_history:48]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,300 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 16,800 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |

- changed (2013-11-12):
[0001157523-13-005478:note_history:49]
The
 Revolving Credit Facility and Term Loans (collectively the
 “Agreement”) also provide for a LIBOR-based interest
 rate option of LIBOR plus 2.0% to 2.75%, depending on the ratio of
 outstanding debt to EBITDA, which is to be measured and adjusted
 quarterly, a prime rate-based option of the prime rate plus 0.25%
 and other terms and conditions as more fully described in the
 Agreement. In addition, the Agreement provides for availability
 under the Revolving Credit Facility to be limited to the lesser of
 $11,000,000 or the result of a borrowing base formula based upon
 the Company’s Accounts Receivables and Inventory values net
 of certain deductions. The Company’s obligations under the
 Agreement continue to be secured by all of its assets, including
 but not limited to, deposit accounts, accounts receivable,
 inventory, the Company’s corporate headquarters in
 Amityville, NY, equipment and fixtures and intangible assets. In
 addition, the Company’s wholly-owned subsidiaries, with the
 exception of the Company’s foreign subsidiaries, have issued
 guarantees and pledges of all of their assets to secure the
 Company’s obligations under the Agreement. All of the
 outstanding common stock of the Company’s domestic
 subsidiaries and 65% of the common stock of the Company’s
 foreign subsidiaries has been pledged to secure the Company’s
 obligations under the Agreement.
  (was, 2013-05-13, similarity 0.8608):
[0001157523-13-002629:note_history:49]
On
June 29, 2012, the Company entered into a Third Amended and
Restated Credit Agreement with the Company, as the Borrower, and
HSBC Bank USA, National Association as Lender, Administrative Agent
and Collateral Agent (the “Agreement”).  The
Agreement amended and restated the previous revolving credit
facility and term loan as described above. The Agreement also
provides for a LIBOR-based interest rate option of LIBOR plus 2.0%
to 2.75%, depending on the ratio of outstanding debt to EBITDA,
which is to be measured and adjusted quarterly, a prime rate-based
option of the prime rate plus 0.25% and other terms and conditions
as more fully described in the Agreement. In addition, the
Agreement provides for availability under the Revolving Credit
Facility to be limited to the lesser of $11,000,000 or the result
of a borrowing base formula based upon the Company’s Accounts
Receivables and Inventory values net of certain deductions. The
Company’s obligations under the Agreement continue to be
secured by all of its assets, including but not limited to, deposit
accounts, accounts receivable, inventory, the Company’s
corporate headquarters in Amityville, N.Y., equipment and fixtures
and intangible assets. In addition, the Company’s
wholly-owned subsidiaries, with the exception of the
Company’s foreign subsidiaries, have issued guarantees and
pledges of all of their assets to secure the Company’s
obligations under the Agreement. All of the outstanding common
stock of the Company’s domestic subsidiaries and 65% of the
common stock of the Company’s foreign subsidiaries has been
pledged to secure the Company’s obligations under the
Agreement.

- changed (2013-11-12):
[0001157523-13-005478:note_history:50]
The
 Agreement contains various restrictions and covenants including,
 among others, restrictions on payment of dividends, restrictions on
 borrowings and compliance with certain financial ratios, as defined
 in the Agreement.
  (was, 2013-05-13, similarity 0.9404):
[0001157523-13-002629:note_history:50]
The
agreements contain various restrictions and covenants including,
among others, restrictions on payment of dividends, restrictions on
borrowings and compliance with certain financial ratios, as defined
in the restated agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001157523-13-005478:note_history:51]
Outstanding
 balances and interest rates as of September 30, 2013 and June 30,
 2013 are as follows:
  (was, 2013-05-13, similarity 0.8308):
[0001157523-13-002629:note_history:51]
Outstanding
balances and interest rates as of March 31, 2013 and June 30, 2012
are as follows (dollars in thousands):

- changed (2013-11-12):
[0001157523-13-005478:note_history:52]
|  |  | September 30, 2013 |  |  | June 30, 2013 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 3,000 |  |  |  | 2.2 | % |  | $ | 5,500 |  |  |  | 2.5 | % |
| Term loans |  |  | 10,500 |  |  |  | 2.2 | % |  |  | 10,900 |  |  |  | 2.5 | % |
| Total debt |  | $ | 13,500 |  |  |  | 2.2 | % |  | $ | 16,400 |  |  |  | 2.5 | % |
  (was, 2013-05-13, similarity 0.981):
[0001157523-13-002629:note_history:52]
|  |  | March 31, 2013 |  |  | June 30, 2012 |  |
|  |  | Outstanding |  |  | Interest Rate |  |  | Outstanding |  |  | Interest Rate |  |
| Revolving line of credit |  | $ | 5,500 |  |  |  | 2.5 | % |  | $ | 7,757 |  |  |  | 3.1 | % |
| Term loans |  |  | 11,300 |  |  |  | 2.5 | % |  |  | 12,500 |  |  |  | 3.1 | % |
| Total debt |  | $ | 16,800 |  |  |  | 2.5 | % |  | $ | 20,257 |  |  |  | 3.1 | % |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2013-11-12):
[0001157523-13-005478:note_history:53]
The
 Company recognizes revenue when the following criteria are met: (i)
 persuasive evidence of an agreement exists, (ii) there is a fixed
 and determinable price for the Company's product, (iii) shipment
 and passage of title occurs, and (iv) collectability is reasonably
 assured. Revenues from product sales are recorded at the time the
 product is shipped or delivered to the customer pursuant to the
 terms of the sale. The Company reports its sales on a net sales
 basis, with net sales being computed by deducting from gross sales
 the amount of actual sales returns and other allowances and the
 amount of reserves established for anticipated sales returns and
 other allowances.
  (was, 2013-05-13, similarity 0.9817):
[0001157523-13-002629:note_history:53]
The
Company recognizes revenue when the following criteria are met: (i)
persuasive evidence of an agreement exists, (ii) there is a fixed
and determinable price for the Company's product, (iii) shipment
and passage of title occurs, and (iv) collectability is reasonably
assured.  Revenues from merchandise sales are recorded at
the time the product is shipped or delivered to the customer
pursuant to the terms of the sale.  The Company reports
its sales levels on a net sales basis, with net sales being
computed by deducting from gross sales the amount of actual sales
returns and other allowances and the amount of reserves established
for anticipated sales returns and other allowances.
