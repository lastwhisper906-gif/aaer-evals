# NSSC 8-K — 0001144204-16-132460 filed 2016-11-08

## item codes, every 8-K on or before 2017-02-06

- 2016-12-13 0001144204-16-139204 — 5.07
- 2016-11-08 0001144204-16-132460 — 2.02, 9.01
- 2016-09-09 0001144204-16-123444 — 2.02, 9.01
- 2016-07-01 0001144204-16-111270 — 1.01
- 2016-05-10 0001144204-16-100142 — 2.02, 9.01
- 2015-12-14 0001144204-15-070760 — 5.07
- 2015-11-09 0001144204-15-063858 — 2.02, 9.01
- 2015-09-11 0001144204-15-054531 — 2.02, 9.01
- 2015-05-12 0001144204-15-029770 — 2.02, 9.01
- 2015-02-10 0001144204-15-007465 — 2.02, 9.01
- 2014-12-11 0001144204-14-073344 — 5.07
- 2014-11-12 0001144204-14-067288 — 2.02, 9.01
- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2017-02-06

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-16-132460:8k_2_02:1]
EX-99.1
2
v452424_ex99-1.htm
EXHIBIT 99.1

[0001144204-16-132460:8k_2_02:2]
Exhibit 99.1

[0001144204-16-132460:8k_2_02:3]
NAPCO
Announces Results for the First Quarter Ended September 30, 2016

[0001144204-16-132460:8k_2_02:4]
-Revenue Increased 11% to a First Quarter
Record of $20.2 Million -

[0001144204-16-132460:8k_2_02:5]
-Net Income Increased by 80%-

[0001144204-16-132460:8k_2_02:6]
-Alarm Division Recurring Revenues Grew
65%-

[0001144204-16-132460:8k_2_02:7]
-Sixth Consecutive Quarter of Record-Breaking
Revenue-

[0001144204-16-132460:8k_2_02:8]
-Management to Host Conference Call Today at 11 a.m. ET-

[0001144204-16-132460:8k_2_02:9]
AMITYVILLE, N.Y., November 7,
2016 -- NAPCO Security Technologies, Inc. (NasdaqGS: NSSC), one of the world's leading solutions providers and manufacturers
of high tech electronic intrusion security, Internet of Things (IoT) connected home, video and fire systems, as well as enterprise-class
access control and door locking products, today announced financial results for its first fiscal quarter ended September 30,2016.

[0001144204-16-132460:8k_2_02:10]
Financial Highlights:

[0001144204-16-132460:8k_2_02:11]
|  | ● | Net sales were $20.2 million, up 11% from the same quarter last year. |

[0001144204-16-132460:8k_2_02:12]
|  | ● | Sales of Alarm products increased 19% in the first quarter as compared to the same quarter a year ago. |

[0001144204-16-132460:8k_2_02:13]
|  | ● | Recurring monthly revenue (“RMR”) for the first quarter increased 65% compared to the same quarter a year ago and grew 14% sequentially. |

[0001144204-16-132460:8k_2_02:14]
|  | ● | Sales of Door-locking products rose 7%, inclusive of school security products, for the first quarter as compared to the same quarter a year ago. |

[0001144204-16-132460:8k_2_02:15]
|  | ● | Net Income for the quarter increased 80% to $568,000 as compared to $315,000 for the same quarter a year ago. |

[0001144204-16-132460:8k_2_02:16]
|  | ● | Earnings per share (diluted) for the first quarter was $0.03 as compared to $0.02 for the same quarter last year. |

[0001144204-16-132460:8k_2_02:17]
Richard Soloway, Chairman and
President, commented, “To start out fiscal 2017, we achieved yet another consecutive, record quarterly sales level. As a
result, this first quarter’s 11% sales increase, to $20.2 million, will mark our sixth consecutive record-breaking sales
quarter. This growth is partially attributable to a 65% increase in subscription-based Recurring Monthly Revenue (RMR) from our
base StarLink™ 3G/4G, Verizon CDMA and commercial fire and intrusion alarm communicators. We are particularly pleased to
see that our investment in the engineering and marketing of fertile new product opportunities is driving our double digit top-line
growth.

[0001144204-16-132460:8k_2_02:18]
“To continue this sales
growth momentum, we will be unveiling our wireless Internet of Things (IoT) communicator, StarLink Connect™, at the International
Security Conference & Exhibition East trade show, on November 16th, at the Jacob Javits Convention Center in NYC. An innovative
IoT product entry, StarLink Connect will enable security professionals to easily upgrade tens of millions of currently installed
traditional security systems, to include state-of-the-art IoT services, such as smart device remote control of alarm systems, lighting,
thermostats, video cameras and locking, all via our wireless cellular communicator. This will supply both our Company and dealers
with incremental, subscriber-based, RMR income streams.

[0001144204-16-132460:8k_2_02:19]
“Sales of our school
security and locking products showed vibrant growth, as our Company continued to play an important role in providing advanced security
solutions to the education vertical market, which is comprised of over 100,000 K-12 and 10,000 college/university educational institutions,
across the U.S. Q1 saw the appointment of Mr. Byron Thurmond, as our VP School & Campus Security, who will lead our Project
LocDown™ school security initiative. Mr. Thurmond comes to NAPCO with over 30 years of specialized experience in school security
and is one of the foremost experts, in the U.S., in this field. As a member of The Council of Great City Schools, comprising 28
of the largest public schools in the country, Mr. Thurmond played an influential role in innovating new methods of protecting our
nation’s schools.”

[0001144204-16-132460:8k_2_02:20]
Mr. Soloway concluded, “Our
product development and marketing investment, enabling us to enter growing and lucrative markets, will continue to fuel our future
growth. Targeting categories such as alarm communications and IoT, generates substantial levels of RMR, in addition to the initial
hardware sale and grows the Company’s profitability. Our presence in the rapidly growing school security arena is particularly
rewarding for us, as we are able to apply our expertise in helping to address the challenge in this area. Overall, I am glad to
say, this year promises to be one of continued growth and progress for NAPCO.”

[0001144204-16-132460:8k_2_02:21]
Financial Results

[0001144204-16-132460:8k_2_02:22]
Net Sales for the three months
ended September 30, 2016 increased 11% to a record first quarter revenue of $20.2 million, as compared to $18.1 million for the
same period one year ago. Selling, general and administrative expenses for the quarter were $5.7 million, or 28.4% of sales, as
compared to $5.3 million, or 29.3% of sales, for the same period last year.

[0001144204-16-132460:8k_2_02:23]
Operating income for the three
months ended September 30, 2016 increased 121% to $716,000, as compared to $324,000 for the first quarter of fiscal 2016. Adjusted
EBITDA* for the three months ended September 30, 2016 increased 53% to $1.1 million, or $0.06 per diluted share, as compared to
$0.7 million, or $0.04 per diluted share, for the first quarter of fiscal 2016. (*see table attached).

[0001144204-16-132460:8k_2_02:24]
Net income for the three months
ended September 30, 2016 increased 80%, to $568,000, or $0.03 per share, as compared to $315,000, or $0.02 per share, for the same
quarter last year.

[0001144204-16-132460:8k_2_02:25]
Balance Sheet Summary

[0001144204-16-132460:8k_2_02:26]
At September 30, 2016, the Company
had $4.7 million in cash and cash equivalents, an increase of $0.9 million compared to $3.8 million at June 30, 2016. NAPCO had
working capital of $36.7 million as compared with working capital of $36.9 million at June 30, 2016. Current ratio was 5.2:1 at
September 30, 2016 and 5.1:1 at June 30, 2016.

[0001144204-16-132460:8k_2_02:27]
Conference Call Information

[0001144204-16-132460:8k_2_02:28]
Management will conduct a conference
call at 11 a.m. ET today, November 7, 2016. Interested parties may participate in the call by dialing 1-877-407-4018 or for international
callers, 1-201-689-8471, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on
replay starting at 2 p.m. ET on November 7,2016 and ending on November 14,2016 at 11:59 p.m. ET. For the replay, please dial 1-844-512-2921
domestically, or 1-412-317-6671 for international callers, and use the replay access code 13649178. In addition, the call will
be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=119088.

[0001144204-16-132460:8k_2_02:29]
About NAPCO Security Technologies,
Inc.

[0001144204-16-132460:8k_2_02:30]
NAPCO Security Technologies,
Inc. is one of the world's leading solutions providers and manufacturers of high-technology electronic security, including recurring
revenue, connected home, video, fire alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO,
its security and connected home segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA.
Headquartered in Amityville, New York, its products are installed by tens of thousands of security professionals worldwide in commercial,
industrial, institutional, residential and government applications. NAPCO products have earned a reputation for innovation,
technical excellence and reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic
security market. For additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-16-132460:8k_2_02:31]
Safe Harbor Statement

[0001144204-16-132460:8k_2_02:32]
This press release contains
forward-looking statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ
materially from those anticipated in such forward-looking statements as a result of certain factors, including those set forth
in the Company's filings with the Securities and Exchange Commission.

[0001144204-16-132460:8k_2_02:33]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
|  |  | (unaudited) |  |  | (audited) |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,715 |  |  | $ | 3,805 |  |
| Accounts receivable, net of reserves and allowances |  |  | 17,311 |  |  |  | 19,012 |  |
| Inventories |  |  | 21,792 |  |  |  | 21,428 |  |
| Prepaid expenses and other current assets |  |  | 920 |  |  |  | 936 |  |
| Deferred income taxes |  |  | 698 |  |  |  | 703 |  |
| Total Current Assets |  |  | 45,436 |  |  |  | 45,884 |  |
| Inventories - non-current |  |  | 4,012 |  |  |  | 3,909 |  |
| Deferred income taxes |  |  | 401 |  |  |  | 436 |  |
| Property, plant and equipment, net |  |  | 5,974 |  |  |  | 6,049 |  |
| Intangible assets, net |  |  | 8,247 |  |  |  | 8,357 |  |
| Other assets |  |  | 176 |  |  |  | 134 |  |
| TOTAL ASSETS |  | $ | 64,246 |  |  | $ | 64,769 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 300 |  |  | $ | 300 |  |
| Accounts payable |  |  | 4,220 |  |  |  | 4,328 |  |
| Accrued expenses |  |  | 1,783 |  |  |  | 1,893 |  |
| Accrued salaries and wages |  |  | 2,405 |  |  |  | 2,467 |  |
| Accrued income taxes |  |  | 39 |  |  |  | 8 |  |
| Total Current Liabilities |  |  | 8,747 |  |  |  | 8,996 |  |
| Long-term debt, net of current maturities |  |  | 3,625 |  |  |  | 4,500 |  |
| Total Liabilities |  |  | 12,372 |  |  |  | 13,496 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,116,743 and 21,116,743 shares issued; and 18,786,893 and 18,786,893 shares outstanding, respectively |  |  | 211 |  |  |  | 211 |  |
| Additional paid-in capital |  |  | 16,655 |  |  |  | 16,622 |  |
| Retained earnings |  |  | 46,740 |  |  |  | 46,172 |  |
|  |  |  | 63,606 |  |  |  | 63,005 |  |
| Less: Treasury Stock, at cost (2,329,850 and 2,329,850 shares, respectively) |  |  | (11,732 | ) |  |  | (11,732 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 51,874 |  |  |  | 51,273 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 64,246 |  |  | $ | 64,769 |  |

[0001144204-16-132460:8k_2_02:34]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME (unaudited) |
|  |  | Three months ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 20,168 |  |  | $ | 18,149 |  |
| Cost of sales |  |  | 13,716 |  |  |  | 12,512 |  |
| Gross Profit |  |  | 6,452 |  |  |  | 5,637 |  |
| Selling, general, and administrative expenses |  |  | 5,736 |  |  |  | 5,313 |  |
| Operating Income |  |  | 716 |  |  |  | 324 |  |
| Other expense: |  |  |  |  |  |  |  |  |
| Interest, net |  |  | 24 |  |  |  | 53 |  |
| Income before Income Taxes |  |  | 692 |  |  |  | 271 |  |
| Income tax expense (benefit) |  |  | 124 |  |  |  | (44 | ) |
| Net Income |  | $ | 568 |  |  | $ | 315 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.03 |  |  | $ | 0.02 |  |
| Diluted |  | $ | 0.03 |  |  | $ | 0.02 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 18,787,000 |  |  |  | 18,965,000 |  |
| Diluted |  |  | 18,838,000 |  |  |  | 18,986,000 |  |

[0001144204-16-132460:8k_2_02:35]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) |
|  |  | Three months ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (in thousands) |  |
| CASH FLOWS FROM OPERATING ACTIVITIES |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 568 |  |  | $ | 315 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 322 |  |  |  | 344 |  |
| Provision for doubtful accounts |  |  | (5 | ) |  |  | (75 | ) |
| Deferred income taxes |  |  | 40 |  |  |  | (11 | ) |
| Stock based compensation expense |  |  | 33 |  |  |  | 32 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,706 |  |  |  | 2,800 |  |
| Inventories |  |  | (467 | ) |  |  | (910 | ) |
| Prepaid expenses and other current assets |  |  | 16 |  |  |  | 89 |  |
| Income tax receivable |  |  | -- |  |  |  | (23 | ) |
| Other assets |  |  | (45 | ) |  |  | -- |  |
| Accounts payable, accrued expenses and accrued income taxes |  |  | (249 | ) |  |  | (474 | ) |
| Net Cash Provided by Operating Activities |  |  | 1,919 |  |  |  | 2,087 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES |  |  |  |  |  |  |  |  |
| Purchases of property, plant, and equipment |  |  | (134 | ) |  |  | (133 | ) |
| Net Cash Used in Investing Activities |  |  | (134 | ) |  |  | (133 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt |  |  | (875 | ) |  |  | (1,400 | ) |
| Cash paid for purchase of treasury stock |  |  | -- |  |  |  | (94 | ) |
| Net Cash Used in Financing Activities |  |  | (875 | ) |  |  | (1,494 | ) |
| Net Increase in Cash and Cash Equivalents |  |  | 910 |  |  |  | 460 |  |
| CASH AND CASH EQUIVALENTS - Beginning |  |  | 3,805 |  |  |  | 2,346 |  |
| CASH AND CASH EQUIVALENTS - Ending |  | $ | 4,715 |  |  |  | 2,806 |  |
| SUPPLEMENTAL CASH FLOW INFORMATION |  |  |  |  |  |  |  |  |
| Interest paid, net |  | $ | 29 |  |  | $ | 52 |  |
| Income taxes paid |  | $ | 53 |  |  | $ | -- |  |

[0001144204-16-132460:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. |
| NON-GAAP MEASURES OF PERFORMANCE* (Unaudited) |
| (in thousands) |
|  |  | Three months ended September 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net income (GAAP) |  | $ | 568 |  |  | $ | 315 |  |
| Add back provision (benefit) for income taxes |  |  | 124 |  |  |  | (44 | ) |
| Add back interest and other expense |  |  | 24 |  |  |  | 53 |  |
| Operating Income (GAAP) |  |  | 716 |  |  |  | 324 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 110 |  |  |  | 137 |  |
| Add back stock-based compensation expense |  |  | 33 |  |  |  | 32 |  |
| Adjusted non-GAAP operating income |  |  | 859 |  |  |  | 493 |  |
| Add back depreciation and other amortization |  |  | 212 |  |  |  | 207 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 1,071 |  |  | $ | 700 |  |
| Adjusted EBITDA* per Diluted Share |  | $ | 0.06 |  |  | $ | 0.04 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 18,838,000 |  |  |  | 18,986,000 |  |

[0001144204-16-132460:8k_2_02:37]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-16-132460:8k_2_02:38]
Contacts:

[0001144204-16-132460:8k_2_02:39]
Patrick McKillop

[0001144204-16-132460:8k_2_02:40]
Director of Investor Relations

[0001144204-16-132460:8k_2_02:41]
NAPCO Security Technologies, Inc.

[0001144204-16-132460:8k_2_02:42]
OP: 800-645-9445 x 374

[0001144204-16-132460:8k_2_02:43]
CP: 516-404-3597

[0001144204-16-132460:8k_2_02:44]
pmckillop@napcosecurity.com

[0001144204-16-132460:8k_2_02:45]
Three Part Advisors

[0001144204-16-132460:8k_2_02:46]
Jeff Elliott

[0001144204-16-132460:8k_2_02:47]
972-423-7070

[0001144204-16-132460:8k_2_02:48]
jelliott@threepa.com
