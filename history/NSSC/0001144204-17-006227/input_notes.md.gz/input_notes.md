# NSSC notes — 0001144204-17-006227


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-17-006227:notes:1]
[same as prior period, unchanged from 0001144204-16-132116:notes:86]

[0001144204-17-006227:notes:2]
An entity is more vulnerable to concentrations of credit risk if it is exposed to risk of loss greater than it would have had if it mitigated its risk through diversification of customers. Such risks of loss manifest themselves differently, depending on the nature of the concentration, and vary in significance. The Company had one customer with an accounts receivable balance that comprised  25% and  22% of the Company’s accounts receivable at December 31, 2016 and June 30, 2016, respectively. Sales to this customer comprised  13% of net sales in each of the three months ended December 31, 2016 and 2015. Sales to this customer comprised  14% and  11% of net sales in the six months ended December 31, 2016 and 2015, respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-17-006227:notes:3]
NOTE 1 - Nature of Business and Summary of Significant Accounting Policies

[0001144204-17-006227:notes:4]
[same as prior period, unchanged from 0001144204-16-132116:notes:108]

[0001144204-17-006227:notes:5]
Napco Security Technologies, Inc. and Subsidiaries (the "Company" or “Napco”) is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-17-006227:notes:6]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Deterioration of the current economic conditions may also affect this trend.

[0001144204-17-006227:notes:7]
[same as prior period, unchanged from 0001144204-16-132116:notes:111]

[0001144204-17-006227:notes:8]
[same as prior period, unchanged from 0001144204-16-132116:notes:112]

[0001144204-17-006227:notes:9]
[same as prior period, unchanged from 0001144204-16-132116:notes:113]

[0001144204-17-006227:notes:10]
[same as prior period, unchanged from 0001144204-16-132116:notes:114]

[0001144204-17-006227:notes:11]
[same as prior period, unchanged from 0001144204-16-132116:notes:115]

[0001144204-17-006227:notes:12]
[same as prior period, unchanged from 0001144204-16-132116:notes:116]

[0001144204-17-006227:notes:13]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2016 in the amount of $2,350,000 approximates fair value.

[0001144204-17-006227:notes:14]
Cash and Cash Equivalents

[0001144204-17-006227:notes:15]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2016 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2016 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

[0001144204-17-006227:notes:16]
Accounts Receivable

[0001144204-17-006227:notes:17]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of December 31, 2016 and June 30, 2016 and for returns and other allowances of $1,199,000 and $1,255,000 as of December 31, 2016 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.

[0001144204-17-006227:notes:18]
Inventories

[0001144204-17-006227:notes:19]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-17-006227:notes:20]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.

[0001144204-17-006227:notes:21]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.

[0001144204-17-006227:notes:22]
Property, Plant, and Equipment

[0001144204-17-006227:notes:23]
Property, plant, and equipment are carried at cost less accumulated depreciation. Expenditures for maintenance and repairs are charged to expense as incurred; costs of major renewals and improvements are capitalized. At the time property and equipment are retired or otherwise disposed of, the cost and accumulated depreciation are eliminated from the asset and accumulated depreciation accounts and the profit or loss on such disposition is reflected in income.

[0001144204-17-006227:notes:24]
Depreciation is recorded over the estimated service lives of the related assets using primarily the straight-line method. Amortization of leasehold improvements is calculated by using the straight-line method over the estimated useful life of the asset or lease term, whichever is shorter.

[0001144204-17-006227:notes:25]
[same as prior period, unchanged from 0001144204-16-132116:notes:118]

[0001144204-17-006227:notes:26]
[same as prior period, unchanged from 0001144204-16-132116:notes:119]

[0001144204-17-006227:notes:27]
[same as prior period, unchanged from 0001144204-16-132116:notes:120]

[0001144204-17-006227:notes:28]
Changes in intangible assets are as follows (in thousands):

[0001144204-17-006227:notes:29]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,563) |  | $ | 2,237 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,563) |  | $ | 8,137 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

[0001144204-17-006227:notes:30]
Amortization expense for intangible assets subject to amortization was approximately $110,000 and $131,000 for the three months ended December 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $220,000 and $268,000 for the six months ended December 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.6 years and  12.6 years at December 31, 2016 and 2015, respectively.

[0001144204-17-006227:notes:31]
Long-Lived Assets

[0001144204-17-006227:notes:32]
Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets in question may not be recoverable. Impairment would be recorded in circumstances where undiscounted cash flows expected to be generated by an asset are less than the carrying value of that asset.

[0001144204-17-006227:notes:33]
Revenue Recognition

[0001144204-17-006227:notes:34]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product or service, (iii) shipment and passage of title occurs or service has been provided, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. Revenues for services are recorded at the time the service is provided to the customer pursuant to the terms of sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.

[0001144204-17-006227:notes:35]
[same as prior period, unchanged from 0001144204-16-132116:notes:122]

[0001144204-17-006227:notes:36]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2016 and 2015, respectively.

[0001144204-17-006227:notes:37]
[same as prior period, unchanged from 0001144204-16-132116:notes:124]

[0001144204-17-006227:notes:38]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2016 and 2015 was $498,000 and $510,000, respectively. Advertising expense for the six months ended December 31, 2016 and 2015 was $1,172,000 and $1,068,000, respectively.

[0001144204-17-006227:notes:39]
[same as prior period, unchanged from 0001144204-16-132116:notes:126]

[0001144204-17-006227:notes:40]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2016 and 2015 was $1,609,000 and $1,519,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2016 and 2015 was $3,237,000 and $3,008,000, respectively.

[0001144204-17-006227:notes:41]
Income Taxes

[0001144204-17-006227:notes:42]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.

[0001144204-17-006227:notes:43]
Net Income Per Share

[0001144204-17-006227:notes:44]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.

[0001144204-17-006227:notes:45]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):

[0001144204-17-006227:notes:46]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 857 |  | $ | 976 |  |  | 18,798 |  |  | 18,931 |  | $ | 0.05 |  | $ | 0.05 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 53 |  |  | 26 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 857 |  | $ | 976 |  |  | 18,851 |  |  | 18,957 |  | $ | 0.05 |  | $ | 0.05 |  |

[0001144204-17-006227:notes:47]
Options to purchase  5,000 and  106,000 shares of common stock for the three months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-17-006227:notes:48]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

[0001144204-17-006227:notes:49]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 1,425 |  | $ | 1,291 |  |  | 18,792 |  |  | 18,948 |  | $ | 0.08 |  | $ | 0.07 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 52 |  |  | 23 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,425 |  | $ | 1,291 |  |  | 18,844 |  |  | 18,971 |  | $ | 0.08 |  | $ | 0.07 |  |

[0001144204-17-006227:notes:50]
Options to purchase  5,000 and  137,750 shares of common stock for the six months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

[0001144204-17-006227:notes:51]
[same as prior period, unchanged from 0001144204-16-132116:notes:128]

[0001144204-17-006227:notes:52]
[same as prior period, unchanged from 0001144204-16-132116:notes:129]

[0001144204-17-006227:notes:53]
[same as prior period, unchanged from 0001144204-16-132116:notes:130]

[0001144204-17-006227:notes:54]
Stock-based compensation costs of $65,000 and $60,000 were recognized for three months ended December 31, 2016 and 2015, respectively. Stock-based compensation costs of $98,000 and $92,000 were recognized for six months ended December 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2016 and 2015.

[0001144204-17-006227:notes:55]
Foreign Currency

[0001144204-17-006227:notes:56]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2016 and 2015.

[0001144204-17-006227:notes:57]
Comprehensive Income

[0001144204-17-006227:notes:58]
For the three and six months ended December 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

[0001144204-17-006227:notes:59]
Segment Reporting

[0001144204-17-006227:notes:60]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11, and no additional segment data has been presented.

[0001144204-17-006227:notes:61]
Shipping and Handling Revenues and Costs

[0001144204-17-006227:notes:62]
The Company records the amount billed to customers for shipping and handling in net sales ($105,000 and $125,000 in the three months ended December 31, 2016 and 2015, respectively and $245,000 and $256,000 in the six months ended December 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($217,000 and $225,000 in the three months ended December 31, 2016 and 2015, respectively and $433,000 and $441,000 in the six months ended December 31, 2016 and 2015, respectively).

[0001144204-17-006227:notes:63]
Recently Issued Accounting Standards

[0001144204-17-006227:notes:64]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued authoritative guidance that changes the way companies account for certain aspects of share-based payments to employees. The most significant impact relates to the accounting for income tax effects of share-based compensation awards.  This new guidance is part of the FASB’s simplification initiative and requires that all excess tax benefits and tax deficiencies be recorded as income tax expense or benefit in the income statement. In addition, companies are required to treat the tax effects of exercised or vested awards as discrete items in the period that they occur.  Other updates include changing the threshold on tax withholding requirements.  Under this guidance, an employer can withhold up to the maximum statutory withholding rates in a jurisdiction without tainting the award classification.  Additionally, this guidance allows companies to elect a forfeiture recognition method whereby they account for forfeitures as they occur (actual) or they estimate the number of awards expected to be forfeited (current GAAP).  Lastly, as it relates to public entities, this guidance also provides requirements for the cash flow classification of cash paid by an employer when directly withholding shares for tax-withholding purposes and excess tax benefits.  This guidance becomes effective for the Company’s fiscal 2018 first quarter, with early adoption permitted, and the guidance prescribes different transition methods for the various provisions (i.e., retrospective, modified retrospective, or prospective).  The Company is currently evaluating the impact of applying this guidance on its consolidated financial statements.

[0001144204-17-006227:notes:65]
In February 2016, the FASB issued authoritative guidance that requires lessees to account for most leases on their balance sheets with the liability being equal to the present value of the lease payments.  The right-of-use asset will be based on the lease liability adjusted for certain costs such as direct costs.  Lease expense will be recognized similar to current accounting guidance with operating leases resulting in a straight-line expense and financing leases resulting in a front-loaded expense similar to the current accounting for capital leases.  This guidance becomes effective for the Company’s fiscal 2020 first quarter, with early adoption permitted.  This guidance must be adopted using a modified retrospective transition approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements, and provides for certain practical expedients.  The Company is currently evaluating the timing, impact and method of applying this guidance on its consolidated financial statements.

[0001144204-17-006227:notes:66]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively.

[0001144204-17-006227:notes:67]
In July 2015, the FASB issued ASU 2015-11 “Inventory (Topic 330): Simplifying the Measurement of Inventory” (ASU 2015-11). The amendments in ASU 2015-11 simplify the subsequent measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. ASU 2015-11 is effective for the Company’s quarter ended September 30, 2017. Early application is permitted. We have not early adopted ASU 2015-11. The new guidance must be applied prospectively after the date of adoption. We are in the process of evaluating the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

[0001144204-17-006227:notes:68]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements. Prior periods were not retrospectively adjusted.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-006227:notes:69]
[same as prior period, unchanged from 0001144204-16-132116:notes:39]

[0001144204-17-006227:notes:70]
[same as prior period, unchanged from 0001144204-16-132116:notes:40]

[0001144204-17-006227:notes:71]
[same as prior period, unchanged from 0001144204-16-132116:notes:41]

[0001144204-17-006227:notes:72]
|  |  | Three months ended December 31, |  | Six months ended December 31, |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
|  |  | (in thousands) |  | (in thousands) |  |  |  |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 20,100 |  | $ | 19,729 |  | $ | 39,593 |  | $ | 37,286 |  |
| Foreign |  |  | 615 |  |  | 768 |  |  | 1,290 |  |  | 1,360 |  |
| Total Net Sales |  | $ | 20,715 |  | $ | 20,497 |  | $ | 40,883 |  | $ | 38,646 |  |

[0001144204-17-006227:notes:73]
| Identifiable assets: |  | December 31, 2016 |  | June 30, 2016 |  |
| United States |  | $ | 48,813 |  | $ | 51,272 |  |
| Dominican Republic (2) |  |  | 15,226 |  |  | 13,497 |  |
| Total Identifiable Assets |  | $ | 64,039 |  | $ | 64,769 |  |

[0001144204-17-006227:notes:74]
[same as prior period, unchanged from 0001144204-16-132116:notes:44]

[0001144204-17-006227:notes:75]
(2) Consists primarily of inventories (December 31, 2016 = $11,781, June 30, 2016 = $10,076) and fixed assets (December 31, 2016 = $3,219, June 30, 2016 = $3,311) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-006227:notes:76]
[same as prior period, unchanged from 0001144204-16-132116:notes:88]

[0001144204-17-006227:notes:77]
[same as prior period, unchanged from 0001144204-16-132116:notes:89]

[0001144204-17-006227:notes:78]
[same as prior period, unchanged from 0001144204-16-132116:notes:90]

[0001144204-17-006227:notes:79]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
| Component parts |  | $ | 15,333 |  | $ | 14,021 |  |
| Work-in-process |  |  | 4,110 |  |  | 3,758 |  |
| Finished product |  |  | 8,263 |  |  | 7,558 |  |
|  |  | $ | 27,706 |  | $ | 25,337 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 23,562 |  | $ | 21,428 |  |
| Non-current |  |  | 4,144 |  |  | 3,909 |  |
|  |  | $ | 27,706 |  | $ | 25,337 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-17-006227:notes:80]
NOTE 4 - Property, Plant and Equipment

[0001144204-17-006227:notes:81]
[same as prior period, unchanged from 0001144204-16-132116:notes:95]

[0001144204-17-006227:notes:82]
|  |  | December 31, 2016 |  | June 30, 2016 |  | Useful Life in Years |
| Land |  | $ | 904 |  | $ | 904 |  | — |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |
| Molds and dies |  |  | 7,058 |  |  | 7,036 |  | 3 to 5 |
| Furniture and fixtures |  |  | 2,532 |  |  | 2,531 |  | 5 to 10 |
| Machinery and equipment |  |  | 21,285 |  |  | 21,035 |  | 7 to 10 |
| Leasehold improvements |  |  | 587 |  |  | 294 |  | Shorter of the lease term or life of asset |
|  |  |  | 41,277 |  |  | 40,711 |  |  |
| Less: accumulated depreciation and amortization |  |  | 35,070 |  |  | 34,662 |  |  |
|  |  | $ | 6,207 |  | $ | 6,049 |  |  |

[0001144204-17-006227:notes:83]
Depreciation and amortization expense on property, plant, and equipment was $213,000 and $209,000 for the three months ended December 31, 2016 and 2015, respectively and $422,000 and $414,000 for the six months ended December 31, 2016 and 2015, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-17-006227:notes:84]
NOTE 10 - Commitments and Contingencies

[0001144204-17-006227:notes:85]
Leases

[0001144204-17-006227:notes:86]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2019.

[0001144204-17-006227:notes:87]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $8,000 for the three months ended December 31, 2016 and 2015, respectively and $12,000 and $15,000 for the six months ended December 31, 2016 and 2015, respectively.

[0001144204-17-006227:notes:88]
Land Lease

[0001144204-17-006227:notes:89]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately  four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-17-006227:notes:90]
Litigation

[0001144204-17-006227:notes:91]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-17-006227:notes:92]
Employment Agreements

[0001144204-17-006227:notes:93]
As of December 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2017 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-006227:notes:94]
[same as prior period, unchanged from 0001144204-16-132116:notes:104]

[0001144204-17-006227:notes:95]
[same as prior period, unchanged from 0001144204-16-132116:notes:105]

[0001144204-17-006227:notes:96]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of December 31, 2016 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2012 and thereafter.

[0001144204-17-006227:notes:97]
[same as prior period, unchanged from 0001144204-16-132116:notes:107]


## us-gaap:LongTermDebtTextBlock

[0001144204-17-006227:notes:98]
NOTE 6 - Long-Term Debt

[0001144204-17-006227:notes:99]
As of December 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 and one term loan which expires in June 2019 (the “Term Loan”). The term loan, which was originally for $6,000,000, is being repaid with 28 equal, quarterly payments of $75,000 which commenced on September 30, 2012, plus any additional payments made at the Company’s discretion with the remaining balance due on or before the expiration date.

[0001144204-17-006227:notes:100]
Outstanding balances and interest rates as of December 31, 2016 and June 30, 2016 are as follows:

[0001144204-17-006227:notes:101]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | 350 |  |  | 1.8 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 2,350 |  |  | 1.9 | % | $ | 4,800 |  |  | 1.6 | % |

[0001144204-17-006227:notes:102]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.15% to  2.00%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, and the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-17-006227:notes:103]
The Agreements contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-006227:notes:104]
[same as prior period, unchanged from 0001144204-16-132116:notes:56]

[0001144204-17-006227:notes:105]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $27,000 and $27,000 for the three months ended December 31, 2016 and 2015, respectively, and $55,000 and $55,000 for the six months ended December 31, 2016 and 2015, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-006227:notes:106]
NOTE 8 - Stockholders’ Equity Transactions

[0001144204-17-006227:notes:107]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the Loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. No shares were purchased under this plan during the six months ended December 31, 2016.


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001144204-17-006227:notes:108]
The following table reflects activity under the 2012 Plan for the six months ended December 31,:

[0001144204-17-006227:notes:109]
|  |  | 2016 |  | 2015 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 112,500 |  | $ | 5.54 |  |  | 112,500 |  | $ | 5.30 |  |
| Granted |  |  | 5,000 |  |  | 8.15 |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (400) |  |  | 6.31 |  |  | (15,000) |  |  | 4.29 |  |
| Exercised |  |  | (1,500) |  |  | 6.31 |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 115,600 |  | $ | 5.64 |  |  | 97,500 |  | $ | 5.46 |  |
| Exercisable, end of period |  |  | 74,500 |  | $ | 5.57 |  |  | 53,500 |  | $ | 5.54 |  |
| Weighted average fair value at grant date of options granted |  | $ | 26,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 9,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 331,000 |  |  |  |  | $ | 61,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 218,000 |  |  |  |  | $ | 30,000 |  |  |  |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001144204-17-006227:notes:110]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at December 31, 2016:

[0001144204-17-006227:notes:111]
|  |  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
|  | $4.88-$8.15 |  |  | 115,600 |  |  | 7.5 |  | $ | 5.64 |  |  | 74,500 |  | $ | 5.57 |  |
|  |  |  |  | 115,600 |  |  | 7.5 |  | $ | 5.64 |  |  | 74,500 |  | $ | 5.57 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001144204-17-006227:notes:112]
The following table reflects activity under the 2012 Non-Employee Plan for the six months ended December 31,:

[0001144204-17-006227:notes:113]
|  |  | 2016 |  | 2015 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 35,000 |  | $ | 4.73 |  |  | 35,000 |  | $ | 4.73 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | (5,200) |  |  | 4.76 |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 29,800 |  | $ | 4.73 |  |  | 35,000 |  | $ | 4.73 |  |
| Exercisable, end of period |  |  | 20,800 |  | $ | 4.76 |  |  | 19,000 |  | $ | 4.77 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 25,000 |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 112,000 |  |  |  |  | $ | 41,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 78,000 |  |  |  |  | $ | 21,000 |  |  |  |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001144204-17-006227:notes:114]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at December 31, 2016:

[0001144204-17-006227:notes:115]
|  |  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
|  | $4.37 - $4.88 |  |  | 29,800 |  |  | 7.0 |  | $ | 4.73 |  |  | 20,800 |  | $ | 4.76 |  |
|  |  |  |  | 29,800 |  |  | 7.0 |  | $ | 4.73 |  |  | 20,800 |  | $ | 4.76 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001144204-17-006227:notes:116]
The following table reflects activity under the 2002 Employee plan for the six months ended December 31,:

[0001144204-17-006227:notes:117]
|  |  | 2016 |  | 2015 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 102,500 |  | $ | 6.04 |  |  | 208,500 |  | $ | 6.86 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (10,500) |  |  | 6.02 |  |  | (1,000) |  |  | 6.02 |  |
| Exercised |  |  | (52,000) |  |  | 6.31 |  |  | (67,500) |  |  | 5.73 |  |
| Outstanding, end of period |  |  | 40,000 |  | $ | 5.69 |  |  | 140,000 |  | $ | 7.41 |  |
| Exercisable, end of period |  |  | 40,000 |  | $ | 5.69 |  |  | 140,000 |  | $ | 7.41 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  | $ | 114,000 |  |  |  |  | $ | 11,000 |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | 113,000 |  |  |  |  | $ | 9,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | 113,000 |  |  |  |  | $ | 9,000 |  |  |  |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001144204-17-006227:notes:118]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at December 31, 2016:

[0001144204-17-006227:notes:119]
|  |  |  | Options outstanding and exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  |
|  | $5.35 - $5.89 |  |  | 40,000 |  |  | 0.8 |  | $ | 5.69 |  |
|  |  |  |  | 40,000 |  |  | 0.8 |  | $ | 5.69 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-006227:notes:120]
[same as prior period, unchanged from 0001144204-16-132116:notes:60]

[0001144204-17-006227:notes:121]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended December 31, 2016 and 2015, the Company recorded non-cash compensation expense of $65,000 ($.00 per basic and diluted share) and $60,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation. For the six months ended December 31, 2016 and 2015, the Company recorded non-cash compensation expense of $98,000 ($.01 per basic and diluted share) and $92,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-17-006227:notes:122]
[same as prior period, unchanged from 0001144204-16-132116:notes:62]

[0001144204-17-006227:notes:123]
[same as prior period, unchanged from 0001144204-16-132116:notes:63]

[0001144204-17-006227:notes:124]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2016,  117,500 stock options were granted,  74,500 stock options were exercisable and  832,900 stock options were available for grant under this plan.

[0001144204-17-006227:notes:125]
1,500 and 0 stock options were exercised during the three and six months ended December 31, 2016 and 2015, respectively. $9,000 and $0 was received from option exercises during the three months ended December 31, 2016 and 2015, respectively and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-006227:notes:126]
As of December 31, 2016, there was $154,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan.  5,000 options were granted during the three and six months ended December 31, 2016. The total fair value of the options vesting during the three months ended December 31, 2016 and 2015 under this plan was $59,000 and $94,000, respectively. The total fair value of the options vesting during the six months ended December 31, 2016 and 2015 under this plan was $75,000 and $110,000, respectively.

[0001144204-17-006227:notes:127]
[same as prior period, unchanged from 0001144204-16-132116:notes:70]

[0001144204-17-006227:notes:128]
[same as prior period, unchanged from 0001144204-16-132116:notes:71]

[0001144204-17-006227:notes:129]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At December 31, 2016,  35,000 stock options were granted,  20,800 stock options were exercisable and  15,000 stock options were available for grant under this plan.

[0001144204-17-006227:notes:130]
5,200 and 0 options were exercised during the three and six months ended December 31, 2016 and 2015, respectively. All of the 5,200 exercises were settled by exchanging  3,056 shares of the Company’s common stock which were retired and returned to authorized. No cash was received from option exercises during the three and six months ended December 31, 2016 and 2015 and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-17-006227:notes:131]
As of December 31, 2016, there was $28,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. No options were granted during the six months ended December 31, 2016. The total fair value of the options vesting during each of the three months ended December 31, 2016 and 2015 under this plan was $6,000. The total fair value of the options vesting during each of the six months ended December 31, 2016 and 2015 under this plan was $22,000.

[0001144204-17-006227:notes:132]
[same as prior period, unchanged from 0001144204-16-132116:notes:78]

[0001144204-17-006227:notes:133]
[same as prior period, unchanged from 0001144204-16-132116:notes:79]

[0001144204-17-006227:notes:134]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At December 31, 2016,  1,471,480 stock options had been granted and  40,000 stock options were exercisable. No further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-17-006227:notes:135]
52,000 and  67,500 stock options were exercised during the three and six months ended December 31, 2016 and 2015, respectively.  45,500 of the 52,000 exercises were settled by exchanging  40,655 shares of the Company’s common stock which were retired and returned to authorized. The remaining  6,500 exercises were paid for in cash. $40,000 and $0 was received from option exercises during the three and six months ended December 31, 2016 and 2015, respectively and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.
