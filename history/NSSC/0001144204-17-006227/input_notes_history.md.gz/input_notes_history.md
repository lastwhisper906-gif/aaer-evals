# NSSC note change history — 0001144204-16-132116 → 0001144204-17-006227


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001144204-17-006227:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $8,000 for the three months ended December 31, 2016 and 2015, respectively and $12,000 and $15,000 for the six months ended December 31, 2016 and 2015, respectively.
  (was, 2016-11-07, similarity 0.8173):
[0001144204-16-132116:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $6,000 and $7,000 for the three months ended September 30, 2016 and 2015, respectively.

- changed (2017-02-06):
[0001144204-17-006227:note_history:2]
As of December 31, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2017 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement for fiscal 2017 and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.
  (was, 2016-11-07, similarity 0.9952):
[0001144204-16-132116:note_history:2]
As of September 30, 2016, the Company was obligated under three employment agreements and one severance agreement. The employment agreements are with the Company’s CEO, Senior Vice President of Sales and Marketing (“the SVP of Sales”) and the Senior Vice President of Engineering (“the SVP of Engineering”). The employment agreement with the CEO provides for an annual salary of $670,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP of Sales expires in October  2017 and provides for an annual salary of $315,000, a bonus arrangement for fiscal 2016 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The employment agreement with the SVP of Engineering expires in August  2018 and provides for an annual salary of $285,000, a bonus arrangement and, if terminated by the Company without cause, severance of nine month’s salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement is with the Senior Vice President of Operations and Finance and provides for, if terminated by the Company without cause or within three months of a change in corporate control of the Registrant, severance of nine month’s salary, continued company-sponsored health insurance for six months from the date of termination and certain non-compete and other restrictive provisions. Each of the severance agreements with the SVP of Sales, the SVP of Engineering and the Senior Vice President of Operations and Finance contains non-compete restrictions for three years after the employee’s termination of employment.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-02-06):
[0001144204-17-006227:note_history:3]
NOTE 1 - Nature of Business and Summary of Significant Accounting Policies

- changed (2017-02-06):
[0001144204-17-006227:note_history:4]
Napco Security Technologies, Inc. and Subsidiaries (the "Company" or “Napco”) is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.
  (was, 2016-11-07, similarity 0.9891):
[0001144204-16-132116:note_history:4]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door-locking products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

- changed (2017-02-06):
[0001144204-17-006227:note_history:5]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of Napco's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets. Deterioration of the current economic conditions may also affect this trend.
  (was, 2016-11-07, similarity 0.9052):
[0001144204-16-132116:note_history:5]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of the Company's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets.

- changed (2017-02-06):
[0001144204-17-006227:note_history:6]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of December 31, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at December 31, 2016 in the amount of $2,350,000 approximates fair value.
  (was, 2016-11-07, similarity 0.9871):
[0001144204-16-132116:note_history:6]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities - The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2016 due to their short-term maturities; Long-Term Debt - The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2016 in the amount of $3,925,000 approximates fair value.

- changed (2017-02-06):
[0001144204-17-006227:note_history:7]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at December 31, 2016 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of December 31, 2016 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits
  (was, 2016-11-07, similarity 0.9857):
[0001144204-16-132116:note_history:7]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2016 and June 30, 2016. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2016 and June 30, 2016. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2017-02-06):
[0001144204-17-006227:note_history:8]
Accounts receivable is stated net of the reserves for doubtful accounts of $145,000 as of December 31, 2016 and June 30, 2016 and for returns and other allowances of $1,199,000 and $1,255,000 as of December 31, 2016 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.
  (was, 2016-11-07, similarity 0.9588):
[0001144204-16-132116:note_history:8]
Accounts receivable is stated net of the reserves for doubtful accounts of $140,000 and $145,000 and for returns and other allowances of $1,186,000 and $1,255,000 as of September 30, 2016 and June 30, 2016, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of our accounts receivable aging, specific exposures, sales levels and historical trends.

- added (2017-02-06):
[0001144204-17-006227:note_history:9]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,563) |  | $ | 2,237 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,563) |  | $ | 8,137 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

- added (2017-02-06):
[0001144204-17-006227:note_history:10]
Amortization expense for intangible assets subject to amortization was approximately $110,000 and $131,000 for the three months ended December 31, 2016 and 2015, respectively. Amortization expense for intangible assets subject to amortization was approximately $220,000 and $268,000 for the six months ended December 31, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.6 years and  12.6 years at December 31, 2016 and 2015, respectively.

- changed (2017-02-06):
[0001144204-17-006227:note_history:11]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were 8% and 7% for the six months ended December 31, 2016 and 2015, respectively.
  (was, 2016-11-07, similarity 0.9654):
[0001144204-16-132116:note_history:11]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  9% and 7% for the three months ended September 30, 2016 and 2015, respectively.

- changed (2017-02-06):
[0001144204-17-006227:note_history:12]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended December 31, 2016 and 2015 was $498,000 and $510,000, respectively. Advertising expense for the six months ended December 31, 2016 and 2015 was $1,172,000 and $1,068,000, respectively.
  (was, 2016-11-07, similarity 0.8411):
[0001144204-16-132116:note_history:12]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2016 and 2015 was $674,000 and $558,000, respectively.

- changed (2017-02-06):
[0001144204-17-006227:note_history:13]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended December 31, 2016 and 2015 was $1,609,000 and $1,519,000, respectively. Company-sponsored research and development expense for the six months ended December 31, 2016 and 2015 was $3,237,000 and $3,008,000, respectively.
  (was, 2016-11-07, similarity 0.8184):
[0001144204-16-132116:note_history:13]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2016 and 2015 was $1,628,000 and $1,489,000, respectively.

- changed (2017-02-06):
[0001144204-17-006227:note_history:14]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.
  (was, 2016-11-07, similarity 0.9053):
[0001144204-16-132116:note_history:14]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. The components of the deferred tax assets and liabilities are individually classified as current and non-current based on their characteristics. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.

- changed (2017-02-06):
[0001144204-17-006227:note_history:15]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended December 31 (in thousands, except per share data):
  (was, 2016-11-07, similarity 0.9856):
[0001144204-16-132116:note_history:15]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

- changed (2017-02-06):
[0001144204-17-006227:note_history:16]
Options to purchase  5,000 and  106,000 shares of common stock for the three months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2016-11-07, similarity 0.9877):
[0001144204-16-132116:note_history:16]
Options to purchase 0 and  170,000 shares of common stock for the three months ended September 30, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2017-02-06):
[0001144204-17-006227:note_history:17]
The following provides a reconciliation of information used in calculating the per share amounts for the six months ended December 31 (in thousands, except per share data):

- added (2017-02-06):
[0001144204-17-006227:note_history:18]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |  |
| Basic EPS |  | $ | 1,425 |  | $ | 1,291 |  |  | 18,792 |  |  | 18,948 |  | $ | 0.08 |  | $ | 0.07 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | 52 |  |  | 23 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 1,425 |  | $ | 1,291 |  |  | 18,844 |  |  | 18,971 |  | $ | 0.08 |  | $ | 0.07 |  |

- added (2017-02-06):
[0001144204-17-006227:note_history:19]
Options to purchase  5,000 and  137,750 shares of common stock for the six months ended December 31, 2016 and 2015, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.

- added (2017-02-06):
[0001144204-17-006227:note_history:20]
Stock-based compensation costs of $65,000 and $60,000 were recognized for three months ended December 31, 2016 and 2015, respectively. Stock-based compensation costs of $98,000 and $92,000 were recognized for six months ended December 31, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three and six months ended December 31, 2016 and 2015.

- changed (2017-02-06):
[0001144204-17-006227:note_history:21]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three and six months ended December 31, 2016 and 2015.
  (was, 2016-11-07, similarity 0.952):
[0001144204-16-132116:note_history:21]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2016 and 2015.

- added (2017-02-06):
[0001144204-17-006227:note_history:22]
For the three and six months ended December 31, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2017-02-06):
[0001144204-17-006227:note_history:23]
The Company records the amount billed to customers for shipping and handling in net sales ($105,000 and $125,000 in the three months ended December 31, 2016 and 2015, respectively and $245,000 and $256,000 in the six months ended December 31, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($217,000 and $225,000 in the three months ended December 31, 2016 and 2015, respectively and $433,000 and $441,000 in the six months ended December 31, 2016 and 2015, respectively).
  (was, 2016-11-07, similarity 0.6821):
[0001144204-16-132116:note_history:23]
The Company records the amount billed to customers for shipping and handling in net sales ($139,000 and $131,000 in the three months ended September 30, 2016 and 2015, respectively) and classifies the costs associated with these revenues in cost of sales ($216,000 in each of the three months ended September 30, 2016 and 2015).

- changed (2017-02-06):
[0001144204-17-006227:note_history:24]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have early adopted ASU 2015-17 as of December 31, 2016. The new guidance will be applied prospectively.
  (was, 2016-11-07, similarity 0.819):
[0001144204-16-132116:note_history:24]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes”. The amendments require deferred tax assets and liabilities, along with related valuation allowances, to be classified as noncurrent on the balance sheet. As a result, each tax jurisdiction will now only have one net noncurrent deferred tax asset or liability. The new guidance does not change the existing requirement that prohibits offsetting deferred tax liabilities from one jurisdiction against deferred tax assets of another jurisdiction. ASU 2015-17 is effective for the Company’s fiscal year ended June 30, 2018. Early application is permitted. We have not early adopted ASU 2015-17. The new guidance must be applied prospectively after the date of adoption. We have evaluated the adoption of this ASU, and do not expect this to have a material effect on our consolidated results of operations and financial condition.

- changed (2017-02-06):
[0001144204-17-006227:note_history:25]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements. Prior periods were not retrospectively adjusted.
  (was, 2016-11-07, similarity 0.982):
[0001144204-16-132116:note_history:25]
In May 2014, the FASB issued authoritative guidance that defines how companies should report revenues from contracts with customers.  The standard requires an entity to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  It provides companies with a single comprehensive five-step principles-based model to use in accounting for revenue and supersedes current revenue recognition requirements, including most industry-specific and transaction-specific revenue guidance.  In August 2015, the FASB deferred the effective date of the new revenue standard by one year.  As a result, the new standard would not be effective for the Company until fiscal 2019.  In addition, the FASB is allowing companies to early adopt this guidance for the Company’s fiscal 2018.  The guidance permits an entity to apply the standard retrospectively to all prior periods presented, with certain practical expedients, or apply the requirements in the year of adoption, through a cumulative adjustment.  The Company will apply this new guidance when it becomes effective and has not yet selected a transition method.  The Company is currently evaluating the impact of adoption on its consolidated financial statements.

- removed (2017-02-06):
[0001144204-16-132116:note_history:26]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (7,453) |  | $ | 2,347 |  | $ | 9,800 |  | $ | (7,343) |  | $ | 2,457 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 15,700 |  | $ | (7,453) |  | $ | 8,247 |  | $ | 15,700 |  | $ | (7,343) |  | $ | 8,357 |  |

- removed (2017-02-06):
[0001144204-16-132116:note_history:27]
Amortization expense for intangible assets subject to amortization was approximately $110,000 and $137,000 for the three months ended September 30, 2016 and 2015, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2017 - $441,000; 2018 - $371,000; 2019 - $313,000 and 2020 - $264,000 and 2021 - $223,000. The weighted average amortization period for intangible assets was  11.9 years and  12.9 years at September 30, 2016 and 2015, respectively.

- removed (2017-02-06):
[0001144204-16-132116:note_history:28]
Stock-based compensation costs of $33,000 and $32,000 was recognized for the three months ended September 30, 2016 and 2015, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for each of the three months ended September 30, 2016 and 2015.

- removed (2017-02-06):
[0001144204-16-132116:note_history:29]
For the three months ended September 30, 2016 and 2015, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-06):
[0001144204-17-006227:note_history:30]
As of December 31, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 and one term loan which expires in June 2019 (the “Term Loan”). The term loan, which was originally for $6,000,000, is being repaid with 28 equal, quarterly payments of $75,000 which commenced on September 30, 2012, plus any additional payments made at the Company’s discretion with the remaining balance due on or before the expiration date.

- changed (2017-02-06):
[0001144204-17-006227:note_history:31]
Outstanding balances and interest rates as of December 31, 2016 and June 30, 2016 are as follows:
  (was, 2016-11-07, similarity 0.9714):
[0001144204-16-132116:note_history:31]
Outstanding balances and interest rates as of September 30, 2016 and June 30, 2016 are as follows:

- changed (2017-02-06):
[0001144204-17-006227:note_history:32]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | 350 |  |  | 1.8 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 2,350 |  |  | 1.9 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2016-11-07, similarity 0.9862):
[0001144204-16-132116:note_history:32]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loans |  |  | 1,925 |  |  | 1.7 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,925 |  |  | 1.7 | % | $ | 4,800 |  |  | 1.6 | % |

- changed (2017-02-06):
[0001144204-17-006227:note_history:33]
The Agreements contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.
  (was, 2016-11-07, similarity 0.9978):
[0001144204-16-132116:note_history:33]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.

- removed (2017-02-06):
[0001144204-16-132116:note_history:34]
As of September 30, 2016, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2021 and one loan for $6,000,000 which expires in June 2019 (the “Term Loan”). The Revolving Credit Facility had an expiration date of June 2017 which was extended to June 2021 at the end of fiscal 2016. Repayment of the Term Loan commenced on September 30, 2012. The Term Loan is being repaid with 28 equal, quarterly payments of $75,000 plus any additional payments made at the Company’s discretion with the remaining balance of $1,100,000 due on or before the expiration date.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001144204-17-006227:note_history:35]
Outstanding balances and interest rates as of December 31, 2016 and June 30, 2016 are as follows:
  (was, 2016-11-07, similarity 0.9714):
[0001144204-16-132116:note_history:35]
Outstanding balances and interest rates as of September 30, 2016 and June 30, 2016 are as follows:

- changed (2017-02-06):
[0001144204-17-006227:note_history:36]
|  |  | December 31, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.9 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loan |  |  | 350 |  |  | 1.8 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 2,350 |  |  | 1.9 | % | $ | 4,800 |  |  | 1.6 | % |
  (was, 2016-11-07, similarity 0.9862):
[0001144204-16-132116:note_history:36]
|  |  | September 30, 2016 |  | June 30, 2016 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,000 |  |  | 1.7 | % | $ | 2,000 |  |  | 1.6 | % |
| Term loans |  |  | 1,925 |  |  | 1.7 | % |  | 2,800 |  |  | 1.6 | % |
| Total debt |  | $ | 3,925 |  |  | 1.7 | % | $ | 4,800 |  |  | 1.6 | % |
