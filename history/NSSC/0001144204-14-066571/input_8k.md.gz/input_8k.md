# NSSC 8-K — 0001144204-14-056567 filed 2014-09-17

## item codes, every 8-K on or before 2014-11-10

- 2014-11-10 0001144204-14-066543 — 5.02, 9.01
- 2014-09-19 0001144204-14-056809 — 8.01, 9.01
- 2014-09-17 0001144204-14-056567 — 2.02, 9.01
- 2014-05-07 0001157523-14-001990 — 2.02, 9.01
- 2014-02-13 0001157523-14-000610 — 8.01
- 2014-02-10 0001157523-14-000521 — 2.02, 9.01
- 2013-12-11 0001157523-13-005755 — 5.07
- 2013-11-12 0001157523-13-005435 — 2.02, 9.01
- 2013-09-19 0001157523-13-004483 — 5.02
- 2013-09-18 0001157523-13-004450 — 2.02, 9.01
- 2013-06-04 0001157523-13-003008 — 4.01, 9.01
- 2013-05-14 0001157523-13-002669 — 2.02, 9.01
- 2013-02-11 0001157523-13-000666 — 5.02, 9.01
- 2013-02-01 0001157523-13-000434 — 5.07
- 2012-12-12 0001157523-12-006355 — 5.02
- 2012-11-13 0001157523-12-006019 — 2.02, 9.01
- 2012-09-26 0001157523-12-004953 — 2.02, 9.01
- 2012-07-09 0001157523-12-003565 — 1.01, 9.01
- 2012-02-15 0001157523-12-000774 — 2.02, 9.01
- 2011-12-06 0001157523-11-007079 — 5.07
- 2011-09-15 0001157523-11-005422 — 2.02, 9.01
- 2011-05-16 0001157523-11-003189 — 2.02, 9.01
- 2010-12-10 0001157523-10-007260 — 5.07
- 2010-11-17 0001157523-10-006987 — 2.02, 9.01
- 2010-11-03 0001157523-10-006515 — 1.01, 9.01
- 2010-09-30 0001157523-10-005675 — 2.02, 9.01
- 2009-11-25 0001157523-09-008326 — 2.02, 9.01
- 2009-02-11 0001157523-09-001142 — 2.02, 9.01
- 2008-12-19 0001157523-08-010025 — 4.01, 9.01
- 2008-11-12 0001157523-08-009250 — 9.01 — amendment of 0001157523-08-007060
- 2008-08-22 0001157523-08-007060 — 2.01, 2.03, 9.01
- 2008-05-08 0001157523-08-004002 — 2.02, 9.01
- 2008-02-11 0001157523-08-001206 — 2.02, 9.01
- 2007-12-06 0001157523-07-011957 — 5.03, 9.01
- 2007-11-13 0001157523-07-011139 — 2.02, 9.01
- 2007-09-19 0001157523-07-009279 — 2.02, 9.01
- 2007-05-10 0001157523-07-004995 — 2.02, 9.01
- 2007-02-06 0001157523-07-001122 — 2.02, 9.01
- 2006-11-06 0001157523-06-010887 — 2.02, 9.01
- 2006-09-15 0000950123-06-011655 — 2.02, 9.01
- 2006-05-11 0000950123-06-006179 — 8.01
- 2006-05-09 0000950123-06-005934 — 2.02, 9.01
- 2006-02-14 0000950123-06-001755 — 2.02, 9.01
- 2005-12-02 0000950123-05-014365 — 8.01
- 2005-11-17 0000950123-05-013827 — 2.02, 9.01
- 2005-09-22 0000950123-05-011399 — 2.02, 9.01
- 2005-05-11 0000950123-05-006139 — 2.02, 9.01
- 2005-02-09 0000950123-05-001373 — 2.02, 9.01
- 2004-09-28 0000950123-04-011452 — 2.02, 9.01
- 2004-09-15 0000950123-04-011016 — 2.02, 9.01
- 2004-08-10 0000950123-04-009506 — 5, 7
- 2004-06-02 0000950123-04-007011 — 5, 7
- 2004-05-28 0000950123-04-006950 — 5, 7
- 2004-05-06 0000950123-04-005875 — 5, 7
- 2004-03-30 0000950123-04-003956 — 5, 7
- 2004-02-23 0000950123-04-002204 — 5, 7
- 2004-02-17 0000950123-04-001895 — 5, 7
- 2004-02-09 0000950123-04-001403 — 5, 7
- 2004-01-09 0000950123-04-000206 — 5, 7
- 2003-12-29 0000950123-03-014218 — 5, 7
- 2003-12-22 0000950123-03-014035 — 4, 7
- 2003-10-16 0000950123-03-011419 — 5, 7
- 2003-10-14 0000950123-03-011361 — 5, 7
- 2002-07-10 0000950123-02-006856 — 4
- 2001-03-13 0000950123-01-002241 — 5, 7
- 2000-09-27 0000950123-00-008897 — 2, 7 — amendment of 0000950123-00-007499
- 2000-08-11 0000950123-00-007499 — 2, 7
- 1998-05-29 0000950123-98-005484 — 5, 7
- 1998-05-15 0000950123-98-005157 — 5, 7

## late-filing notifications on or before 2014-11-10

- 2010-09-29 0001157523-10-005663 — NT 10-K, for the period ended 2010-06-30
- 2009-09-29 0001157523-09-006660 — NT 10-K, for the period ended 2009-06-30
- 2009-05-18 0001157523-09-003991 — NT 10-Q, for the period ended 2009-03-31
- 2008-11-12 0001157523-08-009253 — NT 10-Q, for the period ended 2008-09-30
- 2008-09-16 0001157523-08-007430 — NT 10-K, for the period ended 2008-06-30
- 2008-02-11 0001157523-08-001202 — NT 10-Q, for the period ended 2007-12-31
- 2007-11-13 0001157523-07-011133 — NT 10-Q, for the period ended 2007-09-30
- 2007-09-14 0001157523-07-009191 — NT 10-K, for the period ended 2007-06-30
- 2006-09-14 0000950123-06-011604 — NT 10-K, for the period ended 2006-06-30
- 2005-11-15 0000950123-05-013677 — NT 10-Q, for the period ended 2005-09-30
- 2005-09-29 0000950123-05-011652 — NT 10-K, for the period ended 2005-06-30
- 2003-11-14 0000950123-03-012779 — NT 10-Q, for the period ended 2003-09-30
- 2003-09-29 0000950123-03-010912 — NT 10-K, for the period ended 2003-06-30
- 2002-09-30 0000950123-02-009297 — NT 10-K, for the period ended 2002-06-30
- 1997-09-26 0000950123-97-008129 — NT 10-K, for the period ended 1997-06-30
- 1997-02-18 0000950123-97-001467 — NT 10-Q, for the period ended 1996-12-31
- 1996-11-14 0000950123-96-006624 — NT 10-Q, for the period ended 1996-09-30
- 1996-09-30 0000950123-96-005286 — NT 10-K, for the period ended 1996-06-30
- 1996-02-15 0000950123-96-000651 — NT 10-Q, for the period ended 1995-12-31
- 1995-09-27 0000950123-95-002759 — NT 10-K, for the period ended 1995-06-30
- 1995-05-16 0000950123-95-001451 — NT 10-Q, for the period ended 1995-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001144204-14-056567:8k_2_02:1]
EX-99.1
2
v389353_ex99-1.htm
EXHIBIT 99.1

[0001144204-14-056567:8k_2_02:2]
Exhibit 99.1

[0001144204-14-056567:8k_2_02:3]
NAPCO
Announces Fiscal Year-End 2014 Results

[0001144204-14-056567:8k_2_02:4]
-Record Full-Year Revenue of $74.4 Million-

[0001144204-14-056567:8k_2_02:5]
-Net Income Increases 15% to $3.5 Million-

[0001144204-14-056567:8k_2_02:6]
-Management to Host Conference Call Today at 11 a.m.-

[0001144204-14-056567:8k_2_02:7]
AMITYVILLE, N.Y., Sept. 15, 2014 /PRNewswire/
-- NAPCO Security Technologies, Inc. (NSSC), one of the world's leading solutions providers and manufacturers of high-technology
electronic intrusion security, connected home, video and fire systems, as well as enterprise-class access control and door locking
products, today announced financial results for its fiscal year ended June 30, 2014.

[0001144204-14-056567:8k_2_02:8]
Highlights:

[0001144204-14-056567:8k_2_02:9]
|  | · | Net sales for the fourth quarter were $21.5 million, comparable to the same quarter last year which included a large custom access control order for a major university. Net sales for the year were a record $74.4 million, a 4% increase from $71.4 million last year. |

[0001144204-14-056567:8k_2_02:10]
|  | · | Sales of the Company's door-locking products, including LocDown™ products, grew 12% in the fourth quarter, representing the eighth consecutive quarter of growth of these products. |

[0001144204-14-056567:8k_2_02:11]
|  | · | Intrusion recurring revenue for the fourth quarter and the full fiscal year increased 82% and 98% respectively and grew sequentially by 12%. |

[0001144204-14-056567:8k_2_02:12]
|  | · | Gross margin improved 40 basis points to 38.5% for the quarter, the highest gross margin of the fiscal year and the highest in eight years, as compared to 38.1% for the same period last year. Gross margin for the year improved 150 basis points to 31.9% as compared to 30.4% a year ago. |

[0001144204-14-056567:8k_2_02:13]
|  | · | Income before taxes for fiscal 2014 increased by $799,000, or 25%, to $4.0 million from $3.2 million last year. |

[0001144204-14-056567:8k_2_02:14]
|  | · | Earnings per share (diluted) for the fourth quarter decreased 29% to $0.12 from $0.17, reflecting increased investments in sales and marketing to drive and support long-term, future growth. Earnings per share (diluted) for the year increased 13% to $0.18 from $0.16. |

[0001144204-14-056567:8k_2_02:15]
|  | · | Debt, net of cash, has been reduced by $26.6 million from $35.9 million to $9.3 million since acquiring Marks in August of 2008, with $3.9 million of this reduction occurring in this fiscal year. |

[0001144204-14-056567:8k_2_02:16]
Richard Soloway, Chairman and President
summarized, "2014 saw the culmination of positioning the company for sustainable, long-term growth in a variety of market
sectors in which NAPCO competes. A significant component of our expected future growth is based on a recurring revenue model which
should, in turn, drive incremental bottom line growth. I am encouraged by the positive trends in gross profitability we are already
seeing from the increase in recurring revenue. We are successfully building upon our substantial base of business by entering categories
which offer promising future long-term sales growth, such as the paradigm-shifting Connected Home Services business, a revolution
in the way consumers control all of their household systems via the internet. Our Company has also become a major market participant
in providing advanced security solutions to address the growing need for increased safety in the education market. Today, NAPCO
is a company with a broad portfolio of solutions that are each poised to not only contribute to significant long-term revenue growth
in their respective market segments, but with our business model, they are positioned to grow profitably."

[0001144204-14-056567:8k_2_02:17]
"The NAPCO Intrusion, Fire and Connected
Home Division performed well in expanding its product entries, which generate highly profitable recurring revenue, namely iBridge™
Connected Home Services and Starlink™ 3G/4G Radios. The iBridge Connected Home Dealer Program, launched in April, is comprised
of a network of professional installation companies which are capitalizing on the increasing consumer interest in controlling security
systems, thermostats, lighting, video cameras and entry locks, all remotely, via smart phones and tablets. Consumer adoption is
at the beginning stages of taking hold in the nascent Connected Home category, and while we have not yet seen the near-term growth
as expected, we are increasingly encouraged by the progress we are making and the response from our dealer network."

[0001144204-14-056567:8k_2_02:18]
Mr. Soloway added, "The Alarm Lock,
Continental Access Control and Marks USA Divisions introduced our unique Project LocDown™ product solutions to the growing
education vertical, and these solutions have been well-received in the marketplace. These solutions, along with the application
of our innovative School Access-Control Vulnerability Index ('S.A.V.I.') Audit  Program, strive to protect schools across
the U.S. from, all too frequent, active-shooter attacks. As an example, our Alarm Lock Division, is a pioneer in the commercial,
wireless, access control locking arena, with its Networx™ Wireless Locking Systems. Networx offers cost-effective, low installation
labor, solutions to the needs of the K-12, college and university education vertical by providing unique global and individual
classroom lock-down capabilities. Additionally, Continental Access Control, by integrating the Networx Wireless Locking System,
produces a cost-effective enterprise-class solution for the education and health-care verticals. Also, the Marks USA Architectural
Locking Division's LocDown™ intruder lock allows teachers to lock-down their doors, safely from inside the classroom, and
the Marks' anti-ligature, suicide preventative LifeSaver™ lock. Each of these segments generated profitable top-line growth,
though schools are just beginning to allocate budget resources for these solutions and we are still at the beginning of the adoption
curve."

[0001144204-14-056567:8k_2_02:19]
Mr. Soloway concluded, "We enter fiscal
2015 well-positioned for sustainable and profitable long-term growth. I firmly believe we have the most comprehensive offering
in the industry, and increasingly, our large and growing dealer network is embracing our Connected Home and school safety offerings.
The steadily growing consumer demand for Connected Home solutions, and the investments in school safety, will drive adoption. The
fact that we delivered the highest gross margin in eight years, and have a cost-effective, off-shore manufacturing capability that
enables us to scale profitably, makes me increasingly excited about the future of NAPCO."

[0001144204-14-056567:8k_2_02:20]
Fiscal 2014 Results

[0001144204-14-056567:8k_2_02:21]
Net Sales for the three months ended June
30, 2014 remained relatively constant at $21.5 million, as compared to $21.8 million for the same period one year ago. Revenue
in the fourth quarter of last year included a large custom access control order for a major university. Revenue for the year ended
June 30, 2014 increased 4% to a record $74.4 million, compared to $71.4 million a year ago. Selling, general and administrative
expenses for the quarter were $5.5 million, as compared to $4.7 million for the same period in 2013. Selling, general and administrative
expenses for the year ended June 30, 2014 increased by $1.4 million, or 8%, to $19.4 million or 26.1% of sales, compared to $18.0
million or 25.2% of sales last year. The increase was due primarily to additional sales staff and tradeshow and advertising expenditures
to support recent product introductions.

[0001144204-14-056567:8k_2_02:22]
Operating income for the three months ended
June 30, 2014 decreased by $734,000 or 21% to $2.8 million as compared to $3.6 million for the same period a year ago. Operating
income for the year ended June 30, 2014 increased by $599,000 or 16% to $4.3 million as compared to $3.7 million for the same period
a year ago. Adjusted EBITDA* for the three months ended June 30, 2014 decreased $719,000, or 18%, to $3.3 million as compared to
$4.1 million for the same period a year ago (*see table attached). Adjusted EBITDA* for the year ended June 30, 2014 increased
$441,000, or 8%, to $6.1 million as compared to $5.7 million for the same period a year ago (*see table attached).

[0001144204-14-056567:8k_2_02:23]
Net income for the three months ended June
30, 2014 decreased by $874,000 or 27%, to $2.3 million or $0.12 per share as compared to $3.2 million or $0.17 per share for the
same period last year. Net income for the year ended June 30, 2014 increased by $455,000 or 15% to $3.5 million or $0.18 per share
compared to net income of $3.0 million or $0.16 per share for the same period last year. Full-year net income of $3.5 million was
the highest level since the recession of 2008.

[0001144204-14-056567:8k_2_02:24]
Balance Sheet Summary

[0001144204-14-056567:8k_2_02:25]
At June 30, 2014, the Company had $2.5
million in cash and cash equivalents a decrease of $746,000 compared to $3.2 million at June 30, 2013. NAPCO had working capital
of $33.4 million as compared with working capital of $33.2 million at June 30, 2013. Current ratio was 4.6:1 at June 30, 2014 and
4.9:1 at June 30, 2013. Debt, net of cash, was $9.3 million at June 30, 2014, a decrease of $3.9 million compared to $13.2 million
as of June 30, 2013.

[0001144204-14-056567:8k_2_02:26]
NAPCO Security Technologies, Inc. Annual
Meeting of Stockholders

[0001144204-14-056567:8k_2_02:27]
NAPCO Security Technologies, Inc. annual
meeting is set for December 10, 2014, for shareholders of record as of October 30, 2014.

[0001144204-14-056567:8k_2_02:28]
Conference Call Information

[0001144204-14-056567:8k_2_02:29]
Management will conduct a conference call
at 11 a.m. today, September 15, 2014. Interested parties may participate in the call by dialing 1-877-407-4018 or for international
callers, 1-201-689-8471, about 5-10 minutes prior to the start time of 11 a.m. ET. The conference call will also be available on
replay starting at 2 p.m. ET on September 15, 2014 and ending on September 22, 2014. For the replay, please dial 1-877-870-5176
domestically, or 1-858-384-5517 for international callers, and use the replay access code 13590077. In addition, the call will
be webcast and will be available on the Company's website at www.napcosecurity.com or by visiting http://public.viavid.com/index.php?id=110771.

[0001144204-14-056567:8k_2_02:30]
About NAPCO Security Technologies, Inc.

[0001144204-14-056567:8k_2_02:31]
NAPCO Security Technologies, Inc. is one
of the world's leading solutions providers and manufacturers of high-technology electronic security, connected home, video, fire
alarm, access control and door locking systems. The Company consists of four Divisions: NAPCO, its security and connected home
segment, plus three wholly-owned subsidiaries: Alarm Lock, Continental Instruments, and Marks USA. Headquartered in Amityville,
New York, its products are installed by tens of thousands of security professionals worldwide in commercial, industrial, institutional,
residential and government applications. NAPCO products have earned a reputation for  innovation, technical excellence and
reliability, positioning the Company for growth in the multi-billion dollar and rapidly expanding electronic security market. For
additional information on NAPCO, please visit the Company's web site at http://www.napcosecurity.com.

[0001144204-14-056567:8k_2_02:32]
Safe Harbor Statement

[0001144204-14-056567:8k_2_02:33]
This press release contains forward-looking
statements that involve numerous risks and uncertainties. Actual results, performance or achievements could differ materially from
those anticipated in such forward-looking statements as a result of certain factors, including those set forth in the Company's
filings with the Securities and Exchange Commission.

[0001144204-14-056567:8k_2_02:34]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS (audited) |

[0001144204-14-056567:8k_2_02:35]
|  |  | June 30, 2014 |  |  | June 30, 2013 |  |
| ASSETS |  | (in thousands, except for share data) |  |
| CURRENT ASSETS |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,483 |  |  | $ | 3,229 |  |
| Accounts receivable, net of reserves and allowances |  |  | 16,904 |  |  |  | 18,211 |  |
| Inventories |  |  | 21,443 |  |  |  | 18,471 |  |
| Prepaid expenses and other current assets |  |  | 989 |  |  |  | 1,219 |  |
| Income tax receivable |  |  | 121 |  |  |  | 64 |  |
| Deferred income taxes |  |  | 739 |  |  |  | 642 |  |
| Total Current Assets |  |  | 42,679 |  |  |  | 41,836 |  |
| Inventories - non-current |  |  | 3,567 |  |  |  | 3,436 |  |
| Deferred income taxes |  |  | 1,005 |  |  |  | 1,526 |  |
| Property, plant and equipment, net |  |  | 6,394 |  |  |  | 6,586 |  |
| Intangible assets, net |  |  | 9,552 |  |  |  | 10,334 |  |
| Other assets |  |  | 167 |  |  |  | 185 |  |
| TOTAL ASSETS |  | $ | 63,364 |  |  | $ | 63,903 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| CURRENT LIABILITIES |  |  |  |  |  |  |  |  |
| Current maturities of long term debt |  | $ | 1,600 |  |  | $ | 1,600 |  |
| Accounts payable |  |  | 4,082 |  |  |  | 3,318 |  |
| Accrued expenses |  |  | 1,737 |  |  |  | 2,093 |  |
| Accrued salaries and wages |  |  | 1,824 |  |  |  | 1,604 |  |
| Total Current Liabilities |  |  | 9,243 |  |  |  | 8,615 |  |
| Long-term debt, net of current maturities |  |  | 10,200 |  |  |  | 14,800 |  |
| Accrued income taxes |  |  | 169 |  |  |  | 153 |  |
| Total Liabilities |  |  | 19,612 |  |  |  | 23,568 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Common Stock, par value $0.01 per share; 40,000,000 shares authorized; 21,049,243 and 20,796,813 shares issued; and 19,419,076 and 19,296,335 shares outstanding, respectively |  |  | 210 |  |  |  | 208 |  |
| Additional paid-in capital |  |  | 16,032 |  |  |  | 15,356 |  |
| Retained earnings |  |  | 35,554 |  |  |  | 32,078 |  |
|  |  |  | 51,796 |  |  |  | 47,642 |  |
| Less: Treasury Stock, at cost (1,630,167 and 1,000,000 shares, respectively) |  |  | (8,044 | ) |  |  | (7,307 | ) |
| TOTAL STOCKHOLDERS' EQUITY |  |  | 43,752 |  |  |  | 40,335 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY |  | $ | 63,364 |  |  | $ | 63,903 |  |

[0001144204-14-056567:8k_2_02:36]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME (audited) |

[0001144204-14-056567:8k_2_02:37]
|  |  | Three months ended June 30, |  |  | Twelve months ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (In thousands, except share and per share data) |  |
| Net sales |  | $ | 21,518 |  |  | $ | 21,795 |  |  | $ | 74,382 |  |  | $ | 71,386 |  |
| Cost of sales |  |  | 13,242 |  |  |  | 13,500 |  |  |  | 50,669 |  |  |  | 49,662 |  |
| Gross Profit |  |  | 8,276 |  |  |  | 8,295 |  |  |  | 23,713 |  |  |  | 21,724 |  |
| Selling, general, and administrative expenses |  |  | 5,453 |  |  |  | 4,738 |  |  |  | 19,397 |  |  |  | 18,007 |  |
| Operating Income |  |  | 2,823 |  |  |  | 3,557 |  |  |  | 4,316 |  |  |  | 3,717 |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | 56 |  |  |  | 108 |  |  |  | 295 |  |  |  | 495 |  |
| Other, net |  |  | 4 |  |  |  | 4 |  |  |  | 14 |  |  |  | 14 |  |
|  |  |  | 60 |  |  |  | 112 |  |  |  | 309 |  |  |  | 509 |  |
| Income before Provision for Income Taxes |  |  | 2,763 |  |  |  | 3,445 |  |  |  | 4,007 |  |  |  | 3,208 |  |
| Provision for income taxes |  |  | 428 |  |  |  | 236 |  |  |  | 531 |  |  |  | 187 |  |
| Net Income |  | $ | 2,335 |  |  | $ | 3,209 |  |  | $ | 3,476 |  |  | $ | 3,021 |  |
| Net Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.18 |  |  | $ | 0.16 |  |
| Diluted |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.18 |  |  | $ | 0.16 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 19,419,000 |  |  |  | 19,296,000 |  |  |  | 19,392,000 |  |  |  | 19,210,000 |  |
| Diluted |  |  | 19,431,000 |  |  |  | 19,441,000 |  |  |  | 19,428,000 |  |  |  | 19,362,000 |  |

[0001144204-14-056567:8k_2_02:38]
| NAPCO SECURITY TECHNOLOGIES, INC. AND SUBSIDIARIES |
| NON-GAAP MEASURES OF PERFORMANCE* (unaudited) |

[0001144204-14-056567:8k_2_02:39]
|  |  | Three months endedJune 30, |  |  | Twelve months endedJune 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
|  |  | (In thousands) |  |
| Net income |  | $ | 2,335 |  |  | $ | 3,209 |  |  | $ | 3,476 |  |  | $ | 3,021 |  |
| Add back provision for income taxes |  |  | 428 |  |  |  | 236 |  |  |  | 531 |  |  |  | 187 |  |
| Add back interest and other expense |  |  | 60 |  |  |  | 112 |  |  |  | 309 |  |  |  | 509 |  |
| Operating income (GAAP) |  |  | 2,823 |  |  |  | 3,557 |  |  |  | 4,316 |  |  |  | 3,717 |  |
| Adjustments for non-GAAP measures of performance: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization of acquisition-related intangibles |  |  | 196 |  |  |  | 229 |  |  |  | 782 |  |  |  | 917 |  |
| Add back stock-based compensation expense |  |  | 59 |  |  |  | -- |  |  |  | 76 |  |  |  | -- |  |
| Adjusted non-GAAP operating income |  |  | 3,078 |  |  |  | 3,786 |  |  |  | 5,174 |  |  |  | 4,634 |  |
| Add back depreciation and other amortization |  |  | 267 |  |  |  | 278 |  |  |  | 958 |  |  |  | 1,057 |  |
| Adjusted EBITDA (earnings before interest, taxes, depreciation and amortization) |  | $ | 3,345 |  |  | $ | 4,064 |  |  | $ | 6,132 |  |  | $ | 5,691 |  |
| Adjusted EBITDA per Diluted Share |  | $ | 0.17 |  |  | $ | 0.21 |  |  | $ | 0.32 |  |  | $ | 0.29 |  |
| Weighted average number of Diluted Shares outstanding |  |  | 19,431,000 |  |  |  | 19,441,000 |  |  |  | 19,428,000 |  |  |  | 19,362,000 |  |

[0001144204-14-056567:8k_2_02:40]
* Non-GAAP Information. Certain non-GAAP measures are included
in this press release, including EBITDA, non-GAAP operating income and Adjusted EBITDA. We define EBITDA as GAAP net income plus
income tax expense (benefit), net interest expense and depreciation and amortization expense. Non-GAAP operating income does not
include impairment of goodwill, amortization of intangibles, restructuring charges, stock-based compensation expense and other
infrequent or unusual charges. These non-GAAP measures are provided to enhance the user's overall understanding of our financial
performance. By excluding these charges our non-GAAP results provide information to management and investors that is useful in
assessing NAPCO's core operating performance and in comparing our results of operations on a consistent basis from period to period.
The presentation of this information is not meant to be a substitute for the corresponding financial measures prepared in accordance
with generally accepted accounting principles. Investors are encouraged to review the reconciliation of GAAP to non-GAAP financial
measures included in the above.

[0001144204-14-056567:8k_2_02:41]
INVESTOR INQUIRIES:

[0001144204-14-056567:8k_2_02:42]
Brett Maas

[0001144204-14-056567:8k_2_02:43]
Hayden IR

[0001144204-14-056567:8k_2_02:44]
(646) 536-7331

[0001144204-14-056567:8k_2_02:45]
brett@haydenir.com
