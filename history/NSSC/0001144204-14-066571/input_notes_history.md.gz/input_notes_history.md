# NSSC note change history — 0001157523-14-001989 → 0001144204-14-066571


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001144204-14-066571:note_history:1]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $9,000 for the three months ended September 30, 2014 and 2013, respectively.
  (was, 2014-05-07, similarity 0.7866):
[0001157523-14-001989:note_history:1]
Rent
 expense, with the exception of the land lease referred to below,
 totaled approximately $7,000 and $14,000 for the three months ended
 March 31, 2014 and 2013, respectively and $25,000 and $37,000 for
 the nine months ended March 31, 2014 and 2013,
 respectively.

- changed (2014-11-10):
[0001144204-14-066571:note_history:2]
As of September 30, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.
  (was, 2014-05-07, similarity 0.7026):
[0001157523-14-001989:note_history:2]
As
 of June 30, 2013, the Company was obligated under two employment
 agreements and one severance agreement.  The employment
 agreements are with the Company’s CEO and Senior Vice
 President of Sales and Marketing (“the SVP”). The
 employment agreement with the CEO provides for an annual salary of
 $587,000, as adjusted for inflation; incentive compensation as may
 be approved by the Board of Directors from time to time and a
 termination payment in an amount up to 299% of the average of the
 prior five calendar year's compensation, subject to certain
 limitations, as defined in the agreement.  The employment
 agreement renews annually in August unless either party gives the
 other notice of non-renewal at least six months prior to the end of
 the applicable term. The employment agreement with the SVP expires
 in October 2014 and provides for an annual salary of $274,400 and,
 if terminated by the Company without cause, severance of nine
 months’ salary and continued company-sponsored health
 insurance for six months from the date of termination. The
 severance agreement provides for payments equal to nine months of
 salary and six months of health insurance in the event of a
 non-voluntary termination of employment without cause.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-11-10):
[0001144204-14-066571:note_history:3]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

- changed (2014-11-10):
[0001144204-14-066571:note_history:4]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated. Certain prior period amounts relating to credit card fees have been reclassified for consistency with the current period presentation. The reclassification did not have an impact on the Balance Sheets, Statement of Cash Flows or reported Net income (loss) for any period.
  (was, 2014-05-07, similarity 0.9762):
[0001157523-14-001989:note_history:4]
The
 unaudited condensed consolidated financial statements of Napco
 Security Technologies, Inc and Subsidiaries (the
 “Company”), including these notes, have been prepared
 by the Company in accordance with U.S. generally accepted
 accounting principles (“GAAP”) for interim financial
 information and pursuant to the rules and regulations promulgated
 by the U.S. Securities and Exchange Commission (the
 “SEC”). Accordingly, certain information and
 disclosures normally included in financial statements prepared in
 accordance with GAAP have been omitted or condensed. However, in
 the opinion of management, all adjustments (consisting of normal
 recurring accruals) considered necessary for a fair presentation
 have been included. These unaudited condensed consolidated
 financial statements should be read in conjunction with the
 Company’s audited consolidated financial statements for the
 year ended June 30, 2013 and the notes thereto included in the
 Company’s Annual Report on Form 10-K filed with the SEC on
 September 17, 2013. Results of consolidated operations for the
 interim periods are not necessarily indicative of a full
 year’s operating results. The unaudited condensed
 consolidated financial statements herein include the accounts of
 the Company and its wholly owned subsidiaries. All material
 inter-company accounts and transactions have been eliminated.
 Certain
 prior period amounts relating to credit card fees have been
 reclassified for consistency with the current period presentation.
 The reclassification did not have an impact on the Balance Sheets,
 Statement of Cash Flows or reported Net income (loss) for any
 period.

- changed (2014-11-10):
[0001144204-14-066571:note_history:5]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent gains and losses at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Critical estimates include management's judgments associated with reserves for sales returns and allowances, concentration of credit risk, inventory reserves, intangible assets and income taxes. Actual results could differ from those estimates.
  (was, 2014-05-07, similarity 0.9773):
[0001157523-14-001989:note_history:5]
The
 preparation of financial statements in conformity with accounting
 principles generally accepted in the United States of America
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent gains and losses at the date of the financial statements
 and the reported amounts of revenues and expenses during the
 reporting period. Critical estimates include management's judgments
 associated with revenue recognition, reserves for sales returns and
 allowances, concentration of credit risk, inventories, intangible
 assets and income taxes.  Actual results could differ
 from those estimates.

- changed (2014-11-10):
[0001144204-14-066571:note_history:6]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2014 in the amount of $11,400,000 approximates fair value.
  (was, 2014-05-07, similarity 0.9721):
[0001157523-14-001989:note_history:6]
The
 methods and assumptions used to estimate the fair value of the
 following classes of financial instruments were: Current Assets and
 Current Liabilities: The carrying amount of cash, certificates of
 deposits, current receivables and payables and certain other
 short-term financial instruments approximate their fair value as of
 March 31, 2014 due to their short-term maturities; Long-Term Debt:
 The carrying amount of the Company’s long-term debt,
 including the current portion, at March 31, 2014 in the amount of
 $12,200,000 approximates fair value.

- added (2014-11-10):
[0001144204-14-066571:note_history:7]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits

- changed (2014-11-10):
[0001144204-14-066571:note_history:8]
Accounts receivable is stated net of the reserves for doubtful accounts of $165,000 and $180,000 and for returns and other allowances of $840,000 and $1,005,000 as of September 30, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.
  (was, 2014-05-07, similarity 0.9872):
[0001157523-14-001989:note_history:8]
Accounts
 receivable is stated net of the reserves for doubtful accounts of
 $180,000 and $220,000 and for returns and other allowances of
 $865,000 and $1,055,000 as of March 31, 2014 and June 30, 2013,
 respectively.  Our reserves for doubtful accounts and for
 returns and other allowances are subjective critical estimates that
 have a direct impact on reported net earnings. These reserves are
 based upon the evaluation of accounts receivable agings, specific
 exposures, sales levels and historical trends.

- changed (2014-11-10):
[0001144204-14-066571:note_history:9]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of  twenty years (customer relationships) and seven years (non-compete agreement). The Marks trade name was deemed to have an indefinite life.
  (was, 2014-05-07, similarity 0.9894):
[0001157523-14-001989:note_history:9]
The
 Company’s acquisition of substantially all of the assets and
 certain liabilities of G. Marks Hardware Inc. (“Marks
 USA”) in August 2008 included intangible assets recorded at
 fair value on the date of acquisition. The intangible assets are
 amortized over their estimated useful lives of twenty years
 (customer relationships) and seven years (non-compete agreement).
 The Marks USA trade name was deemed to have an indefinite
 life.

- changed (2014-11-10):
[0001144204-14-066571:note_history:10]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,357) |  | $ | 3,443 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (297) |  |  | 43 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,654) |  | $ | 9,386 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |
  (was, 2014-05-07, similarity 0.7398):
[0001157523-14-001989:note_history:10]
|  |  | March 31, 2014 |  |  | June 30, 2013 |  |
|  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |  | Cost |  |  | Accumulated amortization |  |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  |  | $ | (6,019 | ) |  | $ | 3,781 |  |  | $ | 9,800 |  |  | $ | (5,469 | ) |  | $ | 4,331 |  |
| Non-compete agreement |  |  | 340 |  |  |  | (273 | ) |  |  | 67 |  |  |  | 340 |  |  |  | (237 | ) |  |  | 103 |  |
| Trade name |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |  |  | 5,900 |  |  |  | -- |  |  |  | 5,900 |  |
|  |  | $ | 16,040 |  |  | $ | (6,292 | ) |  | $ | 9,748 |  |  | $ | 16,040 |  |  | $ | (5,706 | ) |  | $ | 10,334 |  |

- changed (2014-11-10):
[0001144204-14-066571:note_history:11]
Amortization expense for intangible assets subject to amortization was approximately $166,000 and $195,000 for the three months ended September 30, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.7 years and  14.6 years at September 30, 2014 and 2013, respectively.
  (was, 2014-05-07, similarity 0.817):
[0001157523-14-001989:note_history:11]
Amortization
 expense for intangible assets subject to amortization was
 approximately $195,000 and $229,000 for the three months ended
 March 31, 2014 and 2013, respectively. Amortization expense for
 intangible assets subject to amortization was approximately
 $586,000 and $688,000 for the nine months ended March 31, 2014 and
 2013, respectively. Amortization expense for each of the next five
 fiscal years is estimated to be as follows: 2014 - $781,000; 2015 -
 $667,000; 2016 - $529,000; 2017 - $441,000 and 2018 - $371,000. The
 weighted average amortization period for intangible assets was 14.1
 years and 15.1 years at March 31, 2014 and 2013,
 respectively.

- changed (2014-11-10):
[0001144204-14-066571:note_history:12]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% and 7% for the three months ended September 30, 2014 and 2013, respectively.
  (was, 2014-05-07, similarity 0.867):
[0001157523-14-001989:note_history:12]
The
 Company analyzes sales returns and is able to make reasonable and
 reliable estimates of product returns based on the Company’s
 past history. Estimates for sales returns are based on several
 factors including actual returns and based on expected return data
 communicated to it by its customers. Accordingly, the Company
 believes that its historical returns analysis is an accurate basis
 for its allowance for sales returns. Actual results could differ
 from those estimates.

- changed (2014-11-10):
[0001144204-14-066571:note_history:13]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2014 and 2013 was $544,000 and $365,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.
  (was, 2014-05-07, similarity 0.6856):
[0001157523-14-001989:note_history:13]
Advertising
 and promotional costs are included in "Selling, General and
 Administrative" expenses in the consolidated statements of
 operations and are expensed as incurred.  Advertising
 expense for the three months ended March 31, 2014 and 2013 was
 $189,000 and $124,000, respectively. Advertising expense for the
 nine months ended March 31, 2014 and 2013 was $801,000 and
 $847,000, respectively.

- changed (2014-11-10):
[0001144204-14-066571:note_history:14]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2014 and 2013 was $1,307,000 and $1,286,000, respectively.
  (was, 2014-05-07, similarity 0.7944):
[0001157523-14-001989:note_history:14]
Research
 and development costs incurred by the Company are charged to
 expense in the year incurred and are included in "Cost of Sales" in
 the consolidated statements of
 operations.  Company-sponsored research and development
 expense for the three months ended March 31, 2014 and 2013 was
 $1,275,000 and $1,187,000, respectively. Company-sponsored research
 and development expense for the nine months ended March 31, 2014
 and 2013 was $3,813,000 and $3,842,000, respectively.

- changed (2014-11-10):
[0001144204-14-066571:note_history:15]
Net Income Per Share
  (was, 2014-05-07, similarity 0.8511):
[0001157523-14-001989:note_history:15]
Net
 Income (Loss) Per Share

- changed (2014-11-10):
[0001144204-14-066571:note_history:16]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.
  (was, 2014-05-07, similarity 0.8379):
[0001157523-14-001989:note_history:16]
Basic
 net income (loss) per common share (Basic EPS) is computed by
 dividing net income by the weighted average number of common shares
 outstanding.  Diluted net income (loss) per common share
 (Diluted EPS) is computed by dividing net income by the weighted
 average number of common shares and dilutive common share
 equivalents and convertible securities then
 outstanding.

- changed (2014-11-10):
[0001144204-14-066571:note_history:17]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):
  (was, 2014-05-07, similarity 0.9709):
[0001157523-14-001989:note_history:17]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the three months ended March
 31 (in thousands, except per share data):

- changed (2014-11-10):
[0001144204-14-066571:note_history:18]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 159 |  | $ | 123 |  |  | 19,412 |  |  | 19,323 |  | $ | 0.01 |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | — |  |  | 18 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 159 |  | $ | 123 |  |  | 19,412 |  |  | 19,341 |  | $ | 0.01 |  | $ | 0.01 |  |
  (was, 2014-05-07, similarity 0.6172):
[0001157523-14-001989:note_history:18]
|  |  | Net Income |  |  | Weighted Average Shares |  |  | Net Income per Share |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Basic EPS |  | $ | 650 |  |  | $ | 111 |  |  |  | 19,416 |  |  |  | 19,296 |  |  | $ | 0.03 |  |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 55 |  |  |  | 123 |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 650 |  |  | $ | 111 |  |  |  | 19,471 |  |  |  | 19,419 |  |  | $ | 0.03 |  |  | $ | 0.01 |  |

- changed (2014-11-10):
[0001144204-14-066571:note_history:19]
Options to purchase  145,500 and  268,116 shares of common stock for the three months ended September 30, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.
  (was, 2014-05-07, similarity 0.9754):
[0001157523-14-001989:note_history:19]
Options
 to purchase 37,500 and 395,750 shares of common stock for the three
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

- changed (2014-11-10):
[0001144204-14-066571:note_history:20]
The Company has established two share incentive programs as discussed in Note 7.
  (was, 2014-05-07, similarity 0.974):
[0001157523-14-001989:note_history:20]
The
 Company has established share incentive programs as discussed in
 Note 7.

- added (2014-11-10):
[0001144204-14-066571:note_history:21]
Stock-based compensation costs of $33,000 and $1,000 were recognized for three months ended September 30, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2014 and 2013.

- added (2014-11-10):
[0001144204-14-066571:note_history:22]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2014 and 2013.

- added (2014-11-10):
[0001144204-14-066571:note_history:23]
For the three months ended September 30, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.

- changed (2014-11-10):
[0001144204-14-066571:note_history:24]
The Company records the amount billed to customers for shipping and handling in net sales ($127,000 and $131,000 in the three months ended September 30, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($241,000 and $242,000 in the three months ended September 30, 2014 and 2013, respectively).
  (was, 2014-05-07, similarity 0.7778):
[0001157523-14-001989:note_history:24]
The
 Company records the amount billed to customers for shipping and
 handling in net sales ($131,000 and $118,000 in the three months
 ended March 31, 2014 and 2013, respectively and $383,000 and
 $367,000 in the nine months ended March 31, 2014 and 2013,
 respectively) and classifies the costs associated with these
 revenues in cost of sales ($241,000 and $266,000 in the three
 months ended March 31, 2014 and 2013, respectively and $704,000 and
 $748,000 in the nine months ended March 31, 2014 and 2013,
 respectively).

- added (2014-11-10):
[0001144204-14-066571:note_history:25]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers (Topic 606),” which is the new comprehensive revenue recognition standard that will supersede all existing revenue recognition guidance under U.S. GAAP. The standard’s core principle is that a company will recognize revenue when it transfers promised goods or services to a customer in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services. ASU 2014-09 is effective for annual and interim periods beginning on or after December 15, 2016, and early adoption is not permitted. Entities will have the option of using either a full retrospective approach or a modified approach to adopt the guidance. The Company is currently evaluating the impact of adopting this guidance.

- changed (2014-11-10):
[0001144204-14-066571:note_history:26]
In July 2013, the FASB issued authoritative guidance that requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a net operating loss (“NOL”) carry-forward, a similar tax loss, or a tax credit carry-forward.  If either (i) an NOL carry-forward, a similar tax loss, or tax credit carry-forward is not available as of the reporting date under the governing tax law to settle taxes that would result from the disallowance of the tax position or (ii) the entity does not intend to use the deferred tax asset for this purpose (provided that the tax law permits a choice), an entity should present an unrecognized tax benefit in the financial statements as a liability and should not net the unrecognized tax benefit with a deferred tax asset.  This guidance became effective for unrecognized tax benefits that exist as of the Company’s fiscal 2015 first quarter. The guidance did not have an impact on the Company’s consolidated financial statements.
  (was, 2014-05-07, similarity 0.8872):
[0001157523-14-001989:note_history:26]
In
 July 2013, the FASB issued authoritative guidance that
 requires an entity to present an unrecognized tax benefit, or a
 portion of an unrecognized tax benefit, in the financial statements
 as a reduction to a deferred tax asset for a net operating loss
 (“NOL”) carry-forward, a similar tax loss, or a tax
 credit carry-forward.  If either (i) an NOL
 carry-forward, a similar tax loss, or tax credit carry-forward is
 not available as of the reporting date under the governing tax law
 to settle taxes that would result from the disallowance of the tax
 position or (ii) the entity does not intend to use the
 deferred tax asset for this purpose (provided that the tax law
 permits a choice), an entity should present an unrecognized tax
 benefit in the financial statements as a liability and should not
 net the unrecognized tax benefit with a deferred tax asset. 
 This guidance becomes effective prospectively for unrecognized tax
 benefits that exist as of the Company’s fiscal 2015 first
 quarter, with retrospective application and early adoption
 permitted.  The Company is currently evaluating the timing of
 adoption and the impact of this balance sheet presentation guidance
 but does not expect it to have a significant impact on the
 Company’s consolidated financial statements.

- removed (2014-11-10):
[0001157523-14-001989:note_history:27]
Napco
 Security Technologies, Inc. and Subsidiaries (the "Company") is a
 diversified manufacturer of security products, encompassing
 electronic door-locking devices, intrusion and fire alarms and
 building access control systems. These products are used for
 commercial, residential, institutional, industrial and governmental
 applications, and are sold worldwide principally to independent
 distributors, dealers and installers of security
 equipment.

- removed (2014-11-10):
[0001157523-14-001989:note_history:28]
Cash
 and cash equivalents include approximately $460,000 of short-term
 time deposits at March 31, 2014 and June 30, 2013.  The
 Company considers all highly liquid investments with original
 maturities of three months or less to be cash
 equivalents.  The Company has cash balances in banks in
 excess of the maximum amount insured by the FDIC and other
 international agencies as of March 31, 2014 and June 30, 2013. The
 Company has historically not experienced any credit losses with
 balances in excess of FDIC limits.

- removed (2014-11-10):
[0001157523-14-001989:note_history:29]
The
 following provides a reconciliation of information used in
 calculating the per share amounts for the nine months ended March
 31 (in thousands, except per share data):

- removed (2014-11-10):
[0001157523-14-001989:note_history:30]
|  |  | Net Income (Loss) |  |  | Weighted Average Shares |  |  | Net Income (Loss) per Share |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Basic EPS |  | $ | 1,141 |  |  | $ | (188 | ) |  |  | 19,382 |  |  |  | 19,181 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | -- |  |  |  | -- |  |  |  | 37 |  |  |  | -- |  |  |  | -- |  |  |  | -- |  |
| Diluted EPS |  | $ | 1,141 |  |  | $ | (188 | ) |  |  | 19,419 |  |  |  | 19,181 |  |  | $ | 0.06 |  |  | $ | (0.01 | ) |

- removed (2014-11-10):
[0001157523-14-001989:note_history:31]
Options
 to purchase 145,673 and 672,740 shares of common stock for the nine
 months ended March 31, 2014 and 2013, respectively, were not
 included in the computation of Diluted EPS because their inclusion
 would be anti-dilutive.  These options were still
 outstanding at the end of the respective periods.

- removed (2014-11-10):
[0001157523-14-001989:note_history:32]
Stock-based
 compensation costs of $10,000 and $0 were recognized for the three
 months ended March 31, 2014 and 2013, respectively and $17,000 and
 $0 for the nine months ended March 31, 2014 and 2013,
 respectively.

- removed (2014-11-10):
[0001157523-14-001989:note_history:33]
All
 assets and liabilities of foreign subsidiaries are translated into
 U.S. Dollars at fiscal period-end exchange rates.  Income
 and expense items are translated at the prevailing exchange rates
 during the reporting period.  The realized and unrealized
 gains and losses associated with foreign currency translation, as
 well as related other comprehensive income, were not material for
 the nine months ended March 31, 2014 and 2013.

- removed (2014-11-10):
[0001157523-14-001989:note_history:34]
For
 the nine months ended March 31, 2014 and 2013 the Company's
 operations did not give rise to material items includable in
 comprehensive income which were not already included in net
 income.  Accordingly, the Company's comprehensive income
 approximates its net income for all periods presented.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001144204-14-066571:note_history:35]
As of September 30, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal,  quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal,  quarterly payments of $325,000.
  (was, 2014-05-07, similarity 0.7978):
[0001157523-14-001989:note_history:35]
As
 of March 31, 2014, long-term debt consisted of a revolving credit
 facility of $11,000,000 (the “Revolving Credit
 Facility”) which expires in June 2017 and two term loans, one
 for $6,000,000 which expires in June 2019, and one for $6,500,000
 which expires in June 2017 (the “Term Loans”).
 Repayment of the Terms Loans commenced on September 30, 2012. The
 $6,000,000 Term Loan is being repaid with 28 equal, quarterly
 payments of $75,000 and the remaining balance of $3,900,000 due on
 or before the expiration date. The $6,500,000 Term Loan is being
 repaid in 20 equal, quarterly payments of $325,000. In January 2014
 the Company and its lender amended the Revolving Credit Facility
 and Term Loans to allow for a lower LIBOR-based interest rate
 option of 1.5% as compared to 2.0% provided for previously. All
 other terms and conditions remain the same.

- changed (2014-11-10):
[0001144204-14-066571:note_history:36]
Outstanding balances and interest rates as of September 30, 2014 and June 30, 2014 are as follows:
  (was, 2014-05-07, similarity 0.9419):
[0001157523-14-001989:note_history:36]
Outstanding
 balances and interest rates as of March 31, 2014 and June 30, 2013
 are as follows:

- changed (2014-11-10):
[0001144204-14-066571:note_history:37]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,900 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,400 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2014-05-07, similarity 0.6136):
[0001157523-14-001989:note_history:37]
|  | March 31, 2014 |  | June 30, 2013 |
|  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit | $ 2,500 |  | 1.7% |  | $ 5,500 |  | 2.5% |
| Term loans | 9,700 |  | 1.7% |  | 10,900 |  | 2.5% |
| Total debt | $ 12,200 |  | 1.7% |  | $ 16,400 |  | 2.5% |

- changed (2014-11-10):
[0001144204-14-066571:note_history:38]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the  prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.
  (was, 2014-05-07, similarity 0.9996):
[0001157523-14-001989:note_history:38]
The
 Revolving Credit Facility and Term Loans (collectively the
 “Agreement”) also provide for a LIBOR-based interest
 rate option of LIBOR plus 1.5% to 2.75%, depending on the ratio of
 outstanding debt to EBITDA, which is to be measured and adjusted
 quarterly, a prime rate-based option of the prime rate plus 0.25%
 and other terms and conditions as more fully described in the
 Agreement. In addition, the Agreement provides for availability
 under the Revolving Credit Facility to be limited to the lesser of
 $11,000,000 or the result of a borrowing base formula based upon
 the Company’s Accounts Receivables and Inventory values net
 of certain deductions. The Company’s obligations under the
 Agreement continue to be secured by all of its assets, including
 but not limited to, deposit accounts, accounts receivable,
 inventory, the Company’s corporate headquarters in
 Amityville, NY, equipment and fixtures and intangible assets. In
 addition, the Company’s wholly-owned subsidiaries, with the
 exception of the Company’s foreign subsidiaries, have issued
 guarantees and pledges of all of their assets to secure the
 Company’s obligations under the Agreement. All of the
 outstanding common stock of the Company’s domestic
 subsidiaries and 65% of the common stock of the Company’s
 foreign subsidiaries has been pledged to secure the Company’s
 obligations under the Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-10):
[0001144204-14-066571:note_history:39]
Outstanding balances and interest rates as of September 30, 2014 and June 30, 2014 are as follows:
  (was, 2014-05-07, similarity 0.9419):
[0001157523-14-001989:note_history:39]
Outstanding
 balances and interest rates as of March 31, 2014 and June 30, 2013
 are as follows:

- changed (2014-11-10):
[0001144204-14-066571:note_history:40]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,900 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,400 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |
  (was, 2014-05-07, similarity 0.6136):
[0001157523-14-001989:note_history:40]
|  | March 31, 2014 |  | June 30, 2013 |
|  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |
| Revolving line of credit | $ 2,500 |  | 1.7% |  | $ 5,500 |  | 2.5% |
| Term loans | 9,700 |  | 1.7% |  | 10,900 |  | 2.5% |
| Total debt | $ 12,200 |  | 1.7% |  | $ 16,400 |  | 2.5% |
