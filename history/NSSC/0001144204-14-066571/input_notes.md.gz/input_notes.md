# NSSC notes — 0001144204-14-066571


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-14-066571:notes:1]
NOTE 4 – Property, Plant and Equipment

[0001144204-14-066571:notes:2]
Property, plant and equipment consist of the following (in thousands):

[0001144204-14-066571:notes:3]
|  |  | September 30, 2014 |  | June 30, 2014 |  | Useful Life in Years |  |
| Land |  | $ | 904 |  | $ | 904 |  | — |  |
| Buildings |  |  | 8,911 |  |  | 8,911 |  | 30 to 40 |  |
| Molds and dies |  |  | 6,913 |  |  | 6,906 |  | 3 to 5 |  |
| Furniture and fixtures |  |  | 2,441 |  |  | 2,427 |  | 5 to 10 |  |
| Machinery and equipment |  |  | 19,933 |  |  | 19,974 |  | 7 to 10 |  |
| Leasehold improvements |  |  | 288 |  |  | 288 |  | Shorter of the lease term or life of asset |  |
|  |  |  | 39,391 |  |  | 39,410 |  |  |  |
| Less: accumulated depreciation and amortization |  |  | 33,096 |  |  | 33,016 |  |  |  |
|  |  | $ | 6,295 |  | $ | 6,394 |  |  |  |

[0001144204-14-066571:notes:4]
Depreciation and amortization expense on property, plant, and equipment was $202,000 and $217,000 for the three months ended September 30, 2014 and 2013, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-14-066571:notes:5]
[same as prior period, unchanged from 0001157523-14-001989:notes:84]

[0001144204-14-066571:notes:6]
The provision for income taxes represents Federal, foreign, and state and local income taxes. The effective rate differs from statutory rates due to the effect of state and local income taxes, tax rates in foreign jurisdictions, tax benefit of R&D credits and certain nondeductible expenses. Our effective tax rate will change from quarter to quarter based on recurring and non-recurring factors including, but not limited to, the geographical mix of earnings, enacted tax legislation, and state and local income taxes. In addition, changes in judgment from the evaluation of new information resulting in the recognition, de-recognition or re-measurement of a tax position taken in a prior annual period is recognized separately in the quarter of the change.

[0001144204-14-066571:notes:7]
The Company does not expect that our unrecognized tax benefits will significantly change within the next twelve months. We file a consolidated U.S. income tax return and tax returns in certain state and local and foreign jurisdictions. As of September 30, 2014 we remain subject to examination in all tax jurisdictions for all relevant jurisdictional statutes for fiscal years 2008 and thereafter.

[0001144204-14-066571:notes:8]
The Company has identified its U.S. Federal income tax return and its State return in New York as its major tax jurisdictions. As of September 30, 2014 and June 30, 2014 the Company has a long-term accrued income tax liability of $169,000.


## us-gaap:LongTermDebtTextBlock

[0001144204-14-066571:notes:9]
NOTE 6 - Long-Term Debt

[0001144204-14-066571:notes:10]
As of September 30, 2014, long-term debt consisted of a revolving credit facility of $11,000,000 (the “Revolving Credit Facility”) which expires in June 2017 and two term loans, one for $6,000,000 which expires in June 2019, and one for $6,500,000 which expires in June 2017 (the “Term Loans”). Repayment of the Term Loans commenced on September 30, 2012. The $6,000,000 Term Loan is being repaid with 28 equal,  quarterly payments of $75,000 and the remaining balance of $3,900,000 due on or before the expiration date. The $6,500,000 Term Loan is being repaid in 20 equal,  quarterly payments of $325,000.

[0001144204-14-066571:notes:11]
Outstanding balances and interest rates as of September 30, 2014 and June 30, 2014 are as follows:

[0001144204-14-066571:notes:12]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Outstanding |  | Interest Rate |  | Outstanding |  | Interest Rate |  |
| Revolving line of credit |  | $ | 2,500 |  |  | 1.7 | % | $ | 2,500 |  |  | 1.7 | % |
| Term loans |  |  | 8,900 |  |  | 1.7 | % |  | 9,300 |  |  | 1.7 | % |
| Total debt |  | $ | 11,400 |  |  | 1.7 | % | $ | 11,800 |  |  | 1.7 | % |

[0001144204-14-066571:notes:13]
The Revolving Credit Facility and Term Loans (collectively the “Agreement”) also provides for a LIBOR-based interest rate option of LIBOR plus  1.5% to  2.75%, depending on the ratio of outstanding debt to EBITDA, which is to be measured and adjusted quarterly, a prime rate-based option of the  prime rate plus  0.25% and other terms and conditions as more fully described in the Agreement. In addition, the Agreement provides for availability under the Revolving Credit Facility to be limited to the lesser of $11,000,000 or the result of a borrowing base formula based upon the Company’s Accounts Receivables and Inventory values net of certain deductions. The Company’s obligations under the Agreement continue to be secured by all of its assets, including but not limited to, deposit accounts, accounts receivable, inventory, the Company’s corporate headquarters in Amityville, NY, equipment and fixtures and intangible assets. In addition, the Company’s wholly-owned subsidiaries, with the exception of the Company’s foreign subsidiaries, have issued guarantees and pledges of all of their assets to secure the Company’s obligations under the Agreement. All of the outstanding common stock of the Company’s domestic subsidiaries and  65% of the common stock of the Company’s foreign subsidiaries has been pledged to secure the Company’s obligations under the Agreement.

[0001144204-14-066571:notes:14]
The Agreement contains various restrictions and covenants including, among others, restrictions on payment of dividends, restrictions on borrowings and compliance with certain financial ratios, as defined in the Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-14-066571:notes:15]
[same as prior period, unchanged from 0001157523-14-001989:notes:88]

[0001144204-14-066571:notes:16]
The Company follows ASC 718 (“Share-Based Payment”), which requires that all share based payments to employees, including stock options, be recognized as compensation expense in the consolidated financial statements based on their fair values and over the requisite service period.  For the three months ended September 30, 2014 and 2013, the Company recorded non-cash compensation expense of $33,000 ($.00 per basic and diluted share) and $1,000 ($.00 per basic and diluted share), respectively, relating to stock-based compensation.

[0001144204-14-066571:notes:17]
In December 2012, the stockholders approved the 2012 Employee Stock Option Plan (the 2012 Employee Plan). The 2012 Employee Plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  950,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options, which are intended to qualify as incentive stock options (ISOs), to valued employees. Any plan participant who is granted ISOs and possesses more than  10% of the voting rights of the Company's outstanding common stock must be granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-14-066571:notes:18]
Under the 2012 Employee Plan, stock options may be granted to valued employees with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable, in whole or in part, at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2014,  78,500 stock options were granted,  18,700 stock options were exercisable and  871,500 stock options were available for grant under this plan.

[0001144204-14-066571:notes:19]
The following table reflects activity under the 2012 Plan for the three months ended September 30,:

[0001144204-14-066571:notes:20]
|  |  |  | 2014 |  | 2013 |  |
|  |  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 78,500 |  | $ | 5.73 |  |  | — |  | $ | — |  |
| Granted |  |  | — |  |  | — |  |  | 35,000 |  |  | 5.02 |  |
| Terminated/Lapsed |  |  | (10,000) |  |  | 4.88 |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 68,500 |  | $ | 5.86 |  |  | 35,000 |  | $ | 5.02 |  |
| Exercisable, end of period |  |  | 18,700 |  | $ | 5.65 |  |  | 7,000 |  | $ | 5.02 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 3.28 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | — |  |  |  |  | $ | 11,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | — |  |  |  |  | $ | 2,000 |  |  |  |  |

[0001144204-14-066571:notes:21]
The following table summarizes information about stock options outstanding under the 2012 Employee Plan at September 30, 2014:

[0001144204-14-066571:notes:22]
|  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $ 4.88 - $ 6.31 |  | 68,500 |  |  | 9.1 |  | $ | 5.86 |  | 18,700 |  | $ | 5.65 |  |
|  |  | 68,500 |  |  | 9.1 |  | $ | 5.86 |  | 18,700 |  | $ | 5.65 |  |

[0001144204-14-066571:notes:23]
As of September 30, 2014, there was $198,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Employee Plan. $17,000 of compensation expense was recorded during the three months ended September 30, 2014 for stock options granted under the 2012 Employee Plan. There were no options granted during the three months ended September 30, 2014. The total fair value of the options vesting during the three months ended September 30, 2014 and 2013 under this plan was $16,000 and $2,000, respectively.

[0001144204-14-066571:notes:24]
In December 2012, the stockholders approved the 2012 Non-Employee Stock Option Plan (the 2012 Non-Employee Plan). This plan authorizes the granting of awards, the exercise of which would allow up to an aggregate of  50,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may grant stock options to non-employee directors and consultants to the Company and its subsidiaries.

[0001144204-14-066571:notes:25]
Under the 2012 Non-Employee Plan, stock options may be granted with a term of up to 10 years at an exercise price equal to or greater than the fair market value on the date of grant and are exercisable in whole or in part at  20% per year beginning on the date of grant. An option granted under this plan shall vest in full upon a “change in control” as defined in the plan. At September 30, 2014,  25,000 stock options were granted,  10,000 stock options were exercisable and  25,000 stock options were available for grant under this plan.

[0001144204-14-066571:notes:26]
The following table reflects activity under the 2012 Non-Employee Plan for the three months ended September 30,:

[0001144204-14-066571:notes:27]
|  |  | 2014 |  | 2013 |  |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 25,000 |  | $ | 4.88 |  |  | — |  | $ | — |  |
| Granted |  |  | — |  |  | — |  |  | 25,000 |  |  | 4.88 |  |
| Terminated/Lapsed |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Outstanding, end of period |  |  | 25,000 |  | $ | 4.88 |  |  | 25,000 |  | $ | 4.88 |  |
| Exercisable, end of period |  |  | 10,000 |  | $ | 4.88 |  |  | 5,000 |  | $ | 4.88 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  | $ | 3.30 |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | — |  |  |  |  | $ | 11,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | — |  |  |  |  | $ | 2,000 |  |  |  |  |

[0001144204-14-066571:notes:28]
The following table summarizes information about stock options outstanding under the 2012 Non-Employee Plan at September 30, 2014:

[0001144204-14-066571:notes:29]
|  |  |  | Options outstanding |  | Options exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  | Number exercisable |  | Weighted average exercise price |  |
| $ | 4.88 |  | 25,000 |  | 8.9 |  | $ | 4.88 |  | 10,000 |  | $ | 4.88 |  |
|  |  |  | 25,000 |  | 8.9 |  | $ | 4.88 |  | 10,000 |  | $ | 4.88 |  |

[0001144204-14-066571:notes:30]
As of September 30, 2014, there was $50,000 of unearned stock-based compensation cost related to share-based compensation arrangements granted under the 2012 Non-Employee Plan. $16,000 of compensation expense was recorded during the three months ended September 30, 2014 for stock options granted under the 2012 Non-Employee Plan. There were no options granted during the three months ended September 30, 2014. The total fair value of the options vesting during each of the three month periods ended September 30, 2014 and 2013 under this plan was $17,000.

[0001144204-14-066571:notes:31]
In December 2002, the stockholders approved the 2002 Employee Stock Option Plan (the 2002 Employee Plan). This plan expired in October 2012. This plan authorized the granting of awards, the exercise of which would allow up to an aggregate of  1,836,000 shares of the Company's common stock to be acquired by the holders of such awards. Under this plan, the Company may have granted stock options, which were intended to qualify as incentive stock options (ISOs), to key employees. Any plan participant who was granted ISOs and possessed more than 10% of the voting rights of the Company's outstanding common stock must have been granted an option with a price of at least  110% of the fair market value on the date of grant.

[0001144204-14-066571:notes:32]
Under the 2002 Employee Plan, stock options have been granted to key employees with a term of 10 years at an exercise price equal to the fair market value on the date of grant and are exercisable in whole or in part at  20% per year from the date of grant. At September 30, 2014,  1,471,480 stock options had been granted,  264,750 stock options were exercisable and no further stock options were available for grant under this plan after the plans expiration in October 2012.

[0001144204-14-066571:notes:33]
The following table reflects activity under the 2002 Employee plan for the year ended September 30,:

[0001144204-14-066571:notes:34]
|  |  | 2014 |  | 2013 |
|  |  | Options |  | Weighted average exercise price |  | Options |  | Weighted average exercise price |  |
| Outstanding, beginning of year |  |  | 265,750 |  | $ | 6.51 |  |  | 651,140 |  | $ | 4.18 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Terminated/Lapsed |  |  | (1,000) |  |  | 6.02 |  |  | (30,240) |  |  | 1.74 |  |
| Exercised |  |  | — |  |  | — |  |  | (326,800) |  |  | 2.70 |  |
| Outstanding, end of period |  |  | 264,750 |  | $ | 6.51 |  |  | 294,100 |  | $ | 6.07 |  |
| Exercisable, end of period |  |  | 264,750 |  | $ | 6.51 |  |  | 294,100 |  | $ | 6.07 |  |
| Weighted average fair value at grant date of options granted |  |  | n/a |  |  |  |  |  | n/a |  |  |  |  |
| Total intrinsic value of options exercised |  |  | n/a |  |  |  |  | $ | 854,000 |  |  |  |  |
| Total intrinsic value of options outstanding |  | $ | — |  |  |  |  | $ | 101,000 |  |  |  |  |
| Total intrinsic value of options exercisable |  | $ | — |  |  |  |  | $ | 101,000 |  |  |  |  |

[0001144204-14-066571:notes:35]
0 and 326,800 stock options were exercised during the three months ended September 30, 2014 and 2013, respectively. 324,100 of the 326,800 stock options exercised during the three months ended September 30, 2013 were settled by exchanging 164,859 shares of the Company’s common stock of which 85,170 was retired upon receipt. Cash received from option exercises was $0 and $5,000 for the three months ended September 30, 2014 and 2013, respectively, and the actual tax benefit realized for the tax deductions from option exercises was $0 for each of these periods.

[0001144204-14-066571:notes:36]
The following table summarizes information about stock options outstanding under the 2002 Employee Plan at September 30, 2014:

[0001144204-14-066571:notes:37]
|  |  | Options outstanding and exercisable |  |
| Range of exercise prices |  | Number outstanding |  | Weighted average remaining contractual life |  | Weighted average exercise price |  |
| $ 5.22 - $ 6.62 |  | 227,250 |  | 1.6 |  | $ | 5.75 |  |
| $11.16 |  | 37,500 |  | 1.5 |  |  | 11.16 |  |
|  |  | 264,750 |  | 1.6 |  | $ | 6.51 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-14-066571:notes:38]
NOTE 8 – Stockholders’ Equity Transactions

[0001144204-14-066571:notes:39]
On September 16, 2014 the Company’s board of directors authorized the repurchase of up to 1 million of the approximately  19.4 million shares of the Company’s common stock outstanding. The repurchase will be made from time to time in the open market or in privately negotiated transactions subject to market conditions and the market price of the common stock. Relative to the loan Agreement described in Note 6, the Company’s lender gave its consent to this stock repurchase plan. During the three months ended September 30, 2014 the Company repurchased  107,556 shares of its outstanding common stock for a weighted average price of $4.73 per share. These repurchased shares are included in the Company’s Treasury Stock as of September 30, 2014.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-14-066571:notes:40]
[same as prior period, unchanged from 0001157523-14-001989:notes:80]

[0001144204-14-066571:notes:41]
The Company maintains a 401(k) plan (“the Plan”) that covers all U.S. non-union employees with one or more years of service and is qualified under Sections 401(a) and 401(k) of the Internal Revenue Code. Company contributions to this plan are discretionary and totaled $25,000 and $25,000 for the three months ended September 30, 2014 and 2013, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-14-066571:notes:42]
NOTE 10 - Commitments and Contingencies

[0001144204-14-066571:notes:43]
Leases

[0001144204-14-066571:notes:44]
The Company is committed under various operating leases, not including the land lease discussed below, which do not extend beyond fiscal 2016.

[0001144204-14-066571:notes:45]
Rent expense, with the exception of the land lease referred to below, totaled approximately $7,000 and $9,000 for the three months ended September 30, 2014 and 2013, respectively.

[0001144204-14-066571:notes:46]
Land Lease

[0001144204-14-066571:notes:47]
On April 26, 1993, one of the Company's foreign subsidiaries entered into a 99 year lease, expiring in  2092, for approximately four acres of land in the Dominican Republic at an annual cost of $288,000, on which the Company's principal production facility is located.

[0001144204-14-066571:notes:48]
Litigation

[0001144204-14-066571:notes:49]
In the normal course of business, the Company is a party to claims and/or litigation. Management believes that the settlement of such claims and/or litigation, considered in the aggregate, will not have a material adverse effect on the Company's financial position and results of operations.

[0001144204-14-066571:notes:50]
Employment Agreements

[0001144204-14-066571:notes:51]
As of September 30, 2014, the Company was obligated under two employment agreements and one severance agreement. The employment agreements are with the Company’s CEO and Senior Vice President of Sales and Marketing (“the SVP”). The employment agreement with the CEO provides for an annual salary of $587,000, as adjusted for inflation; incentive compensation as may be approved by the Board of Directors from time to time and a termination payment in an amount up to  299% of the average of the prior five calendar year's compensation, subject to certain limitations, as defined in the agreement. The employment agreement renews annually in August unless either party gives the other notice of non-renewal at least six months prior to the end of the applicable term. The employment agreement with the SVP expires in October 2016 and provides for an annual salary of $296,900, a bonus arrangement for fiscal 2015 and, if terminated by the Company without cause, severance of nine months’ salary and continued company-sponsored health insurance for six months from the date of termination. The severance agreement provides for payments equal to nine months of salary and six months of health insurance in the event of a non-voluntary termination of employment without cause.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-14-066571:notes:52]
Cash and Cash Equivalents

[0001144204-14-066571:notes:53]
Cash and cash equivalents include approximately $460,000 of short-term time deposits at September 30, 2014 and June 30, 2014. The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company has cash balances in banks in excess of the maximum amount insured by the FDIC and other international agencies as of September 30, 2014 and June 30, 2014. The Company has historically not experienced any credit losses with balances in excess of FDIC limits


## us-gaap:ReceivablesPolicyTextBlock

[0001144204-14-066571:notes:54]
Accounts Receivable

[0001144204-14-066571:notes:55]
Accounts receivable is stated net of the reserves for doubtful accounts of $165,000 and $180,000 and for returns and other allowances of $840,000 and $1,005,000 as of September 30, 2014 and June 30, 2014, respectively. Our reserves for doubtful accounts and for returns and other allowances are subjective critical estimates that have a direct impact on reported net earnings. These reserves are based upon the evaluation of accounts receivable agings, specific exposures, sales levels and historical trends.


## us-gaap:InventoryPolicyTextBlock

[0001144204-14-066571:notes:56]
[same as prior period, unchanged from 0001157523-14-001989:notes:33]

[0001144204-14-066571:notes:57]
Inventories are valued at the lower of cost or fair market value, with cost being determined on the first-in, first-out (FIFO) method. The reported net value of inventory includes finished saleable products, work-in-process and raw materials that will be sold or used in future periods. Inventory costs include raw materials, direct labor and overhead. The Company’s overhead expenses are applied based, in part, upon estimates of the proportion of those expenses that are related to procuring and storing raw materials as compared to the manufacture and assembly of finished products. These proportions, the method of their application, and the resulting overhead included in ending inventory, are based in part on subjective estimates and actual results could differ from those estimates.

[0001144204-14-066571:notes:58]
In addition, the Company records an inventory obsolescence reserve, which represents any excess of the cost of the inventory over its estimated market value, based on various product sales projections. This reserve is calculated using an estimated obsolescence percentage applied to the inventory based on age, historical trends, requirements to support forecasted sales, and the ability to find alternate applications of its raw materials and to convert finished product into alternate versions of the same product to better match customer demand. In addition, and as necessary, the Company may establish specific reserves for future known or anticipated events. There is inherent professional judgment and subjectivity made by both production and engineering members of management in determining the estimated obsolescence percentage.

[0001144204-14-066571:notes:59]
The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-14-066571:notes:60]
Property, Plant, and Equipment

[0001144204-14-066571:notes:61]
Property, plant, and equipment are carried at cost less accumulated depreciation. Expenditures for maintenance and repairs are charged to expense as incurred; costs of major renewals and improvements are capitalized. At the time property and equipment are retired or otherwise disposed of, the cost and accumulated depreciation are eliminated from the asset and accumulated depreciation accounts and the profit or loss on such disposition is reflected in income.

[0001144204-14-066571:notes:62]
Depreciation is recorded over the estimated service lives of the related assets using primarily the straight-line method. Amortization of leasehold improvements is calculated by using the straight-line method over the estimated useful life of the asset or lease term, whichever is shorter.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001144204-14-066571:notes:63]
Long-Lived Assets

[0001144204-14-066571:notes:64]
Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets in question may not be recoverable. Impairment would be recorded in circumstances where undiscounted cash flows expected to be generated by an asset are less than the carrying value of that asset.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-14-066571:notes:65]
Revenue Recognition

[0001144204-14-066571:notes:66]
The Company recognizes revenue when the following criteria are met: (i) persuasive evidence of an agreement exists, (ii) there is a fixed and determinable price for the Company's product, (iii) shipment and passage of title occurs, and (iv) collectability is reasonably assured. Revenues from product sales are recorded at the time the product is shipped or delivered to the customer pursuant to the terms of the sale. The Company reports its sales on a net sales basis, with net sales being computed by deducting from gross sales the amount of actual sales returns and other allowances and the amount of reserves established for anticipated sales returns and other allowances.


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-14-066571:notes:67]
Income Taxes

[0001144204-14-066571:notes:68]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax expense represents the change during the period in the deferred tax assets and deferred tax liabilities. The components of the deferred tax assets and liabilities are individually classified as current and non-current based on their characteristics. Deferred tax assets are reduced by a valuation allowance when, in the opinion of management, it is more likely than not that some portion or all of the deferred tax assets will not be realized. The Company measures and recognizes the tax implications of positions taken or expected to be taken in its tax returns on an ongoing basis.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-14-066571:notes:69]
Net Income Per Share

[0001144204-14-066571:notes:70]
Basic net income per common share (Basic EPS) is computed by dividing net income by the weighted average number of common shares outstanding. Diluted net income per common share (Diluted EPS) is computed by dividing net income by the weighted average number of common shares and dilutive common share equivalents and convertible securities then outstanding.

[0001144204-14-066571:notes:71]
The following provides a reconciliation of information used in calculating the per share amounts for the three months ended September 30 (in thousands, except per share data):

[0001144204-14-066571:notes:72]
|  |  | Net Income |  | Weighted Average Shares |  | Net Income per Share |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Basic EPS |  | $ | 159 |  | $ | 123 |  |  | 19,412 |  |  | 19,323 |  | $ | 0.01 |  | $ | 0.01 |  |
| Effect of Dilutive Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock Options |  |  | — |  |  | — |  |  | — |  |  | 18 |  |  | — |  |  | — |  |
| Diluted EPS |  | $ | 159 |  | $ | 123 |  |  | 19,412 |  |  | 19,341 |  | $ | 0.01 |  | $ | 0.01 |  |

[0001144204-14-066571:notes:73]
Options to purchase  145,500 and  268,116 shares of common stock for the three months ended September 30, 2014 and 2013, respectively, were not included in the computation of Diluted EPS because their inclusion would be anti-dilutive. These options were still outstanding at the end of the respective periods.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-14-066571:notes:74]
Foreign Currency

[0001144204-14-066571:notes:75]
All assets and liabilities of foreign subsidiaries are translated into U.S. Dollars at fiscal period-end exchange rates. Income and expense items are translated at average exchange rates prevailing during the fiscal year. The realized and unrealized gains and losses associated with foreign currency translation, as well as related other comprehensive income, were not material for the three months ended September 30, 2014 and 2013.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001144204-14-066571:notes:76]
Comprehensive Income

[0001144204-14-066571:notes:77]
For the three months ended September 30, 2014 and 2013, the Company's operations did not give rise to material items includable in comprehensive income, which were not already included in net income. Accordingly, the Company's comprehensive income approximates its net income for all periods presented.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001144204-14-066571:notes:78]
Segment Reporting

[0001144204-14-066571:notes:79]
The Company’s reportable operating segments are determined based on the Company's management approach. The management approach is based on the way that the chief operating decision maker organizes the segments within an enterprise for making operating decisions and assessing performance. The Company's results of operations are reviewed by the chief operating decision maker on a consolidated basis and the Company operates in only one segment. The Company has presented required geographical data in Note 11, and no additional segment data has been presented.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001144204-14-066571:notes:80]
Shipping and Handling Revenues and Costs

[0001144204-14-066571:notes:81]
The Company records the amount billed to customers for shipping and handling in net sales ($127,000 and $131,000 in the three months ended September 30, 2014 and 2013, respectively) and classifies the costs associated with these revenues in cost of sales ($241,000 and $242,000 in the three months ended September 30, 2014 and 2013, respectively).


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001144204-14-066571:notes:82]
Recently Issued Accounting Standards

[0001144204-14-066571:notes:83]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers (Topic 606),” which is the new comprehensive revenue recognition standard that will supersede all existing revenue recognition guidance under U.S. GAAP. The standard’s core principle is that a company will recognize revenue when it transfers promised goods or services to a customer in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services. ASU 2014-09 is effective for annual and interim periods beginning on or after December 15, 2016, and early adoption is not permitted. Entities will have the option of using either a full retrospective approach or a modified approach to adopt the guidance. The Company is currently evaluating the impact of adopting this guidance.

[0001144204-14-066571:notes:84]
In July 2013, the FASB issued authoritative guidance that requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a net operating loss (“NOL”) carry-forward, a similar tax loss, or a tax credit carry-forward.  If either (i) an NOL carry-forward, a similar tax loss, or tax credit carry-forward is not available as of the reporting date under the governing tax law to settle taxes that would result from the disallowance of the tax position or (ii) the entity does not intend to use the deferred tax asset for this purpose (provided that the tax law permits a choice), an entity should present an unrecognized tax benefit in the financial statements as a liability and should not net the unrecognized tax benefit with a deferred tax asset.  This guidance became effective for unrecognized tax benefits that exist as of the Company’s fiscal 2015 first quarter. The guidance did not have an impact on the Company’s consolidated financial statements.


## nssc:ScheduleOfIntangibleAssetsTableTextBlock

[0001144204-14-066571:notes:85]
Changes in intangible assets are as follows (in thousands):

[0001144204-14-066571:notes:86]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
|  |  | Cost |  | Accumulated amortization |  | Net book value |  | Cost |  | Accumulated amortization |  | Net book value |  |
| Customer relationships |  | $ | 9,800 |  | $ | (6,357) |  | $ | 3,443 |  | $ | 9,800 |  | $ | (6,203) |  | $ | 3,597 |  |
| Non-compete agreement |  |  | 340 |  |  | (297) |  |  | 43 |  |  | 340 |  |  | (285) |  |  | 55 |  |
| Trade name |  |  | 5,900 |  |  | — |  |  | 5,900 |  |  | 5,900 |  |  | — |  |  | 5,900 |  |
|  |  | $ | 16,040 |  | $ | (6,654) |  | $ | 9,386 |  | $ | 16,040 |  | $ | (6,488) |  | $ | 9,552 |  |


## nssc:InventoryTableTextBlock

[0001144204-14-066571:notes:87]
Inventories, net of reserves consist of the following (in thousands):

[0001144204-14-066571:notes:88]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
| Component parts |  | $ | 16,129 |  | $ | 15,268 |  |
| Work-in-process |  |  | 3,837 |  |  | 3,632 |  |
| Finished product |  |  | 6,454 |  |  | 6,110 |  |
|  |  | $ | 26,420 |  | $ | 25,010 |  |
| Classification of inventories, net of reserves: |  |  |  |  |  |  |  |
| Current |  | $ | 22,767 |  | $ | 21,443 |  |
| Non-current |  |  | 3,653 |  |  | 3,567 |  |
|  |  | $ | 26,420 |  | $ | 25,010 |  |


## nssc:ScheduleOfRevenueFromExternalCustomersAndIdentifiableAssetsByGeographicalAreasTableTextBlock

[0001144204-14-066571:notes:89]
The following represents selected consolidated geographical data:

[0001144204-14-066571:notes:90]
Financial Information Relating to Domestic and Foreign Operations

[0001144204-14-066571:notes:91]
|  |  | Three months ended September 30, |  |
|  |  | 2014 |  | 2013 |  |
|  |  | (in thousands) |  |
| Sales to external customers(1): |  |  |  |  |  |  |  |
| Domestic |  | $ | 16,572 |  | $ | 16,293 |  |
| Foreign |  |  | 764 |  |  | 946 |  |
| Total Net Sales |  | $ | 17,336 |  | $ | 17,239 |  |

[0001144204-14-066571:notes:92]
|  |  | September 30, 2014 |  | June 30, 2014 |  |
| Identifiable assets: |  |  |  |  |  |  |  |
| United States |  | $ | 47,955 |  | $ | 49,529 |  |
| Dominican Republic (2) |  |  | 14,682 |  |  | 13,835 |  |
| Total Identifiable Assets |  | $ | 62,637 |  | $ | 63,364 |  |

[0001144204-14-066571:notes:93]
(1) All of the Company's sales originate in the United States and are shipped primarily from the Company's facilities in the United States. There were no sales into any one foreign country in excess of 10% of total Net Sales.

[0001144204-14-066571:notes:94]
(2) Consists primarily of inventories (September 30, 2014 = $11,227; June 30, 2014 = $10,216) and fixed assets (September 30, 2014 = $3,397; June 30, 2014 = $3,475) located at the Company's principal manufacturing facility in the Dominican Republic.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001144204-14-066571:notes:95]
NOTE 1 - Nature of Business and Summary of Significant Accounting Policies

[0001144204-14-066571:notes:96]
[same as prior period, unchanged from 0001157523-14-001989:notes:43]

[0001144204-14-066571:notes:97]
Napco Security Technologies, Inc. and Subsidiaries (the "Company") is a diversified manufacturer of security products, encompassing access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. These products are used for commercial, residential, institutional, industrial and governmental applications, and are sold worldwide principally to independent distributors, dealers and installers of security equipment.

[0001144204-14-066571:notes:98]
The Company's fiscal year begins on July 1 and ends on June 30. Historically, the end users of the Company's products want to install its products prior to the summer; therefore sales of its products historically peak in the period April 1 through June 30, the Company's fiscal fourth quarter, and are reduced in the period July 1 through September 30, the Company's fiscal first quarter. In addition, demand is affected by the housing and construction markets.

[0001144204-14-066571:notes:99]
[same as prior period, unchanged from 0001157523-14-001989:notes:46]

[0001144204-14-066571:notes:100]
Basis of Presentation

[0001144204-14-066571:notes:101]
The unaudited condensed consolidated financial statements of the Company, including these notes, have been prepared by the Company in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information and pursuant to the rules and regulations promulgated by the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted or condensed. However, in the opinion of management, all adjustments (consisting of normal recurring accruals) considered necessary for a fair presentation have been included. These unaudited condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the year ended June 30, 2014 and the notes thereto included in the Company’s Annual Report on Form 10-K filed with the SEC on September 15, 2014. Results of consolidated operations for the interim periods are not necessarily indicative of a full year’s operating results. The unaudited condensed consolidated financial statements herein include the accounts of the Company and its wholly owned subsidiaries. All material inter-company accounts and transactions have been eliminated. Certain prior period amounts relating to credit card fees have been reclassified for consistency with the current period presentation. The reclassification did not have an impact on the Balance Sheets, Statement of Cash Flows or reported Net income (loss) for any period.

[0001144204-14-066571:notes:102]
Accounting Estimates

[0001144204-14-066571:notes:103]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent gains and losses at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Critical estimates include management's judgments associated with reserves for sales returns and allowances, concentration of credit risk, inventory reserves, intangible assets and income taxes. Actual results could differ from those estimates.

[0001144204-14-066571:notes:104]
Fair Value of Financial Instruments

[0001144204-14-066571:notes:105]
The methods and assumptions used to estimate the fair value of the following classes of financial instruments were: Current Assets and Current Liabilities: The carrying amount of cash, certificates of deposits, current receivables and payables and certain other short-term financial instruments approximate their fair value as of September 30, 2014 due to their short-term maturities. Long-Term Debt: The carrying amount of the Company’s long-term debt, including the current portion, at September 30, 2014 in the amount of $11,400,000 approximates fair value.

[0001144204-14-066571:notes:106]
Intangible Assets

[0001144204-14-066571:notes:107]
Intangible assets determined to have indefinite lives are not amortized but are tested for impairment at least annually. Intangible assets with definite lives are amortized over their useful lives. Intangible assets are reviewed for impairment at least annually at the Company’s fiscal year end of June 30 or more often whenever there is an indication that the carrying amount may not be recovered.

[0001144204-14-066571:notes:108]
The Company’s acquisition of substantially all of the assets and certain liabilities of G. Marks Hardware, Inc. (“Marks”) in August 2008 included intangible assets recorded at fair value on the date of acquisition. The intangible assets are amortized over their estimated useful lives of  twenty years (customer relationships) and seven years (non-compete agreement). The Marks trade name was deemed to have an indefinite life.

[0001144204-14-066571:notes:109]
Amortization expense for intangible assets subject to amortization was approximately $166,000 and $195,000 for the three months ended September 30, 2014 and 2013, respectively. Amortization expense for each of the next five fiscal years is estimated to be as follows: 2015 - $667,000; 2016 - $529,000; 2017 - $441,000; 2018 - $371,000 and 2019 - $313,000. The weighted average amortization period for intangible assets was  13.7 years and  14.6 years at September 30, 2014 and 2013, respectively.

[0001144204-14-066571:notes:110]
Sales Returns and Other Allowances

[0001144204-14-066571:notes:111]
The Company analyzes sales returns and is able to make reasonable and reliable estimates of product returns based on the Company’s past history. Estimates for sales returns are based on several factors including actual returns and based on expected return data communicated to it by its customers. Accordingly, the Company believes that its historical returns analysis is an accurate basis for its allowance for sales returns. Actual results could differ from those estimates. As a percentage of gross sales, sales returns, rebates and allowances were  8% and 7% for the three months ended September 30, 2014 and 2013, respectively.

[0001144204-14-066571:notes:112]
Advertising and Promotional Costs

[0001144204-14-066571:notes:113]
Advertising and promotional costs are included in "Selling, General and Administrative" expenses in the consolidated statements of operations and are expensed as incurred. Advertising expense for the three months ended September 30, 2014 and 2013 was $544,000 and $365,000, respectively. The increase in Advertising and promotional costs was due primarily to increased expenditures on media advertising as compared to the same period a year ago.

[0001144204-14-066571:notes:114]
Research and Development Costs

[0001144204-14-066571:notes:115]
Research and development costs incurred by the Company are charged to expense as incurred and are included in "Cost of Sales" in the consolidated statements of operations. Company-sponsored research and development expense for the three months ended September 30, 2014 and 2013 was $1,307,000 and $1,286,000, respectively.

[0001144204-14-066571:notes:116]
Stock-Based Compensation

[0001144204-14-066571:notes:117]
The Company has established two share incentive programs as discussed in Note 7.

[0001144204-14-066571:notes:118]
Stock-based compensation cost is measured at the grant date based on the fair value of the award and is recognized as expense on a straight-line basis over the vesting period. Determining the fair value of share-based awards at the grant date requires assumptions and judgments about expected volatility and forfeiture rates, among other factors.

[0001144204-14-066571:notes:119]
Stock-based compensation costs of $33,000 and $1,000 were recognized for three months ended September 30, 2014 and 2013, respectively. The effect on both Basic and Diluted Earnings per share was $0.00 for the three months ended September 30, 2014 and 2013.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001144204-14-066571:notes:120]
[same as prior period, unchanged from 0001157523-14-001989:notes:15]

[0001144204-14-066571:notes:121]
The Company had one customer with accounts receivable balance that comprised  13% of the Company’s accounts receivable at September 30, 2014 and  12% at June 30, 2014. Sales to any one customer did not exceed 10% of net sales in any of the past two fiscal years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-14-066571:notes:122]
[same as prior period, unchanged from 0001157523-14-001989:notes:19]

[0001144204-14-066571:notes:123]
Inventories, net of reserves are valued at lower of cost (first-in, first-out method) or market. The Company regularly reviews parts and finished goods inventories on hand and, when necessary, records a provision for excess or obsolete inventories. The Company also regularly reviews the period over which its inventories will be converted to sales. Any inventories expected to convert to sales beyond 12 months from the balance sheet date are classified as non-current.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-14-066571:notes:124]
NOTE 11 - Geographical Data

[0001144204-14-066571:notes:125]
The Company is engaged in one major line of business: the development, manufacture, and distribution of access control systems, door security products, intrusion and fire alarm systems and video surveillance products for commercial and residential use. Sales to unaffiliated customers are primarily shipped from the United States. The Company has customers worldwide with major concentrations in North America and Europe.
