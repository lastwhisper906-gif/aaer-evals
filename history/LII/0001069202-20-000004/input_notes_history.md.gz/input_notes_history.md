# LII note change history — 0001069202-19-000030 → 0001069202-19-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-10-21):
[0001069202-19-000036:note_history:1]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated

- changed (2019-10-21):
[0001069202-19-000036:note_history:2]
Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.
  (was, 2019-07-22, similarity 0.8285):
[0001069202-19-000030:note_history:2]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

- changed (2019-10-21):
[0001069202-19-000036:note_history:3]
|  | For the Three Months Ended September 30, 2019 |  | For the Nine Months Ended September 30, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 1.9 |  |  | $ | 5.2 |  |
| Interest on lease liabilities | 0.2 |  |  | 0.5 |  |
| Operating lease cost | 14.7 |  |  | 44.0 |  |
| Short-term lease cost | 1.1 |  |  | 3.4 |  |
| Variable lease cost | 5.0 |  |  | 15.1 |  |
| Total lease cost | $ | 22.9 |  |  | $ | 68.2 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 15.0 |  |  | $ | 42.4 |  |
| Financing cash flows from finance leases | $ | 2.0 |  |  | $ | 5.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 2.5 |  |  | $ | 8.5 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 10.3 |  |  | $ | 31.9 |  |
  (was, 2019-07-22, similarity 0.9597):
[0001069202-19-000030:note_history:3]
|  | For the Three Months Ended June 30, 2019 |  | For the Six Months Ended June 30, 2019 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 1.8 |  |  | $ | 3.3 |  |
| Interest on lease liabilities | 0.2 |  |  | 0.3 |  |
| Operating lease cost | 14.9 |  |  | 29.3 |  |
| Short-term lease cost | 1.2 |  |  | 2.3 |  |
| Variable lease cost | 5.2 |  |  | 10.1 |  |
| Total lease cost | $ | 23.3 |  |  | $ | 45.3 |  |
| Other information |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 14.7 |  |  | $ | 27.4 |  |
| Financing cash flows from finance leases | $ | 2.3 |  |  | $ | 3.8 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 2.8 |  |  | $ | 6.0 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 5.0 |  |  | $ | 21.6 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:4]
|  | As of September 30, 2019 |
| Finance lease right-of-use assets | $ | 24.4 |  |
| Operating lease right-of-use assets | $ | 172.9 |  |
| Finance lease liability, current | $ | 6.9 |  |
| Finance lease liability, non-current | $ | 23.7 |  |
| Operating lease liability, current | $ | 51.6 |  |
| Operating lease liability, non-current | $ | 123.0 |  |
| Weighted-average remaining lease term - finance leases | 5.2 years |  |
| Weighted-average remaining lease term - operating leases | 4.2 years |  |
| Weighted-average discount rate - finance leases | 2.10 | % |
| Weighted-average discount rate – operating leases | 3.81 | % |
  (was, 2019-07-22, similarity 0.8616):
[0001069202-19-000030:note_history:4]
|  | As of June 30, 2019 |
| Finance lease right-of-use assets | 23.9 |  |
| Operating lease right-of-use assets | 166.2 |  |
| Finance lease liability, current | 6.6 |  |
| Finance lease liability, non-current | 23.4 |  |
| Operating lease liability, current | 49.6 |  |
| Operating lease liability, non-current | 117.6 |  |
| Weighted-average remaining lease term - finance leases | 5.31 years |  |
| Weighted-average remaining lease term - operating leases | 4.25 years |  |
| Weighted-average discount rate - finance leases | 2.18 | % |
| Weighted-average discount rate – operating leases | 3.97 | % |

- changed (2019-10-21):
[0001069202-19-000036:note_history:5]
Future annual minimum lease payments and finance lease commitments as of September 30, 2019 were as follows (in millions):
  (was, 2019-07-22, similarity 0.952):
[0001069202-19-000030:note_history:5]
Future annual minimum lease payments and finance lease commitments as of June 30, 2019 were as follows (in millions):

- changed (2019-10-21):
[0001069202-19-000036:note_history:6]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the nine months ended September 30, 2019) | $ | 14.9 |  |  | $ | 2.0 |  |
| 2020 | 55.3 |  |  | 7.1 |  |
| 2021 | 42.9 |  |  | 5.5 |  |
| 2022 | 30.3 |  |  | 3.6 |  |
| 2023 | 23.3 |  |  | 1.6 |  |
| 2024 and thereafter | 22.5 |  |  | 11.9 |  |
| Total minimum lease payments | $ | 189.2 |  |  | $ | 31.7 |  |
| Less imputed interest | (14.6 | ) |  | (1.1 | ) |
| Lease liability | $ | 174.6 |  |  | $ | 30.6 |  |
  (was, 2019-07-22, similarity 0.9731):
[0001069202-19-000030:note_history:6]
|  | Operating Leases |  | Finance Leases |
| 2019 (excluding the six months ended June 30, 2019) | $ | 28.5 |  |  | $ | 3.7 |  |
| 2020 | 50.9 |  |  | 6.5 |  |
| 2021 | 37.8 |  |  | 4.9 |  |
| 2022 | 25.8 |  |  | 3.1 |  |
| 2023 | 19.7 |  |  | 1.2 |  |
| 2024 and thereafter | 19.2 |  |  | 11.7 |  |
| Total minimum lease payments | $ | 181.9 |  |  | $ | 31.1 |  |
| Less imputed interest | (14.7 | ) |  | (1.1 | ) |
| Lease liability | $ | 167.2 |  |  | $ | 30.0 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:7]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of September 30, 2019.
  (was, 2019-07-22, similarity 0.9868):
[0001069202-19-000030:note_history:7]
Our obligations under the headquarters lease are secured by a pledge of our interest in the leased property.  The lease contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of June 30, 2019.

- changed (2019-10-21):
[0001069202-19-000036:note_history:8]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 38.2 |  |  | $ | 37.9 |  |
| Other liabilities | 75.8 |  |  | 73.7 |  |
| Total warranty liability | $ | 114.0 |  |  | $ | 111.6 |  |
  (was, 2019-07-22, similarity 0.9687):
[0001069202-19-000030:note_history:8]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Accrued expenses | $ | 37.6 |  |  | $ | 37.9 |  |
| Other liabilities | 76.3 |  |  | 73.7 |  |
| Total warranty liability | $ | 113.9 |  |  | $ | 111.6 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:9]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2019 were as follows (in millions):
  (was, 2019-07-22, similarity 0.9444):
[0001069202-19-000030:note_history:9]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2019 were as follows (in millions):

- changed (2019-10-21):
[0001069202-19-000036:note_history:10]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (28.2 | ) |
| Changes resulting from issuance of new warranties | 36.0 |  |
| Changes in estimates associated with pre-existing liabilities | (4.8 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Warranty liability from divestitures | (0.4 | ) |
| Total warranty liability as of September 30, 2019 | $ | 114.0 |  |
  (was, 2019-07-22, similarity 0.785):
[0001069202-19-000030:note_history:10]
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Warranty claims paid | (15.3 | ) |
| Changes resulting from issuance of new warranties | 22.2 |  |
| Changes in estimates associated with pre-existing liabilities | (4.1 | ) |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Warranty liability from divestitures | (0.6 | ) |
| Total warranty liability as of June 30, 2019 | $ | 113.9 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:11]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded insignificant expenses associated with this product quality in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024.  Reimbursements we receive from the vendor will offset the costs we have incurred related to this product quality matter.
  (was, 2019-07-22, similarity 0.9528):
[0001069202-19-000030:note_history:11]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded expenses associated with this product quality in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements will include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024. The total reimbursements we receive from the vendor should off set the cost we have incurred related to this product quality matter.

- changed (2019-10-21):
[0001069202-19-000036:note_history:12]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and
  (was, 2019-07-22, similarity 0.996):
[0001069202-19-000030:note_history:12]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and

- added (2019-10-21):
[0001069202-19-000036:note_history:13]
judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

- added (2019-10-21):
[0001069202-19-000036:note_history:14]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Expense for asbestos-related litigation | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 3.3 |  |  | $ | 3.3 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:15]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in (Gain) loss from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.
  (was, 2019-07-22, similarity 0.9634):
[0001069202-19-000030:note_history:15]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred and Insurance proceeds for lost profits in the Consolidated Statements of Operations.

- added (2019-10-21):
[0001069202-19-000036:note_history:16]
| (Amounts in millions) | For the Three months Ended September 30, |  | For the Nine months Ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Insurance recoveries received | $ | 10.0 |  |  | $ | 45.0 |  |  | $ | 138.0 |  |  | $ | 45.0 |  |
| Insurance recoveries receivable | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| Less losses and expenses incurred: |  |  |  |  |  |  |  |
| Site clean-up and remediation | (3.5 | ) |  | 28.4 |  |  | 19.8 |  |  | 28.4 |  |
| Factory inefficiencies due to lower productivity | 0.8 |  |  | 4.9 |  |  | 9.3 |  |  | 4.9 |  |
| Write-off of property, plant and equipment | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Write-off of inventory | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |
| Other | 5.6 |  |  | 6.7 |  |  | 23.5 |  |  | 6.7 |  |
| Total losses and expenses | $ | 2.9 |  |  | $ | 49.4 |  |  | $ | 52.6 |  |  | $ | 49.4 |  |
| Total gain (loss) from insurance recoveries | $ | 7.1 |  |  | $ | (0.3 | ) |  | $ | 85.4 |  |  | $ | (0.3 | ) |
| Components of (Gain) loss from insurance recoveries, net of losses incurred: |  |  |  |  |  |  |  |
| Insurance proceeds for lost profits | (8.3 | ) |  | 0.3 |  |  | (73.8 | ) |  | 0.3 |  |
| (Gain) loss from insurance recoveries, net of losses incurred | 1.2 |  |  | — |  |  | (11.6 | ) |  | — |  |

- removed (2019-10-21):
[0001069202-19-000030:note_history:17]
judgments. For the three months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $0.4 million and $(0.2) million and for the six months ended June 30, 2019 and 2018, expense for asbestos-related litigation was $1.8 million and $1.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

- removed (2019-10-21):
[0001069202-19-000030:note_history:18]
| (Amounts in millions) | For the Three months Ended June 30, 2019 |  | For the Six months Ended June 30, 2019 |
| Insurance recoveries received | $ | 52.0 |  |  | $ | 128.0 |  |
| Less losses and expenses incurred: |  |  |  |
| Site clean-up and remediation | 6.2 |  |  | 23.3 |  |
| Factory inefficiencies due to lower productivity | 4.5 |  |  | 8.0 |  |
| Other | 9.4 |  |  | 18.4 |  |
| Total losses and expenses | $ | 20.1 |  |  | $ | 49.7 |  |
| Total gain from insurance recoveries | $ | 31.9 |  |  | $ | 78.3 |  |
| Presentation in the Consolidated Statements of Operations: |  |  |  |
| Insurance proceeds for lost profits | (26.0 | ) |  | (65.5 | ) |
| Gain from insurance recoveries, net of losses incurred | (5.9 | ) |  | (12.8 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-21):
[0001069202-19-000036:note_history:19]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2019, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three and nine months ended September 30, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2019-07-22, similarity 0.9385):
[0001069202-19-000030:note_history:19]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2019, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2019 and 2018, the accompanying unaudited Consolidated Statements of Stockholders' (Deficit) Equity for the three and six months ended June 30, 2019 and 2018, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2019 and 2018 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2018. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2019-10-21):
[0001069202-19-000036:note_history:20]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.
  (was, 2019-07-22, similarity 0.9743):
[0001069202-19-000030:note_history:20]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

- changed (2019-10-21):
[0001069202-19-000036:note_history:21]
We adopted other new accounting standards during the first quarter of 2019 and their impacts are discussed in their respective Notes to the Consolidated Financial Statements.
  (was, 2019-07-22, similarity 0.9041):
[0001069202-19-000030:note_history:21]
We adopted other new accounting standards during the first quarter of 2019. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.

- added (2019-10-21):
[0001069202-19-000036:note_history:22]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable

- added (2019-10-21):
[0001069202-19-000036:note_history:23]
information to estimate credit losses. ASU 2016-13 is effective for SEC filers for interim and annual periods beginning after December 15, 2019.  We are currently assessing the impact ASU 2016-13, but do not expect it to have a material impact on our financial statements.

- removed (2019-10-21):
[0001069202-19-000030:note_history:24]
Reclassifications

- removed (2019-10-21):
[0001069202-19-000030:note_history:25]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-21):
[0001069202-19-000036:note_history:26]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.31 | % |  | 3.74 | % |
  (was, 2019-07-22, similarity 0.9447):
[0001069202-19-000030:note_history:26]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.63 | % |  | 3.74 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-21):
[0001069202-19-000036:note_history:27]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 365.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | 6.9 |  |  | 3.5 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 394.3 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.7 |  |  | 15.7 |  |
| Domestic credit facility | 685.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.4 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,056.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,451.1 |  |  | $ | 1,041.3 |  |
  (was, 2019-07-22, similarity 0.9756):
[0001069202-19-000030:note_history:27]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.6 |  |  | $ | 3.5 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.4 |  |  | 15.7 |  |
| Domestic credit facility | 785.0 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.6 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,155.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,466.8 |  |  | $ | 1,041.3 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:28]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2019 or December 31, 2018.  There were $5.3 million in proceeds and repayments on these facilities for the nine months ended September 30, 2019.  Proceeds and repayments on these facilities were $39.6 million and $41.1 million, respectively, for the nine months ended September 30, 2018.
  (was, 2019-07-22, similarity 0.7404):
[0001069202-19-000030:note_history:28]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2019 or December 31, 2018.  There were no significant proceeds or repayments on these facilities for the six months ended June 30, 2019.  Proceeds and repayments on these facilities were $21.3 million and $18.4 million, respectively, for the six months ended June 30, 2018.

- added (2019-10-21):
[0001069202-19-000036:note_history:29]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 380.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (365.5 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 14.5 |  |  | $ | 22.0 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:30]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2019 and December 31, 2018 were 2.79% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2019-07-22, similarity 0.9913):
[0001069202-19-000030:note_history:30]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2019 and December 31, 2018 were 3.11% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2019-10-21):
[0001069202-19-000036:note_history:31]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-07-22, similarity 0.9357):
[0001069202-19-000030:note_history:31]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.

- changed (2019-10-21):
[0001069202-19-000036:note_history:32]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $708.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of September 30, 2019. Subject to covenant limitations, $449.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.
  (was, 2019-07-22, similarity 0.9766):
[0001069202-19-000030:note_history:32]
On January 22, 2019, we amended our credit facility with the Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $190.0 million unsecured term loan that matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $800.0 million, of which $160.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of June 30, 2019. Subject to covenant limitations, $357.5 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

- changed (2019-10-21):
[0001069202-19-000036:note_history:33]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.31 | % |  | 3.74 | % |
  (was, 2019-07-22, similarity 0.9447):
[0001069202-19-000030:note_history:33]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Weighted average borrowing rate | 3.63 | % |  | 3.74 | % |

- changed (2019-10-21):
[0001069202-19-000036:note_history:34]
and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-07-22, similarity 0.9642):
[0001069202-19-000030:note_history:34]
and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2019, we believe we were in compliance with all covenant requirements.

- changed (2019-10-21):
[0001069202-19-000036:note_history:35]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2019, we believe we were in compliance with all covenant requirements.
  (was, 2019-07-22, similarity 0.9449):
[0001069202-19-000030:note_history:35]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2019, we believe we were in compliance with all covenant requirements.

- removed (2019-10-21):
[0001069202-19-000030:note_history:36]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (268.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 22.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-21):
[0001069202-19-000036:note_history:37]
|  | As of September 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 365.5 |  |  | $ | 268.0 |  |
| Finance lease obligations | 6.9 |  |  | 3.5 |  |
| Domestic credit facility | 22.5 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 394.3 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.7 |  |  | 15.7 |  |
| Domestic credit facility | 685.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.4 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,056.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,451.1 |  |  | $ | 1,041.3 |  |
  (was, 2019-07-22, similarity 0.9756):
[0001069202-19-000030:note_history:37]
|  | As of June 30, 2019 |  | As of December 31, 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | $ | 6.6 |  |  | $ | 3.5 |  |
| Domestic credit facility | 15.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 311.0 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 23.4 |  |  | 15.7 |  |
| Domestic credit facility | 785.0 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.6 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 1,155.8 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,466.8 |  |  | $ | 1,041.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-21):
[0001069202-19-000036:note_history:38]
|  | For the Three Months Ended September 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 597.3 |  |  | $ | 227.0 |  |  | $ | 82.5 |  |  | $ | 906.8 |  |
| Canada | 40.3 |  |  | 26.0 |  |  | — |  |  | 66.3 |  |
| International | — |  |  | 0.3 |  |  | 59.5 |  |  | 59.8 |  |
| Total | $ | 637.6 |  |  | $ | 253.3 |  |  | $ | 142.0 |  |  | $ | 1,032.9 |  |
  (was, 2019-07-22, similarity 0.853):
[0001069202-19-000030:note_history:38]
|  | For the Three Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 647.2 |  |  | $ | 239.1 |  |  | $ | 80.0 |  |  | $ | 966.3 |  |
| Canada | 41.9 |  |  | 21.9 |  |  | — |  |  | 63.8 |  |
| International | — |  |  | 0.3 |  |  | 68.7 |  |  | 69.0 |  |
| Total | $ | 689.1 |  |  | 261.3 |  |  | 148.7 |  |  | 1,099.1 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:39]
|  | For the Three Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 553.8 |  |  | $ | 212.4 |  |  | $ | 114.0 |  |  | $ | 880.2 |  |
| Canada | 40.9 |  |  | 24.3 |  |  | 2.1 |  |  | 67.3 |  |
| International | — |  |  | 0.2 |  |  | 82.5 |  |  | 82.7 |  |
| Total | $ | 594.7 |  |  | $ | 236.9 |  |  | $ | 198.6 |  |  | $ | 1,030.2 |  |
  (was, 2019-07-22, similarity 0.853):
[0001069202-19-000030:note_history:39]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 663.6 |  |  | $ | 229.8 |  |  | $ | 112.7 |  |  | $ | 1,006.1 |  |
| Canada | 52.4 |  |  | 21.6 |  |  | 1.1 |  |  | 75.1 |  |
| International | — |  |  | 0.7 |  |  | 93.5 |  |  | 94.2 |  |
| Total | $ | 716.0 |  |  | 252.1 |  |  | 207.3 |  |  | 1,175.4 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:40]
|  | For the Nine Months Ended September 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,677.6 |  |  | $ | 623.3 |  |  | $ | 254.1 |  |  | $ | 2,555.0 |  |
| Canada | 114.6 |  |  | 63.8 |  |  | 0.7 |  |  | 179.1 |  |
| International | — |  |  | 0.8 |  |  | 187.3 |  |  | 188.1 |  |
| Total | $ | 1,792.2 |  |  | $ | 687.9 |  |  | $ | 442.1 |  |  | $ | 2,922.2 |  |
  (was, 2019-07-22, similarity 0.8059):
[0001069202-19-000030:note_history:40]
|  | For the Six Months Ended June 30, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,080.3 |  |  | $ | 396.4 |  |  | $ | 171.6 |  |  | $ | 1,648.3 |  |
| Canada | 74.3 |  |  | 37.8 |  |  | 0.7 |  |  | 112.8 |  |
| International | — |  |  | 0.5 |  |  | 127.8 |  |  | 128.3 |  |
| Total | $ | 1,154.6 |  |  | 434.7 |  |  | 300.1 |  |  | 1,889.4 |  |

- changed (2019-10-21):
[0001069202-19-000036:note_history:41]
|  | For the Nine Months Ended September 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,640.9 |  |  | $ | 604.5 |  |  | $ | 322.4 |  |  | $ | 2,567.8 |  |
| Canada | 123.5 |  |  | 62.7 |  |  | 4.1 |  |  | 190.3 |  |
| International | — |  |  | 0.9 |  |  | 281.4 |  |  | 282.3 |  |
| Total | $ | 1,764.4 |  |  | $ | 668.1 |  |  | $ | 607.9 |  |  | $ | 3,040.4 |  |
  (was, 2019-07-22, similarity 0.8059):
[0001069202-19-000030:note_history:41]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,087.1 |  |  | $ | 392.1 |  |  | $ | 208.4 |  |  | $ | 1,687.6 |  |
| Canada | 82.6 |  |  | 38.3 |  |  | 2.0 |  |  | 122.9 |  |
| International | — |  |  | 0.8 |  |  | 198.9 |  |  | 199.7 |  |
| Total | $ | 1,169.7 |  |  | 431.2 |  |  | 409.3 |  |  | 2,010.2 |  |

- added (2019-10-21):
[0001069202-19-000036:note_history:42]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2019 and 2018, direct sales represented 74% and 77% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2019 and 2018, direct sales represented 74% and 76% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2019-10-21):
[0001069202-19-000036:note_history:43]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the three months ended September 30, 2019 and 2018, equipment sales represented 86% and 86% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2019 and 2018, equipment sales represented 86% and 86% of revenues and the remainder was generated from our service business.
  (was, 2019-07-22, similarity 0.7635):
[0001069202-19-000030:note_history:43]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.    For the segment, for the three months ended June 30, 2019 and 2018, equipment sales represent approximately $226.6 million and $218.7 million of revenues while $34.7 million and $33.4 million of our revenue is generated from our service business, respectively. For the six months ended June 30, 2019 and 2018, equipment sales represent approximately $370.2 million and $370.2 million of revenues while $64.5 million and $61.0 million of our revenue is generated from our service business, respectively.

- changed (2019-10-21):
[0001069202-19-000036:note_history:44]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.
  (was, 2019-07-22, similarity 0.6114):
[0001069202-19-000030:note_history:44]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems.  Revenue for the products sold is $148.2 million and $205.5 million for the three months ended June 30, 2019 and 2018 and $297.1 million and $405.5 million for the six months ended June 30, 2019 and 2018, respectively and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- changed (2019-10-21):
[0001069202-19-000036:note_history:45]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheets.
  (was, 2019-07-22, similarity 0.999):
[0001069202-19-000030:note_history:45]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets, net in our Consolidated Balance Sheet.

- changed (2019-10-21):
[0001069202-19-000036:note_history:46]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheets.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.
  (was, 2019-07-22, similarity 0.9984):
[0001069202-19-000030:note_history:46]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

- added (2019-10-21):
[0001069202-19-000036:note_history:47]
|  | September 30, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | $ | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (8.4 | ) |  | (13.0 | ) |  | 4.6 |  |  | (35.4 | )% |
| Contract liabilities - noncurrent | (5.9 | ) |  | (5.9 | ) |  | — |  |  | — | % |
| Total | $ | (14.3 | ) |  | $ | (16.4 | ) |  | $ | 2.1 |  |  |  |

- added (2019-10-21):
[0001069202-19-000036:note_history:48]
For the three months ended September 30, 2019 and 2018, we recognized revenue of $0.2 million and $1.3 million and for the nine months ended September 30, 2019 and 2018, we recognized revenue of $2.8 million and $4.2 million related to our contract

- added (2019-10-21):
[0001069202-19-000036:note_history:49]
liabilities at January 1, 2019 and  2018, respectively.  Impairment losses recognized in our receivables and contract assets were de minimis in 2018 and 2019.

- removed (2019-10-21):
[0001069202-19-000030:note_history:50]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the segment, for the three months ended June 30, 2019 and 2018, direct sales represent approximately $515.2 million and $546.7 million of revenues, and sales to independent distributors represent approximately $173.9 million and $169.3 million of revenues, respectively. For the six months ended June 30, 2019 and 2018, direct sales represent approximately $849.8 million and $886.3 million of revenues, and sales to independent distributors represent approximately $304.8 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- removed (2019-10-21):
[0001069202-19-000030:note_history:51]
|  | June 30, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (4.9 | ) |  | (13.0 | ) |  | 8.1 |  |  | (62.2 | )% |
| Contract liabilities - noncurrent | (6.0 | ) |  | (5.9 | ) |  | (0.1 | ) |  | 1.7 | % |
| Total | $ | (10.9 | ) |  | $ | (16.4 | ) |  | $ | 5.5 |  |  |  |

- removed (2019-10-21):
[0001069202-19-000030:note_history:52]
For the three months ended June 30, 2019 and 2018, we recognized revenue of $1.5 million and $1.3 million and for the six months ended June 30, 2019 and 2018, we recognized revenue of $2.6 million and $2.9 million related to our contract liabilities at January 1, 2019 and  2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2019 and 2018.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-10-21):
[0001069202-19-000036:note_history:53]
On October 15, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $75.0 million of our pension plan assets and $77.9 million of related benefit obligations.  This transaction requires a remeasurement of the pension plan and we expect to recognize a $38.5 million non-cash pension settlement pre-tax loss in the fourth quarter of 2019 for this remeasurement.

- removed (2019-10-21):
[0001069202-19-000030:note_history:54]
In July 2019, we repurchased 0.5 million shares of our common stock for $150.0 million under the Share Repurchase Plans through transactions pursuant to a Rule 10b5-1 trading plan.
