# LII MD&A — 0001069202-20-000004


## mdna

[0001069202-20-000004:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-20-000004:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001069202-20-000004:mdna:3]
Business Overview

[0001069202-20-000004:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-20-000004:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-20-000004:mdna:7]
Marshalltown Tornado

[0001069202-20-000004:mdna:8]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covered the repair or replacement of our assets that suffered damage or loss and, in 2018 and 2019, we worked closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provided business interruption coverage, including lost profits, and reimbursement for other expenses and costs that were incurred relating to the damages and losses suffered.

[0001069202-20-000004:mdna:9]
For the year ended December 31, 2019, we incurred expenses of $64 million related to damages caused by the tornado, which included site clean-up and demolition, factory inefficiencies, freight to move product to other warehouses, professional fees, and sales and marketing promotional costs.

[0001069202-20-000004:mdna:10]
In December 2019, we reached a final settlement with our insurance carriers for the losses we suffered from the tornado.  The settlement allowed for total cumulative insurance recoveries of $367.5 million, of which $243 million was received for the year ended December 31, 2019.   We allocated the first $64 million of insurance recoveries received in 2019 to cover our expenses, we allocated $80 million for capital expenditures related to rebuilding costs, and the remaining $99 million of insurance recoveries represents amounts for lost profits. These amounts are included in Gain from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations. See Note 5 in the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000004:mdna:11]
Financial Highlights

[0001069202-20-000004:mdna:12]
| • | Net sales decreased $77 million, or 2.0%, to $3,807 million in 2019 from $3,884 million in 2018. Sales growth in our Residential Heating & Cooling and Commercial Heating & Cooling segments was offset by a sales decline in our Refrigeration segment due to the sale of our Australia, Asia, and South America businesses in 2018, and the sale of our Kysor Warren business in the first quarter of 2019. |

[0001069202-20-000004:mdna:13]
| • | Operating income in 2019 was $657 million compared to $510 million in 2018. The increase was primarily due to increased sales in our Residential Heating & Cooling and Commercial Heating & Cooling segments, sourcing and engineering-led cost reductions, and a larger gain from insurance proceeds received related to the Marshalltown tornado. |

[0001069202-20-000004:mdna:14]
| • | Net income in 2019 increased to $409 million from $359 million in 2018. |

[0001069202-20-000004:mdna:15]
| • | Diluted earnings per share from continuing operations were $10.38 per share in 2019 compared to $8.77 per share in 2018. |

[0001069202-20-000004:mdna:16]
| • | We generated $396 million of cash flow from operating activities in 2019 compared to $496 million in 2018. The decrease was primarily due to an increase in working capital. |

[0001069202-20-000004:mdna:17]
| • | In 2019, we returned $111 million to shareholders through dividend payments and we used $400 million to purchase 1.5 million shares of stock under our Share Repurchase Plans. We also received $44 million in net proceeds from the sale of our Kysor Warren business. |

[0001069202-20-000004:mdna:18]
Overview of Results

[0001069202-20-000004:mdna:19]
Despite the impact of the tornado at our Marshalltown facility, the Residential Heating & Cooling segment performed well in 2019, with a 3% increase in net sales and a $65 million increase in segment profit compared to 2018, including the insurance proceeds received for lost profits in 2019.  Our Commercial Heating & Cooling segment also performed well in 2019 with a 5% increase in net sales and an $8 million increase in segment profit compared to 2018.  This segment’s results were driven by higher volumes and price and mix gains.  Sales in our Refrigeration segment decreased 25% and segment profit decreased $7 million compared to 2018 mostly due to the sale of our Australia, Asia, South America, and Kysor Warren businesses.

[0001069202-20-000004:mdna:20]
On a consolidated basis, our gross profit margins decreased to 28.4% in 2019 due primarily to unfavorable commodities, factory inefficiencies, and higher freight and distribution costs. These declines were partially offset by favorable price and mix, sourcing and engineering-led cost reductions across our business, and the divestiture of our Kysor Warren business which had lower margins.

[0001069202-20-000004:mdna:21]
Results of Operations

[0001069202-20-000004:mdna:22]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-20-000004:mdna:23]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,807.2 |  |  | 100.0 | % |  | $ | 3,883.9 |  |  | 100.0 | % |  | $ | 3,839.6 |  |  | 100.0 | % |
| Cost of goods sold | 2,727.4 |  |  | 71.6 | % |  | 2,772.7 |  |  | 71.4 | % |  | 2,714.4 |  |  | 70.7 | % |
| Gross profit | 1,079.8 |  |  | 28.4 | % |  | 1,111.2 |  |  | 28.6 | % |  | 1,125.2 |  |  | 29.3 | % |
| Selling, general and administrative expenses | 585.9 |  |  | 15.4 | % |  | 608.2 |  |  | 15.7 | % |  | 637.7 |  |  | 16.6 | % |
| Losses (gains) and other expenses, net | 8.3 |  |  | 0.2 | % |  | 13.4 |  |  | 0.3 | % |  | 7.1 |  |  | 0.2 | % |
| Restructuring charges | 10.3 |  |  | 0.3 | % |  | 3.0 |  |  | 0.1 | % |  | 3.2 |  |  | 0.1 | % |
| Loss (gain), net on sale of businesses and related property | 10.6 |  |  | 0.3 | % |  | 27.0 |  |  | 0.7 | % |  | 1.1 |  |  | — | % |
| Gain from insurance recoveries, net of losses incurred | (178.8 | ) |  | (4.7 | )% |  | (38.3 | ) |  | (1.0 | )% |  | — |  |  | — | % |
| Income from equity method investments | (13.4 | ) |  | (0.4 | )% |  | (12.0 | ) |  | (0.3 | )% |  | (18.4 | ) |  | (0.5 | )% |
| Operating income | $ | 656.9 |  |  | 17.3 | % |  | $ | 509.9 |  |  | 13.1 | % |  | $ | 494.5 |  |  | 12.9 | % |
| Loss from discontinued operations | (0.1 | ) |  | — | % |  | (1.3 | ) |  | — | % |  | (1.4 | ) |  | — | % |
| Net income | $ | 408.7 |  |  | 10.7 | % |  | $ | 359.0 |  |  | 9.2 | % |  | $ | 305.7 |  |  | 8.0 | % |

[0001069202-20-000004:mdna:24]
Year Ended December 31, 2019 Compared to Year Ended December 31, 2018 - Consolidated Results

[0001069202-20-000004:mdna:25]
Net Sales

[0001069202-20-000004:mdna:26]
Net sales decreased 2.0% in 2019 compared to 2018, driven by a 5% decline related to the divestitures of our Australia, Asia, South America, and Kysor Warren businesses, partially offset by 1% volume growth and 2% from favorable price and mix combined. The increase in volume was primarily due to market growth in our Residential Heating & Cooling and Commercial Heating & Cooling segments, and the favorable price and mix combined was attributable to all three of our business segments.

[0001069202-20-000004:mdna:27]
Gross Profit

[0001069202-20-000004:mdna:28]
Gross profit margins for 2019 decreased 20 basis points (“bps”) to 28.4% compared to 28.6% in 2018.  We saw margin decreases of 30 bps from higher commodity costs, 80 bps from higher freight and distribution costs, 70 bps from lower factory productivity, and 50 bps from other product costs.  These decreases were offset by increases of 100 bps from favorable price and mix, 50 bps from sourcing and engineering-led cost reductions, and 60 bps from our divested Australia, Asia, South America, and Kysor Warren businesses which collectively had lower margins.

[0001069202-20-000004:mdna:29]
Selling, General and Administrative Expenses

[0001069202-20-000004:mdna:30]
SG&A expenses decreased by $22 million in 2019 compared to 2018.  As a percentage of net sales, SG&A expenses decreased 30 bps from 15.7% to 15.4% in the same periods.  SG&A decreased primarily due to the sale of our divested Australia, Asia, South America, and Kysor Warren businesses.

[0001069202-20-000004:mdna:31]
Losses (Gains) and Other Expenses, Net

[0001069202-20-000004:mdna:32]
Losses (gains) and other expenses, net for 2019 and 2018 included the following (in millions):

[0001069202-20-000004:mdna:33]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |
| Realized losses (gains), net on settled futures contracts | $ | 0.4 |  |  | $ | (0.4 | ) |
| Foreign currency exchange (gains) losses, net | (1.5 | ) |  | 1.7 |  |
| (Gains) losses on disposal of fixed assets | (0.2 | ) |  | 0.7 |  |
| Other operating (gains) losses | (1.7 | ) |  | — |  |
| Change in unrealized (gains) losses, net of unsettled futures contracts | (0.5 | ) |  | 1.5 |  |
| Asbestos-related litigation | 3.1 |  |  | 4.0 |  |
| Special legal contingency charges | 1.2 |  |  | 1.9 |  |
| Environmental liabilities | 5.7 |  |  | 2.2 |  |
| Other items, net | 1.8 |  |  | 1.8 |  |
| Losses (gains) and other expenses, net | $ | 8.3 |  |  | $ | 13.4 |  |

[0001069202-20-000004:mdna:34]
The realized losses on settled futures contracts in 2019 were attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have decreased in 2019 relative to 2018.  Additionally, the change in unrealized (gains) losses, net on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:35]
Foreign currency exchange gains increased in 2019 primarily due to strengthening in foreign exchange rates in our primary markets.  The special legal contingency charges in 2019 relate to outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-20-000004:mdna:36]
Restructuring Charges

[0001069202-20-000004:mdna:37]
Restructuring charges were $10.3 million in 2019 compared to $3.0 million in 2018. The charges in 2019 related primarily to activities in the Residential Heating & Cooling segment to close certain Lennox Stores and reduce management and support staff, and activities in the Commercial Heating & Cooling segments to re-align resources and its product portfolio.  The charges in 2018 were primarily for projects to realign resources and enhance manufacturing and distribution capabilities.  For more information on our restructuring activities, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:38]
Goodwill

[0001069202-20-000004:mdna:39]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2019.  We did not record any goodwill impairments in 2018 or 2019.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-20-000004:mdna:40]
Asset Impairments

[0001069202-20-000004:mdna:41]
We did not have any impairments of assets related to continuing operations in 2019 or 2018.

[0001069202-20-000004:mdna:42]
Pension Settlement

[0001069202-20-000004:mdna:43]
In the second and fourth quarters of 2019, we entered into agreements to purchase group annuity contracts and transfer certain pension assets and related pension benefit obligations to Pacific Life Insurance Company.  We recognized $99.2 million of pension settlement charges related to these transactions.  We did not have significant pension buyout activity in 2018.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-20-000004:mdna:44]
Income from Equity Method Investments

[0001069202-20-000004:mdna:45]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $13 million in 2019 compared to $12 million in 2018.  The increase is due to improved operating performance at the joint ventures.

[0001069202-20-000004:mdna:46]
Interest Expense, net

[0001069202-20-000004:mdna:47]
Net interest expense of $48 million in 2019 increased from $38 million in 2018 primarily due to an increase in our average borrowings.

[0001069202-20-000004:mdna:48]
Income Taxes

[0001069202-20-000004:mdna:49]
The income tax provision was $99 million in 2019 compared to $108 million in 2018, and the effective tax rate was 19.5% in 2019 compared to 23.0% in 2018.  The 2019 and 2018 effective tax rates differ from the statutory rate of 21% primarily due to state and foreign taxes. Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.  We expect our effective tax rate will be between 21% and 22% in future years, excluding the impact of excess tax benefits.

[0001069202-20-000004:mdna:50]
Loss from Discontinued Operations

[0001069202-20-000004:mdna:51]
There were no significant losses from discontinued operations in 2019.  The $1 million of pre-tax income in 2018 primarily related to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-20-000004:mdna:52]
Year Ended December 31, 2019 Compared to Year Ended December 31, 2018 - Results by Segment

[0001069202-20-000004:mdna:53]
Residential Heating & Cooling

[0001069202-20-000004:mdna:54]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-20-000004:mdna:55]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 2,291.1 |  |  | $ | 2,225.0 |  |  | $ | 66.1 |  |  | 3.0 | % |
| Profit | $ | 464.6 |  |  | $ | 399.4 |  |  | $ | 65.2 |  |  | 16.3 | % |
| % of net sales | 20.3 | % |  | 18.0 | % |  |  |  |  |

[0001069202-20-000004:mdna:56]
Residential Heating & Cooling net sales increased 3% in 2019 compared to 2018. Sales volume increased 1% and price and mix combined increased 2%.

[0001069202-20-000004:mdna:57]
Segment profit in 2019 increased $65 million compared to 2018 due to an incremental $72 million of insurance proceeds for lost profits related to the Marshalltown tornado, $53 million of favorable price, $14 million of sourcing and engineer-led cost reductions, $8 million of lower warranty costs, and $2 million of higher sales volume.  Partially offsetting these increases is $28 million of higher freight and distribution expense, $16 million from lower factory efficiency, $12 million of higher SG&A, $11

[0001069202-20-000004:mdna:58]
million of unfavorable mix, $10 million of higher other product costs, $6 million of higher commodities, and $1 million of unfavorable foreign exchange rates.

[0001069202-20-000004:mdna:59]
Commercial Heating & Cooling

[0001069202-20-000004:mdna:60]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-20-000004:mdna:61]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 947.4 |  |  | $ | 900.7 |  |  | $ | 46.7 |  |  | 5.2 | % |
| Profit | $ | 165.4 |  |  | $ | 157.5 |  |  | $ | 7.9 |  |  | 5.0 | % |
| % of net sales | 17.5 | % |  | 17.5 | % |  |  |  |  |

[0001069202-20-000004:mdna:62]
Commercial Heating & Cooling net sales increased 5% in 2019 compared to 2018.  Sales volume increased 2% and price and mix combined increased 3%.

[0001069202-20-000004:mdna:63]
Segment profit in 2019 increased $8 million compared to 2018 due to $23 million of higher price and mix combined, $7 million of higher sales volume, and $6 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases was $7 million of lower factory efficiency, $6 million of higher warranty and other product costs, $5 million of higher commodities, $4 million of higher freight and distribution expense, $3 million of higher SG&A expense, and $3 million of higher tariffs on Chinese imports.

[0001069202-20-000004:mdna:64]
Refrigeration

[0001069202-20-000004:mdna:65]
The following table presents our Refrigeration segment’s net sales and profit for 2019 and 2018 (dollars in millions):

[0001069202-20-000004:mdna:66]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2019 |  | 2018 |  | Difference |  | % Change |
| Net sales | $ | 568.7 |  |  | $ | 758.2 |  |  | $ | (189.5 | ) |  | (25.0 | )% |
| Profit | $ | 61.3 |  |  | $ | 68.1 |  |  | $ | (6.8 | ) |  | (10.0 | )% |
| % of net sales | 10.8 | % |  | 9.0 | % |  |  |  |  |

[0001069202-20-000004:mdna:67]
Net sales decreased 25% in 2019 compared to 2018.  The loss of sales from the divested Australia, Asia, South America and Kysor Warren businesses contributed 24% and unfavorable foreign currency exchange rates contributed 2%, partially offset by 1% favorable price and mix combined.

[0001069202-20-000004:mdna:68]
Segment profit in 2019 decreased $7 million compared to 2018 due to $5 million of lower factory efficiency, $2 million of higher commodities, $3 million of lower sales of refrigerant allocations in Europe, $3 million of higher warranty and other product costs, $3 million of higher SG&A expenses, $1 million unfavorable foreign currency exchange rates, and $1 million of higher tariffs on Chinese imports.  Partially offsetting these decreases was $4 million from higher price and mix combined, $5 million of sourcing and engineering-led cost reductions, and $2 million of higher profit due to the divestiture of Kysor Warren.

[0001069202-20-000004:mdna:69]
Corporate and Other

[0001069202-20-000004:mdna:70]
Corporate and other expenses decreased by $2 million in 2019 compared to 2018 primarily due to lower short-term and long-term incentive compensation.

[0001069202-20-000004:mdna:71]
Year Ended December 31, 2018 Compared to Year Ended December 31, 2017 - Consolidated Results

[0001069202-20-000004:mdna:72]
Net Sales

[0001069202-20-000004:mdna:73]
Net sales increased 1.2% in 2018 compared to 2017, primarily driven by volume and price increases.  The increase in volume was primarily due to market growth in our Residential Heating and Cooling and Commercial Heating and Cooling segments.

[0001069202-20-000004:mdna:74]
These increases were partially offset by the impact due to the sale of our Australia, Asia and South America businesses in our Refrigeration segment.

[0001069202-20-000004:mdna:75]
Gross Profit

[0001069202-20-000004:mdna:76]
Gross profit margins for 2018 decreased 70 basis points (“bps”) to 28.6% compared to 29.3% in 2017.  We saw margin decreases of 120 bps from higher commodity costs, 100 bps from higher freight and distribution costs, and 50 bps from other product costs.  These decreases were offset by increases of 130 bps from favorable price and mix and 70 bps from sourcing and engineering-led cost reductions.

[0001069202-20-000004:mdna:77]
Selling, General and Administrative Expenses

[0001069202-20-000004:mdna:78]
SG&A expenses decreased by $30 million in 2018 compared to 2017.  As a percentage of net sales, SG&A expenses decreased 90 bps from 16.6% to 15.7% in the same periods.  SG&A decreased primarily due to the sale of our divested businesses in Australia,  Asia and South America.

[0001069202-20-000004:mdna:79]
Losses (Gains) and Other Expenses, Net

[0001069202-20-000004:mdna:80]
Losses (gains) and other expenses, net for 2018 and 2017 included the following (in millions):

[0001069202-20-000004:mdna:81]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |
| Realized gains, net on settled futures contracts | $ | (0.4 | ) |  | $ | (1.7 | ) |
| Foreign currency exchange losses (gains), net | 1.7 |  |  | (1.8 | ) |
| Losses on disposal of fixed assets | 0.7 |  |  | 0.2 |  |
| Change in unrealized losses, net of unsettled futures contracts | 1.5 |  |  | 0.9 |  |
| Asbestos-related litigation | 4.0 |  |  | 3.5 |  |
| Special legal contingency charges | 1.9 |  |  | 3.7 |  |
| Environmental liabilities | 2.2 |  |  | 2.2 |  |
| Contractor tax payments | — |  |  | 0.1 |  |
| Other items, net | 1.8 |  |  | — |  |
| Losses (gains) and other expenses, net | $ | 13.4 |  |  | $ | 7.1 |  |

[0001069202-20-000004:mdna:82]
The realized gains on settled futures contracts in 2018 were attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2018 relative to 2017.  Additionally, the change in unrealized losses, net on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 10 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:83]
Foreign currency exchange losses increased in 2018 primarily due to weakening in foreign exchange rates in our primary markets.  The special legal contingency charges decreased primarily due to lower legal costs associated with outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-20-000004:mdna:84]
Restructuring Charges

[0001069202-20-000004:mdna:85]
Restructuring charges were $3.0 million in 2018 compared to $3.2 million in 2017.  The charges in 2018 and 2017 were primarily for projects to realign resources and enhance manufacturing and distribution capabilities.  For more information on our restructuring activities, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:86]
Goodwill

[0001069202-20-000004:mdna:87]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2018. In 2018, we wrote off $11.5 million of goodwill as a part of the completed sales of our Australia, Asia and South America businesses (discussed further in Note 7 of the Notes to the Consolidated Financial Statements).  Also, we did not record any

[0001069202-20-000004:mdna:88]
goodwill impairments in 2017. Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-20-000004:mdna:89]
Asset Impairment

[0001069202-20-000004:mdna:90]
We did not have any impairments of assets related to continuing operations in 2018 or 2017.

[0001069202-20-000004:mdna:91]
Pension Settlement

[0001069202-20-000004:mdna:92]
We did not have significant pension buyout activity in 2018 or 2017.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-20-000004:mdna:93]
Income from Equity Method Investments

[0001069202-20-000004:mdna:94]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $12 million in 2018 compared to $18 million in 2017.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed these increased costs on through price increases.

[0001069202-20-000004:mdna:95]
Interest Expense, net

[0001069202-20-000004:mdna:96]
Net interest expense of $38 million in 2018 increased from $31 million in 2017 primarily due to an increase in our average borrowings and rising interest rates.

[0001069202-20-000004:mdna:97]
Income Taxes

[0001069202-20-000004:mdna:98]
The income tax provision was $108 million in 2018 compared to $157 million in 2017, and the effective tax rate was 23% in 2018 compared to 34% in 2017.  The 2018 effective tax rate differs from the statutory rate of 21% primarily due to state and foreign taxes. The 2017 effective tax rate was negatively impacted by changes in U.S. tax legislation that reduced the value of our deferred tax assets by $31.8 million, partially offset by the benefit from the impact of excess tax benefits related to stock-based compensation of $23.6 million.  Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on the impact of recent changes in tax legislation.

[0001069202-20-000004:mdna:99]
Loss from Discontinued Operations

[0001069202-20-000004:mdna:100]
The $1 million of pre-tax income incurred in 2018 and $2 million of pre-tax losses in 2017 primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-20-000004:mdna:101]
Year Ended December 31, 2018 Compared to Year Ended December 31, 2017 - Results by Segment

[0001069202-20-000004:mdna:102]
Residential Heating & Cooling

[0001069202-20-000004:mdna:103]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-20-000004:mdna:104]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 2,225.0 |  |  | $ | 2,140.4 |  |  | $ | 84.6 |  |  | 4.0 | % |
| Profit | $ | 399.4 |  |  | $ | 373.9 |  |  | $ | 25.5 |  |  | 6.8 | % |
| % of net sales | 18.0 | % |  | 17.5 | % |  |  |  |  |

[0001069202-20-000004:mdna:105]
Residential Heating & Cooling net sales increased 4% in 2018 compared to 2017. Sales volume increased 2% and price and mix combined increased 2%.

[0001069202-20-000004:mdna:106]
Segment profit in 2018 increased $26 million due to $52 million of combined price and mix, $27 million of insurance proceeds for the third quarter 2018 lost profits from the Marshalltown tornado, $14 million from higher sales volume, $12 million from

[0001069202-20-000004:mdna:107]
sourcing and engineering-led cost reductions, and $5 million of higher factory productivity.  Partially offsetting these increases is $35 million of higher commodity costs, $32 million of higher freight and distribution expenses, $9 million of higher other product costs, $4 million from lower equity method income, $3 million from unfavorable foreign exchange rates, and $1 million from higher SG&A.

[0001069202-20-000004:mdna:108]
Commercial Heating & Cooling

[0001069202-20-000004:mdna:109]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-20-000004:mdna:110]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 900.7 |  |  | $ | 819.5 |  |  | $ | 81.2 |  |  | 9.9 | % |
| Profit | $ | 157.5 |  |  | $ | 149.3 |  |  | $ | 8.2 |  |  | 5.5 | % |
| % of net sales | 17.5 | % |  | 18.2 | % |  |  |  |  |

[0001069202-20-000004:mdna:111]
Commercial Heating & Cooling net sales increased 10% in 2018 compared to 2017.  Sales volume increased 7% and price and mix combined increased 3%.

[0001069202-20-000004:mdna:112]
Segment profit in 2018 increased $8 million compared to 2017 due to $19 million from higher sales volume, $11 million of combined price and mix, and $5 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases is $9 million of higher commodity costs, $9 million of higher other product costs, $5 million of higher freight and distribution expense, $2 million of lower factory productivity, and $2 million of higher SG&A expense.

[0001069202-20-000004:mdna:113]
Refrigeration

[0001069202-20-000004:mdna:114]
The following table presents our Refrigeration segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-20-000004:mdna:115]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 758.2 |  |  | $ | 879.7 |  |  | $ | (121.5 | ) |  | (13.8 | )% |
| Profit | $ | 68.1 |  |  | $ | 80.6 |  |  | $ | (12.5 | ) |  | (15.5 | )% |
| % of net sales | 9.0 | % |  | 9.2 | % |  |  |  |  |

[0001069202-20-000004:mdna:116]
Net sales decreased 14% in 2018 compared to 2017.  The loss of sales from the divested Australia, Asia and South America businesses contributed 13%, price and mix combined was 1% lower and sales volume was 1% lower.  These were partially offset by an increase of 1% from favorable foreign currency exchange rates.

[0001069202-20-000004:mdna:117]
Segment profit in 2018 decreased $13 million compared to 2017 due to $6 million of higher commodity costs, $6 million of lower profit due to the divested Australia, Asia and South America businesses, $3 million from lower sales volume, $3 million of lower factory productivity, $2 million of higher freight and distribution expense and $2 million of lower equity method income.  Partially offsetting these decreases was $6 million of sourcing and engineering-led cost reductions, $2 million from selling refrigerant allocations in Europe, and $1 million of lower SG&A expense.

[0001069202-20-000004:mdna:118]
Corporate and Other

[0001069202-20-000004:mdna:119]
Corporate and other expenses decreased by $5 million in 2018 primarily due to $2 million of non-recurring discretionary expenses in 2017, $2 million of pension expense that was reclassified out of operating income due to a change in accounting rules, and $1 million of lower health and welfare expense.

[0001069202-20-000004:mdna:120]
Accounting for Futures Contracts

[0001069202-20-000004:mdna:121]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 10 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001069202-20-000004:mdna:122]
Liquidity and Capital Resources

[0001069202-20-000004:mdna:123]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-20-000004:mdna:124]
Statement of Cash Flows

[0001069202-20-000004:mdna:125]
The following table summarizes our cash flow activity for the years ended December 31, 2019, 2018 and 2017 (in millions):

[0001069202-20-000004:mdna:126]
|  | 2019 |  | 2018 |  | 2017 |
| Net cash provided by operating activities | $ | 396.1 |  |  | $ | 495.5 |  |  | $ | 325.1 |  |
| Net cash provided by (used in) investing activities | 15.9 |  |  | 30.5 |  |  | (98.1 | ) |
| Net cash used in financing activities | $ | (423.4 | ) |  | $ | (537.8 | ) |  | $ | (218.3 | ) |

[0001069202-20-000004:mdna:127]
Net Cash Provided by Operating Activities - Net cash provided by operating activities decreased $99 million to $396 million in 2019 compared to $496 million in 2018.  The decrease was primarily attributable to an increase in working capital partially offset by an increase in net income.

[0001069202-20-000004:mdna:128]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $106 million, $95 million and $98 million in 2019, 2018 and 2017, respectively.  Capital expenditures in 2019 were primarily related to the reconstruction of the Marshalltown facility, expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.  We received net proceeds of $44 million in 2019 from the sale of our Kysor Warren business, and we received $80 million of insurance proceeds to fund the capital expenditures for the reconstruction of our Marshalltown facility.

[0001069202-20-000004:mdna:129]
Net Cash Used in Financing Activities - Net cash used in financing activities decreased to $423 million in 2019 from $538 million in 2018.  The decrease is largely due to lower share repurchases in 2019 and an increase in borrowings from our debt facilities.  During 2019 we repurchased $400 million of shares compared to $450 million of shares in 2018.  We also returned $111 million to shareholders through dividend payments.  For additional information on share repurchases, refer to Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-20-000004:mdna:130]
Debt Position

[0001069202-20-000004:mdna:131]
The following table details our lines of credit and financing arrangements as of December 31, 2019 (in millions):

[0001069202-20-000004:mdna:132]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program (1) | $ | 285.0 |  |
| Capital lease obligations | 7.8 |  |
| Domestic credit facility (2) | 30.0 |  |
| Debt issuance costs | (0.9 | ) |
| Total current maturities of long-term debt | $ | 321.9 |  |
| Long-term debt: |  |
| Capital lease obligations | $ | 25.9 |  |
| Domestic credit facility (2) | 475.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (2.1 | ) |
| Total long-term debt | 849.3 |  |
| Total debt | $ | 1,171.2 |  |

[0001069202-20-000004:mdna:133]
| (1) | The maximum securitization amount ranges from $250.0 million to $400.0 million, depending on the period. The maximum capacity of the Asset Securitization Program (“ASP”) is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP. Refer to Note 14 in the Notes to the Consolidated Financial Statements for more details. |

[0001069202-20-000004:mdna:134]
| (2) | The available future borrowings on our domestic credit facility are $652 million after being reduced by the outstanding borrowings and $2 million in outstanding standby letters of credit. We also had $30.0 million in outstanding standby letters of credit outside of the domestic credit facility as of December 31, 2019. In January 2019, we increased the maximum credit commitments by $350 million as permitted under the Domestic Credit Facility bringing the total maximum credit commitments to $1.0 billion. |

[0001069202-20-000004:mdna:135]
Financial Leverage

[0001069202-20-000004:mdna:136]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-20-000004:mdna:137]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans.  Our debt-to-total-capital ratio increased to 117.0% at December 31, 2019 compared to 116.8% at December 31, 2018.  The increase in the ratio in 2019 is primarily due to the increase in total debt.

[0001069202-20-000004:mdna:138]
As of December 31, 2019, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001069202-20-000004:mdna:139]
Liquidity

[0001069202-20-000004:mdna:140]
We believe our cash and cash equivalents of $37 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2019 was $19 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally

[0001069202-20-000004:mdna:141]
do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-20-000004:mdna:142]
No contributions are required to be made to our U.S. defined benefit plans in 2020. We made $2 million in total contributions to pension plans in 2019.

[0001069202-20-000004:mdna:143]
On May 22, 2019, our Board of Directors approved a 20% increase in our quarterly dividend on common stock from $0.64 to $0.77 per share effective with the July 2019 dividend payment.  Dividend payments were $111 million in 2019 compared to $94 million in 2018, with the increase due to the increase in dividends approved by the Board of Directors.

[0001069202-20-000004:mdna:144]
We also continued to increase shareholder value through our Share Repurchase Plans.  We returned $400 million to our investors through share repurchases in 2019 and expect to repurchase another $400 million of shares in 2020.  Our Board of Directors authorized an incremental $500 million of share repurchases in December 2019,  and we have $546 million of repurchases available under the Share Repurchase Plans at December 31, 2019.

[0001069202-20-000004:mdna:145]
We expect capital expenditures of approximately $153 million in 2020, including $53 million to complete the reconstruction of the Marshalltown, Iowa manufacturing facility.

[0001069202-20-000004:mdna:146]
Financial Covenants related to our Debt

[0001069202-20-000004:mdna:147]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio.  The required ratios under our domestic credit facility are detailed below:

[0001069202-20-000004:mdna:148]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-20-000004:mdna:149]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-20-000004:mdna:150]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or |

[0001069202-20-000004:mdna:151]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-20-000004:mdna:152]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our domestic credit facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-20-000004:mdna:153]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-20-000004:mdna:154]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-20-000004:mdna:155]
As of December 31, 2019, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001069202-20-000004:mdna:156]
Leasing Commitments

[0001069202-20-000004:mdna:157]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-20-000004:mdna:158]
Off Balance Sheet Arrangements

[0001069202-20-000004:mdna:159]
An off-balance sheet arrangement is any transaction, agreement or other contractual arrangement involving an unconsolidated entity under which the company has: (1) made guarantees, (2) a retained or a contingent interest in transferred assets, (3) an obligation under derivative instruments classified as equity or (4) any obligation arising out of a material variable interest in an unconsolidated entity that provides financing, liquidity, market risk or credit risk support to us, or that engages in leasing, hedging or research and development arrangements with us.  We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001069202-20-000004:mdna:160]
Contractual Obligations

[0001069202-20-000004:mdna:161]
Summarized below are our contractual obligations as of December 31, 2019 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-20-000004:mdna:162]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 1,174.2 |  |  | $ | 322.8 |  |  | $ | 486.6 |  |  | $ | 353.1 |  |  | $ | 11.7 |  |
| Estimated interest payments on existing debt obligations (2) | 72.5 |  |  | 32.4 |  |  | 30.5 |  |  | 9.3 |  |  | 0.3 |  |
| Operating leases | 199.3 |  |  | 58.4 |  |  | 80.1 |  |  | 43.7 |  |  | 17.1 |  |
| Purchase obligations (3) | 25.4 |  |  | 25.4 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 1,471.4 |  |  | $ | 439.0 |  |  | $ | 597.2 |  |  | $ | 406.1 |  |  | $ | 29.1 |  |

[0001069202-20-000004:mdna:163]
(1) Contractual obligations related to finance leases are included as part of long-term debt.

[0001069202-20-000004:mdna:164]
(2) Estimated interest payments are based on current contractual requirements and do not reflect seasonal changes in the balance of our domestic credit facility.

[0001069202-20-000004:mdna:165]
(3) Purchase obligations consist of inventory that is part of our third party logistics programs.

[0001069202-20-000004:mdna:166]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded. For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements.  See Note 11 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-20-000004:mdna:167]
Fair Value Measurements

[0001069202-20-000004:mdna:168]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-20-000004:mdna:169]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-20-000004:mdna:170]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-20-000004:mdna:171]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-20-000004:mdna:172]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-20-000004:mdna:173]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2019 and 2018, the measurement dates.  See Note 17 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-20-000004:mdna:174]
Market Risk

[0001069202-20-000004:mdna:175]
Commodity Price Risk

[0001069202-20-000004:mdna:176]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-20-000004:mdna:177]
| Notional amount (pounds of aluminum and copper) | 61.8 |  |
| Carrying amount and fair value of net liability | $ | (0.7 | ) |
| Change in fair value from 10% change in forward prices | $ | 9.1 |  |

[0001069202-20-000004:mdna:178]
Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-20-000004:mdna:179]
Interest Rate Risk

[0001069202-20-000004:mdna:180]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $3.9 million, $2.7 million and $1.8 million for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001069202-20-000004:mdna:181]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2019 and 2018, no interest rate swaps were in effect.

[0001069202-20-000004:mdna:182]
Foreign Currency Exchange Rate Risk

[0001069202-20-000004:mdna:183]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2019, 2018 and 2017, net sales from outside the U.S. represented 13.2%, 18.5% and 18.5% , respectively, of our total net sales.  For the years ended December 31, 2019 and 2018, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $4.2 million, $2.1 million and $5.2 million impact to net income for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001069202-20-000004:mdna:184]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 10 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-20-000004:mdna:185]
Critical Accounting Estimates

[0001069202-20-000004:mdna:186]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-20-000004:mdna:187]
Product Warranties and Product-Related Contingencies

[0001069202-20-000004:mdna:188]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001069202-20-000004:mdna:189]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.  These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001069202-20-000004:mdna:190]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-20-000004:mdna:191]
Recent Accounting Pronouncements

[0001069202-20-000004:mdna:192]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
