# LII notes — 0001069202-20-000004


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-20-000004:notes:1]
Principles of Consolidation

[0001069202-20-000004:notes:2]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-20-000004:notes:3]
rinciples of Consolidation

[0001069202-20-000004:notes:4]
Cash and Cash Equivalents

[0001069202-20-000004:notes:5]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.

[0001069202-20-000004:notes:6]
Short term Investments

[0001069202-20-000004:notes:7]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date and are expected to be used in current operations.

[0001069202-20-000004:notes:8]
Accounts and Notes Receivable

[0001069202-20-000004:notes:9]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheet, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001069202-20-000004:notes:10]
Inventories

[0001069202-20-000004:notes:11]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $360.7 million and $343.5 million as of December 31, 2019 and 2018, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-20-000004:notes:12]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 10 for more information on our inventories.

[0001069202-20-000004:notes:13]
Property, Plant and Equipment

[0001069202-20-000004:notes:14]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-20-000004:notes:15]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-20-000004:notes:16]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 10 years |
| Vehicles | 3 to 10 years |

[0001069202-20-000004:notes:17]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 10 for additional information on our property, plant and equipment.

[0001069202-20-000004:notes:18]
Goodwill

[0001069202-20-000004:notes:19]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired.  See Note 10 for additional information on our goodwill.

[0001069202-20-000004:notes:20]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-20-000004:notes:21]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.

[0001069202-20-000004:notes:22]
Intangible Assets

[0001069202-20-000004:notes:23]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-20-000004:notes:24]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |

[0001069202-20-000004:notes:25]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair

[0001069202-20-000004:notes:26]
value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-20-000004:notes:27]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-20-000004:notes:28]
Product Warranties

[0001069202-20-000004:notes:29]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 5 for more information on our estimated future warranty costs.

[0001069202-20-000004:notes:30]
Pensions and Post-retirement Benefits

[0001069202-20-000004:notes:31]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheet.  Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-20-000004:notes:32]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 11 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-20-000004:notes:33]
Self-Insurance

[0001069202-20-000004:notes:34]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors and trends.  The self-insurance liabilities as of December 31, 2019 represent the best estimate of the future payments to be made on reported and unreported losses for 2019 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 5 for additional information on our self-insured risks and liabilities.

[0001069202-20-000004:notes:35]
Derivatives

[0001069202-20-000004:notes:36]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheet at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 10 for more information on our derivatives.

[0001069202-20-000004:notes:37]
Income Taxes

[0001069202-20-000004:notes:38]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 13 for more information related to income taxes.

[0001069202-20-000004:notes:39]
Revenue Recognition

[0001069202-20-000004:notes:40]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 9 for more information on our revenue recognition practices.

[0001069202-20-000004:notes:41]
Cost of Goods Sold

[0001069202-20-000004:notes:42]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.

[0001069202-20-000004:notes:43]
Selling, General and Administrative Expenses

[0001069202-20-000004:notes:44]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.

[0001069202-20-000004:notes:45]
Stock-Based Compensation

[0001069202-20-000004:notes:46]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 16 for more information.

[0001069202-20-000004:notes:47]
Translation of Foreign Currencies

[0001069202-20-000004:notes:48]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001069202-20-000004:notes:49]
Use of Estimates

[0001069202-20-000004:notes:50]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-20-000004:notes:51]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity

[0001069202-20-000004:notes:52]
markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-20-000004:notes:53]
Recently Adopted Accounting Pronouncements

[0001069202-20-000004:notes:54]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (“ASC 842”). This accounting standard requires lessees to recognize a lease liability and a right-of-use (“ROU”) asset on the balance sheet for operating leases.  Accounting for finance leases is substantially unchanged.  ASC 842 is effective for fiscal years beginning after December 15, 2018 and we adopted the standard effective January 1, 2019.  The adoption of ASC 842 had a material impact on our Consolidated Balance Sheet due to the recognition of operating lease liabilities and the corresponding right-of-use assets. Refer to Note 5 of the Notes to the Consolidated Financial Statements for additional information.

[0001069202-20-000004:notes:55]
Changes in Accounting Standards Effective for Future Reporting Periods

[0001069202-20-000004:notes:56]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to estimate credit losses. ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019.  We are currently assessing the impact of ASU 2016-13, but do not expect it to have a material impact on our financial statements.

[0001069202-20-000004:notes:57]
In January 2017, the FASB issued ASU No. 2017-04, Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 eliminates step two of the goodwill impairment test and specifies that goodwill impairment should be measured by comparing the fair value of a reporting unit with its carrying amount. Additionally, the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount of net assets should be disclosed. ASU 2017-04 is effective for annual or interim goodwill impairment tests performed in fiscal years beginning after December 15, 2019. We do not expect the adoption of ASU 2017-04 to have a material impact on our financial statements.

[0001069202-20-000004:notes:58]
In August 2018, the FASB issued ASU No. 2018-15, Intangibles - Internal-Use Software (Topic 350-40): Customer’s Accounting for Implementation Costs incurred in a Cloud Computing Arrangement That is a Service Contract.  ASU 2018-15 provides guidance to determine how implementation costs associated with cloud computing arrangements that are incurred to develop or obtain internal-use software should be capitalized or expensed as incurred. ASU 2018-15 is effective for fiscal years beginning after December 15, 2019.  We do not expect the adoption of ASU 2018-15 to have a material impact on our financial statements.

[0001069202-20-000004:notes:59]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations,  foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  We are currently assessing the impact of ASU 2019-12, but do not expect it to have a material impact on our financial statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001069202-20-000004:notes:60]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-20-000004:notes:61]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Land | $ | 23.7 |  |  | $ | 25.5 |  |
| Buildings and improvements | 242.9 |  |  | 210.9 |  |
| Machinery and equipment | 883.4 |  |  | 838.6 |  |
| Capital leases | 47.2 |  |  | 49.9 |  |
| Construction in progress and equipment not yet in service | 72.5 |  |  | 61.9 |  |
| Total | 1,269.7 |  |  | 1,186.8 |  |
| Less accumulated depreciation | (824.3 | ) |  | (778.5 | ) |
| Property, plant and equipment, net | $ | 445.4 |  |  | $ | 408.3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-20-000004:notes:62]
scription of Segments

[0001069202-20-000004:notes:63]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-20-000004:notes:64]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanada |
| Refrigeration(2) |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, and compressorized racks |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEurope(1) |

[0001069202-20-000004:notes:65]
(1) Effective January 1, 2019, we realigned our segment structure. We shifted financial reporting of the European Commercial HVAC business from our Commercial Heating & Cooling segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. We have revised our historical segment results to present them on a comparable basis.

[0001069202-20-000004:notes:66]
(2) Descriptions of the products, services, markets and geographic areas of divested businesses were excluded from this table.   Refer to Note 7 for details regarding the divestitures of our Australia, Asia, South America and Kysor Warren businesses.

[0001069202-20-000004:notes:67]
Segment Data

[0001069202-20-000004:notes:68]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-20-000004:notes:69]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term, share-based incentive awards provided to employees throughout our business.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-20-000004:notes:70]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-20-000004:notes:71]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-20-000004:notes:72]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 2,291.1 |  |  | $ | 2,225.0 |  |  | $ | 2,140.4 |  |
| Commercial Heating & Cooling | 947.4 |  |  | 900.7 |  |  | 819.5 |  |
| Refrigeration | 568.7 |  |  | 758.2 |  |  | 879.7 |  |
|  | $ | 3,807.2 |  |  | $ | 3,883.9 |  |  | $ | 3,839.6 |  |
| Segment profit (loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 464.6 |  |  | $ | 399.4 |  |  | $ | 373.9 |  |
| Commercial Heating & Cooling | 165.4 |  |  | 157.5 |  |  | 149.3 |  |
| Refrigeration | 61.3 |  |  | 68.1 |  |  | 80.6 |  |
| Corporate and other | (82.4 | ) |  | (84.4 | ) |  | (89.2 | ) |
| Total segment profit | 608.9 |  |  | 540.6 |  |  | 514.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special inventory write down | — |  |  | 0.2 |  |  | — |  |
| Special product quality adjustments | (0.6 | ) |  | — |  |  | 5.4 |  |
| Loss (gain), net on sale of businesses and related property | 10.6 |  |  | 27.0 |  |  | 1.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster | (79.6 | ) |  | (10.9 | ) |  | — |  |
| Items in (Gains) Losses and other expenses, net that are excluded from segment profit (loss) (2) | 11.3 |  |  | 11.4 |  |  | 10.4 |  |
| Restructuring charges | 10.3 |  |  | 3.0 |  |  | 3.2 |  |
| Operating income | $ | 656.9 |  |  | $ | 509.9 |  |  | $ | 494.5 |  |

[0001069202-20-000004:notes:73]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-20-000004:notes:74]
(2) We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000004:notes:75]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-20-000004:notes:76]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-20-000004:notes:77]
| ◦ | Special legal contingency charges, |

[0001069202-20-000004:notes:78]
| ◦ | Asbestos-related litigation, |

[0001069202-20-000004:notes:79]
| ◦ | Environmental liabilities, |

[0001069202-20-000004:notes:80]
| ◦ | Other items, net, |

[0001069202-20-000004:notes:81]
| • | Special inventory write down, |

[0001069202-20-000004:notes:82]
| • | Special product quality adjustments |

[0001069202-20-000004:notes:83]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-20-000004:notes:84]
| • | Insurance recoveries received for property damage incurred from natural disaster, and |

[0001069202-20-000004:notes:85]
| • | Restructuring charges. |

[0001069202-20-000004:notes:86]
Total assets by segment are shown below (in millions):

[0001069202-20-000004:notes:87]
|  | As of December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,055.7 |  |  | $ | 837.4 |  |  | $ | 771.3 |  |
| Commercial Heating & Cooling | 409.0 |  |  | 349.5 |  |  | 324.3 |  |
| Refrigeration | 393.3 |  |  | 462.9 |  |  | 626.5 |  |
| Corporate and other | 176.9 |  |  | 167.4 |  |  | 169.4 |  |
| Total assets | $ | 2,034.9 |  |  | $ | 1,817.2 |  |  | $ | 1,891.5 |  |

[0001069202-20-000004:notes:88]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets

[0001069202-20-000004:notes:89]
recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-20-000004:notes:90]
Total capital expenditures by segment are shown below (in millions):

[0001069202-20-000004:notes:91]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 59.2 |  |  | $ | 45.2 |  |  | $ | 38.9 |  |
| Commercial Heating & Cooling | 11.3 |  |  | 12.5 |  |  | 14.7 |  |
| Refrigeration | 9.4 |  |  | 9.3 |  |  | 11.8 |  |
| Corporate and other | 25.7 |  |  | 28.2 |  |  | 32.9 |  |
| Total capital expenditures | $ | 105.6 |  |  | $ | 95.2 |  |  | $ | 98.3 |  |

[0001069202-20-000004:notes:92]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-20-000004:notes:93]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 30.0 |  |  | $ | 26.6 |  |  | $ | 24.9 |  |
| Commercial Heating & Cooling | 12.5 |  |  | 8.6 |  |  | 8.6 |  |
| Refrigeration | 7.9 |  |  | 8.9 |  |  | 11.4 |  |
| Corporate and other | 20.7 |  |  | 21.9 |  |  | 19.7 |  |
| Total depreciation and amortization | $ | 71.1 |  |  | $ | 66.0 |  |  | $ | 64.6 |  |

[0001069202-20-000004:notes:94]
The equity method investments are shown below (in millions):

[0001069202-20-000004:notes:95]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 8.8 |  |  | $ | 8.5 |  |  | $ | 11.7 |  |
| Commercial Heating & Cooling | 1.7 |  |  | 1.4 |  |  | 2.8 |  |
| Refrigeration | 2.9 |  |  | 2.1 |  |  | 3.9 |  |
| Total income from equity method investments | $ | 13.4 |  |  | $ | 12.0 |  |  | $ | 18.4 |  |

[0001069202-20-000004:notes:96]
Geographic Information

[0001069202-20-000004:notes:97]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-20-000004:notes:98]
|  | As of December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 333.6 |  |  | $ | 293.3 |  |  | $ | 257.6 |  |
| Mexico | 82.0 |  |  | 86.7 |  |  | 79.8 |  |
| Canada | 2.2 |  |  | 1.7 |  |  | 1.7 |  |
| Other international | 27.6 |  |  | 26.6 |  |  | 58.7 |  |
| Total Property, plant and equipment, net | $ | 445.4 |  |  | $ | 408.3 |  |  | $ | 397.8 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-20-000004:notes:99]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-20-000004:notes:100]
|  | Incurred in 2019 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 2.9 |  |  | $ | 2.9 |  |  | $ | 2.9 |  |
| Commercial Heating & Cooling | 1.0 |  |  | 2.7 |  |  | 3.7 |  |
| Refrigeration | 1.2 |  |  | 2.6 |  |  | 2.7 |  |
| Corporate & Other | 5.2 |  |  | 5.2 |  |  | 5.2 |  |
| Total | $ | 10.3 |  |  | $ | 13.4 |  |  | $ | 14.5 |  |


## us-gaap:EarningsPerShareTextBlock

[0001069202-20-000004:notes:101]
sic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-20-000004:notes:102]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-20-000004:notes:103]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Net income | $ | 408.7 |  |  | $ | 359.0 |  |  | $ | 305.7 |  |
| Add: Loss from discontinued operations | 0.1 |  |  | 1.3 |  |  | 1.4 |  |
| Income from continuing operations | $ | 408.8 |  |  | $ | 360.3 |  |  | $ | 307.1 |  |
| Weighted-average shares outstanding – basic | 39.0 |  |  | 40.6 |  |  | 42.2 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.4 |  |  | 0.5 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 39.4 |  |  | 41.1 |  |  | 42.8 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 10.49 |  |  | $ | 8.87 |  |  | $ | 7.28 |  |
| Loss from discontinued operations | — |  |  | (0.03 | ) |  | (0.03 | ) |
| Net income | $ | 10.49 |  |  | $ | 8.84 |  |  | $ | 7.25 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 10.38 |  |  | $ | 8.77 |  |  | $ | 7.17 |  |
| Loss from discontinued operations | — |  |  | (0.03 | ) |  | (0.03 | ) |
| Net income | $ | 10.38 |  |  | $ | 8.74 |  |  | $ | 7.14 |  |

[0001069202-20-000004:notes:104]
An insignificant number of stock appreciation rights and Restricted Stock Units were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001069202-20-000004:notes:105]
Leases

[0001069202-20-000004:notes:106]
We adopted ASC 842 on January 1, 2019, using the modified retrospective method, with the cumulative-effect adjustment to the opening balance sheet of retained earnings as of the effective date. The financial results reported in periods prior to January 1, 2019 are unchanged.  Upon adoption, we recognized almost all of our leases greater than one year in duration on the balance sheet as right-of-use assets and lease liabilities. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification is based on criteria that are largely similar to those previously applied. We have made certain assumptions in judgments when applying ASC 842.  Those judgments of most significance are as follows:

[0001069202-20-000004:notes:107]
| • | We elected the package of practical expedients available for transition which allow us to not reassess: |

[0001069202-20-000004:notes:108]
| ◦ | Whether expired or existing contracts contain leases under the new definition of a lease; |

[0001069202-20-000004:notes:109]
| ◦ | Lease classification for expired or existing leases; and |

[0001069202-20-000004:notes:110]
| ◦ | Whether previously capitalized initial direct costs would qualify for capitalization under ASC 842. |

[0001069202-20-000004:notes:111]
| • | We did not elect to use hindsight for transition when considering judgments and estimates such as assessments of lessee options to extend or terminate a lease or purchase the underlying asset. |

[0001069202-20-000004:notes:112]
| • | We did not elect to reassess whether land easements meet the definition of a lease if they were not accounted for as leases under the former rules. |

[0001069202-20-000004:notes:113]
| • | For all asset classes, we elected to not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. |

[0001069202-20-000004:notes:114]
| • | For all asset classes, we elected to not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component. |

[0001069202-20-000004:notes:115]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheet as of December 31, 2019 as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheet. Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.

[0001069202-20-000004:notes:116]
Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001069202-20-000004:notes:117]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001069202-20-000004:notes:118]
We lease certain real and personal property under non-cancelable operating leases.  Approximately 74% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-20-000004:notes:119]
The components of lease expense were as follows (in millions):

[0001069202-20-000004:notes:120]
|  | For the Year Ended December 31, 2019 |
| Finance lease cost: |  |
| Amortization of right-of-use assets | $ | 7.6 |  |
| Interest on lease liabilities | 0.9 |  |
| Operating lease cost | 59.7 |  |
| Short-term lease cost | 4.3 |  |
| Variable lease cost | 19.9 |  |
| Total lease cost | $ | 92.4 |  |
| Other information |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |
| Operating cash flows from operating leases | $ | 58.1 |  |
| Financing cash flows from finance leases | 6.4 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | 13.4 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | 51.5 |  |

[0001069202-20-000004:notes:121]
|  | As of December 31, 2019 |
| Finance lease right-of-use assets | $ | 28.4 |  |
| Operating lease right-of-use assets | $ | 181.6 |  |
| Finance lease liability, current | $ | 7.8 |  |
| Finance lease liability, non-current | $ | 25.9 |  |
| Operating lease liability, current | $ | 52.7 |  |
| Operating lease liability, non-current | $ | 131.0 |  |
| Weighted-average remaining lease term - finance leases | 4.9 years |  |
| Weighted-average remaining lease term - operating leases | 4.5 years |  |
| Weighted-average discount rate - finance leases | 2.71 | % |
| Weighted-average discount rate – operating leases | 3.69 | % |

[0001069202-20-000004:notes:122]
Future annual minimum lease payments and finance lease commitments as of December 31, 2019 were as follows (in millions):

[0001069202-20-000004:notes:123]
|  | Operating Leases |  | Finance Leases |
| 2020 | $ | 58.4 |  |  | $ | 8.4 |  |
| 2021 | 46.3 |  |  | 6.8 |  |
| 2022 | 33.8 |  |  | 4.9 |  |
| 2023 | 26.7 |  |  | 2.5 |  |
| 2024 | 17.0 |  |  | 0.6 |  |
| Thereafter | 17.1 |  |  | 11.7 |  |
| Total minimum lease payments | $ | 199.3 |  |  | $ | 34.9 |  |
| Less imputed interest | (15.6 | ) |  | (1.2 | ) |
| Present value of minimum payments | $ | 183.7 |  |  | $ | 33.7 |  |

[0001069202-20-000004:notes:124]
The Company adopted ASU 2016-02 on January 1, 2019 as noted above, and as required, the following disclosure is provided for periods prior to adoption. Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

[0001069202-20-000004:notes:125]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | (2.1 | ) |
| Present value of minimum payments |  |  | $ | 29.5 |  |

[0001069202-20-000004:notes:126]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024 (the “Lake Park Renewal”). The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, we are obligated to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance of $41.2 million, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 87% of the lease balance.  The headquarters lease is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-20-000004:notes:127]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of December 31, 2019.

[0001069202-20-000004:notes:128]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from industrial development bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and have outstanding letters of credit totaling $11.7 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the trustee.  We had finance lease obligations of $11.7 million related to these transactions as of December 31, 2019 and 2018.

[0001069202-20-000004:notes:129]
Environmental

[0001069202-20-000004:notes:130]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-20-000004:notes:131]
Product Warranties and Product Related Contingencies

[0001069202-20-000004:notes:132]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-20-000004:notes:133]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000004:notes:134]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Accrued expenses | $ | 38.2 |  |  | $ | 37.9 |  |
| Other liabilities | 74.6 |  |  | 73.7 |  |
| Total product warranty liabilities | $ | 112.8 |  |  | $ | 111.6 |  |

[0001069202-20-000004:notes:135]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2019 and 2018 were as follows (in millions):

[0001069202-20-000004:notes:136]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Payments made in 2018 | (31.6 | ) |
| Changes resulting from issuance of new warranties | 36.8 |  |
| Changes in estimates associated with pre-existing liabilities | (1.5 | ) |
| Changes in foreign currency translation rates and other | (0.8 | ) |
| Warranty liability from divestitures | (1.2 | ) |
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |
| Payments made in 2019 | (34.9 | ) |
| Changes resulting from issuance of new warranties | 44.1 |  |
| Changes in estimates associated with pre-existing liabilities | (7.6 | ) |
| Changes in foreign currency translation rates and other | — |  |
| Warranty liability from divestitures | (0.4 | ) |
| Total warranty liability as of December 31, 2019 | $ | 112.8 |  |

[0001069202-20-000004:notes:137]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the table above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001069202-20-000004:notes:138]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect was isolated, the vendor is supplying corrected components, and we are manufacturing products with the corrected components. We incurred and recorded insignificant expenses associated with this product quality issue in 2017. In the second quarter of 2019, the vendor agreed to reimburse us for certain losses incurred due to this quality issue.  These reimbursements include cash payments in 2019 and price reductions on annual qualifying purchases from this vendor through 2024.

[0001069202-20-000004:notes:139]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-20-000004:notes:140]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-20-000004:notes:141]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000004:notes:142]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Accrued expenses | $ | 5.2 |  |  | $ | 6.0 |  |
| Other liabilities | 19.4 |  |  | 19.5 |  |
| Total self-insurance liabilities | $ | 24.6 |  |  | $ | 25.5 |  |

[0001069202-20-000004:notes:143]
Litigation

[0001069202-20-000004:notes:144]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-20-000004:notes:145]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.

[0001069202-20-000004:notes:146]
Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the years ended December 31, 2019 and 2018, we estimated our probable liability for known cases at $10.2 million and $9.7 million, respectively, and these amounts were recorded in Accrued expenses in the Consolidated Balance Sheets. For the years ended December 31, 2019 and 2018, we estimated future asbestos-related litigation cases to be $22.1 million and $19.3 million, respectively, before consideration of probable insurance recoveries and these amounts were recorded in Other liabilities in the Consolidated Balance Sheets.  For the years ended December 31, 2019, 2018 and 2017, we recorded expense of $3.1 million, $4.0 million and $3.5 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-20-000004:notes:147]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.

[0001069202-20-000004:notes:148]
Marshalltown Tornado and Recovery

[0001069202-20-000004:notes:149]
On July 19, 2018, our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  We have insurance for the repair or replacement of our assets that suffered damage or loss, and we worked closely with our insurance carriers and claims adjusters to ascertain the amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.

[0001069202-20-000004:notes:150]
For the years ended December 31, 2019 and 2018, we incurred expenses and losses of $64.4 million and $86.0 million, respectively, related to damages caused by the tornado.  These amounts included site clean-up and demolition, factory inefficiencies, freight to move product to other warehouses, professional fees, and sales and marketing promotional costs.

[0001069202-20-000004:notes:151]
In December 2019, we reached a final settlement with our insurance carriers for the losses we suffered from the tornado.  The settlement allowed for total cumulative insurance recoveries of $367.5 million, of which $243.2 million and $124.3 million were received in the years ended December 31, 2019 and 2018, respectively.

[0001069202-20-000004:notes:152]
These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.  The following table summarizes the Gain from insurance recoveries, net of losses incurred:

[0001069202-20-000004:notes:153]
| (Amounts in millions) | For the Year Ended December 31, |
|  | 2019 |  | 2018 |
| Insurance recoveries received | $ | 243.2 |  |  | $ | 124.3 |  |
| Less losses and expenses incurred: |  |  |  |
| Site clean-up and remediation | 20.4 |  |  | 50.9 |  |
| Factory inefficiencies due to lower productivity | 9.3 |  |  | 7.4 |  |
| Write-off of property, plant and equipment | — |  |  | 4.2 |  |
| Write-off of inventory | — |  |  | 5.8 |  |
| Other | 34.7 |  |  | 17.7 |  |
| Total losses and expenses | $ | 64.4 |  |  | $ | 86.0 |  |
| Gain from insurance recoveries, net of losses incurred | $ | 178.8 |  |  | $ | 38.3 |  |
| Components of Gain from insurance recoveries, net of losses incurred: |  |  |  |
| Insurance proceeds for lost profits | 99.2 |  |  | 27.4 |  |
| Insurance proceeds for property damage incurred from natural disaster | 79.6 |  |  | 10.9 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-20-000004:notes:154]
Our Board of Directors have authorized a total of $3 billion to repurchase shares of our common stock , including an incremental $500 million share repurchase authorization in December 2019, under our Share Repurchase Plans. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2019, $546 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-20-000004:notes:155]
We repurchased 0.4 million shares for $100.0 million during the first quarter of 2019, 0.6 million shares for $150.0 million during the second quarter of 2019 and 0.5 million shares for $150.0 million during the third quarter of 2019, respectively, from open market transactions.

[0001069202-20-000004:notes:156]
We also repurchased 0.1 million  shares for $24.0 million and 0.1 million shares for $26.9 million for the years ended December 31, 2019 and 2018, respectively, from employees who tendered their shares to satisfy minimum tax withholding obligation upon the vesting of stock-based compensation awards.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-20-000004:notes:157]
During the first quarter of 2019, we obtained Board of Directors’ approval and signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. The sale was completed on March 29, 2019. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-20-000004:notes:158]
| (Amounts in millions) | For the Year Ended December 31, 2019 |
| Cash received from the buyer | $ | 49.0 |  |
| Net assets sold | (52.0 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (2.1 | ) |
| Direct costs to sell | (5.5 | ) |
| Loss on sale of business | $ | (10.6 | ) |

[0001069202-20-000004:notes:159]
2018 Divestitures:

[0001069202-20-000004:notes:160]
Australia and Asia Divestiture

[0001069202-20-000004:notes:161]
During the first quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia and Asia business except for the Milperra property.  The Milperra property was sold to another purchaser during the second quarter of 2018. We completed the sale to Beijer Ref AB in the second quarter of 2018 with the final post-completion adjustment being recorded in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-20-000004:notes:162]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 82.9 |  |
| Net assets sold (1) | (87.2 | ) |
| AOCL reclassification adjustments, primarily foreign currency translation | (3.2 | ) |
| Direct costs to sell | (5.8 | ) |
| Loss on sale of business | $ | (13.3 | ) |

[0001069202-20-000004:notes:163]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia and Asia business.

[0001069202-20-000004:notes:164]
The Milperra property was sold during the quarter ended June 30, 2018. We received net cash proceeds of $37.2 million net of direct costs to sell of $1.5 million. The net gain recognized in connection with this sale was $23.8 million.

[0001069202-20-000004:notes:165]
South America Divestiture

[0001069202-20-000004:notes:166]
During the second quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale was subject to Brazilian antitrust approval.  We obtained antitrust approval and completed the sale to Elgin SA in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-20-000004:notes:167]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 4.2 |  |
| Net assets sold (2) | (14.1 | ) |
| AOCL reclassification adjustments, primarily foreign currency translation | (24.7 | ) |
| Direct costs to sell | (2.9 | ) |
| Loss on sale of business | $ | (37.5 | ) |

[0001069202-20-000004:notes:168]
(2) Includes $1.2 of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our South America business.

[0001069202-20-000004:notes:169]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations of $10.6 million for the year ended December 31, 2019 is comprised of the loss on the sale of the Kysor Warren business.  The total Loss (gain), net on sale of businesses and related property for the year ended December 31, 2018 of $27.0 million is comprised of the $13.3 million loss on the sale of our Australia and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $37.5 million loss on the sale of our South America business.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-20-000004:notes:170]
The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-20-000004:notes:171]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia and Asia business.
 following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-20-000004:notes:172]
record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.

[0001069202-20-000004:notes:173]
Restructuring Activities in 2019

[0001069202-20-000004:notes:174]
In the third quarter of 2019, the Commercial Heating & Cooling and Corporate segments incurred restructuring charges primarily related to activities to re-align resources and its product portfolio. In the fourth quarter of 2019, the Residential Heating & Cooling and Commercial Heating & Cooling segments incurred restructuring charges, primarily related to activities to close certain Lennox Stores and related to reductions of management and support staff.

[0001069202-20-000004:notes:175]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-20-000004:notes:176]
|  | Incurred in 2019 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 2.9 |  |  | $ | 5.3 |  |  | $ | 5.4 |  |
| Asset write-offs and accelerated depreciation | 5.6 |  |  | 5.6 |  |  | 5.6 |  |
| Accelerated depreciation on right-of-use assets from operating leases | 1.2 |  |  | 1.9 |  |  | 1.9 |  |
| Other | 0.6 |  |  | 0.6 |  |  | 1.6 |  |
| Total | $ | 10.3 |  |  | $ | 13.4 |  |  | $ | 14.5 |  |

[0001069202-20-000004:notes:177]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-20-000004:notes:178]
The following table disaggregates our revenue by business segment by geography which provides information as to the major sources of revenue.  See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001069202-20-000004:notes:179]
|  | For the Year Ended December 31, 2019 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,135.6 |  |  | $ | 847.1 |  |  | $ | 321.9 |  |  | $ | 3,304.6 |  |
| Canada | 155.5 |  |  | 98.5 |  |  | 0.7 |  |  | 254.7 |  |
| International | — |  |  | 1.8 |  |  | 246.1 |  |  | 247.9 |  |
| Total | $ | 2,291.1 |  |  | $ | 947.4 |  |  | $ | 568.7 |  |  | $ | 3,807.2 |  |

[0001069202-20-000004:notes:180]
|  | For the Year Ended December 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,066.7 |  |  | $ | 805.4 |  |  | $ | 403.2 |  |  | $ | 3,275.3 |  |
| Canada | 158.3 |  |  | 92.7 |  |  | 4.5 |  |  | 255.5 |  |
| International | — |  |  | 2.6 |  |  | 350.5 |  |  | 353.1 |  |
| Total | $ | 2,225.0 |  |  | $ | 900.7 |  |  | $ | 758.2 |  |  | $ | 3,883.9 |  |

[0001069202-20-000004:notes:181]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001069202-20-000004:notes:182]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001069202-20-000004:notes:183]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the years ended December 31, 2019 and 2018, direct sales represented 75% and 76% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-20-000004:notes:184]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.

[0001069202-20-000004:notes:185]
For the years ended December 31, 2019 and 2018, equipment sales represented 86% of revenues and the remainder of our revenue was generated from our service business.

[0001069202-20-000004:notes:186]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Approximately 1% of segment revenue relates to services for start-up and commissioning activities.

[0001069202-20-000004:notes:187]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-20-000004:notes:188]
Other Judgments and Assumptions - On January 1, 2018, we adopted Accounting Standards Update No.2014-09, Revenue from Contracts with Customers (Topic 606), as amended and applied it to all contracts using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as a $1.0 million reduction in the January 1, 2018, balance of retained earnings.We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-20-000004:notes:189]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001069202-20-000004:notes:190]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001069202-20-000004:notes:191]
Net contract assets (liabilities) consisted of the following:

[0001069202-20-000004:notes:192]
|  | December 31, 2019 |  | December 31, 2018 |  | $ Change |  | % Change |
| Contract assets | $ | — |  |  | $ | 2.5 |  |  | $ | (2.5 | ) |  | (100.0 | )% |
| Contract liabilities - current | (8.4 | ) |  | (13.0 | ) |  | 4.6 |  |  | (35.4 | )% |
| Contract liabilities - noncurrent | (5.9 | ) |  | (5.9 | ) |  | — |  |  | — | % |
| Total | $ | (14.3 | ) |  | $ | (16.4 | ) |  | $ | 2.1 |  |  |  |

[0001069202-20-000004:notes:193]
For the years ended December 31, 2019 and 2018, we recognized revenue of $3.3 million and $4.8 million related to our contract liabilities at January 1, 2019 and 2018, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2018 and 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-20-000004:notes:194]
The components of inventories are as follows (in millions):

[0001069202-20-000004:notes:195]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Finished goods | $ | 402.9 |  |  | $ | 330.5 |  |
| Work in process | 6.0 |  |  | 10.0 |  |
| Raw materials and parts | 198.8 |  |  | 229.1 |  |
| Total | 607.7 |  |  | 569.6 |  |
| Excess of current cost over last-in, first-out cost | (63.6 | ) |  | (59.8 | ) |
| Total inventories, net | $ | 544.1 |  |  | $ | 509.8 |  |

[0001069202-20-000004:notes:196]
The Company recorded a pre-tax gain of $0.2 million in 2019 and no pre-tax gains or losses in 2018 or 2017 from LIFO inventory liquidations.  Reserves for obsolete and slow-moving inventories were $19.2 million and $16.5 million at December 31, 2019 and December 31, 2018, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-20-000004:notes:197]
The changes in the carrying amount of goodwill in 2019 and 2018, in total and by segment, are summarized in the table below (in millions):

[0001069202-20-000004:notes:198]
| Segment: | Balance at December 31, 2017 (1) |  | Write-off due to divested businesses |  | Changes in foreign currency translation rates |  | Balance at December 31, 2018 |  | Goodwill Reallocation (2) |  | Changes in foreign currency translation rates |  | Balance at December 31, 2019 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.2 |  |  | — |  |  | (0.8 | ) |  | 61.4 |  |  | (0.3 | ) |  | — |  |  | 61.1 |  |
| Refrigeration | 112.2 |  |  | (11.5 | ) |  | (1.6 | ) |  | 99.1 |  |  | 0.3 |  |  | (0.1 | ) |  | 99.3 |  |
|  | $ | 200.5 |  |  | $ | (11.5 | ) |  | $ | (2.4 | ) |  | $ | 186.6 |  |  | $ | — |  |  | $ | (0.1 | ) |  | $ | 186.5 |  |

[0001069202-20-000004:notes:199]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $21.2 million, all of which relate to impairments in periods prior to 2017.

[0001069202-20-000004:notes:200]
(2) In 2019, we reorganized our external financial reporting structure by moving our European Commercial HVAC business from our Commercial segment to our Refrigeration segment as we manage both our commercial HVAC and refrigeration operations in Europe together. See Note 3 for additional information.

[0001069202-20-000004:notes:201]
A qualitative review of impairment indicators was performed in 2019 for the Residential Heating & Cooling, the Commercial Heating & Cooling, and the Refrigeration segments.  Based on our impairment review, we did not record any goodwill impairments in 2019.

[0001069202-20-000004:notes:202]
In 2018, we de-recognized $11.5 million of goodwill as a part of the completed sales of our Australia, Asia and South America businesses as discussed further in Note 7. We did not de-recognize any goodwill in 2017 or 2019 and we did not record any goodwill impairments related to continuing operations in 2017, 2018 or 2019.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-20-000004:notes:203]
In 2018, we impaired $4 million of property, plant and equipment at our Marshalltown facility that was damaged by a tornado.  Refer to Note 5 for more information on the damage to our Marshalltown facility.  No impairment charges were recorded in 2019 or 2017.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-20-000004:notes:204]
Accrued Expenses

[0001069202-20-000004:notes:205]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-20-000004:notes:206]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Accrued rebates and promotions | $ | 70.1 |  |  | $ | 70.8 |  |
| Accrued compensation and benefits | 70.4 |  |  | 69.0 |  |
| Accrued warranties | 38.2 |  |  | 37.9 |  |
| Accrued sales, use, property and VAT taxes | 18.6 |  |  | 20.7 |  |
| Deferred income | 8.4 |  |  | 13.0 |  |
| Derivative contracts | 2.9 |  |  | 10.2 |  |
| Accrued asbestos reserves | 10.2 |  |  | 9.7 |  |
| Self insurance reserves | 5.2 |  |  | 6.0 |  |
| Other | 31.7 |  |  | 35.0 |  |
| Total Accrued expenses | $ | 255.7 |  |  | $ | 272.3 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-20-000004:notes:207]
Objectives and Strategies for Using Derivative Instruments

[0001069202-20-000004:notes:208]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-20-000004:notes:209]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-20-000004:notes:210]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-20-000004:notes:211]
Cash Flow Hedges

[0001069202-20-000004:notes:212]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2021 and January 2021, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001069202-20-000004:notes:213]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001069202-20-000004:notes:214]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Unrealized losses on unsettled contracts | $ | 0.2 |  |  | $ | 8.4 |  |
| Income tax benefit | (0.2 | ) |  | (2.2 | ) |
| Losses included in AOCL, net of tax (1) | $ | — |  |  | $ | 6.2 |  |

[0001069202-20-000004:notes:215]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $0.3 million of derivative losses into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-20-000004:notes:216]
Expenses included in our Consolidated Statements of Operations

[0001069202-20-000004:notes:217]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001069202-20-000004:notes:218]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Research and development | $ | 69.9 |  |  | $ | 72.2 |  |  | $ | 73.6 |  |
| Advertising, promotions and marketing (1) | 43.7 |  |  | 42.5 |  |  | 45.0 |  |
| Cooperative advertising expenditures | 21.3 |  |  | 16.8 |  |  | 18.6 |  |

[0001069202-20-000004:notes:219]
(1) Cooperative advertising expenditures were not included in these amounts.

[0001069202-20-000004:notes:220]
Interest Expense, net

[0001069202-20-000004:notes:221]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-20-000004:notes:222]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest | $ | 48.6 |  |  | $ | 39.1 |  |  | $ | 32.1 |  |
| Interest income | 1.1 |  |  | 0.8 |  |  | 1.5 |  |
| Interest expense, net | $ | 47.5 |  |  | $ | 38.3 |  |  | $ | 30.6 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001069202-20-000004:notes:223]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-20-000004:notes:224]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Realized losses (gains) on settled futures contracts | $ | 0.4 |  |  | $ | (0.4 | ) |  | $ | (1.7 | ) |
| Foreign currency exchange (gains) losses | (1.5 | ) |  | 1.7 |  |  | (1.8 | ) |
| (Gains) losses on disposal of fixed assets | (0.2 | ) |  | 0.7 |  |  | 0.2 |  |
| Other operating (gains) losses | (1.7 | ) |  | — |  |  | — |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.5 | ) |  | 1.5 |  |  | 0.9 |  |
| Asbestos-related litigation | 3.1 |  |  | 4.0 |  |  | 3.5 |  |
| Special legal contingency charges | 1.2 |  |  | 1.9 |  |  | 3.7 |  |
| Environmental liabilities | 5.7 |  |  | 2.2 |  |  | 2.2 |  |
| Contractor tax payments | — |  |  | — |  |  | 0.1 |  |
| Other items, net | 1.8 |  |  | 1.8 |  |  | — |  |
| Losses (gains) and other expenses, net | $ | 8.3 |  |  | $ | 13.4 |  |  | $ | 7.1 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001069202-20-000004:notes:225]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-20-000004:notes:226]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |
| Federal | $ | 55.9 |  |  | $ | 59.5 |  |  | $ | 86.1 |  |
| State | 14.2 |  |  | 17.8 |  |  | 12.5 |  |
| Foreign | 9.3 |  |  | 4.6 |  |  | 15.0 |  |
| Total current | 79.4 |  |  | 81.9 |  |  | 113.6 |  |
| Deferred: |  |  |  |  |  |
| Federal | 15.0 |  |  | 23.2 |  |  | 43.8 |  |
| State | 3.9 |  |  | 1.0 |  |  | 0.9 |  |
| Foreign | 0.8 |  |  | 1.5 |  |  | (1.4 | ) |
| Total deferred | 19.7 |  |  | 25.7 |  |  | 43.3 |  |
| Total provision for income taxes | $ | 99.1 |  |  | $ | 107.6 |  |  | $ | 156.9 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-20-000004:notes:227]
Losses (Gains) and Other Expenses, net


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-20-000004:notes:228]
efined Contribution Plans

[0001069202-20-000004:notes:229]
We recorded the following contributions to the defined contribution plans (in millions):

[0001069202-20-000004:notes:230]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Contributions to defined contribution plans | $ | 19.1 |  |  | $ | 18.8 |  |  | $ | 18.1 |  |

[0001069202-20-000004:notes:231]
Pension and Post-retirement Benefit Plans

[0001069202-20-000004:notes:232]
Pension Settlement Activity in 2019

[0001069202-20-000004:notes:233]
On April 3, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $100.0 million of our pension plan assets and $105.6 million of related pension benefit obligations.  In the second quarter of 2019, we recognized a $60.6 million pension settlement charge in the Statement of Operations and reclassified $5.6 million of pension benefit obligations to AOCL as a result of this transaction.

[0001069202-20-000004:notes:234]
On October 15, 2019, we entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer $73.5 million of our pension plan assets and $77.9 million of related benefit obligations.  In the fourth quarter of 2019, we recognized a $38.6 million pension settlement charge in the Statement of Operations and reclassified $4.4 million of pension benefit obligations to AOCL as a result of this transaction.

[0001069202-20-000004:notes:235]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001069202-20-000004:notes:236]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-20-000004:notes:237]
|  | Pension Benefits |
|  | 2019 |  | 2018 |
| Accumulated benefit obligation | $ | 237.3 |  |  | $ | 368.0 |  |
| Changes in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 371.9 |  |  | $ | 405.5 |  |
| Service cost | 4.9 |  |  | 5.3 |  |
| Interest cost | 10.2 |  |  | 12.3 |  |
| Other | — |  |  | 0.3 |  |
| Actuarial (gain) loss | 38.9 |  |  | (26.4 | ) |
| Effect of exchange rates | 1.1 |  |  | (2.7 | ) |
| Settlements | (173.5 | ) |  | (1.3 | ) |
| Benefits paid | (12.0 | ) |  | (21.1 | ) |
| Benefit obligation at end of year | $ | 241.5 |  |  | $ | 371.9 |  |
| Changes in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 291.0 |  |  | $ | 318.6 |  |
| Actual gain (loss) return on plan assets | 45.7 |  |  | (23.3 | ) |
| Employer contributions | 1.8 |  |  | 20.6 |  |
| Effect of exchange rates | 1.3 |  |  | (2.5 | ) |
| Plan settlements | (173.5 | ) |  | (1.3 | ) |
| Benefits paid | (12.0 | ) |  | (21.1 | ) |
| Fair value of plan assets at end of year | 154.3 |  |  | 291.0 |  |
| Funded status / net amount recognized | $ | (87.2 | ) |  | $ | (80.9 | ) |
| Net amount recognized consists of: |  |  |  |
| Non-current assets | $ | 3.5 |  |  | $ | 3.3 |  |
| Current liability | (3.3 | ) |  | (1.4 | ) |
| Non-current liability | (87.4 | ) |  | (82.8 | ) |
| Net amount recognized | $ | (87.2 | ) |  | $ | (80.9 | ) |

[0001069202-20-000004:notes:238]
Plans with Benefit Obligations in Excess of Plan Assets

[0001069202-20-000004:notes:239]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 204.5 |  |  | $ | 357.2 |  |
| Accumulated benefit obligation | 200.5 |  |  | 353.4 |  |
| Fair value of plan assets | 113.9 |  |  | 275.0 |  |

[0001069202-20-000004:notes:240]
Net Periodic Benefit Cost

[0001069202-20-000004:notes:241]
Our U.S.-based pension plans comprised approximately 81%  of the projected benefit obligation and 74% of plan assets as of December 31, 2019.

[0001069202-20-000004:notes:242]
|  | Pension Benefits |
|  | 2019 |  | 2018 |  | 2017 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |
| Service cost | $ | 4.9 |  |  | $ | 5.3 |  |  | $ | 5.0 |  |
| Interest cost | 10.2 |  |  | 12.3 |  |  | 12.6 |  |
| Expected return on plan assets | (13.4 | ) |  | (18.8 | ) |  | (21.3 | ) |
| Amortization of prior service costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Recognized actuarial loss | 5.6 |  |  | 9.2 |  |  | 8.1 |  |
| Settlements | 99.2 |  |  | 0.4 |  |  | — |  |
| Other | (0.5 | ) |  | 0.3 |  |  | 0.7 |  |
| Net periodic benefit cost | $ | 106.1 |  |  | $ | 8.8 |  |  | $ | 5.3 |  |

[0001069202-20-000004:notes:243]
Amounts recognized in AOCL and Other Comprehensive Income

[0001069202-20-000004:notes:244]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2019 and 2018 (in millions):

[0001069202-20-000004:notes:245]
|  | Pension Benefits |
|  | 2019 |  | 2018 |
| Amounts recognized in AOCL: |  |  |  |
| Prior service costs | $ | (0.8 | ) |  | $ | (0.9 | ) |
| Actuarial loss | (101.6 | ) |  | (199.4 | ) |
| Subtotal | (102.4 | ) |  | (200.3 | ) |
| Deferred taxes | 24.7 |  |  | 49.5 |  |
| Net amount recognized | $ | (77.7 | ) |  | $ | (150.8 | ) |
| Changes recognized in other comprehensive (loss) income: |  |  |  |
| Current year prior service costs | — |  |  | 0.3 |  |
| Current year actuarial (gain) loss | (5.1 | ) |  | 15.7 |  |
| Effect of exchange rates | 0.5 |  |  | (1.1 | ) |
| Amortization of prior service costs | (0.1 | ) |  | (0.1 | ) |
| Amortization of actuarial loss, including settlements | (93.1 | ) |  | (9.9 | ) |
| Total recognized in other comprehensive (loss) income | $ | (97.8 | ) |  | $ | 4.9 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 8.3 |  |  | $ | 13.7 |  |

[0001069202-20-000004:notes:246]
The estimated prior service costs and actuarial losses for pension benefits that will be amortized from AOCL in 2020 are $0.2 million and $5.4 million, respectively.

[0001069202-20-000004:notes:247]
Assumptions

[0001069202-20-000004:notes:248]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2019 and 2018:

[0001069202-20-000004:notes:249]
|  |  | Pension Benefits |
|  |  | 2019 |  | 2018 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |
| Discount rate |  | 3.19 | % |  | 4.32 | % |
| Rate of compensation increase |  | 4.23 | % |  | 4.23 | % |

[0001069202-20-000004:notes:250]
|  | Pension Benefits |
|  | 2019 |  | 2018 |  | 2017 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 3.96 | % |  | 3.48 | % |  | 3.96 | % |
| Discount rate - interest cost | 3.67 | % |  | 3.22 | % |  | 3.51 | % |
| Expected long-term return on plan assets | 6.50 | % |  | 6.50 | % |  | 7.50 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |

[0001069202-20-000004:notes:251]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2019 and 2018:

[0001069202-20-000004:notes:252]
|  | Pension Benefits |
|  | 2019 |  | 2018 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 2.15 | % |  | 2.93 | % |
| Rate of compensation increase | 3.20 | % |  | 3.77 | % |

[0001069202-20-000004:notes:253]
|  | Pension Benefits |
|  | 2019 |  | 2018 |  | 2017 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 1.60 | % |  | 1.32 | % |  | 1.34 | % |
| Discount rate - interest cost | 2.98 | % |  | 2.67 | % |  | 2.75 | % |
| Expected long-term return on plan assets | 3.92 | % |  | 4.19 | % |  | 4.40 | % |
| Rate of compensation increase | 3.77 | % |  | 3.62 | % |  | 3.78 | % |

[0001069202-20-000004:notes:254]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 6.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-20-000004:notes:255]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and OPEB plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001069202-20-000004:notes:256]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-20-000004:notes:257]
|  | 2019 |  | 2018 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2022 |  |  | 2022 |  |

[0001069202-20-000004:notes:258]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-20-000004:notes:259]
|  | For the Years Ended December 31, |
|  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025-2029 |
| Pension benefits | $ | 6.0 |  |  | $ | 11.5 |  |  | $ | 6.2 |  |  | $ | 7.0 |  |  | $ | 11.7 |  |  | $ | 92.6 |  |

[0001069202-20-000004:notes:260]
Composition of Pension Plan Assets

[0001069202-20-000004:notes:261]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the fourth quarter of 2019, we changed the targeted allocations for our plan assets. The targeted allocation for fixed income and cash investments was changed to 50%, and the targeted allocation for equity investments was changed to 50%. Our targeted exposure to International equity including emerging markets was changed to 6.0% of total assets and our exposure to domestic equity was changed to 44.0%. Our U.S. pension plan represents 74%, our Canadian pension plan 12%, and our United Kingdom (“U.K.”) pension plan 14% of the total fair value of our plan assets as of December 31, 2019.

[0001069202-20-000004:notes:262]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2019 and 2018, by asset category, were as follows:

[0001069202-20-000004:notes:263]
|  | Plan Assets as of December 31, |
| Asset Category: | 2019 |  | 2018 |
| U.S. equity | 44.6 | % |  | 24.6 | % |
| International equity | 7.3 | % |  | 15.5 | % |
| Fixed income | 48.0 | % |  | 57.2 | % |
| Money market/cash | 0.1 | % |  | 2.7 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-20-000004:notes:264]
Our U.S. pension plans’ assets were invested according to the following targets:

[0001069202-20-000004:notes:265]
| Asset Category: | Target |
| U.S. equity | 44.0 | % |
| International equity | 6.0 | % |
| Fixed income | 50.0 | % |

[0001069202-20-000004:notes:266]
Our Canadian pension plans were invested approximately 73% in Canadian bonds and 27% in international equities. Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001069202-20-000004:notes:267]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001069202-20-000004:notes:268]
|  | Fair Value Measurements as of December 31, 2019 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 50.8 |  |  | — |  |  | 50.8 |  |
| International equity (2) | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |
| Fixed income (3) | — |  |  | 54.6 |  |  | — |  |  | 54.6 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.8 |  |  | — |  |  | 4.8 |  |
| Fixed income | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Pension fund: |  |  |  |  |  |  |  |
| Fixed income (6) | — |  |  | 22.0 |  |  | — |  |  | 22.0 |  |
| Total | $ | 0.2 |  |  | $ | 154.1 |  |  | $ | — |  |  | $ | 154.3 |  |

[0001069202-20-000004:notes:269]
|  | Fair Value Measurements as of December 31, 2018 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 7.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 62.7 |  |  | — |  |  | 62.7 |  |
| International equity (2) | — |  |  | 39.5 |  |  | — |  |  | 39.5 |  |
| Fixed income (3) | — |  |  | 146.2 |  |  | — |  |  | 146.2 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| Fixed income | — |  |  | 12.0 |  |  | — |  |  | 12.0 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Fixed income (6) | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Blend (7) | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |
| Total | $ | 7.2 |  |  | $ | 283.8 |  |  | $ | — |  |  | $ | 291.0 |  |

[0001069202-20-000004:notes:270]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-20-000004:notes:271]
|  | As of December 31, 2019 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 50.8 |  |  | Daily |  | 5 days |
| International equity (2) | 8.3 |  |  | Daily |  | 5 days |
| Fixed income (3) | 54.6 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.8 |  |  | Daily |  | 3-5 days |
| Fixed income | 13.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (6) | 22.0 |  |  | Daily |  | 1-3 days |
| Total | $ | 154.1 |  |  |  |  |  |

[0001069202-20-000004:notes:272]
|  | As of December 31, 2018 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 62.7 |  |  | Daily |  | 5 days |
| International equity (2) | 39.5 |  |  | Daily |  | 5 days |
| Fixed income (3) | 146.2 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.0 |  |  | Daily |  | 3-5 days |
| Fixed income | 12.0 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 2.7 |  |  | Daily |  | 1-3 days |
| Fixed income (6) | 8.9 |  |  | Daily |  | 1-3 days |
| Blend (7) | 7.8 |  |  | Daily |  | 1-3 days |
| Total | $ | 283.8 |  |  |  |  |  |

[0001069202-20-000004:notes:273]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (5) | This category includes investments in international equity securities, a portion of which may be invested in U.S. securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. |
| (7) | This category includes investments in pooled funds where the fund manager has discretion for the asset allocation and can invest in a wide range of international and US asset classes including equity, credit markets, sovereign debt and alternative assets (including derivative-based strategies). |

[0001069202-20-000004:notes:274]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 17 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-20-000004:notes:275]
participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-20-000004:notes:276]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-20-000004:notes:277]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Equity method investments | $ | 38.6 |  |  | $ | 36.6 |  |

[0001069202-20-000004:notes:278]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-20-000004:notes:279]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Purchases of compressors from joint venture | $ | 123.1 |  |  | $ | 103.1 |  |  | $ | 106.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-20-000004:notes:280]
r Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-20-000004:notes:281]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-20-000004:notes:282]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Domestic | $ | 383.2 |  |  | $ | 428.7 |  |  | $ | 402.5 |  |
| Foreign | 124.7 |  |  | 39.2 |  |  | 61.5 |  |
| Total | $ | 507.9 |  |  | $ | 467.9 |  |  | $ | 464.0 |  |

[0001069202-20-000004:notes:283]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-20-000004:notes:284]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Provision at the U.S. statutory rate of 21% (35% for 2017) | $ | 106.7 |  |  | $ | 98.3 |  |  | $ | 162.4 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 13.2 |  |  | 15.5 |  |  | 9.2 |  |
| Domestic manufacturing deduction | — |  |  | — |  |  | (9.6 | ) |
| Tax credits, net of unrecognized tax benefits | (13.8 | ) |  | (2.5 | ) |  | (8.6 | ) |
| Change in unrecognized tax benefits | 3.1 |  |  | 0.4 |  |  | (0.1 | ) |
| Change in valuation allowance | 1.9 |  |  | 5.0 |  |  | 6.4 |  |
| Foreign taxes at rates other than U.S. statutory rate | (20.7 | ) |  | (3.2 | ) |  | (9.0 | ) |
| Deemed inclusions | 8.3 |  |  | 3.9 |  |  | 0.3 |  |
| Global intangible low-taxed income | 9.5 |  |  | 0.7 |  |  | — |  |
| Change in rates from the Tax Act & other law changes | (0.8 | ) |  | 1.9 |  |  | 31.8 |  |
| Excess tax benefits from stock-based compensation | (10.9 | ) |  | (10.5 | ) |  | (23.6 | ) |
| Miscellaneous other | 2.6 |  |  | (1.9 | ) |  | (2.3 | ) |
| Total provision for income taxes | $ | 99.1 |  |  | $ | 107.6 |  |  | $ | 156.9 |  |

[0001069202-20-000004:notes:285]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-20-000004:notes:286]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-20-000004:notes:287]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 27.8 |  |  | $ | 27.8 |  |
| Loss carryforwards (foreign, U.S. and state) | 23.2 |  |  | 23.1 |  |
| Post-retirement and pension benefits | 22.4 |  |  | 21.3 |  |
| Inventory reserves | 5.6 |  |  | 9.3 |  |
| Receivables allowance | 3.1 |  |  | 3.4 |  |
| Compensation liabilities | 6.2 |  |  | 7.9 |  |
| Insurance liabilities | 1.6 |  |  | 2.9 |  |
| Legal reserves | 8.5 |  |  | 7.4 |  |
| Tax credits, net of federal effect | 11.4 |  |  | 11.0 |  |
| Other | 7.1 |  |  | 8.1 |  |
| Total deferred tax assets | 116.9 |  |  | 122.2 |  |
| Valuation allowance | (24.9 | ) |  | (25.4 | ) |
| Total deferred tax assets, net of valuation allowance | 92.0 |  |  | 96.8 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (52.5 | ) |  | (22.1 | ) |
| Intangibles | (15.1 | ) |  | (5.4 | ) |
| Other | (2.9 | ) |  | (2.3 | ) |
| Total deferred tax liabilities | (70.5 | ) |  | (29.8 | ) |
| Net deferred tax assets | $ | 21.5 |  |  | $ | 67.0 |  |

[0001069202-20-000004:notes:288]
As of December 31, 2019 and 2018, we had $0.1 million and $0.6 million in tax-effected state net operating loss carryforwards, respectively, and $14.9 million and $12.6 million  in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in European tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits.

[0001069202-20-000004:notes:289]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2019.

[0001069202-20-000004:notes:290]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001069202-20-000004:notes:291]
We are currently under examination for our U.S. federal income taxes for 2019 and 2018 and are subject to examination by numerous other taxing authorities in the U.S. and foreign jurisdictions.  We are generally no longer subject to U.S., state and local or non-U.S. income tax examinations by taxing authorities for years before 2012.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001069202-20-000004:notes:292]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000004:notes:293]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 285.0 |  |  | $ | 268.0 |  |
| Finance lease obligations | 7.8 |  |  | 3.5 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.9 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 321.9 |  |  | $ | 300.8 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 25.9 |  |  | 15.7 |  |
| Domestic credit facility | 475.5 |  |  | 378.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (2.1 | ) |  | (3.2 | ) |
| Total long-term debt | $ | 849.3 |  |  | $ | 740.5 |  |
| Total debt | $ | 1,171.2 |  |  | $ | 1,041.3 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-20-000004:notes:294]
e following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-20-000004:notes:295]
As of December 31, 2019, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-20-000004:notes:296]
| 2020 | $ | 322.8 |  |
| 2021 | 481.9 |  |
| 2022 | 4.7 |  |
| 2023 | 352.5 |  |
| 2024 | 0.6 |  |
| Thereafter | 11.7 |  |

[0001069202-20-000004:notes:297]
Short-Term Debt

[0001069202-20-000004:notes:298]
Foreign Obligations

[0001069202-20-000004:notes:299]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. As of December 31, 2019 or 2018, we did not have any outstanding short-term foreign obligations.  Proceeds from these facilities were $5.3 million, $40.3 million and $30.4 million during the years ended December 31, 2019, 2018 and 2017, respectively. Repayments on the facilities were $5.3 million, $40.3 million and $31.9 million during the years ended December 31, 2019, 2018 and 2017, respectively.

[0001069202-20-000004:notes:300]
Asset Securitization Program

[0001069202-20-000004:notes:301]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheet and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-20-000004:notes:302]
We renewed the ASP in November 2019, extending its term to November 2021 and increasing the maximum securitization amount to a range from $250.0 million to $400.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-20-000004:notes:303]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 320.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (285.0 | ) |  | (268.0 | ) |
| Remaining amount available | $ | 35.0 |  |  | $ | 22.0 |  |

[0001069202-20-000004:notes:304]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of December 31, 2019 and 2018 were 2.51% and 3.27%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at rate ranging between 0.25% and 0.35%, depending on available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-20-000004:notes:305]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement (“Domestic Credit Facility”), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings.  As of December 31, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-20-000004:notes:306]
Long-Term Debt

[0001069202-20-000004:notes:307]
Domestic Credit Facility

[0001069202-20-000004:notes:308]
On January 22, 2019, we amended our Domestic Credit Facility to provide for a $350.0 million increase in revolving commitments.  The Domestic Credit Facility currently consists of a $1,000.0 million unsecured revolving credit facility and a $160.0 million unsecured term loan that matures in August 2021 (the “Maturity Date”). Under our Domestic Credit Facility, we had outstanding borrowings of $505.5 million, of which $160.0 million was the term loan balance, as well as $2.4 million committed to standby letters of credit as of December 31, 2019. Subject to covenant limitations, $652.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.

[0001069202-20-000004:notes:309]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-20-000004:notes:310]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Weighted average borrowing rate | 2.93 | % |  | 3.74 | % |

[0001069202-20-000004:notes:311]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-20-000004:notes:312]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-20-000004:notes:313]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-20-000004:notes:314]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or |

[0001069202-20-000004:notes:315]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-20-000004:notes:316]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-20-000004:notes:317]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2019, we believe we were in compliance with all covenant requirements.

[0001069202-20-000004:notes:318]
Senior Unsecured Notes

[0001069202-20-000004:notes:319]
We issued $350.0 million of senior unsecured notes in November 2016 (the “Notes”) which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually. The Notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2019, we believe we were in compliance with all covenant requirements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001069202-20-000004:notes:320]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-20-000004:notes:321]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2019 |  | 2018 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | (6.9 | ) |  | $ | 6.1 |  |  | Cost of goods sold and Losses (gains) and other expenses, net. |
| Income tax benefit (expense) |  | 1.6 |  |  | (1.4 | ) |  | Provision for income taxes |
| Net of tax |  | $ | (5.3 | ) |  | $ | 4.7 |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (5.7 | ) |  | $ | (9.3 | ) |  | Cost of goods sold; Selling, general, administrative expenses and Other (income) expense, net |
| Pension settlements |  | (99.2 | ) |  | (0.4 | ) |  | Pension settlements |
| Income tax benefit |  | 26.2 |  |  | 2.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (78.7 | ) |  | $ | (7.3 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments on sale of businesses |  | (2.1 | ) |  | (27.9 | ) |  | Loss (gain), net on sale of businesses and related property |
| Net of tax |  | (2.1 | ) |  | (27.9 | ) |  |  |
| Total reclassifications from AOCL |  | $ | (86.1 | ) |  | $ | (30.5 | ) |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-20-000004:notes:322]
following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-20-000004:notes:323]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2019 and 2018 (in millions):

[0001069202-20-000004:notes:324]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | — |  |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |
| Other comprehensive income (loss) before reclassifications |  | 0.9 |  |  | — |  |  | (5.7 | ) |  | 3.7 |  |  | (1.1 | ) |
| Amounts reclassified from AOCL |  | 5.3 |  |  | — |  |  | 78.7 |  |  | 2.1 |  |  | 86.1 |  |
| Net other comprehensive (loss) income |  | 6.2 |  |  | — |  |  | 73.0 |  |  | 5.8 |  |  | 85.0 |  |
| Balance as of December 31, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (81.5 | ) |  | $ | (22.3 | ) |  | $ | (103.8 | ) |

[0001069202-20-000004:notes:325]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |
| Other comprehensive loss before reclassifications |  | (8.9 | ) |  | (1.8 | ) |  | (34.3 | ) |  | (16.9 | ) |  | (61.9 | ) |
| Amounts reclassified from AOCI |  | (4.7 | ) |  | — |  |  | 7.3 |  |  | 27.9 |  |  | 30.5 |  |
| Net other comprehensive (loss) income |  | (13.6 | ) |  | (1.8 | ) |  | (27.0 | ) |  | 11.0 |  |  | (31.4 | ) |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | — |  |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001069202-20-000004:notes:326]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-20-000004:notes:327]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Compensation expense(1) | $ | 21.3 |  |  | $ | 26.3 |  |  | $ | 24.9 |  |

[0001069202-20-000004:notes:328]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-20-000004:notes:329]
ock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-20-000004:notes:330]
Incentive Plan

[0001069202-20-000004:notes:331]
Under the Lennox International Inc. 2019 Equity and Incentive Plan Compensation Plan, we are authorized to issue awards for 1.5 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-20-000004:notes:332]
As of December 31, 2019, awards for 1.5 million shares of common stock had been granted, net of cancellations and repurchases, and there were 1.4 million shares available for future issuance.

[0001069202-20-000004:notes:333]
Performance Share Units

[0001069202-20-000004:notes:334]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001069202-20-000004:notes:335]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-20-000004:notes:336]
The following table provides information on our performance share units:

[0001069202-20-000004:notes:337]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Compensation expense for performance share units (in millions) | $ | 6.8 |  |  | $ | 12.3 |  |  | $ | 12.2 |  |
| Weighted-average fair value of grants, per share | $ | 245.06 |  |  | $ | 204.64 |  |  | $ | 197.54 |  |
| Payout ratio for shares paid | 157.2 | % |  | 173.2 | % |  | 185.9 | % |

[0001069202-20-000004:notes:338]
A summary of the status of our undistributed performance share units as of December 31, 2019, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-20-000004:notes:339]
|  | Shares (2) |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2018 | 0.2 |  |  | $ | 160.69 |  |
| Distributed | 0.1 |  |  | 126.31 |  |
| Undistributed performance share units as of December 31, 2019 (1) | 0.2 |  |  | $ | 191.14 |  |

[0001069202-20-000004:notes:340]
(1) Undistributed performance share units include approximately 0.1 million units with a weighted-average grant date fair value of $213.73 per share that had not yet vested and 0.1 million units that have vested but were not yet distributed.

[0001069202-20-000004:notes:341]
(2) Share amounts are rounded but the balance of undistributed performance share units as of December 31, 2019 accurately reflects actual units undistributed.

[0001069202-20-000004:notes:342]
As of December 31, 2019, we had $16.9 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.3 years. Our weighted-average estimated forfeiture rate for these performance share units was 11.0% as of December 31, 2019.

[0001069202-20-000004:notes:343]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-20-000004:notes:344]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Fair value of performance share units distributed | $ | 20.2 |  |  | $ | 21.1 |  |  | $ | 64.3 |  |
| Realized tax benefits from tax deductions | $ | 5.1 |  |  | $ | 5.3 |  |  | $ | 24.5 |  |

[0001069202-20-000004:notes:345]
Restricted Stock Units

[0001069202-20-000004:notes:346]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-20-000004:notes:347]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-20-000004:notes:348]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Compensation expense for restricted stock units | $ | 9.7 |  |  | $ | 9.2 |  |  | $ | 8.3 |  |
| Weighted-average fair value of grants, per share | $ | 247.02 |  |  | $ | 204.64 |  |  | $ | 197.54 |  |

[0001069202-20-000004:notes:349]
A summary of our non-vested restricted stock units as of December 31, 2019 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-20-000004:notes:350]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2018 | 0.2 |  |  | $ | 182.84 |  |
| Granted | 0.1 |  |  | 247.02 |  |
| Vested | (0.1 | ) |  | 150.50 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2019 (1) | 0.2 |  |  | $ | 216.07 |  |

[0001069202-20-000004:notes:351]
(1) As of December 31, 2019, we had $20.4 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.3 years.  Our estimated forfeiture rate for restricted stock units was 14.6% as of December 31, 2019.

[0001069202-20-000004:notes:352]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-20-000004:notes:353]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Fair value of restricted stock units vested | $ | 10.9 |  |  | $ | 9.7 |  |  | $ | 19.0 |  |
| Realized tax benefits from tax deductions | 2.7 |  |  | 2.4 |  |  | 7.2 |  |

[0001069202-20-000004:notes:354]
Stock Appreciation Rights

[0001069202-20-000004:notes:355]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally

[0001069202-20-000004:notes:356]
vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years .  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-20-000004:notes:357]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-20-000004:notes:358]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Compensation expense for stock appreciation rights | $ | 4.8 |  |  | $ | 4.8 |  |  | $ | 4.4 |  |
| Weighted-average fair value of grants, per share | 39.40 |  |  | 35.57 |  |  | 32.32 |  |

[0001069202-20-000004:notes:359]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-20-000004:notes:360]
The fair value of the stock appreciation rights granted in 2019, 2018 and 2017 were estimated on the date of grant using the following assumptions:

[0001069202-20-000004:notes:361]
|  | 2019 |  | 2018 |  | 2017 |
| Expected dividend yield | 1.77 | % |  | 1.76 | % |  | 1.47 | % |
| Risk-free interest rate | 1.59 | % |  | 2.71 | % |  | 2.02 | % |
| Expected volatility | 21.23 | % |  | 20.60 | % |  | 19.97 | % |
| Expected life (in years) | 3.96 |  |  | 3.93 |  |  | 3.95 |  |

[0001069202-20-000004:notes:362]
A summary of our stock appreciation rights as of December 31, 2019, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-20-000004:notes:363]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2018 | 0.9 |  |  | $ | 148.98 |  |
| Granted | 0.1 |  |  | 257.08 |  |
| Exercised | (0.2 | ) |  | 100.75 |  |
| Outstanding stock appreciation rights as of December 31, 2019 | 0.8 |  |  | $ | 181.15 |  |
| Exercisable stock appreciation rights as of December 31, 2019 | 0.5 |  |  | $ | 152.28 |  |

[0001069202-20-000004:notes:364]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2019 (in millions, except per share data and years):

[0001069202-20-000004:notes:365]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $81.11 to $131.94 |  | 0.2 |  |  | 2.27 |  | $ | 28.3 |  |  | 0.2 |  |  | 1.75 |  | $ | 28.3 |  |
| $156.94 to $205.53 |  | 0.3 |  |  | 4.49 |  | $ | 19.3 |  |  | 0.3 |  |  | 4.39 |  | $ | 17.4 |  |
| $214.63 to $257.08 |  | 0.3 |  |  | 6.49 |  | $ | 4.2 |  |  | 0.1 |  |  | 6.00 |  | $ | 1.4 |  |

[0001069202-20-000004:notes:366]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2019.

[0001069202-20-000004:notes:367]
As of December 31, 2019, we had $9.5 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 12.7% as of December 31, 2019.

[0001069202-20-000004:notes:368]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-20-000004:notes:369]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Intrinsic value of stock appreciation rights exercised | $ | 37.1 |  |  | $ | 35.9 |  |  | $ | 25.1 |  |
| Realized tax benefits from tax deductions | $ | 9.3 |  |  | $ | 8.9 |  |  | $ | 9.6 |  |

[0001069202-20-000004:notes:370]
Employee Stock Purchase Plan

[0001069202-20-000004:notes:371]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 12,400 shares under the ESPP during the year ended December 31, 2019.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-20-000004:notes:372]
ir value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-20-000004:notes:373]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-20-000004:notes:374]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-20-000004:notes:375]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-20-000004:notes:376]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2019 and 2018, the measurement dates.

[0001069202-20-000004:notes:377]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2019 were the same as those used as of December 31, 2018.

[0001069202-20-000004:notes:378]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-20-000004:notes:379]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-20-000004:notes:380]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 10 for more information related to our derivative instruments.

[0001069202-20-000004:notes:381]
Other Fair Value Disclosures

[0001069202-20-000004:notes:382]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-20-000004:notes:383]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-20-000004:notes:384]
|  | As of December 31, |
|  | 2019 |  | 2018 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 356.8 |  |  | $ | 338.4 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001069202-20-000004:notes:385]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-20-000004:notes:386]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (1) |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| First Quarter | $ | 790.3 |  |  | $ | 834.8 |  |  | $ | 201.6 |  |  | $ | 223.2 |  |  | $ | 69.3 |  |  | $ | 37.9 |  |
| Second Quarter | 1,099.1 |  |  | 1,175.4 |  |  | 332.1 |  |  | 361.6 |  |  | 110.7 |  |  | 137.6 |  |
| Third Quarter | 1,032.9 |  |  | 1,030.2 |  |  | 298.3 |  |  | 301.9 |  |  | 114.7 |  |  | 108.0 |  |
| Fourth Quarter | 885.0 |  |  | 843.6 |  |  | 247.8 |  |  | 224.5 |  |  | 114.0 |  |  | 75.6 |  |

[0001069202-20-000004:notes:387]
|  | Basic Earnings per Share (2) |  | Diluted Earnings per Share (2) |  | Cash Dividends per Common Share |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| First Quarter | $ | 1.75 |  |  | $ | 0.91 |  |  | $ | 1.73 |  |  | $ | 0.90 |  |  | $ | 0.64 |  |  | $ | 0.51 |  |
| Second Quarter | 2.83 |  |  | 3.38 |  |  | 2.80 |  |  | 3.35 |  |  | 0.77 |  |  | 0.64 |  |
| Third Quarter | 2.97 |  |  | 2.68 |  |  | 2.94 |  |  | 2.65 |  |  | 0.77 |  |  | 0.64 |  |
| Fourth Quarter | 2.96 |  |  | 1.89 |  |  | 2.93 |  |  | 1.87 |  |  | 0.77 |  |  | 0.64 |  |

[0001069202-20-000004:notes:388]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-20-000004:notes:389]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-20-000004:notes:390]
following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-20-000004:notes:391]
Summary of 2019 Quarterly Results

[0001069202-20-000004:notes:392]
The following unusual or infrequent pre-tax items were included in the 2019 quarterly results:

[0001069202-20-000004:notes:393]
1st Quarter.  We signed an agreement with EPTA S.p.A., a private Italian company, for the sale of our Kysor Warren business. Refer to Note 7 for details regarding the divestiture.  We also recorded gains of $46.4 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-20-000004:notes:394]
2nd Quarter.   We entered into an agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer our pension plan assets and related pension benefit obligations. Refer to Note 11 for details regarding the transaction.  We also recorded gains of $31.9 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-20-000004:notes:395]
3rd Quarter.  We recorded gains of $7.1 million from insurance recoveries related to our Marshalltown facility; refer to Note 5 for details.

[0001069202-20-000004:notes:396]
4th Quarter.  We entered into a second agreement with Pacific Life Insurance Company to purchase a group annuity contract and transfer our pension plan assets and related pension benefit obligations. Refer to Note 11 for details regarding the transaction.  We also reached a final settlement with our insurance carriers for the losses incurred from tornado damage at our Marshalltown  facility.  We recorded gains of $93.4 million for the settlement and receipt of insurance recoveries; refer to Note 5 for further details.

[0001069202-20-000004:notes:397]
Summary of 2018 Quarterly Results

[0001069202-20-000004:notes:398]
The following unusual or infrequent pre-tax items were included in the 2018 quarterly results:

[0001069202-20-000004:notes:399]
1st Quarter.  We obtained board approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia and Asia business.

[0001069202-20-000004:notes:400]
2nd Quarter.   We completed the sale to Beijer Ref AB of our Australia and Asia business and sold our Milperra property. We obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business.  Refer to Note 7 for details regarding the divestiture.

[0001069202-20-000004:notes:401]
3rd Quarter.   We completed the sale to Elgin SA of our South America business. Our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado. Refer to Note 7 for details regarding the divestiture and Note 5 for details related to the tornado damage.

[0001069202-20-000004:notes:402]
4th Quarter. We recorded gains of $38.6 million from insurance recoveries related to our Marshalltown facility, refer to Note 5 for further details.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-20-000004:notes:403]
e Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor
 Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-20-000004:notes:404]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-20-000004:notes:405]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2019 and December 31, 2018 and for the years ended December 31, 2019, 2018 and 2017 are shown on the following pages.

[0001069202-20-000004:notes:406]
Condensed Consolidating Balance Sheets

[0001069202-20-000004:notes:407]
As of December 31, 2019

[0001069202-20-000004:notes:408]
(In millions)

[0001069202-20-000004:notes:409]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.5 |  |  | $ | 18.6 |  |  | $ | — |  |  | $ | 37.3 |  |
| Short-term investments | — |  |  | — |  |  | 2.9 |  |  | — |  |  | 2.9 |  |
| Accounts and notes receivable, net | — |  |  | 53.5 |  |  | 424.3 |  |  | — |  |  | 477.8 |  |
| Inventories, net | — |  |  | 477.2 |  |  | 68.7 |  |  | (1.8 | ) |  | 544.1 |  |
| Other assets | 4.4 |  |  | 40.7 |  |  | 48.4 |  |  | (34.7 | ) |  | 58.8 |  |
| Total current assets | 5.6 |  |  | 588.9 |  |  | 562.9 |  |  | (36.5 | ) |  | 1,120.9 |  |
| Property, plant and equipment, net | — |  |  | 388.8 |  |  | 56.6 |  |  | — |  |  | 445.4 |  |
| Right-of-use assets from operating leases | — |  |  | 158.9 |  |  | 22.7 |  |  | — |  |  | 181.6 |  |
| Goodwill | — |  |  | 166.2 |  |  | 20.3 |  |  | — |  |  | 186.5 |  |
| Investment in subsidiaries | 2,128.9 |  |  | 390.6 |  |  | 50.2 |  |  | (2,569.7 | ) |  | — |  |
| Deferred income taxes | 4.1 |  |  | 5.4 |  |  | 24.2 |  |  | (12.2 | ) |  | 21.5 |  |
| Other assets, net | 1.6 |  |  | 61.9 |  |  | 1.3 |  |  | 14.2 |  |  | 79.0 |  |
| Intercompany (payables) receivables, net | (1,453.6 | ) |  | 1,114.6 |  |  | 167.1 |  |  | 171.9 |  |  | — |  |
| Total assets | $ | 686.6 |  |  | $ | 2,875.3 |  |  | $ | 905.3 |  |  | $ | (2,432.3 | ) |  | $ | 2,034.9 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | 29.4 |  |  | 6.4 |  |  | 286.1 |  |  | — |  |  | 321.9 |  |
| Current operating lease liabilities | — |  |  | 45.5 |  |  | 7.2 |  |  | — |  |  | 52.7 |  |
| Accounts payable | 29.7 |  |  | 296.5 |  |  | 46.2 |  |  | — |  |  | 372.4 |  |
| Accrued expenses | 4.2 |  |  | 211.2 |  |  | 40.3 |  |  | — |  |  | 255.7 |  |
| Income taxes (receivable) payable | (53.4 | ) |  | 50.2 |  |  | 54.1 |  |  | (50.9 | ) |  | — |  |
| Total current liabilities | 9.9 |  |  | 609.8 |  |  | 433.9 |  |  | (50.9 | ) |  | 1,002.7 |  |
| Long-term debt | 823.4 |  |  | 23.4 |  |  | 2.5 |  |  | — |  |  | 849.3 |  |
| Long-term operating lease liabilities | — |  |  | 115.3 |  |  | 15.7 |  |  | — |  |  | 131.0 |  |
| Pensions | — |  |  | 79.4 |  |  | 8.0 |  |  | — |  |  | 87.4 |  |
| Other liabilities | 23.5 |  |  | 104.4 |  |  | 6.8 |  |  | — |  |  | 134.7 |  |
| Total liabilities | 856.8 |  |  | 932.3 |  |  | 466.9 |  |  | (50.9 | ) |  | 2,205.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders’ (deficit) equity | (170.2 | ) |  | 1,943.0 |  |  | 438.4 |  |  | (2,381.4 | ) |  | (170.2 | ) |
| Total liabilities and stockholders’ (deficit) equity | $ | 686.6 |  |  | $ | 2,875.3 |  |  | $ | 905.3 |  |  | $ | (2,432.3 | ) |  | $ | 2,034.9 |  |

[0001069202-20-000004:notes:410]
As of December 31, 2018

[0001069202-20-000004:notes:411]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net | — |  |  | 44.3 |  |  | 428.4 |  |  | — |  |  | 472.7 |  |
| Inventories, net | — |  |  | 411.4 |  |  | 103.9 |  |  | (5.5 | ) |  | 509.8 |  |
| Other assets | 3.3 |  |  | 36.2 |  |  | 54.7 |  |  | (33.6 | ) |  | 60.6 |  |
| Total current assets | 5.1 |  |  | 507.3 |  |  | 616.1 |  |  | (39.1 | ) |  | 1,089.4 |  |
| Property, plant and equipment, net | — |  |  | 293.3 |  |  | 118.6 |  |  | (3.6 | ) |  | 408.3 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,311.9 |  |  | 357.8 |  |  | (0.5 | ) |  | (1,669.2 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 54.4 |  |  | 23.4 |  |  | (12.2 | ) |  | 67.0 |  |
| Other assets, net | 1.5 |  |  | 48.1 |  |  | 17.8 |  |  | (1.5 | ) |  | 65.9 |  |
| Intercompany (payables) receivables, net | (715.5 | ) |  | 675.8 |  |  | 142.6 |  |  | (102.9 | ) |  | — |  |
| Total assets | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt | $ | 29.4 |  |  | $ | 2.8 |  |  | $ | 268.6 |  |  | $ | — |  |  | $ | 300.8 |  |
| Accounts payable | 25.5 |  |  | 295.7 |  |  | 112.1 |  |  | — |  |  | 433.3 |  |
| Accrued expenses | 12.1 |  |  | 213.8 |  |  | 46.4 |  |  | — |  |  | 272.3 |  |
| Income taxes (receivable) payable | (38.5 | ) |  | 40.6 |  |  | 50.8 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | 28.5 |  |  | 552.9 |  |  | 477.9 |  |  | (50.8 | ) |  | 1,008.5 |  |
| Long-term debt | 724.9 |  |  | 15.0 |  |  | 0.6 |  |  | — |  |  | 740.5 |  |
| Pensions | — |  |  | 75.1 |  |  | 7.7 |  |  | — |  |  | 82.8 |  |
| Other liabilities | 0.6 |  |  | 126.4 |  |  | 8.0 |  |  | — |  |  | 135.0 |  |
| Total liabilities | 754.0 |  |  | 769.4 |  |  | 494.2 |  |  | (50.8 | ) |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders’ (deficit) equity | (149.6 | ) |  | 1,333.4 |  |  | 444.3 |  |  | (1,777.7 | ) |  | (149.6 | ) |
| Total liabilities and stockholders’ (deficit) equity | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |

[0001069202-20-000004:notes:412]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-20-000004:notes:413]
For the Year Ended December 31, 2019

[0001069202-20-000004:notes:414]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,479.8 |  |  | $ | 555.7 |  |  | $ | (228.3 | ) |  | $ | 3,807.2 |  |
| Cost of goods sold | — |  |  | 2,513.2 |  |  | 441.6 |  |  | (227.4 | ) |  | 2,727.4 |  |
| Gross profit | — |  |  | 966.6 |  |  | 114.1 |  |  | (0.9 | ) |  | 1,079.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 559.6 |  |  | 26.3 |  |  | — |  |  | 585.9 |  |
| Losses (gains) and other expenses, net | (0.5 | ) |  | 6.4 |  |  | 2.7 |  |  | (0.3 | ) |  | 8.3 |  |
| Restructuring charges | — |  |  | 9.3 |  |  | 1.0 |  |  | — |  |  | 10.3 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 2.8 |  |  | 7.8 |  |  | — |  |  | 10.6 |  |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (178.8 | ) |  | — |  |  | — |  |  | (178.8 | ) |
| Income from equity method investments | (415.2 | ) |  | (54.2 | ) |  | (10.5 | ) |  | 466.5 |  |  | (13.4 | ) |
| Operating income | 415.7 |  |  | 621.5 |  |  | 86.8 |  |  | (467.1 | ) |  | 656.9 |  |
| Pension settlements | — |  |  | 99.2 |  |  | — |  |  | — |  |  | 99.2 |  |
| Interest expense, net | 8.9 |  |  | 29.7 |  |  | 8.9 |  |  | — |  |  | 47.5 |  |
| Other expense (income), net | — |  |  | 0.5 |  |  | 1.8 |  |  | — |  |  | 2.3 |  |
| Income from continuing operations before income taxes | 406.8 |  |  | 492.1 |  |  | 76.1 |  |  | (467.1 | ) |  | 507.9 |  |
| Provision for income taxes | (2.0 | ) |  | 72.5 |  |  | 28.6 |  |  | — |  |  | 99.1 |  |
| Income from continuing operations | 408.8 |  |  | 419.6 |  |  | 47.5 |  |  | (467.1 | ) |  | 408.8 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Net income | $ | 408.8 |  |  | $ | 419.6 |  |  | $ | 47.4 |  |  | $ | (467.1 | ) |  | $ | 408.7 |  |
| Other comprehensive income | $ | 7.4 |  |  | $ | 74.5 |  |  | $ | 3.1 |  |  | $ | — |  |  | $ | 85.0 |  |
| Comprehensive income | $ | 416.2 |  |  | $ | 494.1 |  |  | $ | 50.5 |  |  | $ | (467.1 | ) |  | $ | 493.7 |  |

[0001069202-20-000004:notes:415]
For the Year Ended December 31, 2018

[0001069202-20-000004:notes:416]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 3,473.2 |  |  | $ | 1,129.6 |  |  | $ | (718.9 | ) |  | $ | 3,883.9 |  |
| Cost of goods sold | — |  |  | 2,500.6 |  |  | 988.7 |  |  | (716.6 | ) |  | 2,772.7 |  |
| Gross profit | — |  |  | 972.6 |  |  | 140.9 |  |  | (2.3 | ) |  | 1,111.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 555.3 |  |  | 53.6 |  |  | (0.7 | ) |  | 608.2 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 5.4 |  |  | 6.3 |  |  | (0.3 | ) |  | 13.4 |  |
| Restructuring charges | — |  |  | 1.1 |  |  | 1.9 |  |  | — |  |  | 3.0 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 40.3 |  |  | (13.3 | ) |  | — |  |  | 27.0 |  |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (38.3 | ) |  | — |  |  | — |  |  | (38.3 | ) |
| Income from equity method investments | (367.4 | ) |  | (70.3 | ) |  | (9.9 | ) |  | 435.6 |  |  | (12.0 | ) |
| Operational income | 365.4 |  |  | 479.1 |  |  | 102.3 |  |  | (436.9 | ) |  | 509.9 |  |
| Pension settlement | — |  |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Interest expense, net | 9.0 |  |  | 18.5 |  |  | 10.8 |  |  | — |  |  | 38.3 |  |
| Other expense (income), net | — |  |  | 1.5 |  |  | 1.8 |  |  | — |  |  | 3.3 |  |
| Income from continuing operations before income taxes | 356.4 |  |  | 459.1 |  |  | 89.3 |  |  | (436.9 | ) |  | 467.9 |  |
| Provision for income taxes | (2.6 | ) |  | 92.1 |  |  | 18.0 |  |  | 0.1 |  |  | 107.6 |  |
| Income from continuing operations | 359.0 |  |  | 367.0 |  |  | 71.3 |  |  | (437.0 | ) |  | 360.3 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (1.3 | ) |  | — |  |  | (1.3 | ) |
| Net income | $ | 359.0 |  |  | $ | 367.0 |  |  | $ | 70.0 |  |  | $ | (437.0 | ) |  | $ | 359.0 |  |
| Other comprehensive loss | $ | (15.4 | ) |  | $ | (15.3 | ) |  | $ | (0.7 | ) |  | $ | — |  |  | $ | (31.4 | ) |
| Comprehensive income | $ | 343.6 |  |  | $ | 351.7 |  |  | $ | 69.3 |  |  | $ | (437.0 | ) |  | $ | 327.6 |  |

[0001069202-20-000004:notes:417]
For the Year Ended December 31, 2017

[0001069202-20-000004:notes:418]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,295.8 |  |  | $ | 1,144.2 |  |  | $ | (600.4 | ) |  | $ | 3,839.6 |  |
| Cost of goods sold | — |  |  | 2,359.6 |  |  | 953.6 |  |  | (598.8 | ) |  | 2,714.4 |  |
| Gross profit | — |  |  | 936.2 |  |  | 190.6 |  |  | (1.6 | ) |  | 1,125.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 553.6 |  |  | 85.0 |  |  | (0.9 | ) |  | 637.7 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 3.3 |  |  | 1.9 |  |  | (0.1 | ) |  | 7.1 |  |
| Restructuring charges | — |  |  | 2.1 |  |  | 1.1 |  |  | — |  |  | 3.2 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 1.1 |  |  | — |  |  | — |  |  | 1.1 |  |
| Income from equity method investments | (324.3 | ) |  | (74.9 | ) |  | (14.5 | ) |  | 395.3 |  |  | (18.4 | ) |
| Operational income | 322.3 |  |  | 451.0 |  |  | 117.1 |  |  | (395.9 | ) |  | 494.5 |  |
| Interest expense, net | 26.9 |  |  | (2.7 | ) |  | 6.4 |  |  | — |  |  | 30.6 |  |
| Other income, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 295.4 |  |  | 453.7 |  |  | 110.8 |  |  | (395.9 | ) |  | 464.0 |  |
| Provision for income taxes | (10.3 | ) |  | 136.2 |  |  | 31.2 |  |  | (0.2 | ) |  | 156.9 |  |
| Income from continuing operations | 305.7 |  |  | 317.5 |  |  | 79.6 |  |  | (395.7 | ) |  | 307.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Net income | $ | 305.7 |  |  | $ | 317.5 |  |  | $ | 78.2 |  |  | $ | (395.7 | ) |  | $ | 305.7 |  |
| Other comprehensive income | $ | 1.7 |  |  | $ | 5.5 |  |  | $ | 30.5 |  |  | $ | — |  |  | $ | 37.7 |  |
| Comprehensive income | $ | 307.4 |  |  | $ | 323.0 |  |  | $ | 108.7 |  |  | $ | (395.7 | ) |  | $ | 343.4 |  |

[0001069202-20-000004:notes:419]
Condensed Consolidating Statements of Cash Flows

[0001069202-20-000004:notes:420]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (30.2 | ) |  | $ | 421.8 |  |  | $ | 4.5 |  |  | $ | — |  |  | $ | 396.1 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Purchases of property, plant and equipment | — |  |  | (95.2 | ) |  | (10.4 | ) |  | — |  |  | (105.6 | ) |
| Purchases of short-term investments | — |  |  | — |  |  | (2.9 | ) |  |  |  | (2.9 | ) |
| Net proceeds from sale of businesses | — |  |  | 42.8 |  |  | 0.7 |  |  | — |  |  | 43.5 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 79.6 |  |  | — |  |  | — |  |  | 79.6 |  |
| Net cash provided by (used in) investing activities | — |  |  | 28.2 |  |  | (12.3 | ) |  | — |  |  | 15.9 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt payments | — |  |  | — |  |  | (5.3 | ) |  | — |  |  | (5.3 | ) |
| Short-term debt borrowings | — |  |  | — |  |  | 5.3 |  |  | — |  |  | 5.3 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 184.5 |  |  | — |  |  | 184.5 |  |
| Asset securitization payments | — |  |  | — |  |  | (167.5 | ) |  | — |  |  | (167.5 | ) |
| Long-term debt payments | — |  |  | (3.7 | ) |  | (2.7 | ) |  | — |  |  | (6.4 | ) |
| Long-term debt borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings on credit facility | 2,367.0 |  |  | — |  |  | — |  |  | — |  |  | 2,367.0 |  |
| Payments on credit facility | (2,269.5 | ) |  | — |  |  | — |  |  | — |  |  | (2,269.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Proceeds from employee stock purchases | 3.3 |  |  | — |  |  | — |  |  | — |  |  | 3.3 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (24.0 | ) |  | — |  |  | — |  |  | — |  |  | (24.0 | ) |
| Repurchases of common stock | (400.0 | ) |  | — |  |  | — |  |  | — |  |  | (400.0 | ) |
| Intercompany debt | 21.8 |  |  | (15.1 | ) |  | (6.7 | ) |  | — |  |  | — |  |
| Intercompany financing activity | 441.5 |  |  | (429.6 | ) |  | (11.9 | ) |  | — |  |  | — |  |
| Cash dividends paid | (110.5 | ) |  | — |  |  | — |  |  | — |  |  | (110.5 | ) |
| Net cash provided by (used in) financing activities | 29.6 |  |  | (448.4 | ) |  | (4.6 | ) |  | — |  |  | (423.4 | ) |
| (Decrease) increase in cash and cash equivalents | (0.6 | ) |  | 1.6 |  |  | (12.4 | ) |  | — |  |  | (11.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | 0.5 |  |  | 1.9 |  |  | — |  |  | 2.4 |  |
| Cash and cash equivalents, beginning of year | 1.8 |  |  | 15.4 |  |  | 29.1 |  |  | — |  |  | 46.3 |  |
| Cash and cash equivalents, end of year | $ | 1.2 |  |  | $ | 17.5 |  |  | $ | 18.6 |  |  | $ | — |  |  | $ | 37.3 |  |

[0001069202-20-000004:notes:421]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 53.7 |  |  | $ | 477.9 |  |  | $ | (36.1 | ) |  | $ | — |  |  | $ | 495.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (76.0 | ) |  | (19.2 | ) |  | — |  |  | (95.2 | ) |
| Net proceeds from sale of businesses and related property | — |  |  | 2.7 |  |  | 112.0 |  |  | — |  |  | 114.7 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 10.9 |  |  | — |  |  | — |  |  | 10.9 |  |
| Net cash (used in) provided by investing activities | — |  |  | (62.4 | ) |  | 92.9 |  |  | — |  |  | 30.5 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt borrowings | — |  |  | — |  |  | 40.3 |  |  | — |  |  | 40.3 |  |
| Short-term debt payments | — |  |  | — |  |  | (40.3 | ) |  | — |  |  | (40.3 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 155.0 |  |  | — |  |  | 155.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (163.0 | ) |  | — |  |  | (163.0 | ) |
| Long-term debt payments | — |  |  | (2.9 | ) |  | (0.1 | ) |  | — |  |  | (3.0 | ) |
| Borrowings from credit facility | 2,435.9 |  |  | — |  |  | — |  |  | — |  |  | 2,435.9 |  |
| Payments on credit facility | (2,395.0 | ) |  | — |  |  | — |  |  | — |  |  | (2,395.0 | ) |
| Proceeds from employee stock purchases | 3.3 |  |  | — |  |  | — |  |  | — |  |  | 3.3 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.9 | ) |  | — |  |  | — |  |  | — |  |  | (26.9 | ) |
| Repurchases of common stock | (450.2 | ) |  | — |  |  | — |  |  | — |  |  | (450.2 | ) |
| Intercompany debt | (14.5 | ) |  | 83.3 |  |  | (68.8 | ) |  | — |  |  | — |  |
| Intercompany financing activity | 487.8 |  |  | (508.5 | ) |  | 20.7 |  |  | — |  |  | — |  |
| Cash dividends paid | (93.9 | ) |  | — |  |  | — |  |  | — |  |  | (93.9 | ) |
| Net cash used in financing activities | (53.5 | ) |  | (428.1 | ) |  | (56.2 | ) |  | — |  |  | (537.8 | ) |
| Increase (decrease) in cash and cash equivalents | 0.2 |  |  | (12.6 | ) |  | 0.6 |  |  | — |  |  | (11.8 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (10.1 | ) |  | — |  |  | (10.1 | ) |
| Cash and cash equivalents, beginning of year | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of year | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |

[0001069202-20-000004:notes:422]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 467.4 |  |  | $ | 31.1 |  |  | $ | (173.4 | ) |  | $ | — |  |  | $ | 325.1 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (70.7 | ) |  | (27.6 | ) |  | — |  |  | (98.3 | ) |
| Net cash used in investing activities | — |  |  | (70.6 | ) |  | (27.5 | ) |  | — |  |  | (98.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term debt borrowings | — |  |  | — |  |  | 30.4 |  |  | — |  |  | 30.4 |  |
| Short-term debt payments | — |  |  | — |  |  | (31.9 | ) |  | — |  |  | (31.9 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 315.0 |  |  | — |  |  | 315.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (89.0 | ) |  | — |  |  | (89.0 | ) |
| Long-term debt payments | (200.0 | ) |  | (0.3 | ) |  | (0.6 | ) |  | — |  |  | (200.9 | ) |
| Borrowings from credit facility | 2,376.5 |  |  | — |  |  | — |  |  | — |  |  | 2,376.5 |  |
| Payments on credit facility | (2,265.5 | ) |  | — |  |  | — |  |  | — |  |  | (2,265.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Proceeds from employee stock purchases | 3.1 |  |  | — |  |  | — |  |  | — |  |  | 3.1 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.1 | ) |  | — |  |  | — |  |  | — |  |  | (26.1 | ) |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Intercompany debt | 56.4 |  |  | (34.9 | ) |  | (21.5 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (81.7 | ) |  | 85.6 |  |  | (3.9 | ) |  | — |  |  | — |  |
| Cash dividends paid | (79.7 | ) |  | — |  |  | — |  |  | — |  |  | (79.7 | ) |
| Net cash (used in) provided by financing activities | (467.0 | ) |  | 50.4 |  |  | 198.3 |  |  | — |  |  | (218.3 | ) |
| Increase (decrease) in cash and cash equivalents | 0.4 |  |  | 10.9 |  |  | (2.6 | ) |  | — |  |  | 8.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 9.3 |  |  | — |  |  | 9.3 |  |
| Cash and cash equivalents, beginning of year | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of year | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-20-000004:notes:423]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-20-000004:notes:424]
For the Years Ended December 31, 2019, 2018 and 2017

[0001069202-20-000004:notes:425]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.7 |  |  | $ | 3.9 |  |  | $ | (5.6 | ) |  | $ | 0.9 |  |  | $ | — |  |  | $ | 5.9 |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 5.9 |  |  | $ | 4.8 |  |  | $ | (3.7 | ) |  | $ | 0.6 |  |  | $ | (1.3 | ) |  | $ | 6.3 |  |
| 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.3 |  |  | $ | 4.5 |  |  | $ | (4.9 | ) |  | $ | 1.6 |  |  | $ | (1.4 | ) |  | $ | 6.1 |  |
