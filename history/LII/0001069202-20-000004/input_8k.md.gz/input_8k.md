# LII 8-K — 0001069202-20-000002 filed 2020-02-04

## item codes, every 8-K on or before 2020-02-18

- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2020-02-18

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-20-000002:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetabl.htm
EXHIBIT 99.1

[0001069202-20-000002:8k_2_02:2]
Exhibit

[0001069202-20-000002:8k_2_02:3]
Exhibit-99.1

[0001069202-20-000002:8k_2_02:4]
Lennox International Reports Fourth Quarter Results and Reiterates 2020 Guidance

[0001069202-20-000002:8k_2_02:5]
| • | Fourth-quarter revenue $885 million, up 5% on a GAAP basis and up 8% to a fourth-quarter record on an adjusted basis, excluding the impact from divestitures |

[0001069202-20-000002:8k_2_02:6]
| • | Fourth-quarter GAAP EPS from continuing operations up 57% to fourth-quarter record $2.92; adjusted EPS from continuing operations up 24% to fourth-quarter record $2.45 |

[0001069202-20-000002:8k_2_02:7]
| • | 2019 revenue $3.8 billion, down 2% on a GAAP basis and up 3% to a record high on an adjusted basis, excluding the impact from divestitures |

[0001069202-20-000002:8k_2_02:8]
| • | 2019 GAAP EPS from continuing operations up 18% to a record $10.38; adjusted EPS from continuing operations up 18% to a record $11.19 |

[0001069202-20-000002:8k_2_02:9]
| • | Generated $396 million of cash from operations and $371 million of free cash flow in 2019 |

[0001069202-20-000002:8k_2_02:10]
| • | Reiterating 2020 guidance for adjusted revenue growth of 4-8% |

[0001069202-20-000002:8k_2_02:11]
| • | Reiterating 2020 guidance for GAAP and adjusted EPS from continuing operations of $11.30-$11.90 |

[0001069202-20-000002:8k_2_02:12]
| • | Reiterating 2020 guidance for $400 million of stock repurchases |

[0001069202-20-000002:8k_2_02:13]
DALLAS, February 4, 2020 - Lennox International Inc. (NYSE: LII) today reported fourth-quarter and full-year 2019 results. All comparisons are to the prior-year period. Adjusted revenue and profit exclude non-core Refrigeration divestitures. The company’s tornado and insurance references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. As previously announced, the company reached a final agreement with its insurers for total insurance proceeds of $368 million, which have been received over the course of 2018-2019. A final chart of the insurance recovery and financial impact from the tornado for 2018-2019 is archived on the company’s website as presented at the 2019 Investment Community Meeting in December.

[0001069202-20-000002:8k_2_02:14]
For the fourth quarter, GAAP and adjusted revenue was $885 million. GAAP revenue was up 5%. Foreign exchange was neutral to revenue. GAAP operating income was a fourth-quarter record $192 million, up 64%. GAAP earnings per share from continuing operations was a fourth-quarter record $2.92, up 57%.

[0001069202-20-000002:8k_2_02:15]
On an adjusted basis, excluding the impact from divestitures, revenue was up 8% to a new fourth-quarter high. Foreign exchange was neutral to revenue. Total segment profit increased 19% to a fourth-quarter record $133 million, and total segment margin expanded 140 basis points to a fourth-quarter record 15.1%. Adjusted earnings per share from continuing operations rose 24% to a fourth-quarter record $2.45.

[0001069202-20-000002:8k_2_02:16]
For the full year, GAAP revenue was $3.81 billion, down 2% including a negative 5% impact from divestitures. Foreign exchange was neutral to revenue. GAAP operating income was a record $657 million, up 29%. GAAP earnings per share from continuing operations was a record $10.38, up 18%.

[0001069202-20-000002:8k_2_02:17]
On an adjusted basis for the full year, excluding the impact from divestitures, revenue was a record $3.77 billion, up 3%. Foreign exchange was neutral to revenue. Total segment profit increased 12% to a record $610 million, and total segment margin expanded 130 basis points to a record 16.2%. Adjusted earnings per share from continuing operations rose 18% to a record $11.19 for the full year.

[0001069202-20-000002:8k_2_02:18]
“Weather was a headwind to growth in the last three quarters of 2019, but the company posted records for adjusted revenue, margin and profit for the year and had strong cash generation,” said Chairman and CEO Todd Bluedorn. “In 2019, we completed the divestiture of non-core Refrigeration businesses, operationally recovered from the tornado, and resumed capturing share in the market. We introduced new products in 2019 and continued to make investments for future growth and profitability that position the company well for 2020 and beyond.

[0001069202-20-000002:8k_2_02:19]
“In the fourth quarter, our Residential business reported new fourth-quarter records for revenue, profit and margin. Residential revenue was up 8% on growth in both replacement and new construction business. Residential profit rose 20%, and segment margin expanded 190 basis points to 19.6%.

[0001069202-20-000002:8k_2_02:20]
“As presented in December, the Residential business in the fourth quarter had negative tornado impact of $23 million to revenue and $13 million to segment profit offset by $25 million of insurance recovery for a net benefit of $12 million to segment profit. For the year, Residential had negative tornado impact of $109 million to revenue and $59 million to segment profit offset by $99 million of insurance recovery for a net benefit of $40 million to segment profit.

[0001069202-20-000002:8k_2_02:21]
“In the fourth quarter for Commercial, the business set new fourth-quarter records for revenue, profit and margin. Commercial revenue was up 12% on broad strength across the equipment and service businesses. Commercial profit rose 24%, and segment margin expanded 190 basis points to 19.0%. In Refrigeration, adjusted revenue was relatively flat at constant currency. North America was up low-single digits, and Europe was down low-single digits at constant currency. Refrigeration profit rose 5%, and segment margin expanded 70 basis points to 11.1%.

[0001069202-20-000002:8k_2_02:22]
“Looking ahead for the company overall, we are well-positioned for a year of strong growth and profitability and reiterate guidance for 2020. With a strong balance sheet and cash generation, the company continues to invest in the business to drive performance, grow the dividend with earnings, and repurchase stock, with $400 million planned for 2020.”

[0001069202-20-000002:8k_2_02:23]
FOURTH QUARTER 2019 FINANCIAL HIGHLIGHTS

[0001069202-20-000002:8k_2_02:24]
Revenue: Revenue for the fourth quarter was $885 million, up 5% on a GAAP basis and up 8% on an adjusted basis, excluding the impact from divestitures. Foreign exchange was neutral. Volume, price and mix were up from the prior-year quarter.

[0001069202-20-000002:8k_2_02:25]
Gross Profit: Gross profit in the fourth quarter was $248 million, up 10% on a GAAP basis and up 12% on an adjusted basis, excluding the impact from divestitures. Gross margin was 28.0%, up 140 basis points on a GAAP basis and up 100 basis points on an adjusted basis. Gross profit was favorably impacted by higher volume, price and mix, and lower material, tariff, and warranty costs. Partial offsets included negative tornado impact and lower factory efficiency, higher distribution, freight and other product costs. Divestitures had a negative impact on GAAP gross profit.

[0001069202-20-000002:8k_2_02:26]
Income from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $113.8 million, or $2.92 diluted earnings per share, compared to $75.3 million, or $1.86 diluted earnings per share, in the prior-year quarter.

[0001069202-20-000002:8k_2_02:27]
On an adjusted basis, fourth quarter income from continuing operations was $95.1 million, or $2.45 diluted earnings per share, compared to $79.9 million, or $1.98 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth quarter of 2019 excludes net after-tax gain of $18.7 million: a gain of $51.0 million for insurance recoveries received for property damage incurred from the 2018 tornado, a benefit of $4.0 million for excess tax benefits from share-based compensation, a charge of $28.9 million for pension settlement, and a total charge of $7.4 million for various other items, net.

[0001069202-20-000002:8k_2_02:28]
FULL YEAR 2019 FINANCIAL HIGHLIGHTS

[0001069202-20-000002:8k_2_02:29]
Revenue: For the full year, GAAP revenue was $3.81 billion, down 2%. Adjusted revenue was $3.77 billion, up 3% excluding the impact from divestitures. Foreign exchange was neutral. Volume and price were up, and mix was flat.

[0001069202-20-000002:8k_2_02:30]
Gross Profit: Gross profit for the full year was $1.08 billion, down 3% on a GAAP basis and flat on an adjusted basis, excluding the impact from divestitures. GAAP gross margin was 28.4%, down 20 basis points, and adjusted gross margin was 28.5%, down 80 basis points. Gross profit was negatively impacted by the tornado and factory inefficiency, unfavorable mix, higher commodity, distribution, freight, tariff and other product costs, and unfavorable foreign exchange. On a GAAP basis, divestitures had a negative impact on gross profit. Favorable offsets included higher volume, price, sourcing and engineering-led cost reductions, and warranty.

[0001069202-20-000002:8k_2_02:31]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for 2019 was $408.8 million, or $10.38 diluted earnings per share, compared to $360.3 million, or $8.77 diluted earnings per share, in the prior year.

[0001069202-20-000002:8k_2_02:32]
On an adjusted basis, income from continuing operations for 2019 was $439.9 million, or $11.19 diluted earnings per share, compared to $389.7 million, or $9.52 diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2019 excludes net after-tax charges of $31.1 million: a charge of $74.4 million for pension settlements, a charge of $7.7 million for restructuring activities, a $6.5 million net loss on the sale of businesses and related property, a total charge of $13.2 million for various other items, net, a gain of $59.8 million for insurance recoveries received for property damage incurred from the 2018 tornado and a benefit of $10.9 million for excess tax benefits from share-based compensation.

[0001069202-20-000002:8k_2_02:33]
Free Cash Flow and Total Debt: For the full year, cash from operations was approximately $396 million compared to $496 million in the prior year. Capital expenditures were $106 million compared to $95 million in the prior year. Proceeds for damage to property and disposal of property were $81 million in 2019 compared to $11 million in the prior year. Free cash flow was $371 million for the full year compared to approximately $411 million in the prior year. In 2019, the company paid approximately $111 million in dividends and repurchased $400 million of company stock. Ending the year, total debt was $1.17 billion, and the company’s debt-to-EBITDA ratio stood at 1.7. Total cash and cash equivalents were $37 million at the end of the year.

[0001069202-20-000002:8k_2_02:34]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001069202-20-000002:8k_2_02:35]
Residential Heating and Cooling

[0001069202-20-000002:8k_2_02:36]
| • | 4Q19 revenue a fourth-quarter record $499 million, up 8%; neutral foreign exchange |

[0001069202-20-000002:8k_2_02:37]
| • | 4Q19 segment profit a fourth-quarter record $98 million, up 20% |

[0001069202-20-000002:8k_2_02:38]
| • | 4Q19 segment margin a fourth-quarter record 19.6%, up 190 basis points |

[0001069202-20-000002:8k_2_02:39]
| • | 2019 revenue a record $2.29 billion, up 3%; neutral foreign exchange |

[0001069202-20-000002:8k_2_02:40]
| • | 2019 segment profit a record $465 million, up 16% |

[0001069202-20-000002:8k_2_02:41]
| • | 2019 segment margin a record 20.3%, up 230 basis points |

[0001069202-20-000002:8k_2_02:42]
Fourth-quarter results were favorably impacted by the net benefit from insurance and tornado recovery year-over-year, higher volume, price and mix, and lower material, tariff and warranty costs. Partial offsets included lower factory efficiency, higher distribution, freight and other product costs. Full-year results were favorably impacted by the net benefit from insurance and tornado recovery year-over-year, higher volume, favorable price, sourcing and engineering-led cost reductions, and lower warranty. Partial offsets

[0001069202-20-000002:8k_2_02:43]
included unfavorable mix, lower factory efficiency, higher commodity, distribution, freight and other products costs, higher SG&A, and unfavorable foreign exchange.

[0001069202-20-000002:8k_2_02:44]
Commercial Heating and Cooling

[0001069202-20-000002:8k_2_02:45]
| • | 4Q19 revenue a fourth-quarter record $260 million, up 12%; neutral foreign exchange |

[0001069202-20-000002:8k_2_02:46]
| • | 4Q19 segment profit a fourth-quarter record $49 million, up 24% |

[0001069202-20-000002:8k_2_02:47]
| • | 4Q19 segment margin a fourth-quarter record 19.0%, up 190 basis points |

[0001069202-20-000002:8k_2_02:48]
| • | 2019 revenue $947 million, up 5%; neutral foreign exchange |

[0001069202-20-000002:8k_2_02:49]
| • | 2019 segment profit a record $165 million, up 5% |

[0001069202-20-000002:8k_2_02:50]
| • | 2019 segment margin 17.5%, flat with the prior year’s record level |

[0001069202-20-000002:8k_2_02:51]
Fourth-quarter results were favorably impacted by higher volume and price, lower material and other product costs, and lower SG&A. Partial offsets included unfavorable mix, lower factory efficiency, and higher distribution, warranty, and tariff costs. Full-year results were favorably impacted by higher volume, favorable price and mix, and sourcing and engineering-led cost reductions. Partial offsets included lower factory efficiency, higher commodity, tariff, warranty, distribution, freight, and other product costs, and higher SG&A.

[0001069202-20-000002:8k_2_02:52]
Refrigeration

[0001069202-20-000002:8k_2_02:53]
| • | 4Q19 adjusted revenue $127 million, down 2%; flat at constant currency |

[0001069202-20-000002:8k_2_02:54]
| • | 4Q19 adjusted segment profit $14 million, up 5% |

[0001069202-20-000002:8k_2_02:55]
| • | 4Q19 adjusted segment margin 11.1%, up 70 basis points |

[0001069202-20-000002:8k_2_02:56]
| • | 2019 adjusted revenue $534 million, down 1%; up 1% at constant currency |

[0001069202-20-000002:8k_2_02:57]
| • | 2019 adjusted segment profit $62 million, down 12% |

[0001069202-20-000002:8k_2_02:58]
| • | 2019 adjusted segment margin 11.7%, down 150 basis points |

[0001069202-20-000002:8k_2_02:59]
Fourth-quarter results were favorably impacted by price and mix, lower material, distribution and tariff costs, and higher joint venture income. Partial offsets included lower volume and factory efficiency, higher warranty and other product costs, higher SG&A, and unfavorable foreign exchange. Full-year results were impacted by lower volume and factory efficiency, unfavorable mix, higher commodity, tariff, warranty, distribution and other product costs, higher SG&A, and unfavorable foreign exchange. Partial offsets included higher price and sourcing and engineering-led cost reductions.

[0001069202-20-000002:8k_2_02:60]
2020 FULL-YEAR OUTLOOK

[0001069202-20-000002:8k_2_02:61]
The company reiterates its financial guidance for 2020:

[0001069202-20-000002:8k_2_02:62]
| • | Adjusted revenue growth of 4-8% |

[0001069202-20-000002:8k_2_02:63]
| • | GAAP and adjusted EPS from continuing operations of $11.30-$11.90 |

[0001069202-20-000002:8k_2_02:64]
| • | Corporate expenses of approximately $90 million |

[0001069202-20-000002:8k_2_02:65]
| • | Effective tax rate of 21-22% on an adjusted basis for the full year |

[0001069202-20-000002:8k_2_02:66]
| • | Capital expenditures of approximately $153 million, including $53 million funded by insurance proceeds received in 2019 |

[0001069202-20-000002:8k_2_02:67]
| • | $400 million of stock repurchases |

[0001069202-20-000002:8k_2_02:68]
CONFERENCE CALL INFORMATION

[0001069202-20-000002:8k_2_02:69]
A conference call to discuss the company's fourth-quarter and full-year 2019 results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 409-207-6953 at least 10 minutes prior to the scheduled start time and use reservation number 312948. The conference call also will be webcast on Lennox International's web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on February 4 through February 18, 2020, by dialing 866-207-1041 (U.S.) or 402-970-0847 (international) and using access code 6669476. The call also will be archived on the company's web site.

[0001069202-20-000002:8k_2_02:70]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-20-000002:8k_2_02:71]
FORWARD-LOOKING STATEMENTS

[0001069202-20-000002:8k_2_02:72]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations |
| (Amounts in millions, except per share data) | For the Three Months Ended December 31 |  | For the Years Ended December 31, |
|  | (Unaudited) |  |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 885.0 |  |  | $ | 843.6 |  |  | $ | 3,807.2 |  |  | $ | 3,883.9 |  |
| Cost of goods sold | 637.2 |  |  | 619.1 |  |  | 2,727.4 |  |  | 2,772.7 |  |
| Gross profit | 247.8 |  |  | 224.5 |  |  | 1,079.8 |  |  | 1,111.2 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 144.2 |  |  | 142.1 |  |  | 585.9 |  |  | 608.2 |  |
| Losses (gains) and other expenses, net | 3.0 |  |  | 3.3 |  |  | 8.3 |  |  | 13.4 |  |
| Restructuring charges | 3.8 |  |  | 1.1 |  |  | 10.3 |  |  | 3.0 |  |
| Loss (gain), net on sale of businesses and related property | 1.5 |  |  | 1.2 |  |  | 10.6 |  |  | 27.0 |  |
| Gain from insurance recoveries, net of losses incurred | (93.4 | ) |  | (38.6 | ) |  | (178.8 | ) |  | (38.3 | ) |
| Income from equity method investments | (2.9 | ) |  | (1.2 | ) |  | (13.4 | ) |  | (12.0 | ) |
| Operating income | 191.6 |  |  | 116.6 |  |  | 656.9 |  |  | 509.9 |  |
| Pension settlements | 38.6 |  |  | 0.4 |  |  | 99.2 |  |  | 0.4 |  |
| Interest expense, net | 11.0 |  |  | 9.8 |  |  | 47.5 |  |  | 38.3 |  |
| Other expense (income), net | 0.6 |  |  | 0.9 |  |  | 2.3 |  |  | 3.3 |  |
| Income from continuing operations before income taxes | 141.4 |  |  | 105.5 |  |  | 507.9 |  |  | 467.9 |  |
| Provision for income taxes | 27.6 |  |  | 30.2 |  |  | 99.1 |  |  | 107.6 |  |
| Income from continuing operations | 113.8 |  |  | 75.3 |  |  | 408.8 |  |  | 360.3 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes | 0.3 |  |  | 0.4 |  |  | (0.1 | ) |  | 0.8 |  |
| Provision for income taxes | 0.1 |  |  | 0.1 |  |  | — |  |  | 2.1 |  |
| Income (loss) from discontinued operations | 0.2 |  |  | 0.3 |  |  | (0.1 | ) |  | (1.3 | ) |
| Net income | $ | 114.0 |  |  | $ | 75.6 |  |  | $ | 408.7 |  |  | $ | 359.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.95 |  |  | $ | 1.88 |  |  | $ | 10.49 |  |  | $ | 8.87 |  |
| Loss from discontinued operations | 0.01 |  |  | 0.01 |  |  | — |  |  | (0.03 | ) |
| Net income | $ | 2.96 |  |  | $ | 1.89 |  |  | $ | 10.49 |  |  | $ | 8.84 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 2.92 |  |  | $ | 1.86 |  |  | $ | 10.38 |  |  | $ | 8.77 |  |
| Loss from discontinued operations | 0.01 |  |  | 0.01 |  |  | — |  |  | (0.03 | ) |
| Net income | $ | 2.93 |  |  | $ | 1.87 |  |  | $ | 10.38 |  |  | $ | 8.74 |  |
| Weighted Average Number of Shares Outstanding - Basic | 38.6 |  |  | 40.0 |  |  | 39.0 |  |  | 40.6 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 38.9 |  |  | 40.5 |  |  | 39.4 |  |  | 41.1 |  |

[0001069202-20-000002:8k_2_02:73]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |

[0001069202-20-000002:8k_2_02:74]
| (Amounts in millions) | For the Three Months Ended December 31, (Unaudited) |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 498.9 |  |  | $ | 460.7 |  |  | $ | 2,291.1 |  |  | $ | 2,225.0 |  |
| Commercial Heating & Cooling | 259.5 |  |  | 232.6 |  |  | 947.4 |  |  | 900.7 |  |
| Refrigeration (1) | 126.6 |  |  | 129.0 |  |  | 534.4 |  |  | 538.8 |  |
|  | $ | 885.0 |  |  | $ | 822.3 |  |  | $ | 3,772.9 |  |  | $ | 3,664.5 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 98.0 |  |  | $ | 81.5 |  |  | $ | 464.6 |  |  | $ | 399.4 |  |
| Commercial Heating & Cooling | 49.4 |  |  | 39.9 |  |  | 165.4 |  |  | 157.5 |  |
| Refrigeration (1) | 14.1 |  |  | 13.4 |  |  | 62.3 |  |  | 70.7 |  |
| Corporate and other | (28.2 | ) |  | (22.5 | ) |  | (82.4 | ) |  | (84.4 | ) |
| Total adjusted segment profit | 133.3 |  |  | 112.3 |  |  | 609.9 |  |  | 543.2 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Special product quality adjustment | 0.4 |  |  | — |  |  | (0.6 | ) |  | — |  |
| Loss (gain), net on sale of businesses and related property | 1.5 |  |  | 1.2 |  |  | 10.6 |  |  | 27.0 |  |
| Insurance recoveries received for property damage incurred from natural disaster | (68.0 | ) |  | (11.2 | ) |  | (79.6 | ) |  | (10.9 | ) |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 4.0 |  |  | 2.2 |  |  | 11.3 |  |  | 11.4 |  |
| Restructuring charges | 3.8 |  |  | 1.1 |  |  | 10.3 |  |  | 3.0 |  |
| Operating loss (income) from non-core businesses (1) | — |  |  | 2.4 |  |  | 1.0 |  |  | 2.6 |  |
| Operating income | $ | 191.6 |  |  | $ | 116.6 |  |  | $ | 656.9 |  |  | $ | 509.9 |  |

[0001069202-20-000002:8k_2_02:75]
(1) Excludes the non-core business results related to Kysor Warren, which was sold in March 2019 and the Company's business operations in Australia, Asia and South America, which were sold in 2018.

[0001069202-20-000002:8k_2_02:76]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-20-000002:8k_2_02:77]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-20-000002:8k_2_02:78]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-20-000002:8k_2_02:79]
| ◦ | Special legal contingency charges, |

[0001069202-20-000002:8k_2_02:80]
| ◦ | Asbestos-related litigation, |

[0001069202-20-000002:8k_2_02:81]
| ◦ | Environmental liabilities, |

[0001069202-20-000002:8k_2_02:82]
| ◦ | Other items, net, |

[0001069202-20-000002:8k_2_02:83]
| • | Special inventory write down, |

[0001069202-20-000002:8k_2_02:84]
| • | Special product quality adjustment, |

[0001069202-20-000002:8k_2_02:85]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-20-000002:8k_2_02:86]
| • | Insurance recoveries received for property damage incurred from natural disaster, |

[0001069202-20-000002:8k_2_02:87]
| • | Operating loss (income) from non-core businesses; and |

[0001069202-20-000002:8k_2_02:88]
| • | Restructuring charges. |

[0001069202-20-000002:8k_2_02:89]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
|  | As of December 31, |
| (Amounts in millions, except shares and par values) | 2019 |  | 2018 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 37.3 |  |  | $ | 46.3 |  |
| Short-term investments | 2.9 |  |  | — |  |
| Accounts and notes receivable, net of allowances of $6.1 and $6.3 in 2019 and 2018, respectively | 477.8 |  |  | 472.7 |  |
| Inventories, net | 544.1 |  |  | 509.8 |  |
| Other assets | 58.8 |  |  | 60.6 |  |
| Total current assets | 1,120.9 |  |  | 1,089.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $824.3 and $778.5 in 2019 and 2018, respectively | 445.4 |  |  | 408.3 |  |
| Right-of-use assets from operating leases | 181.6 |  |  | — |  |
| Goodwill | 186.5 |  |  | 186.6 |  |
| Deferred income taxes | 21.5 |  |  | 67.0 |  |
| Other assets, net | 79.0 |  |  | 65.9 |  |
| Total assets | $ | 2,034.9 |  |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | 321.9 |  |  | 300.8 |  |
| Current operating lease liabilities | 52.7 |  |  | — |  |
| Accounts payable | 372.4 |  |  | 433.3 |  |
| Accrued expenses | 255.7 |  |  | 272.3 |  |
| Income taxes payable | — |  |  | 2.1 |  |
| Total current liabilities | 1,002.7 |  |  | 1,008.5 |  |
| Long-term debt | 849.3 |  |  | 740.5 |  |
| Long-term operating lease liabilities | 131.0 |  |  | — |  |
| Pensions | 87.4 |  |  | 82.8 |  |
| Other liabilities | 134.7 |  |  | 135.0 |  |
| Total liabilities | 2,205.1 |  |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' deficit: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,093.5 |  |  | 1,078.8 |  |
| Retained earnings | 2,148.7 |  |  | 1,855.0 |  |
| Accumulated other comprehensive loss | (103.8 | ) |  | (188.8 | ) |
| Treasury stock, at cost, 48,575,901 shares and 47,312,248 shares for 2019 and 2018, respectively | (3,309.5 | ) |  | (2,895.5 | ) |
| Total stockholders' deficit | (170.2 | ) |  | (149.6 | ) |
| Total liabilities and stockholders' deficit | $ | 2,034.9 |  |  | $ | 1,817.2 |  |

[0001069202-20-000002:8k_2_02:90]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-20-000002:8k_2_02:91]
Consolidated Statements of Cash Flows

[0001069202-20-000002:8k_2_02:92]
| (Amounts in millions) | For the Years Ended December 31, |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 408.7 |  |  | $ | 359.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss (gain), net on sale of businesses and related property | 10.6 |  |  | 27.0 |  |
| Gain from insurance recoveries, net of losses incurred | (79.6 | ) |  | (10.9 | ) |
| Income from equity method investments | (13.4 | ) |  | (12.0 | ) |
| Dividends from Affiliates | 12.3 |  |  | 9.6 |  |
| Restructuring charges, net of cash paid | 6.8 |  |  | 1.3 |  |
| Provision for bad debts | 4.5 |  |  | 4.7 |  |
| Unrealized losses on derivative contracts | (0.5 | ) |  | 1.3 |  |
| Stock-based compensation expense | 21.3 |  |  | 26.3 |  |
| Depreciation and amortization | 71.1 |  |  | 66.0 |  |
| Deferred income taxes | 16.6 |  |  | 25.2 |  |
| Pension expense | 106.1 |  |  | 8.8 |  |
| Pension contributions | (1.8 | ) |  | (20.6 | ) |
| Other items, net | (0.4 | ) |  | 5.1 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (33.1 | ) |  | (9.9 | ) |
| Inventories | (63.9 | ) |  | (84.2 | ) |
| Other current assets | 2.8 |  |  | (0.2 | ) |
| Accounts payable | (56.1 | ) |  | 102.2 |  |
| Accrued expenses | (5.6 | ) |  | 5.9 |  |
| Income taxes payable and receivable | (1.9 | ) |  | (5.5 | ) |
| Leases, net | 2.1 |  |  | — |  |
| Other, net | (10.5 | ) |  | (3.6 | ) |
| Net cash provided by operating activities | 396.1 |  |  | 495.5 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.3 |  |  | 0.1 |  |
| Purchases of property, plant and equipment | (105.6 | ) |  | (95.2 | ) |
| Net proceeds from sale of businesses | 43.5 |  |  | 114.7 |  |
| Purchases of short-term investments | (2.9 | ) |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 79.6 |  |  | 10.9 |  |
| Net cash (used in) provided by investing activities | 15.9 |  |  | 30.5 |  |
| Cash flows from financing activities: |  |  |  |
| Short-term debt payments | (5.3 | ) |  | (40.3 | ) |
| Short-term debt proceeds | 5.3 |  |  | 40.3 |  |
| Asset securitization borrowings | 150.5 |  |  | 155.0 |  |
| Asset securitization payments | (133.5 | ) |  | (163.0 | ) |
| Long-term debt payments | (6.4 | ) |  | (3.0 | ) |
| Borrowings from credit facility | 1,828.5 |  |  | 2,435.9 |  |
| Payments on credit facility | (1,731.0 | ) |  | (2,395.0 | ) |
| Payments of deferred financing costs | (0.3 | ) |  | — |  |
| Proceeds from employee stock purchases | 3.3 |  |  | 3.3 |  |
| Repurchases of common stock | (400.0 | ) |  | (450.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (24.0 | ) |  | (26.9 | ) |
| Cash dividends paid | (110.5 | ) |  | (93.9 | ) |
| Net cash used in financing activities | (423.4 | ) |  | (537.8 | ) |
| Decrease in cash and cash equivalents | (11.4 | ) |  | (11.8 | ) |
| Effect of exchange rates on cash and cash equivalents | 2.4 |  |  | (10.1 | ) |
| Cash and cash equivalents, beginning of period | 46.3 |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 37.3 |  |  | $ | 46.3 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 46.8 |  |  | $ | 38.7 |  |
| Income taxes paid (net of refunds) | $ | 83.0 |  |  | $ | 90.0 |  |
| Insurance recoveries received | $ | 243.2 |  |  | $ | 124.3 |  |

[0001069202-20-000002:8k_2_02:93]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. During the first quarter of 2019, the Company completed the sale of its Kysor Warren business. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The sale of the Company's business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of the Company's business in South America was completed in the third quarter of 2018. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |
|  | (Unaudited) |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 141.4 |  | $ | (27.6 | ) | $ | 113.8 |  |  | $ | 105.5 |  | $ | (30.2 | ) | $ | 75.3 |  |
| Restructuring charges | 3.8 |  | (1.2 | ) | 2.6 |  |  | 1.1 |  | (0.2 | ) | 0.9 |  |
| Pension settlement | 38.6 |  | (9.7 | ) | 28.9 |  |  | 0.4 |  | — |  | 0.4 |  |
| Special product quality adjustments (b) | 0.4 |  | (0.1 | ) | 0.3 |  |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | 0.8 |  | (0.2 | ) | 0.6 |  |  | 0.1 |  | — |  | 0.1 |  |
| Asbestos-related litigation (a) | (0.2 | ) | (0.1 | ) | (0.3 | ) |  | 0.7 |  | (0.3 | ) | 0.4 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | (0.2 | ) | 0.1 |  | (0.1 | ) |  | 0.1 |  | — |  | 0.1 |  |
| Environmental liabilities (a) | 3.3 |  | (0.6 | ) | 2.7 |  |  | 0.8 |  | (0.1 | ) | 0.7 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (4.0 | ) | (4.0 | ) |  | — |  | (3.9 | ) | (3.9 | ) |
| Other tax items, net (c) | — |  | 0.7 |  | 0.7 |  |  | — |  | 10.5 |  | 10.5 |  |
| Loss on sale of businesses | 1.5 |  | (0.6 | ) | 0.9 |  |  | 1.2 |  | (1.3 | ) | (0.1 | ) |
| Insurance recoveries received for property damage incurred from natural disaster (g) | (68.0 | ) | 17.0 |  | (51.0 | ) |  | (11.2 | ) | 2.8 |  | (8.4 | ) |
| Other items, net (a) | 0.3 |  | (0.3 | ) | — |  |  | 0.5 |  | 1.3 |  | 1.8 |  |
| Non-core business results (f) | — |  | — |  | — |  |  | 2.7 |  | (0.6 | ) | 2.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 121.7 |  | $ | (26.6 | ) | $ | 95.1 |  |  | $ | 101.9 |  | $ | (22.0 | ) | $ | 79.9 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 2.92 |  |  |  |  |  |  | $ | 1.86 |  |
| Restructuring charges |  |  |  |  | 0.07 |  |  |  |  |  |  | 0.02 |  |
| Pension settlement |  |  | 0.74 |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | — |  |
| Asbestos-related litigation (a) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.07 |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.10 | ) |  |  |  |  |  | (0.09 | ) |
| Other tax items, net (c) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.26 |  |
| Loss on sale of businesses |  |  |  |  | 0.02 |  |  |  |  |  |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster (g) |  |  |  |  | (1.31 | ) |  |  |  |  |  | (0.21 | ) |
| Other items, net (a) |  |  |  |  | — |  |  |  |  |  |  | 0.04 |  |

[0001069202-20-000002:8k_2_02:94]
| Non-core business results (f) |  |  |  |  | — |  |  |  |  |  |  | 0.05 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | — |  |  |  |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 2.45 |  |  |  |  | $ | 1.98 |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represents the Kysor Warren business, not included elsewhere in the reconciliation. |
| (g) Recorded in Gain from insurance recoveries, net of losses incurred in the Consolidated Statement of Operations. |
|  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |
|  | Pre-Tax | Tax Impact (e) | After Tax |  | Pre-Tax | Tax Impact (e) | After Tax |
| Income from continuing operations, a GAAP measure | $ | 507.9 |  | $ | (99.1 | ) | $ | 408.8 |  |  | $ | 467.9 |  | $ | (107.6 | ) | $ | 360.3 |  |
| Restructuring charges | 10.3 |  | (2.6 | ) | 7.7 |  |  | 3.0 |  | (0.7 | ) | 2.3 |  |
| Pension settlements | 99.2 |  | (24.8 | ) | 74.4 |  |  | 0.4 |  | — |  | 0.4 |  |
| Special product quality adjustments (b) | (0.6 | ) | 0.1 |  | (0.5 | ) |  | — |  | — |  | — |  |
| Special legal contingency charges (a) | 1.2 |  | (0.3 | ) | 0.9 |  |  | 1.9 |  | (0.4 | ) | 1.5 |  |
| Asbestos-related litigation (a) | 3.1 |  | (0.8 | ) | 2.3 |  |  | 4.0 |  | (1.1 | ) | 2.9 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) | (0.5 | ) | 0.2 |  | (0.3 | ) |  | 1.5 |  | (0.3 | ) | 1.2 |  |
| Inventory write down (b) | — |  | — |  | — |  |  | 0.2 |  | — |  | 0.2 |  |
| Environmental liabilities (a) | 5.7 |  | (1.1 | ) | 4.6 |  |  | 2.2 |  | (0.4 | ) | 1.8 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (10.9 | ) | (10.9 | ) |  | — |  | (10.5 | ) | (10.5 | ) |
| Other tax items, net (c) | — |  | 3.9 |  | 3.9 |  |  | — |  | 5.8 |  | 5.8 |  |
| Loss (gain), net on sale of businesses and related property | 10.6 |  | (4.1 | ) | 6.5 |  |  | 27.0 |  | (1.0 | ) | 26.0 |  |
| Insurance recoveries received for property damage incurred from natural disaster (g) | (79.6 | ) | 19.8 |  | (59.8 | ) |  | (10.9 | ) | 2.7 |  | (8.2 | ) |
| Other items, net (a) | 1.8 |  | (0.5 | ) | 1.3 |  |  | 1.8 |  | 0.7 |  | 2.5 |  |
| Non-core business results (f) | 1.3 |  | (0.3 | ) | 1.0 |  |  | 4.4 |  | (0.9 | ) | 3.5 |  |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 560.4 |  | $ | (120.5 | ) | $ | 439.9 |  |  | $ | 503.4 |  | $ | (113.7 | ) | $ | 389.7 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 10.38 |  |  |  |  |  |  | $ | 8.77 |  |
| Restructuring charges |  |  |  |  | 0.20 |  |  |  |  |  |  | 0.06 |  |
| Pension settlements |  |  | 1.89 |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  | (0.01 | ) |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.04 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.06 |  |  |  |  |  |  | 0.07 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) |  |  |  |  | (0.01 | ) |  |  |  |  |  | 0.03 |  |
| Inventory write down (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.12 |  |  |  |  |  |  | 0.05 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.28 | ) |  |  |  |  |  | (0.26 | ) |
| Other tax items, net (c) |  |  |  |  | 0.10 |  |  |  |  |  |  | 0.14 |  |
| Loss (gain), net on sale of businesses and related property |  |  |  |  | 0.17 |  |  |  |  |  |  | 0.63 |  |

[0001069202-20-000002:8k_2_02:95]
| Insurance recoveries received for property damage incurred from natural disaster (g) |  |  |  |  | (1.52 | ) |  |  |  |  |  | (0.20 | ) |
| Other items, net (a) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.06 |  |
| Non-core business results (f) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.09 |  |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.03 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 11.19 |  |  |  |  |  |  | $ | 9.52 |  |
| (a) Recorded in Losses (Gains) and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts the Company's diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to the Company's business operations in Australia, Asia, and South America and the Kysor Warren business, not included elsewhere in the reconciliation. |
| (g) Recorded in Gain from insurance recoveries, net of losses incurred in the Consolidated Statement of Operations. |

[0001069202-20-000002:8k_2_02:96]
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | — |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | (0.4 | ) |
| Foreign currency exchange (gains) losses (a) | (0.5 | ) |  | 0.5 |  |  | (1.5 | ) |  | 1.7 |  |
| (Gain) loss on disposal of fixed assets (a) | — |  |  | 0.5 |  |  | (0.2 | ) |  | 0.7 |  |
| Other operating (gains) losses (a) | (0.5 | ) |  | — |  |  | (1.7 | ) |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | (0.2 | ) |  | 0.1 |  |  | (0.5 | ) |  | 1.5 |  |
| Special legal contingency charges (b) | 0.8 |  |  | 0.1 |  |  | 1.2 |  |  | 1.9 |  |
| Asbestos-related litigation (b) | (0.2 | ) |  | 0.7 |  |  | 3.1 |  |  | 4.0 |  |
| Environmental liabilities (b) | 3.3 |  |  | 0.8 |  |  | 5.7 |  |  | 2.2 |  |
| Other items, net (b) | 0.3 |  |  | 0.5 |  |  | 1.8 |  |  | 1.8 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.0 |  |  | $ | 3.3 |  |  | $ | 8.3 |  |  | $ | 13.4 |  |

[0001069202-20-000002:8k_2_02:97]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001069202-20-000002:8k_2_02:98]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2020ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $11.30-$11.90 |
| Other non-core EBIT charges |  | 0.00 |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $11.30-$11.90 |

[0001069202-20-000002:8k_2_02:99]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Average shares outstanding - diluted, a GAAP measure | 38.9 |  |  | 40.5 |  |  | 39.4 |  |  | $ | 41.1 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | — |  |  | (0.2 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 38.9 |  |  | 40.3 |  |  | 39.3 |  |  | 41.0 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 126.6 |  |  | $ | 150.3 |  |  | $ | 885.0 |  |  | $ | 843.6 |  |
| Net sales from non-core businesses (a) | — |  |  | 21.3 |  |  | — |  |  | 21.3 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 126.6 |  |  | $ | 129.0 |  |  | $ | 885.0 |  |  | $ | 822.3 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales, a GAAP measure | $ | 568.7 |  |  | $ | 758.2 |  |  | $ | 3,807.2 |  |  | $ | 3,883.9 |  |
| Net sales from non-core businesses (a) | 34.3 |  |  | 219.4 |  |  | 34.3 |  |  | 219.4 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 534.4 |  |  | $ | 538.8 |  |  | $ | 3,772.9 |  |  | $ | 3,664.5 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 39.0 |  |  | $ | 43.3 |  |  | $ | 247.8 |  |  | $ | 224.5 |  |
| Non-GAAP adjustments to gross profit | (1.3 | ) |  | — |  |  | (0.4 | ) |  | — |  |
| Gross profit from non-core businesses (a) | — |  |  | 2.4 |  |  | — |  |  | 2.4 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 40.3 |  |  | $ | 40.9 |  |  | $ | 248.2 |  |  | $ | 222.1 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |

[0001069202-20-000002:8k_2_02:100]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit, a GAAP measure | $ | 174.6 |  |  | $ | 218.3 |  |  | $ | 1,079.8 |  |  | $ | 1,111.2 |  |
| Non-GAAP adjustments to gross profit | (1.3 | ) |  | (0.2 | ) |  | 0.6 |  |  | (0.2 | ) |
| Gross profit from non-core businesses (a) | 3.6 |  |  | 36.4 |  |  | 3.6 |  |  | 36.4 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 172.3 |  |  | $ | 182.1 |  |  | $ | 1,075.6 |  |  | $ | 1,075.0 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a Non-GAAP measure | $ | 14.1 |  |  | $ | 11.0 |  |  | $ | 133.3 |  |  | $ | 109.9 |  |
| (Loss) profit from non-core businesses (a) | — |  |  | (2.4 | ) |  | — |  |  | (2.4 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 14.1 |  |  | $ | 13.4 |  |  | $ | 133.3 |  |  | $ | 112.3 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit, a Non-GAAP measure | $ | 61.3 |  |  | $ | 68.1 |  |  | $ | 608.9 |  |  | $ | 540.6 |  |
| (Loss) profit from non-core businesses (a) | (1.0 | ) |  | (2.6 | ) |  | (1.0 | ) |  | (2.6 | ) |
| Adjusted Segment profit, a Non-GAAP measure | $ | 62.3 |  |  | $ | 70.7 |  |  | $ | 609.9 |  |  | $ | 543.2 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure (dollars in millions) |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 27.0 |  |  | $ | 31.9 |  |  | $ | 144.2 |  |  | $ | 142.1 |  |
| Selling, general and administrative expenses from non-core businesses (a) | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 27.0 |  |  | $ | 27.3 |  |  | $ | 144.2 |  |  | $ | 137.5 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses, a GAAP measure | $ | 117.1 |  |  | $ | 153.0 |  |  | $ | 585.9 |  |  | $ | 608.2 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 4.6 |  |  | 39.3 |  |  | 4.6 |  |  | 39.3 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 112.5 |  |  | $ | 113.7 |  |  | $ | 581.3 |  |  | $ | 568.9 |  |
| (a) Non-Core businesses represent the Company's business operations in Australia, Asia, and South America and the Kysor Warren business. |  |  |  |  |

[0001069202-20-000002:8k_2_02:101]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net cash provided by operating activities, a GAAP measure | $ | 271.6 |  |  | $ | 264.2 |  |  | $ | 396.1 |  |  | $ | 495.5 |  |
| Purchases of property, plant and equipment | (28.6 | ) |  | (34.3 | ) |  | (105.6 | ) |  | (95.2 | ) |
| Proceeds from the disposal of property, plant and equipment | 0.1 |  |  | — |  |  | 1.3 |  |  | 0.1 |  |
| Insurance recoveries received for property damage incurred from natural disaster | 68.0 |  |  | 6.7 |  |  | 79.6 |  |  | 10.9 |  |
| Free cash flow, a Non-GAAP measure | 311.1 |  |  | 236.6 |  |  | 371.4 |  |  | 411.3 |  |

[0001069202-20-000002:8k_2_02:102]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2019 |
| Adjusted EBIT (b)(a) |  |  |  |  |  |  | $ | 609.9 |  |
| Depreciation and amortization expense (c) |  |  |  |  |  |  | 70.1 |  |
| EBITDA (b + c) |  |  |  |  |  |  | $ | 680.0 |  |
| Total debt at December 31, 2019 (d) |  |  |  |  |  |  | $ | 1,171.2 |  |
| Total Debt to EBITDA ratio ((d / (b + c)) |  |  |  |  |  |  | 1.7 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2019 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 507.9 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 11.3 |  |
| Special product quality adjustments | (0.6 | ) |
| Restructuring charges | 10.3 |  |
| Interest expense, net | 47.5 |  |
| Pension settlements | 99.2 |  |
| Loss (gain), net on sale of businesses and related property | 10.6 |  |
| Insurance recoveries received for property damage incurred from natural disaster | (79.6 | ) |
| Non-core business results (a) | 1.0 |  |
| Other expense (income), net | 2.3 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 609.9 |  |
| (a) Non-Core business represents the Kysor Warren business. |  |  |  |  |
