# LII MD&A — 0001069202-14-000004


## mdna

[0001069202-14-000004:mdna:1]
[same as prior period, unchanged from 0001069202-13-000011:mdna:1]

[0001069202-14-000004:mdna:2]
[same as prior period, unchanged from 0001069202-13-000011:mdna:2]

[0001069202-14-000004:mdna:3]
[same as prior period, unchanged from 0001069202-13-000011:mdna:3]

[0001069202-14-000004:mdna:4]
[same as prior period, unchanged from 0001069202-13-000011:mdna:4]

[0001069202-14-000004:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-14-000004:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components have impacted us and the HVACR industry in general.  We seek to mitigate the impact of higher commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-14-000004:mdna:7]
[same as prior period, unchanged from 0001069202-13-000011:mdna:12]

[0001069202-14-000004:mdna:8]
| • | Net sales increased $27 million, or 4%, to $695 million in the first quarter of 2014 compared to $668 million in the first quarter of 2013. Net sales increased 6% when excluding a 2% unfavorable foreign currency exchange rate impact. |

[0001069202-14-000004:mdna:9]
| • | Operational income from continuing operations in the first quarter of 2014 increased $6 million to $34 million from $28 million in the first quarter of 2013. |

[0001069202-14-000004:mdna:10]
| • | Net income for the first quarter of 2014 increased $12 million to $20 million from $8 million in the first quarter of 2013. |

[0001069202-14-000004:mdna:11]
| • | Diluted earnings per share from continuing operations were $0.40 per share in the first quarter of 2014 compared to $0.31 per share in the first quarter of 2013. |

[0001069202-14-000004:mdna:12]
| • | Cash used in operating activities was $125 million in the first three months of 2014 compared to $137 million in the first three months of 2013. |

[0001069202-14-000004:mdna:13]
| • | We returned $12 million to shareholders through dividend payments. |

[0001069202-14-000004:mdna:14]
Overview of Results

[0001069202-14-000004:mdna:15]
On a consolidated basis, net sales increased 4% primarily due to volume increases and favorable product mix.  Our gross profit margin of 24.2% was comparable quarter over quarter and Selling, general & administrative expenses (“SG&A”) as a percentage of net sales declined approximately 1% to 19%.  Operational income from continuing operations increased $6 million quarter over quarter benefiting from the higher volumes and favorable price and mix.

[0001069202-14-000004:mdna:16]
The Residential Heating & Cooling segment led our overall operational performance in the first quarter of 2014, with a 9% increase in net sales and a $4 million increase in segment profit compared to the first quarter of 2013.  This segment benefited from industry growth and market share gains.  Sales in the Commercial Heating & Cooling segment increased 6% and segment profit declined $1 million in the first quarter of 2014 compared to the first quarter of 2013.  This segment's sales were up due to volume increases while profits were slightly down because the benefits from higher volumes were offset by costs for various growth and productivity initiatives.  Sales in the Refrigeration segment were down 6% and segment profit decreased $5 million in the first quarter of 2014 compared to the first quarter of 2013.  This segment was impacted by unfavorable foreign currency exchange rates, lower volumes and factory investments for future growth.  Also, Corporate and Other expenses declined by $8 million primarily due to lower incentive compensation.

[0001069202-14-000004:mdna:17]
First Quarter of 2014 Compared to First Quarter of 2013 - Consolidated Results

[0001069202-14-000004:mdna:18]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-14-000004:mdna:19]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 695.4 |  |  | $ | 668.4 |  |  | 4.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 527.3 |  |  | 506.4 |  |  | (4.1 | ) |  | 75.8 |  |  | 75.8 |  |
| Gross profit | 168.1 |  |  | 162.0 |  |  | 3.8 |  |  | 24.2 |  |  | 24.2 |  |
| Selling, general and administrative expenses | 135.6 |  |  | 135.6 |  |  | — |  |  | 19.5 |  |  | 20.3 |  |
| Losses and other expenses, net | 2.4 |  |  | 1.1 |  |  | 118.2 |  |  | 0.3 |  |  | 0.2 |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |  | 80.0 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (3.9 | ) |  | (3.1 | ) |  | 25.8 |  |  | (0.6 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 33.9 |  |  | $ | 27.9 |  |  | 21.5 | % |  | 4.9 | % |  | 4.2 | % |

[0001069202-14-000004:mdna:20]
[same as prior period, unchanged from 0001069202-13-000011:mdna:21]

[0001069202-14-000004:mdna:21]
Net sales increased 4% in the first quarter of 2014 compared to the first quarter of 2013, with sales volumes up 5% and price and mix up 1%.  The volume increases were driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Changes in foreign currency exchange rates unfavorably impacted net sales by 2%.

[0001069202-14-000004:mdna:22]
[same as prior period, unchanged from 0001069202-13-000011:mdna:23]

[0001069202-14-000004:mdna:23]
Gross profit margins of 24.2% in the first quarter of 2014 were flat compared to the first quarter of 2013.  Improvements of 30 basis points ("bps") from higher volumes, 30 bps from favorable price and mix and 140 bps from commodity and non-commodity product cost savings were by offset by 80 bps of higher freight and distribution costs and 120 bps from costs related to growth and productivity initiatives and factory investments for future growth.

[0001069202-14-000004:mdna:24]
[same as prior period, unchanged from 0001069202-13-000011:mdna:25]

[0001069202-14-000004:mdna:25]
SG&A of $136 million was flat in the first quarter of 2014 compared to the first quarter of 2013, and as a percentage of net sales, declined 80 bps from 20.3% to 19.5%.  The largest driver of the decrease in SG&A as a percentage of net sales was lower incentive compensation.

[0001069202-14-000004:mdna:26]
Losses and Other Expenses, Net

[0001069202-14-000004:mdna:27]
Losses and other expenses, net for first quarters of 2014 and 2013 included the following (in millions):

[0001069202-14-000004:mdna:28]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Realized losses on settled futures contracts | $ | 0.2 |  |  | $ | — |  |
| Net change in unrealized losses on unsettled futures contracts | 0.6 |  |  | 1.0 |  |
| Foreign currency exchange losses (gains) | 0.8 |  |  | (0.2 | ) |
| Losses on disposal of fixed assets | 0.1 |  |  | — |  |
| Special legal contingency charges | 0.4 |  |  | 0.2 |  |
| Asbestos-related litigation | 0.2 |  |  | — |  |
| Other items, net | 0.1 |  |  | 0.1 |  |
| Losses and other expenses, net | $ | 2.4 |  |  | $ | 1.1 |  |

[0001069202-14-000004:mdna:29]
The increase in realized losses on settled futures contracts in the first quarter of 2014 was attributable to decreases in commodity prices relative to our settled futures contract prices.  Conversely, the decrease in unrealized losses on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses increased in the first quarter of 2014 primarily due to unfavorable Australian dollar exchange rates.

[0001069202-14-000004:mdna:30]
[same as prior period, unchanged from 0001069202-13-000011:mdna:31]

[0001069202-14-000004:mdna:31]
There were no significant restructuring charges incurred in the first quarter of 2014 or 2013.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000004:mdna:32]
[same as prior period, unchanged from 0001069202-13-000011:mdna:33]

[0001069202-14-000004:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $4 million in the first quarter of 2014 increased $1 million over the first quarter of 2013 due to improved operating results from our joint ventures.

[0001069202-14-000004:mdna:34]
[same as prior period, unchanged from 0001069202-13-000011:mdna:35]

[0001069202-14-000004:mdna:35]
Interest expense, net of $3 million in the first quarter of 2014 was flat compared to the first quarter of 2013.  The impact of the increase in our average net borrowings was offset by a slight decline in weighted average borrowing rates over the comparable periods.

[0001069202-14-000004:mdna:36]
[same as prior period, unchanged from 0001069202-13-000011:mdna:37]

[0001069202-14-000004:mdna:37]
The Provision for income taxes was $11 million in the first quarter of 2014 compared to $9 million in the first quarter of 2013.  The effective tax rate was 35.0% for the first quarter of 2014 compared to 35.2% for the first quarter of 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000004:mdna:38]
[same as prior period, unchanged from 0001069202-13-000011:mdna:39]

[0001069202-14-000004:mdna:39]
The Loss from discontinued operations includes the results from the Service Experts business sold in March 2013 and the Hearth business sold in April 2012.  Neither the Service Experts nor Hearth businesses had significant gains, losses or other activity in the first quarter of 2014.

[0001069202-14-000004:mdna:40]
In the first quarter of 2013, the pre-tax Loss from discontinued operations was $13 million and consisted of Service Experts operating losses of $13 million, $2 million of retention bonuses and severance costs and an offsetting $2 million gain on the sale of the business.  The Hearth business did not have any significant gains, losses or other activity in the first quarter of 2013.

[0001069202-14-000004:mdna:41]
First Quarter of 2014 Compared to First Quarter of 2013 - Results by Segment

[0001069202-14-000004:mdna:42]
[same as prior period, unchanged from 0001069202-13-000011:mdna:43]

[0001069202-14-000004:mdna:43]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000004:mdna:44]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 342.1 |  |  | $ | 314.5 |  |  | $ | 27.6 |  |  | 8.8 | % |
| Profit | $ | 24.4 |  |  | $ | 20.5 |  |  | $ | 3.9 |  |  | 19.0 | % |
| % of net sales | 7.1 | % |  | 6.5 | % |  |  |  |  |

[0001069202-14-000004:mdna:45]
Residential Heating & Cooling net sales increased by 9% in the first quarter of 2014 compared to the first quarter of 2013.  Sales volumes increased by 7% due to industry growth and market share gains and the benefits of favorable price and mix contributed 3%.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-14-000004:mdna:46]
Segment profit for the first quarter of 2014 increased $4 million due to $7 million in higher sales volumes, $7 million in commodity and non-commodity product cost savings and $1 million from favorable price and mix.  Partially offsetting these increases were $6 million in higher SG&A costs primarily due to higher employee compensation costs and $5 million of higher freight and distribution expenses primarily related to continued investment in distribution initiatives.

[0001069202-14-000004:mdna:47]
[same as prior period, unchanged from 0001069202-13-000011:mdna:48]

[0001069202-14-000004:mdna:48]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000004:mdna:49]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 173.0 |  |  | $ | 163.0 |  |  | $ | 10.0 |  |  | 6.1 | % |
| Profit | $ | 10.2 |  |  | $ | 11.1 |  |  | $ | (0.9 | ) |  | (8.1 | )% |
| % of net sales | 5.9 | % |  | 6.8 | % |  |  |  |  |

[0001069202-14-000004:mdna:50]
Commercial Heating & Cooling net sales increased 6% in the first quarter of 2014 compared to the first quarter of 2013 due  to broad-based volume increases in North America.  Foreign currency exchange rates had a neutral impact.

[0001069202-14-000004:mdna:51]
Segment profit in the first quarter of 2014 declined $1 million compared to the first quarter of 2013.  The benefits of $3 million from higher volumes and $1 million from commodity and non-commodity material cost savings were offset by $2 million of higher SG&A costs and $3 million of costs primarily related to growth and productivity initiatives.

[0001069202-14-000004:mdna:52]
[same as prior period, unchanged from 0001069202-13-000011:mdna:53]

[0001069202-14-000004:mdna:53]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000004:mdna:54]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 180.3 |  |  | $ | 190.9 |  |  | $ | (10.6 | ) |  | (5.6 | )% |
| Profit | $ | 12.1 |  |  | $ | 16.7 |  |  | $ | (4.6 | ) |  | (27.5 | )% |
| % of net sales | 6.7 | % |  | 8.7 | % |  |  |  |  |

[0001069202-14-000004:mdna:55]
Refrigeration net sales declined 6% in the first quarter of 2014 compared to the first quarter of 2013 primarily due to a 4% unfavorable impact from Australian dollar exchange rates.  Also, volumes declined 1% primarily from soft market conditions in Australia and the North American supermarket business and price and mix had a 1% unfavorable impact.  We have seen continued

[0001069202-14-000004:mdna:56]
weakness in the Australian economy, and after the latest national election and government changeover, lawmakers have drafted legislation to repeal the carbon tax in that country. We have experienced a slowdown in our Australian refrigeration wholesale business, including our refrigerant operations.

[0001069202-14-000004:mdna:57]
Segment profit for the first quarter of 2014 decreased $5 million compared to the first quarter of 2013 primarily due to factory investments for future growth of $5 million, higher SG&A expenses of $2 million and volume-related declines of $2 million.  Partially offsetting these unfavorable impacts were $2 million from incremental commodity and non-commodity material cost savings and $2 million from the Australian wholesale refrigerant business which continued to benefit from one-time purchases of lower cost inventory.

[0001069202-14-000004:mdna:58]
[same as prior period, unchanged from 0001069202-13-000011:mdna:58]

[0001069202-14-000004:mdna:59]
Corporate and other expenses decreased $8 million to $11 million in the first quarter of 2014 from $19 million in the first quarter of 2013 due primarily to lower incentive compensation.

[0001069202-14-000004:mdna:60]
[same as prior period, unchanged from 0001069202-13-000011:mdna:103]

[0001069202-14-000004:mdna:61]
[same as prior period, unchanged from 0001069202-13-000011:mdna:104]

[0001069202-14-000004:mdna:62]
[same as prior period, unchanged from 0001069202-13-000011:mdna:105]

[0001069202-14-000004:mdna:63]
The following table summarizes our cash flow activity for the three months ended March 31, 2014 and 2013 (in millions):

[0001069202-14-000004:mdna:64]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Net cash used in operating activities | $ | (125.0 | ) |  | $ | (137.3 | ) |
| Net cash used in investing activities | (17.3 | ) |  | (6.9 | ) |
| Net cash provided by financing activities | 144.3 |  |  | 128.6 |  |

[0001069202-14-000004:mdna:65]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2014 and 2013 reflects the seasonal increase in working capital requirements. The $12 million decrease in net cash used in operating activities quarter over quarter is primarily due to higher net income.  Also, the seasonal increase in working capital requirements in 2014 was smaller than the increase in 2013.  However, that favorable cash flow impact was offset by higher income tax payments in 2014.

[0001069202-14-000004:mdna:66]
Net Cash Used in Investing Activities - Capital expenditures were $17 million and $12 million in the first three months of 2014 and 2013, respectively.  Capital expenditures in 2014 were primarily related to an expansion of manufacturing capacity for our Residential Heating & Cooling segment, investments in systems and software to support the overall enterprise and investments in our distribution network.  Net cash used in investing activities in the first quarter of 2013 also included net proceeds of $5 million from the sale of the Service Experts business.

[0001069202-14-000004:mdna:67]
Net Cash Used in Financing Activities - Net cash provided by financing activities increased to $144 million in the first three months of 2014 primarily due to an increase in net borrowings and was partially offset by increases in stock repurchases and cash dividends paid.  Net borrowings were higher in 2014 to support the seasonal working capital increase.  Stock repurchases increased as a higher number of long-term incentive awards were exercised in 2014.  Dividend payments increased because the fourth quarter 2012 dividend was paid in 2012, whereas the fourth quarter 2013 dividend was not paid until the first quarter of 2014.

[0001069202-14-000004:mdna:68]
[same as prior period, unchanged from 0001069202-13-000011:mdna:111]

[0001069202-14-000004:mdna:69]
The following table details our lines of credit and financing arrangements as of March 31, 2014 (in millions):

[0001069202-14-000004:mdna:70]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-term debt: |  |  |  |  |  |
| Foreign obligations | $ | 32.9 |  |  | $ | 8.8 |  |  | $ | 24.1 |  |
| Asset Securitization Program (1) | 160.0 |  |  | 160.0 |  |  | — |  |
| Total short-term debt | $ | 192.9 |  |  | $ | 168.8 |  |  | $ | 24.1 |  |
| Current maturities of long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | — |  |
| Long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 17.0 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 177.0 |  |  | 439.5 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 867.0 |  |  | 394.0 |  |  | 439.5 |  |
| Total debt | $ | 1,061.3 |  |  | $ | 564.2 |  |  | $ | 463.6 |  |

[0001069202-14-000004:mdna:71]
(1) The maximum securitization amount ranges from $160.0 million to $220.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.

[0001069202-14-000004:mdna:72]
(2) The available future borrowings on our domestic revolving credit facility were reduced by the outstanding borrowings and $33.5 million in outstanding standby letters of credit.  We also had $26.0 million in outstanding standby letters of credit outside of the domestic revolving credit facility as of March 31, 2014.

[0001069202-14-000004:mdna:73]
[same as prior period, unchanged from 0001069202-13-000011:mdna:117]

[0001069202-14-000004:mdna:74]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 53.4% at March 31, 2014 from 45.2% at December 31, 2013 due to the increase in our net borrowings, as noted above.

[0001069202-14-000004:mdna:75]
As of March 31, 2014, our senior credit rating with Moody's Investors Service, Inc. ("Moody's") was Baa3 with a stable outlook, which is judged to be lowest investment grade and subject to moderate credit risk and may possess certain speculative characteristics.  Our senior credit rating with Standard & Poor's Rating Group ("S&P") was upgraded in the first quarter of 2014 by one notch to BBB with a stable outlook, which is judged to be investment grade but subject to weakened ability to meet commitments upon adverse economic conditions or changing circumstances.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to retain investment grade ratings from Moody's and S&P to ensure adequate access to capital markets.

[0001069202-14-000004:mdna:76]
[same as prior period, unchanged from 0001069202-13-000011:mdna:119]

[0001069202-14-000004:mdna:77]
We believe our cash and cash equivalents of $39 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $39 million as of March 31, 2014 was $27 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and pay taxes in the United States for the amounts that were repatriated.

[0001069202-14-000004:mdna:78]
Our expected capital expenditures for 2014 are $90 million.  We also continue to increase shareholder value through dividend payments and our share repurchase programs, with targets of $150 million in share repurchases under the existing share repurchase programs and between $50 million and $55 million of dividend payments in 2014.

[0001069202-14-000004:mdna:79]
[same as prior period, unchanged from 0001069202-13-000011:mdna:122]

[0001069202-14-000004:mdna:80]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Our operating lease commitments have not materially changed since December 31, 2013.

[0001069202-14-000004:mdna:81]
Commitments, Contingencies and Guarantees

[0001069202-14-000004:mdna:82]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.
