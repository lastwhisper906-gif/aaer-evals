# LII 8-K — 0001193125-14-149734 filed 2014-04-21

## item codes, every 8-K on or before 2014-04-21

- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2014-04-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-149734:8k_2_02:1]
EX-99.1
2
d712644dex991.htm
EX-99.1

[0001193125-14-149734:8k_2_02:2]
EX-99.1

[0001193125-14-149734:8k_2_02:3]
Exhibit 99.1

[0001193125-14-149734:8k_2_02:4]
Lennox International Reports Record First-Quarter Profit

[0001193125-14-149734:8k_2_02:5]
| • |  | Revenue up 6% at constant currency, led by 10% Residential growth |

[0001193125-14-149734:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations up 27% to $0.42 |

[0001193125-14-149734:8k_2_02:7]
| • |  | GAAP EPS from continuing operations up 29% to $0.40 |

[0001193125-14-149734:8k_2_02:8]
| • |  | Reiterating 2014 revenue growth guidance of 3-7% at constant currency; now expecting 2-6% revenue growth including foreign exchange headwind |

[0001193125-14-149734:8k_2_02:9]
| • |  | Reiterating 2014 adjusted EPS from continuing operations guidance of $4.20-$4.60 |

[0001193125-14-149734:8k_2_02:10]
| • |  | Reiterating plans for $150 million of stock repurchases in 2014 |

[0001193125-14-149734:8k_2_02:11]
DALLAS, April 21, 2014 –
Lennox International Inc. (NYSE: LII) today reported financial results for the first quarter of 2014. Financial results in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-14-149734:8k_2_02:12]
Revenue for the first quarter was $695 million, up 4% from the prior-year quarter. At constant currency, revenue was up 6%. Adjusted earnings per share from
continuing operations was $0.42, up 27% from $0.33 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was $0.40, up 29% from $0.31 in the prior-year quarter.

[0001193125-14-149734:8k_2_02:13]
“First quarter performance was led by our Residential business, with revenue up 10% at constant currency and segment profit up 19%,” said Chairman
and CEO Todd Bluedorn. “In Residential, as well as in Commercial, replacement business was strong, while new construction business was notably impacted by severe weather in the quarter. Commercial revenue grew 6% at constant currency, led by
high single digit growth in North America equipment and service. Segment profit was down 8% on softness in Europe and from investments in the growth of our North American business, including distribution expansion and start-up costs for entrance in
the VRF market in the second half of the year. In Refrigeration, revenue was down 2% at constant currency. Including the negative impact of foreign exchange, revenue was down 6% and profit was down 28% as the Australian market and supermarket
business in North America remained soft as expected. Corporate expense in the first quarter was down $8 million on lower incentive compensation as expected, and we maintain our guidance for corporate expense to be down $18 million for the full year.
Overall for Lennox International in the quarter, revenue was up 6% at constant currency and total segment profit margin expanded 70 basis points to a first-quarter record of 5.1%. Adjusted EPS from continuing operations was up 27% to a first-quarter
record of $0.42.

[0001193125-14-149734:8k_2_02:14]
“Looking ahead at the full year, we continue to expect adjusted EPS from continuing operations in the range
of $4.20-$4.60. With a strong balance sheet, we will continue to invest in the business for growth as well as maintain a competitive dividend, and we plan to repurchase $150 million of stock in 2014. The company remains competitively well-positioned
for continued market outperformance with our leading product portfolio and expanding distribution network, and we look forward to the seasonally strongest quarters of the year.”

[0001193125-14-149734:8k_2_02:15]
FINANCIAL HIGHLIGHTS

[0001193125-14-149734:8k_2_02:16]
Revenue: Revenue for the
first quarter was $695 million, up 4% from the prior-year quarter. Foreign exchange had a negative 2 point impact on revenue growth. Volume and price/mix were up from the prior-year quarter.

[0001193125-14-149734:8k_2_02:17]
Gross Profit: Gross profit for the first quarter was $168 million, up 4% from the prior-year quarter. Gross margin was 24.2%, flat with the prior-year
quarter. Gross profit was primarily impacted by higher volume, favorable price/mix and lower material costs, partially offset by negative foreign exchange and investments in distribution.

[0001193125-14-149734:8k_2_02:18]
Income from Continuing Operations: Adjusted income from continuing operations in the first quarter was $20.8 million, or $0.42 per share, compared to
$17.0 million, or $0.33 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the first quarter of 2014 excludes $0.4 million after-tax for the net change in unrealized losses on unsettled future contracts, a $0.2
million after-tax special legal contingency charge, and $0.3 million in after-tax charges for other items, net.

[0001193125-14-149734:8k_2_02:19]
On a GAAP basis, income from continuing
operations for the first quarter was $19.9 million, or $0.40 per share, compared to $15.8 million, or $0.31 per share, in the prior-year quarter.

[0001193125-14-149734:8k_2_02:20]
Free
Cash Flow and Total Debt: Net cash used in operations in the first quarter was $125 million compared to $137 million in the prior-year quarter. The company invested $17 million in capital assets in the first quarter, up from $12 million in the
first quarter a year ago. Free cash flow was ($142) million, compared to ($149) million in the prior-year quarter. Total debt at the end of the first quarter was $564 million. Total cash and cash equivalents were $39 million at the end of the
quarter.

[0001193125-14-149734:8k_2_02:21]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-14-149734:8k_2_02:22]
Residential Heating & Cooling

[0001193125-14-149734:8k_2_02:23]
First quarter 2014
revenue in the Residential Heating & Cooling business segment was $342 million, up 9% from the prior-year quarter. Foreign exchange had a negative 1 point impact on revenue growth. Segment profit was $24 million, up 19% from the prior-year
quarter. Segment profit margin was 7.1%, up 60 basis points. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from higher SG&A, investments in distribution expansion, and
negative foreign exchange.

[0001193125-14-149734:8k_2_02:24]
Commercial Heating & Cooling

[0001193125-14-149734:8k_2_02:25]
Revenue in the Commercial Heating & Cooling business segment was $173 million, up 6% from the prior-year quarter. Foreign exchange was neutral to
revenue. Segment profit was $10 million, down 8% from the prior-year quarter. Segment profit margin was 5.9%, down 90 basis points. Results were negatively impacted by investments in the business for growth, including North American distribution and
service expansion as well as start-up costs to enter the VRF market in the second half of 2014. Partial offsets included higher volume and lower material costs.

[0001193125-14-149734:8k_2_02:26]
Refrigeration

[0001193125-14-149734:8k_2_02:27]
Revenue in the Refrigeration business
segment was $180 million in the first quarter, down 6% from the prior-year quarter. Foreign exchange had a negative 4 point impact on revenue. Segment profit was $12 million, down 28%. Segment profit margin was 6.7%, down 200 basis points. Results
were negatively impacted by foreign exchange, SG&A, lower volume, and factory investments for future growth, with partial offsets from favorable price/mix and lower material costs.

[0001193125-14-149734:8k_2_02:28]
FULL-YEAR OUTLOOK

[0001193125-14-149734:8k_2_02:29]
For 2014, the company reiterates its
revenue guidance at constant currency and adjusted EPS from continuing operations.

[0001193125-14-149734:8k_2_02:30]
|  | • |  | Reiterating revenue growth guidance of 3-7% at constant currency; now expecting 1 point of negative impact from foreign exchange on a full-year basis for revenue growth of 2-6% at actual currency for 2014. |

[0001193125-14-149734:8k_2_02:31]
|  | • |  | Reiterating adjusted EPS from continuing operations guidance of $4.20-$4.60. |

[0001193125-14-149734:8k_2_02:32]
|  | • |  | Adjusting guidance for GAAP EPS from continuing operations from $4.20-$4.60 to a range of $4.18-$4.58, incorporating charges in the first quarter. |

[0001193125-14-149734:8k_2_02:33]
|  | • |  | Reiterating corporate expense guidance of approximately $70 million in 2014. |

[0001193125-14-149734:8k_2_02:34]
|  | • |  | Reiterating effective tax rate guidance of 34-35% on a full-year basis. |

[0001193125-14-149734:8k_2_02:35]
|  | • |  | Reiterating capital expenditure guidance of approximately $90 million in 2014. |

[0001193125-14-149734:8k_2_02:36]
|  | • |  | Reiterating plans for $150 million of stock repurchases in 2014. |

[0001193125-14-149734:8k_2_02:37]
CONFERENCE CALL INFORMATION

[0001193125-14-149734:8k_2_02:38]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the
conference call line at 612-234-9959 at least 10 minutes prior to the scheduled start time and use reservation number 323757. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com.

[0001193125-14-149734:8k_2_02:39]
A replay will be available from 11:00 a.m. Central time on April 21 through April 28, 2014 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 323757. The call will also be archived on the company’s web site.

[0001193125-14-149734:8k_2_02:40]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York
Stock Exchange under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-14-149734:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-149734:8k_2_02:42]
Consolidated Statements of Operations

[0001193125-14-149734:8k_2_02:43]
(Unaudited)

[0001193125-14-149734:8k_2_02:44]
|  |  | For the Three Months |  |
| (Amounts in millions, except per share data) |  | Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 695.4 |  |  | $ | 668.4 |  |
| Cost of goods sold |  |  | 527.3 |  |  |  | 506.4 |  |
| Gross profit |  |  | 168.1 |  |  |  | 162.0 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 135.6 |  |  |  | 135.6 |  |
| Losses and other expenses, net |  |  | 2.4 |  |  |  | 1.1 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.5 |  |
| Income from equity method investments |  |  | (3.9 | ) |  |  | (3.1 | ) |
| Operational income from continuing operations |  |  | 33.9 |  |  |  | 27.9 |  |
| Interest expense, net |  |  | 3.3 |  |  |  | 3.4 |  |
| Other expense, net |  |  | — |  |  |  | 0.1 |  |
| Income from continuing operations before income taxes |  |  | 30.6 |  |  |  | 24.4 |  |
| Provision for income taxes |  |  | 10.7 |  |  |  | 8.6 |  |
| Income from continuing operations |  |  | 19.9 |  |  |  | 15.8 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | — |  |  |  | (13.4 | ) |
| Benefit from income taxes |  |  | — |  |  |  | (5.6 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (7.8 | ) |
| Net income |  | $ | 19.9 |  |  | $ | 8.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.41 |  |  | $ | 0.32 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.16 | ) |
| Net income |  | $ | 0.41 |  |  | $ | 0.16 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.40 |  |  | $ | 0.31 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.15 | ) |
| Net income |  | $ | 0.40 |  |  | $ | 0.16 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 49.0 |  |  |  | 50.3 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 49.9 |  |  |  | 51.0 |  |
| Cash dividends declared per share |  | $ | 0.24 |  |  | $ | 0.20 |  |

[0001193125-14-149734:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-149734:8k_2_02:46]
Segment Net Sales and Profit (Loss)

[0001193125-14-149734:8k_2_02:47]
(Unaudited)

[0001193125-14-149734:8k_2_02:48]
|  |  | For the Three Months |  |
| (Amounts in millions) |  | Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 342.1 |  |  | $ | 314.5 |  |
| Commercial Heating & Cooling |  |  | 173.0 |  |  |  | 163.0 |  |
| Refrigeration |  |  | 180.3 |  |  |  | 190.9 |  |
|  |  | $ | 695.4 |  |  | $ | 668.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 24.4 |  |  | $ | 20.5 |  |
| Commercial Heating & Cooling |  |  | 10.2 |  |  |  | 11.1 |  |
| Refrigeration |  |  | 12.1 |  |  |  | 16.7 |  |
| Corporate and other |  |  | (11.4 | ) |  |  | (18.9 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 35.3 |  |  |  | 29.4 |  |
| Reconciliation to Income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | — |  |  |  | (0.2 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 1.3 |  |  |  | 1.3 |  |
| Restructuring charges |  |  | 0.1 |  |  |  | 0.5 |  |
| Interest expense, net |  |  | 3.3 |  |  |  | 3.4 |  |
| Income from continuing operations before income taxes |  | $ | 30.6 |  |  | $ | 24.4 |  |

[0001193125-14-149734:8k_2_02:49]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-14-149734:8k_2_02:50]
|  | • |  | Special product quality adjustments; |

[0001193125-14-149734:8k_2_02:51]
|  | • |  | The following items in Losses and other expenses, net: |

[0001193125-14-149734:8k_2_02:52]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-14-149734:8k_2_02:53]
|  | • |  | Special legal contingency charges, |

[0001193125-14-149734:8k_2_02:54]
|  | • |  | Asbestos-related litigation, and |

[0001193125-14-149734:8k_2_02:55]
|  | • |  | Other items, net; |

[0001193125-14-149734:8k_2_02:56]
|  | • |  | Restructuring charges; |

[0001193125-14-149734:8k_2_02:57]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-14-149734:8k_2_02:58]
|  | • |  | Interest expense, net; and |

[0001193125-14-149734:8k_2_02:59]
|  | • |  | Other expense, net. |

[0001193125-14-149734:8k_2_02:60]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-149734:8k_2_02:61]
Consolidated Balance Sheets

[0001193125-14-149734:8k_2_02:62]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
| (Amounts in millions, except shares and par values) |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 39.0 |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net of allowances of $9.5 and $9.8 in 2014 and 2013, respectively |  |  | 442.2 |  |  |  | 408.1 |  |
| Inventories, net |  |  | 490.3 |  |  |  | 378.8 |  |
| Deferred income taxes, net |  |  | 26.2 |  |  |  | 24.5 |  |
| Other assets |  |  | 59.8 |  |  |  | 53.0 |  |
| Total current assets |  |  | 1,057.5 |  |  |  | 902.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $631.8 and $617.3 in 2014 and 2013, respectively |  |  | 340.6 |  |  |  | 335.5 |  |
| Goodwill |  |  | 218.9 |  |  |  | 216.8 |  |
| Deferred income taxes |  |  | 82.8 |  |  |  | 88.5 |  |
| Other assets, net |  |  | 87.9 |  |  |  | 83.5 |  |
| Total assets |  | $ | 1,787.7 |  |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt |  |  | 1.4 |  |  |  | 1.3 |  |
| Accounts payable |  |  | 343.1 |  |  |  | 283.1 |  |
| Accrued expenses |  |  | 205.2 |  |  |  | 232.1 |  |
| Income taxes payable |  |  | 1.5 |  |  |  | 31.6 |  |
| Total current liabilities |  |  | 720.0 |  |  |  | 714.0 |  |
| Long-term debt |  |  | 394.0 |  |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions |  |  | 4.3 |  |  |  | 4.6 |  |
| Pensions |  |  | 60.3 |  |  |  | 70.0 |  |
| Other liabilities |  |  | 117.5 |  |  |  | 119.2 |  |
| Total liabilities |  |  | 1,296.1 |  |  |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 935.3 |  |  |  | 912.7 |  |
| Retained earnings |  |  | 878.6 |  |  |  | 870.5 |  |
| Accumulated other comprehensive loss |  |  | (61.1 | ) |  |  | (61.1 | ) |
| Treasury stock, at cost, 38,030,197 shares and 38,066,794 shares in 2014 and 2013, respectively |  |  | (1,262.9 | ) |  |  | (1,238.1 | ) |
| Noncontrolling interests |  |  | 0.8 |  |  |  | 0.8 |  |
| Total stockholders’ equity |  |  | 491.6 |  |  |  | 485.7 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,787.7 |  |  | $ | 1,626.7 |  |

[0001193125-14-149734:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-149734:8k_2_02:64]
Consolidated Statements of Cash Flows

[0001193125-14-149734:8k_2_02:65]
(Unaudited)

[0001193125-14-149734:8k_2_02:66]
|  |  | For the Three Months Ended |  |
| (Amounts in millions) |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 19.9 |  |  | $ | 8.0 |  |
| Net loss from discontinued operations |  |  | — |  |  |  | 7.8 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (3.9 | ) |  |  | (3.1 | ) |
| Restructuring expenses, net of cash paid |  |  | (0.1 | ) |  |  | (1.4 | ) |
| Provision for bad debts |  |  | (0.1 | ) |  |  | 1.2 |  |
| Unrealized losses on derivative contracts |  |  | 0.6 |  |  |  | 0.5 |  |
| Stock-based compensation expense |  |  | 3.8 |  |  |  | 7.7 |  |
| Depreciation and amortization |  |  | 15.0 |  |  |  | 14.1 |  |
| Deferred income taxes |  |  | 0.5 |  |  |  | (1.6 | ) |
| Other items, net |  |  | 12.8 |  |  |  | 9.0 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (33.8 | ) |  |  | (35.8 | ) |
| Inventories |  |  | (122.9 | ) |  |  | (100.9 | ) |
| Other current assets |  |  | (1.7 | ) |  |  | (3.5 | ) |
| Accounts payable |  |  | 59.5 |  |  |  | 18.8 |  |
| Accrued expenses |  |  | (33.1 | ) |  |  | (43.0 | ) |
| Income taxes payable and receivable |  |  | (29.3 | ) |  |  | (9.6 | ) |
| Other |  |  | (12.2 | ) |  |  | 6.5 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (12.0 | ) |
| Net cash used in operating activities |  |  | (125.0 | ) |  |  | (137.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (17.3 | ) |  |  | (12.1 | ) |
| Net proceeds from sale of business |  |  | — |  |  |  | 5.3 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.1 | ) |
| Net cash used in investing activities |  |  | (17.3 | ) |  |  | (6.9 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 2.5 |  |  |  | 1.2 |  |
| Asset securitization borrowings |  |  | — |  |  |  | 130.0 |  |
| Asset securitization payments |  |  | — |  |  |  | (140.0 | ) |
| Long-term debt payments |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Borrowings from revolving credit facility |  |  | 479.0 |  |  |  | 435.5 |  |
| Payments on revolving credit facility |  |  | (319.0 | ) |  |  | (296.5 | ) |
| Proceeds from employee stock purchases |  |  | 0.5 |  |  |  | 0.5 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (10.7 | ) |  |  | (4.2 | ) |
| Excess tax benefits related to share-based payments |  |  | 4.2 |  |  |  | 2.3 |  |
| Cash dividends paid |  |  | (11.8 | ) |  |  | — |  |
| Net cash provided by financing activities |  |  | 144.3 |  |  |  | 128.6 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 2.0 |  |  |  | (15.6 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (1.0 | ) |  |  | (1.3 | ) |
| Cash and cash equivalents, beginning of period |  |  | 38.0 |  |  |  | 51.8 |  |
| Cash and cash equivalents, end of period |  | $ | 39.0 |  |  | $ | 34.9 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 1.2 |  |  | $ | 1.2 |  |
| Income taxes paid (net of refunds) |  | $ | 35.4 |  |  | $ | 11.9 |  |

[0001193125-14-149734:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-149734:8k_2_02:68]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-14-149734:8k_2_02:69]
(Unaudited)

[0001193125-14-149734:8k_2_02:70]
(Amounts in
millions, except per share and ratio data)

[0001193125-14-149734:8k_2_02:71]
Use of Non-GAAP Financial Measures

[0001193125-14-149734:8k_2_02:72]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP
financial measures are provided and reconciled in the following tables. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in
understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating performance.

[0001193125-14-149734:8k_2_02:73]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-14-149734:8k_2_02:74]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Income from continuing operations, a GAAP measure |  | $ | 19.9 |  |  | $ | 15.8 |  |
| Restructuring charges, after tax |  |  | 0.1 |  |  |  | 0.3 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | (0.1 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.2 |  |  |  | 0.2 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.1 |  |  |  | — |  |
| Net change in unrealized losses on unsettled future contracts, after tax (a) |  |  | 0.4 |  |  |  | 0.7 |  |
| Other items, net, after tax (a) |  |  | 0.1 |  |  |  | 0.1 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 20.8 |  |  | $ | 17.0 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 0.40 |  |  | $ | 0.31 |  |
| Restructuring charges, after tax |  |  | — |  |  |  | 0.01 |  |
| Special legal contingency charges, after tax (a) |  |  | 0.01 |  |  |  | — |  |
| Net change in unrealized losses on unsettled future contracts, after tax (a) |  |  | 0.01 |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 0.42 |  |  | $ | 0.33 |  |

[0001193125-14-149734:8k_2_02:75]
|  | (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-14-149734:8k_2_02:76]
|  | (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-14-149734:8k_2_02:77]
|  |  | For the Three MonthsEnded March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.2 |  |  | $ | — |  |
| Foreign currency exchange losses (gains) (a) |  |  | 0.8 |  |  |  | (0.2 | ) |
| Losses on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | — |  |
| Net change in unrealized losses on unsettled futures contracts (b) |  |  | 0.6 |  |  |  | 1.0 |  |
| Special legal contingency charges (b) |  |  | 0.4 |  |  |  | 0.2 |  |
| Asbestos-related litigation (b) |  |  | 0.2 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.1 |  |  |  | 0.1 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 2.4 |  |  | $ | 1.1 |  |

[0001193125-14-149734:8k_2_02:78]
|  | (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-14-149734:8k_2_02:79]
|  | (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-14-149734:8k_2_02:80]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-14-149734:8k_2_02:81]
|  |  | For the Year |  |
|  |  | Ended |  |
|  |  | December 31, |  |
|  |  | 2014 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 4.20 - $4.60 |  |
| Net change in unrealized losses on unsettled future contracts and other items |  |  | (0.02 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 4.18 - $4.58 |  |

[0001193125-14-149734:8k_2_02:82]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure

[0001193125-14-149734:8k_2_02:83]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (125.0 | ) |  | $ | (137.3 | ) |
| Purchases of property, plant and equipment |  |  | (17.3 | ) |  |  | (12.1 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  | $ | (142.3 | ) |  | $ | (149.4 | ) |

[0001193125-14-149734:8k_2_02:84]
|  |  | TrailingTwelveMonths toMarch 31, 2014 |  |
| Calculation of Debt to EBITDA Ratio: |  |  |  |  |
| EBIT (a) |  | $ | 306.4 |  |
| Depreciation and amortization expense (b) |  | $ | 59.8 |  |
| EBITDA (a + b) |  | $ | 366.2 |  |
| Total debt at March 31, 2014 (c) |  | $ | 564.2 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.5 |  |

[0001193125-14-149734:8k_2_02:85]
Reconciliation of EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure

[0001193125-14-149734:8k_2_02:86]
|  |  | TrailingTwelveMonths toMarch 31, 2014 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 306.4 |  |
| Special product quality adjustments |  |  | (2.1 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 8.8 |  |
| Restructuring charges |  |  | 4.6 |  |
| Interest expense, net |  |  | 14.4 |  |
| Other expenses, net |  |  | 0.2 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 280.5 |  |
