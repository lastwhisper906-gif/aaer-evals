# LII notes — 0001069202-14-000004


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-14-000004:notes:1]
[same as prior period, unchanged from 0001069202-13-000011:notes:1]

[0001069202-14-000004:notes:2]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2014, the accompanying unaudited Consolidated

[0001069202-14-000004:notes:3]
Statements of Operations for the three months ended March 31, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-14-000004:notes:4]
[same as prior period, unchanged from 0001069202-13-000011:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-14-000004:notes:5]
Commitments and Contingencies:

[0001069202-14-000004:notes:6]
Product Warranties and Product Related Contingencies

[0001069202-14-000004:notes:7]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-14-000004:notes:8]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000004:notes:9]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 29.2 |  |  | $ | 28.7 |  |
| Other liabilities | 52.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 81.6 |  |  | $ | 81.6 |  |

[0001069202-14-000004:notes:10]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2014 were as follows (in millions):

[0001069202-14-000004:notes:11]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (4.8 | ) |
| Changes resulting from issuance of new warranties | 6.6 |  |
| Changes in estimates associated with pre-existing liabilities | (1.6 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of March 31, 2014 | $ | 81.6 |  |

[0001069202-14-000004:notes:12]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

[0001069202-14-000004:notes:13]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the three months ended March 31, 2014 were as follows (in millions):

[0001069202-14-000004:notes:14]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.2 | ) |
| Total accrued product quality issues as of March 31, 2014 | $ | 4.5 |  |

[0001069202-14-000004:notes:15]
The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets.  The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

[0001069202-14-000004:notes:16]
Litigation

[0001069202-14-000004:notes:17]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

[0001069202-14-000004:notes:18]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2014, and 2013, expenses for asbestos-related litigation were $0.2 million and $0.6 million, net of insurance recoveries, respectively.

[0001069202-14-000004:notes:19]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-14-000004:notes:20]
[same as prior period, unchanged from 0001069202-13-000011:notes:23]

[0001069202-14-000004:notes:21]
[same as prior period, unchanged from 0001069202-13-000011:notes:24]

[0001069202-14-000004:notes:22]
|  |  | For the three months ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2014 |  | 2013 |  |
| Gains (losses) on cash flow hedges: |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | (1.1 | ) |  | $ | 0.4 |  |  | Cost of goods sold |
| Income tax benefit (expense) |  | 0.4 |  |  | (0.1 | ) |  | Provision for income taxes |
| Net of tax |  | $ | (0.7 | ) |  | $ | 0.3 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.3 | ) |  | $ | (2.0 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.5 |  |  | 0.7 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.8 | ) |  | $ | (1.3 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI to Net income |  | $ | (1.5 | ) |  | $ | 40.1 |  |  |  |

[0001069202-14-000004:notes:23]
[same as prior period, unchanged from 0001069202-13-000011:notes:26]

[0001069202-14-000004:notes:24]
The following table provides information on changes in AOCI, by component (net of tax), for the three months ended March 31, 2014 (in millions):

[0001069202-14-000004:notes:25]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| AOCI as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | (4.4 | ) |  | 0.5 |  |  | (0.2 | ) |  | 2.6 |  |  | (1.5 | ) |
| Amounts reclassified from AOCI |  | 0.7 |  |  | — |  |  | 0.8 |  |  | — |  |  | 1.5 |  |
| Net other comprehensive (loss) income |  | (3.7 | ) |  | 0.5 |  |  | 0.6 |  |  | 2.6 |  |  | — |  |
| AOCI as of March 31, 2014 |  | $ | (4.3 | ) |  | $ | 3.0 |  |  | $ | (105.4 | ) |  | $ | 45.6 |  |  | $ | (61.1 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-14-000004:notes:26]
Condensed Consolidating Financial Statements:

[0001069202-14-000004:notes:27]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-14-000004:notes:28]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-14-000004:notes:29]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of March 31, 2014 and December 31, 2013 and for the three months ended March 31, 2014 and 2013 are shown on the following pages.

[0001069202-14-000004:notes:30]
Lennox International Inc. and Subsidiaries

[0001069202-14-000004:notes:31]
Condensed Consolidating Balance Sheets

[0001069202-14-000004:notes:32]
As of March 31, 2014

[0001069202-14-000004:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 10.9 |  |  | $ | 26.9 |  |  | $ | — |  |  | $ | 39.0 |  |
| Accounts and notes receivable, net | — |  |  | 15.8 |  |  | 426.4 |  |  | — |  |  | 442.2 |  |
| Inventories, net | — |  |  | 358.3 |  |  | 136.1 |  |  | (4.1 | ) |  | 490.3 |  |
| Deferred income taxes, net | 2.5 |  |  | 21.2 |  |  | 5.8 |  |  | (3.3 | ) |  | 26.2 |  |
| Other assets | 3.9 |  |  | 40.6 |  |  | 80.1 |  |  | (64.8 | ) |  | 59.8 |  |
| Total current assets | 7.6 |  |  | 446.8 |  |  | 675.3 |  |  | (72.2 | ) |  | 1,057.5 |  |
| Property, plant and equipment, net | — |  |  | 246.7 |  |  | 93.9 |  |  | — |  |  | 340.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 78.5 |  |  | — |  |  | 218.9 |  |
| Investment in subsidiaries | 1,165.0 |  |  | 370.3 |  |  | (0.6 | ) |  | (1,534.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 70.9 |  |  | 20.5 |  |  | (8.6 | ) |  | 82.8 |  |
| Other assets, net | 3.7 |  |  | 64.8 |  |  | 20.9 |  |  | (1.5 | ) |  | 87.9 |  |
| Intercompany receivables (payables), net | (233.0 | ) |  | 222.8 |  |  | 10.2 |  |  | — |  |  | — |  |
| Total assets | $ | 943.3 |  |  | $ | 1,562.7 |  |  | $ | 898.7 |  |  | $ | (1,617.0 | ) |  | $ | 1,787.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 168.8 |  |  | $ | — |  |  | $ | 168.8 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.4 |  |  | — |  |  | 1.4 |  |
| Accounts payable | 11.9 |  |  | 254.3 |  |  | 76.9 |  |  | — |  |  | 343.1 |  |
| Accrued expenses | 11.1 |  |  | 130.6 |  |  | 63.6 |  |  | (0.1 | ) |  | 205.2 |  |
| Income taxes payable | 50.9 |  |  | (35.0 | ) |  | 55.4 |  |  | (69.8 | ) |  | 1.5 |  |
| Total current liabilities | 73.9 |  |  | 350.9 |  |  | 365.1 |  |  | (69.9 | ) |  | 720.0 |  |
| Long-term debt | 377.0 |  |  | 16.7 |  |  | 0.3 |  |  | — |  |  | 394.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.3 |  |  | — |  |  | — |  |  | 4.3 |  |
| Pensions | — |  |  | 49.5 |  |  | 10.8 |  |  | — |  |  | 60.3 |  |
| Other liabilities | 0.8 |  |  | 117.0 |  |  | 11.5 |  |  | (11.8 | ) |  | 117.5 |  |
| Total liabilities | 451.7 |  |  | 538.4 |  |  | 387.7 |  |  | (81.7 | ) |  | 1,296.1 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 491.6 |  |  | 1,024.3 |  |  | 511.0 |  |  | (1,535.3 | ) |  | 491.6 |  |
| Total liabilities and stockholders' equity | $ | 943.3 |  |  | $ | 1,562.7 |  |  | $ | 898.7 |  |  | $ | (1,617.0 | ) |  | $ | 1,787.7 |  |

[0001069202-14-000004:notes:34]
As of December 31, 2013

[0001069202-14-000004:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net | — |  |  | 12.8 |  |  | 395.3 |  |  | — |  |  | 408.1 |  |
| Inventories, net | — |  |  | 253.6 |  |  | 128.4 |  |  | (3.2 | ) |  | 378.8 |  |
| Deferred income taxes, net | 0.9 |  |  | 21.2 |  |  | 5.7 |  |  | (3.3 | ) |  | 24.5 |  |
| Other assets | 3.4 |  |  | 38.4 |  |  | 70.2 |  |  | (59.0 | ) |  | 53.0 |  |
| Total current assets | 5.4 |  |  | 336.5 |  |  | 626.0 |  |  | (65.5 | ) |  | 902.4 |  |
| Property, plant and equipment, net | — |  |  | 246.4 |  |  | 89.1 |  |  | — |  |  | 335.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 76.4 |  |  | — |  |  | 216.8 |  |
| Investment in subsidiaries | 1,138.8 |  |  | 337.5 |  |  | (0.6 | ) |  | (1,475.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 76.9 |  |  | 20.2 |  |  | (8.6 | ) |  | 88.5 |  |
| Other assets, net | 4.2 |  |  | 64.3 |  |  | 16.4 |  |  | (1.4 | ) |  | 83.5 |  |
| Intercompany receivables (payables), net | (460.6 | ) |  | 434.0 |  |  | 26.6 |  |  | — |  |  | — |  |
| Total assets | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 165.9 |  |  | $ | — |  |  | $ | 165.9 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 11.8 |  |  | 187.8 |  |  | 83.5 |  |  | — |  |  | 283.1 |  |
| Accrued expenses | 3.3 |  |  | 168.4 |  |  | 60.4 |  |  | — |  |  | 232.1 |  |
| Income taxes payable | (30.3 | ) |  | 75.7 |  |  | 49.9 |  |  | (63.7 | ) |  | 31.6 |  |
| Total current liabilities | (15.2 | ) |  | 432.9 |  |  | 360.0 |  |  | (63.7 | ) |  | 714.0 |  |
| Long-term debt | 217.0 |  |  | 15.8 |  |  | 0.4 |  |  | — |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| Pensions | — |  |  | 58.4 |  |  | 11.6 |  |  | — |  |  | 70.0 |  |
| Other liabilities | 0.3 |  |  | 119.4 |  |  | 11.3 |  |  | (11.8 | ) |  | 119.2 |  |
| Total liabilities | 202.1 |  |  | 631.1 |  |  | 383.3 |  |  | (75.5 | ) |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 485.7 |  |  | 1,004.9 |  |  | 470.8 |  |  | (1,475.7 | ) |  | 485.7 |  |
| Total liabilities and stockholders' equity | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |

[0001069202-14-000004:notes:36]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-14-000004:notes:37]
For the Three Months Ended March 31, 2014

[0001069202-14-000004:notes:38]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 559.2 |  |  | $ | 182.6 |  |  | $ | (46.4 | ) |  | $ | 695.4 |  |
| Cost of goods sold | — |  |  | 433.3 |  |  | 139.4 |  |  | (45.4 | ) |  | 527.3 |  |
| Gross profit | — |  |  | 125.9 |  |  | 43.2 |  |  | (1.0 | ) |  | 168.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 104.2 |  |  | 31.4 |  |  | — |  |  | 135.6 |  |
| Losses and other expenses, net | 0.9 |  |  | 0.8 |  |  | 0.7 |  |  | — |  |  | 2.4 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (22.4 | ) |  | (2.4 | ) |  | (3.2 | ) |  | 24.1 |  |  | (3.9 | ) |
| Operational income from continuing operations | 21.5 |  |  | 23.3 |  |  | 14.2 |  |  | (25.1 | ) |  | 33.9 |  |
| Interest expense, net | 3.0 |  |  | (0.6 | ) |  | 0.9 |  |  | — |  |  | 3.3 |  |
| Other expense, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 18.5 |  |  | 23.9 |  |  | 13.3 |  |  | (25.1 | ) |  | 30.6 |  |
| Provision for income taxes | (1.4 | ) |  | 7.8 |  |  | 4.7 |  |  | (0.4 | ) |  | 10.7 |  |
| Income from continuing operations | 19.9 |  |  | 16.1 |  |  | 8.6 |  |  | (24.7 | ) |  | 19.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income | $ | 19.9 |  |  | $ | 16.1 |  |  | $ | 8.6 |  |  | $ | (24.7 | ) |  | $ | 19.9 |  |
| Other comprehensive income, net of tax | — |  |  | 3.3 |  |  | 1.3 |  |  | (4.6 | ) |  | — |  |
| Comprehensive income | $ | 19.9 |  |  | $ | 19.4 |  |  | $ | 9.9 |  |  | $ | (29.3 | ) |  | $ | 19.9 |  |

[0001069202-14-000004:notes:39]
Condensed Consolidating Statements of Operations and Comprehensive Income (Loss)

[0001069202-14-000004:notes:40]
For the Three Months Ended March 31, 2013

[0001069202-14-000004:notes:41]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 520.7 |  |  | $ | 189.5 |  |  | $ | (41.8 | ) |  | $ | 668.4 |  |
| Cost of goods sold | — |  |  | 404.4 |  |  | 143.3 |  |  | (41.3 | ) |  | 506.4 |  |
| Gross profit | — |  |  | 116.3 |  |  | 46.2 |  |  | (0.5 | ) |  | 162.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 102.6 |  |  | 33.0 |  |  | — |  |  | 135.6 |  |
| Losses and other expenses, net | 0.4 |  |  | 0.4 |  |  | 0.3 |  |  | — |  |  | 1.1 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 0.2 |  |  | — |  |  | 0.5 |  |
| Income from equity method investments | (7.9 | ) |  | 2.5 |  |  | (2.8 | ) |  | 5.1 |  |  | (3.1 | ) |
| Operational income from continuing operations | 7.5 |  |  | 10.5 |  |  | 15.5 |  |  | (5.6 | ) |  | 27.9 |  |
| Interest expense, net | 3.3 |  |  | (0.5 | ) |  | 0.6 |  |  | — |  |  | 3.4 |  |
| Other expense, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from continuing operations before income taxes | 4.2 |  |  | 11.0 |  |  | 14.8 |  |  | (5.6 | ) |  | 24.4 |  |
| Provision for income taxes | (1.3 | ) |  | 4.8 |  |  | 5.3 |  |  | (0.2 | ) |  | 8.6 |  |
| Income from continuing operations | 5.5 |  |  | 6.2 |  |  | 9.5 |  |  | (5.4 | ) |  | 15.8 |  |
| Loss from discontinued operations | — |  |  | (7.8 | ) |  | — |  |  | — |  |  | (7.8 | ) |
| Net income | $ | 5.5 |  |  | $ | (1.6 | ) |  | $ | 9.5 |  |  | $ | (5.4 | ) |  | $ | 8.0 |  |
| Other comprehensive income (loss), net of tax | (3.4 | ) |  | 0.8 |  |  | (46.0 | ) |  | (0.7 | ) |  | (49.3 | ) |
| Comprehensive income (loss) | $ | 2.1 |  |  | $ | (0.8 | ) |  | $ | (36.5 | ) |  | $ | (6.1 | ) |  | $ | (41.3 | ) |

[0001069202-14-000004:notes:42]
Condensed Consolidating Statements of Cash Flows

[0001069202-14-000004:notes:43]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 85.4 |  |  | $ | (198.8 | ) |  | $ | (11.6 | ) |  | $ | — |  |  | $ | (125.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (11.7 | ) |  | (5.6 | ) |  | — |  |  | (17.3 | ) |
| Net proceeds from sale of business | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (11.7 | ) |  | (5.6 | ) |  | — |  |  | (17.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.5 |  |  | — |  |  | 2.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | — |  |  | (0.3 | ) |  | (0.1 | ) |  | — |  |  | (0.4 | ) |
| Borrowings from revolving credit facility | 479.0 |  |  | — |  |  | — |  |  | — |  |  | 479.0 |  |
| Payments on revolving credit facility | (319.0 | ) |  | — |  |  | — |  |  | — |  |  | (319.0 | ) |
| Proceeds from employee stock purchases | 0.5 |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (10.7 | ) |  | — |  |  | — |  |  | — |  |  | (10.7 | ) |
| Excess tax benefits related to share-based payments | 4.2 |  |  | — |  |  | — |  |  | — |  |  | 4.2 |  |
| Intercompany debt | (6.4 | ) |  | (4.1 | ) |  | 10.5 |  |  | — |  |  | — |  |
| Intercompany financing activity | (221.1 | ) |  | 215.3 |  |  | 5.8 |  |  | — |  |  | — |  |
| Cash dividends paid | (11.8 | ) |  | — |  |  | — |  |  | — |  |  | (11.8 | ) |
| Net cash provided by financing activities | (85.3 | ) |  | 210.9 |  |  | 18.7 |  |  | — |  |  | 144.3 |  |
| Increase in cash and cash equivalents | 0.1 |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | 2.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.0 | ) |  | — |  |  | (1.0 | ) |
| Cash and cash equivalents, beginning of period | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of period | $ | 1.2 |  |  | $ | 10.9 |  |  | $ | 26.9 |  |  | $ | — |  |  | $ | 39.0 |  |

[0001069202-14-000004:notes:44]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 54.3 |  |  | $ | (168.3 | ) |  | $ | (23.3 | ) |  | $ | — |  |  | $ | (137.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (9.3 | ) |  | (2.8 | ) |  | — |  |  | (12.1 | ) |
| Net proceeds from sale of business | 2.0 |  |  | — |  |  | 3.3 |  |  | — |  |  | 5.3 |  |
| Net cash used in discontinued operations | — |  |  | (0.1 | ) |  | — |  |  | — |  |  | (0.1 | ) |
| Net cash used in investing activities | 2.0 |  |  | (9.4 | ) |  | 0.5 |  |  | — |  |  | (6.9 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.2 |  |  | — |  |  | 1.2 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 130.0 |  |  | — |  |  | 130.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (140.0 | ) |  | — |  |  | (140.0 | ) |
| Long-term debt payments | — |  |  | (0.2 | ) |  | — |  |  | — |  |  | (0.2 | ) |
| Borrowings from revolving credit facility | 435.5 |  |  | — |  |  | — |  |  | — |  |  | 435.5 |  |
| Payments on revolving credit facility | (296.5 | ) |  | — |  |  | — |  |  | — |  |  | (296.5 | ) |
| Proceeds from employee stock purchases | 0.5 |  |  | — |  |  | — |  |  | — |  |  | 0.5 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (4.2 | ) |  | — |  |  | — |  |  | — |  |  | (4.2 | ) |
| Excess tax benefits related to share-based payments | 2.3 |  |  | — |  |  | — |  |  | — |  |  | 2.3 |  |
| Intercompany debt | (7.1 | ) |  | (0.7 | ) |  | 7.8 |  |  | — |  |  | — |  |
| Intercompany financing activity | (187.8 | ) |  | 179.2 |  |  | 8.6 |  |  | — |  |  | — |  |
| Cash dividends paid | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by financing activities | (57.3 | ) |  | 178.3 |  |  | 7.6 |  |  | — |  |  | 128.6 |  |
| Decrease in cash and cash equivalents | (1.0 | ) |  | 0.6 |  |  | (15.2 | ) |  | — |  |  | (15.6 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (1.3 | ) |  | — |  |  | (1.3 | ) |
| Cash and cash equivalents, beginning of period | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of period | $ | — |  |  | $ | 14.0 |  |  | $ | 20.9 |  |  | $ | — |  |  | $ | 34.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-14-000004:notes:45]
Lines of Credit and Financing Arrangements:

[0001069202-14-000004:notes:46]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000004:notes:47]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 8.8 |  |  | 5.9 |  |
| Total short-term debt | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 177.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 394.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 564.2 |  |  | $ | 400.4 |  |

[0001069202-14-000004:notes:48]
Short-Term Debt

[0001069202-14-000004:notes:49]
Foreign Obligations

[0001069202-14-000004:notes:50]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $8.8 million and $5.9 million of foreign obligations as of March 31, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

[0001069202-14-000004:notes:51]
Asset Securitization Program

[0001069202-14-000004:notes:52]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-14-000004:notes:53]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-14-000004:notes:54]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

[0001069202-14-000004:notes:55]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for both March 31, 2014 and December 31, 2013 was 0.78%. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-14-000004:notes:56]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000004:notes:57]
Long-Term Debt

[0001069202-14-000004:notes:58]
Domestic Revolving Credit Facility

[0001069202-14-000004:notes:59]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $177.0 million as well as $33.5 million committed to standby letters of credit as of March 31, 2014. Subject to covenant limitations, $439.5 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-14-000004:notes:60]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-14-000004:notes:61]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |

[0001069202-14-000004:notes:62]
Our Domestic Revolving Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Revolving Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Revolving Credit Facility are detailed below:

[0001069202-14-000004:notes:63]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-14-000004:notes:64]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our revolving credit facility could occur if:

[0001069202-14-000004:notes:65]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-14-000004:notes:66]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-14-000004:notes:67]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).   As of March 31, 2014, we were in compliance with all covenant requirements.

[0001069202-14-000004:notes:68]
Senior Unsecured Notes

[0001069202-14-000004:notes:69]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2014, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-14-000004:notes:70]
[same as prior period, unchanged from 0001069202-13-000011:notes:58]

[0001069202-14-000004:notes:71]
[same as prior period, unchanged from 0001069202-13-000011:notes:59]

[0001069202-14-000004:notes:72]
Commodity Price Risk - We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term and lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-14-000004:notes:73]
Interest Rate Risk - A portion of our debt bears interest at variable rates, and as a result, we are subject to variability in the cash paid for interest. To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.  We are not currently hedged against interest rate risk.

[0001069202-14-000004:notes:74]
Foreign Currency Risk - Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies. We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them. By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-14-000004:notes:75]
[same as prior period, unchanged from 0001069202-13-000011:notes:67]

[0001069202-14-000004:notes:76]
We have commodity futures contracts designated as cash flows hedges that are scheduled to mature through September 2015.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive income (loss) (“AOCI”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.  We recorded the following amounts in AOCI related to our cash flow hedges (in millions):

[0001069202-14-000004:notes:77]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Unrealized losses on unsettled futures contracts | $ | 6.7 |  |  | $ | 0.8 |  |
| Income tax benefit | (2.4 | ) |  | (0.2 | ) |
| Losses included in AOCI, net of tax (1) | $ | 4.3 |  |  | $ | 0.6 |  |

[0001069202-14-000004:notes:78]
(1) Assuming commodity prices remain constant, we expect to reclassify $3.9 million of derivative losses into earnings within the next 12 months.

[0001069202-14-000004:notes:79]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-14-000004:notes:80]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Copper | 27.2 |  |  | 22.9 |  |

[0001069202-14-000004:notes:81]
[same as prior period, unchanged from 0001069202-13-000011:notes:73]

[0001069202-14-000004:notes:82]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-14-000004:notes:83]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Copper | 2.9 |  |  | 2.0 |  |
| Aluminum | 2.7 |  |  | 2.7 |  |

[0001069202-14-000004:notes:84]
We also had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-14-000004:notes:85]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Notional Amounts (in local currency): |  |  |  |
| Brazilian Real | 3.5 |  |  | 1.2 |  |
| Mexican Peso | 83.6 |  |  | 130.0 |  |
| British Pound | 3.4 |  |  | 3.4 |  |
| Indian Rupee | — |  |  | 28.0 |  |
| Polish Zloty | 29.2 |  |  | 32.6 |  |

[0001069202-14-000004:notes:86]
[same as prior period, unchanged from 0001069202-13-000011:notes:78]

[0001069202-14-000004:notes:87]
[same as prior period, unchanged from 0001069202-13-000011:notes:79]

[0001069202-14-000004:notes:88]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of March 31, 2014 |  | As of December 31, 2013 |  | As of March 31, 2014 |  | As of December 31, 2013 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 6.3 |  |  | $ | 1.2 |  |  | $ | 0.7 |  |  | $ | 0.3 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.5 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Liabilities | $ | 6.8 |  |  | $ | 1.2 |  |  | $ | 0.8 |  |  | $ | 0.3 |  |

[0001069202-14-000004:notes:89]
[same as prior period, unchanged from 0001069202-13-000011:notes:81]

[0001069202-14-000004:notes:90]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended March 31, |
|  |  | 2014 |  | 2013 |
| Amount of Loss (gain) reclassified from AOCI into Income (Effective Portion) (1) |  | $ | 1.1 |  |  | $ | (0.4 | ) |
| Amount of Loss recognized in Net income (Ineffective Portion) (2) |  | $ | 0.1 |  |  | $ | 0.2 |  |

[0001069202-14-000004:notes:91]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended March 31, |
|  |  | 2014 |  | 2013 |
| Amount of Loss (Gain) Recognized in Net Income: |  |  |  |  |
| Commodity futures contracts (2) |  | $ | 0.7 |  |  | $ | 0.8 |  |
| Foreign currency forward contracts (2) |  | 0.1 |  |  | (0.5 | ) |
|  |  | $ | 0.8 |  |  | $ | 0.3 |  |

[0001069202-14-000004:notes:92]
(1) The loss (gain) was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-14-000004:notes:93]
(2) The loss (gain) was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-14-000004:notes:94]
[same as prior period, unchanged from 0001069202-13-000011:notes:87]

[0001069202-14-000004:notes:95]
We issue various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights under the Lennox International Inc. 2010 Incentive Plan, as amended and restated.  Stock-based compensation expense related to continuing operations is included in Selling, General and Administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-14-000004:notes:96]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Stock-based compensation expense (1) | $ | 3.8 |  |  | $ | 7.7 |  |

[0001069202-14-000004:notes:97]
(1) All expense was recorded in our Corporate and other business segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-14-000004:notes:98]
[same as prior period, unchanged from 0001069202-13-000011:notes:91]

[0001069202-14-000004:notes:99]
On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We also entered into a two-year equipment and parts supply agreement with the Buyer.  In April 2012, we sold our Hearth business to Comvest Investment Partners IV in an all-cash transaction for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.

[0001069202-14-000004:notes:100]
There were no assets and liabilities related to the Service Experts or Hearth businesses included in the accompanying Consolidated Balance Sheets as of March 31, 2014 or December 31, 2013.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations in the accompanying Consolidated Statements of Operations.  The following table provides a summary of net trade sales, pre-tax operating income (loss) and other supplemental information related to discontinued operations (in millions):

[0001069202-14-000004:notes:101]
|  | Service Experts |  | Hearth |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net trade sales (1) | $ | — |  |  | $ | 73.5 |  |  | $ | — |  |  | $ | — |  |
| Pre-tax operating income (loss) (1) | — |  |  | (15.1 | ) |  | — |  |  | 0.1 |  |
| Gain (loss) on sale of business | (0.1 | ) |  | 1.7 |  |  | 0.1 |  |  | — |  |

[0001069202-14-000004:notes:102]
[same as prior period, unchanged from 0001069202-13-000011:notes:96]


## us-gaap:EarningsPerShareTextBlock

[0001069202-14-000004:notes:103]
[same as prior period, unchanged from 0001069202-13-000011:notes:107]

[0001069202-14-000004:notes:104]
[same as prior period, unchanged from 0001069202-13-000011:notes:108]

[0001069202-14-000004:notes:105]
[same as prior period, unchanged from 0001069202-13-000011:notes:109]

[0001069202-14-000004:notes:106]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Net income | $ | 19.9 |  |  | $ | 8.0 |  |
| Add: Loss from discontinued operations | — |  |  | 7.8 |  |
| Income from continuing operations | $ | 19.9 |  |  | $ | 15.8 |  |
| Weighted-average shares outstanding – basic | 49.0 |  |  | 50.3 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.9 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 49.9 |  |  | 51.0 |  |
| Earnings per share – Basic: |  |  |  |
| Income from continuing operations | $ | 0.41 |  |  | $ | 0.32 |  |
| Loss from discontinued operations | — |  |  | (0.16 | ) |
| Net income | $ | 0.41 |  |  | $ | 0.16 |  |
| Earnings per share – Diluted: |  |  |  |
| Income from continuing operations | $ | 0.40 |  |  | $ | 0.31 |  |
| Loss from discontinued operations | — |  |  | (0.15 | ) |
| Net income | $ | 0.40 |  |  | $ | 0.16 |  |

[0001069202-14-000004:notes:107]
[same as prior period, unchanged from 0001069202-13-000011:notes:111]

[0001069202-14-000004:notes:108]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Weighted-average number of shares | 0.3 |  |  | 0.4 |  |
| Price per share | $81.11-$81.14 |  |  | $51.11-$51.40 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-14-000004:notes:109]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Senior unsecured notes | $ | 217.4 |  |  | $ | 214.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-14-000004:notes:110]
[same as prior period, unchanged from 0001069202-13-000011:notes:115]

[0001069202-14-000004:notes:111]
Fair Value Hierarchy

[0001069202-14-000004:notes:112]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2014 were the same as those used at December 31, 2013.

[0001069202-14-000004:notes:113]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-14-000004:notes:114]
Derivatives

[0001069202-14-000004:notes:115]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 4 for more information related to our derivative instruments.

[0001069202-14-000004:notes:116]
Marketable Equity Securities

[0001069202-14-000004:notes:117]
The following table presents the fair values of an investment in marketable equity securities, classified as Level 1 and related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-14-000004:notes:118]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Investment in marketable equity securities | $ | 4.9 |  |  | $ | 4.4 |  |

[0001069202-14-000004:notes:119]
Other Fair Value Disclosures

[0001069202-14-000004:notes:120]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Revolving Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-14-000004:notes:121]
The fair value of our senior unsecured notes in Long-term debt, classified as Level 2, was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents their fair value (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-14-000004:notes:122]
[same as prior period, unchanged from 0001069202-13-000011:notes:123]

[0001069202-14-000004:notes:123]
The changes in the carrying amount of goodwill for the first three months of 2014, in total and by segment, are summarized in the table below (in millions):

[0001069202-14-000004:notes:124]
|  | Balance at December 31, 2013 |  | Acquisitions / (Dispositions) |  | Other (1) |  | Balance at March 31, 2014 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 64.6 |  |  | — |  |  | — |  |  | 64.6 |  |
| Refrigeration | 126.1 |  |  | — |  |  | 2.1 |  |  | 128.2 |  |
| Total Goodwill | $ | 216.8 |  |  | $ | — |  |  | $ | 2.1 |  |  | $ | 218.9 |  |

[0001069202-14-000004:notes:125]
[same as prior period, unchanged from 0001069202-13-000011:notes:126]

[0001069202-14-000004:notes:126]
We performed our annual goodwill impairment test in the first quarter of 2014 and, based on a qualitative assessment of impairment indicators for each of our reporting units, did not record any goodwill impairments.  We will continue to monitor our reporting units for indicators of impairment throughout the year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-14-000004:notes:127]
[same as prior period, unchanged from 0001069202-13-000011:notes:128]

[0001069202-14-000004:notes:128]
As of March 31, 2014, we had approximately $1.7 million in total gross unrecognized tax benefits. Of this amount, $1.4 million (net of federal benefit on state issues), if recognized, would be recorded through the Consolidated Statement of Operations.  As of March 31, 2014, we had approximately $0.2 million (net of federal tax benefits) in interest and penalties recognized in income tax expense in accordance with FASB Accounting Standards Codification ("ASC") Topic 740.

[0001069202-14-000004:notes:129]
We are currently under examination for our U.S. federal income taxes for 2013 and 2014 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2008.

[0001069202-14-000004:notes:130]
Since January 1, 2014, numerous states, including Indiana and New York, have enacted legislation effective for tax years beginning on or after January 1, 2014, including changes to rates.  The impact of these changes is immaterial.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-14-000004:notes:131]
[same as prior period, unchanged from 0001069202-13-000011:notes:133]

[0001069202-14-000004:notes:132]
[same as prior period, unchanged from 0001069202-13-000011:notes:134]

[0001069202-14-000004:notes:133]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Finished goods | $ | 345.7 |  |  | $ | 251.4 |  |
| Work in process | 17.6 |  |  | 11.8 |  |
| Raw materials and parts | 199.7 |  |  | 188.9 |  |
| Subtotal | 563.0 |  |  | 452.1 |  |
| Excess of current cost over last-in, first-out cost | (72.7 | ) |  | (73.3 | ) |
| Total inventories, net | $ | 490.3 |  |  | $ | 378.8 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-14-000004:notes:134]
[same as prior period, unchanged from 0001069202-13-000011:notes:136]

[0001069202-14-000004:notes:135]
[same as prior period, unchanged from 0001069202-13-000011:notes:137]

[0001069202-14-000004:notes:136]
[same as prior period, unchanged from 0001069202-13-000011:notes:138]

[0001069202-14-000004:notes:137]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-14-000004:notes:138]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates will be reflected in the financial statements in future periods.

[0001069202-14-000004:notes:139]
[same as prior period, unchanged from 0001069202-13-000011:notes:141]

[0001069202-14-000004:notes:140]
[same as prior period, unchanged from 0001069202-13-000011:notes:142]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-14-000004:notes:141]
[same as prior period, unchanged from 0001069202-13-000011:notes:143]

[0001069202-14-000004:notes:142]
[same as prior period, unchanged from 0001069202-13-000011:notes:144]

[0001069202-14-000004:notes:143]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.1 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.4 |  |  | 4.1 |  |  | — |  |  | 0.1 |  |
| Expected return on plan assets | (5.7 | ) |  | (5.2 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.8 | ) |  | (0.8 | ) |
| Recognized actuarial loss | 1.6 |  |  | 2.4 |  |  | 0.4 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.5 |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 1.5 |  |  | $ | 3.2 |  |  | $ | (0.4 | ) |  | $ | (0.3 | ) |

[0001069202-14-000004:notes:144]
(1) All net periodic benefit cost for the three months ended March 31, 2014 and 2013 related to continuing operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-14-000004:notes:145]
Net sales and segment profit (loss) for each segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes, are shown below (in millions):

[0001069202-14-000004:notes:146]
|  | For the Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Net Sales |  |  |  |
| Residential Heating & Cooling | $ | 342.1 |  |  | $ | 314.5 |  |
| Commercial Heating & Cooling | 173.0 |  |  | 163.0 |  |
| Refrigeration | 180.3 |  |  | 190.9 |  |
|  | $ | 695.4 |  |  | $ | 668.4 |  |
| Segment Profit (Loss) (1) |  |  |  |
| Residential Heating & Cooling | $ | 24.4 |  |  | $ | 20.5 |  |
| Commercial Heating & Cooling | 10.2 |  |  | 11.1 |  |
| Refrigeration | 12.1 |  |  | 16.7 |  |
| Corporate and other | (11.4 | ) |  | (18.9 | ) |
| Subtotal that includes segment profit and eliminations | 35.3 |  |  | 29.4 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |
| Special product quality adjustments | — |  |  | (0.2 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) | 1.3 |  |  | 1.3 |  |
| Restructuring charges | 0.1 |  |  | 0.5 |  |
| Interest expense, net | 3.3 |  |  | 3.4 |  |
| Income from continuing operations before income taxes | $ | 30.6 |  |  | $ | 24.4 |  |

[0001069202-14-000004:notes:147]
(1)  The Company defines segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-14-000004:notes:148]
| • | Special product quality adjustments; |

[0001069202-14-000004:notes:149]
| • | The following items in Losses and other expenses, net: |

[0001069202-14-000004:notes:150]
| ◦ | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001069202-14-000004:notes:151]
| ◦ | Special legal contingency charges, |

[0001069202-14-000004:notes:152]
| ◦ | Asbestos-related litigation, and |

[0001069202-14-000004:notes:153]
| ◦ | Other items, net; |

[0001069202-14-000004:notes:154]
| • | Restructuring charges; |

[0001069202-14-000004:notes:155]
| • | Goodwill, long-lived asset, and equity method investment impairments; |

[0001069202-14-000004:notes:156]
| • | Interest expense, net; and |

[0001069202-14-000004:notes:157]
| • | Other expense, net. |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-14-000004:notes:158]
[same as prior period, unchanged from 0001069202-13-000011:notes:149]

[0001069202-14-000004:notes:159]
We record restructuring charges associated with management-approved restructuring plans when we reorganize or remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 15.

[0001069202-14-000004:notes:160]
Restructuring Activities in 2014

[0001069202-14-000004:notes:161]
There were several ongoing restructuring activities as of March 31, 2014, however, none were individually significant and there were no significant restructuring charges incurred in the first quarter of 2014.

[0001069202-14-000004:notes:162]
[same as prior period, unchanged from 0001069202-13-000011:notes:154]

[0001069202-14-000004:notes:163]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-14-000004:notes:164]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | — |  |  | $ | 6.5 |  |  | $ | 6.5 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 1.5 |  |  | 1.5 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |
| Other | 0.1 |  |  | 1.7 |  |  | 1.9 |  |
| Total restructuring charges | $ | 0.1 |  |  | $ | 9.7 |  |  | $ | 9.9 |  |

[0001069202-14-000004:notes:165]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-14-000004:notes:166]
|  | Charges Incurred in 2014 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | — |  |  | $ | 1.3 |  |  | $ | 1.3 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 0.1 |  |  | 7.5 |  |  | 7.7 |  |
| Corporate & Other | — |  |  | — |  |  | — |  |
| Total restructuring charges | $ | 0.1 |  |  | $ | 9.7 |  |  | $ | 9.9 |  |

[0001069202-14-000004:notes:167]
Restructuring reserves are included in Accrued expenses in the accompanying Consolidated Balance Sheets. The table below details the activity in 2014 within the restructuring reserves (in millions):

[0001069202-14-000004:notes:168]
|  | Balance as ofDecember 31, 2013 |  | ChargedtoEarnings |  | CashUtilization |  | Non-CashUtilizationand Other |  | Balance as ofMarch 31, 2014 |
| Severance and related expense | $ | 1.6 |  |  | $ | — |  |  | $ | (0.1 | ) |  | $ | (0.1 | ) |  | $ | 1.4 |  |
| Asset write-offs and accelerated depreciation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 1.6 |  |  | $ | 0.1 |  |  | $ | (0.2 | ) |  | $ | (0.1 | ) |  | $ | 1.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-14-000004:notes:169]
The following table describes each segment:

[0001069202-14-000004:notes:170]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-14-000004:notes:171]
[same as prior period, unchanged from 0001069202-13-000011:notes:172]

[0001069202-14-000004:notes:172]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-14-000004:notes:173]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items. The reconciliation below details the items excluded.

[0001069202-14-000004:notes:174]
[same as prior period, unchanged from 0001069202-13-000011:notes:178]

[0001069202-14-000004:notes:175]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations for the periods presented below.

[0001069202-14-000004:notes:176]
Segment Data

[0001069202-14-000004:notes:177]
Total Assets by Segment

[0001069202-14-000004:notes:178]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2013.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-14-000004:notes:179]
[same as prior period, unchanged from 0001069202-13-000011:notes:180]

[0001069202-14-000004:notes:180]
Our Board of Directors has authorized a total of $700.0 million towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans").  The Share Repurchase Plans authorize open market repurchase transactions and do not have an expiration date.    There were no additional share repurchase authorizations in the first quarter of 2014.  As of March 31, 2014, $246.2 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-14-000004:notes:181]
We did not repurchase any shares under the Share Repurchase Plans in the first three months of 2014.  However, we repurchased 0.1 million shares for $10.7 million for the three months ended March 31, 2014 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.
