# LII note change history — 0001069202-13-000011 → 0001069202-14-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-04-21):
[0001069202-14-000004:note_history:1]
We offer warranties to customers for some of our products and record liabilities for estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

- changed (2014-04-21):
[0001069202-14-000004:note_history:2]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 29.2 |  |  | $ | 28.7 |  |
| Other liabilities | 52.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 81.6 |  |  | $ | 81.6 |  |
  (was, 2013-10-21, similarity 0.893):
[0001069202-13-000011:note_history:2]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Accrued expenses | $ | 23.7 |  |  | $ | 25.1 |  |
| Other liabilities | 52.0 |  |  | 46.8 |  |
|  | $ | 75.7 |  |  | $ | 71.9 |  |

- changed (2014-04-21):
[0001069202-14-000004:note_history:3]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2014 were as follows (in millions):
  (was, 2013-10-21, similarity 0.9416):
[0001069202-13-000011:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2013 were as follows (in millions):

- changed (2014-04-21):
[0001069202-14-000004:note_history:4]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (4.8 | ) |
| Changes resulting from issuance of new warranties | 6.6 |  |
| Changes in estimates associated with pre-existing liabilities | (1.6 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of March 31, 2014 | $ | 81.6 |  |
  (was, 2013-10-21, similarity 0.9345):
[0001069202-13-000011:note_history:4]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (15.3 | ) |
| Changes resulting from issuance of new warranties | 22.5 |  |
| Changes in estimates associated with pre-existing liabilities | (3.2 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of September 30, 2013 | $ | 75.7 |  |

- changed (2014-04-21):
[0001069202-14-000004:note_history:5]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.
  (was, 2013-10-21, similarity 0.9824):
[0001069202-13-000011:note_history:5]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and we may, from time to time, repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

- added (2014-04-21):
[0001069202-14-000004:note_history:6]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the three months ended March 31, 2014 were as follows (in millions):

- changed (2014-04-21):
[0001069202-14-000004:note_history:7]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.2 | ) |
| Total accrued product quality issues as of March 31, 2014 | $ | 4.5 |  |
  (was, 2013-10-21, similarity 0.9586):
[0001069202-13-000011:note_history:7]
| Total accrued product quality issues as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Product quality claims paid in 2013 | (1.1 | ) |
| Total accrued product quality issues as of September 30, 2013 | $ | 5.9 |  |

- added (2014-04-21):
[0001069202-14-000004:note_history:8]
The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets.  The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

- changed (2014-04-21):
[0001069202-14-000004:note_history:9]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.
  (was, 2013-10-21, similarity 0.9987):
[0001069202-13-000011:note_history:9]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits based on experience involving similar matters and specific facts known.  Costs related to such matters were not material to the periods presented.

- added (2014-04-21):
[0001069202-14-000004:note_history:10]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2014, and 2013, expenses for asbestos-related litigation were $0.2 million and $0.6 million, net of insurance recoveries, respectively.

- removed (2014-04-21):
[0001069202-13-000011:note_history:11]
Leases

- removed (2014-04-21):
[0001069202-13-000011:note_history:12]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas (the "Lake Park Renewal") for a term of approximately six years through March 1, 2019.  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for approximately $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease.

- removed (2014-04-21):
[0001069202-13-000011:note_history:13]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Domestic Credit Facility.  We were in compliance with those covenants as of September 30, 2013.

- removed (2014-04-21):
[0001069202-13-000011:note_history:14]
We evaluate our heating, ventilation and air conditioning ("HVAC") warranty liabilities at the end of each accounting period and also perform a complete re-evaluation of these liabilities annually in the second quarter.  As a result of the second quarter 2013 re-evaluation, we decreased our warranty liability by $3.2 million and recorded the related adjustment in Cost of Goods Sold in the Consolidated Statements of Operations.

- removed (2014-04-21):
[0001069202-13-000011:note_history:15]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products. Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations. In addition, warranty claims are not covered by our product liability insurance and certain product liability claims also may not be covered by our product liability insurance. There have been no material changes in the circumstances that affect our product warranties since our latest fiscal year-end.

- removed (2014-04-21):
[0001069202-13-000011:note_history:16]
We have non-warranty product quality issues we believe resulted from vendor supplied materials, including a heating and cooling product line produced in 2006 and 2007 and a refrigerant product quality issue. The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated warranty liabilities. The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets. We may incur additional charges in the future as more information becomes available. The changes in the accrued product quality issues for the nine months ended September 30, 2013 were as follows (in millions):

- removed (2014-04-21):
[0001069202-13-000011:note_history:17]
Some of these claims and lawsuits allege health problems resulting from exposure to asbestos.  For the three months ended September 30, 2013, no expense was recorded and for the nine months ended September 30, 2013, $0.5 million of expense, net of insurance recoveries, was recorded for asbestos matters.  These charges were included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations.  We also expect that additional asbestos-related claims will be brought against us in the future.  However, the Company believes our liability exposure related to those additional future claims cannot currently be estimated because of numerous uncertainties, including the number of such claims and lawsuits and the costs of defending and settling them, possible adverse judgments in amounts greater than previously experienced, and possible changes in the laws and process governing the compensation of asbestos claimants.

- removed (2014-04-21):
[0001069202-13-000011:note_history:18]
We are also involved in patent litigation claims related to products from an acquired business.  The Company  has indemnification protection (with certain limitations) for these claims.


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-04-21):
[0001069202-14-000004:note_history:19]
The changes in the accrued product quality issues for the three months ended March 31, 2014 were as follows (in millions):
  (was, 2013-10-21, similarity 0.9283):
[0001069202-13-000011:note_history:19]
The changes in the accrued product quality issues for the nine months ended September 30, 2013 were as follows (in millions):

- changed (2014-04-21):
[0001069202-14-000004:note_history:20]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.2 | ) |
| Total accrued product quality issues as of March 31, 2014 | $ | 4.5 |  |
  (was, 2013-10-21, similarity 0.9586):
[0001069202-13-000011:note_history:20]
| Total accrued product quality issues as of December 31, 2012 | $ | 6.7 |  |
| Changes in estimates associated with pre-existing liabilities | 0.3 |  |
| Product quality claims paid in 2013 | (1.1 | ) |
| Total accrued product quality issues as of September 30, 2013 | $ | 5.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-04-21):
[0001069202-14-000004:note_history:21]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2014, the accompanying unaudited Consolidated

- changed (2014-04-21):
[0001069202-14-000004:note_history:22]
Statements of Operations for the three months ended March 31, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2013-10-21, similarity 0.8819):
[0001069202-13-000011:note_history:22]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2013, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2013 and 2012, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2013 and 2012, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2013 and 2012 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2012. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2014-04-21):
[0001069202-14-000004:note_history:23]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates will be reflected in the financial statements in future periods.
  (was, 2013-10-21, similarity 0.9568):
[0001069202-13-000011:note_history:23]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-04-21):
[0001069202-14-000004:note_history:24]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |
  (was, 2013-10-21, similarity 0.95):
[0001069202-13-000011:note_history:24]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.41 | % |  | 1.46 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-04-21):
[0001069202-14-000004:note_history:25]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):
  (was, 2013-10-21, similarity 0.9933):
[0001069202-13-000011:note_history:25]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2014-04-21):
[0001069202-14-000004:note_history:26]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 8.8 |  |  | 5.9 |  |
| Total short-term debt | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 177.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 394.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 564.2 |  |  | $ | 400.4 |  |

- changed (2014-04-21):
[0001069202-14-000004:note_history:27]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $8.8 million and $5.9 million of foreign obligations as of March 31, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.
  (was, 2013-10-21, similarity 0.8728):
[0001069202-13-000011:note_history:27]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $7.9 million and $4.9 million of foreign obligations as of September 30, 2013 and December 31, 2012, respectively, that are primarily borrowings under non-committed facilities.

- changed (2014-04-21):
[0001069202-14-000004:note_history:28]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.
  (was, 2013-10-21, similarity 0.87):
[0001069202-13-000011:note_history:28]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.

- changed (2014-04-21):
[0001069202-14-000004:note_history:29]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2013-10-21, similarity 0.7963):
[0001069202-13-000011:note_history:29]
The ASP provides for a maximum securitization amount of the lesser of $160.0 million or 100% of the net pool balance as defined by the ASP.  However, eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2014-04-21):
[0001069202-14-000004:note_history:30]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- added (2014-04-21):
[0001069202-14-000004:note_history:31]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for both March 31, 2014 and December 31, 2013 was 0.78%. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2014-04-21):
[0001069202-14-000004:note_history:32]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2014, we were in compliance with all covenant requirements.
  (was, 2013-10-21, similarity 0.9899):
[0001069202-13-000011:note_history:32]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2013, we were in compliance with all covenant requirements.

- added (2014-04-21):
[0001069202-14-000004:note_history:33]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $177.0 million as well as $33.5 million committed to standby letters of credit as of March 31, 2014. Subject to covenant limitations, $439.5 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2014-04-21):
[0001069202-14-000004:note_history:34]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |
  (was, 2013-10-21, similarity 0.95):
[0001069202-13-000011:note_history:34]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Weighted average borrowing rate | 1.41 | % |  | 1.46 | % |

- added (2014-04-21):
[0001069202-14-000004:note_history:35]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).   As of March 31, 2014, we were in compliance with all covenant requirements.

- added (2014-04-21):
[0001069202-14-000004:note_history:36]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2014, we were in compliance with all covenant requirements.

- removed (2014-04-21):
[0001069202-13-000011:note_history:37]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 7.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 167.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.8 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 49.5 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 266.2 |  |  | $ | 351.0 |  |
| Total debt | $ | 434.9 |  |  | $ | 386.6 |  |

- removed (2014-04-21):
[0001069202-13-000011:note_history:38]
The sale of the beneficial interests in our trade accounts receivable are reflected as short-term borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

- removed (2014-04-21):
[0001069202-13-000011:note_history:39]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 30.0 |  |
| Remaining amount available | $ | — |  |  | $ | 130.0 |  |

- removed (2014-04-21):
[0001069202-13-000011:note_history:40]
Under the ASP, we pay certain discount fees to use the program and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates for September 30, 2013 and December 31, 2012 were 0.81% and 0.85%, respectively. The unused fee is based on 102% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement. We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations. The interest expense, including all fees, related to the ASP was as follows (in millions):

- removed (2014-04-21):
[0001069202-13-000011:note_history:41]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Interest expense (including fees) | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |

- removed (2014-04-21):
[0001069202-13-000011:note_history:42]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $49.5 million as well as $33.5 million committed to standby letters of credit as of September 30, 2013. Subject to covenant limitations, $567.0 million was available for future borrowings. This Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- removed (2014-04-21):
[0001069202-13-000011:note_history:43]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- removed (2014-04-21):
[0001069202-13-000011:note_history:44]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2013, we were in compliance with all covenant requirements.

- removed (2014-04-21):
[0001069202-13-000011:note_history:45]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

- removed (2014-04-21):
[0001069202-13-000011:note_history:46]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2013, we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-04-21):
[0001069202-14-000004:note_history:47]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):
  (was, 2013-10-21, similarity 0.9933):
[0001069202-13-000011:note_history:47]
The following table summarizes our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2014-04-21):
[0001069202-14-000004:note_history:48]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 8.8 |  |  | 5.9 |  |
| Total short-term debt | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 177.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 394.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 564.2 |  |  | $ | 400.4 |  |

- removed (2014-04-21):
[0001069202-13-000011:note_history:49]
|  | As of September 30, 2013 |  | As of December 31, 2012 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 30.0 |  |
| Foreign obligations | 7.9 |  |  | 4.9 |  |
| Total short-term debt | $ | 167.9 |  |  | $ | 34.9 |  |
| Current maturities of long-term debt: | $ | 0.8 |  |  | $ | 0.7 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.0 |  |
| Domestic revolving credit facility | 49.5 |  |  | 135.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 266.2 |  |  | $ | 351.0 |  |
| Total debt | $ | 434.9 |  |  | $ | 386.6 |  |
