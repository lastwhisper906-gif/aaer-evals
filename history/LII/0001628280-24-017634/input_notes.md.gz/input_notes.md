# LII notes — 0001628280-24-017634


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-24-017634:notes:1]
[same as prior period, unchanged from 0001628280-23-035265:notes:1]

[0001628280-24-017634:notes:2]
[same as prior period, unchanged from 0001628280-23-035265:notes:2]

[0001628280-24-017634:notes:3]
[same as prior period, unchanged from 0001628280-23-035265:notes:3]

[0001628280-24-017634:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2024, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three months ended March 31, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0001628280-24-017634:notes:5]
[same as prior period, unchanged from 0001628280-23-035265:notes:5]

[0001628280-24-017634:notes:6]
[same as prior period, unchanged from 0001628280-23-035265:notes:6]

[0001628280-24-017634:notes:7]
[same as prior period, unchanged from 0001628280-23-035265:notes:7]

[0001628280-24-017634:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-017634:notes:9]
[same as prior period, unchanged from 0001628280-23-035265:notes:9]

[0001628280-24-017634:notes:10]
[same as prior period, unchanged from 0001628280-23-035265:notes:10]

[0001628280-24-017634:notes:11]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products, curb, curb adapters, drop box diffusers, HVAC recycling and salvage service, condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks |  | Light Commercial;Food Preservation; Non-Food Industry |  | United StatesCanada |

[0001628280-24-017634:notes:12]
[same as prior period, unchanged from 0001628280-23-035265:notes:13]

[0001628280-24-017634:notes:13]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff. Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results. There were no significant intercompany eliminations for the periods presented.

[0001628280-24-017634:notes:14]
[same as prior period, unchanged from 0001628280-23-035265:notes:15]

[0001628280-24-017634:notes:15]
[same as prior period, unchanged from 0001628280-23-035265:notes:16]

[0001628280-24-017634:notes:16]
|  | For the Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 674.6 |  |  | $ | 681.0 |  |  |  |  |  |
| Business Climate Solutions | 372.5 |  |  | 308.7 |  |  |  |  |  |
| Corporate and Other (1) | — |  |  | 59.7 |  |  |  |  |  |
|  | $ | 1,047.1 |  |  | $ | 1,049.4 |  |  |  |  |  |
| Segment profit (loss) (2) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 112.1 |  |  | $ | 111.1 |  |  |  |  |  |
| Business Climate Solutions | 78.2 |  |  | 50.0 |  |  |  |  |  |
| Corporate and Other | (23.5) |  |  | (19.4) |  |  |  |  |  |
| Total segment profit | 166.8 |  |  | 141.7 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | — |  |  | 2.2 |  |  |  |  |  |
| Operating income | $ | 166.8 |  |  | $ | 139.5 |  |  |  |  |  |

[0001628280-24-017634:notes:17]
(1) The Corporate and Other segment included our European portfolio.  In the fourth quarter of 2023 we completed the divestiture of our European operations.

[0001628280-24-017634:notes:18]
(2) We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-24-017634:notes:19]
[same as prior period, unchanged from 0001628280-23-035265:notes:19]

[0001628280-24-017634:notes:20]
[same as prior period, unchanged from 0001628280-23-035265:notes:20]

[0001628280-24-017634:notes:21]
▪Environmental liabilities and special litigation charges, and

[0001628280-24-017634:notes:22]
[same as prior period, unchanged from 0001628280-23-035265:notes:22]


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-017634:notes:23]
[same as prior period, unchanged from 0001628280-23-035265:notes:25]

[0001628280-24-017634:notes:24]
[same as prior period, unchanged from 0001628280-23-035265:notes:26]

[0001628280-24-017634:notes:25]
[same as prior period, unchanged from 0001628280-23-035265:notes:27]

[0001628280-24-017634:notes:26]
|  | For the Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net income | $ | 124.3 |  |  | $ | 98.0 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 35.6 |  |  | 35.5 |  |  |  |  |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.1 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 35.8 |  |  | 35.6 |  |  |  |  |  |
| Earnings per share – Basic: | $ | 3.49 |  |  | $ | 2.76 |  |  |  |  |  |
| Earnings per share – Diluted: | $ | 3.47 |  |  | $ | 2.75 |  |  |  |  |  |

[0001628280-24-017634:notes:27]
The following stock appreciation rights and restricted stock units were outstanding but not included in the diluted earnings per share calculation as the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001628280-24-017634:notes:28]
|  | For the Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Weighted-average number of shares | — |  |  | 0.3 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-017634:notes:29]
4. Commitments and Contingencies:

[0001628280-24-017634:notes:30]
Leases

[0001628280-24-017634:notes:31]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-24-017634:notes:32]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or

[0001628280-24-017634:notes:33]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-24-017634:notes:34]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-24-017634:notes:35]
We lease certain real and personal property under non-cancelable operating leases. Approximately 75% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-24-017634:notes:36]
Product Warranties and Product Related Contingencies

[0001628280-24-017634:notes:37]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-24-017634:notes:38]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-24-017634:notes:39]
|  | March 31, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 45.4 |  |  | $ | 45.4 |  |
| Other liabilities | 102.2 |  |  | 97.4 |  |
| Total warranty liability | $ | 147.6 |  |  | $ | 142.8 |  |

[0001628280-24-017634:notes:40]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2024 were as follows (in millions):

[0001628280-24-017634:notes:41]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (7.0) |  |
| Changes resulting from issuance of new warranties | 11.6 |  |
| Changes in estimates associated with pre-existing liabilities | 0.4 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of March 31, 2024 | $ | 147.6 |  |

[0001628280-24-017634:notes:42]
Litigation

[0001628280-24-017634:notes:43]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-24-017634:notes:44]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-017634:notes:45]
5. Stock Repurchases:
Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2024, $546 million was available for repurchase under the Share Repurchase Plans.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-017634:notes:46]
6. Revenue Recognition:

[0001628280-24-017634:notes:47]
[same as prior period, unchanged from 0001628280-23-035265:notes:52]

[0001628280-24-017634:notes:48]
|  | For the Three Months Ended March 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 626.1 |  |  | $ | 357.3 |  |  | $ | — |  |  | $ | 983.4 |  |
| Canada | 48.5 |  |  | 15.2 |  |  | — |  |  | 63.7 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |

[0001628280-24-017634:notes:49]
|  | For the Three Months Ended March 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 639.3 |  |  | $ | 294.6 |  |  | $ | — |  |  | $ | 933.9 |  |
| Canada | 41.7 |  |  | 14.1 |  |  | — |  |  | 55.8 |  |
| Other international | — |  |  | — |  |  | 59.7 |  |  | 59.7 |  |
| Total | $ | 681.0 |  |  | $ | 308.7 |  |  | $ | 59.7 |  |  | $ | 1,049.4 |  |

[0001628280-24-017634:notes:50]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2024 and 2023, direct sales represented 74% and 70% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-24-017634:notes:51]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2024 and 2023, equipment sales represented 83% and 85% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-24-017634:notes:52]
Corporate and Other - In Europe, we manufactured and marketed equipment for the global commercial refrigeration markets. We also manufactured and sold unitary heating and cooling products and applied systems. A de minimis amount of segment revenue related to services for start-up and commissioning activities. In the fourth quarter of 2023, we completed the divestiture of our European operations.

[0001628280-24-017634:notes:53]
[same as prior period, unchanged from 0001628280-23-035265:notes:61]

[0001628280-24-017634:notes:54]
|  | March 31, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 1.9 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (3.6) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.5) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (9.2) |  |  | $ | (10.0) |  |  |  |  |  |

[0001628280-24-017634:notes:55]
For the three months ended March 31, 2024 and 2023, we recognized revenue of $5.7 million and $3.0 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-017634:notes:56]
[same as prior period, unchanged from 0001628280-23-035265:notes:65]

[0001628280-24-017634:notes:57]
[same as prior period, unchanged from 0001628280-23-035265:notes:66]

[0001628280-24-017634:notes:58]
|  | March 31, 2024 |  | December 31, 2023 |
| Finished goods | $ | 615.6 |  |  | $ | 509.4 |  |
| Work in process | 7.9 |  |  | 9.6 |  |
| Raw materials and parts | 334.0 |  |  | 314.2 |  |
| Subtotal | 957.5 |  |  | 833.2 |  |
| Excess of current cost over last-in, first-out cost | (134.1) |  |  | (134.1) |  |
| Total inventories, net | $ | 823.4 |  |  | $ | 699.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-017634:notes:59]
[same as prior period, unchanged from 0001628280-23-035265:notes:68]

[0001628280-24-017634:notes:60]
The changes in the carrying amount of goodwill in 2024, in total and by segment, are summarized in the table below (in millions):

[0001628280-24-017634:notes:61]
|  | Balance as of December 31, 2023 |  | Goodwill Adjustment (1) |  |  |  | Balance as of March 31, 2024 |
| Home Comfort Solutions | $ | 26.1 |  |  | $ | — |  |  |  |  | $ | 26.1 |  |
| Building Climate Solutions (1) | 196.0 |  |  | (2.2) |  |  |  |  | 193.8 |  |
| Total Goodwill | $ | 222.1 |  |  | $ | (2.2) |  |  |  |  | $ | 219.9 |  |

[0001628280-24-017634:notes:62]
(1) As discussed in Note 13, an update to our purchase price allocation of AES resulted in a $2.2 million reduction of goodwill.

[0001628280-24-017634:notes:63]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the three months ended March 31, 2024 or in any periods presented for our continuing businesses.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-24-017634:notes:64]
[same as prior period, unchanged from 0001628280-23-035265:notes:73]

[0001628280-24-017634:notes:65]
[same as prior period, unchanged from 0001628280-23-035265:notes:74]

[0001628280-24-017634:notes:66]
[same as prior period, unchanged from 0001628280-23-035265:notes:75]

[0001628280-24-017634:notes:67]
[same as prior period, unchanged from 0001628280-23-035265:notes:76]

[0001628280-24-017634:notes:68]
[same as prior period, unchanged from 0001628280-23-035265:notes:77]

[0001628280-24-017634:notes:69]
[same as prior period, unchanged from 0001628280-23-035265:notes:78]

[0001628280-24-017634:notes:70]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through August 2025.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 17 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions) as of:

[0001628280-24-017634:notes:71]
|  | March 31, 2024 |  | December 31, 2023 |
| Unrealized losses (gains), net on unsettled contracts | $ | (0.4) |  |  | $ | 2.6 |  |
| Income tax (benefit) expense | 0.1 |  |  | (0.6) |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | (0.3) |  |  | $ | 2.0 |  |

[0001628280-24-017634:notes:72]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $0.2 million of derivative gain as of March 31, 2024 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-017634:notes:73]
[same as prior period, unchanged from 0001628280-23-035265:notes:82]

[0001628280-24-017634:notes:74]
[same as prior period, unchanged from 0001628280-23-035265:notes:83]

[0001628280-24-017634:notes:75]
|  |  |  | For the Three Months Ended March 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Stock-based compensation expense |  |  |  |  | $ | 6.6 |  |  | $ | 6.1 |  |

[0001628280-24-017634:notes:76]
Historically, our annual equity awards were granted in December.  However, starting in 2024, we made the decision to move our annual grant to February on a go-forward basis.  Equity awards granted in February 2024 were as follows:

[0001628280-24-017634:notes:77]
|  | Shares |  | Weighted - Average Grant Date Fair Value per Share |
| Performance Share Units | 23,690 |  | $ | 403.68 |  |
| Restricted Stock Units | 27,391 |  | $ | 403.68 |  |
| Stock Appreciation Rights | 47,245 |  | $ | 136.37 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-24-017634:notes:78]
8. Pension Benefit Plans:

[0001628280-24-017634:notes:79]
[same as prior period, unchanged from 0001628280-23-035265:notes:86]

[0001628280-24-017634:notes:80]
|  |  |  | For the Three Months Ended March 31, |
|  |  |  |  |  | 2024 |  | 2023 |
| Service cost |  |  |  |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Interest cost |  |  |  |  | 2.2 |  |  | 2.2 |  |
| Expected return on plan assets |  |  |  |  | (1.9) |  |  | (2.4) |  |
| Recognized actuarial loss |  |  |  |  | 0.3 |  |  | 0.2 |  |
| Other |  |  |  |  | 0.1 |  |  | (0.1) |  |
| Settlements and curtailments |  |  |  |  | — |  |  | 0.2 |  |
| Net periodic benefit cost |  |  |  |  | $ | 1.1 |  |  | $ | 0.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-017634:notes:81]
9. Income Taxes:

[0001628280-24-017634:notes:82]
As of March 31, 2024, we had approximately $4.3 million in total gross unrecognized tax benefits. If recognized, $4.3 million would be recorded through the Consolidated Statements of Operations.

[0001628280-24-017634:notes:83]
Our effective tax rate was 19.4% for the three months ended March 31, 2024 compared to 21.7% for the three months ended March 31, 2023.  The decrease in the rate is primarily due to a discrete favorable adjustment for excess tax benefits in 2024 and unfavorable adjustments in 2023 related to discrete return to provision adjustments.

[0001628280-24-017634:notes:84]
We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2017 through 2023. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2017.


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-017634:notes:85]
10. Lines of Credit and Financing Arrangements:

[0001628280-24-017634:notes:86]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:

[0001628280-24-017634:notes:87]
|  | March 31, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 250.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 22.5 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.5 |  |  | $ | 32.7 |  |
| Credit agreement | 12.0 |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,153.7 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,426.2 |  |  | $ | 1,305.2 |  |

[0001628280-24-017634:notes:88]
Foreign Obligations

[0001628280-24-017634:notes:89]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2024.

[0001628280-24-017634:notes:90]
Commercial Paper Program

[0001628280-24-017634:notes:91]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial

[0001628280-24-017634:notes:92]
paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $250.0 million as of March 31, 2024.

[0001628280-24-017634:notes:93]
Our weighted average borrowing rate on the Program was as follows as of:

[0001628280-24-017634:notes:94]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |

[0001628280-24-017634:notes:95]
Credit Agreement

[0001628280-24-017634:notes:96]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had outstanding borrowings of $12.0 million as well as $1.7 million committed to standby letters of credit as of March 31, 2024. Subject to covenant limitations, $836.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-017634:notes:97]
Our weighted average borrowing rate on the facility was as follows as of:

[0001628280-24-017634:notes:98]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 6.66 | % |  | 6.67 | % |

[0001628280-24-017634:notes:99]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-24-017634:notes:100]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-24-017634:notes:101]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-24-017634:notes:102]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-24-017634:notes:103]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-24-017634:notes:104]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-24-017634:notes:105]
As of March 31, 2024, we believe we were in compliance with all covenant requirements.

[0001628280-24-017634:notes:106]
Senior Unsecured Notes

[0001628280-24-017634:notes:107]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027

[0001628280-24-017634:notes:108]
(the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2024, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-017634:notes:109]
11. Comprehensive Income (Loss):

[0001628280-24-017634:notes:110]
[same as prior period, unchanged from 0001628280-23-035265:notes:119]

[0001628280-24-017634:notes:111]
|  |  |  |  | For the Three Months Ended March 31, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  |  |  |  |  | 2024 |  | 2023 |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  |  |  |  |  | $ | (2.0) |  |  | $ | (0.4) |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit |  |  |  |  |  | 0.5 |  |  | 0.1 |  |  | Provision for income taxes |
| Net of tax |  |  |  |  |  | $ | (1.5) |  |  | $ | (0.3) |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  |  |  |  |  | $ | (0.3) |  |  | $ | (0.2) |  |  | Other expense (income), net |
| Pension settlements |  |  |  |  |  | — |  |  | (0.2) |  |  | Pension settlements |
| Income tax benefit |  |  |  |  |  | 0.1 |  |  | 0.1 |  |  | Provision for income taxes |
| Net of tax |  |  |  |  |  | $ | (0.2) |  |  | $ | (0.3) |  |  |  |
| Total reclassifications from AOCL |  |  |  |  |  | $ | (1.7) |  |  | $ | (0.6) |  |  |  |

[0001628280-24-017634:notes:112]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2024 (in millions):

[0001628280-24-017634:notes:113]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of Equity Method Investments Other Comprehensive Income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |
| Other comprehensive income (loss) before reclassifications |  | 0.7 |  |  | — |  |  | (0.1) |  |  | (3.3) |  |  | (2.7) |  |
| Amounts reclassified from AOCL |  | 1.5 |  |  | — |  |  | 0.2 |  |  | — |  |  | 1.7 |  |
| Net other comprehensive income (loss) |  | 2.2 |  |  | — |  |  | 0.1 |  |  | (3.3) |  |  | (1.0) |  |
| Balance as of March 31, 2024 |  | $ | 0.2 |  |  | $ | 0.6 |  |  | $ | (44.1) |  |  | $ | (14.6) |  |  | $ | (57.9) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-017634:notes:114]
12. Fair Value Measurements:

[0001628280-24-017634:notes:115]
[same as prior period, unchanged from 0001628280-23-035265:notes:124]

[0001628280-24-017634:notes:116]
The methodologies used to determine the fair value of our financial assets and liabilities as of March 31, 2024 were the same as those used as of December 31, 2023.

[0001628280-24-017634:notes:117]
[same as prior period, unchanged from 0001628280-23-035265:notes:126]

[0001628280-24-017634:notes:118]
Derivatives were classified as Level 2 and primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives. We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, however, they were insignificant to the overall value of the derivatives.  Refer to Note 7 for more information related to our derivative instruments.

[0001628280-24-017634:notes:119]
[same as prior period, unchanged from 0001628280-23-035265:notes:128]

[0001628280-24-017634:notes:120]
[same as prior period, unchanged from 0001628280-23-035265:notes:129]

[0001628280-24-017634:notes:121]
[same as prior period, unchanged from 0001628280-23-035265:notes:130]

[0001628280-24-017634:notes:122]
|  | March 31, 2024 |  | December 31, 2023 |
| Senior unsecured notes | $ | 1,064.8 |  |  | $ | 1,079.3 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-017634:notes:123]
13. Prior Year Acquisition:

[0001628280-24-017634:notes:124]
In October 2023, we completed the acquisition of AES, a company dedicated to service and sustainability in the light commercial market.  Under the terms of the purchase agreement, a final working capital adjustment was completed in the first quarter of 2024.  This working capital adjustment resulted in a $1.8 million reduction in the purchase price.  Additionally, during the first quarter of 2024 we made certain purchase price adjustments.  The following table details the purchase price adjustments that were made during the first quarter of 2024 (in millions):

[0001628280-24-017634:notes:125]
|  | December 31, 2023 |  | Adjustment |  | March 31, 2024 |
| Net tangible assets acquired | $ | 17.6 |  |  | $ | (1.7) |  |  | $ | 15.9 |  |
| Intangible assets acquired | 36.9 |  |  | 2.1 |  |  | 39.0 |  |
| Goodwill | 40.4 |  |  | (2.2) |  |  | 38.2 |  |
| Total investment | $ | 94.9 |  |  | $ | (1.8) |  |  | $ | 93.1 |  |
