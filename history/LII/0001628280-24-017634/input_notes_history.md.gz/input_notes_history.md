# LII note change history — 0001628280-23-035265 → 0001628280-24-017634


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-24):
[0001628280-24-017634:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or
  (was, 2023-10-26, similarity 0.9079):
[0001628280-23-035265:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- added (2024-04-24):
[0001628280-24-017634:note_history:2]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- changed (2024-04-24):
[0001628280-24-017634:note_history:3]
|  | March 31, 2024 |  | December 31, 2023 |
| Accrued expenses | $ | 45.4 |  |  | $ | 45.4 |  |
| Other liabilities | 102.2 |  |  | 97.4 |  |
| Total warranty liability | $ | 147.6 |  |  | $ | 142.8 |  |
  (was, 2023-10-26, similarity 0.9695):
[0001628280-23-035265:note_history:3]
|  | September 30, 2023 |  | December 31, 2022 |
| Accrued expenses | $ | 44.0 |  |  | $ | 41.3 |  |
| Other liabilities | 100.6 |  |  | 101.4 |  |
| Total warranty liability | $ | 144.6 |  |  | $ | 142.7 |  |

- changed (2024-04-24):
[0001628280-24-017634:note_history:4]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2024 were as follows (in millions):
  (was, 2023-10-26, similarity 0.9416):
[0001628280-23-035265:note_history:4]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2023 were as follows (in millions):

- changed (2024-04-24):
[0001628280-24-017634:note_history:5]
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |
| Warranty claims paid | (7.0) |  |
| Changes resulting from issuance of new warranties | 11.6 |  |
| Changes in estimates associated with pre-existing liabilities | 0.4 |  |
| Changes in foreign currency translation rates and other | (0.2) |  |
| Total warranty liability as of March 31, 2024 | $ | 147.6 |  |
  (was, 2023-10-26, similarity 0.8036):
[0001628280-23-035265:note_history:5]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (33.2) |  |
| Changes resulting from issuance of new warranties | 44.7 |  |
| Changes in estimates associated with pre-existing liabilities | (5.2) |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Warranty liability reclassified as liabilities held for sale | (4.3) |  |
| Total warranty liability as of September 30, 2023 | $ | 144.6 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-04-24):
[0001628280-24-017634:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2024, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2024 and 2023, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three months ended March 31, 2024 and 2023, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2024 and 2023 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2023.
  (was, 2023-10-26, similarity 0.8542):
[0001628280-23-035265:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and nine months ended September 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-04-24):
[0001628280-24-017634:note_history:7]
Our weighted average borrowing rate on the Program was as follows as of:

- changed (2024-04-24):
[0001628280-24-017634:note_history:8]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |
  (was, 2023-10-26, similarity 0.9318):
[0001628280-23-035265:note_history:8]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average borrowing rate | — | % |  | 5.57 | % |

- added (2024-04-24):
[0001628280-24-017634:note_history:9]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 6.66 | % |  | 6.67 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-04-24):
[0001628280-24-017634:note_history:10]
|  | March 31, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 250.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 22.5 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.5 |  |  | $ | 32.7 |  |
| Credit agreement | 12.0 |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,153.7 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,426.2 |  |  | $ | 1,305.2 |  |

- changed (2024-04-24):
[0001628280-24-017634:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2024 or December 31, 2023 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2024.
  (was, 2023-10-26, similarity 0.727):
[0001628280-23-035265:note_history:11]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2023.

- added (2024-04-24):
[0001628280-24-017634:note_history:12]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial

- changed (2024-04-24):
[0001628280-24-017634:note_history:13]
paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $250.0 million as of March 31, 2024.
  (was, 2023-10-26, similarity 0.6337):
[0001628280-23-035265:note_history:13]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. No CP Notes are currently outstanding under the Program.

- added (2024-04-24):
[0001628280-24-017634:note_history:14]
Our weighted average borrowing rate on the Program was as follows as of:

- changed (2024-04-24):
[0001628280-24-017634:note_history:15]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 5.56 | % |  | 5.66 | % |
  (was, 2023-10-26, similarity 0.9318):
[0001628280-23-035265:note_history:15]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average borrowing rate | — | % |  | 5.57 | % |

- added (2024-04-24):
[0001628280-24-017634:note_history:16]
Credit Agreement

- added (2024-04-24):
[0001628280-24-017634:note_history:17]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had outstanding borrowings of $12.0 million as well as $1.7 million committed to standby letters of credit as of March 31, 2024. Subject to covenant limitations, $836.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- added (2024-04-24):
[0001628280-24-017634:note_history:18]
|  | March 31, 2024 |  | December 31, 2023 |
| Weighted average borrowing rate | 6.66 | % |  | 6.67 | % |

- added (2024-04-24):
[0001628280-24-017634:note_history:19]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

- changed (2024-04-24):
[0001628280-24-017634:note_history:20]
• We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.
  (was, 2023-10-26, similarity 0.9499):
[0001628280-23-035265:note_history:20]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

- changed (2024-04-24):
[0001628280-24-017634:note_history:21]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.
  (was, 2023-10-26, similarity 0.7249):
[0001628280-23-035265:note_history:21]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- changed (2024-04-24):
[0001628280-24-017634:note_history:22]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).
  (was, 2023-10-26, similarity 0.9248):
[0001628280-23-035265:note_history:22]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2023, we were in compliance with all covenant requirements.

- added (2024-04-24):
[0001628280-24-017634:note_history:23]
As of March 31, 2024, we believe we were in compliance with all covenant requirements.

- changed (2024-04-24):
[0001628280-24-017634:note_history:24]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027
  (was, 2023-10-26, similarity 0.6284):
[0001628280-23-035265:note_history:24]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes, 2027 Notes, and the 2028 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

- changed (2024-04-24):
[0001628280-24-017634:note_history:25]
(the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.  
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement (the "Guarantor Subsidiaries").  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2024, we believe we were in compliance with all covenant requirements.
  (was, 2023-10-26, similarity 0.6035):
[0001628280-23-035265:note_history:25]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2023, we believe we were in compliance with all covenant requirements.

- removed (2024-04-24):
[0001628280-23-035265:note_history:26]
|  | September 30, 2023 |  | December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.6 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.9 |  |  | 28.3 |  |
| Credit agreement | — |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (10.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,121.6 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,483.2 |  |  | $ | 1,524.8 |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:27]
Asset Securitization Program

- removed (2024-04-24):
[0001628280-23-035265:note_history:28]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

- removed (2024-04-24):
[0001628280-23-035265:note_history:29]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions) as of:

- removed (2024-04-24):
[0001628280-23-035265:note_history:30]
|  | September 30, 2023 |  | December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | — |  |  | (350.0) |  |
| Remaining amount available | $ | 400.0 |  |  | $ | — |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:31]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on the floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2023 and December 31, 2022 were 0.00% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- removed (2024-04-24):
[0001628280-23-035265:note_history:32]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2023, we were in compliance with all covenant requirements.  The ASP will expire according to its terms in November 2023 and we do not intend to renew it.

- removed (2024-04-24):
[0001628280-23-035265:note_history:33]
Second Amendment to the Credit Agreement

- removed (2024-04-24):
[0001628280-23-035265:note_history:34]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.  Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financing.

- removed (2024-04-24):
[0001628280-23-035265:note_history:35]
The Credit Agreement consists of a $1.1 billion unsecured revolving credit facility.  We had outstanding borrowings of $0.0 million as well as $1.7 million committed to standby letters of credit as of September 30, 2023. Subject to covenant limitations, $1,098.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- removed (2024-04-24):
[0001628280-23-035265:note_history:36]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitization (cross default), and bankruptcy. A cross default under our Credit Agreement could occur if:


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-04-24):
[0001628280-24-017634:note_history:37]
|  | March 31, 2024 |  | December 31, 2023 |
| Commercial paper | $ | 250.0 |  |  | $ | 150.0 |  |
| Current maturities of long-term debt: |  |  |  |
| Finance lease obligations | $ | 22.5 |  |  | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |  | $ | 12.1 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | $ | 50.5 |  |  | $ | 32.7 |  |
| Credit agreement | 12.0 |  |  | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |  | (9.6) |  |
| Total long-term debt | $ | 1,153.7 |  |  | $ | 1,143.1 |  |
| Total debt | $ | 1,426.2 |  |  | $ | 1,305.2 |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:38]
|  | September 30, 2023 |  | December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.6 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.9 |  |  | 28.3 |  |
| Credit agreement | — |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (10.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,121.6 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,483.2 |  |  | $ | 1,524.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-04-24):
[0001628280-24-017634:note_history:39]
|  | For the Three Months Ended March 31, 2024 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 626.1 |  |  | $ | 357.3 |  |  | $ | — |  |  | $ | 983.4 |  |
| Canada | 48.5 |  |  | 15.2 |  |  | — |  |  | 63.7 |  |
| Other international | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 674.6 |  |  | $ | 372.5 |  |  | $ | — |  |  | $ | 1,047.1 |  |

- changed (2024-04-24):
[0001628280-24-017634:note_history:40]
|  | For the Three Months Ended March 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 639.3 |  |  | $ | 294.6 |  |  | $ | — |  |  | $ | 933.9 |  |
| Canada | 41.7 |  |  | 14.1 |  |  | — |  |  | 55.8 |  |
| Other international | — |  |  | — |  |  | 59.7 |  |  | 59.7 |  |
| Total | $ | 681.0 |  |  | $ | 308.7 |  |  | $ | 59.7 |  |  | $ | 1,049.4 |  |
  (was, 2023-10-26, similarity 0.7282):
[0001628280-23-035265:note_history:40]
|  | For the Three Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 842.1 |  |  | $ | 376.8 |  |  | $ | — |  |  | $ | 1,218.9 |  |
| Canada | 54.2 |  |  | 28.7 |  |  | — |  |  | 82.9 |  |
| Other international | — |  |  | — |  |  | 64.5 |  |  | 64.5 |  |
| Total | $ | 896.3 |  |  | $ | 405.5 |  |  | $ | 64.5 |  |  | $ | 1,366.3 |  |

- changed (2024-04-24):
[0001628280-24-017634:note_history:41]
Home Comfort Solutions - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2024 and 2023, direct sales represented 74% and 70% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2023-10-26, similarity 0.8206):
[0001628280-23-035265:note_history:41]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2023 and 2022, direct sales represented 77% and 72% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2023 and 2022, direct sales represented 75% and 70% of revenues, and sales to independent distributors represented the remainder.

- changed (2024-04-24):
[0001628280-24-017634:note_history:42]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools. These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers, offers HVAC recycling and salvage services and focuses on multi-family HVAC replacement for expired mechanical assets. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2024 and 2023, equipment sales represented 83% and 85% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2023-10-26, similarity 0.7796):
[0001628280-23-035265:note_history:42]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2023 and 2022, equipment sales represented 88% and 88% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2023 and 2022, equipment sales represented 87% and 87% of revenues and the remainder of our revenue was generated from our service business.

- changed (2024-04-24):
[0001628280-24-017634:note_history:43]
Corporate and Other - In Europe, we manufactured and marketed equipment for the global commercial refrigeration markets. We also manufactured and sold unitary heating and cooling products and applied systems. A de minimis amount of segment revenue related to services for start-up and commissioning activities. In the fourth quarter of 2023, we completed the divestiture of our European operations.
  (was, 2023-10-26, similarity 0.8457):
[0001628280-23-035265:note_history:43]
Corporate and Other - In Europe, we manufacture and market equipment for the global commercial refrigeration markets.  We also manufacture and sell unitary heating and cooling products and applied systems. A de minimis amount of segment revenue relates to services for start-up and commissioning activities.

- added (2024-04-24):
[0001628280-24-017634:note_history:44]
|  | March 31, 2024 |  | December 31, 2023 |  |  |  |  |
| Contract assets | $ | 1.9 |  |  | $ | 2.2 |  |  |  |  |  |
| Contract liabilities - current | (3.6) |  |  | (4.7) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.5) |  |  | (7.5) |  |  |  |  |  |
| Total | $ | (9.2) |  |  | $ | (10.0) |  |  |  |  |  |

- changed (2024-04-24):
[0001628280-24-017634:note_history:45]
For the three months ended March 31, 2024 and 2023, we recognized revenue of $5.7 million and $3.0 million related to our contract liabilities at January 1, 2024 and 2023, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2024 and 2023.
  (was, 2023-10-26, similarity 0.8093):
[0001628280-23-035265:note_history:45]
For the three months ended September 30, 2023 and 2022, we recognized revenue of $2.8 million and $3.6 million and for the nine months ended we recognized revenue of $7.0 million and $9.5 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.

- removed (2024-04-24):
[0001628280-23-035265:note_history:46]
|  | For the Three Months Ended September 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 331.9 |  |  | $ | — |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 352.3 |  |  | $ | 57.3 |  |  | $ | 1,244.9 |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:47]
|  | For the Nine Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,350.0 |  |  | $ | 1,053.5 |  |  | $ | — |  |  | $ | 3,403.5 |  |
| Canada | 163.6 |  |  | 68.0 |  |  | — |  |  | 231.6 |  |
| Other international | — |  |  | — |  |  | 192.0 |  |  | 192.0 |  |
| Total | $ | 2,513.6 |  |  | $ | 1,121.5 |  |  | $ | 192.0 |  |  | $ | 3,827.1 |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:48]
|  | For the Nine Months Ended September 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 915.4 |  |  | $ | — |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 959.2 |  |  | $ | 170.5 |  |  | $ | 3,624.6 |  |

- removed (2024-04-24):
[0001628280-23-035265:note_history:49]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and nine months ended September 30, 2022 have been recast to reflect the revised segment presentation.

- removed (2024-04-24):
[0001628280-23-035265:note_history:50]
|  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (4.9) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.2) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (12.1) |  |  | $ | (16.0) |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-04-24):
[0001628280-23-035265:note_history:51]
14. Subsequent Event:On October 25, 2023, we announced the acquisition of AES, a company dedicated to service and sustainability in the light commercial markets.  Across North America, AES provides installation services, adapter curbs, and recycling services.  AES will become part of the Commercial segment.
