# LII MD&A — 0001628280-24-017634


## mdna

[0001628280-24-017634:mdna:1]
[same as prior period, unchanged from 0001628280-23-035265:mdna:1]

[0001628280-24-017634:mdna:2]
[same as prior period, unchanged from 0001628280-23-035265:mdna:2]

[0001628280-24-017634:mdna:3]
We operate in two reportable business segments of the HVACR industry, Home Comfort Solutions and Building Climate Solutions.  In addition to the two major business segments, Corporate and Other is also reported as a segment.  For more detailed information regarding our reportable segments, see Note 2 in the Notes to the Consolidated Financial Statements.

[0001628280-24-017634:mdna:4]
[same as prior period, unchanged from 0001628280-23-035265:mdna:4]

[0001628280-24-017634:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and can be significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-24-017634:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, aluminum and copper.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of certain commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-24-017634:mdna:7]
[same as prior period, unchanged from 0001628280-23-035265:mdna:9]

[0001628280-24-017634:mdna:8]
Results for the first quarter of 2024 were driven by overall year-over-year sales and profit increases primarily led by our Building Climate Solutions segment, with an increase in net sales of 21% and an increase in segment profit of $28 million. Net sales decreased 1% and segment profit increased $1 million for our Home Comfort Solutions segment. Net sales decreased $60 million and segment loss increased $4 million for our Corporate and Other segment.  Our European businesses were sold in the fourth quarter of 2023 and generated $60 million in net sales in the first quarter of 2023 and had a segment loss of $0.4 million.

[0001628280-24-017634:mdna:9]
[same as prior period, unchanged from 0001628280-23-035265:mdna:11]

[0001628280-24-017634:mdna:10]
•Net sales of $1,047 million in the first quarter of 2024 were relatively flat as compared to the first quarter of 2023.

[0001628280-24-017634:mdna:11]
•Operating income in the first quarter of 2024 increased $27 million to $167 million primarily driven by favorable price.

[0001628280-24-017634:mdna:12]
•Net income for the first quarter of 2024 was $124 million.

[0001628280-24-017634:mdna:13]
•Diluted earnings per share was $3.47 per share in the first quarter of 2024 compared to $2.75 per share in the first quarter of 2023.

[0001628280-24-017634:mdna:14]
•For the three months ended March 31, 2024, we returned $39 million to shareholders through dividend payments.

[0001628280-24-017634:mdna:15]
Three Months Ended March 31, 2024 Compared to Three Months Ended March 31, 2023 - Consolidated Results

[0001628280-24-017634:mdna:16]
[same as prior period, unchanged from 0001628280-23-035265:mdna:18]

[0001628280-24-017634:mdna:17]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 1,047.1 |  |  | $ | 1,049.4 |  |  | (0.2) | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 707.1 |  |  | 742.8 |  |  | 4.8 |  |  | 67.5 |  |  | 70.8 |  |
| Gross profit | 340.0 |  |  | 306.6 |  |  | 10.9 |  |  | 32.5 |  |  | 29.2 |  |
| Selling, general and administrative expenses | 170.7 |  |  | 167.5 |  |  | (1.9) |  |  | 16.3 |  |  | 16.0 |  |
| Losses (gains) and other expenses, net | 3.7 |  |  | 0.3 |  |  | (1,133.3) |  |  | 0.4 |  |  | — |  |
| Income from equity method investments | (1.2) |  |  | (0.7) |  |  | 71.4 |  |  | (0.1) |  |  | (0.1) |  |
| Operating income | $ | 166.8 |  |  | $ | 139.5 |  |  | 19.6 | % |  | 15.9 | % |  | 13.3 | % |

[0001628280-24-017634:mdna:18]
[same as prior period, unchanged from 0001628280-23-035265:mdna:20]

[0001628280-24-017634:mdna:19]
Net sales for the first quarter of 2024 as compared to the same period of 2023 were relatively flat.  This was primarily due to a 6% reduction in sales from the fourth quarter 2023 sale of our European businesses and unfavorable mix of 1% which were partially offset by favorable price of 4%, a 2% increase in sales volumes from our AES acquisition, and 1% from higher sales volumes.

[0001628280-24-017634:mdna:20]
[same as prior period, unchanged from 0001628280-23-035265:mdna:22]

[0001628280-24-017634:mdna:21]
Gross profit margins in the first quarter of 2024 increased 330 basis points ("bps") to 32.5% compared to 29.2% in the first quarter of 2023. Gross margins increased 300 bps from favorable price, 50 bps from lower product warranty costs, and 30 bps from miscellaneous other items.  Partially offsetting these increases was 50 bps from higher freight and distribution costs.

[0001628280-24-017634:mdna:22]
[same as prior period, unchanged from 0001628280-23-035265:mdna:24]

[0001628280-24-017634:mdna:23]
Selling, general and administrative expenses ("SG&A") increased $3 million to $171 million in the first quarter of 2024 compared to $168 million in the first quarter of 2023 primarily due to higher employee-related costs including incentive compensation and wage inflation and higher discretionary spend, which were partially offset by a $16 million reduction in SG&A expenses from our fourth quarter of 2023 divestiture of our European businesses. As a percentage of net sales, SG&A increased 30 bps to 16.3%.

[0001628280-24-017634:mdna:24]
[same as prior period, unchanged from 0001628280-23-035265:mdna:26]

[0001628280-24-017634:mdna:25]
Losses (gains) and other expenses, net for the first quarter of 2024 and 2023 included the following (in millions):

[0001628280-24-017634:mdna:26]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |  |  |
| Foreign currency exchange losses (gains) | $ | 1.3 |  |  | $ | (0.8) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.4) |  |  | (0.3) |  |  |  |  |  |  |  |
| Other operating loss (income) | 0.3 |  |  | (0.8) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.1 |  |  | (0.2) |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 2.4 |  |  | 2.4 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 3.7 |  |  | $ | 0.3 |  |  |  |  |  |  |  |

[0001628280-24-017634:mdna:27]
[same as prior period, unchanged from 0001628280-23-035265:mdna:31]

[0001628280-24-017634:mdna:28]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation. Accordingly, these joint ventures are accounted for under the equity method and their financial position and results of operations are not consolidated. We recognized income from equity method investments of $1 million in the first quarter of 2024 and in the first quarter of 2023.

[0001628280-24-017634:mdna:29]
[same as prior period, unchanged from 0001628280-23-035265:mdna:33]

[0001628280-24-017634:mdna:30]
Interest expense, net decreased to $12 million in the first quarter of 2024 from $14 million in the first quarter of 2023 due to lower borrowings.

[0001628280-24-017634:mdna:31]
[same as prior period, unchanged from 0001628280-23-035265:mdna:35]

[0001628280-24-017634:mdna:32]
Our effective tax rate was 19.4% for the three months ended March 31, 2024 compared to 21.7% for the three months ended March 31, 2023.  The decrease in rate is primarily due to a discrete favorable adjustment for excess tax benefits in 2024 and unfavorable adjustments in 2023 related to discrete return to provision adjustments.

[0001628280-24-017634:mdna:33]
First Quarter of 2024 Compared to First Quarter of 2023 - Results by Segment

[0001628280-24-017634:mdna:34]
Home Comfort Solutions

[0001628280-24-017634:mdna:35]
The following table presents our Home Comfort Solutions segment's net sales and profit for the first quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-017634:mdna:36]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 674.6 |  |  | $ | 681.0 |  |  | $ | (6.4) |  |  | (1) | % |
| Profit | $ | 112.1 |  |  | $ | 111.1 |  |  | $ | 1.0 |  |  | 1 | % |
| % of net sales | 16.6 | % |  | 16.3 | % |  |  |  |  |

[0001628280-24-017634:mdna:37]
Net sales decreased 1% in the first quarter of 2024 compared to 2023 primarily due to unfavorable product mix of 2% and lower sales volumes of 2% which were partially offset by favorable price of 3%.

[0001628280-24-017634:mdna:38]
Segment profit in the first quarter of 2024 compared to 2023 increased by $1 million, primarily due to $23 million from higher price, and $1 million from miscellaneous other items.  Partially offsetting these increases were $11 million from higher SG&A costs, $6 million from higher freight and distribution costs, $4 million from lower sales volumes, and $2 million from unfavorable product mix.

[0001628280-24-017634:mdna:39]
Building Climate Solutions

[0001628280-24-017634:mdna:40]
The following table presents our Building Climate Solutions segment's net sales and profit for the first quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-017634:mdna:41]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | 372.5 |  |  | $ | 308.7 |  |  | $ | 63.8 |  |  | 21 | % |
| Profit | $ | 78.2 |  |  | $ | 50.0 |  |  | $ | 28.2 |  |  | 56 | % |
| % of net sales | 21.0 | % |  | 16.2 | % |  |  |  |  |

[0001628280-24-017634:mdna:42]
Net sales increased 21% in the first quarter of 2024 compared to 2023 as sales volumes increased 7%, price increased 6%, product mix increased 2%, and a 6% increase in sales volumes from our AES acquisition.

[0001628280-24-017634:mdna:43]
Segment profit in the first quarter of 2024 compared to 2023 increased $28 million primarily due to $18 million from favorable price, $7 million from higher sales volumes, $5 million from our acquisition of AES, and $1 million from favorable product mix.  Partially offsetting these increases was $3 million from higher SG&A costs.

[0001628280-24-017634:mdna:44]
[same as prior period, unchanged from 0001628280-23-035265:mdna:50]

[0001628280-24-017634:mdna:45]
The following table presents our Corporate and Other segment's net sales and loss for the first quarter of 2024 and 2023 (dollars in millions):

[0001628280-24-017634:mdna:46]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | Difference |  | % Change |
| Net sales | $ | — |  |  | $ | 59.7 |  |  | $ | (59.7) |  |  | (100) | % |
| Loss | $ | (23.5) |  |  | $ | (19.4) |  |  | $ | (4.1) |  |  | (21) | % |

[0001628280-24-017634:mdna:47]
Net sales decreased $60 million and segment loss increased $4 million in the first quarter of 2024 as compared to 2023.  Our European businesses, which were sold in the fourth quarter of 2023, generated $60 million net sales in the first quarter of 2023.  Excluding our European businesses, Corporate and Other costs increased $4 million in the first quarter of 2024 compared to 2023 due primarily to higher incentive compensation and wage inflation.

[0001628280-24-017634:mdna:48]
[same as prior period, unchanged from 0001628280-23-035265:mdna:93]

[0001628280-24-017634:mdna:49]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and a commercial paper program (as described below). Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001628280-24-017634:mdna:50]
[same as prior period, unchanged from 0001628280-23-035265:mdna:96]

[0001628280-24-017634:mdna:51]
The following table summarizes our cash flow activity for the three months ended March 31, 2024 and 2023 (in millions):

[0001628280-24-017634:mdna:52]
|  | For the Three Months Ended March 31, |
|  | 2024 |  | 2023 |
| Net cash used in operating activities | $ | (22.8) |  |  | $ | (78.8) |  |
| Net cash used in investing activities | (30.7) |  |  | (33.7) |  |
| Net cash provided by financing activities | 42.4 |  |  | 101.1 |  |

[0001628280-24-017634:mdna:53]
Net Cash Used In Operating Activities -  The change in net cash used in operating activities for the three months ended March 31, 2024 compared to the net cash used in operating activities for the same period in 2023 reflects changes in working capital and an increase in net income.

[0001628280-24-017634:mdna:54]
Net Cash Used In Investing Activities - Capital expenditures were $30 million for the three months ended March 31, 2024 compared to $35 million in the same period of 2023.  Capital expenditures in 2024 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-24-017634:mdna:55]
Net Cash Provided By Financing Activities - Net cash provided by financing activities for the three months ended March 31, 2024 decreased to $42 million compared to $101 million provided by financing activities in the same period of 2023.  The change was primarily due to changes in net borrowings and repayments of long-term debt.  We returned $39 million to shareholders through dividend payments for the three months ended March 31, 2024 and $38 million in the same period of 2023.

[0001628280-24-017634:mdna:56]
[same as prior period, unchanged from 0001628280-23-035265:mdna:102]

[0001628280-24-017634:mdna:57]
The following table details our lines of credit and financing arrangements as of March 31, 2024 (in millions):

[0001628280-24-017634:mdna:58]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 250.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 22.5 |  |
| Total current maturities of long-term debt | $ | 22.5 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 50.5 |  |
| Credit agreement | 12.0 |  |
| Senior unsecured notes | 1,100.0 |  |
| Debt issuance costs | (8.8) |  |
| Total long-term debt | $ | 1,153.7 |  |
| Total debt | $ | 1,426.2 |  |

[0001628280-24-017634:mdna:59]
Commercial Paper Program

[0001628280-24-017634:mdna:60]
On October 25, 2023, we established a commercial paper program, as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes have maturities of up to 397 days from the date of issue and rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds from issuances of the CP Notes are typically used for general corporate purposes. Our revolving credit facility serves as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $250.0 million as of March 31, 2024.

[0001628280-24-017634:mdna:61]
Credit Agreement

[0001628280-24-017634:mdna:62]
We have an existing $1.1 billion unsecured revolving credit facility dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. We had outstanding borrowings of $12.0 million as well as $1.7 million committed to standby letters of credit as of March 31, 2024. Subject to covenant limitations, $836.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Program. The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-017634:mdna:63]
[same as prior period, unchanged from 0001628280-23-035265:mdna:111]

[0001628280-24-017634:mdna:64]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027

[0001628280-24-017634:mdna:65]
21

[0001628280-24-017634:mdna:66]
(the "2027 Notes," and collectively with the 2025 Notes and the 2028 Notes, the "Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum.

[0001628280-24-017634:mdna:67]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. All the Notes are guaranteed, on a senior unsecured basis, by the Guarantor Subsidiaries.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the Guarantor Subsidiaries to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2024, we believe we were in compliance with all covenant requirements.

[0001628280-24-017634:mdna:68]
[same as prior period, unchanged from 0001628280-23-035265:mdna:114]

[0001628280-24-017634:mdna:69]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 79% as of March 31, 2024 from 82% as of December 31, 2023.

[0001628280-24-017634:mdna:70]
As of March 31, 2024, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-24-017634:mdna:71]
[same as prior period, unchanged from 0001628280-23-035265:mdna:117]

[0001628280-24-017634:mdna:72]
We believe our cash and cash equivalents of $46 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $46 million as of March 31, 2024 was $21 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-24-017634:mdna:73]
Guarantees Related to Our Debt Obligations

[0001628280-24-017634:mdna:74]
Our senior unsecured notes were issued by Lennox International Inc. ("Parent") and are unconditionally guaranteed by the Guarantor Subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-24-017634:mdna:75]
The following combined Parent and Guarantor Subsidiaries financial information is presented as of March 31, 2024 and December 31, 2023 and for the three months ended March 31, 2024 (in millions):

[0001628280-24-017634:mdna:76]
|  | March 31, 2024 |  | December 31, 2023 |
| Current assets | $ | 1,425.3 |  |  | $ | 1,291.0 |  |
| Non-current assets | 6,009.3 |  |  | 5,737.1 |  |
| Current liabilities | 915.0 |  |  | 843.3 |  |
| Non-current liabilities | 1,492.7 |  |  | 1,477.3 |  |
| Amounts due to non-guarantor subsidiaries | (497.1) |  |  | (472.3) |  |
|  | For the Three Months Ended March 31, 2024 |  | For the Year Ended, December 31, 2023 |
| Net Sales | $ | 1,035.7 |  |  | $ | 4,626.8 |  |
| Gross Profit | 259.5 |  |  | 1,157.8 |  |
| Net Income | 289.8 |  |  | 1,331.1 |  |

[0001628280-24-017634:mdna:77]
[same as prior period, unchanged from 0001628280-23-035265:mdna:125]

[0001628280-24-017634:mdna:78]
We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001628280-24-017634:mdna:79]
Commitments, Contingencies and Guarantees

[0001628280-24-017634:mdna:80]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-24-017634:mdna:81]
[same as prior period, unchanged from 0001628280-23-035265:mdna:129]

[0001628280-24-017634:mdna:82]
[same as prior period, unchanged from 0001628280-23-035265:mdna:130]
