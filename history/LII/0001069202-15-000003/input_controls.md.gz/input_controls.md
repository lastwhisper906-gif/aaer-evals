# LII 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001069202-15-000003:item_9a:1]
Item 9A.  Controls and Procedures

[0001069202-15-000003:item_9a:2]
Disclosure Controls and Procedures

[0001069202-15-000003:item_9a:3]
As required by Rule 13a-15 under the Exchange Act, we carried out an evaluation, under the supervision and with the participation of our current management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures as of the end of the period covered by this report.  There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that, as of December 31, 2014, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports we file or submit under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the applicable rules and forms, and that such information is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001069202-15-000003:item_9a:4]
Management's Annual Report on Internal Control Over Financial Reporting

[0001069202-15-000003:item_9a:5]
See “Management's Report on Internal Control Over Financial Reporting” included in Item 8 “Financial Statements and Supplementary Data.”

[0001069202-15-000003:item_9a:6]
Attestation Report of the Independent Registered Public Accounting Firm

[0001069202-15-000003:item_9a:7]
See “Report of Independent Registered Public Accounting Firm” included in Item 8 “Financial Statements and Supplementary Data.”

[0001069202-15-000003:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001069202-15-000003:item_9a:9]
There were no changes during the fourth quarter ended December 31, 2014 in our internal control over financial reporting that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
