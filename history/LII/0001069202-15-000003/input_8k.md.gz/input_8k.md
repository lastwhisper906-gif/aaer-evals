# LII 8-K — 0001193125-15-028688 filed 2015-02-02

## item codes, every 8-K on or before 2015-02-17

- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2015-02-17

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-028688:8k_2_02:1]
EX-99.1
2
d860984dex991.htm
EX-99.1

[0001193125-15-028688:8k_2_02:2]
EX-99.1

[0001193125-15-028688:8k_2_02:3]
Exhibit 99.1

[0001193125-15-028688:8k_2_02:4]
Lennox International Reports Record Fourth-Quarter and Full-Year Profit

[0001193125-15-028688:8k_2_02:5]
| • |  | 4Q14 revenue up 8%, led by 13% Residential growth |

[0001193125-15-028688:8k_2_02:6]
| • |  | 4Q14 adjusted EPS from continuing operations of $1.02 up 32%, and GAAP EPS from continuing operations of $1.00 up 47% |

[0001193125-15-028688:8k_2_02:7]
| • |  | 2014 revenue up 5%, with adjusted EPS from continuing operations of $4.38 up 18% and GAAP EPS from continuing operations of $4.28 up 21% |

[0001193125-15-028688:8k_2_02:8]
| • |  | Reiterate 2015 revenue growth guidance of 4-8% at constant currency |

[0001193125-15-028688:8k_2_02:9]
| • |  | Reiterate 2015 EPS from continuing operations guidance of $5.20-$5.60 |

[0001193125-15-028688:8k_2_02:10]
DALLAS, February 2, 2015 –
Lennox International Inc. (NYSE: LII) today reported fourth quarter and full year 2014 results. Financial results in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-15-028688:8k_2_02:11]
For the fourth quarter, revenue was $813 million, up 8% from the prior-year quarter. At constant currency, revenue was up 10%. Total segment profit margin was
a fourth-quarter record 9.4%, up 120 basis points from the prior-year quarter. Diluted earnings per share from continuing operations on an adjusted basis was a fourth-quarter record $1.02, up 32% from $0.77 in the prior-year quarter. On a GAAP
basis, diluted earnings per share from continuing operations was a fourth-quarter record $1.00, up 47% from $0.68 in the prior-year quarter.

[0001193125-15-028688:8k_2_02:12]
For the full
year, revenue was $3.4 billion, up 5% from the prior year. At constant currency, revenue was up 6%. Total segment profit margin was a record 10.1%, up 70 basis points from the prior year. Diluted earnings per share from continuing operations on an
adjusted basis was a record $4.38, up 18% from $3.70 in the prior year. On a GAAP basis, diluted earnings per share from continuing operations was a record $4.28, up 21% from $3.55 in the prior year.

[0001193125-15-028688:8k_2_02:13]
“2014 was a year of strong growth and record profitability for Lennox International, led by 10% revenue growth at constant currency and 31% profit growth
in our Residential business,” said Chairman and CEO Todd Bluedorn. “In the fourth quarter, the company’s momentum continued, with revenue up 10% at constant currency and total segment profit up 24%. Growth in the quarter continued to
be led by Residential, with revenue up 14% at constant currency and profit up 57% from the prior-year quarter. In Commercial, revenue rose 8% at constant currency. Commercial profit was essentially flat with the prior-year quarter on headwinds from
customer mix, foreign exchange, and investments related to our entrance in the VRF market. In Refrigeration, revenue was up 8% at constant currency. As expected, Refrigeration profit was down from the prior-year quarter by 45% due to the repeal of
the carbon tax in Australia, North America product mix, and a negative impact from foreign exchange. We continue to expect Refrigeration revenue, margin and profit to be up in 2015 on continued growth in North America and improvement in Australia in
the second half of the year. For the company overall in 2015, we expect another strong year of growth and record profitability, with strong cash generation for investments to drive growth as well as to return cash to shareholders.”

[0001193125-15-028688:8k_2_02:14]
FOURTH QUARTER 2014 FINANCIAL HIGHLIGHTS

[0001193125-15-028688:8k_2_02:15]
Revenue: Revenue for the fourth quarter was $813 million, up 8% from the prior-year quarter. At constant currency, revenue was up 10%. Volume and
price/mix were up from the fourth quarter a year ago.

[0001193125-15-028688:8k_2_02:16]
Gross Profit: Gross profit in the fourth quarter was $225 million, up 9% from $208 million
in the prior-year quarter. Gross margin was 27.7%, flat with the fourth quarter a year ago. Gross profit was positively impacted by higher volume, lower material costs, and favorable warranty expense, with partial offsets from unfavorable foreign
exchange, lower mix, the repeal of the carbon tax in Australia, and investments in distribution expansion.

[0001193125-15-028688:8k_2_02:17]
Income from Continuing Operations: For
the fourth quarter, adjusted income from continuing operations was $47 million, or $1.02 diluted earnings per share, compared to $38 million, or $0.77 diluted earnings per share, in the prior-year quarter. On a GAAP basis, fourth quarter income from
continuing operations was $46 million, or $1.00 diluted earnings per share, compared to $34 million, or $0.68 diluted earnings per share, in the prior-year quarter.

[0001193125-15-028688:8k_2_02:18]
Adjusted income from continuing operations for the fourth quarter of 2014 excludes net after-tax charges of $0.8 million, which are derived from a $0.4
million charge related to restructuring activities, $0.3 million for the net change in unrealized losses on unsettled future contracts, and $0.1 million in charges, net, for other items.

[0001193125-15-028688:8k_2_02:19]
FULL YEAR 2014 FINANCIAL HIGHLIGHTS

[0001193125-15-028688:8k_2_02:20]
Revenue: For the full year, revenue was $3.4 billion, up 5%. At constant currency, revenue was up 6%. Volume and price/mix were up from the prior year.

[0001193125-15-028688:8k_2_02:21]
Gross Profit: Gross profit for the full year was $903 million, up 5% from $861 million in the prior year. Gross margin was 26.8% compared to 26.9%
in the prior year. Gross profit was negatively impacted by unfavorable foreign exchange, lower mix, and investments in distribution expansion, with partial offsets from higher volume, favorable price, and lower material costs.

[0001193125-15-028688:8k_2_02:22]
Income from Continuing Operations: Adjusted income from continuing operations for 2014 was $213 million, or $4.38 diluted earnings per share, compared
to $187 million, or $3.70 diluted earnings per share, in the prior year. On a GAAP basis, income from continuing operations for 2014 was $208 million, or $4.28 diluted earnings per share, compared to $180 million, or $3.55 diluted earnings per
share, in the prior year.

[0001193125-15-028688:8k_2_02:23]
Adjusted income from continuing operations for 2014 excludes net after-tax charges of $5.0 million, which are derived from a
$1.8 million charge related to restructuring activities, $0.4 million for the net change in unrealized losses on unsettled futures contracts, and $2.8 million in charges, net, for other items.

[0001193125-15-028688:8k_2_02:24]
Free Cash Flow and Total Debt: Cash from operations for the fourth quarter was $161 million, compared to $145 million in the prior-year quarter.
Capital expenditures were approximately $28 million in the fourth quarter compared to $37 million in the prior-year quarter. Including $1 million in proceeds from the disposal of property, plant and equipment (PP&E), free cash flow was $134
million, compared to $110 million in the prior-year quarter. As previously announced for the fourth quarter, the company strategically built $77 million of inventory to support customers in the minimum-efficiency regulatory transition taking effect
at the start of 2015 for certain products.

[0001193125-15-028688:8k_2_02:25]
For the full year, cash from operations was $185 million, compared to $210 million in the prior year. Capital
expenditures were $88 million in 2014 compared to $78 million in 2013. Including $1 million from the disposal of PP&E, free cash flow was $98 million for the full year, compared to $134 million in the prior year. The company paid $53 million in
dividends for the year and $550 million related to its stock repurchase programs. Total debt at the end of 2014 was $926 million. Total cash and cash equivalents were $38 million ending the year.

[0001193125-15-028688:8k_2_02:26]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-15-028688:8k_2_02:27]
Residential Heating and Cooling

[0001193125-15-028688:8k_2_02:28]
| • |  | 4Q14 revenue of $404 million, up 13% from $359 million in 4Q13; up 14% at constant currency |

[0001193125-15-028688:8k_2_02:29]
| • |  | 4Q14 segment profit a fourth-quarter record $57 million, up 57% from $36 million in 4Q13 |

[0001193125-15-028688:8k_2_02:30]
| • |  | 4Q14 segment profit margin a fourth-quarter record 14.1%, up 390 basis points from 10.2% in 4Q13 |

[0001193125-15-028688:8k_2_02:31]
| • |  | 2014 revenue of $1,737 million, up 10% from $1,583 million in 2013; up 11% at constant currency |

[0001193125-15-028688:8k_2_02:32]
| • |  | 2014 segment profit a record $236 million, up 31% from $180 million in 2013 |

[0001193125-15-028688:8k_2_02:33]
| • |  | 2014 profit margin a record 13.6%, up 220 basis points from 11.4% in 2013 |

[0001193125-15-028688:8k_2_02:34]
Fourth quarter and full-year
results were positively impacted by higher volume, favorable price/mix, lower material costs, and favorable warranty expense, with partial offsets from unfavorable foreign exchange, higher SG&A, and strategic investments in distribution
expansion.

[0001193125-15-028688:8k_2_02:35]
Commercial Heating and Cooling

[0001193125-15-028688:8k_2_02:36]
| • |  | 4Q14 revenue of $223 million, up 5% from $213 million in 4Q13; up 8% at constant currency |

[0001193125-15-028688:8k_2_02:37]
| • |  | 4Q14 segment profit of $33 million, flat with 4Q13 |

[0001193125-15-028688:8k_2_02:38]
| • |  | 4Q14 segment profit margin of 14.6%, down 110 basis points from 15.7% in 4Q13 |

[0001193125-15-028688:8k_2_02:39]
| • |  | 2014 revenue a record $879 million, up 4% from $844 million in 2013; up 5% at constant currency |

[0001193125-15-028688:8k_2_02:40]
| • |  | 2014 segment profit a record $124 million, up 5% from $118 million in 2013 |

[0001193125-15-028688:8k_2_02:41]
| • |  | 2014 segment profit margin a record 14.1%, up 10 basis points from 14.0% in 2013 |

[0001193125-15-028688:8k_2_02:42]
Fourth quarter and full year
results were positively impacted by higher volume, favorable price, and lower material costs, with partial offsets from unfavorable mix, unfavorable foreign exchange, and strategic investments to enter the VRF market and distribution expansion in
North America.

[0001193125-15-028688:8k_2_02:43]
Refrigeration

[0001193125-15-028688:8k_2_02:44]
| • |  | 4Q14 revenue of $186 million, up 4% from $178 million in 4Q13; up 8% at constant currency |

[0001193125-15-028688:8k_2_02:45]
| • |  | 4Q14 segment profit of $13 million, down 45% from $24 million in 4Q13 |

[0001193125-15-028688:8k_2_02:46]
| • |  | 4Q14 segment profit margin of 7.0%, down 630 basis points from 13.3% in 4Q13 |

[0001193125-15-028688:8k_2_02:47]
| • |  | 2014 revenue of $752 million, down 2% from $772 million in 2013; flat at constant currency |

[0001193125-15-028688:8k_2_02:48]
| • |  | 2014 segment profit of $55 million, down 39% from $90 million in 2013 |

[0001193125-15-028688:8k_2_02:49]
| • |  | 2014 segment profit margin of 7.4%, down 430 basis points from 11.7% in 2013 |

[0001193125-15-028688:8k_2_02:50]
Fourth quarter and full year
results were negatively impacted by lower mix, the repeal of the carbon tax in Australia, unfavorable foreign exchange, and investments for future growth, with partial offsets from higher volume, favorable price, and lower material costs.

[0001193125-15-028688:8k_2_02:51]
FULL-YEAR OUTLOOK

[0001193125-15-028688:8k_2_02:52]
| • |  | Reiterating revenue growth of 4-8% at constant currency; the company now expects a negative 3 point impact from foreign exchange on a full-year basis for a revenue growth range of 1-5% at actual currency |

[0001193125-15-028688:8k_2_02:53]
| • |  | Reiterating adjusted and GAAP EPS from continuing operations of $5.20-$5.60 |

[0001193125-15-028688:8k_2_02:54]
| • |  | Reiterating an effective tax rate of 34-35% |

[0001193125-15-028688:8k_2_02:55]
| • |  | Reiterating capital expenditures of approximately $85 million |

[0001193125-15-028688:8k_2_02:56]
| • |  | Reiterating the completion of the company’s previously announced $450 million accelerated share repurchase program in the second half of 2015 |

[0001193125-15-028688:8k_2_02:57]
CONFERENCE CALL INFORMATION

[0001193125-15-028688:8k_2_02:58]
A conference call to discuss
the company’s fourth quarter and full year 2014 results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-288-0340 at least 10 minutes prior to the scheduled start time and use reservation
number 350261. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com.

[0001193125-15-028688:8k_2_02:59]
A replay will be
available from 11:00 a.m. Central time on February 2 through February 9, 2015, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 350261. The call will also be archived on the company’s web site.

[0001193125-15-028688:8k_2_02:60]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New York
Stock Exchange under the symbol “LII”. Additional information is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-15-028688:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-028688:8k_2_02:62]
Consolidated Statements of Operations

[0001193125-15-028688:8k_2_02:63]
| (Amounts in millions, except per share data) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 812.8 |  |  | $ | 749.5 |  |  | $ | 3,367.4 |  |  | $ | 3,199.1 |  |
| Cost of goods sold |  |  | 587.4 |  |  |  | 541.8 |  |  |  | 2,464.1 |  |  |  | 2,337.9 |  |
| Gross profit |  |  | 225.4 |  |  |  | 207.7 |  |  |  | 903.3 |  |  |  | 861.2 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 148.2 |  |  |  | 146.0 |  |  |  | 573.7 |  |  |  | 570.1 |  |
| Losses and other expenses, net |  |  | 3.3 |  |  |  | 6.4 |  |  |  | 6.8 |  |  |  | 9.3 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 1.8 |  |  |  | 1.9 |  |  |  | 5.0 |  |
| Income from equity method investments |  |  | (1.8 | ) |  |  | (1.4 | ) |  |  | (13.8 | ) |  |  | (12.2 | ) |
| Operational income from continuing operations |  |  | 75.1 |  |  |  | 54.9 |  |  |  | 334.7 |  |  |  | 289.0 |  |
| Interest expense, net |  |  | 6.2 |  |  |  | 3.8 |  |  |  | 17.2 |  |  |  | 14.5 |  |
| Other expense (income), net |  |  | (0.1 | ) |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |
| Income from continuing operations before income taxes |  |  | 69.0 |  |  |  | 50.8 |  |  |  | 317.6 |  |  |  | 274.3 |  |
| Provision for income taxes |  |  | 22.9 |  |  |  | 16.8 |  |  |  | 109.5 |  |  |  | 94.4 |  |
| Income from continuing operations |  |  | 46.1 |  |  |  | 34.0 |  |  |  | 208.1 |  |  |  | 179.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes |  |  | (2.4 | ) |  |  | 2.4 |  |  |  | (3.7 | ) |  |  | (13.3 | ) |
| Provision for (benefit from) income taxes |  |  | (0.9 | ) |  |  | 1.2 |  |  |  | (1.4 | ) |  |  | (5.2 | ) |
| Income (loss) from discontinued operations |  |  | (1.5 | ) |  |  | 1.2 |  |  |  | (2.3 | ) |  |  | (8.1 | ) |
| Net income |  | $ | 44.6 |  |  | $ | 35.2 |  |  | $ | 205.8 |  |  | $ | 171.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.01 |  |  | $ | 0.69 |  |  | $ | 4.35 |  |  | $ | 3.61 |  |
| Income (loss) from discontinued operations |  |  | (0.03 | ) |  |  | 0.03 |  |  |  | (0.05 | ) |  |  | (0.16 | ) |
| Net income |  | $ | 0.98 |  |  | $ | 0.72 |  |  | $ | 4.30 |  |  | $ | 3.45 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.00 |  |  | $ | 0.68 |  |  | $ | 4.28 |  |  | $ | 3.55 |  |
| Income (loss) from discontinued operations |  |  | (0.04 | ) |  |  | 0.02 |  |  |  | (0.05 | ) |  |  | (0.16 | ) |
| Net income |  | $ | 0.96 |  |  | $ | 0.70 |  |  | $ | 4.23 |  |  | $ | 3.39 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 45.5 |  |  |  | 49.2 |  |  |  | 47.9 |  |  |  | 49.8 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 46.2 |  |  |  | 50.1 |  |  |  | 48.6 |  |  |  | 50.6 |  |
| Cash dividends declared per share |  | $ | 0.30 |  |  | $ | 0.24 |  |  | $ | 1.14 |  |  | $ | 0.92 |  |

[0001193125-15-028688:8k_2_02:64]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-028688:8k_2_02:65]
Segment Net Sales and Profit (Loss)

[0001193125-15-028688:8k_2_02:66]
| (Amounts in millions) |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 404.0 |  |  | $ | 358.6 |  |  | $ | 1,736.5 |  |  | $ | 1,583.2 |  |
| Commercial Heating & Cooling |  |  | 222.9 |  |  |  | 212.6 |  |  |  | 878.5 |  |  |  | 844.4 |  |
| Refrigeration |  |  | 185.9 |  |  |  | 178.3 |  |  |  | 752.4 |  |  |  | 771.5 |  |
|  |  | $ | 812.8 |  |  | $ | 749.5 |  |  | $ | 3,367.4 |  |  | $ | 3,199.1 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 57.0 |  |  | $ | 36.4 |  |  | $ | 235.8 |  |  | $ | 180.1 |  |
| Commercial Heating & Cooling |  |  | 32.6 |  |  |  | 33.3 |  |  |  | 124.0 |  |  |  | 118.1 |  |
| Refrigeration |  |  | 13.1 |  |  |  | 23.7 |  |  |  | 55.4 |  |  |  | 90.2 |  |
| Corporate and other |  |  | (26.4 | ) |  |  | (31.8 | ) |  |  | (74.3 | ) |  |  | (87.9 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 76.3 |  |  |  | 61.6 |  |  |  | 340.9 |  |  |  | 300.5 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (1.4 | ) |  |  | (1.9 | ) |  |  | (1.4 | ) |  |  | (2.3 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 2.0 |  |  |  | 6.8 |  |  |  | 4.7 |  |  |  | 8.8 |  |
| Restructuring charges |  |  | 0.6 |  |  |  | 1.8 |  |  |  | 1.9 |  |  |  | 5.0 |  |
| Interest expense, net |  |  | 6.2 |  |  |  | 3.8 |  |  |  | 17.2 |  |  |  | 14.5 |  |
| Special inventory write down |  |  | — |  |  |  | — |  |  |  | 1.0 |  |  |  | — |  |
| Other expense (income), net |  |  | (0.1 | ) |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 0.2 |  |
| Income from continuing operations before income taxes |  | $ | 69.0 |  |  | $ | 50.8 |  |  | $ | 317.6 |  |  | $ | 274.3 |  |

[0001193125-15-028688:8k_2_02:67]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-15-028688:8k_2_02:68]
|  | • |  | Special product quality adjustments; |

[0001193125-15-028688:8k_2_02:69]
|  | • |  | The following items in Losses and other expenses, net: |

[0001193125-15-028688:8k_2_02:70]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-15-028688:8k_2_02:71]
|  | • |  | Special legal contingency charges, |

[0001193125-15-028688:8k_2_02:72]
|  | • |  | Asbestos-related litigation, |

[0001193125-15-028688:8k_2_02:73]
|  | • |  | Environmental liabilities, and |

[0001193125-15-028688:8k_2_02:74]
|  | • |  | Other items, net; |

[0001193125-15-028688:8k_2_02:75]
|  | • |  | Restructuring charges; |

[0001193125-15-028688:8k_2_02:76]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-15-028688:8k_2_02:77]
|  | • |  | Interest expense, net; |

[0001193125-15-028688:8k_2_02:78]
|  | • |  | Special inventory write down; and |

[0001193125-15-028688:8k_2_02:79]
|  | • |  | Other expense, net. |

[0001193125-15-028688:8k_2_02:80]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-028688:8k_2_02:81]
Consolidated Balance Sheets

[0001193125-15-028688:8k_2_02:82]
| (Amounts in millions, except shares and par values) |  | As of December 31,2014 |  |  | As of December 31,2013 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 37.5 |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net of allowances of $7.9 and $9.8 in 2014 and 2013, respectively |  |  | 421.4 |  |  |  | 408.1 |  |
| Inventories, net |  |  | 463.3 |  |  |  | 378.8 |  |
| Deferred income taxes, net |  |  | 32.5 |  |  |  | 24.5 |  |
| Other assets |  |  | 59.3 |  |  |  | 53.0 |  |
| Total current assets |  |  | 1,014.0 |  |  |  | 902.4 |  |
| Property, plant and equipment, net |  |  | 358.6 |  |  |  | 335.5 |  |
| Goodwill |  |  | 209.4 |  |  |  | 216.8 |  |
| Deferred income taxes |  |  | 97.5 |  |  |  | 88.5 |  |
| Other assets, net |  |  | 84.8 |  |  |  | 83.5 |  |
| Total assets |  | $ | 1,764.3 |  |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 226.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt |  |  | 24.0 |  |  |  | 1.3 |  |
| Accounts payable |  |  | 324.3 |  |  |  | 283.1 |  |
| Accrued expenses |  |  | 239.0 |  |  |  | 232.1 |  |
| Income taxes payable |  |  | 13.4 |  |  |  | 31.6 |  |
| Total current liabilities |  |  | 827.3 |  |  |  | 714.0 |  |
| Long-term debt |  |  | 675.0 |  |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions |  |  | 4.5 |  |  |  | 4.6 |  |
| Pensions |  |  | 129.9 |  |  |  | 70.0 |  |
| Other liabilities |  |  | 118.6 |  |  |  | 119.2 |  |
| Total liabilities |  |  | 1,755.3 |  |  |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 824.9 |  |  |  | 912.7 |  |
| Retained earnings |  |  | 1,022.1 |  |  |  | 870.5 |  |
| Accumulated other comprehensive loss |  |  | (153.5 | ) |  |  | (61.1 | ) |
| Treasury stock, at cost, 42,535,126 shares and 38,066,794 shares for 2014 and 2013, respectively |  |  | (1,686.0 | ) |  |  | (1,238.1 | ) |
| Noncontrolling interests |  |  | 0.6 |  |  |  | 0.8 |  |
| Total stockholders’ equity |  |  | 9.0 |  |  |  | 485.7 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,764.3 |  |  | $ | 1,626.7 |  |

[0001193125-15-028688:8k_2_02:83]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-028688:8k_2_02:84]
Consolidated Statements of Cash Flows

[0001193125-15-028688:8k_2_02:85]
| (Amounts in millions) |  | For the Years Ended December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 205.8 |  |  | $ | 171.8 |  |
| Net loss from discontinued operations |  |  | 2.3 |  |  |  | 8.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (13.8 | ) |  |  | (12.2 | ) |
| Dividends from affiliates |  |  | 9.1 |  |  |  | 10.3 |  |
| Restructuring expenses, net of cash paid |  |  | 0.2 |  |  |  | 0.1 |  |
| Provision for bad debts |  |  | 2.6 |  |  |  | 3.6 |  |
| Unrealized losses on derivative contracts |  |  | 0.3 |  |  |  | 0.3 |  |
| Stock-based compensation expense |  |  | 23.3 |  |  |  | 29.3 |  |
| Depreciation and amortization |  |  | 60.8 |  |  |  | 58.9 |  |
| Deferred income taxes |  |  | 6.1 |  |  |  | 3.5 |  |
| Pension costs in excess of (less than) contributions |  |  | (8.0 | ) |  |  | 1.7 |  |
| Other items, net |  |  | 0.1 |  |  |  | 4.5 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (32.6 | ) |  |  | (49.0 | ) |
| Inventories |  |  | (96.7 | ) |  |  | (19.5 | ) |
| Other current assets |  |  | (8.3 | ) |  |  | (16.3 | ) |
| Accounts payable |  |  | 46.1 |  |  |  | (10.9 | ) |
| Accrued expenses |  |  | 6.7 |  |  |  | 15.4 |  |
| Income taxes payable and receivable |  |  | (15.9 | ) |  |  | 21.9 |  |
| Other, net |  |  | (1.0 | ) |  |  | 4.4 |  |
| Net cash used in discontinued operations |  |  | (2.3 | ) |  |  | (15.6 | ) |
| Net cash provided by operating activities |  |  | 184.8 |  |  |  | 210.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 1.1 |  |  |  | 2.4 |  |
| Purchases of property, plant and equipment |  |  | (88.4 | ) |  |  | (78.3 | ) |
| Net proceeds from sale of businesses |  |  | — |  |  |  | 8.6 |  |
| Net cash used in investing activities |  |  | (87.3 | ) |  |  | (67.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 1.5 |  |  |  | 2.0 |  |
| Asset securitization borrowings |  |  | 100.0 |  |  |  | 330.0 |  |
| Asset securitization payments |  |  | (40.0 | ) |  |  | (200.0 | ) |
| Term loan borrowings from credit facility |  |  | 300.0 |  |  |  | — |  |
| Long-term debt payments |  |  | (2.3 | ) |  |  | (1.0 | ) |
| Borrowings from revolving credit facility |  |  | 2,073.5 |  |  |  | 1,425.5 |  |
| Payments on revolving credit facility |  |  | (1,908.5 | ) |  |  | (1,543.5 | ) |
| Payments of deferred financing costs |  |  | (2.2 | ) |  |  | — |  |
| Additional investment in subsidiary |  |  | — |  |  |  | (0.5 | ) |
| Proceeds from employee stock purchases |  |  | 2.0 |  |  |  | 1.8 |  |
| Repurchases of common stock |  |  | (550.3 | ) |  |  | (125.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (22.4 | ) |  |  | (12.0 | ) |
| Excess tax benefits related to share-based payments |  |  | 11.8 |  |  |  | 6.5 |  |
| Cash dividends paid |  |  | (52.6 | ) |  |  | (34.0 | ) |
| Net cash used in financing activities |  |  | (89.5 | ) |  |  | (150.2 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 8.0 |  |  |  | (7.2 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (8.5 | ) |  |  | (6.6 | ) |
| Cash and cash equivalents, beginning of year |  |  | 38.0 |  |  |  | 51.8 |  |
| Cash and cash equivalents, end of year |  | $ | 37.5 |  |  | $ | 38.0 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the year for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 17.6 |  |  | $ | 15.7 |  |
| Income taxes (net of refunds) |  | $ | 105.3 |  |  | $ | 56.8 |  |

[0001193125-15-028688:8k_2_02:86]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-15-028688:8k_2_02:87]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-15-028688:8k_2_02:88]
(Unaudited, in millions, except per share and ratio data)

[0001193125-15-028688:8k_2_02:89]
Use of Non-GAAP Financial Measures

[0001193125-15-028688:8k_2_02:90]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-15-028688:8k_2_02:91]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-15-028688:8k_2_02:92]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Income from continuing operations, a GAAP measure |  | $ | 46.1 |  |  | $ | 34.0 |  |  | $ | 208.1 |  |  | $ | 179.9 |  |
| Restructuring charges, after tax |  |  | 0.4 |  |  |  | 1.3 |  |  |  | 1.8 |  |  |  | 3.4 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.8 | ) |  |  | (1.1 | ) |  |  | (0.9 | ) |  |  | (1.5 | ) |
| Special legal contingency charges, after tax (a) |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.6 |  |  |  | 0.7 |  |
| Asbestos-related litigation, after tax (a) |  |  | — |  |  |  | 3.9 |  |  |  | 0.6 |  |  |  | 3.9 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | 0.3 |  |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | 0.3 |  |
| Special inventory write down, after tax (b) |  |  | — |  |  |  | — |  |  |  | 0.8 |  |  |  | — |  |
| Environmental liabilities, after tax (a) |  |  | 0.7 |  |  |  | — |  |  |  | 1.2 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.3 |  |  |  | 0.5 |  |  |  | 0.6 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 46.9 |  |  | $ | 38.3 |  |  | $ | 213.1 |  |  | $ | 187.3 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 1.00 |  |  | $ | 0.68 |  |  | $ | 4.28 |  |  | $ | 3.55 |  |
| Restructuring charges, after tax |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.07 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.02 | ) |  |  | (0.02 | ) |  |  | (0.02 | ) |  |  | (0.03 | ) |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Asbestos-related litigation, after tax (a) |  |  | — |  |  |  | 0.08 |  |  |  | 0.01 |  |  |  | 0.08 |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax(a) |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Special inventory write down, after tax (b) |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Environmental liabilities, after tax (a) |  |  | 0.02 |  |  |  | — |  |  |  | 0.03 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  | $ | 1.02 |  |  | $ | 0.77 |  |  | $ | 4.38 |  |  | $ | 3.70 |  |

[0001193125-15-028688:8k_2_02:93]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-15-028688:8k_2_02:94]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-15-028688:8k_2_02:95]
|  |  | For the Three MonthsEnded December 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Components of Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.8 |  |  | $ | 1.0 |  |
| Foreign currency exchange losses (a) |  |  | 1.5 |  |  |  | 0.4 |  |  |  | 1.6 |  |  |  | 0.5 |  |
| Gain on disposal of fixed assets (a) |  |  | (0.3 | ) |  |  | (1.0 | ) |  |  | (0.3 | ) |  |  | (1.0 | ) |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | 0.6 |  |  |  | 0.4 |  |
| Special legal contingency charges (b) |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 0.9 |  |  |  | 1.2 |  |
| Asbestos-related litigation (b) |  |  | — |  |  |  | 6.3 |  |  |  | 0.9 |  |  |  | 6.3 |  |
| Environmental liabilities (b) |  |  | 1.2 |  |  |  | — |  |  |  | 2.0 |  |  |  | — |  |
| Other items, net (b) |  |  | — |  |  |  | 0.6 |  |  |  | 0.3 |  |  |  | 0.9 |  |
| Losses and other expenses, net (pre-tax) |  | $ | 3.3 |  |  | $ | 6.4 |  |  | $ | 6.8 |  |  | $ | 9.3 |  |

[0001193125-15-028688:8k_2_02:96]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-028688:8k_2_02:97]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-15-028688:8k_2_02:98]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-15-028688:8k_2_02:99]
|  |  | For the YearEndedDecember 31,2015ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 5.20 - $5.60 |  |
| Restructuring and other items |  |  | 0.00 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 5.20 - $5.60 |  |

[0001193125-15-028688:8k_2_02:100]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars
in millions)

[0001193125-15-028688:8k_2_02:101]
|  |  | For the Three Months EndedDecember 31, |  |  | For the Years EndedDecember 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 161.3 |  |  | $ | 145.3 |  |  | $ | 184.8 |  |  | $ | 210.3 |  |
| Purchases of property, plant and equipment |  |  | (28.5 | ) |  |  | (37.3 | ) |  |  | (88.4 | ) |  |  | (78.3 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.9 |  |  |  | 2.3 |  |  |  | 1.1 |  |  |  | 2.4 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 133.7 |  |  | $ | 110.3 |  |  | $ | 97.5 |  |  | $ | 134.4 |  |

[0001193125-15-028688:8k_2_02:102]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelveMonths toDecember 31,2014 |  |
| Adjusted EBIT (a) |  | $ | 340.9 |  |
| Depreciation and amortization expense (b) |  |  | 60.8 |  |
| EBITDA (a + b) |  | $ | 401.7 |  |
| Total debt at December 31, 2014 (c) |  | $ | 925.6 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.3 |  |

[0001193125-15-028688:8k_2_02:103]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP
measure (dollars in millions)

[0001193125-15-028688:8k_2_02:104]
|  |  | TrailingTwelveMonths toDecember 31,2014 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 340.9 |  |
| Special product quality adjustments |  |  | (1.4 | ) |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 4.7 |  |
| Restructuring charges |  |  | 1.9 |  |
| Interest expense, net |  |  | 17.2 |  |
| Special inventory write down |  |  | 1.0 |  |
| Other expenses, net |  |  | (0.1 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 317.6 |  |
