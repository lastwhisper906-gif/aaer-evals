# LII notes — 0001069202-15-000003


## lii:DebtrepaymentsTableTextBlock

[0001069202-15-000003:notes:1]
18.3

[0001069202-15-000003:notes:2]
16.3

[0001069202-15-000003:notes:3]
16.6


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-15-000003:notes:4]
The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000003:notes:5]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 220.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-15-000003:notes:6]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000003:notes:7]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:ScheduleOfFairValueOfPerformanceShareUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-15-000003:notes:8]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-15-000003:notes:9]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Fair value of performance share units distributed | $ | 19.6 |  |  | $ | 9.9 |  |  | $ | 6.0 |  |
| Realized tax benefits from tax deductions | $ | 7.5 |  |  | $ | 3.8 |  |  | $ | 2.3 |  |


## lii:ScheduleOfFairValueOfRestrictedStockUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-15-000003:notes:10]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-15-000003:notes:11]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Fair value of restricted stock units vested | $ | 19.5 |  |  | $ | 11.1 |  |  | $ | 8.6 |  |
| Realized tax benefits from tax deductions | 7.4 |  |  | 4.3 |  |  | 3.3 |  |


## lii:ScheduleOfIntrinsicValueAndTaxBenefitsRelatedToStockAppreciationRightsTableTextBlock

[0001069202-15-000003:notes:12]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-15-000003:notes:13]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Intrinsic value of stock appreciation rights exercised | $ | 27.3 |  |  | $ | 16.7 |  |  | $ | 14.4 |  |
| Realized tax benefits from tax deductions | $ | 10.4 |  |  | $ | 6.4 |  |  | $ | 5.5 |  |


## lii:ScheduleOfShareBasedCompensationSharesAuthorizedUnderEquityInstrumentOtherThanOptionPlansByExercisePriceRangeTableTextBlock

[0001069202-15-000003:notes:14]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2014 (in millions, except per share data and years):

[0001069202-15-000003:notes:15]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $28.24 to $36.94 |  | 0.5 |  |  | 3.1 |  | $ | 33.2 |  |  | 0.5 |  |  | 3.1 |  | $ | 33.2 |  |
| $46.78 to $51.40 |  | 0.5 |  |  | 4.3 |  | $ | 22.3 |  |  | 0.4 |  |  | 4.1 |  | $ | 17.6 |  |
| $81.11 to $92.64 |  | 0.5 |  |  | 6.5 |  | $ | 4.1 |  |  | 0.1 |  |  | 6.0 |  | $ | 1.2 |  |


## lii:SummaryOfTargetAllocationPercentageOfAssetsTableTextBlock

[0001069202-15-000003:notes:16]
U.S. pension plan assets are invested within the following range targets:

[0001069202-15-000003:notes:17]
| Asset Category: | Target |
| U.S. equity | 25.0 | % |
| International equity | 17.0 | % |
| Fixed income | 56.0 | % |
| Money market/cash/guaranteed investment contracts | 2.0 | % |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-15-000003:notes:18]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-15-000003:notes:19]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Weighted average borrowing rate | 1.88 | % |  | 1.17 | % |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-15-000003:notes:20]
Accrued Expenses:

[0001069202-15-000003:notes:21]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-15-000003:notes:22]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Accrued compensation and benefits | $ | 73.3 |  |  | $ | 85.7 |  |
| Self insurance reserves | 13.0 |  |  | 13.4 |  |
| Deferred income | 11.6 |  |  | 9.8 |  |
| Accrued warranties | 27.3 |  |  | 28.7 |  |
| Accrued product quality reserves | 4.2 |  |  | 3.4 |  |
| Accrued Sales, Use and VAT taxes | 8.7 |  |  | 7.1 |  |
| Accrued rebates and promotions | 45.4 |  |  | 37.0 |  |
| Derivative contracts | 7.4 |  |  | 1.5 |  |
| Other | 48.1 |  |  | 45.5 |  |
| Total Accrued expenses | $ | 239.0 |  |  | $ | 232.1 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-15-000003:notes:23]
Supplemental Information:

[0001069202-15-000003:notes:24]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-15-000003:notes:25]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Research and development (1) | $ | 60.7 |  |  | $ | 53.7 |  |  | $ | 50.7 |  |
| Advertising, promotions and marketing (2) | 41.9 |  |  | 45.2 |  |  | 59.4 |  |
| Cooperative advertising expenditures (3) | 13.1 |  |  | 10.9 |  |  | 9.5 |  |
| Rent expense (4) | 50.5 |  |  | 53.5 |  |  | 67.8 |  |

[0001069202-15-000003:notes:26]
(1) Includes research and development costs related to discontinued operations of $1.2 million for the year ended December 31, 2012.  No research and development costs related to discontinued operations were recorded for the years ended December 31, 2014 and 2013 .

[0001069202-15-000003:notes:27]
(2) Includes advertising, promotions and marketing costs related to discontinued operations of $4.1 million and $20.1 million for the years ended December 31, 2013 and 2012, respectively.  No advertising costs related to discontinued operations were recorded for the year ended December 31, 2014.  Cooperative advertising expenditures were not included in these amounts.

[0001069202-15-000003:notes:28]
(3) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-15-000003:notes:29]
(4) Includes rent expense related to discontinued operations of $4.5 million and $20.1 million for the years ended December 31, 2013 and 2012, respectively.  No rent costs related to discontinued operations were recorded for the year ended December 31, 2014.

[0001069202-15-000003:notes:30]
Interest Expense, net

[0001069202-15-000003:notes:31]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-15-000003:notes:32]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Interest expense, net of capitalized interest | $ | 18.9 |  |  | $ | 16.5 |  |  | $ | 18.9 |  |
| Interest income | 1.7 |  |  | 2.0 |  |  | 1.8 |  |
| Interest expense, net | $ | 17.2 |  |  | $ | 14.5 |  |  | $ | 17.1 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-15-000003:notes:33]
Cash and Cash Equivalents

[0001069202-15-000003:notes:34]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-15-000003:notes:35]
Commitments and Contingencies:

[0001069202-15-000003:notes:36]
Leases

[0001069202-15-000003:notes:37]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-15-000003:notes:38]
Future annual minimum lease payments and capital lease commitments as of December 31, 2014 were as follows (in millions):

[0001069202-15-000003:notes:39]
|  | Operating Leases |  | Capital Leases |
| 2015 | $ | 37.8 |  |  | $ | 1.5 |  |
| 2016 | 29.4 |  |  | 0.8 |  |
| 2017 | 24.0 |  |  | 0.5 |  |
| 2018 | 18.5 |  |  | 0.3 |  |
| 2019 | 12.1 |  |  | 0.1 |  |
| Thereafter | 19.7 |  |  | 14.3 |  |
| Total minimum lease payments | $ | 141.5 |  |  | 17.5 |  |
| Less amount representing interest |  |  | (0.5 | ) |
| Present value of minimum payments |  |  | $ | 17.0 |  |

[0001069202-15-000003:notes:40]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-15-000003:notes:41]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Fifth Amended and Restated Credit Facility Agreement.  We were in compliance with these financial covenants as of December 31, 2014.

[0001069202-15-000003:notes:42]
Environmental

[0001069202-15-000003:notes:43]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities, however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000003:notes:44]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Accrued expenses | $ | 1.7 |  |  | $ | 1.4 |  |
| Other liabilities | 4.5 |  |  | 3.8 |  |
| Total environmental accruals | $ | 6.2 |  |  | $ | 5.2 |  |

[0001069202-15-000003:notes:45]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-15-000003:notes:46]
Product Warranties and Product Related Contingencies

[0001069202-15-000003:notes:47]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-15-000003:notes:48]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000003:notes:49]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Accrued expenses | $ | 27.3 |  |  | $ | 28.7 |  |
| Other liabilities | 59.9 |  |  | 52.9 |  |
| Total product warranty liabilities | $ | 87.2 |  |  | $ | 81.6 |  |

[0001069202-15-000003:notes:50]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2014 and 2013 were as follows (in millions):

[0001069202-15-000003:notes:51]
| Total warranty liability as of December 31, 2012 | $ | 71.9 |  |
| Payments made in 2013 | (21.3 | ) |
| Changes resulting from issuance of new warranties | 29.6 |  |
| Changes in estimates associated with pre-existing liabilities | 1.6 |  |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Payments made in 2014 | (23.1 | ) |
| Changes resulting from issuance of new warranties | 33.4 |  |
| Changes in estimates associated with pre-existing liabilities | (3.5 | ) |
| Changes in foreign currency translation rates and other | (1.2 | ) |
| Total warranty liability as of December 31, 2014 | $ | 87.2 |  |

[0001069202-15-000003:notes:52]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties.   Also, to satisfy our customers and protect our brands,  we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.   We currently estimate our probable liability for a supplier quality issue within a range of $2.2 million and $6 million; accordingly, we accrued, as of December 31, 2014, a $2.2 million liability in Accrued Expenses on the Consolidated Balance Sheet because all amounts in that range were equally likely. The supplier has agreed to reimburse our costs related to this liability; accordingly, we also recorded, as of December 31, 2014, a receivable of $2.2 million in Other Assets on the Consolidated Balance Sheet.  If additional costs are incurred, we expect the supplier will also reimburse those costs. The $2.2 million accrual is not included in the estimated warranty liabilities tables immediately above.

[0001069202-15-000003:notes:53]
Self Insurance

[0001069202-15-000003:notes:54]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and certain other insurance programs.    For directors' and officers' liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-15-000003:notes:55]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-15-000003:notes:56]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000003:notes:57]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Accrued expenses | $ | 13.0 |  |  | $ | 13.4 |  |
| Other liabilities | 25.8 |  |  | 32.0 |  |
| Total self-insurance liabilities | $ | 38.8 |  |  | $ | 45.4 |  |

[0001069202-15-000003:notes:58]
Litigation

[0001069202-15-000003:notes:59]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-15-000003:notes:60]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the years ended December 31, 2014 and 2013, we recorded expense of $0.9 million and $6.3 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation.

[0001069202-15-000003:notes:61]
We are the defendant in an attempted class action lawsuit which alleges that evaporator coils in our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks, and asserts claims for relief.  We dispute the allegations in the lawsuit.  The outcome related to this action is uncertain but we do not expect this lawsuit to have a material adverse effect on our financial condition or results of operations.

[0001069202-15-000003:notes:62]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-15-000003:notes:63]
Comprehensive Income:

[0001069202-15-000003:notes:64]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-15-000003:notes:65]
|  |  | For the Years Ended December 31, |  |  |
| AOCI Component |  | 2014 |  | 2013 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Losses on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | (5.8 | ) |  | $ | (4.2 | ) |  | Cost of goods sold |
| Income tax benefit |  | 2.0 |  |  | 1.5 |  |  | Provision for income taxes |
| Net of tax |  | $ | (3.8 | ) |  | $ | (2.7 | ) |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (6.9 | ) |  | $ | (9.5 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 2.4 |  |  | 3.4 |  |  | Provision for income taxes |
| Net of tax |  | $ | (4.5 | ) |  | $ | (6.1 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Sale of foreign business (1) |  | $ | — |  |  | $ | 41.1 |  |  | Loss from discontinued operations |
| Total reclassifications from AOCI |  | $ | (8.3 | ) |  | $ | 32.3 |  |  |  |

[0001069202-15-000003:notes:66]
(1) The reclassification of foreign currency translation adjustments related to the sale of the Service Experts business in the first quarter of 2013.  Refer to Note 17 for details.

[0001069202-15-000003:notes:67]
The following tables provide information on changes in AOCI, by component (net of tax), for the years ended December 31, 2014 and 2013 (in millions):

[0001069202-15-000003:notes:68]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | (7.8 | ) |  | 0.7 |  |  | (47.9 | ) |  | (45.7 | ) |  | (100.7 | ) |
| Amounts reclassified from AOCI |  | 3.8 |  |  | — |  |  | 4.5 |  |  | — |  |  | 8.3 |  |
| Net other comprehensive (loss) income |  | (4.0 | ) |  | 0.7 |  |  | (43.4 | ) |  | (45.7 | ) |  | (92.4 | ) |
| Balance as of December 31, 2014 |  | $ | (4.6 | ) |  | $ | 3.2 |  |  | $ | (149.4 | ) |  | $ | (2.7 | ) |  | $ | (153.5 | ) |

[0001069202-15-000003:notes:69]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2012 |  | $ | 1.1 |  |  | $ | 9.3 |  |  | $ | (147.5 | ) |  | $ | 114.8 |  |  | $ | (22.3 | ) |
| Other comprehensive (loss) income before reclassifications |  | (4.4 | ) |  | (6.8 | ) |  | 35.4 |  |  | (30.7 | ) |  | (6.5 | ) |
| Amounts reclassified from AOCI |  | 2.7 |  |  | — |  |  | 6.1 |  |  | (41.1 | ) |  | (32.3 | ) |
| Net other comprehensive (loss) income |  | (1.7 | ) |  | (6.8 | ) |  | 41.5 |  |  | (71.8 | ) |  | (38.8 | ) |
| Balance as of December 31, 2013 |  | $ | (0.6 | ) |  | $ | 2.5 |  |  | $ | (106.0 | ) |  | $ | 43.0 |  |  | $ | (61.1 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-15-000003:notes:70]
Condensed Consolidating Financial Statements:

[0001069202-15-000003:notes:71]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-15-000003:notes:72]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-15-000003:notes:73]
On March 22, 2013, the Company sold its Service Experts business to a majority-owned entity of American Capital, Ltd.  The primary subsidiary for the U.S. Service Experts business had previously been included as a "Guarantor Subsidiary" and the Canada Service Experts subsidiary had previously been included as a "Non-Guarantor Subsidiary."  As of December 31, 2014, the U.S. and Canada Service Experts businesses were included in discontinued operations of the condensed consolidating financial statements.

[0001069202-15-000003:notes:74]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-15-000003:notes:75]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2014 and December 31, 2013 and for the years ended December 31, 2014, 2013 and 2012 are shown on the following pages.

[0001069202-15-000003:notes:76]
Condensed Consolidating Balance Sheets

[0001069202-15-000003:notes:77]
As of December 31, 2014

[0001069202-15-000003:notes:78]
(In millions)

[0001069202-15-000003:notes:79]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |
| Accounts and notes receivable, net | — |  |  | 12.3 |  |  | 409.1 |  |  | — |  |  | 421.4 |  |
| Inventories, net | — |  |  | 350.6 |  |  | 119.7 |  |  | (7.0 | ) |  | 463.3 |  |
| Deferred income taxes, net | 2.8 |  |  | 27.3 |  |  | 7.4 |  |  | (5.0 | ) |  | 32.5 |  |
| Other assets | 3.6 |  |  | 45.7 |  |  | 67.2 |  |  | (57.2 | ) |  | 59.3 |  |
| Total current assets | 7.4 |  |  | 447.4 |  |  | 628.4 |  |  | (69.2 | ) |  | 1,014.0 |  |
| Property, plant and equipment, net | — |  |  | 269.0 |  |  | 89.6 |  |  | — |  |  | 358.6 |  |
| Goodwill | — |  |  | 140.4 |  |  | 69.0 |  |  | — |  |  | 209.4 |  |
| Investment in subsidiaries | 978.1 |  |  | 263.5 |  |  | (0.6 | ) |  | (1,241.0 | ) |  | — |  |
| Deferred income taxes | 0.5 |  |  | 90.8 |  |  | 15.8 |  |  | (9.6 | ) |  | 97.5 |  |
| Other assets, net | 5.2 |  |  | 61.0 |  |  | 20.1 |  |  | (1.5 | ) |  | 84.8 |  |
| Intercompany receivables (payables), net | (280.4 | ) |  | 302.4 |  |  | (22.0 | ) |  | — |  |  | — |  |
| Total assets | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 226.6 |  |  | $ | — |  |  | $ | 226.6 |  |
| Current maturities of long-term debt | 22.5 |  |  | 1.2 |  |  | 0.3 |  |  | — |  |  | 24.0 |  |
| Accounts payable | 13.4 |  |  | 237.8 |  |  | 73.1 |  |  | — |  |  | 324.3 |  |
| Accrued expenses | 9.0 |  |  | 175.5 |  |  | 54.5 |  |  | — |  |  | 239.0 |  |
| Income taxes payable | (3.7 | ) |  | 34.7 |  |  | 47.5 |  |  | (65.1 | ) |  | 13.4 |  |
| Total current liabilities | 41.2 |  |  | 449.2 |  |  | 402.0 |  |  | (65.1 | ) |  | 827.3 |  |
| Long-term debt | 659.5 |  |  | 15.3 |  |  | 0.2 |  |  | — |  |  | 675.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.5 |  |  | — |  |  | — |  |  | 4.5 |  |
| Pensions | — |  |  | 117.6 |  |  | 12.3 |  |  | — |  |  | 129.9 |  |
| Other liabilities | 1.1 |  |  | 118.7 |  |  | 11.7 |  |  | (12.9 | ) |  | 118.6 |  |
| Total liabilities | 701.8 |  |  | 705.3 |  |  | 426.2 |  |  | (78.0 | ) |  | 1,755.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 9.0 |  |  | 869.2 |  |  | 374.1 |  |  | (1,243.3 | ) |  | 9.0 |  |
| Total liabilities and stockholders' equity | $ | 710.8 |  |  | $ | 1,574.5 |  |  | $ | 800.3 |  |  | $ | (1,321.3 | ) |  | $ | 1,764.3 |  |

[0001069202-15-000003:notes:80]
As of December 31, 2013

[0001069202-15-000003:notes:81]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net | — |  |  | 12.8 |  |  | 395.3 |  |  | — |  |  | 408.1 |  |
| Inventories, net | — |  |  | 253.6 |  |  | 128.4 |  |  | (3.2 | ) |  | 378.8 |  |
| Deferred income taxes, net | 0.9 |  |  | 21.2 |  |  | 5.7 |  |  | (3.3 | ) |  | 24.5 |  |
| Other assets | 3.4 |  |  | 38.4 |  |  | 70.2 |  |  | (59.0 | ) |  | 53.0 |  |
| Total current assets | 5.4 |  |  | 336.5 |  |  | 626.0 |  |  | (65.5 | ) |  | 902.4 |  |
| Property, plant and equipment, net | — |  |  | 246.4 |  |  | 89.1 |  |  | — |  |  | 335.5 |  |
| Goodwill | — |  |  | 140.4 |  |  | 76.4 |  |  | — |  |  | 216.8 |  |
| Investment in subsidiaries | 1,138.8 |  |  | 337.5 |  |  | (0.6 | ) |  | (1,475.7 | ) |  | — |  |
| Deferred income taxes | — |  |  | 76.9 |  |  | 20.2 |  |  | (8.6 | ) |  | 88.5 |  |
| Other assets, net | 4.2 |  |  | 64.3 |  |  | 16.4 |  |  | (1.4 | ) |  | 83.5 |  |
| Intercompany receivables (payables), net | (460.6 | ) |  | 434.0 |  |  | 26.6 |  |  | — |  |  | — |  |
| Total assets | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 165.9 |  |  | $ | — |  |  | $ | 165.9 |  |
| Current maturities of long-term debt | — |  |  | 1.0 |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Accounts payable | 11.8 |  |  | 187.8 |  |  | 83.5 |  |  | — |  |  | 283.1 |  |
| Accrued expenses | 3.3 |  |  | 168.4 |  |  | 60.4 |  |  | — |  |  | 232.1 |  |
| Income taxes payable | (30.3 | ) |  | 75.7 |  |  | 49.9 |  |  | (63.7 | ) |  | 31.6 |  |
| Total current liabilities | (15.2 | ) |  | 432.9 |  |  | 360.0 |  |  | (63.7 | ) |  | 714.0 |  |
| Long-term debt | 217.0 |  |  | 15.8 |  |  | 0.4 |  |  | — |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions | — |  |  | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| Pensions | — |  |  | 58.4 |  |  | 11.6 |  |  | — |  |  | 70.0 |  |
| Other liabilities | 0.3 |  |  | 119.4 |  |  | 11.3 |  |  | (11.8 | ) |  | 119.2 |  |
| Total liabilities | 202.1 |  |  | 631.1 |  |  | 383.3 |  |  | (75.5 | ) |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 485.7 |  |  | 1,004.9 |  |  | 470.8 |  |  | (1,475.7 | ) |  | 485.7 |  |
| Total liabilities and stockholders' equity | $ | 687.8 |  |  | $ | 1,636.0 |  |  | $ | 854.1 |  |  | $ | (1,551.2 | ) |  | $ | 1,626.7 |  |

[0001069202-15-000003:notes:82]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-15-000003:notes:83]
For the Year Ended December 31, 2014

[0001069202-15-000003:notes:84]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,775.7 |  |  | $ | 818.0 |  |  | $ | (226.3 | ) |  | $ | 3,367.4 |  |
| Cost of goods sold | — |  |  | 2,057.8 |  |  | 628.3 |  |  | (222.0 | ) |  | 2,464.1 |  |
| Gross profit | — |  |  | 717.9 |  |  | 189.7 |  |  | (4.3 | ) |  | 903.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 454.5 |  |  | 119.2 |  |  | — |  |  | 573.7 |  |
| Losses and other expenses, net | — |  |  | 3.2 |  |  | 3.6 |  |  | — |  |  | 6.8 |  |
| Restructuring charges | — |  |  | 0.4 |  |  | 1.5 |  |  | — |  |  | 1.9 |  |
| Income from equity method investments | (216.4 | ) |  | (25.4 | ) |  | (11.3 | ) |  | 239.3 |  |  | (13.8 | ) |
| Operational income from continuing operations | 216.4 |  |  | 285.2 |  |  | 76.7 |  |  | (243.6 | ) |  | 334.7 |  |
| Interest expense, net | 16.0 |  |  | (3.0 | ) |  | 4.2 |  |  | — |  |  | 17.2 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 200.4 |  |  | 288.2 |  |  | 72.6 |  |  | (243.6 | ) |  | 317.6 |  |
| Provision for income taxes | (5.6 | ) |  | 91.7 |  |  | 24.9 |  |  | (1.5 | ) |  | 109.5 |  |
| Income from continuing operations | 206.0 |  |  | 196.5 |  |  | 47.7 |  |  | (242.1 | ) |  | 208.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (2.3 | ) |  | — |  |  | (2.3 | ) |
| Net income | $ | 206.0 |  |  | $ | 196.5 |  |  | $ | 45.4 |  |  | $ | (242.1 | ) |  | $ | 205.8 |  |
| Other comprehensive loss | $ | (4.1 | ) |  | $ | (51.2 | ) |  | $ | (34.8 | ) |  | $ | (2.3 | ) |  | $ | (92.4 | ) |
| Comprehensive Income | $ | 201.9 |  |  | $ | 145.3 |  |  | $ | 10.6 |  |  | $ | (244.4 | ) |  | $ | 113.4 |  |

[0001069202-15-000003:notes:85]
For the Year Ended December 31, 2013

[0001069202-15-000003:notes:86]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 2,557.9 |  |  | $ | 837.0 |  |  | $ | (195.8 | ) |  | $ | 3,199.1 |  |
| Cost of goods sold | — |  |  | 1,900.9 |  |  | 632.8 |  |  | (195.8 | ) |  | 2,337.9 |  |
| Gross profit | — |  |  | 657.0 |  |  | 204.2 |  |  | — |  |  | 861.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 437.1 |  |  | 133.0 |  |  | — |  |  | 570.1 |  |
| Losses and other expenses, net | 1.1 |  |  | 7.9 |  |  | 0.3 |  |  | — |  |  | 9.3 |  |
| Restructuring charges | — |  |  | 2.9 |  |  | 2.1 |  |  | — |  |  | 5.0 |  |
| Income from equity method investments | (181.7 | ) |  | (26.4 | ) |  | (9.7 | ) |  | 205.6 |  |  | (12.2 | ) |
| Operational income from continuing operations | 180.6 |  |  | 235.5 |  |  | 78.5 |  |  | (205.6 | ) |  | 289.0 |  |
| Interest expense, net | 14.0 |  |  | (2.1 | ) |  | 2.6 |  |  | — |  |  | 14.5 |  |
| Other expense, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Income from continuing operations before income taxes | 166.6 |  |  | 237.6 |  |  | 75.7 |  |  | (205.6 | ) |  | 274.3 |  |
| Provision for income taxes | (5.2 | ) |  | 73.7 |  |  | 25.9 |  |  | — |  |  | 94.4 |  |
| Income from continuing operations | 171.8 |  |  | 163.9 |  |  | 49.8 |  |  | (205.6 | ) |  | 179.9 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (8.1 | ) |  | — |  |  | (8.1 | ) |
| Net income | $ | 171.8 |  |  | $ | 163.9 |  |  | $ | 41.7 |  |  | $ | (205.6 | ) |  | $ | 171.8 |  |
| Other comprehensive loss | $ | (38.8 | ) |  | $ | 36.3 |  |  | $ | (6.1 | ) |  | $ | (30.2 | ) |  | $ | (38.8 | ) |
| Comprehensive income | $ | 133.0 |  |  | $ | 200.2 |  |  | $ | 35.6 |  |  | $ | (235.8 | ) |  | $ | 133.0 |  |

[0001069202-15-000003:notes:87]
For the Year Ended December 31, 2012

[0001069202-15-000003:notes:88]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,327.7 |  |  | $ | 824.0 |  |  | $ | (202.3 | ) |  | $ | 2,949.4 |  |
| Cost of goods sold | 0.2 |  |  | 1,799.6 |  |  | 629.2 |  |  | (201.9 | ) |  | 2,227.1 |  |
| Gross profit | (0.2 | ) |  | 528.1 |  |  | 194.8 |  |  | (0.4 | ) |  | 722.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 374.3 |  |  | 132.7 |  |  | — |  |  | 507.0 |  |
| Losses and other expenses, net | (1.7 | ) |  | 1.1 |  |  | 3.2 |  |  | (0.1 | ) |  | 2.5 |  |
| Restructuring charges | — |  |  | 2.8 |  |  | 1.4 |  |  | — |  |  | 4.2 |  |
| Income from equity method investments | (116.3 | ) |  | (17.0 | ) |  | (7.8 | ) |  | 130.6 |  |  | (10.5 | ) |
| Operational income from continuing operations | 117.8 |  |  | 166.9 |  |  | 65.3 |  |  | (130.9 | ) |  | 219.1 |  |
| Interest expense, net | 16.6 |  |  | (2.4 | ) |  | 2.9 |  |  | — |  |  | 17.1 |  |
| Other expense, net | — |  |  | — |  |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Income from continuing operations before income taxes | 101.2 |  |  | 169.3 |  |  | 62.1 |  |  | (130.9 | ) |  | 201.7 |  |
| Provision for income taxes | (4.9 | ) |  | 50.5 |  |  | 21.2 |  |  | (0.1 | ) |  | 66.7 |  |
| Income from continuing operations | 106.1 |  |  | 118.8 |  |  | 40.9 |  |  | (130.8 | ) |  | 135.0 |  |
| Loss from discontinued operations | — |  |  | (18.5 | ) |  | (26.5 | ) |  | — |  |  | (45.0 | ) |
| Net income | $ | 106.1 |  |  | $ | 100.3 |  |  | $ | 14.4 |  |  | $ | (130.8 | ) |  | $ | 90.0 |  |
| Other comprehensive income | $ | 6.7 |  |  | $ | (2.8 | ) |  | $ | 5.2 |  |  | $ | 5.7 |  |  | $ | 14.8 |  |
| Comprehensive Income | $ | 112.8 |  |  | $ | 97.5 |  |  | $ | 19.6 |  |  | $ | (125.1 | ) |  | $ | 104.8 |  |

[0001069202-15-000003:notes:89]
Condensed Consolidating Statements of Cash Flows

[0001069202-15-000003:notes:90]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 328.8 |  |  | $ | (97.2 | ) |  | $ | (46.8 | ) |  | $ | — |  |  | $ | 184.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 1.0 |  |  | 0.1 |  |  | — |  |  | 1.1 |  |
| Purchases of property, plant and equipment | — |  |  | (70.5 | ) |  | (17.9 | ) |  | — |  |  | (88.4 | ) |
| Net cash used in investing activities | — |  |  | (69.5 | ) |  | (17.8 | ) |  | — |  |  | (87.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 100.0 |  |  | — |  |  | 100.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (40.0 | ) |  | — |  |  | (40.0 | ) |
| Term loan borrowings from credit facility | 300.0 |  |  | — |  |  | — |  |  | — |  |  | 300.0 |  |
| Long-term debt payments | — |  |  | (1.9 | ) |  | (0.4 | ) |  | — |  |  | (2.3 | ) |
| Borrowings from credit facility | 2,073.5 |  |  | — |  |  | — |  |  | — |  |  | 2,073.5 |  |
| Payments on credit facility | (1,908.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,908.5 | ) |
| Payments of deferred financing costs | (2.2 | ) |  | — |  |  | — |  |  | — |  |  | (2.2 | ) |
| Proceeds from employee stock purchases | 2.0 |  |  | — |  |  | — |  |  | — |  |  | 2.0 |  |
| Repurchases of common stock | (550.3 | ) |  | — |  |  | — |  |  | — |  |  | (550.3 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (22.4 | ) |  | — |  |  | — |  |  | — |  |  | (22.4 | ) |
| Excess tax benefits related to share-based payments | 11.8 |  |  | — |  |  | — |  |  | — |  |  | 11.8 |  |
| Intercompany debt | (0.1 | ) |  | 4.7 |  |  | (4.6 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (180.1 | ) |  | 164.9 |  |  | 15.2 |  |  | — |  |  | — |  |
| Cash dividends paid | (52.6 | ) |  | — |  |  | — |  |  | — |  |  | (52.6 | ) |
| Net cash provided by (used in) financing activities | (328.9 | ) |  | 167.7 |  |  | 71.7 |  |  | — |  |  | (89.5 | ) |
| Increase (decrease) in cash and cash equivalents | (0.1 | ) |  | 1.0 |  |  | 7.1 |  |  | — |  |  | 8.0 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (8.5 | ) |  | — |  |  | (8.5 | ) |
| Cash and cash equivalents, beginning of year | 1.1 |  |  | 10.5 |  |  | 26.4 |  |  | — |  |  | 38.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 11.5 |  |  | $ | 25.0 |  |  | $ | — |  |  | $ | 37.5 |  |

[0001069202-15-000003:notes:91]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | (30.4 | ) |  | $ | 328.4 |  |  | $ | (87.7 | ) |  | $ | — |  |  | $ | 210.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 2.4 |  |  | — |  |  | — |  |  | 2.4 |  |
| Purchases of property, plant and equipment | — |  |  | (55.8 | ) |  | (22.5 | ) |  | — |  |  | (78.3 | ) |
| Net Proceeds from sale of business | 5.3 |  |  | — |  |  | 3.3 |  |  | — |  |  | 8.6 |  |
| Net cash used in investing activities | 5.3 |  |  | (53.4 | ) |  | (19.2 | ) |  | — |  |  | (67.3 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 330.0 |  |  | — |  |  | 330.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (200.0 | ) |  | — |  |  | (200.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.3 | ) |  | — |  |  | (1.0 | ) |
| Borrowings from revolving credit facility | 1,425.5 |  |  | — |  |  | — |  |  | — |  |  | 1,425.5 |  |
| Payments on revolving credit facility | (1,543.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,543.5 | ) |
| Proceeds from employee stock purchases | 1.8 |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |
| Additional investment in subsidiary | — |  |  | — |  |  | (0.5 | ) |  | — |  |  | (0.5 | ) |
| Repurchases of common stock | (125.0 | ) |  | — |  |  | — |  |  | — |  |  | (125.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (12.0 | ) |  | — |  |  | — |  |  | — |  |  | (12.0 | ) |
| Excess tax benefits related to share-based payments | 6.5 |  |  | — |  |  | — |  |  | — |  |  | 6.5 |  |
| Intercompany debt | (26.8 | ) |  | 12.3 |  |  | 14.5 |  |  | — |  |  | — |  |
| Intercompany financing activity | 332.7 |  |  | (289.5 | ) |  | (43.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (34.0 | ) |  | — |  |  | — |  |  | — |  |  | (34.0 | ) |
| Net cash provided by (used in) financing activities | 25.2 |  |  | (277.9 | ) |  | 102.5 |  |  | — |  |  | (150.2 | ) |
| Decrease in cash and cash equivalents | 0.1 |  |  | (2.9 | ) |  | (4.4 | ) |  | — |  |  | (7.2 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (6.6 | ) |  | — |  |  | (6.6 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 13.4 |  |  | 37.4 |  |  | — |  |  | 51.8 |  |
| Cash and cash equivalents, end of year | $ | 1.1 |  |  | $ | 10.5 |  |  | $ | 26.4 |  |  | $ | — |  |  | $ | 38.0 |  |

[0001069202-15-000003:notes:92]
|  | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 20.7 |  |  | $ | 207.3 |  |  | $ | (6.6 | ) |  | $ | — |  |  | $ | 221.4 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (37.7 | ) |  | (12.5 | ) |  | — |  |  | (50.2 | ) |
| Net proceeds from sale of business | — |  |  | 10.1 |  |  | — |  |  | — |  |  | 10.1 |  |
| Net cash used in discontinued operations | — |  |  | (0.5 | ) |  | 0.1 |  |  | — |  |  | (0.4 | ) |
| Net cash used in investing activities | — |  |  | (28.0 | ) |  | (12.4 | ) |  | — |  |  | (40.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 645.0 |  |  | — |  |  | 645.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (615.0 | ) |  | — |  |  | (615.0 | ) |
| Long-term debt payments | — |  |  | (0.7 | ) |  | (0.4 | ) |  | — |  |  | (1.1 | ) |
| Borrowings from revolving credit facility | 967.0 |  |  | — |  |  | — |  |  | — |  |  | 967.0 |  |
| Payments on revolving credit facility | (1,075.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,075.0 | ) |
| Proceeds from stock option exercises | 0.8 |  |  | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Repurchases of common stock | (50.1 | ) |  | — |  |  | — |  |  | — |  |  | (50.1 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (7.8 | ) |  | — |  |  | — |  |  | — |  |  | (7.8 | ) |
| Excess tax benefits related to share-based payments | 3.5 |  |  | — |  |  | — |  |  | — |  |  | 3.5 |  |
| Intercompany debt | 2.4 |  |  | (4.0 | ) |  | 1.6 |  |  | — |  |  | — |  |
| Intercompany financing activity | 186.1 |  |  | (170.9 | ) |  | (15.2 | ) |  | — |  |  | — |  |
| Cash dividends paid | (47.6 | ) |  | — |  |  | — |  |  | — |  |  | (47.6 | ) |
| Net cash provided by (used in) financing activities | (20.7 | ) |  | (175.6 | ) |  | 16.2 |  |  | — |  |  | (180.1 | ) |
| Increase (decrease) in cash and cash equivalents | — |  |  | 3.7 |  |  | (2.8 | ) |  | — |  |  | 0.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 9.7 |  |  | 34.3 |  |  | — |  |  | 45.0 |  |
| Cash and cash equivalents, end of year | $ | 1.0 |  |  | $ | 13.4 |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 51.8 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-15-000003:notes:93]
Principles of Consolidation

[0001069202-15-000003:notes:94]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-15-000003:notes:95]
Cost of Goods Sold

[0001069202-15-000003:notes:96]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-15-000003:notes:97]
Lines of Credit and Financing Arrangements:

[0001069202-15-000003:notes:98]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000003:notes:99]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 6.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 226.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.5 |  |  | $ | 1.3 |  |
| Domestic credit facility | $ | 22.5 |  |  | $ | — |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 15.5 |  |  | $ | 16.2 |  |
| Domestic credit facility | 459.5 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 675.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 925.6 |  |  | $ | 400.4 |  |

[0001069202-15-000003:notes:100]
As of December 31, 2014, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-15-000003:notes:101]
| 2015 | $ | 250.6 |  |
| 2016 | 31.2 |  |
| 2017 | 230.0 |  |
| 2018 | 32.6 |  |
| 2019 | 369.5 |  |
| Thereafter | 11.7 |  |

[0001069202-15-000003:notes:102]
Short-Term Debt

[0001069202-15-000003:notes:103]
Short Term Facility

[0001069202-15-000003:notes:104]
On October 20, 2014, Lennox International Inc. (the “Company”) entered into a short term loan agreement (the “Short-Term Facility”) with JPMorgan Chase Bank, N.A., as administrative agent, and Morgan Stanley Bank, N.A. and the other lenders named therein, to borrow $250.0 million. The Short-Term Facility had a maturity date of March 31, 2015, but was prepaid in full without penalty in November 2014. The term loan bore interest at a variable base rate or a variable rate based on the London interbank offered rate, at the Company’s election, plus a spread.

[0001069202-15-000003:notes:105]
Foreign Obligations

[0001069202-15-000003:notes:106]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $6.6 million and $5.9 million of foreign obligations as of December 31, 2014 and 2013, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $18.1 million, $18.3 million and $18.5 million during the years ended December 31, 2014, 2013 and 2012, respectively. Repayments on the facilities were $16.6 million, $16.3 million and $18.3 million during the years ended December 31, 2014, 2013 and 2012, respectively.

[0001069202-15-000003:notes:107]
Asset Securitization Program

[0001069202-15-000003:notes:108]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP is subject to annual renewal and contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-15-000003:notes:109]
In November 2014, we amended the ASP, extending its term to November 13, 2015 and increasing the maximum securitization amount from a range of $160.0 million to $220.0 million to a range of $180.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-15-000003:notes:110]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rates as of December 31, 2014 and 2013 were 0.79% and 0.78%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $180.0 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-15-000003:notes:111]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Fifth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2014, we were in compliance with all covenant requirements.

[0001069202-15-000003:notes:112]
Long-Term Debt

[0001069202-15-000003:notes:113]
Domestic Credit Facility

[0001069202-15-000003:notes:114]
On November 13, 2014, we replaced our $650 million Domestic Revolving Credit Facility with a $950 million Domestic Credit Facility, which consists of a $650 million revolving credit facility and a $300 million term loan and matures in November 2019.  Under our $950 million Domestic Credit Facility, we had outstanding borrowings of $482.0 million as well as 27.2 million committed to standby letters of credit as of December 31, 2014.  Subject to covenant limitations, $440.8 million was available for future borrowings. The unsecured $300 million term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning on June 30, 2015. The revolving credit facility allows up to $150 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-15-000003:notes:115]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-15-000003:notes:116]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Credit Facility could occur if:

[0001069202-15-000003:notes:117]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-15-000003:notes:118]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-15-000003:notes:119]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Credit Facility, our senior unsecured notes, the Lake Park Renewal or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-15-000003:notes:120]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2014, we were in compliance with all covenant requirements.

[0001069202-15-000003:notes:121]
Senior Unsecured Notes

[0001069202-15-000003:notes:122]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Credit Facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.   As of December 31, 2014, we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-15-000003:notes:123]
Derivatives:

[0001069202-15-000003:notes:124]
Objectives and Strategies for Using Derivative Instruments

[0001069202-15-000003:notes:125]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-15-000003:notes:126]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows.  Prior to 2013, we used an interest rate swap hedge to fix the interest payments associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility tied to changes in the benchmark interest rate. The variable portion of the interest rate swap was tied to the 1-Month LIBOR (the benchmark interest rate). On a monthly basis, the interest rates for both the interest rate swap and the underlying debt were reset, the swap was settled with the counterparty, and the interest was paid.  The interest rate swap was classified as a cash flow hedge and it expired on October 12, 2012. Subsequently, we have not hedged against interest rate risk.

[0001069202-15-000003:notes:127]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts. These forward contracts are not designated as hedges and generally expire during the quarter that we enter into them.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.

[0001069202-15-000003:notes:128]
Cash Flow Hedges

[0001069202-15-000003:notes:129]
We have commodity futures contracts designated as cash flows hedges that are scheduled to mature through June 2016.  Unrealized gains or losses from our cash flow hedges are included in accumulated other comprehensive income (“AOCI”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.

[0001069202-15-000003:notes:130]
We recorded the following amounts related to our cash flow hedges in AOCI (in millions):

[0001069202-15-000003:notes:131]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Unrealized losses on unsettled contracts | $ | 7.2 |  |  | $ | 0.8 |  |
| Income tax expense (benefit) | (2.6 | ) |  | (0.2 | ) |
| Losses included in AOCI, net of tax (1) | $ | 4.6 |  |  | $ | 0.6 |  |

[0001069202-15-000003:notes:132]
(1) Assuming commodity prices remain constant, we expect to reclassify $4.2 million of derivative losses into earnings within the next 12 months.

[0001069202-15-000003:notes:133]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-15-000003:notes:134]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Copper | 29.4 |  |  | 22.9 |  |

[0001069202-15-000003:notes:135]
Derivatives not Designated as Cash Flow Hedges

[0001069202-15-000003:notes:136]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had

[0001069202-15-000003:notes:137]
the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-15-000003:notes:138]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Copper | 2.9 |  |  | 2.0 |  |
| Aluminum | 2.2 |  |  | 2.7 |  |

[0001069202-15-000003:notes:139]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-15-000003:notes:140]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Notional amounts (in local currency): |  |  |  |
| Brazilian Real | 8.7 |  |  | 1.2 |  |
| Mexican Peso | 229.7 |  |  | 130.0 |  |
| United States Dollar | 4.5 |  |  | — |  |
| Euro | 3.6 |  |  | — |  |
| British Pound | — |  |  | 3.4 |  |
| Russian Ruble | 80.8 |  |  | — |  |
| Indian Rupee | — |  |  | 28.0 |  |
| Polish Zloty | 30.6 |  |  | 32.6 |  |

[0001069202-15-000003:notes:141]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-15-000003:notes:142]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-15-000003:notes:143]
|  | Fair Values of Derivative Instruments as of December 31 (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Current Assets: |  |  |  |  |  |  |  |
| Other assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | — |  |  | 0.3 |  |  | 0.1 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Total Assets | $ | — |  |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 6.7 |  |  | $ | 1.2 |  |  | $ | 0.7 |  |  | $ | 0.3 |  |
| Foreign currency forward contracts | — |  |  | — |  |  | — |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.5 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total Liabilities | $ | 7.2 |  |  | $ | 1.2 |  |  | $ | 0.8 |  |  | $ | 0.3 |  |

[0001069202-15-000003:notes:144]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 20 for more information on fair value measurements.

[0001069202-15-000003:notes:145]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Amount of Loss (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts (1) | $ | 5.8 |  |  | $ | 4.2 |  |  | $ | 6.0 |  |
| Interest rate swap (2) | — |  |  | — |  |  | 1.9 |  |
|  | $ | 5.8 |  |  | $ | 4.2 |  |  | $ | 7.9 |  |
| Amount of (Gain) Loss Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts (3) | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | (0.1 | ) |

[0001069202-15-000003:notes:146]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Amount of Loss (Gain) Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts (3) | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | (0.5 | ) |
| Foreign currency forward contracts (3) | (0.8 | ) |  | 0.1 |  |  | 0.4 |  |
|  | $ | 0.4 |  |  | $ | 1.3 |  |  | $ | (0.1 | ) |

[0001069202-15-000003:notes:147]
(1) The loss (gain) was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-15-000003:notes:148]
(2) The loss was recorded in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-15-000003:notes:149]
(3) The loss (gain) was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-15-000003:notes:150]
Derivatives

[0001069202-15-000003:notes:151]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 8 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-15-000003:notes:152]
Stock-Based Compensation:

[0001069202-15-000003:notes:153]
Stock-Based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-15-000003:notes:154]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Compensation expense(1) | $ | 23.3 |  |  | $ | 29.3 |  |  | $ | 15.2 |  |

[0001069202-15-000003:notes:155]
(1) Stock-Based compensation expense was recorded in our Corporate and other business segment.

[0001069202-15-000003:notes:156]
Incentive Plan

[0001069202-15-000003:notes:157]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-15-000003:notes:158]
As of December 31, 2014, awards for 20.5 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.8 million shares available for future issuance.

[0001069202-15-000003:notes:159]
Performance Share Units

[0001069202-15-000003:notes:160]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-15-000003:notes:161]
Performance share units are classified as equity awards.  Compensation expense is recognized ratably over the service period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-15-000003:notes:162]
The following table provides information on our performance share units:

[0001069202-15-000003:notes:163]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Compensation expense for performance share units (in millions) | $ | 11.5 |  |  | $ | 17.1 |  |  | $ | 5.7 |  |
| Weighted-average fair value of grants, per share | $ | 88.26 |  |  | $ | 78.00 |  |  | $ | 48.64 |  |
| Payout ratio for shares paid | 153.2 | % |  | 86.9 | % |  | 52.5 | % |

[0001069202-15-000003:notes:164]
A summary of the status of our undistributed performance share units as of December 31, 2014, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-15-000003:notes:165]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2013 | 0.7 |  |  | $ | 47.83 |  |
| Granted | 0.1 |  |  | 88.26 |  |
| Adjustments to shares paid based on payout ratio | 0.2 |  |  | 31.78 |  |
| Distributed | (0.2 | ) |  | 44.85 |  |
| Forfeited | — |  |  | — |  |
| Undistributed performance share units as of December 31, 2014 (1) | 0.8 |  |  | $ | 49.47 |  |

[0001069202-15-000003:notes:166]
(1) Undistributed performance share units include approximately 0.4 million units with a weighted-average grant date fair value of $68.27 per share that had not yet vested and 0.4 million units that have vested but were not yet distributed.

[0001069202-15-000003:notes:167]
As of December 31, 2014, we had $15.9 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.2 years. Our estimated forfeiture rate for these performance share units was 16.5% as of December 31, 2014.

[0001069202-15-000003:notes:168]
Restricted Stock Units

[0001069202-15-000003:notes:169]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-15-000003:notes:170]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-15-000003:notes:171]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Compensation expense for restricted stock units | $ | 7.0 |  |  | $ | 6.8 |  |  | $ | 5.0 |  |
| Weighted-average fair value of grants, per share | $ | 88.26 |  |  | $ | 77.26 |  |  | $ | 48.45 |  |

[0001069202-15-000003:notes:172]
A summary of our non-vested restricted stock units as of December 31, 2014 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-15-000003:notes:173]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2013 | 0.5 |  |  | $ | 48.83 |  |
| Granted | 0.1 |  |  | 88.26 |  |
| Distributed | (0.2 | ) |  | 32.42 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2014 | 0.4 |  |  | $ | 69.09 |  |

[0001069202-15-000003:notes:174]
As of December 31, 2014, we had $14.9 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.4 years.  Our estimated forfeiture rate for restricted stock units was 16.9% as of December 31, 2014.

[0001069202-15-000003:notes:175]
Stock Appreciation Rights

[0001069202-15-000003:notes:176]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive a value, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-15-000003:notes:177]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-15-000003:notes:178]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Compensation expense for stock appreciation rights | $ | 4.8 |  |  | $ | 5.4 |  |  | $ | 4.5 |  |
| Weighted-average fair value of grants, per share | 19.55 |  |  | 18.76 |  |  | 14.34 |  |

[0001069202-15-000003:notes:179]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-15-000003:notes:180]
The fair value of the stock appreciation rights granted in 2014, 2013 and 2012 were estimated on the date of grant using the following assumptions:

[0001069202-15-000003:notes:181]
|  | 2014 |  | 2013 |  | 2012 |
| Expected dividend yield | 1.75 | % |  | 1.36 | % |  | 1.75 | % |
| Risk-free interest rate | 1.27 | % |  | 1.12 | % |  | 0.48 | % |
| Expected volatility | 29.60 | % |  | 31.50 | % |  | 40.42 | % |
| Expected life (in years) | 4.04 |  |  | 4.02 |  |  | 4.14 |  |

[0001069202-15-000003:notes:182]
A summary of our stock appreciation rights as of December 31, 2014, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-15-000003:notes:183]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2013 | 1.8 |  |  | $ | 45.58 |  |
| Granted | 0.2 |  |  | 92.64 |  |
| Exercised | (0.5 | ) |  | 35.91 |  |
| Forfeited | — |  |  | — |  |
| Outstanding stock appreciation rights as of December 31, 2014 | 1.5 |  |  | $ | 56.20 |  |
| Exercisable stock appreciation rights as of December 31, 2014 | 1.0 |  |  | $ | 43.65 |  |

[0001069202-15-000003:notes:184]
As of December 31, 2014, we had $8.5 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 15.6% as of December 31, 2014.

[0001069202-15-000003:notes:185]
Employee Stock Purchase Plan

[0001069202-15-000003:notes:186]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 20,000 shares under the ESPP during the year ended December 31, 2014.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2014.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-15-000003:notes:187]
Discontinued Operations:

[0001069202-15-000003:notes:188]
On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. (the "Buyer") in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We also entered into a two-year equipment and parts supply agreement with the Buyer.  In April 2012, we sold our Hearth business to Comvest Investment Partners IV in an all-cash transaction for net proceeds of $10.1 million, excluding the transaction costs and cash transferred with the business.  The gains and losses on the sale of these businesses and their operating results for all periods are presented in discontinued operations.

[0001069202-15-000003:notes:189]
Service Experts

[0001069202-15-000003:notes:190]
A summary of net sales and pre-tax gains and losses for the Service Experts business is detailed below (in millions):

[0001069202-15-000003:notes:191]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net sales (1) | $ | — |  |  | $ | 73.5 |  |  | $ | 385.1 |  |
| Pre-tax operating income (loss) (1)(2) | 2.6 |  |  | (15.1 | ) |  | (50.8 | ) |
| Gain on sale of business | — |  |  | 1.4 |  |  | — |  |

[0001069202-15-000003:notes:192]
(1) Excludes eliminations of intercompany sales and any associated profit.

[0001069202-15-000003:notes:193]
(2) Pre-tax operating loss for the year ended December 31, 2012 included a $20.5 million goodwill impairment loss.

[0001069202-15-000003:notes:194]
There were no assets or liabilities related to the Service Experts business included in the accompanying Consolidated Balance Sheets as of December 31, 2014 or 2013.

[0001069202-15-000003:notes:195]
Hearth

[0001069202-15-000003:notes:196]
A summary of net sales and pre-tax gains and losses for the Hearth business is detailed below (in millions):

[0001069202-15-000003:notes:197]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net sales (1) | $ | — |  |  | $ | — |  |  | $ | 23.5 |  |
| Pre-tax operating income (loss) (1)(2) | (6.3 | ) |  | 0.5 |  |  | (13.7 | ) |
| Loss on sale of business | — |  |  | — |  |  | (0.9 | ) |

[0001069202-15-000003:notes:198]
(2) Pre-tax operating loss in 2012 included a $6.3 million pre-tax impairment charge for the write-down of net assets to their estimated fair value, a $6.3 million settlement charge related to actuarial losses recognized upon transition of a pension obligation to the acquirer of the Hearth business and a $3.5 million gain related to realized foreign currency translation adjustments.

[0001069202-15-000003:notes:199]
There were no assets or liabilities related to the Hearth business included in the accompanying Consolidated Balance Sheets as of December 31, 2014 or 2013.


## us-gaap:EarningsPerShareTextBlock

[0001069202-15-000003:notes:200]
Earnings Per Share:

[0001069202-15-000003:notes:201]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-15-000003:notes:202]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-15-000003:notes:203]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net income | $ | 205.8 |  |  | $ | 171.8 |  |  | $ | 90.0 |  |
| Add: Loss from discontinued operations | 2.3 |  |  | 8.1 |  |  | 45.0 |  |
| Income from continuing operations | $ | 208.1 |  |  | $ | 179.9 |  |  | $ | 135.0 |  |
| Weighted-average shares outstanding – basic | 47.9 |  |  | 49.8 |  |  | 50.7 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.7 |  |  | 0.8 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 48.6 |  |  | 50.6 |  |  | 51.4 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 4.35 |  |  | $ | 3.61 |  |  | $ | 2.66 |  |
| Loss from discontinued operations | (0.05 | ) |  | (0.16 | ) |  | (0.89 | ) |
| Net income | $ | 4.30 |  |  | $ | 3.45 |  |  | $ | 1.77 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 4.28 |  |  | $ | 3.55 |  |  | $ | 2.63 |  |
| Loss from discontinued operations | (0.05 | ) |  | (0.16 | ) |  | (0.88 | ) |
| Net income | $ | 4.23 |  |  | $ | 3.39 |  |  | $ | 1.75 |  |

[0001069202-15-000003:notes:204]
The following stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive (in millions, except for per share data):

[0001069202-15-000003:notes:205]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Weighted-average number of shares | 0.3 |  |  | 0.1 |  |  | 0.1 |  |
| Price ranges per share | $81.11 - $92.64 |  |  | $81.11 - $81.14 |  |  | $51.11 - $51.40 |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-15-000003:notes:206]
Joint Ventures and Other Equity Investments:

[0001069202-15-000003:notes:207]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-15-000003:notes:208]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-15-000003:notes:209]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Equity method investments | $ | 30.9 |  |  | $ | 28.0 |  |

[0001069202-15-000003:notes:210]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-15-000003:notes:211]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Purchases of compressors from joint venture | $ | 114.7 |  |  | $ | 96.7 |  |  | $ | 90.4 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-15-000003:notes:212]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-15-000003:notes:213]
|  | Fair Value Measurements as of December 31, 2014 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 5.8 |  |  | — |  |  | — |  |  | 5.8 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 78.0 |  |  | — |  |  | 78.0 |  |
| International equity (2) | — |  |  | 47.3 |  |  | — |  |  | 47.3 |  |
| Fixed income (3) | — |  |  | 145.4 |  |  | — |  |  | 145.4 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 14.2 |  |  | — |  |  | 14.2 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 11.4 |  |  | — |  |  | 11.4 |  |
| Fixed income (6) | — |  |  | 8.2 |  |  | — |  |  | 8.2 |  |
| Total | 5.8 |  |  | 309.2 |  |  | — |  |  | 315.0 |  |

[0001069202-15-000003:notes:214]
|  | Fair Value Measurements as of December 31, 2013 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 8.2 |  |  | — |  |  | — |  |  | 8.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 100.1 |  |  | — |  |  | 100.1 |  |
| International equity (2) | — |  |  | 70.8 |  |  | — |  |  | 70.8 |  |
| Fixed income (3) | — |  |  | 89.4 |  |  | — |  |  | 89.4 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 10.8 |  |  | — |  |  | 10.8 |  |
| Fixed income | — |  |  | 7.2 |  |  | — |  |  | 7.2 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 9.4 |  |  | — |  |  | 9.4 |  |
| Fixed income (6) | — |  |  | 6.9 |  |  | — |  |  | 6.9 |  |
| Total | 8.2 |  |  | 294.6 |  |  | — |  |  | 302.8 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-15-000003:notes:215]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-15-000003:notes:216]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 210.6 |  |  | $ | 214.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-15-000003:notes:217]
Fair Value Measurements:

[0001069202-15-000003:notes:218]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-15-000003:notes:219]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-15-000003:notes:220]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-15-000003:notes:221]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-15-000003:notes:222]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2014 and 2013, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2014 were the same as those used as of December 31, 2013.

[0001069202-15-000003:notes:223]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-15-000003:notes:224]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-15-000003:notes:225]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001069202-15-000003:notes:226]
Marketable Equity Securities

[0001069202-15-000003:notes:227]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-15-000003:notes:228]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | 5.3 |  |  | $ | 4.4 |  |

[0001069202-15-000003:notes:229]
Other Fair Value Disclosures

[0001069202-15-000003:notes:230]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-15-000003:notes:231]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-15-000003:notes:232]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-15-000003:notes:233]
|  | As of December 31, 2014 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 78.0 |  |  | Daily |  | 5 days |
| International equity (2) | 47.3 |  |  | Daily |  | 5 days |
| Fixed income (3) | 145.4 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 14.2 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 11.4 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 8.2 |  |  | Daily |  | 1-7 days |
| Total | $ | 309.2 |  |  |  |  |  |

[0001069202-15-000003:notes:234]
|  | As of December 31, 2013 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 100.1 |  |  | Daily |  | 5 days |
| International equity (2) | 70.8 |  |  | Daily |  | 5 days |
| Fixed income (3) | 89.4 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 10.8 |  |  | Daily |  | 3-5 days |
| Fixed income | 7.2 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 9.4 |  |  | Daily |  | 7 days |
| Fixed income (6) | 6.9 |  |  | Daily |  | 7 days |
| Total | $ | 294.6 |  |  |  |  |  |

[0001069202-15-000003:notes:235]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in international equities. |
| (5) | This category includes investments in international equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer and investment grade corporate bonds denominated in sterling. |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001069202-15-000003:notes:236]
Amortization expense related to these intangible and other assets was as follows (in millions):

[0001069202-15-000003:notes:237]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Amortization expense | $ | 3.9 |  |  | $ | 3.9 |  |  | $ | 3.8 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-15-000003:notes:238]
Translation of Foreign Currencies

[0001069202-15-000003:notes:239]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-15-000003:notes:240]
Goodwill and Intangible Assets:

[0001069202-15-000003:notes:241]
Goodwill

[0001069202-15-000003:notes:242]
The changes in the carrying amount of goodwill in 2014 and 2013, in total and by segment, are summarized in the table below (in millions):

[0001069202-15-000003:notes:243]
| Segment: | Balance at December 31, 2012 (2) |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at December 31, 2013 |  | Acquisitions / (Dispositions) |  | Other(1) |  | Balance at December 31, 2014 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 63.8 |  |  | — |  |  | 0.8 |  |  | 64.6 |  |  | — |  |  | (2.3 | ) |  | 62.3 |  |
| Refrigeration | 133.9 |  |  | — |  |  | (7.8 | ) |  | 126.1 |  |  | — |  |  | (5.1 | ) |  | 121.0 |  |
|  | $ | 223.8 |  |  | $ | — |  |  | $ | (7.0 | ) |  | $ | 216.8 |  |  | $ | — |  |  | $ | (7.4 | ) |  | $ | 209.4 |  |

[0001069202-15-000003:notes:244]
(1) Other consists of changes in foreign currency translation rates.

[0001069202-15-000003:notes:245]
(2) The goodwill balances in the table above are presented net of accumulated impairment charges of $15.7 million, all of which relate to impairments in periods prior to 2012.

[0001069202-15-000003:notes:246]
We reviewed our reporting unit structure as part of our annual goodwill impairment testing.  We identified several components one level below our operating segments which were determined to be reporting units.  We then performed our analysis to determine the proper aggregation of our reporting units, which considered similar economic and other characteristics, including product types, gross profits, production processes, customer types, distribution processes, and regulatory environments.  Our analysis incorporated qualitative and quantitative measures to evaluate economic similarity  and concluded that our reporting units continue to be equivalent to our operating segments.

[0001069202-15-000003:notes:247]
A qualitative review of impairment indicators was performed in 2014 for the Residential Heating & Cooling and the Commercial Heating & Cooling segments, and we determined that it was not more likely than not the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, a quantitative impairment analysis was not performed for these segments.  Due to the softening of the North American supermarket and Australian wholesale businesses, a quantitative impairment analysis was performed for the Refrigeration segment using the discounted cash flow approach.  The Refrigeration segment was not at risk of failing step one of the quantitative impairment test, and no impairments were recognized as part of the annual test. No other indicators of impairment were identified from the date of our annual impairment test through December 31, 2014.  Also, we did not record any goodwill impairments related to continuing operations in 2012 or 2013.  Refer to Note 17 for information on goodwill related to discontinued operations.

[0001069202-15-000003:notes:248]
Intangible Assets

[0001069202-15-000003:notes:249]
As of December 31, 2014 and 2013, there were $9.4 million of indefinite-lived intangible assets recorded in Other assets, net in the accompanying Consolidated Balance Sheets.  These intangible assets consisted primarily of trademarks and are not subject to amortization.

[0001069202-15-000003:notes:250]
Identifiable intangible and other assets subject to amortization were recorded in Other assets, net in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-15-000003:notes:251]
|  | As of December 31, |
|  | 2014 |  | 2013 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Deferred financing costs | $ | 5.4 |  |  | $ | (1.5 | ) |  | $ | 3.9 |  |  | $ | 5.0 |  |  | $ | (2.3 | ) |  | $ | 2.7 |  |
| Customer relationships | 42.6 |  |  | (23.1 | ) |  | 19.5 |  |  | 42.6 |  |  | (20.6 | ) |  | 22.0 |  |
| Patents and others | 12.0 |  |  | (7.6 | ) |  | 4.4 |  |  | 10.3 |  |  | (7.2 | ) |  | 3.1 |  |
| Total | $ | 60.0 |  |  | $ | (32.2 | ) |  | $ | 27.8 |  |  | $ | 57.9 |  |  | $ | (30.1 | ) |  | $ | 27.8 |  |

[0001069202-15-000003:notes:252]
Estimated amortization expense for the next five years and thereafter is as follows (in millions):

[0001069202-15-000003:notes:253]
| Estimated Future Amortization Expense: |  |
| 2015 | $ | 3.8 |  |
| 2016 | 3.7 |  |
| 2017 | 3.5 |  |
| 2018 | 3.4 |  |
| 2019 | 3.2 |  |
| Thereafter | 10.2 |  |

[0001069202-15-000003:notes:254]
We did not have any impairments of intangible assets related to continuing operations in 2014,  2013, or 2012.  See Note 17 for information on impairments of intangible assets related to discontinued operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-15-000003:notes:255]
Income Taxes:

[0001069202-15-000003:notes:256]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-15-000003:notes:257]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Current: |  |  |  |  |  |
| Federal | $ | 84.3 |  |  | $ | 71.9 |  |  | $ | 47.5 |  |
| State | 10.1 |  |  | 8.5 |  |  | 7.3 |  |
| Foreign | 9.6 |  |  | 16.2 |  |  | 13.4 |  |
| Total current | 104.0 |  |  | 96.6 |  |  | 68.2 |  |
| Deferred: |  |  |  |  |  |
| Federal | 2.3 |  |  | (4.0 | ) |  | 0.7 |  |
| State | 1.0 |  |  | 2.5 |  |  | (0.2 | ) |
| Foreign | 2.2 |  |  | (0.7 | ) |  | (2.0 | ) |
| Total deferred | 5.5 |  |  | (2.2 | ) |  | (1.5 | ) |
| Total provision for income taxes | $ | 109.5 |  |  | $ | 94.4 |  |  | $ | 66.7 |  |

[0001069202-15-000003:notes:258]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-15-000003:notes:259]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Domestic | $ | 283.7 |  |  | $ | 231.1 |  |  | $ | 169.9 |  |
| Foreign | 33.9 |  |  | 43.2 |  |  | 31.8 |  |
| Total | $ | 317.6 |  |  | $ | 274.3 |  |  | $ | 201.7 |  |

[0001069202-15-000003:notes:260]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-15-000003:notes:261]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Provision at the U.S. statutory rate of 35% | $ | 111.2 |  |  | $ | 96.0 |  |  | $ | 70.6 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 8.8 |  |  | 7.1 |  |  | 5.9 |  |
| Other permanent items | (8.2 | ) |  | (6.4 | ) |  | (3.1 | ) |
| Research tax credit | — |  |  | (0.5 | ) |  | — |  |
| Change in unrecognized tax benefits | 0.2 |  |  | 0.7 |  |  | (5.1 | ) |
| Change in valuation allowance | 0.2 |  |  | 0.7 |  |  | 2.3 |  |
| Foreign taxes at rates other than 35% and miscellaneous other | (2.7 | ) |  | (3.2 | ) |  | (3.9 | ) |
| Total provision for income taxes | $ | 109.5 |  |  | $ | 94.4 |  |  | $ | 66.7 |  |

[0001069202-15-000003:notes:262]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and are reflected as current or non-current depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-15-000003:notes:263]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-15-000003:notes:264]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 30.9 |  |  | $ | 29.3 |  |
| Loss carryforwards (foreign, U.S. and state) | 23.6 |  |  | 28.2 |  |
| Post-retirement and pension benefits | 50.7 |  |  | 28.3 |  |
| Inventory reserves | 4.4 |  |  | 4.8 |  |
| Receivables allowance | 4.9 |  |  | 5.1 |  |
| Compensation liabilities | 19.6 |  |  | 22.6 |  |
| Deferred income | 1.0 |  |  | 0.9 |  |
| Insurance liabilities | 15.8 |  |  | 18.1 |  |
| Legal reserves | 11.1 |  |  | 10.7 |  |
| Hedges | 2.8 |  |  | 0.6 |  |
| State credits, net of federal effect | 8.8 |  |  | 8.7 |  |
| Other | 9.2 |  |  | 7.7 |  |
| Total deferred tax assets | 182.8 |  |  | 165.0 |  |
| Valuation allowance | (21.2 | ) |  | (21.2 | ) |
| Total deferred tax assets, net of valuation allowance | 161.6 |  |  | 143.8 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (10.8 | ) |  | (12.4 | ) |
| Intangibles | (11.0 | ) |  | (8.7 | ) |
| Other | (9.9 | ) |  | (9.7 | ) |
| Total deferred tax liabilities | (31.7 | ) |  | (30.8 | ) |
| Net deferred tax assets | $ | 129.9 |  |  | $ | 113.0 |  |

[0001069202-15-000003:notes:265]
As of December 31, 2014 and 2013, we had $3.8 million and $5.0 million in tax-effected state net operating loss carryforwards, respectively, and $18.5 million and $21.8 million in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards began expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in various states in the U.S., European and Asian tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits which began to expire in 2014.

[0001069202-15-000003:notes:266]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2014.

[0001069202-15-000003:notes:267]
To realize the net deferred tax asset, we will need to generate future foreign taxable income of approximately $71.2 million during the periods in which those temporary differences become deductible.  We do not need to generate additional U.S. federal income as we have sufficient carryback capacity to fully realize the federal deferred tax asset.  U.S. taxable income for the years ended December 31, 2014 and 2013 was $201.6 million and $198.7 million, respectively.

[0001069202-15-000003:notes:268]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  These earnings were approximately $122.2 million  as of December 31, 2014.  It is not practicable to estimate the amount of tax that might be payable because our intent is to permanently reinvest these earnings or to repatriate earnings when it is tax effective to do so.

[0001069202-15-000003:notes:269]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-15-000003:notes:270]
| Balance as of December 31, 2012 | $ | 1.0 |  |
| Increases related to prior year tax positions | 0.7 |  |
| Decreases related to prior year tax positions | (0.1 | ) |
| Increases related to current year tax positions | 0.1 |  |
| Balance as of December 31, 2013 | 1.7 |  |
| Increases related to prior year tax positions | 0.7 |  |
| Decreases related to prior year tax positions | (0.7 | ) |
| Increases related to current year tax positions | — |  |
| Settlement | $ | (0.1 | ) |
| Balance as of December 31, 2014 | $ | 1.6 |  |

[0001069202-15-000003:notes:271]
Included in the balance of unrecognized tax benefits as of December 31, 2014 are potential benefits of $1.2 million that, if recognized, would affect the effective tax rate on income from continuing operations.  As of December 31, 2014, we recognized $0.2 million (net of federal tax benefits) in interest and penalties in income tax expense.

[0001069202-15-000003:notes:272]
We are currently under examination for our U.S. federal income taxes for 2014 and 2013 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as Australia, Belgium, France, Canada, and Germany.  We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years before 2009.

[0001069202-15-000003:notes:273]
Since January 1, 2013, numerous states, including New Mexico, North Carolina, North Dakota, Minnesota, Oregon, Texas and West Virginia enacted legislation effective for tax years beginning on or after January 1, 2013, including changes to rates and apportionment methods.  The impact of these changes is immaterial.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-15-000003:notes:274]
Income Taxes

[0001069202-15-000003:notes:275]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 9 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-15-000003:notes:276]
Inventories:

[0001069202-15-000003:notes:277]
The components of inventories are as follows (in millions):

[0001069202-15-000003:notes:278]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Finished goods | $ | 338.2 |  |  | $ | 251.4 |  |
| Work in process | 8.1 |  |  | 11.8 |  |
| Raw materials and parts | 182.6 |  |  | 188.9 |  |
| Total | 528.9 |  |  | 452.1 |  |
| Excess of current cost over last-in, first-out cost | (65.6 | ) |  | (73.3 | ) |
| Total inventories, net | $ | 463.3 |  |  | $ | 378.8 |  |

[0001069202-15-000003:notes:279]
The Company recorded pre-tax loss of $0.9 million in 2014, pre-tax income of 0.3 million in 2013 and pre-tax loss of $0.1 million in 2012 from LIFO inventory liquidations.


## us-gaap:InventoryPolicyTextBlock

[0001069202-15-000003:notes:280]
Inventories

[0001069202-15-000003:notes:281]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $212.9 million and $187.3 million as of December 31, 2014 and 2013, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or market with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-15-000003:notes:282]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-15-000003:notes:283]
Losses and Other Expenses, net:

[0001069202-15-000003:notes:284]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-15-000003:notes:285]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Realized losses on settled futures contracts | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 1.5 |  |
| Foreign currency exchange losses | 1.6 |  |  | 0.5 |  |  | 0.8 |  |
| Losses (gains) on disposal of fixed assets | (0.3 | ) |  | (1.0 | ) |  | 0.4 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.6 |  |  | 0.4 |  |  | (2.2 | ) |
| Asbestos-related litigation | 0.9 |  |  | 6.3 |  |  | — |  |
| Acquisition expenses | — |  |  | 0.2 |  |  | 0.1 |  |
| Special legal contingency charges | 0.9 |  |  | 1.2 |  |  | 1.2 |  |
| Environmental liabilities | 2.0 |  |  | — |  |  | — |  |
| Other items, net | 0.3 |  |  | 0.7 |  |  | 0.7 |  |
| Losses and other expenses, net | $ | 6.8 |  |  | $ | 9.3 |  |  | $ | 2.5 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-15-000003:notes:286]
Employee Benefit Plans:

[0001069202-15-000003:notes:287]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.  We also have several active defined benefit plans that provide benefits based on years of service.

[0001069202-15-000003:notes:288]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2015, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-15-000003:notes:289]
Defined Contribution Plans

[0001069202-15-000003:notes:290]
We recorded the following expenses related to our contributions to the defined contribution plans (in millions):

[0001069202-15-000003:notes:291]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Contributions to defined contribution plans (1) | $ | 14.8 |  |  | $ | 13.7 |  |  | $ | 13.2 |  |

[0001069202-15-000003:notes:292]
(1)  Contributions of $0.4 million and $2.0 million were included in Loss from discontinued operations for the years ended December 31, 2013 and 2012, respectively.  No contributions were included in Loss from discontinued operations in 2014.

[0001069202-15-000003:notes:293]
Pension and Post-retirement Benefit Plans

[0001069202-15-000003:notes:294]
The following tables set forth amounts recognized in our financial statements and the plans' funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-15-000003:notes:295]
|  | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Accumulated benefit obligation | $ | 439.6 |  |  | $ | 367.3 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 374.6 |  |  | $ | 413.9 |  |  | $ | 6.0 |  |  | $ | 7.6 |  |
| Service cost | 4.2 |  |  | 5.2 |  |  | — |  |  | — |  |
| Interest cost | 17.7 |  |  | 16.2 |  |  | 0.2 |  |  | 0.2 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.6 |  |  | 0.7 |  |
| Amendments | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Actuarial (gain) loss | 77.0 |  |  | (39.4 | ) |  | 0.6 |  |  | — |  |
| Effect of exchange rates | (4.3 | ) |  | (0.7 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Settlements and curtailments | (0.8 | ) |  | (1.6 | ) |  | — |  |  | — |  |
| Benefits paid | (21.9 | ) |  | (19.1 | ) |  | (2.0 | ) |  | (2.5 | ) |
| Benefit obligation at end of year | $ | 446.5 |  |  | $ | 374.6 |  |  | $ | 5.4 |  |  | $ | 6.0 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 302.8 |  |  | $ | 276.8 |  |  | $ | — |  |  | $ | — |  |
| Actual gain return on plan assets | 23.3 |  |  | 37.4 |  |  | — |  |  | — |  |
| Employer contribution | 14.5 |  |  | 9.9 |  |  | 1.4 |  |  | 1.8 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.6 |  |  | 0.7 |  |
| Effect of exchange rates | (2.9 | ) |  | (0.6 | ) |  | — |  |  | — |  |
| Divestiture | — |  |  | — |  |  | — |  |  | — |  |
| Plan settlements | (0.8 | ) |  | (1.6 | ) |  | — |  |  | — |  |
| Benefits paid | (21.9 | ) |  | (19.1 | ) |  | (2.0 | ) |  | (2.5 | ) |
| Fair value of plan assets at end of year | 315.0 |  |  | 302.8 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (131.5 | ) |  | $ | (71.8 | ) |  | $ | (5.4 | ) |  | $ | (6.0 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Current liability | $ | (1.6 | ) |  | $ | (1.8 | ) |  | $ | (0.9 | ) |  | $ | (1.4 | ) |
| Non-current liability | (129.9 | ) |  | (70.0 | ) |  | (4.5 | ) |  | (4.6 | ) |
| Net amount recognized | $ | (131.5 | ) |  | $ | (71.8 | ) |  | $ | (5.4 | ) |  | $ | (6.0 | ) |

[0001069202-15-000003:notes:296]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 446.5 |  |  | $ | 374.6 |  |
| Accumulated benefit obligation | 439.6 |  |  | 367.3 |  |
| Fair value of plan assets | 315.0 |  |  | 302.8 |  |

[0001069202-15-000003:notes:297]
Our U.S.-based pension plans comprised approximately 88% of the projected benefit obligation and 87% of plan assets as of December 31, 2014.

[0001069202-15-000003:notes:298]
|  | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 4.2 |  |  | $ | 5.2 |  |  | $ | 5.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |
| Interest cost | 17.7 |  |  | 16.2 |  |  | 17.5 |  |  | 0.2 |  |  | 0.2 |  |  | 0.4 |  |
| Expected return on plan assets | (22.7 | ) |  | (20.7 | ) |  | (19.0 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.3 |  |  | 0.4 |  |  | 0.4 |  |  | (3.1 | ) |  | (3.1 | ) |  | (2.7 | ) |
| Recognized actuarial loss | 6.6 |  |  | 9.2 |  |  | 8.7 |  |  | 1.5 |  |  | 1.5 |  |  | 1.4 |  |
| Settlements and curtailments | 0.4 |  |  | 1.5 |  |  | 7.1 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (1) | $ | 6.5 |  |  | $ | 11.8 |  |  | $ | 20.5 |  |  | $ | (1.4 | ) |  | $ | (1.4 | ) |  | $ | (0.7 | ) |

[0001069202-15-000003:notes:299]
(1)  Pension expense of $0.2 million and $6.9 million was included in Loss for discontinued operations for the years ended December 31, 2013 and 2012, respectively.   No pension expense was included in Loss from discontinued operations in 2014.

[0001069202-15-000003:notes:300]
The following table sets forth amounts recognized in AOCI and Other comprehensive income (loss) in our financial statements for 2014 and 2013 (in millions):

[0001069202-15-000003:notes:301]
|  | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amounts recognized in AOCI: |  |  |  |  |  |  |  |
| Prior service costs | $ | (1.3 | ) |  | $ | (1.7 | ) |  | $ | 18.1 |  |  | $ | 21.1 |  |
| Actuarial loss | (231.8 | ) |  | (164.4 | ) |  | (19.8 | ) |  | (20.7 | ) |
| Subtotal | (233.1 | ) |  | (166.1 | ) |  | (1.7 | ) |  | 0.4 |  |
| Deferred taxes | 84.7 |  |  | 59.9 |  |  | 0.6 |  |  | (0.2 | ) |
| Net amount recognized | $ | (148.4 | ) |  | $ | (106.2 | ) |  | $ | (1.1 | ) |  | $ | 0.2 |  |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Adjustment to OCI due to reclassification | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current year prior service costs | — |  |  | — |  |  | — |  |  | — |  |
| Current year actuarial (gain) loss | 75.9 |  |  | (56.1 | ) |  | 0.6 |  |  | — |  |
| Effect of exchange rates | (1.8 | ) |  | (0.6 | ) |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (0.3 | ) |  | (1.1 | ) |  | 3.1 |  |  | 3.1 |  |
| Amortization of actuarial loss | (7.0 | ) |  | (10.0 | ) |  | (1.5 | ) |  | (1.5 | ) |
| Total recognized in other comprehensive income | $ | 66.8 |  |  | $ | (67.8 | ) |  | $ | 2.2 |  |  | $ | 1.6 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 73.3 |  |  | $ | (56.0 | ) |  | $ | 0.8 |  |  | $ | 0.2 |  |

[0001069202-15-000003:notes:302]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCI in 2014 are $(0.2) million and $(10.3) million, respectively, for pension benefits and $2.8 million and $(1.4) million, respectively, for other benefits.

[0001069202-15-000003:notes:303]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the U.S.-based plans in 2014 and 2013:

[0001069202-15-000003:notes:304]
|  | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 4.04 | % |  | 4.88 | % |  | 3.23 | % |  | 3.57 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-15-000003:notes:305]
|  | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.88 | % |  | 3.97 | % |  | 4.83 | % |  | 3.57 | % |  | 2.72 | % |  | 4.64 | % |
| Expected long-term return on plan assets | 8.00 | % |  | 8.00 | % |  | 8.00 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-15-000003:notes:306]
The following tables set forth the weighted-average assumptions used to determine Benefit Obligations and Net Periodic Benefit Cost for the non-U.S.-based plans in 2014 and 2013:

[0001069202-15-000003:notes:307]
|  | Pension Benefits |
|  | 2014 |  | 2013 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 3.45 | % |  | 4.38 | % |
| Rate of compensation increase | 3.66 | % |  | 3.31 | % |

[0001069202-15-000003:notes:308]
|  | Pension Benefits |
|  | 2014 |  | 2013 |  | 2012 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate | 4.38 | % |  | 4.12 | % |  | 4.93 | % |
| Expected long-term return on plan assets | 6.32 | % |  | 6.05 | % |  | 6.26 | % |
| Rate of compensation increase | 3.31 | % |  | 3.48 | % |  | 3.68 | % |

[0001069202-15-000003:notes:309]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns and the future expectations for returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 8.0% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-15-000003:notes:310]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the duration of projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available.  We used the results of the yield curve analysis to select the discount rate that matched the duration and payment stream of the benefits in each plan.  This resulted in the selection of the 4.94% discount rate assumption for the U.S. qualified pension plans, 4.30% for the U.S. non-qualified pension plans, and 3.23% for the other benefits.  A similar process was followed for the non-U.S.-based plans.

[0001069202-15-000003:notes:311]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-15-000003:notes:312]
|  | 2014 |  | 2013 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 7.50 | % |  | 8.00 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2020 |  |  | 2020 |  |

[0001069202-15-000003:notes:313]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-15-000003:notes:314]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | — |  |  | $ | — |  |
| Effect on the post-retirement benefit obligation | 0.2 |  |  | (0.2 | ) |

[0001069202-15-000003:notes:315]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-15-000003:notes:316]
|  | For the Years Ended December 31, |
|  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020-2024 |
| Pension benefits | $ | 18.0 |  |  | $ | 18.3 |  |  | $ | 18.9 |  |  | $ | 19.5 |  |  | $ | 20.0 |  |  | $ | 124.9 |  |
| Other benefits | 0.9 |  |  | 0.7 |  |  | 0.6 |  |  | 0.6 |  |  | 0.5 |  |  | 1.7 |  |

[0001069202-15-000003:notes:317]
Pension Plan Assets

[0001069202-15-000003:notes:318]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the first quarter of 2014, in order to increase diversification, we changed the targeted allocations for our plan assets. The target allocations for fixed income, money market, cash and guaranteed investment contracts investments increased from 40% to 58% while targeted equity investment allocations declined from 60% to 42%. We decreased our exposure to International equity from 24% to 17% of total assets and reduced our exposure to domestic equity from 36% to 25%. These categories are further diversified among various asset classes including high yield and emerging markets debt, and international and emerging markets equities in order to avoid significant concentrations of risk. Our U.S. pension plan represents 88%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 6% of the total fair value of our plan assets as of December 31, 2014.

[0001069202-15-000003:notes:319]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2014 and 2013, by asset category, are as follows:

[0001069202-15-000003:notes:320]
|  | Plan Assets as of December 31, |
| Asset Category: | 2014 |  | 2013 |
| U.S. equity | 28.3 | % |  | 37.8 | % |
| International equity | 17.1 | % |  | 26.7 | % |
| Fixed income | 52.6 | % |  | 33.8 | % |
| Money market/cash | 2.0 | % |  | 1.7 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-15-000003:notes:321]
Our Canadian pension plan was invested solely in a balanced fund that maintains diversification among various asset classes, including Canadian common stocks, bonds and money market securities, international equities and fixed income investments. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K., international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-15-000003:notes:322]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund's NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 20 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-15-000003:notes:323]
Property, Plant and Equipment:

[0001069202-15-000003:notes:324]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-15-000003:notes:325]
|  | As of December 31, |
|  | 2014 |  | 2013 |
| Land | $ | 38.3 |  |  | $ | 39.5 |  |
| Buildings and improvements | 215.0 |  |  | 202.5 |  |
| Machinery and equipment | 681.8 |  |  | 634.0 |  |
| Capital leases | 27.0 |  |  | 25.2 |  |
| Construction in progress and equipment not yet in service | 50.6 |  |  | 51.6 |  |
| Total | 1,012.7 |  |  | 952.8 |  |
| Less accumulated depreciation | (654.1 | ) |  | (617.3 | ) |
| Property, plant and equipment, net | $ | 358.6 |  |  | $ | 335.5 |  |

[0001069202-15-000003:notes:326]
No impairment charges were recorded in 2014, 2013 or 2012.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-15-000003:notes:327]
Property, Plant and Equipment

[0001069202-15-000003:notes:328]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-15-000003:notes:329]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-15-000003:notes:330]
| Buildings and improvements: |  |
| Buildings and improvements | 5 to 30 years |
| Leasehold improvements | 1 to 20 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 5 to 10 years |
| Vehicles | 3 to 8 years |

[0001069202-15-000003:notes:331]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 5 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-15-000003:notes:332]
Quarterly Financial Information (unaudited):

[0001069202-15-000003:notes:333]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-15-000003:notes:334]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (Loss) (1) |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| First Quarter | $ | 695.4 |  |  | $ | 668.4 |  |  | $ | 168.1 |  |  | $ | 162.0 |  |  | $ | 19.9 |  |  | $ | 8.0 |  |
| Second Quarter | 960.7 |  |  | 913.1 |  |  | 262.6 |  |  | 254.0 |  |  | 73.9 |  |  | 64.3 |  |
| Third Quarter | 898.4 |  |  | 868.0 |  |  | 247.1 |  |  | 237.4 |  |  | 67.4 |  |  | 64.3 |  |
| Fourth Quarter | 812.8 |  |  | 749.5 |  |  | 225.4 |  |  | 207.7 |  |  | 44.6 |  |  | 35.2 |  |

[0001069202-15-000003:notes:335]
|  | Basic Earnings (Loss) per Share (2) |  | Diluted Earnings (Loss) per Share (2) |  | Cash Dividends per Common Share |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| First Quarter | $ | 0.41 |  |  | $ | 0.16 |  |  | $ | 0.40 |  |  | $ | 0.16 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |
| Second Quarter | 1.51 |  |  | 1.28 |  |  | 1.49 |  |  | 1.26 |  |  | 0.30 |  |  | 0.24 |  |
| Third Quarter | 1.40 |  |  | 1.29 |  |  | 1.38 |  |  | 1.27 |  |  | 0.30 |  |  | 0.24 |  |
| Fourth Quarter | 0.98 |  |  | 0.72 |  |  | 0.96 |  |  | 0.70 |  |  | 0.30 |  |  | 0.24 |  |

[0001069202-15-000003:notes:336]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-15-000003:notes:337]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-15-000003:notes:338]
Summary of 2014 Quarterly Results

[0001069202-15-000003:notes:339]
The following unusual or infrequent pre-tax items were included in the 2014 quarterly results:

[0001069202-15-000003:notes:340]
1st Quarter.  No significant unusual or infrequent items.

[0001069202-15-000003:notes:341]
2nd Quarter.  No significant unusual or infrequent items.

[0001069202-15-000003:notes:342]
3rd Quarter.  We recorded restructuring charges of $1 million for a new project to realign resources and enhance distribution capabilities.  Refer to Note 16 for more information related to our restructuring activities.

[0001069202-15-000003:notes:343]
4th Quarter.  We recorded restructuring charges of $0.6 million for our project to realign resources and enhance distribution capabilities.

[0001069202-15-000003:notes:344]
Summary of 2013 Quarterly Results

[0001069202-15-000003:notes:345]
The following unusual or infrequent pre-tax items were included in the 2013 quarterly results:

[0001069202-15-000003:notes:346]
1st Quarter.  On March 22, 2013, we sold our Service Experts business to a majority-owned entity of American Capital, Ltd. in an all-cash transaction for net proceeds of $10.4 million, excluding transaction costs.  We recorded a 1.4 million gain on the sale of the business for the year ended December 31, 2013.  Refer to Note 17 for more information.

[0001069202-15-000003:notes:347]
2nd Quarter.  We recorded restructuring charges of $2.4 million primarily related to the completion of the transition activities with our North American Parts Center in Des Moines, Iowa.  Refer to Note 16 for more information related to our restructuring activities.

[0001069202-15-000003:notes:348]
3rd Quarter.  We recorded legal contingency charges of $0.8 million associated with ongoing patent litigation.  Refer to Note 10 for more information on our legal contingencies.

[0001069202-15-000003:notes:349]
4th Quarter.  We recorded expenses of $6.3 million for asbestos-related litigation.  Refer to Note 10 for more information.  We also recorded restructuring charges of $1.8 million primarily related to anticipated severance charges associated with a relocation of certain Residential Heating & Cooling manufacturing operations to lower cost facilities.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-15-000003:notes:350]
Accounts and Notes Receivable

[0001069202-15-000003:notes:351]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management's judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management's review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-15-000003:notes:352]
Total assets by segment are shown below (in millions):

[0001069202-15-000003:notes:353]
|  | As of December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 632.3 |  |  | $ | 500.0 |  |  | $ | 457.5 |  |
| Commercial Heating & Cooling | 353.4 |  |  | 346.3 |  |  | 321.9 |  |
| Refrigeration | 551.5 |  |  | 572.0 |  |  | 585.3 |  |
| Corporate and other | 227.1 |  |  | 208.4 |  |  | 228.6 |  |
| Assets for continuing operations | 1,764.3 |  |  | 1,626.7 |  |  | 1,593.3 |  |
| Discontinued operations (See Note 17) | — |  |  | — |  |  | 98.6 |  |
| Total assets | $ | 1,764.3 |  |  | $ | 1,626.7 |  |  | $ | 1,691.9 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-15-000003:notes:354]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Income from continuing operations before income taxes, are shown below (in millions):

[0001069202-15-000003:notes:355]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 1,736.5 |  |  | $ | 1,583.2 |  |  | $ | 1,375.8 |  |
| Commercial Heating & Cooling | 878.5 |  |  | 844.4 |  |  | 785.4 |  |
| Refrigeration | 752.4 |  |  | 771.5 |  |  | 788.2 |  |
|  | $ | 3,367.4 |  |  | $ | 3,199.1 |  |  | $ | 2,949.4 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 235.8 |  |  | $ | 180.1 |  |  | $ | 102.9 |  |
| Commercial Heating & Cooling | 124.0 |  |  | 118.1 |  |  | 99.5 |  |
| Refrigeration | 55.4 |  |  | 90.2 |  |  | 81.9 |  |
| Corporate and other | (74.3 | ) |  | (87.9 | ) |  | (60.1 | ) |
| Subtotal that includes segment profit and eliminations | 340.9 |  |  | 300.5 |  |  | 224.2 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |
| Special product quality adjustments | (1.4 | ) |  | (2.3 | ) |  | 1.1 |  |
| Items in Losses and other expenses, net that are excluded from segment profit (loss) (2) | 4.7 |  |  | 8.8 |  |  | (0.2 | ) |
| Restructuring charges | 1.9 |  |  | 5.0 |  |  | 4.2 |  |
| Interest expense, net | 17.2 |  |  | 14.5 |  |  | 17.1 |  |
| Special inventory write down | 1.0 |  |  | — |  |  | — |  |
| Other expense, net | (0.1 | ) |  | 0.2 |  |  | 0.3 |  |
| Income from continuing operations before income taxes | $ | 317.6 |  |  | $ | 274.3 |  |  | $ | 201.7 |  |

[0001069202-15-000003:notes:356]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-15-000003:notes:357]
(2) The Company defines segment profit and loss as a segment's income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-15-000003:notes:358]
| • | Special product quality adjustments; |

[0001069202-15-000003:notes:359]
| • | The following items in Losses and other expenses, net: |

[0001069202-15-000003:notes:360]
| ◦ | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001069202-15-000003:notes:361]
| ◦ | Special legal contingency charges, |

[0001069202-15-000003:notes:362]
| ◦ | Asbestos-related litigation, |

[0001069202-15-000003:notes:363]
| ◦ | Environmental liabilities, and |

[0001069202-15-000003:notes:364]
| ◦ | Other items, net; |

[0001069202-15-000003:notes:365]
| • | Restructuring charges; |

[0001069202-15-000003:notes:366]
| • | Goodwill, long-lived asset, and equity method investment impairments; |

[0001069202-15-000003:notes:367]
| • | Interest expense, net; |

[0001069202-15-000003:notes:368]
| • | Special inventory write down; and |

[0001069202-15-000003:notes:369]
| • | Other expense, net. |


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-15-000003:notes:370]
Total capital expenditures by segment are shown below (in millions):

[0001069202-15-000003:notes:371]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 39.4 |  |  | $ | 34.2 |  |  | $ | 13.7 |  |
| Commercial Heating & Cooling | 14.1 |  |  | 11.2 |  |  | 8.7 |  |
| Refrigeration | 15.8 |  |  | 16.5 |  |  | 15.6 |  |
| Corporate and other | 19.1 |  |  | 16.4 |  |  | 12.2 |  |
| Total capital expenditures (1) | $ | 88.4 |  |  | $ | 78.3 |  |  | $ | 50.2 |  |

[0001069202-15-000003:notes:372]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2014, 2013 or 2012.

[0001069202-15-000003:notes:373]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-15-000003:notes:374]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 20.7 |  |  | $ | 20.5 |  |  | $ | 19.9 |  |
| Commercial Heating & Cooling | 9.3 |  |  | 9.0 |  |  | 8.5 |  |
| Refrigeration | 16.3 |  |  | 15.3 |  |  | 13.0 |  |
| Corporate and other | 14.5 |  |  | 14.1 |  |  | 14.0 |  |
| Total depreciation and amortization | $ | 60.8 |  |  | $ | 58.9 |  |  | $ | 55.4 |  |

[0001069202-15-000003:notes:375]
The equity method investments are shown below (in millions):

[0001069202-15-000003:notes:376]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 2.5 |  |  | $ | 2.5 |  |  | $ | 2.6 |  |
| Corporate and other (1) | 11.3 |  |  | 9.7 |  |  | 7.9 |  |
| Total income from equity method investments | $ | 13.8 |  |  | $ | 12.2 |  |  | $ | 10.5 |  |

[0001069202-15-000003:notes:377]
(1) We allocated $11.7 million, $9.6 million and $5.0 million of income from equity method investments to our Residential Heating & Cooling and Commercial Heating & Cooling segments in 2014, 2013 and 2012, respectively.  These allocations were recorded as reductions to the segments' Cost of goods sold in the Consolidated Statements of Operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-15-000003:notes:378]
Restructuring Charges:

[0001069202-15-000003:notes:379]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 19.

[0001069202-15-000003:notes:380]
Restructuring Activities in 2014

[0001069202-15-000003:notes:381]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-15-000003:notes:382]
|  | Incurred in 2014 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 1.4 |  |  | $ | 6.9 |  |  | $ | 7.2 |  |
| Asset write-offs and accelerated depreciation | 0.3 |  |  | 1.8 |  |  | 1.8 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | 0.1 |  |
| Other | 0.2 |  |  | 1.9 |  |  | 2.3 |  |
| Total | $ | 1.9 |  |  | $ | 10.6 |  |  | $ | 11.4 |  |

[0001069202-15-000003:notes:383]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-15-000003:notes:384]
|  | Incurred in 2014 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.4 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |
| Commercial Heating & Cooling | — |  |  | 0.9 |  |  | 0.9 |  |
| Refrigeration | 1.6 |  |  | 8.2 |  |  | 9.0 |  |
| Corporate & Other | (0.1 | ) |  | — |  |  | — |  |
| Total | $ | 1.9 |  |  | $ | 10.6 |  |  | $ | 11.4 |  |

[0001069202-15-000003:notes:385]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.  The activity within the restructuring accruals is summarized in the tables below (in millions):

[0001069202-15-000003:notes:386]
| Description of Reserves: | Balance as of December 31, 2013 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2014 |
| Severance and related expense | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | (1.5 | ) |  | $ | — |  |  | $ | 1.5 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.3 |  |  | — |  |  | (0.2 | ) |  | 0.1 |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.2 |  |  | (0.2 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 1.6 |  |  | $ | 1.9 |  |  | $ | (1.7 | ) |  | $ | (0.2 | ) |  | $ | 1.6 |  |

[0001069202-15-000003:notes:387]
| Description of Reserves: | Balance as of December 31, 2012 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2013 |
| Severance and related expense | $ | 0.7 |  |  | $ | 2.7 |  |  | $ | (1.6 | ) |  | $ | (0.2 | ) |  | $ | 1.6 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.7 |  |  | — |  |  | (0.7 | ) |  | — |  |
| Equipment moves | — |  |  | 0.1 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Lease termination | 1.2 |  |  | — |  |  | (1.2 | ) |  | — |  |  | — |  |
| Other | 0.5 |  |  | 1.5 |  |  | (2.0 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | 2.4 |  |  | $ | 5.0 |  |  | $ | (4.9 | ) |  | $ | (0.9 | ) |  | $ | 1.6 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-15-000003:notes:388]
Revenue Recognition

[0001069202-15-000003:notes:389]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-15-000003:notes:390]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for these services is recognized over the life of the contract.

[0001069202-15-000003:notes:391]
We engage in cooperative advertising, customer rebate, cash discount and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.  See Note 23 for more information on these costs.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-15-000003:notes:392]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-15-000003:notes:393]
|  | As of December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 243.4 |  |  | $ | 230.3 |  |  | $ | 227.9 |  |
| Mexico | 52.4 |  |  | 39.7 |  |  | 28.0 |  |
| Canada | 0.6 |  |  | 0.6 |  |  | 0.6 |  |
| International | 62.2 |  |  | 64.9 |  |  | 41.7 |  |
| Total Property, plant and equipment, net | $ | 358.6 |  |  | $ | 335.5 |  |  | $ | 298.2 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-15-000003:notes:394]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-15-000003:notes:395]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-15-000003:notes:396]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-15-000003:notes:397]
|  | For the Years Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 2,576.4 |  |  | $ | 2,382.0 |  |  | $ | 2,147.2 |  |
| Canada | 236.3 |  |  | 232.3 |  |  | 226.7 |  |
| International | 554.7 |  |  | 584.8 |  |  | 575.5 |  |
| Total net sales to external customers | $ | 3,367.4 |  |  | $ | 3,199.1 |  |  | $ | 2,949.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-15-000003:notes:398]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-15-000003:notes:399]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-15-000003:notes:400]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-15-000003:notes:401]
For the Years Ended December 31, 2014, 2013 and 2012

[0001069202-15-000003:notes:402]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2012: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 11.3 |  |  | $ | 3.9 |  |  | $ | (6.8 | ) |  | $ | 1.8 |  |  | $ | (0.7 | ) |  | $ | 9.5 |  |
| 2013: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.5 |  |  | $ | 3.6 |  |  | $ | (4.6 | ) |  | $ | 1.6 |  |  | $ | (0.3 | ) |  | $ | 9.8 |  |
| 2014: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.8 |  |  | $ | 2.6 |  |  | $ | (4.6 | ) |  | $ | 1.1 |  |  | $ | (1.0 | ) |  | $ | 7.9 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-15-000003:notes:403]
Reportable Business Segments:

[0001069202-15-000003:notes:404]
Description of Segments

[0001069202-15-000003:notes:405]
In September 2012, we announced the planned sale of our Service Experts business. The Service Experts business had previously been reported within the Service Experts reportable segment along with the Lennox National Account Services ("NAS") business.  Beginning in the third quarter of 2012, the Service Experts business was included in discontinued operations, NAS was included in our Commercial Heating & Cooling segment, and the Service Experts segment was eliminated. Results for all periods have been revised to reflect this new presentation.

[0001069202-15-000003:notes:406]
Segment Data

[0001069202-15-000003:notes:407]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-15-000003:notes:408]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-15-000003:notes:409]
As they arise, transactions between segments are recorded on an arm’s-length basis using the relevant market prices.  Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-15-000003:notes:410]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-15-000003:notes:411]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-15-000003:notes:412]
Self-Insurance

[0001069202-15-000003:notes:413]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information and industry factors and trends.  The self-insurance liabilities as of December 31, 2014 represent the best estimate of the future payments to be made on reported and unreported losses for 2014 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 10 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-15-000003:notes:414]
Selling, General and Administrative Expenses

[0001069202-15-000003:notes:415]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-15-000003:notes:416]
Summary of Significant Accounting Policies:

[0001069202-15-000003:notes:417]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 3 for more information on our inventories.

[0001069202-15-000003:notes:418]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired.

[0001069202-15-000003:notes:419]
The annual goodwill impairment test was performed during the first quarter of 2014, and no impairment was recognized.  During the third quarter of 2014, we changed the date of our annual goodwill impairment test from March 31st to December 31st.   The change was made to more closely align the impairment testing date with the year-end results.  The change in goodwill impairment testing date was deemed a change in accounting principle and did not delay, accelerate, or avoid a goodwill impairment charge.  Management determined that the change in accounting principle was preferable under the circumstances and did not result in adjustments to our financial statements when applied retrospectively.

[0001069202-15-000003:notes:420]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-15-000003:notes:421]
For those reporting units which are evaluated using the two-step quantitative goodwill impairment test, we estimate reporting unit fair values using the discounted cash flow approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. See Note 4 for additional information on our goodwill.

[0001069202-15-000003:notes:422]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-15-000003:notes:423]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets. For those intangible assets which are evaluated using the two-step quantitative impairment test, we compare the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets. If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.

[0001069202-15-000003:notes:424]
Product Warranties

[0001069202-15-000003:notes:425]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 10 for more information on our estimated future warranty costs.

[0001069202-15-000003:notes:426]
Pensions and Post-retirement Benefits

[0001069202-15-000003:notes:427]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-15-000003:notes:428]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 12 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-15-000003:notes:429]
Stock-Based Compensation

[0001069202-15-000003:notes:430]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 14 for more information.

[0001069202-15-000003:notes:431]
Use of Estimates

[0001069202-15-000003:notes:432]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-15-000003:notes:433]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-15-000003:notes:434]
Reclassifications

[0001069202-15-000003:notes:435]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:TreasuryStockTextBlock

[0001069202-15-000003:notes:436]
Stock Repurchases:

[0001069202-15-000003:notes:437]
Our Board of Directors has authorized a total of $1.4 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $700.0 million share repurchase authorization in October 2014. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date.  As of December 31, 2014, $395.9 million of shares may still be repurchased under the Share Repurchase Plans.

[0001069202-15-000003:notes:438]
On October 20, 2014, we announced our plans for a new $450.0 million accelerated share repurchase program.  For the years ended December 31, 2014 and 2013, we repurchased 5.2 million shares for $550.3 million and 1.7 million shares for $125.0 million, respectively, under the Share Repurchase Plans. The final number of shares to be repurchased and the aggregate cost to LII will be based on LII's volume-weighted average stock price during the term of the transaction, which is expected to be completed in the second half of 2015.

[0001069202-15-000003:notes:439]
We also repurchased 0.2 million shares for $22.4 million and 0.2 million shares for $12.0 million for the years ended December 31, 2014 and 2013, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.
