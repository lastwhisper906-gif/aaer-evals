# LII note change history — 0001069202-14-000006 → 0001069202-14-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-10-20):
[0001069202-14-000008:note_history:1]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.5 |  |  | $ | 28.7 |  |
| Other liabilities | 58.6 |  |  | 52.9 |  |
| Total warranty liability | $ | 86.1 |  |  | $ | 81.6 |  |
  (was, 2014-07-21, similarity 0.9687):
[0001069202-14-000006:note_history:1]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.9 |  |  | $ | 28.7 |  |
| Other liabilities | 57.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 85.3 |  |  | $ | 81.6 |  |

- changed (2014-10-20):
[0001069202-14-000008:note_history:2]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2014 were as follows (in millions):
  (was, 2014-07-21, similarity 0.9444):
[0001069202-14-000006:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2014 were as follows (in millions):

- changed (2014-10-20):
[0001069202-14-000008:note_history:3]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (16.6 | ) |
| Changes resulting from issuance of new warranties | 24.1 |  |
| Changes in estimates associated with pre-existing liabilities | (2.3 | ) |
| Changes in foreign currency translation rates and other | (0.7 | ) |
| Total warranty liability as of September 30, 2014 | $ | 86.1 |  |
  (was, 2014-07-21, similarity 0.9686):
[0001069202-14-000006:note_history:3]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (10.3 | ) |
| Changes resulting from issuance of new warranties | 16.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.2 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of June 30, 2014 | $ | 85.3 |  |

- changed (2014-10-20):
[0001069202-14-000008:note_history:4]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the nine months ended September 30, 2014 were as follows (in millions):
  (was, 2014-07-21, similarity 0.92):
[0001069202-14-000006:note_history:4]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the six months ended June 30, 2014 were as follows (in millions):

- changed (2014-10-20):
[0001069202-14-000008:note_history:5]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.6 | ) |
| Total accrued product quality issues as of September 30, 2014 | $ | 4.1 |  |
  (was, 2014-07-21, similarity 0.9741):
[0001069202-14-000006:note_history:5]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.4 | ) |
| Total accrued product quality issues as of June 30, 2014 | $ | 4.3 |  |

- changed (2014-10-20):
[0001069202-14-000008:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the nine months ended September 30, 2014, and 2013, expense for asbestos-related litigation was $1.0 million, and $0.5 million, net of insurance recoveries, respectively.
  (was, 2014-07-21, similarity 0.9772):
[0001069202-14-000006:note_history:6]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2014, and 2013, expense for asbestos-related litigation was $0.6 million, and $0.5 million, net of insurance recoveries, respectively.


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-10-20):
[0001069202-14-000008:note_history:7]
The changes in the accrued product quality issues for the nine months ended September 30, 2014 were as follows (in millions):
  (was, 2014-07-21, similarity 0.9316):
[0001069202-14-000006:note_history:7]
The changes in the accrued product quality issues for the six months ended June 30, 2014 were as follows (in millions):

- changed (2014-10-20):
[0001069202-14-000008:note_history:8]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.6 | ) |
| Total accrued product quality issues as of September 30, 2014 | $ | 4.1 |  |
  (was, 2014-07-21, similarity 0.9741):
[0001069202-14-000006:note_history:8]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.4 | ) |
| Total accrued product quality issues as of June 30, 2014 | $ | 4.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-10-20):
[0001069202-14-000008:note_history:9]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2014, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2014-07-21, similarity 0.8332):
[0001069202-14-000006:note_history:9]
Statements of Operations for the three and six months ended June 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- added (2014-10-20):
[0001069202-14-000008:note_history:10]
Change in method of accounting for evaluating goodwill for impairment

- added (2014-10-20):
[0001069202-14-000008:note_history:11]
The annual goodwill impairment test was performed during the first quarter of 2014, and no impairment was recognized.  During the third quarter of 2014, we changed the date of our annual goodwill impairment test from March 31st to December 31st. The change was made to more closely align the impairment testing date with the year-end results and may result in impairment charges identified in the fourth quarter.

- added (2014-10-20):
[0001069202-14-000008:note_history:12]
The change in goodwill impairment testing date is deemed a change in accounting principle. Management believes that the change in accounting principle will not delay, accelerate, or avoid a goodwill impairment charge. Management determined that the change in accounting principle is preferable under the circumstances and does not result in adjustments to our financial statements when applied retrospectively.

- removed (2014-10-20):
[0001069202-14-000006:note_history:13]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2014, the accompanying unaudited Consolidated


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-10-20):
[0001069202-14-000008:note_history:14]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.38 | % |  | 1.17 | % |
  (was, 2014-07-21, similarity 0.9447):
[0001069202-14-000006:note_history:14]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-10-20):
[0001069202-14-000008:note_history:15]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 9.0 |  |  | 5.9 |  |
| Total short-term debt | $ | 229.0 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 149.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 365.7 |  |  | $ | 233.2 |  |
| Total debt | $ | 596.0 |  |  | $ | 400.4 |  |

- changed (2014-10-20):
[0001069202-14-000008:note_history:16]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $9.0 million and $5.9 million of foreign obligations as of September 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.
  (was, 2014-07-21, similarity 0.9794):
[0001069202-14-000006:note_history:16]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.6 million and $5.9 million of foreign obligations as of June 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

- added (2014-10-20):
[0001069202-14-000008:note_history:17]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 220.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 220.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- changed (2014-10-20):
[0001069202-14-000008:note_history:18]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for September 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2014-07-21, similarity 0.9924):
[0001069202-14-000006:note_history:18]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for June 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2014-10-20):
[0001069202-14-000008:note_history:19]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of September 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-07-21, similarity 0.9906):
[0001069202-14-000006:note_history:19]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2014, we were in compliance with all covenant requirements.

- added (2014-10-20):
[0001069202-14-000008:note_history:20]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $149.0 million as well as $27.2 million committed to standby letters of credit as of September 30, 2014. Subject to covenant limitations, $473.8 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2014-10-20):
[0001069202-14-000008:note_history:21]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.38 | % |  | 1.17 | % |
  (was, 2014-07-21, similarity 0.9447):
[0001069202-14-000006:note_history:21]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |

- changed (2014-10-20):
[0001069202-14-000008:note_history:22]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of September 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-07-21, similarity 0.9742):
[0001069202-14-000006:note_history:22]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2014, we were in compliance with all covenant requirements.

- changed (2014-10-20):
[0001069202-14-000008:note_history:23]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of September 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-07-21, similarity 0.9702):
[0001069202-14-000006:note_history:23]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2014, we were in compliance with all covenant requirements.

- removed (2014-10-20):
[0001069202-14-000006:note_history:24]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 5.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 203.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 419.8 |  |  | $ | 233.2 |  |
| Total debt | $ | 606.7 |  |  | $ | 400.4 |  |

- removed (2014-10-20):
[0001069202-14-000006:note_history:25]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 180.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- removed (2014-10-20):
[0001069202-14-000006:note_history:26]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $203.0 million as well as $27.6 million committed to standby letters of credit as of June 30, 2014. Subject to covenant limitations, $419.4 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-10-20):
[0001069202-14-000008:note_history:27]
|  | As of September 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 220.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 9.0 |  |  | 5.9 |  |
| Total short-term debt | $ | 229.0 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.7 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 149.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 365.7 |  |  | $ | 233.2 |  |
| Total debt | $ | 596.0 |  |  | $ | 400.4 |  |

- removed (2014-10-20):
[0001069202-14-000006:note_history:28]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 5.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 203.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 419.8 |  |  | $ | 233.2 |  |
| Total debt | $ | 606.7 |  |  | $ | 400.4 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-10-20):
[0001069202-14-000008:note_history:29]
17. Subsequent Events:

- added (2014-10-20):
[0001069202-14-000008:note_history:30]
On October 17, 2014, our Board of Directors authorized an additional $700.0 million towards our Share Repurchase Plans.  This is in addition to the amounts set forth in Note 10 and results in a total of $845.9 million that may be used, subject to certain conditions, under the Share Repurchase Plans.  On October 20, 2014, we announced our plans for a new $450.0 million accelerated share repurchase program in October, 2014.

- added (2014-10-20):
[0001069202-14-000008:note_history:31]
On October 20, 2014, the Company entered into a short term loan agreement (the “Short-Term Facility”) with JPMorgan Chase Bank, N.A. and Morgan Stanley Bank, N.A. to borrow, subject to the satisfaction of specified conditions, up to $250.0 million.  The Short-Term Facility is guaranteed by the same subsidiaries as our Domestic Revolving Credit Facility, and contains substantially similar financial and other covenants as described in Note 7.  The Short-Term Facility will become due on March 31, 2015, and allows for pre-payment. The Company intends to use the borrowings under the Short-Term Facility, along with borrowings under the Domestic Revolving Credit Facility, to fund the expected $450.0 million accelerated share repurchase program.
