# LII 8-K — 0001628280-23-025808 filed 2023-07-27

## item codes, every 8-K on or before 2023-07-27

- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2023-07-27

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-025808:8k_2_02:1]
EX-99.1
2
lii-2023630xexx991pressrel.htm
EX-99.1

[0001628280-23-025808:8k_2_02:2]
Document

[0001628280-23-025808:8k_2_02:3]
Exhibit 99.1

[0001628280-23-025808:8k_2_02:4]
Lennox Reports Record Second Quarter Results and Raises 2023 Guidance

[0001628280-23-025808:8k_2_02:5]
______________________________________________________________________________

[0001628280-23-025808:8k_2_02:6]
Q2 Highlights

[0001628280-23-025808:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-23-025808:8k_2_02:8]
•     Revenue up 3% to $1.41 billion; core revenue excluding European Operations up 3% to $1.34 billion

[0001628280-23-025808:8k_2_02:9]
•     Operating income up 23% to $279 million; adjusted segment profit up 22% to $281 million

[0001628280-23-025808:8k_2_02:10]
•     GAAP diluted EPS up 23% to $6.10; adjusted diluted EPS up 22% to $6.15

[0001628280-23-025808:8k_2_02:11]
•     Operating cash flow up 101% to $196 million

[0001628280-23-025808:8k_2_02:12]
•     Raising 2023 outlook with core revenue up 2% to up 4% and an EPS range of $15.50 to $16.00

[0001628280-23-025808:8k_2_02:13]
_____________________________________________________________________________

[0001628280-23-025808:8k_2_02:14]
DALLAS, July 27, 2023 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported record second quarter revenue of $1.41 billion. Operating income was a record $279 million and operating margin was 19.8%. GAAP diluted earnings per share was a record $6.10.

[0001628280-23-025808:8k_2_02:15]
Core revenue, excluding European Operations, grew 3% to $1.34 billion. Adjusted segment profit rose 22% to $281 million.  Adjusted segment margin was 20.9%, up 320 basis points. Adjusted earnings per share rose 22% to $6.15.

[0001628280-23-025808:8k_2_02:16]
“With record setting results in the second quarter, Lennox once again demonstrates our team’s execution prowess and the benefit of a focused growth strategy,” said Chief Executive Officer Alok Maskara. “Our commercial growth and profit recovery has gained momentum as our team successfully improved manufacturing output to meet robust demand.”

[0001628280-23-025808:8k_2_02:17]
“Strong commercial results offset challenging residential end markets impacted by right sizing of industry inventory levels, post successful transition to the new minimum efficiency standards.” Maskara continued. “Given our record first half performance, we are raising our 2023 earnings and cash flow guidance which reflects our exceptional progress towards delivering our long-term financial targets.”

[0001628280-23-025808:8k_2_02:18]
In the second quarter, Residential segment revenue was down 4% primarily due to continued distributor destocking. Segment profit was down 6% as the impact of lower sales volume was partially offset by favorable pricing and mix. As we start the third quarter, distributor destocking is decelerating, and we expect the recently announced price increase to fuel margin recovery even though factory productivity and output will remain constrained as we right-size our finished goods inventory levels to improve operating cash flow.

[0001628280-23-025808:8k_2_02:19]
The Commercial segment delivered exceptional second-quarter results with revenues up 24% and profits up 150% while maintaining strong backlog. Last year the commercial segment faced manufacturing and supply chain challenges that tempered revenue and delayed pricing actions. This year’s significant improvement in results is driven by improved factory productivity, instituted pricing actions, and product mix benefits. We expect further manufacturing improvements in the second half of this year as our factory output remains below historical levels and our delivery lead times remain extended.

[0001628280-23-025808:8k_2_02:20]
SECOND QUARTER 2023 FINANCIAL HIGHLIGHTS

[0001628280-23-025808:8k_2_02:21]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-23-025808:8k_2_02:22]
Revenue: $1.41 billion; Core revenue, which excludes our European operations, was $1.34 billion, up 3%.  Revenue growth was driven by price and favorable mix and partially offset by lower sales volumes.

[0001628280-23-025808:8k_2_02:23]
Operating Income: $279 million with operating profit margin of 19.8%.

[0001628280-23-025808:8k_2_02:24]
Adjusted Segment Profit: $281 million, up 22%, and adjusted segment profit margin of 20.9%, up 320 basis points. Adjusted segment profit increased $50 million as $106 million of price and mix benefits were partially offset by lower sales volumes and inflationary impacts on SG&A and distribution costs.

[0001628280-23-025808:8k_2_02:25]
Net Income: $217.2 million, or $6.10 per share, compared to $177.2 million, or $4.96 per share, in the prior year quarter.

[0001628280-23-025808:8k_2_02:26]
Adjusted Net Income: $218.8 million, or $6.15 per share, compared to $179.6 million, or $5.03 per share, in the prior year quarter.

[0001628280-23-025808:8k_2_02:27]
Cash: Operating cash flow was $196 million compared to $97 million in the prior-year quarter. Capital expenditures were $49 million compared to $21 million in the prior year quarter with the increase driven by the new Commercial factory investment in Saltillo, Mexico. Total debt at the end of the second quarter was approximately $1.6 billion. Total cash, cash equivalents and short-term investments were $59 million at the end of the quarter.

[0001628280-23-025808:8k_2_02:28]
Residential: Business segment revenue was $936 million, 4% lower than the prior year. Segment Profit was $203 million, down 6%, and segment margin was 21.6%, down 50 basis points. Versus prior year, profit decreased $14 million. The decrease was driven predominately by lower sales volumes of $46 million along with other cost and investment headwinds totaling $8 million, all partially offset with $40 million in pricing and mix benefits.

[0001628280-23-025808:8k_2_02:29]
Commercial: Business segment revenue was $408 million, up 24%. Segment profit was $103 million, up 150%, and segment margin expanded 1,270 basis points to 25.3%.  Segment profit increased $62 million compared to prior year, driven by $66 million of pricing and mix benefits and $3 million generated by higher sales volumes. Inflationary impacts on materials and production costs partially offset these gains.

[0001628280-23-025808:8k_2_02:30]
Corporate and Other: Revenue in the European Refrigeration operations was $67.7 million, up 10%. European operations had $2.4 million in profit compared to a $0.6 million loss in the prior year quarter.  Corporate expenses were $25 million, or down $2 million compared to the prior year quarter.

[0001628280-23-025808:8k_2_02:31]
As previously announced, beginning in 2023 our North American Refrigeration operations are reported in the Commercial Segment and European operations are classified as non-core and included in the Corporate and Other Segment until disposition.

[0001628280-23-025808:8k_2_02:32]
FULL-YEAR 2023 GUIDANCE

[0001628280-23-025808:8k_2_02:33]
For the full year of 2023, we now expect core revenue to be up 2% to up 4% (previous: flat to up 4%) and we expect earnings per share of $15.50 to $16.00 (previous: $14.25 to $15.25).

[0001628280-23-025808:8k_2_02:34]
Based on our record first half performance and confidence in our outlook for the balance of the year, we are updating our free cash flow outlook to include operating cash flow of $550 million to $600 million and capital expenditures of approximately $250 million.

[0001628280-23-025808:8k_2_02:35]
“Our primary focus remains on self-help operational excellence which includes prioritizing pricing excellence and increasing commercial production output, while normalizing inventory levels to further improve cash flow. Looking ahead, we are excited to build on the current momentum to meet or exceed our long-range targets,” Maskara concluded.

[0001628280-23-025808:8k_2_02:36]
CONFERENCE CALL INFORMATION

[0001628280-23-025808:8k_2_02:37]
A conference call to discuss the company’s second-quarter results and 2023 outlook will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-274-8461 (U.S.) or +1 203-518-9765 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ223. The conference call also will be webcast live on the company’s investor relations web site at www.investor.lennox.com. A replay of the conference call will be available until August 10, 2023, by calling toll-free 800-925-9354 (U.S.) or +1 402-220-5384 (international). The call will also be archived on the company's web site.

[0001628280-23-025808:8k_2_02:38]
ABOUT LENNOX

[0001628280-23-025808:8k_2_02:39]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at www.investor.lennox.com or by contacting investor@lennoxintl.com.

[0001628280-23-025808:8k_2_02:40]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001628280-23-025808:8k_2_02:41]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001628280-23-025808:8k_2_02:42]
This document includes forward-looking statements regarding core revenue, segment profit, adjusted segment profit, adjusted net income, adjusted earnings per share and free cash flow which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter

[0001628280-23-025808:8k_2_02:43]
of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. Core revenue excludes net sales from our European portfolio, which we plan to divest.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001628280-23-025808:8k_2_02:44]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-025808:8k_2_02:45]
Consolidated Statements of Operations

[0001628280-23-025808:8k_2_02:46]
(Unaudited)

[0001628280-23-025808:8k_2_02:47]
| (Amounts in millions, except per share data) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,411.4 |  |  | $ | 1,366.3 |  |  | $ | 2,460.7 |  |  | $ | 2,379.7 |  |
| Cost of goods sold | 953.6 |  |  | 969.2 |  |  | 1,696.2 |  |  | 1,714.4 |  |
| Gross profit | 457.8 |  |  | 397.1 |  |  | 764.5 |  |  | 665.3 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 181.3 |  |  | 169.6 |  |  | 348.8 |  |  | 324.9 |  |
| Losses (gains) and other expenses, net | 0.8 |  |  | 1.6 |  |  | 1.1 |  |  | 2.0 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | — |  |  | 1.0 |  |
| Income from equity method investments | (3.1) |  |  | (1.5) |  |  | (3.8) |  |  | (1.4) |  |
| Operating income | 278.8 |  |  | 226.9 |  |  | 418.4 |  |  | 338.8 |  |
| Pension settlements | 0.1 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Interest expense, net | 15.0 |  |  | 8.7 |  |  | 29.2 |  |  | 15.6 |  |
| Other expense (income), net | — |  |  | 0.7 |  |  | — |  |  | 1.2 |  |
| Net income before income taxes | 263.7 |  |  | 217.3 |  |  | 388.9 |  |  | 321.7 |  |
| Provision for income taxes | 46.5 |  |  | 40.1 |  |  | 73.7 |  |  | 60.9 |  |
| Net income | $ | 217.2 |  |  | $ | 177.2 |  |  | $ | 315.2 |  |  | $ | 260.8 |  |
| Earnings per share – Basic: | $ | 6.12 |  |  | $ | 4.97 |  |  | $ | 8.88 |  |  | $ | 7.25 |  |
| Earnings per share – Diluted: | $ | 6.10 |  |  | $ | 4.96 |  |  | $ | 8.85 |  |  | $ | 7.23 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.5 |  |  | 35.6 |  |  | 35.5 |  |  | 36.0 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.6 |  |  | 35.7 |  |  | 35.6 |  |  | 36.1 |  |

[0001628280-23-025808:8k_2_02:48]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001628280-23-025808:8k_2_02:49]
| (Amounts in millions) | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022(2) |  | 2023 |  | 2022(2) |
| Net Sales |  |  |  |  |  |  |  |
| Residential | $ | 936.2 |  |  | $ | 977.5 |  |  | $ | 1,617.2 |  |  | $ | 1,659.6 |  |
| Commercial (2) | 407.5 |  |  | 327.4 |  |  | 716.1 |  |  | 606.9 |  |
| Corporate and other (2) | 67.7 |  |  | 61.4 |  |  | 127.4 |  |  | 113.2 |  |
|  | $ | 1,411.4 |  |  | $ | 1,366.3 |  |  | $ | 2,460.7 |  |  | $ | 2,379.7 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Residential | $ | 202.6 |  |  | $ | 216.3 |  |  | $ | 313.7 |  |  | $ | 324.0 |  |
| Commercial (2) | 103.0 |  |  | 41.2 |  |  | 153.0 |  |  | 64.9 |  |
| Corporate and other (2) | (22.5) |  |  | (27.7) |  |  | (41.9) |  |  | (44.5) |  |
| Total segment profit | 283.1 |  |  | 229.8 |  |  | 424.8 |  |  | 344.4 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) | 4.3 |  |  | $ | 2.4 |  |  | 6.4 |  |  | 4.6 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | — |  |  | 1.0 |  |
| Operating income | $ | 278.8 |  |  | $ | 226.9 |  |  | $ | 418.4 |  |  | $ | 338.8 |  |

[0001628280-23-025808:8k_2_02:50]
(1)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-23-025808:8k_2_02:51]
•The following items in Losses (gains) and other expenses, net:

[0001628280-23-025808:8k_2_02:52]
◦Net change in unrealized losses (gains) on unsettled futures contracts,

[0001628280-23-025808:8k_2_02:53]
◦Environmental liabilities and special litigation charges,  and

[0001628280-23-025808:8k_2_02:54]
◦Other items, net,

[0001628280-23-025808:8k_2_02:55]
•Restructuring charges.

[0001628280-23-025808:8k_2_02:56]
(2) Previously, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio and that we would continue to invest in our Heatcraft Worldwide Refrigeration business, all of which were previously in our Refrigeration segment.  On January 1, 2023, we adjusted our segment presentation to better align with how the segments are managed and evaluated after the change in portfolio.  Heatcraft Worldwide Refrigeration is now part of the Commercial segment while the European portfolio is presented with Corporate and Other until disposition. Amounts presented in this table have been recast to reflect the revised segment presentation.

[0001628280-23-025808:8k_2_02:57]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-025808:8k_2_02:58]
Consolidated Balance Sheets

[0001628280-23-025808:8k_2_02:59]
(Unaudited)

[0001628280-23-025808:8k_2_02:60]
| (Amounts in millions, except shares and par values) | As of June 30, 2023 |  | As of December 31, 2022 |
| ASSETS | (Unaudited) |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 51.4 |  |  | $ | 52.6 |  |
| Short-term investments | 7.2 |  |  | 8.5 |  |
| Accounts and notes receivable, net of allowances of $17.0 and $15.5 in 2023 and 2022, respectively | 843.6 |  |  | 608.5 |  |
| Inventories, net | 856.0 |  |  | 753.0 |  |
| Other assets | 68.6 |  |  | 73.9 |  |
| Total current assets | 1,826.8 |  |  | 1,496.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $953.4 and $920.8 in 2023 and 2022, respectively | 608.5 |  |  | 548.9 |  |
| Right-of-use assets from operating leases | 214.2 |  |  | 219.9 |  |
| Goodwill | 186.4 |  |  | 186.3 |  |
| Deferred income taxes | 46.3 |  |  | 27.5 |  |
| Other assets, net | 99.1 |  |  | 88.5 |  |
| Total assets | $ | 2,981.3 |  |  | $ | 2,567.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current Liabilities: |  |  |  |
| Current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Current operating lease liabilities | 63.2 |  |  | 63.3 |  |
| Accounts payable | 470.1 |  |  | 427.3 |  |
| Accrued expenses | 425.5 |  |  | 376.9 |  |
| Income taxes payable | 21.8 |  |  | 17.6 |  |
| Total current liabilities | 1,741.9 |  |  | 1,595.7 |  |
| Long-term debt | 817.7 |  |  | 814.2 |  |
| Long-term operating lease liabilities | 159.6 |  |  | 161.8 |  |
| Pensions | 39.6 |  |  | 40.1 |  |
| Other liabilities | 159.9 |  |  | 158.9 |  |
| Total liabilities | 2,918.7 |  |  | 2,770.7 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity (deficit): |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,169.3 |  |  | 1,155.2 |  |
| Retained earnings | 3,309.0 |  |  | 3,070.6 |  |
| Accumulated other comprehensive loss | (75.8) |  |  | (90.6) |  |
| Treasury stock, at cost, 51,658,951 shares and 51,700,260 shares for 2023 and 2022, respectively | (4,340.8) |  |  | (4,339.2) |  |
| Total stockholders' equity (deficit) | 62.6 |  |  | (203.1) |  |
| Total liabilities and stockholders' equity (deficit) | $ | 2,981.3 |  |  | $ | 2,567.6 |  |

[0001628280-23-025808:8k_2_02:61]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-23-025808:8k_2_02:62]
Consolidated Statements of Cash Flows

[0001628280-23-025808:8k_2_02:63]
(Unaudited)

[0001628280-23-025808:8k_2_02:64]
| (Amounts in millions) | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 315.2 |  |  | $ | 260.8 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Income from equity method investments | (3.8) |  |  | (1.4) |  |
| Restructuring charges, net of cash paid | — |  |  | 0.5 |  |
| Provision for credit losses | 3.8 |  |  | 2.7 |  |
| Unrealized losses, net on derivative contracts | 3.9 |  |  | 2.0 |  |
| Stock-based compensation expense | 13.8 |  |  | 10.6 |  |
| Depreciation and amortization | 40.5 |  |  | 37.8 |  |
| Deferred income taxes | (18.9) |  |  | (11.6) |  |
| Pension expense | 1.4 |  |  | 3.5 |  |
| Pension contributions | (2.0) |  |  | (0.5) |  |
| Other items, net | (1.2) |  |  | (0.9) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts and notes receivable | (236.5) |  |  | (281.6) |  |
| Inventories | (100.4) |  |  | (187.3) |  |
| Other current assets | 8.7 |  |  | 1.2 |  |
| Accounts payable | 45.4 |  |  | 93.7 |  |
| Accrued expenses | 45.6 |  |  | 14.8 |  |
| Income taxes payable and receivable, net | 4.1 |  |  | 39.4 |  |
| Leases, net | 3.3 |  |  | 0.9 |  |
| Other, net | (6.2) |  |  | 14.6 |  |
| Net cash provided by (used in) operating activities | 116.7 |  |  | (0.8) |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 1.5 |  |  | 0.5 |  |
| Purchases of property, plant and equipment | (85.3) |  |  | (46.7) |  |
| Proceeds from short-term investments, net | 1.5 |  |  | — |  |
| Net cash used in investing activities | (82.3) |  |  | (46.2) |  |
| Cash flows from financing activities: |  |  |  |
| Asset securitization borrowings | 140.0 |  |  | 211.0 |  |
| Asset securitization payments | (90.0) |  |  | (61.0) |  |
| Long-term debt payments | (7.3) |  |  | (6.4) |  |
| Borrowings from credit facility | 1,182.0 |  |  | 1,331.0 |  |
| Payments on credit facility | (1,182.0) |  |  | (1,029.0) |  |
| Proceeds from employee stock purchases | 1.9 |  |  | 1.8 |  |
| Repurchases of common stock | — |  |  | (300.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (3.2) |  |  | (5.1) |  |
| Cash dividends paid | (75.2) |  |  | (66.9) |  |
| Net cash (used in) provided by financing activities | (33.8) |  |  | 75.4 |  |
| Increase in cash and cash equivalents | 0.6 |  |  | 28.4 |  |
| Effect of exchange rates on cash and cash equivalents | (1.8) |  |  | (2.0) |  |
| Cash and cash equivalents, beginning of period | 52.6 |  |  | 31.0 |  |
| Cash and cash equivalents, end of period | $ | 51.4 |  |  | $ | 57.4 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 27.1 |  |  | $ | 14.2 |  |
| Income taxes paid (net of refunds) | $ | 88.4 |  |  | $ | 32.9 |  |

[0001628280-23-025808:8k_2_02:65]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio. The results from operations for these businesses have been shown in the tables below as "Non-Core business results." The prior period results have been updated to provide period-over-period comparability. |  |  |
| Reconciliation of Net income, a GAAP measure, to Adjusted Net income, a Non-GAAP measure |  |  |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |  |  |  |  |
| Net income, a GAAP measure | $ | 217.2 |  | $ | 6.10 |  |  | $ | 177.2 |  | $ | 4.96 |  |  | $ | 315.2 |  | $ | 8.85 |  |  | $ | 260.8 |  | $ | 7.23 |  |  |  |  |  |  |  |
| Restructuring charges | — |  | — |  |  | 0.4 |  | 0.01 |  |  | — |  | — |  |  | 0.8 |  | 0.02 |  |  |  |  |  |  |  |
| Pension settlements | 0.1 |  | — |  |  | 0.1 |  | — |  |  | 0.3 |  | 0.01 |  |  | 0.2 |  | 0.01 |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) | 2.9 |  | 0.09 |  |  | 2.0 |  | 0.06 |  |  | 3.5 |  | 0.10 |  |  | 3.7 |  | 0.10 |  |  |  |  |  |  |  |
| Excess tax (benefit) expense from share-based compensation (b) | (0.1) |  | — |  |  | 0.1 |  | — |  |  | (0.1) |  | — |  |  | 0.5 |  | 0.01 |  |  |  |  |  |  |  |
| Other tax items, net (b) | 0.1 |  | — |  |  | (1.4) |  | (0.03) |  |  | 0.4 |  | 0.01 |  |  | (1.4) |  | (0.04) |  |  |  |  |  |  |  |
| Non-core business results (c) | (1.4) |  | (0.04) |  |  | 1.2 |  | 0.03 |  |  | — |  | — |  |  | 4.9 |  | 0.14 |  |  |  |  |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 218.8 |  | $ | 6.15 |  |  | $ | 179.6 |  | $ | 5.03 |  |  | $ | 319.3 |  | $ | 8.97 |  |  | $ | 269.5 |  | $ | 7.47 |  |  |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (c) Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-23-025808:8k_2_02:66]
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Average shares outstanding - diluted, a GAAP measure | 35.6 |  | 35.7 |  |  | 35.6 |  | 36.1 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 35.6 |  | 35.7 |  |  | 35.6 |  | 36.1 |  |
| Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net cash provided by (used in) operating activities | $ | 195.5 |  |  | $ | 97.1 |  |  | $ | 116.7 |  |  | $ | (0.8) |  |
| Purchases of property, plant and equipment | (49.9) |  |  | (20.9) |  |  | (85.3) |  |  | (46.7) |  |
| Proceeds from the disposal of property, plant and equipment | 1.2 |  |  | 0.2 |  |  | 1.5 |  |  | 0.5 |  |
| Free cash flow, a Non-GAAP measure | $ | 146.8 |  |  | $ | 76.4 |  |  | $ | 32.9 |  |  | $ | (47.0) |  |

[0001628280-23-025808:8k_2_02:67]
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Three Months Ended June 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 67.7 |  |  | $ | 61.4 |  |  | $ | 1,411.4 |  |  | $ | 1,366.3 |  |
| Net sales from non-core businesses (a) | (67.7) |  |  | (61.4) |  |  | (67.7) |  |  | (61.4) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 1,343.7 |  |  | $ | 1,304.9 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Six Months Ended June 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 127.4 |  |  | $ | 113.2 |  |  | $ | 2,460.7 |  |  | $ | 2,379.7 |  |
| Net sales from non-core businesses (a) | (127.4) |  |  | (113.2) |  |  | (127.4) |  |  | (113.2) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 2,333.3 |  |  | $ | 2,266.5 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
| Reconciliation of Segment profit (loss), a Non-GAAP measure to Adjusted Segment profit (loss), a Non-GAAP measure |
|  | For the Three Months Ended June 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (22.5) |  |  | $ | (27.7) |  |  | $ | 283.1 |  |  | $ | 229.8 |  |
| Profit (loss) from non-core businesses (a) | 2.4 |  |  | (0.6) |  |  | 2.4 |  |  | (0.6) |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (24.9) |  |  | $ | (27.1) |  |  | $ | 280.7 |  |  | $ | 230.4 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Six Months Ended June 30, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (41.9) |  |  | $ | (44.5) |  |  | $ | 424.8 |  |  | $ | 344.4 |  |
| Profit (loss) from non-core businesses (a) | 2.1 |  |  | (4.0) |  |  | 2.1 |  |  | (4.0) |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (44.0) |  |  | $ | (40.5) |  |  | $ | 422.7 |  |  | $ | 348.4 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
