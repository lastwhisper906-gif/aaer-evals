# LII note change history — 0001628280-23-013427 → 0001628280-23-025847


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001628280-23-025847:note_history:1]
4. Commitments and Contingencies:

- changed (2023-07-27):
[0001628280-23-025847:note_history:2]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.
  (was, 2023-04-27, similarity 0.802):
[0001628280-23-013427:note_history:2]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To

- changed (2023-07-27):
[0001628280-23-025847:note_history:3]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Accrued expenses | $ | 44.2 |  |  | $ | 41.3 |  |
| Other liabilities | 102.5 |  |  | 101.4 |  |
| Total warranty liability | $ | 146.7 |  |  | $ | 142.7 |  |
  (was, 2023-04-27, similarity 0.9741):
[0001628280-23-013427:note_history:3]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Accrued expenses | $ | 42.3 |  |  | $ | 41.3 |  |
| Other liabilities | 103.0 |  |  | 101.4 |  |
| Total warranty liability | $ | 145.3 |  |  | $ | 142.7 |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:4]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2023 were as follows (in millions):
  (was, 2023-04-27, similarity 0.9404):
[0001628280-23-013427:note_history:4]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2023 were as follows (in millions):

- changed (2023-07-27):
[0001628280-23-025847:note_history:5]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (19.3) |  |
| Changes resulting from issuance of new warranties | 28.5 |  |
| Changes in estimates associated with pre-existing liabilities | (5.5) |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of June 30, 2023 | $ | 146.7 |  |
  (was, 2023-04-27, similarity 0.9869):
[0001628280-23-013427:note_history:5]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (8.0) |  |
| Changes resulting from issuance of new warranties | 11.1 |  |
| Changes in estimates associated with pre-existing liabilities | (0.6) |  |
| Changes in foreign currency translation rates and other | 0.1 |  |
| Total warranty liability as of March 31, 2023 | $ | 145.3 |  |

- removed (2023-07-27):
[0001628280-23-013427:note_history:6]
estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001628280-23-025847:note_history:7]
1. General:

- changed (2023-07-27):
[0001628280-23-025847:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and six months ended June 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.
  (was, 2023-04-27, similarity 0.7952):
[0001628280-23-013427:note_history:8]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2023, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001628280-23-025847:note_history:9]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.46 | % |  | 5.57 | % |
  (was, 2023-04-27, similarity 0.9538):
[0001628280-23-013427:note_history:9]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.06 | % |  | 5.57 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001628280-23-025847:note_history:10]
10. Lines of Credit and Financing Arrangements:

- changed (2023-07-27):
[0001628280-23-025847:note_history:11]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.5 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.0 |  |  | 28.3 |  |
| Credit agreement | 192.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 817.7 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,579.0 |  |  | $ | 1,524.8 |  |
  (was, 2023-04-27, similarity 0.9927):
[0001628280-23-013427:note_history:11]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 297.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 10.9 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.4) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 657.5 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 28.3 |  |
| Credit agreement | 388.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.7) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,010.1 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,667.6 |  |  | $ | 1,524.8 |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2023.
  (was, 2023-04-27, similarity 0.9049):
[0001628280-23-013427:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2023.

- changed (2023-07-27):
[0001628280-23-025847:note_history:13]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (350.0) |  |
| Remaining amount available | $ | — |  |  | $ | — |  |
  (was, 2023-04-27, similarity 0.9354):
[0001628280-23-013427:note_history:13]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 297.3 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | (297.0) |  |  | (350.0) |  |
| Remaining amount available | $ | 0.3 |  |  | $ | — |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2023 and December 31, 2022 were 5.98% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2023-04-27, similarity 0.9944):
[0001628280-23-013427:note_history:14]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2023 and December 31, 2022 were 5.58% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2023-07-27):
[0001628280-23-025847:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of June 30, 2023, we were in compliance with all covenant requirements.
  (was, 2023-04-27, similarity 0.9804):
[0001628280-23-013427:note_history:15]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of March 31, 2023, we believe we were in compliance with all covenant requirements.

- changed (2023-07-27):
[0001628280-23-025847:note_history:16]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $192.0 million as well as $1.7 million committed to standby letters of credit as of June 30, 2023. Subject to covenant limitations, $556.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2023-04-27, similarity 0.9924):
[0001628280-23-013427:note_history:16]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $388.0 million as well as $2.0 million committed to standby letters of credit as of March 31, 2023. Subject to covenant limitations, $360.0 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2023-07-27):
[0001628280-23-025847:note_history:17]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.46 | % |  | 5.57 | % |
  (was, 2023-04-27, similarity 0.9538):
[0001628280-23-013427:note_history:17]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.06 | % |  | 5.57 | % |

- changed (2023-07-27):
[0001628280-23-025847:note_history:18]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2023, we were in compliance with all covenant requirements.
  (was, 2023-04-27, similarity 0.9811):
[0001628280-23-013427:note_history:18]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2023, we believe we were in compliance with all covenant requirements.

- changed (2023-07-27):
[0001628280-23-025847:note_history:19]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2023, we believe we were in compliance with all covenant requirements.
  (was, 2023-04-27, similarity 0.9965):
[0001628280-23-013427:note_history:19]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2023, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001628280-23-025847:note_history:20]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.5 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.0 |  |  | 28.3 |  |
| Credit agreement | 192.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 817.7 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,579.0 |  |  | $ | 1,524.8 |  |
  (was, 2023-04-27, similarity 0.9927):
[0001628280-23-013427:note_history:20]
|  | As of March 31, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 297.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 10.9 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.4) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 657.5 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 28.3 |  |
| Credit agreement | 388.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.7) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,010.1 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,667.6 |  |  | $ | 1,524.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001628280-23-025847:note_history:21]
6. Revenue Recognition:

- changed (2023-07-27):
[0001628280-23-025847:note_history:22]
|  | For the Three Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 868.5 |  |  | $ | 382.2 |  |  | $ | — |  |  | $ | 1,250.7 |  |
| Canada | 67.7 |  |  | 25.3 |  |  | — |  |  | 93.0 |  |
| Other international | — |  |  | — |  |  | 67.7 |  |  | 67.7 |  |
| Total | $ | 936.2 |  |  | $ | 407.5 |  |  | $ | 67.7 |  |  | $ | 1,411.4 |  |
  (was, 2023-04-27, similarity 0.6797):
[0001628280-23-013427:note_history:22]
|  | For the Three Months Ended March 31, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 639.3 |  |  | $ | 294.6 |  |  | $ | — |  |  | $ | 933.9 |  |
| Canada | 41.7 |  |  | 14.1 |  |  | — |  |  | 55.8 |  |
| Other international | — |  |  | — |  |  | 59.7 |  |  | 59.7 |  |
| Total | $ | 681.0 |  |  | $ | 308.7 |  |  | $ | 59.7 |  |  | $ | 1,049.4 |  |

- added (2023-07-27):
[0001628280-23-025847:note_history:23]
|  | For the Three Months Ended June 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 901.8 |  |  | $ | 315.0 |  |  | $ | — |  |  | $ | 1,216.8 |  |
| Canada | 75.7 |  |  | 12.4 |  |  | — |  |  | 88.1 |  |
| Other international | — |  |  | — |  |  | 61.4 |  |  | 61.4 |  |
| Total | $ | 977.5 |  |  | $ | 327.4 |  |  | $ | 61.4 |  |  | $ | 1,366.3 |  |

- added (2023-07-27):
[0001628280-23-025847:note_history:24]
|  | For the Six Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,507.8 |  |  | $ | 676.7 |  |  | $ | — |  |  | $ | 2,184.5 |  |
| Canada | 109.4 |  |  | 39.4 |  |  | — |  |  | 148.8 |  |
| Other international | — |  |  | — |  |  | 127.4 |  |  | 127.4 |  |
| Total | $ | 1,617.2 |  |  | $ | 716.1 |  |  | $ | 127.4 |  |  | $ | 2,460.7 |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:25]
|  | For the Six Months Ended June 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,531.4 |  |  | $ | 583.6 |  |  | $ | — |  |  | $ | 2,115.0 |  |
| Canada | 128.2 |  |  | 22.8 |  |  | — |  |  | 151.0 |  |
| Other international | — |  |  | 0.5 |  |  | 113.2 |  |  | 113.7 |  |
| Total | $ | 1,659.6 |  |  | $ | 606.9 |  |  | $ | 113.2 |  |  | $ | 2,379.7 |  |
  (was, 2023-04-27, similarity 0.6231):
[0001628280-23-013427:note_history:25]
|  | For the Three Months Ended March 31,2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 629.7 |  |  | $ | 268.6 |  |  | $ | — |  |  | $ | 898.3 |  |
| Canada | 52.5 |  |  | 10.4 |  |  | — |  |  | 62.9 |  |
| Other international | — |  |  | 0.5 |  |  | 51.7 |  |  | 52.2 |  |
| Total | $ | 682.2 |  |  | $ | 279.5 |  |  | $ | 51.7 |  |  | $ | 1,013.4 |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:26]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and six months ended June 30, 2022 have been recast to reflect the revised segment presentation.
  (was, 2023-04-27, similarity 0.9296):
[0001628280-23-013427:note_history:26]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three months ended March 31, 2022 have been recast to reflect the revised segment presentation.

- changed (2023-07-27):
[0001628280-23-025847:note_history:27]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2023 and 2022, direct sales represented 76% and 70% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2023 and 2022, direct sales represented 73% and 69% of revenues, and sales to independent distributors represented the remainder.
  (was, 2023-04-27, similarity 0.8991):
[0001628280-23-013427:note_history:27]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2023 and 2022, direct sales represented 70% and 66% of revenues, and sales to independent distributors represented the remainder.

- changed (2023-07-27):
[0001628280-23-025847:note_history:28]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well
  (was, 2023-04-27, similarity 0.7113):
[0001628280-23-013427:note_history:28]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended March 31, 2023 and 2022, equipment sales represented 85% and 87% of revenues and the remainder of our revenue was generated from our service business.

- added (2023-07-27):
[0001628280-23-025847:note_history:29]
as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended June 30, 2023 and 2022, equipment sales represented 87% and 88% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2023 and 2022, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business.

- changed (2023-07-27):
[0001628280-23-025847:note_history:30]
|  | As of June 30, 2023 |  | As of December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (13.4) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.9) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (20.3) |  |  | $ | (16.0) |  |  |  |  |  |
  (was, 2023-04-27, similarity 0.9169):
[0001628280-23-013427:note_history:30]
|  | March 31, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (12.5) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.7) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (19.2) |  |  | $ | (16.0) |  |  |  |  |  |

- changed (2023-07-27):
[0001628280-23-025847:note_history:31]
For the three months ended June 30, 2023 and 2022, we recognized revenue of $1.2 million and $2.1 million and for the six months ended we recognized revenue of $4.2 million and $5.9 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.
  (was, 2023-04-27, similarity 0.8174):
[0001628280-23-013427:note_history:31]
For the three months ended March 31, 2023 and 2022, we recognized revenue of $3.0 million and $3.7 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2023 and 2022.
