# LII notes — 0001628280-23-025847


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-025847:notes:1]
1. General:

[0001628280-23-025847:notes:2]
[same as prior period, unchanged from 0001628280-23-013427:notes:1]

[0001628280-23-025847:notes:3]
[same as prior period, unchanged from 0001628280-23-013427:notes:2]

[0001628280-23-025847:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and six months ended June 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.

[0001628280-23-025847:notes:5]
[same as prior period, unchanged from 0001628280-23-013427:notes:4]

[0001628280-23-025847:notes:6]
[same as prior period, unchanged from 0001628280-23-013427:notes:5]

[0001628280-23-025847:notes:7]
[same as prior period, unchanged from 0001628280-23-013427:notes:6]

[0001628280-23-025847:notes:8]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses. Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment. 
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-025847:notes:9]
2. Reportable Business Segments:

[0001628280-23-025847:notes:10]
[same as prior period, unchanged from 0001628280-23-013427:notes:8]

[0001628280-23-025847:notes:11]
[same as prior period, unchanged from 0001628280-23-013427:notes:9]

[0001628280-23-025847:notes:12]
Prior to January 1, 2023, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses. We will continue to invest in our Heatcraft Worldwide Refrigeration business which became part of the Commercial segment effective on January 1, 2023 while the European portfolio will be presented with Corporate and Other until disposition. The consolidation of our Heatcraft business within the Commercial segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio. Recast Segment Results were presented in our March 31, 2023 Form 10-Q for both the previously presented segment results as well as the recast financial information to reflect the change in our segment presentation.

[0001628280-23-025847:notes:13]
[same as prior period, unchanged from 0001628280-23-013427:notes:11]

[0001628280-23-025847:notes:14]
[same as prior period, unchanged from 0001628280-23-013427:notes:12]

[0001628280-23-025847:notes:15]
Segment Net Sales and Profit (Loss)

[0001628280-23-025847:notes:16]
[same as prior period, unchanged from 0001628280-23-013427:notes:14]

[0001628280-23-025847:notes:17]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 (2) |  | 2023 |  | 2022 (2) |
| Net sales |  |  |  |  |  |  |  |
| Residential | $ | 936.2 |  |  | $ | 977.5 |  |  | $ | 1,617.2 |  |  | $ | 1,659.6 |  |
| Commercial (2) | 407.5 |  |  | 327.4 |  |  | 716.1 |  |  | 606.9 |  |
| Corporate and other (2) | 67.7 |  |  | 61.4 |  |  | 127.4 |  |  | 113.2 |  |
|  | $ | 1,411.4 |  |  | $ | 1,366.3 |  |  | $ | 2,460.7 |  |  | $ | 2,379.7 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential | $ | 202.6 |  |  | $ | 216.3 |  |  | $ | 313.7 |  |  | $ | 324.0 |  |
| Commercial (2) | 103.0 |  |  | 41.2 |  |  | 153.0 |  |  | 64.9 |  |
| Corporate and other (2) | (22.5) |  |  | (27.7) |  |  | (41.9) |  |  | (44.5) |  |
| Total segment profit | 283.1 |  |  | 229.8 |  |  | 424.8 |  |  | 344.4 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 4.3 |  |  | 2.4 |  |  | 6.4 |  |  | 4.6 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | — |  |  | 1.0 |  |
| Operating income | $ | 278.8 |  |  | $ | 226.9 |  |  | $ | 418.4 |  |  | $ | 338.8 |  |

[0001628280-23-025847:notes:18]
[same as prior period, unchanged from 0001628280-23-013427:notes:16]

[0001628280-23-025847:notes:19]
[same as prior period, unchanged from 0001628280-23-013427:notes:17]

[0001628280-23-025847:notes:20]
▪Net change in unrealized losses (gains) on unsettled futures contracts,

[0001628280-23-025847:notes:21]
▪Environmental liabilities and special litigation charges,  and

[0001628280-23-025847:notes:22]
[same as prior period, unchanged from 0001628280-23-013427:notes:21]

[0001628280-23-025847:notes:23]
◦Restructuring charges.
(2) 2022 results have been recast to reflect the realignment of our reportable segments.


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-025847:notes:24]
3. Earnings Per Share:

[0001628280-23-025847:notes:25]
[same as prior period, unchanged from 0001628280-23-013427:notes:28]

[0001628280-23-025847:notes:26]
[same as prior period, unchanged from 0001628280-23-013427:notes:29]

[0001628280-23-025847:notes:27]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income | $ | 217.2 |  |  | $ | 177.2 |  |  | $ | 315.2 |  |  | $ | 260.8 |  |
| Weighted-average shares outstanding – basic | 35.5 |  |  | 35.6 |  |  | 35.5 |  |  | 36.0 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares outstanding – diluted | 35.6 |  |  | 35.7 |  |  | 35.6 |  |  | 36.1 |  |
| Earnings per share – Basic: | $ | 6.12 |  |  | $ | 4.97 |  |  | $ | 8.88 |  |  | $ | 7.25 |  |
| Earnings per share – Diluted: | $ | 6.10 |  |  | $ | 4.96 |  |  | $ | 8.85 |  |  | $ | 7.23 |  |

[0001628280-23-025847:notes:28]
[same as prior period, unchanged from 0001628280-23-013427:notes:31]

[0001628280-23-025847:notes:29]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted-average number of shares | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | 0.3 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-025847:notes:30]
4. Commitments and Contingencies:

[0001628280-23-025847:notes:31]
Leases

[0001628280-23-025847:notes:32]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-23-025847:notes:33]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-23-025847:notes:34]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various periods (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-23-025847:notes:35]
We lease certain real and personal property under non-cancelable operating leases. Approximately 81% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-23-025847:notes:36]
Product Warranties and Product Related Contingencies

[0001628280-23-025847:notes:37]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-23-025847:notes:38]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-23-025847:notes:39]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Accrued expenses | $ | 44.2 |  |  | $ | 41.3 |  |
| Other liabilities | 102.5 |  |  | 101.4 |  |
| Total warranty liability | $ | 146.7 |  |  | $ | 142.7 |  |

[0001628280-23-025847:notes:40]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2023 were as follows (in millions):

[0001628280-23-025847:notes:41]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (19.3) |  |
| Changes resulting from issuance of new warranties | 28.5 |  |
| Changes in estimates associated with pre-existing liabilities | (5.5) |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of June 30, 2023 | $ | 146.7 |  |

[0001628280-23-025847:notes:42]
Litigation

[0001628280-23-025847:notes:43]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-23-025847:notes:44]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-025847:notes:45]
5. Stock Repurchases:Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of June 30, 2023, $546 million was available for repurchase under the Share Repurchase Plans.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-025847:notes:46]
6. Revenue Recognition:

[0001628280-23-025847:notes:47]
[same as prior period, unchanged from 0001628280-23-013427:notes:50]

[0001628280-23-025847:notes:48]
|  | For the Three Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 868.5 |  |  | $ | 382.2 |  |  | $ | — |  |  | $ | 1,250.7 |  |
| Canada | 67.7 |  |  | 25.3 |  |  | — |  |  | 93.0 |  |
| Other international | — |  |  | — |  |  | 67.7 |  |  | 67.7 |  |
| Total | $ | 936.2 |  |  | $ | 407.5 |  |  | $ | 67.7 |  |  | $ | 1,411.4 |  |

[0001628280-23-025847:notes:49]
|  | For the Three Months Ended June 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 901.8 |  |  | $ | 315.0 |  |  | $ | — |  |  | $ | 1,216.8 |  |
| Canada | 75.7 |  |  | 12.4 |  |  | — |  |  | 88.1 |  |
| Other international | — |  |  | — |  |  | 61.4 |  |  | 61.4 |  |
| Total | $ | 977.5 |  |  | $ | 327.4 |  |  | $ | 61.4 |  |  | $ | 1,366.3 |  |

[0001628280-23-025847:notes:50]
|  | For the Six Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,507.8 |  |  | $ | 676.7 |  |  | $ | — |  |  | $ | 2,184.5 |  |
| Canada | 109.4 |  |  | 39.4 |  |  | — |  |  | 148.8 |  |
| Other international | — |  |  | — |  |  | 127.4 |  |  | 127.4 |  |
| Total | $ | 1,617.2 |  |  | $ | 716.1 |  |  | $ | 127.4 |  |  | $ | 2,460.7 |  |

[0001628280-23-025847:notes:51]
|  | For the Six Months Ended June 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,531.4 |  |  | $ | 583.6 |  |  | $ | — |  |  | $ | 2,115.0 |  |
| Canada | 128.2 |  |  | 22.8 |  |  | — |  |  | 151.0 |  |
| Other international | — |  |  | 0.5 |  |  | 113.2 |  |  | 113.7 |  |
| Total | $ | 1,659.6 |  |  | $ | 606.9 |  |  | $ | 113.2 |  |  | $ | 2,379.7 |  |

[0001628280-23-025847:notes:52]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and six months ended June 30, 2022 have been recast to reflect the revised segment presentation.

[0001628280-23-025847:notes:53]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2023 and 2022, direct sales represented 76% and 70% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2023 and 2022, direct sales represented 73% and 69% of revenues, and sales to independent distributors represented the remainder.

[0001628280-23-025847:notes:54]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well

[0001628280-23-025847:notes:55]
as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended June 30, 2023 and 2022, equipment sales represented 87% and 88% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2023 and 2022, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-23-025847:notes:56]
Corporate and Other - In Europe, we manufacture and market equipment for the global commercial refrigeration markets.  We also manufacture and sell unitary heating and cooling products and applied systems. A de minimis amount of segment revenue relates to services for start-up and commissioning activities.

[0001628280-23-025847:notes:57]
[same as prior period, unchanged from 0001628280-23-013427:notes:57]

[0001628280-23-025847:notes:58]
|  | As of June 30, 2023 |  | As of December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (13.4) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.9) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (20.3) |  |  | $ | (16.0) |  |  |  |  |  |

[0001628280-23-025847:notes:59]
For the three months ended June 30, 2023 and 2022, we recognized revenue of $1.2 million and $2.1 million and for the six months ended we recognized revenue of $4.2 million and $5.9 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-025847:notes:60]
7. Other Financial Statement Details:

[0001628280-23-025847:notes:61]
[same as prior period, unchanged from 0001628280-23-013427:notes:60]

[0001628280-23-025847:notes:62]
[same as prior period, unchanged from 0001628280-23-013427:notes:61]

[0001628280-23-025847:notes:63]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Finished goods | $ | 601.3 |  |  | $ | 534.6 |  |
| Work in process | 10.6 |  |  | 8.9 |  |
| Raw materials and parts | 367.4 |  |  | 328.7 |  |
| Subtotal | 979.3 |  |  | 872.2 |  |
| Excess of current cost over last-in, first-out cost | (123.3) |  |  | (119.2) |  |
| Total inventories, net | $ | 856.0 |  |  | $ | 753.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-025847:notes:64]
[same as prior period, unchanged from 0001628280-23-013427:notes:63]

[0001628280-23-025847:notes:65]
[same as prior period, unchanged from 0001628280-23-013427:notes:64]

[0001628280-23-025847:notes:66]
|  | Balance as of December 31, 2022 |  | Goodwill Reallocation (1) |  | Changes in foreign currency translation rates |  | Balance as of June 30, 2023 |
| Residential | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial (1) | 61.1 |  |  | 94.5 |  |  | — |  |  | 155.6 |  |
| Refrigeration (1) | 99.1 |  |  | (99.1) |  |  | — |  |  | $ | — |  |
| Corporate and Other (1) | — |  |  | 4.6 |  |  | 0.1 |  |  | 4.7 |  |
| Total Goodwill | $ | 186.3 |  |  | $ | — |  |  | $ | 0.1 |  |  | 186.4 |  |

[0001628280-23-025847:notes:67]
(1) As discussed in Note 2, we recast our segment presentation to present our Heatcraft Worldwide Refrigeration business as a component of our Commercial segment and our European portfolio as a component of Corporate & Other.  Since there is no longer a Refrigeration segment, we allocated goodwill to each segment based upon the relative fair value of the business.

[0001628280-23-025847:notes:68]
We monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  We have not recorded any goodwill impairments for the six months ended June 30, 2023 or in any periods presented.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-23-025847:notes:69]
[same as prior period, unchanged from 0001628280-23-013427:notes:67]

[0001628280-23-025847:notes:70]
[same as prior period, unchanged from 0001628280-23-013427:notes:68]

[0001628280-23-025847:notes:71]
Commodity Price Risk - We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term and lower percentages are hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001628280-23-025847:notes:72]
[same as prior period, unchanged from 0001628280-23-013427:notes:71]

[0001628280-23-025847:notes:73]
[same as prior period, unchanged from 0001628280-23-013427:notes:72]

[0001628280-23-025847:notes:74]
[same as prior period, unchanged from 0001628280-23-013427:notes:73]

[0001628280-23-025847:notes:75]
[same as prior period, unchanged from 0001628280-23-013427:notes:74]

[0001628280-23-025847:notes:76]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Unrealized losses (gains), net on unsettled contracts | $ | 5.4 |  |  | $ | 6.3 |  |
| Income tax (benefit) expense | (1.0) |  |  | (1.4) |  |
| Unrealized losses (gains), net included in AOCL, net of tax (1) | $ | 4.4 |  |  | $ | 4.9 |  |

[0001628280-23-025847:notes:77]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $3.9 million of derivative losses as of June 30, 2023 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-025847:notes:78]
[same as prior period, unchanged from 0001628280-23-013427:notes:77]

[0001628280-23-025847:notes:79]
We issue various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights under the Lennox International Inc. 2019 Equity and Incentive Plan, as it may be amended and restated from time to time. Stock-based compensation expense related to continuing operations is included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001628280-23-025847:notes:80]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Stock-based compensation expense | $ | 7.7 |  |  | $ | 5.9 |  |  | $ | 13.8 |  |  | $ | 10.6 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-23-025847:notes:81]
8. Pension Benefit Plans:

[0001628280-23-025847:notes:82]
The components of net periodic benefit cost for pension benefits were as follows (in millions):

[0001628280-23-025847:notes:83]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost | $ | 0.5 |  |  | $ | 1.1 |  |  | $ | 1.1 |  |  | $ | 2.1 |  |
| Interest cost | 2.2 |  |  | 1.5 |  |  | 4.5 |  |  | 3.0 |  |
| Expected return on plan assets | (2.4) |  |  | (2.3) |  |  | (4.7) |  |  | (4.6) |  |
| Recognized actuarial loss | 0.2 |  |  | 1.3 |  |  | 0.4 |  |  | 2.9 |  |
| Other | — |  |  | — |  |  | (0.3) |  |  | (0.1) |  |
| Settlements and curtailments | 0.1 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Net periodic benefit cost | $ | 0.6 |  |  | $ | 1.8 |  |  | $ | 1.3 |  |  | $ | 3.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-025847:notes:84]
9. Income Taxes:

[0001628280-23-025847:notes:85]
As of June 30, 2023, we had approximately $3.9 million in total gross unrecognized tax benefits which, if recognized, would be recorded through the Consolidated Statements of Operations.

[0001628280-23-025847:notes:86]
We are currently in the Bridge program for our U.S. federal income taxes under the Internal Revenue Service’s Compliance Assurance Program for 2022 and 2021.  We are also subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2016.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-025847:notes:87]
10. Lines of Credit and Financing Arrangements:

[0001628280-23-025847:notes:88]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-23-025847:notes:89]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.5 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.0 |  |  | 28.3 |  |
| Credit agreement | 192.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 817.7 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,579.0 |  |  | $ | 1,524.8 |  |

[0001628280-23-025847:notes:90]
Foreign Obligations

[0001628280-23-025847:notes:91]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2023.

[0001628280-23-025847:notes:92]
Asset Securitization Program

[0001628280-23-025847:notes:93]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-23-025847:notes:94]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001628280-23-025847:notes:95]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (350.0) |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

[0001628280-23-025847:notes:96]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2023 and December 31, 2022 were 5.98% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-23-025847:notes:97]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of June 30, 2023, we were in compliance with all covenant requirements.

[0001628280-23-025847:notes:98]
Credit Agreement

[0001628280-23-025847:notes:99]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-23-025847:notes:100]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $192.0 million as well as $1.7 million committed to standby letters of credit as of June 30, 2023. Subject to covenant limitations, $556.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-23-025847:notes:101]
Our weighted average borrowing rate on the facility was as follows:

[0001628280-23-025847:notes:102]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.46 | % |  | 5.57 | % |

[0001628280-23-025847:notes:103]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or

[0001628280-23-025847:notes:104]
substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-23-025847:notes:105]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitization (cross default), and bankruptcy. A cross default under our Credit Agreement could occur if:

[0001628280-23-025847:notes:106]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-23-025847:notes:107]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-23-025847:notes:108]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Credit Agreement, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-23-025847:notes:109]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2023, we were in compliance with all covenant requirements.

[0001628280-23-025847:notes:110]
Senior Unsecured Notes

[0001628280-23-025847:notes:111]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2023, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-025847:notes:112]
11. Comprehensive Income (Loss):

[0001628280-23-025847:notes:113]
[same as prior period, unchanged from 0001628280-23-013427:notes:107]

[0001628280-23-025847:notes:114]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Gains (Losses) on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | — |  |  | $ | 8.8 |  |  | $ | (0.4) |  |  | $ | 16.2 |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax (expense) benefit |  | — |  |  | (2.1) |  |  | 0.1 |  |  | (3.7) |  |  | Provision for income taxes |
| Net of tax |  | $ | — |  |  | $ | 6.7 |  |  | $ | (0.3) |  |  | $ | 12.5 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (0.2) |  |  | $ | (1.4) |  |  | $ | (0.4) |  |  | $ | (2.9) |  |  | Other expense (income), net |
| Pension settlements |  | (0.1) |  |  | (0.2) |  |  | (0.3) |  |  | (0.3) |  |  | Pension settlements |
| Income tax benefit |  | 0.1 |  |  | 0.4 |  |  | 0.2 |  |  | 0.8 |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.2) |  |  | $ | (1.2) |  |  | $ | (0.5) |  |  | $ | (2.4) |  |  |  |
| Total reclassifications from AOCL |  | $ | (0.2) |  |  | $ | 5.5 |  |  | $ | (0.8) |  |  | $ | 10.1 |  |  |  |

[0001628280-23-025847:notes:115]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2023 (in millions):

[0001628280-23-025847:notes:116]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |
| Other comprehensive income (loss) before reclassifications |  | 0.2 |  |  | — |  |  | (0.5) |  |  | 14.3 |  |  | 14.0 |  |
| Amounts reclassified from AOCL |  | 0.3 |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.8 |  |
| Net other comprehensive income |  | 0.5 |  |  | — |  |  | — |  |  | 14.3 |  |  | 14.8 |  |
| Balance as of June 30, 2023 |  | $ | (4.4) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (24.7) |  |  | $ | (75.8) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-025847:notes:117]
12. Fair Value Measurements:

[0001628280-23-025847:notes:118]
[same as prior period, unchanged from 0001628280-23-013427:notes:111]

[0001628280-23-025847:notes:119]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2023 were the same as those used at December 31, 2022.

[0001628280-23-025847:notes:120]
[same as prior period, unchanged from 0001628280-23-013427:notes:113]

[0001628280-23-025847:notes:121]
[same as prior period, unchanged from 0001628280-23-013427:notes:114]

[0001628280-23-025847:notes:122]
[same as prior period, unchanged from 0001628280-23-013427:notes:115]

[0001628280-23-025847:notes:123]
[same as prior period, unchanged from 0001628280-23-013427:notes:116]

[0001628280-23-025847:notes:124]
[same as prior period, unchanged from 0001628280-23-013427:notes:117]

[0001628280-23-025847:notes:125]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Senior unsecured notes | $ | 883.3 |  |  | $ | 878.0 |  |
