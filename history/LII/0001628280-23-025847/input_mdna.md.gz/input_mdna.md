# LII MD&A — 0001628280-23-025847


## mdna

[0001628280-23-025847:mdna:1]
[same as prior period, unchanged from 0001628280-23-013427:mdna:1]

[0001628280-23-025847:mdna:2]
[same as prior period, unchanged from 0001628280-23-013427:mdna:2]

[0001628280-23-025847:mdna:3]
We operate in two reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential and Commercial. For additional information regarding our reportable segments, see Note 2 in the Notes to the Consolidated Financial Statements.

[0001628280-23-025847:mdna:4]
Our fiscal quarterly periods are comprised of approximately 13 weeks, but the number of days per quarter may vary year-over-year. Our quarterly reporting periods usually end on the Saturday closest to the last day of March, June and September. Our fourth quarter and fiscal year ends on December 31, regardless of the day of the week on which December 31 falls. For convenience, throughout this Management’s Discussion and Analysis of Financial Condition and Results of Operations, the 13-week periods comprising each fiscal quarter are denoted by the last day of the respective calendar quarter.

[0001628280-23-025847:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned parts and supplies stores. The demand for our products and services is seasonal and significantly impacted by the weather. Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services. Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services. In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions, and consumer spending habits and confidence. A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-23-025847:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated warranty costs, and freight and distribution costs. The principal raw materials used in our manufacturing processes are steel, copper and aluminum. In recent years, pricing volatility for these commodities and related components, including the impact of imposed tariffs on the import of certain of our raw materials and components, has impacted us and the HVACR industry in general. We seek to mitigate the impact of volatility in commodity prices through a combination of price increases, commodity contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-23-025847:mdna:7]
[same as prior period, unchanged from 0001628280-23-013427:mdna:7]

[0001628280-23-025847:mdna:8]
Prior to January 1, 2023, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses. We will continue to operate and invest in our Heatcraft Worldwide Refrigeration business which became part of the Commercial segment effective on January 1, 2023, while the European portfolio will be presented with Corporate and Other until disposition. The consolidation of our Heatcraft business within the Commercial segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.  All amounts discussed in this Management's Discussion and Analysis of Financial Condition and Results of Operations reflect the revised segment presentation.

[0001628280-23-025847:mdna:9]
[same as prior period, unchanged from 0001628280-23-013427:mdna:9]

[0001628280-23-025847:mdna:10]
Results for the second quarter of 2023 were driven by overall year-over-year sales and profit increases. Net sales increased 24% and segment profit increased $62 million for the Commercial segment. Net sales decreased 4% and segment profit decreased $14 million for the Residential segment. Net sales increased 10% and segment loss decreased $5 million for the Corporate & Other segment.

[0001628280-23-025847:mdna:11]
[same as prior period, unchanged from 0001628280-23-013427:mdna:11]

[0001628280-23-025847:mdna:12]
•Net sales increased $45 million to $1,411 million in the second quarter of 2023 driven by favorable price and mix partially offset by lower sales volumes and unfavorable foreign currency.

[0001628280-23-025847:mdna:13]
•Operating income in the second quarter of 2023 increased $52 million to $279 million primarily driven by favorable price.

[0001628280-23-025847:mdna:14]
•Net income for the second quarter of 2023 was $217 million.

[0001628280-23-025847:mdna:15]
•Diluted earnings per share was $6.10 per share in the second quarter of 2023 compared to $4.96 per share in the second quarter of 2022.

[0001628280-23-025847:mdna:16]
•For the six months ended June 30, 2023, we returned $75 million to shareholders through dividend payments.

[0001628280-23-025847:mdna:17]
Three Months Ended June 30, 2023 Compared to Three Months Ended June 30, 2022 - Consolidated Results

[0001628280-23-025847:mdna:18]
[same as prior period, unchanged from 0001628280-23-013427:mdna:18]

[0001628280-23-025847:mdna:19]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,411.4 |  |  | $ | 1,366.3 |  |  | 3.3 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 953.6 |  |  | 969.2 |  |  | 1.6 |  |  | 67.6 |  |  | 70.9 |  |
| Gross profit | 457.8 |  |  | 397.1 |  |  | 15.3 |  |  | 32.4 |  |  | 29.1 |  |
| Selling, general and administrative expenses | 181.3 |  |  | 169.6 |  |  | (6.9) |  |  | 12.8 |  |  | 12.4 |  |
| Losses (gains) and other expenses, net | 0.8 |  |  | 1.6 |  |  | 50.0 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring charges | — |  |  | 0.5 |  |  | 100.0 |  |  | — |  |  | — |  |
| Income from equity method investments | (3.1) |  |  | (1.5) |  |  | 106.7 |  |  | (0.2) |  |  | (0.1) |  |
| Operating income | $ | 278.8 |  |  | $ | 226.9 |  |  | 22.9 | % |  | 19.8 | % |  | 16.6 | % |

[0001628280-23-025847:mdna:20]
[same as prior period, unchanged from 0001628280-23-013427:mdna:20]

[0001628280-23-025847:mdna:21]
Net sales for the second quarter of 2023 compared to the second quarter of 2022 increased as a result of favorable price of 6% and favorable product mix of 6% which was partially offset by lower sales volumes of 8% due to general lower residential industry volumes and 1% from unfavorable foreign currency and other.

[0001628280-23-025847:mdna:22]
[same as prior period, unchanged from 0001628280-23-013427:mdna:22]

[0001628280-23-025847:mdna:23]
Gross profit margins in the second quarter of 2023 increased 330 basis points ("bps") to 32.4% compared to 29.1% in the second quarter of 2022. Gross margins increased 380 bps from favorable price, 90 bps from favorable commodity costs, 80 bps from favorable product mix, and 10 bps from miscellaneous other items.  Partially offsetting these increases were 100 bps from lower sales volumes, 70 bps from higher component costs, 30 bps from higher freight and distribution costs, and 30 bps from higher factory inefficiencies.

[0001628280-23-025847:mdna:24]
[same as prior period, unchanged from 0001628280-23-013427:mdna:24]

[0001628280-23-025847:mdna:25]
Selling, general and administrative expenses ("SG&A") increased $12 million to $181.3 million in the second quarter of 2023 compared to $169.6 million in the second quarter of 2022 due to higher employee-related costs. As a percentage of net sales, SG&A increased 40 bps to 12.8%.

[0001628280-23-025847:mdna:26]
[same as prior period, unchanged from 0001628280-23-013427:mdna:26]

[0001628280-23-025847:mdna:27]
Losses (gains) and other expenses, net for the second quarter of 2023 and 2022 included the following (in millions):

[0001628280-23-025847:mdna:28]
|  | For the Three Months Ended June 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (0.1) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (2.4) |  |  | (0.5) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.0) |  |  | — |  |  |  |  |  |  |  |
| Other operating income | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.2 |  |  | 1.9 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 4.8 |  |  | 1.0 |  |  |  |  |  |  |  |
| Other items, net | (0.7) |  |  | (0.5) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.8 |  |  | $ | 1.6 |  |  |  |  |  |  |  |

[0001628280-23-025847:mdna:29]
[same as prior period, unchanged from 0001628280-23-013427:mdna:29]

[0001628280-23-025847:mdna:30]
Restructuring charges were immaterial in the second quarter of 2023 and 2022.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-23-025847:mdna:31]
[same as prior period, unchanged from 0001628280-23-013427:mdna:31]

[0001628280-23-025847:mdna:32]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation. Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated. We recognized income from equity method investments of $3 million in the second quarter of 2023 and $1 million in the second quarter of 2022.

[0001628280-23-025847:mdna:33]
[same as prior period, unchanged from 0001628280-23-013427:mdna:33]

[0001628280-23-025847:mdna:34]
Interest expense, net increased to $15 million in the second quarter of 2023 from $9 million in the second quarter of 2022 due to higher interest rates during the period.

[0001628280-23-025847:mdna:35]
[same as prior period, unchanged from 0001628280-23-013427:mdna:35]

[0001628280-23-025847:mdna:36]
Our effective tax rate was 17.6% for the second quarter of 2023 compared to 18.4% for the second quarter of 2022.  The rate decreased primarily due to higher income in low tax jurisdictions.

[0001628280-23-025847:mdna:37]
We expect our annual effective tax rate to be 19-20%, excluding the impacts of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001628280-23-025847:mdna:38]
Second Quarter of 2023 Compared to Second Quarter of 2022 - Results by Segment

[0001628280-23-025847:mdna:39]
[same as prior period, unchanged from 0001628280-23-013427:mdna:39]

[0001628280-23-025847:mdna:40]
The following table presents our Residential segment's net sales and profit for the second quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:41]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 936.2 |  |  | $ | 977.5 |  |  | $ | (41.3) |  |  | (4) | % |
| Profit | $ | 202.6 |  |  | $ | 216.3 |  |  | $ | (13.7) |  |  | (6) | % |
| % of net sales | 21.6 | % |  | 22.1 | % |  |  |  |  |

[0001628280-23-025847:mdna:42]
Net sales decreased 4% in the second quarter of 2023 compared to 2022, as sales volumes declined 12%.  Offsetting these declines were favorable product mix of 6% and higher price of 2%.

[0001628280-23-025847:mdna:43]
Segment profit in the second quarter of 2023 compared to 2022 decreased by $14 million, driven by $46 million from lower sales volumes, $12 million in higher SG&A costs, $5 million from higher freight and distribution costs, $4 million from higher component costs, and $3 million from higher factory inefficiencies.  Partially offsetting these decreases were $21 million from higher price, $19 million from product mix, $11 million from lower commodity costs, and $5 million from miscellaneous other items.

[0001628280-23-025847:mdna:44]
[same as prior period, unchanged from 0001628280-23-013427:mdna:44]

[0001628280-23-025847:mdna:45]
The following table presents our Commercial segment's net sales and profit for the second quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:46]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 407.5 |  |  | $ | 327.4 |  |  | $ | 80.1 |  |  | 24 | % |
| Profit | $ | 103.0 |  |  | $ | 41.2 |  |  | $ | 61.8 |  |  | 150 | % |
| % of net sales | 25.3 | % |  | 12.6 | % |  |  |  |  |

[0001628280-23-025847:mdna:47]
[same as prior period, unchanged from 0001628280-23-013427:mdna:47]

[0001628280-23-025847:mdna:48]
Net sales increased 24% in the second quarter of 2023 compared to 2022 as price increased 15%, product mix increased 7% and an increase in sales volumes of 4% were partially offset by 2% foreign exchange and other items.

[0001628280-23-025847:mdna:49]
Segment profit in the second quarter of 2023 compared to 2022 increased $62 million due to $49 million from favorable price, $16 million from favorable product mix, $3 million from higher sales volumes, $3 million from lower commodity costs, and $2 million from favorable freight and distribution costs.  Partially offsetting these increases were $5 million from higher component costs, $4 million from higher other product costs and higher factory inefficiencies, and $2 million from higher SG&A costs.

[0001628280-23-025847:mdna:50]
[same as prior period, unchanged from 0001628280-23-013427:mdna:50]

[0001628280-23-025847:mdna:51]
The following table presents our Corporate and Other segment's net sales and loss for the second quarter of 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:52]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 67.7 |  |  | $ | 61.4 |  |  | $ | 6.3 |  |  | 10 | % |
| Loss | $ | (22.5) |  |  | $ | (27.7) |  |  | $ | 5.2 |  |  | 19 | % |

[0001628280-23-025847:mdna:53]
[same as prior period, unchanged from 0001628280-23-013427:mdna:53]

[0001628280-23-025847:mdna:54]
Net sales increased $6 million and segment loss decreased $5 million in the second quarter of 2023 compared to 2022.  Excluding the $2 million profit results of Europe, Corporate and Other costs decreased $2 million to $25 million in the second quarter of 2023 compared to 2022.

[0001628280-23-025847:mdna:55]
Year-to-Date through June 30, 2023 Compared to Year-to-Date through June 30, 2022 - Consolidated Results

[0001628280-23-025847:mdna:56]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001628280-23-025847:mdna:57]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 2,460.7 |  |  | $ | 2,379.7 |  |  | 3.4 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,696.2 |  |  | 1,714.4 |  |  | 1.1 |  |  | 68.9 |  |  | 72.0 |  |
| Gross profit | 764.5 |  |  | 665.3 |  |  | 14.9 |  |  | 31.1 |  |  | 28.0 |  |
| Selling, general and administrative expenses | 348.8 |  |  | 324.9 |  |  | (7.4) |  |  | 14.2 |  |  | 13.7 |  |
| Losses (gains) and other expenses, net | 1.1 |  |  | 2.0 |  |  | 45.0 |  |  | — |  |  | 0.1 |  |
| Restructuring charges | — |  |  | 1.0 |  |  | 100.0 |  |  | — |  |  | — |  |
| Income from equity method investments | (3.8) |  |  | (1.4) |  |  | 171.4 |  |  | (0.2) |  |  | (0.1) |  |
| Operating income | $ | 418.4 |  |  | $ | 338.8 |  |  | 23.5 | % |  | 17.0 | % |  | 14.2 | % |

[0001628280-23-025847:mdna:58]
Net Sales

[0001628280-23-025847:mdna:59]
Net sales increased 3% for the six months ended June 30, 2023 compared to the six months ended June 30, 2022 due to higher price of 6% and favorable mix of 6%.  Partially offsetting these increases were lower sales volumes of 8% and unfavorable foreign currency and other of 1%.

[0001628280-23-025847:mdna:60]
Gross Profit

[0001628280-23-025847:mdna:61]
Gross profit margins for the six months ended June 30, 2023 increased 310 bps to 31.1% compared to 28.0% for the six months ended June 30, 2022. Gross margins increased 390 bps from higher price, 90 bps from lower commodity costs, and 90 bps from favorable mix.  Partially offsetting these increases were 80 bps from higher component costs, 60 bps from higher other product costs, 50 bps from lower sales volumes, 40 bps from higher factory inefficiencies, and 30 bps from higher freight and distribution costs.

[0001628280-23-025847:mdna:62]
Selling, General and Administrative Expenses

[0001628280-23-025847:mdna:63]
SG&A increased $24 million to $349 million for the six months ended June 30, 2023 compared to $325 million for the six months ended June 30, 2022 primarily due to higher employee-related costs. As a percentage of net sales, SG&A increased 50 bps to 14.2% from 13.7%.

[0001628280-23-025847:mdna:64]
24

[0001628280-23-025847:mdna:65]
Losses (gains) and Other Expenses, Net

[0001628280-23-025847:mdna:66]
Losses (gains) and other expenses, net for the six months ended June 30, 2023 and 2022 included the following (in millions):

[0001628280-23-025847:mdna:67]
|  | For the Six Months Ended June 30, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | (0.4) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (3.2) |  |  | (0.8) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (1.3) |  |  | (0.9) |  |  |  |  |  |  |  |
| Other operating income | (0.9) |  |  | (0.5) |  |  |  |  |  |  |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.1) |  |  | 1.2 |  |  |  |  |  |  |  |
| Environmental liabilities and special litigation charges | 7.3 |  |  | 3.1 |  |  |  |  |  |  |  |
| Other items, net | (0.8) |  |  | 0.3 |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 1.1 |  |  | $ | 2.0 |  |  |  |  |  |  |  |

[0001628280-23-025847:mdna:68]
Restructuring Charges

[0001628280-23-025847:mdna:69]
There were no restructuring charges for the six months ended June 30, 2023 and $1 million for the six months ended June 30, 2022.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-23-025847:mdna:70]
Income from Equity Method Investments

[0001628280-23-025847:mdna:71]
Income from equity method investments increased to $4 million for the six months ended June 30, 2023 as compared to $1 million for the six months ended June 30, 2022.  The increase was due to lower operating costs at the investments.

[0001628280-23-025847:mdna:72]
Interest Expense, net

[0001628280-23-025847:mdna:73]
Interest expense, net increased $14 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022 primarily due to higher interest rates.

[0001628280-23-025847:mdna:74]
Income Taxes

[0001628280-23-025847:mdna:75]
Our effective tax rate increased to 19.0% for the six months ended June 30, 2023 compared to 18.9% for the six months ended June 30, 2022 primarily due to slightly lower income allocated to low tax rate jurisdictions.

[0001628280-23-025847:mdna:76]
Year-to-Date through June 30, 2023 Compared to Year-to-Date through June 30, 2022 - Results by Segment

[0001628280-23-025847:mdna:77]
Residential

[0001628280-23-025847:mdna:78]
The following table presents our Residential segment's net sales and profit for the six months ended June 30, 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:79]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 1,617.2 |  |  | $ | 1,659.6 |  |  | $ | (42.4) |  |  | (3) | % |
| Profit | $ | 313.7 |  |  | $ | 324.0 |  |  | $ | (10.3) |  |  | (3) | % |
| % of net sales | 19.4 | % |  | 19.5 | % |  |  |  |  |

[0001628280-23-025847:mdna:80]
Net sales decreased 3% for the six months ended June 30, 2023 compared to the six months ended June 30, 2022 as sales volumes decreased by 11% and 1% from unfavorable foreign exchange and other.  Partially offsetting these declines was 6% from favorable product mix and 3% from higher price.

[0001628280-23-025847:mdna:81]
Segment profit for the first six months of 2023 compared to 2022 decreased $10 million due to $58 million from lower sales

[0001628280-23-025847:mdna:82]
volumes, $18 million in higher SG&A costs, $12 million in higher freight and distribution costs, $11 million from higher factory inefficiencies and other product costs, and $10 million in higher component costs.  Partially offsetting these decreases was $46 million from higher price, $28 million from favorable product mix, $17 million from favorable commodity costs, $8 million from lower product warranty costs and miscellaneous other costs.

[0001628280-23-025847:mdna:83]
Commercial

[0001628280-23-025847:mdna:84]
The following table presents our Commercial segment's net sales and profit for the six months ended June 30, 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:85]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 716.1 |  |  | $ | 606.9 |  |  | $ | 109.2 |  |  | 18 | % |
| Profit | $ | 153.0 |  |  | $ | 64.9 |  |  | $ | 88.1 |  |  | 136 | % |
| % of net sales | 21.4 | % |  | 10.7 | % |  |  |  |  |

[0001628280-23-025847:mdna:86]
Net sales increased 18% for the six months ended June 30, 2023 compared to the six months ended June 30, 2022 as price increased 12% and product mix was 7% favorable.  Partially offsetting these increases was 1% lower sales volumes.

[0001628280-23-025847:mdna:87]
Segment profit for the first six months of 2023 compared to 2022 increased $88 million primarily due to $75 million from higher price, $32 million from favorable product mix, $7 million from lower commodity costs, and $4 million from lower freight and distribution costs.  Partially offsetting these increases were $15 million from higher other product costs including warranty costs, $8 million from higher component costs, $5 million from higher SG&A costs, and $2 million from lower sales volumes.

[0001628280-23-025847:mdna:88]
Corporate and Other

[0001628280-23-025847:mdna:89]
The following table presents our Corporate and Other segment's net sales and loss for the six months ended June 30, 2023 and 2022 (dollars in millions):

[0001628280-23-025847:mdna:90]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 (1) |  | Difference |  | % Change |
| Net sales | $ | 127.4 |  |  | $ | 113.2 |  |  | $ | 14.2 |  |  | 13 | % |
| Loss | $ | (41.9) |  |  | $ | (44.5) |  |  | $ | 2.6 |  |  | 6 | % |
| % of net sales | (32.9) | % |  | (39.3) | % |  |  |  |  |

[0001628280-23-025847:mdna:91]
(1) 2022 amounts have been recast to reflect the changes in segment reporting.  Please see Note 2 in the Notes to the Consolidated Financial Statements for further detail.

[0001628280-23-025847:mdna:92]
Net sales increased $14 million and segment costs decreased $3 million in the six months ended June 30, 2023 compared to 2022.  Excluding the $2 million profit from Europe, Corporate and Other costs increased $4 million to $44 million in the six months ended June 30, 2023 compared to 2022, primarily due to increased employee costs.

[0001628280-23-025847:mdna:93]
[same as prior period, unchanged from 0001628280-23-013427:mdna:55]

[0001628280-23-025847:mdna:94]
[same as prior period, unchanged from 0001628280-23-013427:mdna:56]

[0001628280-23-025847:mdna:95]
[same as prior period, unchanged from 0001628280-23-013427:mdna:57]

[0001628280-23-025847:mdna:96]
The following table summarizes our cash flow activity for the six months ended June 30, 2023 and 2022 (in millions):

[0001628280-23-025847:mdna:97]
|  | For the Six Months Ended June 30, |
|  | 2023 |  | 2022 |
| Net cash provided by (used in) operating activities | $ | 116.7 |  |  | $ | (0.8) |  |
| Net cash used in investing activities | (82.3) |  |  | (46.2) |  |
| Net cash (used in) provided by financing activities | (33.8) |  |  | 75.4 |  |

[0001628280-23-025847:mdna:98]
Net Cash Provided By (Used In) Operating Activities -  The change in net cash provided by operating activities for the six months ended June 30, 2023 compared to the net cash used in operating activities for the same period in 2022 reflects changes in working capital and an increase in net income.

[0001628280-23-025847:mdna:99]
Net Cash Used In Investing Activities - Capital expenditures were $85 million for the six months ended June 30, 2023 compared to $47 million in the same period of 2022.  Capital expenditures in 2023 were related to our Commercial factory in Mexico, the general expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-23-025847:mdna:100]
Net Cash (Used In) Provided By Financing Activities - Net cash used in financing activities for the six months ended June 30, 2023 changed to $34 million compared to $75 million provided by financing activities in the same period of 2022.  The change was primarily due to less net borrowings partially offset by less share repurchases.  We did not repurchase any shares for the six months ended June 30, 2023 and we repurchased $300 million in shares in the same period of 2022.  We returned $75 million to shareholders through dividend payments for the six months ended June 30, 2023 and $67 million in the same period of 2022. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-23-025847:mdna:101]
[same as prior period, unchanged from 0001628280-23-013427:mdna:63]

[0001628280-23-025847:mdna:102]
The following table details our lines of credit and financing arrangements as of June 30, 2023 (in millions):

[0001628280-23-025847:mdna:103]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset securitization program (1) | $ | 400.0 |  |
| Finance lease obligations | 11.5 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (0.2) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |
| Long-term debt: |  |
| Finance lease obligations | 31.0 |  |
| Credit agreement (2) | 192.0 |  |
| Senior unsecured notes | 600.0 |  |
| Debt issuance costs | (5.3) |  |
| Total long-term debt | 817.7 |  |
| Total debt | $ | 1,579.0 |  |

[0001628280-23-025847:mdna:104]
(1)    The maximum securitization amount ranges from $300.0 million to $450.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-23-025847:mdna:105]
(2)   The available future borrowings on our Credit Agreement (as defined below) are $556.3 million, after being reduced by the outstanding borrowings and $1.7 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-23-025847:mdna:106]
[same as prior period, unchanged from 0001628280-23-013427:mdna:68]

[0001628280-23-025847:mdna:107]
[same as prior period, unchanged from 0001628280-23-013427:mdna:69]

[0001628280-23-025847:mdna:108]
In July 2021, we entered into a new Credit agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-23-025847:mdna:109]
[same as prior period, unchanged from 0001628280-23-013427:mdna:71]

[0001628280-23-025847:mdna:110]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control. As of June 30, 2023, we were in compliance with all covenant requirements.

[0001628280-23-025847:mdna:111]
[same as prior period, unchanged from 0001628280-23-013427:mdna:73]

[0001628280-23-025847:mdna:112]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio decreased to 96% at June 30, 2023 from 115% at December 31, 2022.

[0001628280-23-025847:mdna:113]
As of June 30, 2023, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-23-025847:mdna:114]
[same as prior period, unchanged from 0001628280-23-013427:mdna:77]

[0001628280-23-025847:mdna:115]
We believe our cash and cash equivalents of $51 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $51 million as of June 30, 2023 was $21 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-23-025847:mdna:116]
[same as prior period, unchanged from 0001628280-23-013427:mdna:79]

[0001628280-23-025847:mdna:117]
[same as prior period, unchanged from 0001628280-23-013427:mdna:80]

[0001628280-23-025847:mdna:118]
[same as prior period, unchanged from 0001628280-23-013427:mdna:81]

[0001628280-23-025847:mdna:119]
[same as prior period, unchanged from 0001628280-23-013427:mdna:82]

[0001628280-23-025847:mdna:120]
Commitments, Contingencies and Guarantees

[0001628280-23-025847:mdna:121]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-23-025847:mdna:122]
[same as prior period, unchanged from 0001628280-23-013427:mdna:85]

[0001628280-23-025847:mdna:123]
[same as prior period, unchanged from 0001628280-23-013427:mdna:86]
