# LII MD&A — 0000950123-11-039069


## mdna

[0000950123-11-039069:mdna:1]
[same as prior period, unchanged from 0000950123-10-096054:mdna:1]

[0000950123-11-039069:mdna:2]
[same as prior period, unchanged from 0000950123-10-096054:mdna:2]

[0000950123-11-039069:mdna:3]
We operate in four reportable business segments of the HVACR industry. Our reportable
segments consist of Residential Heating & Cooling, Commercial Heating & Cooling, Service Experts
and Refrigeration. For more detailed information regarding our reportable segments, see Note 14 in
the Notes to our Consolidated Financial Statements.

[0000950123-11-039069:mdna:4]
Our products and services are sold through a combination of distributors, independent and
company-owned dealer service centers, other installing contractors, wholesalers, manufacturers’
representatives, original equipment manufacturers and to national accounts. The demand for our
products and services is seasonal and dependent on the weather. Warmer than normal summer
temperatures generate strong demand for replacement air conditioning and refrigeration products and
services and colder than normal winter temperatures have the same effect on heating products and
services. Conversely, cooler than normal summers and warmer than normal winters depress the demand
for HVACR products and services. In addition to weather, demand for our products and services is
influenced by national and regional economic and demographic factors, such as interest rates, the
availability of financing, regional population and employment trends, new construction, general
economic conditions and consumer spending habits and confidence.

[0000950123-11-039069:mdna:5]
The principal elements of cost of goods sold in our manufacturing operations are components,
raw materials, factory overhead, labor and estimated costs of warranty expense. The principal
raw materials used in our manufacturing processes are steel, copper and aluminum. In recent years,
increased prices for these commodities and related components have challenged us and the HVACR
industry in general. We seek to mitigate the impact of higher commodity prices through a
combination of price increases for our products and services, commodity contracts, improved
production efficiency and cost reduction initiatives. We also seek to mitigate volatility in the
prices of these commodities by entering into futures contracts and fixed forward contracts. In our
Service Experts segment, the principal components of cost of goods sold are equipment, parts and
supplies and labor.

[0000950123-11-039069:mdna:6]
A substantial portion of the sales in each of our business segments is attributable to
replacement business, with the balance comprised of new construction business.

[0000950123-11-039069:mdna:7]
The Residential Heating & Cooling business was impacted in the first quarter of 2011 by
pull-forward of demand in the fourth quarter of 2010 ahead of announced price increases.
 These items
combined for a 10% volume decline in net sales for this business when compared to the prior year
quarter. We were able to offset the sales volume decline with a 5% increase in price and mix. The
Service Experts business also experienced a sales volume decline in our seasonally lightest
quarter. Our Commercial Heating & Cooling business showed strong growth in the quarter with 16%
revenue growth, largely driven by volume. The Refrigeration segment experienced a 33% increase in
net sales. We had organic growth of 3%, excluding a 5% impact of foreign currency exchange rates,
with the remainder of the growth from the acquisition of the Kysor/Warren business in January 2011.

[0000950123-11-039069:mdna:8]
We will continue to execute on our strategic priorities to win new business and capture
opportunities through innovative product and system solutions and lower our cost structure through
manufacturing and sourcing excellence and expense reduction efforts. As we move into the strongest
seasonal quarters of the year, we believe we are well-positioned across all our businesses.

[0000950123-11-039069:mdna:9]
Key Financial Statistics

[0000950123-11-039069:mdna:10]
|  | • |  | Net sales for first quarter of 2011 increased to $687.8 million as compared to $644.1 million in 2010. The Kysor/Warren acquisition contributed 5% to the net sales growth with the remainder of the increase due to favorable foreign currency exchange rates. |
|  | • |  | Operational income for first quarter of 2011 declined to a $7.0 million loss as compared to operational income of $0.5 million in 2010. The decline to an operational loss in 2011 was primarily due to gross profit compression from commodity headwinds and an increase in freight costs. |
|  | • |  | Net loss for the first quarter of 2011 was $7.2 million compared to a net loss of $1.6 million in 2010. Basic and diluted loss per share from continuing operations were $0.13 in the first quarter of 2011 compared to basic and diluted loss per share from continuing operations of $0.02 in 2010. |
|  | • |  | Cash of $148.3 million was used in operating activities for first quarter of 2011 compared to cash used in operating activities of $40.3 million in the first quarter of 2010. Cash used in operating activities was higher primarily due to the increased build of inventory levels in the first quarter of 2011. |
|  | • |  | During the first quarter of 2011, we returned $31.8 million to shareholders through share repurchases and dividends. Our dividends increased in the first quarter of 2011 to $0.15 per share from $0.14 per share in 2010. |

[0000950123-11-039069:mdna:11]
[same as prior period, unchanged from 0000950123-10-096054:mdna:12]

[0000950123-11-039069:mdna:12]
The following table provides a summary of our financial results, including information
presented as a percentage of net sales (dollars in millions):

[0000950123-11-039069:mdna:13]
|  |  | Three Months Ended March 31, |  |
|  |  |  |  |  |  |  |  | Percent |  |  |  |  |  |  |  |
|  |  | Dollars |  |  | Change |  |  | Percent Sales |  |
|  |  | 2011 |  |  | 2010 |  |  | Fav/(Unfav) |  |  | 2011 |  |  | 2010 |  |
| Net sales |  | $ | 687.8 |  |  | $ | 644.1 |  |  |  | 6.8 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 522.6 |  |  |  | 469.8 |  |  |  | (11.2 | ) |  |  | 76.0 |  |  |  | 72.9 |  |
| Gross profit |  |  | 165.2 |  |  |  | 174.3 |  |  |  | (5.2 | ) |  |  | 24.0 |  |  |  | 27.1 |  |
| Selling, general and administrative expenses |  |  | 173.9 |  |  |  | 168.9 |  |  |  | (3.0 | ) |  |  | 25.2 |  |  |  | 26.2 |  |
| Gains and other expenses, net |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | — |  |  |  | N.M |  |  |  | N.M |  |
| Restructuring charges |  |  | 1.2 |  |  |  | 7.2 |  |  |  | 83.3 |  |  |  | 0.2 |  |  |  | 1.1 |  |
| Income from equity method investments |  |  | (2.6 | ) |  |  | (2.0 | ) |  |  | 30.0 |  |  |  | (0.4 | ) |  |  | (0.3 | ) |
| Operational (loss) income |  | $ | (7.0 | ) |  | $ | 0.5 |  |  |  | (1,500.0 | )% |  |  | (1.0 | )% |  |  | 0.1 | % |
| Net loss |  | $ | (7.2 | ) |  | $ | (1.6 | ) |  |  | (350.0 | )% |  |  | (1.0 | )% |  |  | (0.2 | )% |

[0000950123-11-039069:mdna:14]
First Quarter of 2011 Compared to First Quarter of 2010 — Consolidated Results

[0000950123-11-039069:mdna:15]
[same as prior period, unchanged from 0000950123-10-096054:mdna:16]

[0000950123-11-039069:mdna:16]
Net sales increased 7% in the first quarter of 2011 compared to the first quarter of 2010. The
Kysor/Warren acquisition added 5% to our net sales. Our price and mix were up 3% in the comparable
period; however, our sales volume was down 1%. The decline in volume was predominantly in our
residential segment partially offset by volume growth in our commercial and refrigeration segments.
Changes in foreign currency exchange rates favorably impacted net sales by 2%.

[0000950123-11-039069:mdna:17]
[same as prior period, unchanged from 0000950123-10-096054:mdna:18]

[0000950123-11-039069:mdna:18]
Gross
profit margins declined 310 basis points to 24.0% for the first quarter of 2011 when
compared to gross profit margins of 27.1% in 2010. Commodity headwinds contributed approximately
180 basis points to the decline which was partially offset by improved price and mix of 110 basis
points. Contributing to the decline in gross profit margins were
other cost changes contributing 50
basis points and foreign currency translation rates 110 basis points. The other costs changes
decline was primarily due to an increase in freight charges primarily from rate increases and fuel
surcharges.

[0000950123-11-039069:mdna:19]
[same as prior period, unchanged from 0000950123-10-096054:mdna:20]

[0000950123-11-039069:mdna:20]
Selling, general and administrative (“SG&A”) expenses increased by $5 million in the first
quarter of 2011 compared to 2010; however, as a percentage of net sales, SG&A expenses declined to
25% in 2011 from 26% in 2010. SG&A expenses excluding the Kysor/Warren acquisition were
relatively flat. The impact of changes in foreign exchange rates increased SG&A expenses by $2
million. Offsetting the effects of foreign currency exchange rates were $1 million in favorable
bad debt experience and $1 million in lower commissions primarily due to lower sales in our
residential segment.

[0000950123-11-039069:mdna:21]
Gains and Other Expenses, Net

[0000950123-11-039069:mdna:22]
Gains and other expenses, net for the first quarters of 2011 and 2010 included the following
(in millions):

[0000950123-11-039069:mdna:23]
|  |  | Three Months Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Realized gains losses on settled futures contracts |  | $ | (0.6 | ) |  | $ | (0.3 | ) |
| Unrealized loss on unsettled futures contracts not designated as cash flow hedges |  |  | 0.7 |  |  |  | — |  |
| Foreign currency exchange loss (gains) |  |  | 0.1 |  |  |  | (0.2 | ) |
| Acquisition expenses |  |  | 0.2 |  |  |  | — |  |
| Other items, net |  |  | (0.7 | ) |  |  | 0.2 |  |
| Gains and other expenses, net |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0000950123-11-039069:mdna:24]
The change in gains and losses on futures contracts was primarily due to increases in
commodity prices relative to our futures contract prices during 2011 as compared to 2010 for the
contracts that settled during the period. Conversely, the change in unrealized losses related to
unsettled futures contracts not designated as cash flow hedges was primarily due to higher
commodity prices relative to the futures contract prices for those contracts. For more
information, see Note 5 in the Notes to the Consolidated Financial Statements.

[0000950123-11-039069:mdna:25]
[same as prior period, unchanged from 0000950123-10-096054:mdna:26]

[0000950123-11-039069:mdna:26]
Restructuring charges declined from $7.2 million in the first quarter of 2010 to $1.2 million
in the first quarter of 2011. As we didn’t initiate any new projects in the first quarter of 2011,
the charges in this period related to minor charges from various open projects initiated in prior
years. The restructuring charges from the first quarter of 2010 were primarily related to the exit
of coil manufacturing in Milperra, Australia which was initiated in that quarter. This
restructuring project resulted in $5.8 million in restructuring charges consisting of $4.4 million
in severance, $1.2 million in asset impairments, and $0.2 million in other charges. The remaining
restructuring charges from the first quarter of 2010 were minor charges from various open projects
initiated in prior years.

[0000950123-11-039069:mdna:27]
Results from Equity Method and Other Equity Investments

[0000950123-11-039069:mdna:28]
Investments over which we do not exercise control but have significant influence are accounted
for using the equity method of accounting. Income from equity method investments increased to $2.6
million in the first quarter of 2011 from $2.0 million in 2010,
primarily from improved performance from
our compressor manufacturing joint venture.

[0000950123-11-039069:mdna:29]
Interest Expense, Net

[0000950123-11-039069:mdna:30]
Interest expense, net, increased to $4.1 million in 2011 from $2.5 million in 2010. The
increase in interest expense was primarily attributable to an increase in our weighted average
interest rate as well as an increase in the average amounts borrowed in the first quarter of 2011
compared to 2010.

[0000950123-11-039069:mdna:31]
Benefit from Income Taxes

[0000950123-11-039069:mdna:32]
The income tax benefits were
$3.9 million in the first quarter of 2011 compared $0.7 million
in 2010. The effective tax rate was 35.1% for 2011 and 35.0% in 2010. Our effective rates differ
from the statutory federal rate of 35% for certain items, such as state and local taxes,
non-deductible expenses, foreign operating losses for which no tax benefits have been recognized
and foreign taxes at rates other than 35%. In the first quarters of 2011 and 2010, these items
effectively offset each other and did not affect our effective tax rates.

[0000950123-11-039069:mdna:33]
First Quarter of 2011 Compared to First Quarter of 2010 — Results by Segment

[0000950123-11-039069:mdna:34]
[same as prior period, unchanged from 0000950123-10-096054:mdna:42]

[0000950123-11-039069:mdna:35]
The following table summarizes our Residential Heating & Cooling segment’s net sales and
(loss) profit for the first quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-039069:mdna:36]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 272.0 |  |  | $ | 284.2 |  |  | $ | (12.2 | ) |  |  | (4.3 | )% |
| (Loss) profit |  |  | (1.2 | ) |  |  | 7.1 |  |  |  | (8.3 | ) |  |  | (116.9 | )% |
| % of net sales |  |  | (0.4 | )% |  |  | 2.5 | % |  |  |  |  |  |  |  |  |

[0000950123-11-039069:mdna:37]
The decrease in sales was impacted by the pull-forward of demand into the fourth quarter of
2010 ahead of announced price increases. Sales volumes
declined by almost 10% in 2011 as compared to 2010. Partially offsetting the decline in sales
volume was higher price and mix of 5% and foreign currency exchange rates of 1%.

[0000950123-11-039069:mdna:38]
Segment profit decreased $8 million due to $11 million in lower sales volumes and $8 million
in higher freight charges. Commodity headwinds of $8 million
were more than offset by $12 million
in favorable price and mix. Other product cost savings of $5 million, primarily from material
savings and lower SG&A expense of $2 million, partially offset the decline in segment profit. The
lower SG&A expenses were the result of $1 million in favorable bad debt experience and $1 million
in lower commissions due to the decline in net sales.

[0000950123-11-039069:mdna:39]
[same as prior period, unchanged from 0000950123-10-096054:mdna:47]

[0000950123-11-039069:mdna:40]
The following table summarizes our Commercial Heating & Cooling segment’s net sales and profit
for the first quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-039069:mdna:41]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 138.8 |  |  | $ | 119.7 |  |  | $ | 19.1 |  |  |  | 16.0 | % |
| Profit |  |  | 5.9 |  |  |  | 3.4 |  |  |  | 2.5 |  |  |  | 73.5 |  |
| % of net sales |  |  | 4.3 | % |  |  | 2.8 | % |  |  |  |  |  |  |  |  |

[0000950123-11-039069:mdna:42]
Our Commercial Heating & Cooling business experienced 16% in higher net sales in the first
quarter of 2011 compared to 2010 primarily due to  an increase in both our commercial new
construction and replacement businesses which resulted in a 15% increase in sales volume.
Changes in foreign currency exchange rates favorably impacted sales
by 1%.

[0000950123-11-039069:mdna:43]
Segment profit for the first quarter of 2011 increased almost $3 million from the first
quarter of 2010. Segment profit increased from the impact of higher sales volume of $5 million.
Partially offsetting our higher sales were commodity headwinds of $2 million and freight charges of
$1 million. The increase in freight charges is primarily related to an increase in fuel
surcharges.

[0000950123-11-039069:mdna:44]
[same as prior period, unchanged from 0000950123-10-096054:mdna:52]

[0000950123-11-039069:mdna:45]
The following table summarizes our Service Experts segment’s net sales and loss for the first
quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-039069:mdna:46]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 116.5 |  |  | $ | 127.1 |  |  | $ | (10.6 | ) |  |  | (8.3 | )% |
| Loss |  |  | (8.2 | ) |  |  | (4.6 | ) |  |  | (3.6 | ) |  |  | 78.3 |  |
| % of net sales |  |  | (7.0 | )% |  |  | (3.6 | )% |  |  |  |  |  |  |  |  |

[0000950123-11-039069:mdna:47]
In total, sales volumes declined 11% which was partially offset by a 2% increase in price and
mix. Foreign currency exchange rates increased net sales by 1%.

[0000950123-11-039069:mdna:48]
In the seasonally lightest quarter, segment loss increased $4 million due to the impact of the
volume decline in net sales. Partially offsetting the volume decline was an SG&A expense
improvement of $2 million due to $1 million in favorable bad debt experience and $1 million in
lower commissions due to the decline in net sales.

[0000950123-11-039069:mdna:49]
[same as prior period, unchanged from 0000950123-10-096054:mdna:57]

[0000950123-11-039069:mdna:50]
The following table summarizes our Refrigeration segment’s net sales and profit for the first
quarters of 2011 and 2010 (dollars in millions):

[0000950123-11-039069:mdna:51]
|  |  | Three Months EndedMarch 31, |  |  |  |  |  |  |  |
|  |  | 2011 |  |  | 2010 |  |  | Difference |  |  | % Change |  |
| Net sales |  | $ | 175.1 |  |  | $ | 131.4 |  |  | $ | 43.7 |  |  |  | 33.3 | % |
| Profit |  |  | 13.5 |  |  |  | 14.9 |  |  |  | (1.4 | ) |  |  | (9.4 | ) |
| % of net sales |  |  | 7.7 | % |  |  | 11.3 | % |  |  |  |  |  |  |  |  |

[0000950123-11-039069:mdna:52]
Net
sales, excluding Kysor/Warren, increased 3% due to higher sales volumes. Price and mix
were relatively flat. Foreign exchange rates increased net sales by an additional 4%. The
Kysor/Warren acquisition contributed 26% to the increase in net sales.

[0000950123-11-039069:mdna:53]
Segment
profit decreased by $1 million from commodity headwinds and $1 million in increased
freight charges. The increase in freight charges was due to an increase in rates and fuel
surcharges. Offsetting these decreases to segment profit was a favorable impact from foreign
currency exchange rates of $1 million.

[0000950123-11-039069:mdna:54]
[same as prior period, unchanged from 0000950123-10-096054:mdna:62]

[0000950123-11-039069:mdna:55]
Corporate and other expenses were $15 million in the first quarter of 2011, up from $13
million in 2010. The increase was primarily driven by a $1 million pension settlement and a $1
million increase in stock-based and incentive compensation plans.

[0000950123-11-039069:mdna:56]
[same as prior period, unchanged from 0000950123-10-096054:mdna:106]

[0000950123-11-039069:mdna:57]
Our working capital and capital expenditure requirements are generally met through internally
generated funds, bank lines of credit and a revolving period asset securitization arrangement.
Working capital needs are generally greater in the first and second quarters due to the seasonal
nature of our business cycle.

[0000950123-11-039069:mdna:58]
[same as prior period, unchanged from 0000950123-10-096054:mdna:108]

[0000950123-11-039069:mdna:59]
The following table summarizes our cash activity for the quarters ended March 31, 2011 and
2010 (in millions):

[0000950123-11-039069:mdna:60]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net cash used in operating activities |  | $ | (148.3 | ) |  | $ | (40.3 | ) |
| Net cash used in investing activities |  |  | (150.1 | ) |  |  | (39.3 | ) |
| Net cash provided by financing activities |  |  | 191.8 |  |  |  | 15.8 |  |

[0000950123-11-039069:mdna:61]
Net Cash Used in by Operating Activities

[0000950123-11-039069:mdna:62]
Operating activities resulted in a higher use of cash in 2011 compared to 2010. This
increased use was primarily due to higher working capital requirements in 2011 and a higher
incentive payout in 2011 from improved operating results in 2010. Our working capital requirements
resulted in a $69.5 million use of cash in the first quarter of 2011 compared to a $32.6 million
use of cash in 2010. The increase in working capital requirements is primarily due to a larger
increase in inventory of $136.3 million in the first quarter of 2011 compared to $85.6 million in
2010. As we prepare for the peak cooling season, we carry higher than average inventory balances
in the first and second quarters. Our increases in inventory in the first quarter of 2011 were
larger than 2010 primarily due to anticipated sales growth across all business segments in 2011.

[0000950123-11-039069:mdna:63]
Net Cash Used in Investing Activities

[0000950123-11-039069:mdna:64]
Net cash used in investing activities for the first quarter of 2011 included $144.2 million
for the acquisition of the Kysor/Warren business from The Manitowoc Company. Kysor/Warren is a
leading manufacturer of refrigerated systems and display cases for supermarkets throughout North
America and will be included in our Refrigeration Segment.

[0000950123-11-039069:mdna:65]
Capital expenditures in the first quarter of 2011 were $8.2 million, which was slightly lower
than the $10.7 million in the first quarter of 2010. Capital expenditures in the quarter were
primarily related to maintenance capital expenditures.

[0000950123-11-039069:mdna:66]
In addition to the $10.7 million in capital expenditures, net cash used in investing
activities for the first quarter of 2010 included $25.1 million placed in a trust for our captive
insurance subsidiary and $6.7 million for business acquisitions. Offsetting these uses were $3.2
million in proceeds from the sale of businesses.

[0000950123-11-039069:mdna:67]
Net Cash Provided by Financing Activities

[0000950123-11-039069:mdna:68]
Net cash provided by financing activities increased by $176.0 million in the first quarter of
2011 compared to the first quarter of 2010. This increase was primarily related to an increase in
net borrowings to support the Kysor/Warren acquisition and the increase in working capital needs in
the first quarter of 2011. Additionally, we had lower share repurchase activity in the first
quarter of 2011 of $23.7 million compared to $34.7 million in the first quarter of 2010 which
contributed to the increase in net cash provided by financing activities. Offsetting these
increases was an increase in our cash dividend from $0.14 per share in the first quarter of 2010 to
$0.15 per share in the first quarter of 2011.

[0000950123-11-039069:mdna:69]
[same as prior period, unchanged from 0000950123-10-096054:mdna:120]

[0000950123-11-039069:mdna:70]
The following table details our lines of credit and financing arrangements as of March 31,
2011:

[0000950123-11-039069:mdna:71]
|  |  |  |  |  |  | Outstanding |  |  | Available for |  |
|  |  | Maximum Capacity |  |  | Borrowings |  |  | Future Borrowings |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign Obligations |  |  |  |  |  |  |  |  |  |  |  |  |
| Committed |  | $ | 10.9 |  |  | $ | — |  |  | $ | 10.9 |  |
| Non-committed |  |  | 2.7 |  |  | $ | 2.7 |  |  |  | — |  |
| Asset Securitization (1) |  |  | 94.0 |  |  |  | 50.0 |  |  |  | 44.0 |  |
| Total short-term debt |  | $ | 107.6 |  |  | $ | 52.7 |  |  | $ | 54.9 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital lease obligations |  | $ | 17.4 |  |  |  | 17.4 |  |  |  | — |  |
| Domestic revolving credit facility (2) |  |  | 650.0 |  |  |  | 271.5 |  |  |  | 309.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |  |  | — |  |
| Total long-term debt |  | $ | 867.4 |  |  | $ | 488.9 |  |  |  | 309.0 |  |
| Total |  | $ | 975.0 |  |  | $ | 541.6 |  |  | $ | 363.9 |  |

[0000950123-11-039069:mdna:72]
| (1) |  | The maximum capacity under the asset securitization arrangement (“ASA”) is the lesser of $100.0 million or 100% of the net pool balance defined under the ASA. |
| (2) |  | The available future borrowings on our domestic revolving credit facility exclude $69.5 million in standby letters of credit. |

[0000950123-11-039069:mdna:73]
As discussed above,
we utilized our domestic revolving credit facility (“credit facility”) and
ASA to support the acquisition of the Kysor/Warren
business and the increase in working capital needs in the first quarter of 2011.

[0000950123-11-039069:mdna:74]
As our peak season arrives, we typically pay down debt. We believe our available
future borrowings combined with our cash of $55.2 million and anticipated cash from operations in
the latter half of the year will be more than sufficient to fund our operations, capital
expenditures, share repurchases, dividends and other needs in the foreseeable future.
Our expected capital expenditures are $65 million for 2011.

[0000950123-11-039069:mdna:75]
Our debt-to-total-capital ratio increased to 48.9% at March 31, 2011 compared to 35.1% at
December 31, 2010. Lower stockholders’ equity was primarily due to the repurchase of approximately
0.5 million shares of our common stock for $23.7 million since December 31, 2010 under our current
share repurchase plan. The increase in debt since December 31, 2010 was principally due to the
acquisition of the Kysor/Warren business as well as our increase in working capital needs.

[0000950123-11-039069:mdna:76]
Covenants on our outstanding debt did not change in the first quarter of 2011 and we were in
compliance with all of our debt covenants as of March 31, 2011. For a more detailed discussion of
our debt, see Note 8 in the Notes to the Consolidated Financial Statements set forth in Part I,
Item I of this Quarterly Report on Form 10-Q.

[0000950123-11-039069:mdna:77]
We periodically review our capital structure, including our primary bank facility, to ensure
that it has adequate liquidity. Our ASA expires on November 18, 2011 and our credit facility
matures in October 2012. We expect to amend, renew or replace these facilities prior to or upon
their expiration. We also periodically consider various other financing alternatives and may, from
time to time, seek to take advantage of favorable interest rate environments or other market
conditions, which may include accessing the capital markets. We filed a shelf registration
statement with the SEC that became effective on December 1, 2008, which allows us to offer and sell
an indeterminate number or amount of debt securities, common shares, preferred shares, subscription
rights, warrants, depositary shares and units.

[0000950123-11-039069:mdna:78]
On March 11, 2011, we announced that our Board of Directors approved a 20% increase in our
quarterly dividend on common stock from $0.15 to $0.18 effective with the April dividend payment.
Dividend payments are expected to be approximately $35 million in 2011. We also continue to
increase shareholder value through our share repurchase program. During the quarter we returned
$23.7 million to our investors through share repurchases. We are targeting in excess of $100.0
million in share repurchases in 2011.

[0000950123-11-039069:mdna:79]
[same as prior period, unchanged from 0000950123-10-096054:mdna:133]

[0000950123-11-039069:mdna:80]
In addition to the credit facilities and promissory notes described above, we also lease real
estate and machinery and equipment pursuant to operating leases that are not capitalized on the
balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived
equipment such as personal computers.

[0000950123-11-039069:mdna:81]
Commitments, Contingencies and Guarantees

[0000950123-11-039069:mdna:82]
For a detailed discussion of commitments, contingencies and guarantees, see Note 7 in the
Notes to the Consolidated Financial Statements.

[0000950123-11-039069:mdna:83]
The estimate of our liability for future warranty costs requires us to make significant
assumptions about the amount, timing and nature of the costs we will incur in the future. We review
the assumptions used to determine the liability periodically and we adjust our assumptions based
upon factors such as actual failure rates and cost experience. Numerous factors could affect actual
failure rates and cost experience, including the amount and timing of new product introductions,
changes in manufacturing techniques or locations, components or suppliers used. In recent years,
changes in the warranty liability as the result of the issuance of new warranties and the payments
made have remained relatively stable. Should actual warranty costs differ from our estimates, we
may be required to record adjustments to accruals and expense in the future. At the end of each
accounting period, we evaluate our warranty liabilities and during the second quarter of each year,
we perform a complete reevaluation of our warranty liabilities.

[0000950123-11-039069:mdna:84]
We also may incur costs related to our products that may not be covered under our warranties
and are not covered by insurance, and we may, from time to time, repair or replace installed
products experiencing quality

[0000950123-11-039069:mdna:85]
issues in order to satisfy our customers and to protect our brand. These product quality
issues may be caused by vendor-supplied components that fail to meet required specifications. We
have identified a product quality issue in a heating and cooling product line produced in 2006 and
2007 period that we believe results from a vendor-supplied materials quality issue. To date, we
recorded an expense of $24.4 million for the portion of the issue that is probable and can be
reasonably estimated. No material charges were recorded for this matter in the first quarter of
2011. As of March 31, 2011, we had $14.0 million accrued for this matter. We may incur
additional charges in the future as more information becomes available.

[0000950123-11-039069:mdna:86]
We estimate the costs to settle pending litigation based on experience involving similar
claims and specific facts known. We do not believe that any current or pending or threatened
litigation will have a material adverse effect on our financial position. Litigation and
arbitration, however, involve uncertainties and it is possible that the eventual outcome of
litigation could adversely affect our results of operations for a particular period. We are the
defendant in a class action lawsuit related to certain hearth products we produced and sold that
claims such products are hazardous and that consumers were not adequately warned. On August 23,
2010, the Company and the plaintiffs entered into a binding Memorandum of Understanding (MOU) and
have reached tentative terms for settlement of the case. On January 11, 2011, the court granted
preliminary approval of the settlement. At the parties’ request, the court stayed the lawsuit
shortly after the MOU was signed. The court set June 2, 2011 as the date for the final approval
hearing. We had $9.3 million in expenses to date related to this matter with no additional charges
during the first quarter of 2011.
