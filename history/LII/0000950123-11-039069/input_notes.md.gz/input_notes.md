# LII notes — 0000950123-11-039069


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-039069:notes:1]
[same as prior period, unchanged from 0000950123-10-096054:notes:1]

[0000950123-11-039069:notes:2]
[same as prior period, unchanged from 0000950123-10-096054:notes:2]

[0000950123-11-039069:notes:3]
[same as prior period, unchanged from 0000950123-10-096054:notes:3]

[0000950123-11-039069:notes:4]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three months ended March 31, 2011 and 2010,
   and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended
   March 31, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.

[0000950123-11-039069:notes:5]
[same as prior period, unchanged from 0000950123-10-096054:notes:5]

[0000950123-11-039069:notes:6]
[same as prior period, unchanged from 0000950123-10-096054:notes:6]

[0000950123-11-039069:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on
   management’s best estimates and judgment.

[0000950123-11-039069:notes:8]
We evaluate these estimates and assumptions on an ongoing basis using historical experience
   and other factors, including the current economic environment. We believe these estimates and
   assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when
   facts and circumstances dictate.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-039069:notes:9]
[same as prior period, unchanged from 0000950123-10-096054:notes:11]

[0000950123-11-039069:notes:10]
[same as prior period, unchanged from 0000950123-10-096054:notes:12]

[0000950123-11-039069:notes:11]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Finished goods |  | $ | 324.9 |  |  | $ | 213.7 |  |
| Work in process |  |  | 17.6 |  |  |  | 6.5 |  |
| Raw materials and repair parts |  |  | 182.1 |  |  |  | 137.0 |  |
|  |  |  | 524.6 |  |  |  | 357.2 |  |
| Excess of current cost over last-in, first-out cost |  |  | (71.4 | ) |  |  | (71.0 | ) |
| Total inventories, net |  | $ | 453.2 |  |  | $ | 286.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-11-039069:notes:12]
3. Acquisition:

[0000950123-11-039069:notes:13]
On January 14, 2011, we acquired substantially all the assets of the Kysor/Warren business
   from The Manitowoc Company. Kysor/Warren is a leading manufacturer of refrigerated systems and
   display cases for supermarkets throughout North America and will be included in our Refrigeration
   Segment. The total consideration for the acquisition was $144.2 million, including post-closing
   purchase price working capital adjustments. In connection with this acquisition, we recorded
   goodwill of $43.3 million and intangible assets of $33.4 million. The intangible assets consisted
   of the following: trade names of $5.0 million with indefinite lives, customer relationships of
   $26.2 million with 11 to 12 year lives, and other intangibles of $2.2 million with lives ranging
   from one to eight years. We paid more than the fair value of the underlying net assets as a result
   of expected operational synergies. The entire $43.3 million of goodwill is expected to be
   deductible for tax purposes. The initial accounting for this acquisition is substantially
   complete with the exception of additional minor adjustments as allowed under the purchase
   agreement. Overall, the acquisition would not have had a significant impact on our historical results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950123-11-039069:notes:14]
4. Goodwill:

[0000950123-11-039069:notes:15]
The changes in the carrying amount of goodwill for the first quarter of 2011, in total and by
   segment, are as follows (in millions):

[0000950123-11-039069:notes:16]
|  |  | Balance atDecember 31, |  |  | Acquisitions/ |  |  |  |  |  |  | Balance atMarch |  |
|  |  | 2010 |  |  | (Dispositions) |  |  |  |  |  |  | 31, 2011 |  |
| Segment: |  | Goodwill |  |  | (2) |  |  | Other(3) |  |  | Goodwill |  |
| Residential Heating & Cooling |  | $ | 33.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 33.7 |  |
| Commercial Heating & Cooling. |  |  | 30.0 |  |  |  | — |  |  |  | 1.2 |  |  |  | 31.2 |  |
| Service Experts(1) |  |  | 116.6 |  |  |  | — |  |  |  | 3.7 |  |  |  | 120.3 |  |
| Refrigeration |  |  | 91.5 |  |  |  | 43.3 |  |  |  | 1.3 |  |  |  | 136.1 |  |
|  |  | $ | 271.8 |  |  | $ | 43.3 |  |  | $ | 6.2 |  |  | $ | 321.3 |  |

[0000950123-11-039069:notes:17]
| (1) |  | Service Experts goodwill was reduced for accumulated impairment losses of $208.0 million from prior periods. |
| (2) |  | During 2011, our Refrigeration segment acquired Kysor/Warren which resulted in additional goodwill of $43.3 million. |
| (3) |  | Other consists primarily of changes in foreign currency translation rates. |

[0000950123-11-039069:notes:18]
We performed our annual goodwill impairment test in the first quarter of 2011. Based on this
   test, our fair values exceeded the carrying values for each of our reporting units; therefore, we
   recognized no goodwill impairment for any of our reporting units.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950123-11-039069:notes:19]
5. Derivatives:

[0000950123-11-039069:notes:20]
Objectives and Strategies for Using Derivative Instruments

[0000950123-11-039069:notes:21]
Commodity Price Risk

[0000950123-11-039069:notes:22]
We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of
   metal commodities we use in our production processes. The hedging program includes the use of
   futures contracts, and we enter into these contracts based on our hedging strategy. We use a
   dollar cost averaging strategy for our hedge program. As part of this strategy, a higher
   percentage of commodity price exposures are hedged near term with lower percentages hedged at
   future dates. This strategy provides us with protection against near-term price volatility cause
   by market speculators and market forces, such as supply variation, while allowing us to adjust to
   market price movements over time. Upon entering into futures contracts, we lock in prices and are
   subject to derivative losses should the metal commodity prices decrease and gains should the price
   increase.

[0000950123-11-039069:notes:23]
Interest Rate Risk

[0000950123-11-039069:notes:24]
A portion of our debt bears interest at variable interest rates and therefore, we are subject
   to variability in the cash paid for interest expense. In order to mitigate a portion of the risk,
   we use a hedging strategy to eliminate the variability of cash flows in the interest payments
   associated with the first $100 million of the total variable-rate debt outstanding under our revolving credit facility that is solely due to changes in the
   benchmark interest rate. This strategy allows us to fix a portion of our interest payments.

[0000950123-11-039069:notes:25]
Foreign Currency Risk

[0000950123-11-039069:notes:26]
Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar
   value of assets and liabilities arising in foreign currencies. Our objective for entering into
   foreign currency forward contracts is to mitigate the impact of short-term currency exchange rate
   movements on certain short-term intercompany transactions. In order to meet that objective, we
   periodically enter into foreign currency forward contracts that act as economic hedges against
   changes in foreign currency exchange rates. These forward contracts are not designated as hedges
   and generally expire during the quarter.

[0000950123-11-039069:notes:27]
[same as prior period, unchanged from 0000950123-10-096054:notes:19]

[0000950123-11-039069:notes:28]
We include gains or losses in accumulated other comprehensive income (“AOCI”) from our
   commodity cash flow hedges. The gains or losses related to commodity price hedges are expected to
   be reclassified into earnings based on the prices of the commodities at the settlement dates.
   Assuming that commodity prices remain constant, $6.8 million of derivative gains are expected to be
   reclassified into earnings within the next 12 months. Commodity futures contracts that are
   designated as cash flow hedges and are in place as of March 31, 2011 are scheduled to mature
   through July 2012.

[0000950123-11-039069:notes:29]
We also include gains or losses in AOCI from our $100 million pay-fixed, receive-variable
   interest rate swap with a financial institution at a fixed interest rate of 2.66%. The variable
   portion of the interest rate swap is tied to the 1-Month LIBOR (the benchmark interest rate). The
   interest rates under both the interest rate swap and the underlying debt are reset, the swap is
   settled with the counterparty, and interest is paid, on a monthly basis. Assuming that the interest
   rate environment remains constant, $1.4 million of derivative losses are expected to be
   reclassified into earnings within the next 12 months. The interest rate swap expires October 12,
   2012.

[0000950123-11-039069:notes:30]
[same as prior period, unchanged from 0000950123-10-096054:notes:22]

[0000950123-11-039069:notes:31]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Commodity Price Hedges: |  |  |  |  |  |  |  |  |
| Gains included in AOCI, net of tax |  | $ | (6.9 | ) |  | $ | (11.7 | ) |
| Provision for income taxes |  |  | 3.9 |  |  |  | 6.7 |  |
| Interest Rate Swap: |  |  |  |  |  |  |  |  |
| Losses included in AOCI, net of tax |  | $ | 2.0 |  |  | $ | 2.3 |  |
| Benefit from income taxes |  |  | (1.1 | ) |  |  | (1.3 | ) |

[0000950123-11-039069:notes:32]
[same as prior period, unchanged from 0000950123-10-096054:notes:24]

[0000950123-11-039069:notes:33]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 20.1 |  |  |  | 18.5 |  |

[0000950123-11-039069:notes:34]
[same as prior period, unchanged from 0000950123-10-096054:notes:26]

[0000950123-11-039069:notes:35]
[same as prior period, unchanged from 0000950123-10-096054:notes:27]

[0000950123-11-039069:notes:36]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (pounds) |  |  | (pounds) |  |
| Copper |  |  | 1.7 |  |  |  | 1.4 |  |
| Aluminum |  |  | 2.3 |  |  |  | 1.4 |  |

[0000950123-11-039069:notes:37]
We had the following outstanding foreign currency forward contracts not designated as cash
   flow hedges (in millions):

[0000950123-11-039069:notes:38]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Notional amounts: |  |  |  |  |  |  |  |  |
| Brazilian Real |  |  | 5.6 |  |  |  | 5.6 |  |
| Mexican Peso |  |  | 119.0 |  |  |  | 138.0 |  |
| Euros |  |  | 15.6 |  |  |  | 15.6 |  |
| British Pounds |  |  | 2.0 |  |  |  | 2.0 |  |

[0000950123-11-039069:notes:39]
[same as prior period, unchanged from 0000950123-10-096054:notes:30]

[0000950123-11-039069:notes:40]
The following table provides the location and amounts of derivative fair values in the
   Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of
   Operations (in millions):

[0000950123-11-039069:notes:41]
|  |  | Fair Values of Derivative Instruments(1) |  |
|  |  | Derivatives Designated as |  |  | Derivatives Not Designated as |  |
|  |  | Hedging Instruments |  |  | Hedging Instruments |  |
|  |  | As of March 31, |  |  | As of December 31, |  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 10.9 |  |  | $ | 17.4 |  |  | $ | 0.9 |  |  | $ | 1.4 |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  |  | 0.2 |  |  |  | 1.3 |  |  |  | — |  |  |  | 0.1 |  |
| Total Assets |  | $ | 11.1 |  |  | $ | 18.7 |  |  | $ | 0.9 |  |  | $ | 1.7 |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | $ | 2.2 |  |  | $ | 2.2 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 0.9 |  |  |  | 1.4 |  |  |  | — |  |  |  | — |  |
| Total Liabilities |  | $ | 3.1 |  |  | $ | 3.6 |  |  | $ | 0.3 |  |  | $ | — |  |

[0000950123-11-039069:notes:42]
| (1) |  | All our derivative instruments are classified as Level 2 within the fair value hierarchy. For more information on other fair value measurements, see Note 15. |

[0000950123-11-039069:notes:43]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Amount of Loss or (Gain) Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |  |  |  |
| Commodity futures contracts(1) |  | $ | (5.2 | ) |  | $ | (2.9 | ) |
| Interest rate swap(2) |  |  | 0.6 |  |  |  | 0.6 |  |
|  |  | $ | (4.6 | ) |  | $ | (2.3 | ) |

[0000950123-11-039069:notes:44]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Amount of (Gain) or Loss Recognized in Income on Derivatives: |  |  |  |  |  |  |  |  |
| Commodity futures contracts(3) |  | $ | 0.1 |  |  | $ | (0.3 | ) |
| Foreign currency forward contracts(3) |  |  | 0.9 |  |  |  | (0.7 | ) |
|  |  | $ | 1.0 |  |  | $ | (1.0 | ) |

[0000950123-11-039069:notes:45]
| (1) |  | The loss (gain) is recorded in Cost of Goods Sold in the accompanying Consolidated Statements of Operations. |
| (2) |  | The loss (gain) is recorded in Interest Expense, net in the accompanying Consolidated Statements of Operations. |
| (3) |  | The loss (gain) is recorded in Gains and Other Expenses, net in the accompanying Consolidated Statements of Operations. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-039069:notes:46]
6. Income Taxes:

[0000950123-11-039069:notes:47]
As of March 31, 2011, we had approximately $1.1 million in total gross unrecognized tax
   benefits. Of this amount, $0.7 million (net of federal benefit on state issues), if recognized,
   would be recorded through the Consolidated Statement of Operations. As of March 31, 2011, we
   recognized $0.1 million (net of federal tax benefits) in interest and penalties in income tax
   expense in accordance with Financial Accounting Standards Board (“FASB”) Accounting Standards
   Codification (“ASC”) Topic 740.

[0000950123-11-039069:notes:48]
We are currently under examination for our U.S. federal income taxes for 2011, 2010, 2009 and
   2008 and are subject to examination by numerous other taxing authorities in the U.S. and in
   jurisdictions such as Australia, Belgium, France, Canada, and Germany. We are generally no longer
   subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities
   for years before 2005.

[0000950123-11-039069:notes:49]
Since January 1, 2011, numerous states including Arizona and Illinois have enacted
   legislation effective for tax years beginning on or after January 1, 2011, including changes to
   rates and changes to apportionment methods. We believe any adjustments will be immaterial.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-039069:notes:50]
7. Commitments and Contingencies:

[0000950123-11-039069:notes:51]
We are subject to contingencies that arise in the normal course of business, including product
   warranties and other product related contingencies, pending litigation, environmental matters and
   other guarantees or claims.

[0000950123-11-039069:notes:52]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends and because we have a captive insurance company, we are
   required to maintain specified levels of liquid assets from which we must pay claims. The majority
   of our self-insured risks (excluding auto liability and physical damage) will be paid over an
   extended period of time. There have been no material changes since our latest fiscal year-end. We
   also maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued expenses in the
   accompanying Consolidated Balance Sheets were $64.8 million and $61.3 million as of March 31, 2011
   and December 31, 2010, respectively.

[0000950123-11-039069:notes:53]
Product Warranties and Product Related Contingencies

[0000950123-11-039069:notes:54]
Total liabilities for estimated warranty are included in the following captions on the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-039069:notes:55]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 32.8 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 43.5 |  |  |  | 44.3 |  |
|  |  | $ | 76.3 |  |  | $ | 75.5 |  |

[0000950123-11-039069:notes:56]
The changes in the total warranty liabilities for the first quarter of 2011 were as
   follows (in millions):

[0000950123-11-039069:notes:57]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (6.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 5.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | 0.2 |  |
| Changes in foreign currency translation rates and other |  |  | 1.5 |  |
| Total warranty liability as of March 31, 2011 |  | $ | 76.3 |  |

[0000950123-11-039069:notes:58]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our heating, ventilation and air
   conditioning (“HVAC”) warranty liabilities.

[0000950123-11-039069:notes:59]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances since our latest
   fiscal year-end.

[0000950123-11-039069:notes:60]
We may also incur costs related to our products that may not be covered under our warranties
   and are not covered by insurance, and we may, from time to time, repair or replace installed
   products experiencing quality issues in order to satisfy our customers and to protect our brand.
   These product quality issues may be caused by vendor-supplied components that fail to meet required
   specifications.

[0000950123-11-039069:notes:61]
In addition to normal product warranty, we have identified a product quality issue in a
   heating and cooling product line produced in 2006 and 2007 that we believe results from a
   vendor-supplied materials quality issue. The expense for this product quality issue, and the
   related liability, is not included in the tables related to our estimated warranty liabilities.
   The expense related to this product quality issue was classified in Cost of Goods Sold in the
   Consolidated Statements of Operations and the related liability is included in Accrued Expenses in
   the accompanying Consolidated Balance Sheets. We may incur additional charges in the future as more
   information becomes available. The changes in the accrued product quality issue for the first
   quarter of 2011 were as follows (in millions):

[0000950123-11-039069:notes:62]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (2.0 | ) |
| Total accrued product quality issue as of March 31, 2011 |  | $ | 14.0 |  |

[0000950123-11-039069:notes:63]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period. We are the
   defendant in a class action lawsuit related to certain hearth products we produced and sold that
   claims such products are hazardous and that consumers were not adequately warned. On August, 23,
   2010, the Company and plaintiffs entered into a binding Memorandum of Understanding (“MOU”) and
   reached tentative terms for settlement of the case. At the parties’ request, the court stayed the
   lawsuit shortly after the MOU was signed. On January 11, 2011, the court granted preliminary
   approval of the settlement. The court set June 2, 2011 as the date for the final approval hearing.
   We had $9.3 million in expenses to date related to this matter with no additional charges during
   the first quarter of 2011.

[0000950123-11-039069:notes:64]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of March 31, 2011.


## us-gaap:DebtDisclosureTextBlock

[0000950123-11-039069:notes:65]
8. Lines of Credit and Financing Arrangements:

[0000950123-11-039069:notes:66]
The following tables summarize our outstanding debt obligations and the classification in the
   accompanying Consolidated Balance Sheets (in millions):

[0000950123-11-039069:notes:67]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 2.7 |  |  | $ | 1.4 |  |
| Asset securitization |  |  | 50.0 |  |  |  | — |  |
| Total short-term debt |  | $ | 52.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 17.0 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 271.5 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 488.5 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 541.6 |  |  | $ | 319.0 |  |

[0000950123-11-039069:notes:68]
Short-Term Debt

[0000950123-11-039069:notes:69]
Foreign Obligations

[0000950123-11-039069:notes:70]
Through several of our foreign subsidiaries, we have $10.9 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $10.9 million and $10.1 million of available capacity as of March 31, 2011 and December 31,
   2010, respectively. Our foreign obligations of $2.7 million represented borrowings under
   non-committed facilities.

[0000950123-11-039069:notes:71]
Asset Securitization

[0000950123-11-039069:notes:72]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retained the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The ASA provides for a maximum securitization
   amount of $100.0 million or 100% of the net pool balance as defined by the ASA. However,
   eligibility for securitization is limited based on the amount and quality of the qualifying
   accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any
   point in time. In the first quarter of 2011, we sold a beneficial interest in $50.0 million of our
   trade accounts receivable under the ASA. Because the ASA matures in November 2011, we classified
   the related debt as short-term on the Consolidated Balance Sheet. The eligible amounts available
   and beneficial interests sold were as follows (in millions):

[0000950123-11-039069:notes:73]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 94.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | 50.0 |  |  |  | — |  |
| Remaining amount available |  | $ | 44.0 |  |  | $ | 100.0 |  |

[0000950123-11-039069:notes:74]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of March 31, 2011 and December 31, 2010 was 1.06% for both periods. The unused fee is based on
   102% of the maximum available amount less the beneficial interest sold and calculated at a 0.375%
   fixed rate throughout the term of the agreement. We recorded these fees in Selling, General and
   Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

[0000950123-11-039069:notes:75]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |

[0000950123-11-039069:notes:76]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating. We continue to evaluate its credit rating and have no reason to believe it will not
   perform under the ASA. As of March 31, 2011, we were in compliance with all covenant requirements.

[0000950123-11-039069:notes:77]
Long-Term Debt

[0000950123-11-039069:notes:78]
Domestic Revolving Credit Facility

[0000950123-11-039069:notes:79]
Under the $650 million domestic revolving credit facility, we had outstanding borrowings of
   $271.5 million and $69.5 million committed to standby letters of credit as of March 31, 2011.
   Subject to covenant limitations, $309.0 million was available for future borrowings. Included in
   this facility is a subfacility for swingline loans of up to $50 million and provides for the
   issuance of letters of credit for the full amount of the credit facility. The subfacility is fully
   drawn and is included in our outstanding borrowings. This domestic revolving credit facility
   matures in October 2012.

[0000950123-11-039069:notes:80]
Our weighted average borrowing rate on the facility was as follows:

[0000950123-11-039069:notes:81]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.05 | % |  |  | 0.96 | % |

[0000950123-11-039069:notes:82]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a
   Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The
   required ratios under our domestic revolving credit facility as of March 31, 2011 are detailed
   below:

[0000950123-11-039069:notes:83]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than |  |  | 3.5 : 1.0 |  |
| Cash Flow to Net Interest Expense Ratio no less than |  |  | 3.0 : 1.0 |  |

[0000950123-11-039069:notes:84]
Our domestic revolving credit facility contains customary events of default. These events of
   default include nonpayment of principal or interest, breach of covenants or other restrictions or
   requirements, default on certain other indebtedness or receivables securitizations (cross default),
   and bankruptcy. A cross default under our revolving credit facility could occur if:

[0000950123-11-039069:notes:85]
|  | • |  | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $40.0 million; or |
|  | • |  | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $40.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0000950123-11-039069:notes:86]
Each of our major debt agreements contains provisions by which a default under one agreement
   causes a default in the others (a cross default). If a cross default under the revolving credit
   facility, our senior unsecured notes, or our revolving period asset securitization program were to
   occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a
   single debt instrument or lease commitment.

[0000950123-11-039069:notes:87]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will
   automatically terminate). As of March 31, 2011, we were in compliance with all covenant
   requirements.

[0000950123-11-039069:notes:88]
Senior Unsecured Notes

[0000950123-11-039069:notes:89]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid
   semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

[0000950123-11-039069:notes:90]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic
   subsidiaries that guarantee payment by us of any indebtedness under our domestic revolving credit
   facility. The indenture governing the notes contains covenants that, among other things, limit our
   ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into
   certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers
   of substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of March 31, 2011, we were in compliance with all covenant requirements and these
   covenants have not changed from December 31, 2010.

[0000950123-11-039069:notes:91]
Credit Rating

[0000950123-11-039069:notes:92]
At March 31, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-, with
   a stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.

[0000950123-11-039069:notes:93]
Other Financing Arrangements

[0000950123-11-039069:notes:94]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. As of March 31, 2011 and December 31, 2010, we
   had $10.5 million and $12.2 million in Restricted Cash on the accompanying Consolidated Balance
   Sheets to pay these claims.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950123-11-039069:notes:95]
9. Pension and Postretirement Benefit Plans:

[0000950123-11-039069:notes:96]
[same as prior period, unchanged from 0000950123-10-096054:notes:84]

[0000950123-11-039069:notes:97]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
|  |  | Pension Benefits |  |  | Other Benefits |  |
| Service cost |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Interest cost |  |  | 4.5 |  |  |  | 4.4 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Expected return on plan assets |  |  | (4.8 | ) |  |  | (4.8 | ) |  |  | — |  |  |  | — |  |
| Amortization of prior service cost |  |  | 0.1 |  |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Amortization of net loss |  |  | 1.7 |  |  |  | 2.2 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Settlements or curtailments |  |  | 1.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net periodic pension cost |  | $ | 4.4 |  |  | $ | 3.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950123-11-039069:notes:98]
10. Comprehensive Income:

[0000950123-11-039069:notes:99]
The changes in the components of other comprehensive income, net of taxes, were as follows (in
   millions):

[0000950123-11-039069:notes:100]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net loss |  | $ | (7.2 | ) |  | $ | (1.6 | ) |
| Foreign currency translation adjustments, net |  |  | 16.2 |  |  |  | 8.4 |  |
| Derivatives, net of tax benefit of $2.6 and $0.1 in 2011 and 2010, respectively |  |  | (5.0 | ) |  |  | (0.5 | ) |
| Comprehensive income |  | $ | 4.0 |  |  | $ | 6.3 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-039069:notes:101]
11. Stock-Based Compensation:

[0000950123-11-039069:notes:102]
The Lennox International Inc. 2010 Incentive Plan, as amended and restated provides for various
   long-term incentive awards, which include stock options, performance share units, restricted stock
   units and stock appreciation rights. Net stock-based compensation expense recognized was as follows
   (in millions):

[0000950123-11-039069:notes:103]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net stock-based compensation expense |  | $ | 4.9 |  |  | $ | 4.3 |  |

[0000950123-11-039069:notes:104]
These expenses are included in Selling, General and Administrative Expenses in the
   accompanying Consolidated Statements of Operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950123-11-039069:notes:105]
12. Restructuring Charges:

[0000950123-11-039069:notes:106]
As part of our strategic priorities of manufacturing and sourcing excellence and expense
   reduction, we initiated various manufacturing rationalization actions designed to lower our cost
   structure. We expanded these expense reductions across the organization by initiating a number of
   activities to rationalize and reorganize various support and administrative functions.
   Restructuring charges are not included in our calculation of segment (loss) profit, see Note 14 for
   further discussion. Detailed below are the restructuring activities that we anticipate incurring
   additional expense in 2011.

[0000950123-11-039069:notes:107]
2010 Plans

[0000950123-11-039069:notes:108]
Refrigeration

[0000950123-11-039069:notes:109]
We began to exit certain Refrigeration manufacturing operations in Milperra, Australia in
   2010, specifically our contract coil and OEM coil manufacturing. In the first quarter of 2010, we
   began to exit the OEM coil manufacturing with total restructuring charges of $5.8 million composed
   of $4.4 million in severance, $1.2 million in asset impairment charges, and $0.2 million in other
   charges. This activity was substantially complete in 2010. We initiated the restructuring
   activities related to exiting contract coil manufacturing in the third quarter of 2010. The total
   restructuring charges related to this activity were $4.2 million composed of $3.1 million in
   severance, $0.4 million in asset impairment and accelerated
   depreciation, and $0.7 million in other charges. In the
   first quarter of 2011, we recognized $0.5 million in other plant closure costs related to these
   restructuring activities.

[0000950123-11-039069:notes:110]
Service Experts

[0000950123-11-039069:notes:111]
We began to reorganize certain administrative functions and the management structure of our
   Service Experts business in 2010. We initiated two actions in 2010. The first action, started in
   the second quarter of 2010, was to reorganize the administrative operations of an acquired company.
   This project was completed in 2010. The second action, initiated in the fourth quarter of 2010,
   was to reorganize the management structure of our Service Experts business. Expected restructuring
   charges for this project are $1.5 million and consist principally of severance charges. We
   anticipate this action to complete in the third quarter of 2011. We recognized $0.3 million in
   lease termination and other costs in the first quarter of 2011.

[0000950123-11-039069:notes:112]
2009 and Prior Plans

[0000950123-11-039069:notes:113]
In the fourth quarter of 2009, we began to consolidate certain Refrigeration manufacturing
   operations located in Parets, Spain into our existing operations in Genas, France. This activity
   had total restructuring charges of $8.5 million, consisting of
   $6.1 million in severance, $1.2
   million in asset impairment and equipment moves, and $1.1 million in other charges, and was substantially complete by
   the fourth quarter of 2010.

[0000950123-11-039069:notes:114]
Commercial Heating & Cooling

[0000950123-11-039069:notes:115]
We completed the consolidation of certain manufacturing operations from Mions, France into our
   Longvic, France operations in the first quarter of 2010. This activity had total restructuring
   charges of $6.3 million which consist primarily of severance charges. We reversed $0.1 million in
   severance charges in the first quarter of 2011 to adjust estimated charges to actual.
   Additionally, included in our 2009 and Prior Plans was a reorganization of various administration
   functions for the Commercial Heating & Cooling Segment.

[0000950123-11-039069:notes:116]
Residential Heating & Cooling

[0000950123-11-039069:notes:117]
Included in our 2009 and Prior Plans was a consolidation of our manufacturing operations from
   Blackville,
   South Carolina into our Orangeburg, South Carolina and Saltillo, Mexico operations. The
   consolidation is expected to be complete by the fourth quarter of 2011 with expected total
   restructuring charges of $14.2 million. These charges consist of $3.1 million in severance, $6.0
   million in asset impairment and accelerated depreciation, and $5.2 million in other costs. We
   recognized $0.3 million in restructuring charges in the first quarter of 2011 related to other
   plant closure costs.

[0000950123-11-039069:notes:118]
Regional Distribution Network

[0000950123-11-039069:notes:119]
In the fourth quarter of 2008, we commenced the transition of activities performed at our
   North American Parts Center in Des Moines, Iowa to other locations, including our North American
   Distribution Center in Marshalltown, Iowa. To date, we incurred $3.2 million, primarily severance
   costs, and we expect the total cost to be $3.6 million. The total costs of this project include
   $2.7 million in severance costs, $0.3 million in moving
   costs, and $0.3 million in other costs.
   The transition is expected to complete by the fourth quarter of 2011.

[0000950123-11-039069:notes:120]
Total Restructuring

[0000950123-11-039069:notes:121]
Information regarding the restructuring charges for all plans is as follows (in millions):

[0000950123-11-039069:notes:122]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Severance and related expense |  | $ | 0.1 |  |  | $ | 50.6 |  |  | $ | 51.0 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | 11.1 |  |  |  | 11.1 |  |
| Equipment moves |  |  | — |  |  |  | 1.2 |  |  |  | 2.1 |  |
| Lease termination |  |  | — |  |  |  | 2.5 |  |  |  | 2.5 |  |
| Other |  |  | 1.1 |  |  |  | 5.9 |  |  |  | 8.5 |  |
| Total |  | $ | 1.2 |  |  | $ | 71.3 |  |  | $ | 75.2 |  |

[0000950123-11-039069:notes:123]
Information regarding the restructuring charges by segment is as follows (in millions):

[0000950123-11-039069:notes:124]
|  |  |  |  |  |  |  |  |  |  | Total |  |
|  |  | Charges |  |  | Charges |  |  | Charges |  |
|  |  | Incurred in |  |  | Incurred to |  |  | Expected to |  |
|  |  | 2011 |  |  | Date |  |  | be Incurred |  |
| Residential Heating & Cooling |  | $ | 0.3 |  |  | $ | 16.0 |  |  | $ | 18.9 |  |
| Commercial Heating & Cooling |  |  | — |  |  |  | 10.4 |  |  |  | 10.6 |  |
| Service Experts |  |  | 0.3 |  |  |  | 3.6 |  |  |  | 3.6 |  |
| Refrigeration |  |  | 0.6 |  |  |  | 29.8 |  |  |  | 30.6 |  |
| Corporate & Other |  |  | — |  |  |  | 11.5 |  |  |  | 11.5 |  |
| Total |  | $ | 1.2 |  |  | $ | 71.3 |  |  | $ | 75.2 |  |

[0000950123-11-039069:notes:125]
Restructuring reserves are included in Accrued Expenses in the accompanying Consolidated
   Balance Sheets. The table below details activity within the restructuring reserves for the first
   quarter of 2011 (in millions):

[0000950123-11-039069:notes:126]
|  |  | Balance as of |  |  | Charged |  |  |  |  |  |  | Non-Cash |  |  | Balance as of |  |
|  |  | December 31, |  |  | to |  |  | Cash |  |  | Utilization and |  |  | March 31, |  |
| Description of Reserves |  | 2010 |  |  | Earnings |  |  | Utilization |  |  | Other |  |  | 2011 |  |
| Severance and related expense |  | $ | 6.2 |  |  | $ | 0.2 |  |  | $ | (2.0 | ) |  | $ | 0.1 |  |  | $ | 4.5 |  |
| Asset write-offs and accelerated depreciation |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Equipment moves |  |  | — |  |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |
| Lease termination |  |  | 0.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Other |  |  | 0.7 |  |  |  | 0.9 |  |  |  | (0.9 | ) |  |  | 0.1 |  |  |  | 0.8 |  |
| Total restructuring reserves |  | $ | 7.2 |  |  | $ | 1.2 |  |  | $ | (3.0 | ) |  | $ | 0.2 |  |  | $ | 5.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-039069:notes:127]
13. Loss Per Share:

[0000950123-11-039069:notes:128]
Due to the net losses recorded in the first quarters of 2011 and 2010, both basic and diluted
   net loss per share are computed by dividing net loss by the weighted-average number of common
   shares outstanding during the period.

[0000950123-11-039069:notes:129]
The computations of basic and diluted loss per share for Loss from Continuing Operations were
   as follows (in millions, except per share data):

[0000950123-11-039069:notes:130]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net loss |  | $ | (7.2 | ) |  | $ | (1.6 | ) |
| Add: Loss from discontinued operations |  |  | — |  |  |  | 0.3 |  |
| Loss from continuing operations |  | $ | (7.2 | ) |  | $ | (1.3 | ) |
| Weighted-average shares outstanding — basic and diluted |  |  | 53.6 |  |  |  | 56.0 |  |
| Loss per share from continuing operations — basic and diluted |  | $ | (0.13 | ) |  | $ | (0.02 | ) |

[0000950123-11-039069:notes:131]
Not included in the 2011 and 2010 computations of diluted loss per share were 1,128,847 and
   1,274,529 shares, respectively, of potentially dilutive securities, including stock options, stock
   appreciation rights, restricted stock units and performance share units as these shares would be
   anti-dilutive. These shares were anti-dilutive due to the loss position in both periods.

[0000950123-11-039069:notes:132]
Additionally, stock appreciation rights were outstanding, but not included in the diluted loss
   per share calculation because the assumed exercise of such rights would be anti-dilutive. The
   details are as follows:

[0000950123-11-039069:notes:133]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Number of shares |  |  | 464,314 |  |  |  | 555,628 |  |
| Price per share |  | $ | 46.78 |  |  | $ | 36.94 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-039069:notes:134]
14. Reportable Business Segments:

[0000950123-11-039069:notes:135]
We operate in four reportable business segments of the heating, ventilation, air conditioning
   and refrigeration (“HVACR”) industry. Our segments are organized primarily by the nature of the
   products and services provided. The table below details the nature of the operations for each
   reportable segment:

[0000950123-11-039069:notes:136]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Heating Air Conditioning Hearth Products |  | Residential Replacement Residential New Construction |  | United States Canada |
| Commercial Heating & Cooling |  | Rooftop Products Chillers Air Handlers |  | Light Commercial |  | United States Canada Europe |
| Service Experts |  | Equipment Sales Installation Maintenance Repair |  | Residential Light Commercial |  | United States Canada |
| Refrigeration |  | Unit Coolers Condensing Units Other Commercial Refrigeration Products Display Cases and Systems |  | Light Commercial Food Preservation and Non-Food/Industrial |  | United States Canada Europe Asia Pacific South America |

[0000950123-11-039069:notes:137]
Transactions between segments, such as products sold to Service Experts by the
   Residential Heating & Cooling segment, are recorded on an arm’s-length basis using the market price
   for these products. The eliminations of these intercompany sales and any associated profit are
   noted in the reconciliation of segment results to the income from continuing operations before
   income taxes below.

[0000950123-11-039069:notes:138]
We use segment profit or loss as the primary measure of profitability to evaluate operating
   performance and to allocate capital resources. We define segment profit or loss as a segment’s
   income or loss from continuing operations before income taxes included in the accompanying
   Consolidated Statements of Operations:

[0000950123-11-039069:notes:139]
|  |  |  | Excluding: |

[0000950123-11-039069:notes:140]
|  | • |  | Gains and/or losses and other expenses, net except for gains and/or losses on the sale of fixed assets |
|  | • |  | Restructuring charges |
|  | • |  | Goodwill and equity method investment impairments |
|  | • |  | Interest expense, net |
|  | • |  | Other expense, net |

[0000950123-11-039069:notes:141]
|  |  |  | Less amounts included in Gains and Other Expenses, net: |

[0000950123-11-039069:notes:142]
|  | • |  | Realized gains and/or losses on settled futures contracts |
|  | • |  | Foreign currency exchange gains and/or losses |

[0000950123-11-039069:notes:143]
[same as prior period, unchanged from 0000950123-10-096054:notes:136]

[0000950123-11-039069:notes:144]
Net sales and segment (loss) profit by business segment, along with a reconciliation of
   segment (loss) profit to Loss from Continuing Operations Before Income Taxes are shown below (in
   millions):

[0000950123-11-039069:notes:145]
|  |  | For the Three Months |  |
|  |  | Ended March, 31 |  |
|  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 272.0 |  |  | $ | 284.2 |  |
| Commercial Heating & Cooling |  |  | 138.8 |  |  |  | 119.7 |  |
| Service Experts |  |  | 116.5 |  |  |  | 127.1 |  |
| Refrigeration |  |  | 175.1 |  |  |  | 131.4 |  |
| Eliminations (1) |  |  | (14.6 | ) |  |  | (18.3 | ) |
|  |  | $ | 687.8 |  |  | $ | 644.1 |  |
| Segment (Loss)Profit(2) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | (1.2 | ) |  | $ | 7.1 |  |
| Commercial Heating & Cooling |  |  | 5.9 |  |  |  | 3.4 |  |
| Service Experts |  |  | (8.2 | ) |  |  | (4.6 | ) |
| Refrigeration |  |  | 13.5 |  |  |  | 14.9 |  |
| Corporate and other |  |  | (14.5 | ) |  |  | (13.2 | ) |
| Eliminations (1) |  |  | (0.4 | ) |  |  | 0.2 |  |
| Subtotal that includes segment (loss) profit and eliminations |  |  | (4.9 | ) |  |  | 7.8 |  |
| Reconciliation to loss from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Items in gains and other expenses, net that are excluded from segment (loss) profit (3) |  |  | 0.9 |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | 7.2 |  |
| Interest expense, net |  |  | 4.1 |  |  |  | 2.5 |  |
| Loss from continuing operations before income taxes |  | $ | (11.1 | ) |  | $ | (2.0 | ) |

[0000950123-11-039069:notes:146]
| (1) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |

[0000950123-11-039069:notes:147]
| (2) |  | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |
|  |  | Excluding: |

[0000950123-11-039069:notes:148]
|  | • |  | Special product quality adjustments. |
|  | • |  | Items within Gains and/or losses and other expenses, net that are noted in (3). |
|  | • |  | Restructuring charges. |
|  | • |  | Goodwill and equity method investment impairments. |
|  | • |  | Interest expense, net. |
|  | • |  | Other expense, net. |

[0000950123-11-039069:notes:149]
| (3) |  | Items in Gains and/or losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-039069:notes:150]
[same as prior period, unchanged from 0000950123-10-096054:notes:142]

[0000950123-11-039069:notes:151]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Total Assets |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 606.4 |  |  | $ | 519.8 |  |
| Commercial Heating & Cooling |  |  | 270.5 |  |  |  | 252.7 |  |
| Service Experts |  |  | 184.1 |  |  |  | 186.2 |  |
| Refrigeration (2) |  |  | 577.2 |  |  |  | 389.7 |  |
| Corporate and other |  |  | 271.1 |  |  |  | 354.9 |  |
| Eliminations (1) |  |  | (8.9 | ) |  |  | (11.3 | ) |
| Total assets |  | $ | 1,900.4 |  |  | $ | 1,692.0 |  |

[0000950123-11-039069:notes:152]
| (1) |  | Eliminations consist of net intercompany receivables and intercompany profit included in inventory from products sold between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (2) |  | The increase in Total assets for the Refrigeration segment is primarily related to the Kysor/Warren acquisition. See Note 3 for more information on this acquisition. |


## us-gaap:FairValueDisclosuresTextBlock

[0000950123-11-039069:notes:153]
15. Fair Value Measurements:

[0000950123-11-039069:notes:154]
[same as prior period, unchanged from 0000950123-10-096054:notes:146]

[0000950123-11-039069:notes:155]
[same as prior period, unchanged from 0000950123-10-096054:notes:147]

[0000950123-11-039069:notes:156]
|  |  | Quoted Prices in Active Markets for |  |
|  |  | Identical Assets (Level 1) |  |
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Assets: |  |  |  |  |  |  |  |  |
| Investment in marketable equity securities (1) |  | $ | 17.0 |  |  | $ | 18.0 |  |

[0000950123-11-039069:notes:157]
| (1) |  | Investment in marketable equity securities is recorded in Other Assets, net in the accompanying Consolidated Balance Sheets. |

[0000950123-11-039069:notes:158]
[same as prior period, unchanged from 0000950123-10-096054:notes:151]

[0000950123-11-039069:notes:159]
The carrying amounts of cash and cash equivalents, accounts and notes receivable, net,
   accounts payable and other current liabilities approximate fair value due to the short maturities
   of these instruments. The fair values of each of our long-term debt instruments are based on the
   quoted market prices for the same issues or on the amount of future cash flows associated with each
   instrument using current market rates for debt instruments of similar maturities and credit risk. The fair values presented are estimates and are not
   necessarily indicative of
   amounts for which we could settle such instruments currently or
   indicative of our intent or ability to dispose of or liquidate them. The estimated fair value of
   our debt was as follows (in millions):

[0000950123-11-039069:notes:160]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Long-term debt (1) |  | $ | 283.4 |  |  | $ | 114.6 |  |
| Senior unsecured notes |  |  | 210.7 |  |  |  | 203.0 |  |

[0000950123-11-039069:notes:161]
| (1) |  | Long-term debt includes our domestic revolving credit facility, capital lease obligations, foreign obligations and any related current maturities. |


## us-gaap:ScheduleOfCondensedFinancialStatementsTextBlock

[0000950123-11-039069:notes:162]
16. Condensed Consolidating Financial Statements

[0000950123-11-039069:notes:163]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the
   Company’s subsidiaries (the “Guarantor Subsidiaries”) while they are not by other subsidiaries (the
   “Non-Guarantor Subsidiaries”). As a result of the guarantee arrangements, we are required to
   present the following condensed consolidating financial statements. During the first quarter of
   2011, our guarantor and non-guarantor subsidiary structure changed as required by our credit
   facility due to the Kysor/Warren acquisition. Three subsidiaries previously classified as
   non-guarantor subsidiaries as of December 31, 2010 are now classified as guarantor subsidiaries as
   of March 31, 2011. These changes will be reflected in the condensed consolidating financial
   statements for periods after December 31, 2010.

[0000950123-11-039069:notes:164]
[same as prior period, unchanged from 0000950123-10-096054:notes:155]

[0000950123-11-039069:notes:165]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and
   Non-Guarantor Subsidiaries as of March 31, 2011 and December 31, 2010 and for the three months
   ended March 31, 2011 and 2010 are shown below:

[0000950123-11-039069:notes:166]
[same as prior period, unchanged from 0000950123-10-096054:notes:157]

[0000950123-11-039069:notes:167]
As of March 31, 2011

[0000950123-11-039069:notes:168]
[same as prior period, unchanged from 0000950123-10-096054:notes:159]

[0000950123-11-039069:notes:169]
|  |  |  |  |  |  | Guarantor |  |  | Non-Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | 13.8 |  |  | $ | 41.4 |  |  | $ | — |  |  | $ | 55.2 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 10.5 |  |  |  | — |  |  |  | 10.5 |  |
| Accounts and notes receivable, net |  |  | (886.2 | ) |  |  | 942.2 |  |  |  | 347.4 |  |  |  | 1.2 |  |  |  | 404.6 |  |
| Inventories, net |  |  | — |  |  |  | 336.2 |  |  |  | 122.2 |  |  |  | (5.2 | ) |  |  | 453.2 |  |
| Deferred income taxes |  |  | 4.4 |  |  |  | 30.7 |  |  |  | 9.2 |  |  |  | (3.1 | ) |  |  | 41.2 |  |
| Other assets |  |  | 12.0 |  |  |  | 24.5 |  |  |  | 137.5 |  |  |  | (91.7 | ) |  |  | 82.3 |  |
| Total current assets |  |  | (869.8 | ) |  |  | 1,347.4 |  |  |  | 668.2 |  |  |  | (98.8 | ) |  |  | 1,047.0 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 265.5 |  |  |  | 82.9 |  |  |  | — |  |  |  | 348.4 |  |
| GOODWILL |  |  | — |  |  |  | 110.6 |  |  |  | 210.7 |  |  |  | — |  |  |  | 321.3 |  |
| DEFERRED INCOME TAXES |  |  | (1.5 | ) |  |  | 78.8 |  |  |  | 24.1 |  |  |  | (12.8 | ) |  |  | 88.6 |  |
| OTHER ASSETS, net |  |  | 2,062.6 |  |  |  | 410.4 |  |  |  | 37.6 |  |  |  | (2,415.5 | ) |  |  | 95.1 |  |
| TOTAL ASSETS |  | $ | 1,191.3 |  |  | $ | 2,212.7 |  |  | $ | 1,023.5 |  |  | $ | (2,527.1 | ) |  | $ | 1,900.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 35.0 |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | (35.3 | ) |  | $ | 2.7 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 50.0 |  |  |  | — |  |  |  | 50.0 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | — |  |  |  | 0.4 |  |
| Accounts payable |  |  | 10.0 |  |  |  | 221.2 |  |  |  | 97.5 |  |  |  | 12.1 |  |  |  | 340.8 |  |

[0000950123-11-039069:notes:170]
| Accrued expenses |  |  | 9.6 |  |  |  | 238.5 |  |  |  | 95.2 |  |  |  | (61.5 | ) |  |  | 281.8 |  |
| Income taxes payable |  |  | 17.5 |  |  |  | (17.3 | ) |  |  | (0.5 | ) |  |  | 1.2 |  |  |  | 0.9 |  |
| Total current liabilities |  |  | 72.1 |  |  |  | 442.8 |  |  |  | 245.2 |  |  |  | (83.5 | ) |  |  | 676.6 |  |
| LONG-TERM DEBT |  |  | 471.5 |  |  |  | 21.9 |  |  |  | 127.5 |  |  |  | (132.4 | ) |  |  | 488.5 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.8 |  |  |  | — |  |  |  | — |  |  |  | 15.8 |  |
| PENSIONS |  |  | — |  |  |  | 78.0 |  |  |  | 10.6 |  |  |  | 0.1 |  |  |  | 88.7 |  |
| OTHER LIABILITIES |  |  | 5.1 |  |  |  | 55.4 |  |  |  | 16.8 |  |  |  | (12.9 | ) |  |  | 64.4 |  |
| Total liabilities |  |  | 548.7 |  |  |  | 613.9 |  |  |  | 400.1 |  |  |  | (228.7 | ) |  |  | 1,334.0 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 642.6 |  |  |  | 1,598.8 |  |  |  | 623.4 |  |  |  | (2,298.4 | ) |  |  | 566.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,191.3 |  |  | $ | 2,212.7 |  |  | $ | 1,023.5 |  |  | $ | (2,527.1 | ) |  | $ | 1,900.4 |  |

[0000950123-11-039069:notes:171]
[same as prior period, unchanged from 0000950123-10-096054:notes:162]

[0000950123-11-039069:notes:172]
For the Three Months Ended March 31, 2011

[0000950123-11-039069:notes:173]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 515.9 |  |  | $ | 216.5 |  |  | $ | (44.6 | ) |  | $ | 687.8 |  |
| COST OF GOODS SOLD |  |  | — |  |  |  | 402.8 |  |  |  | 165.4 |  |  |  | (45.6 | ) |  |  | 522.6 |  |
| Gross profit |  |  | — |  |  |  | 113.1 |  |  |  | 51.1 |  |  |  | 1.0 |  |  |  | 165.2 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 127.7 |  |  |  | 46.1 |  |  |  | 0.1 |  |  |  | 173.9 |  |
| Losses (gains) and other expenses, net |  |  | 0.9 |  |  |  | (0.9 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Restructuring charges |  |  | — |  |  |  | 0.7 |  |  |  | 0.5 |  |  |  | — |  |  |  | 1.2 |  |
| Loss (income) from equity method investments |  |  | 6.2 |  |  |  | 1.1 |  |  |  | (2.3 | ) |  |  | (7.6 | ) |  |  | (2.6 | ) |
| Operational (loss) income from continuing operations |  |  | (7.1 | ) |  |  | (15.5 | ) |  |  | 7.0 |  |  |  | 8.6 |  |  |  | (7.0 | ) |
| INTEREST EXPENSE (INCOME), net |  |  | 4.0 |  |  |  | (0.8 | ) |  |  | 1.0 |  |  |  | (0.1 | ) |  |  | 4.1 |  |
| (Loss) income from continuing operations before income taxes |  |  | (11.1 | ) |  |  | (14.7 | ) |  |  | 6.0 |  |  |  | 8.7 |  |  |  | (11.1 | ) |
| (BENEFIT FROM) PROVISIONS FOR INCOME TAXES |  |  | (1.8 | ) |  |  | (5.0 | ) |  |  | 2.6 |  |  |  | 0.3 |  |  |  | (3.9 | ) |
| (Loss) income from continuing operations |  |  | (9.3 | ) |  |  | (9.7 | ) |  |  | 3.4 |  |  |  | 8.4 |  |  |  | (7.2 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net (loss) income |  | $ | (9.3 | ) |  | $ | (9.7 | ) |  | $ | 3.4 |  |  | $ | 8.4 |  |  | $ | (7.2 | ) |

[0000950123-11-039069:notes:174]
As of December 31, 2010

[0000950123-11-039069:notes:175]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 81.1 |  |  | $ | 14.7 |  |  | $ | 64.2 |  |  | $ | — |  |  | $ | 160.0 |  |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 12.2 |  |  |  | — |  |  |  | 12.2 |  |
| Accounts and notes receivable, net |  |  | (1,169.7 | ) |  |  | 933.3 |  |  |  | 613.2 |  |  |  | 8.0 |  |  |  | 384.8 |  |
| Inventories, net |  |  | — |  |  |  | 163.7 |  |  |  | 128.7 |  |  |  | (6.2 | ) |  |  | 286.2 |  |
| Deferred income taxes |  |  | — |  |  |  | 27.6 |  |  |  | 12.1 |  |  |  | (3.0 | ) |  |  | 36.7 |  |
| Other assets |  |  | 19.3 |  |  |  | 21.0 |  |  |  | 121.2 |  |  |  | (94.5 | ) |  |  | 67.0 |  |
| Total current assets |  |  | (1,069.3 | ) |  |  | 1,160.3 |  |  |  | 951.6 |  |  |  | (95.7 | ) |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net |  |  | — |  |  |  | 202.8 |  |  |  | 121.6 |  |  |  | (0.1 | ) |  |  | 324.3 |  |
| GOODWILL |  |  | — |  |  |  | 50.8 |  |  |  | 225.8 |  |  |  | (4.8 | ) |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | — |  |  |  | 77.3 |  |  |  | 22.6 |  |  |  | (12.7 | ) |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 2,068.3 |  |  |  | 415.6 |  |  |  | 51.8 |  |  |  | (2,473.9 | ) |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 31.1 |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | (31.5 | ) |  | $ | 1.4 |  |
| Current maturities of long-term debt |  |  | — |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |
| Accounts payable |  |  | 8.1 |  |  |  | 133.1 |  |  |  | 131.0 |  |  |  | 1.6 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 6.6 |  |  |  | 262.0 |  |  |  | 115.5 |  |  |  | (49.6 | ) |  |  | 334.5 |  |
| Income taxes payable |  |  | (36.1 | ) |  |  | 30.6 |  |  |  | 28.3 |  |  |  | (17.5 | ) |  |  | 5.3 |  |
| Total current liabilities |  |  | 9.7 |  |  |  | 425.9 |  |  |  | 277.0 |  |  |  | (97.0 | ) |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 300.0 |  |  |  | 5.4 |  |  |  | 139.6 |  |  |  | (128.0 | ) |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | — |  |  |  | 15.9 |  |  |  | — |  |  |  | — |  |  |  | 15.9 |  |
| PENSIONS |  |  | — |  |  |  | 77.4 |  |  |  | 10.7 |  |  |  | — |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 5.8 |  |  |  | 46.8 |  |  |  | 25.9 |  |  |  | (12.8 | ) |  |  | 65.7 |  |
| Total liabilities |  |  | 315.5 |  |  |  | 571.4 |  |  |  | 453.2 |  |  |  | (237.8 | ) |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TOTAL STOCKHOLDERS’ EQUITY |  |  | 683.5 |  |  |  | 1,335.4 |  |  |  | 920.2 |  |  |  | (2,349.4 | ) |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 999.0 |  |  | $ | 1,906.8 |  |  | $ | 1,373.4 |  |  | $ | (2,587.2 | ) |  | $ | 1,692.0 |  |

[0000950123-11-039069:notes:176]
For the Three Months Ended March 31, 2010

[0000950123-11-039069:notes:177]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| NET SALES |  | $ | — |  |  | $ | 429.4 |  |  | $ | 274.2 |  |  | $ | (59.5 | ) |  | $ | 644.1 |  |
| COST OF GOODS SOLD |  |  | — |  |  |  | 322.7 |  |  |  | 206.5 |  |  |  | (59.4 | ) |  |  | 469.8 |  |
| Gross profit |  |  | — |  |  |  | 106.7 |  |  |  | 67.7 |  |  |  | (0.1 | ) |  |  | 174.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 116.4 |  |  |  | 52.6 |  |  |  | (0.1 | ) |  |  | 168.9 |  |
| (Gains) losses and other expenses, net |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |
| Restructuring charges |  |  | — |  |  |  | 2.0 |  |  |  | 5.1 |  |  |  | 0.1 |  |  |  | 7.2 |  |
| Loss (Income) from equity method investments |  |  | 4.8 |  |  |  | 2.9 |  |  |  | (2.0 | ) |  |  | (7.7 | ) |  |  | (2.0 | ) |
| Operational (loss) income from continuing operations |  |  | (4.6 | ) |  |  | (14.5 | ) |  |  | 12.0 |  |  |  | 7.6 |  |  |  | 0.5 |  |
| INTEREST (INCOME) EXPENSE, net |  |  | (0.3 | ) |  |  | 1.9 |  |  |  | 0.9 |  |  |  | — |  |  |  | 2.5 |  |
| (Loss) income from continuing operations before income taxes |  |  | (4.3 | ) |  |  | (16.4 | ) |  |  | 11.1 |  |  |  | 7.6 |  |  |  | (2.0 | ) |
| PROVISIONS FOR (BENEFIT FROM) INCOME TAXES |  |  | 0.2 |  |  |  | (5.0 | ) |  |  | 4.1 |  |  |  | — |  |  |  | (0.7 | ) |
| (Loss) income from continuing operations |  |  | (4.5 | ) |  |  | (11.4 | ) |  |  | 7.0 |  |  |  | 7.6 |  |  |  | (1.3 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.3 |  |  |  | — |  |  |  | 0.3 |  |
| Net (loss) income |  | $ | (4.5 | ) |  | $ | (11.4 | ) |  | $ | 6.7 |  |  | $ | 7.6 |  |  | $ | (1.6 | ) |

[0000950123-11-039069:notes:178]
[same as prior period, unchanged from 0000950123-10-096054:notes:173]

[0000950123-11-039069:notes:179]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | 59.7 |  |  | $ | (131.0 | ) |  | $ | (77.0 | ) |  | $ | — |  |  | $ | (148.3 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.7 |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (7.4 | ) |  |  | (0.8 | ) |  |  | — |  |  |  | (8.2 | ) |
| Acquisition of business |  |  | — |  |  |  | (136.3 | ) |  |  | (7.9 | ) |  |  | — |  |  |  | (144.2 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | 1.6 |  |  |  | — |  |  |  | 1.6 |  |
| Net cash used in investing activities |  |  | — |  |  |  | (143.0 | ) |  |  | (7.1 | ) |  |  | — |  |  |  | (150.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 1.2 |  |  |  | — |  |  |  | 1.2 |  |
| Asset securitization borrowings |  |  | — |  |  |  | — |  |  |  | 50.0 |  |  |  | — |  |  |  | 50.0 |  |
| Long-term payments |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Revolver long-term borrowings, net |  |  | 171.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 171.5 |  |
| Proceeds from stock option exercises |  |  | 0.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.9 |  |
| Repurchases of common stock |  |  | (24.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (24.7 | ) |
| Excess tax benefits related to share-based payments |  |  | 1.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.2 |  |
| Intercompany debt |  |  | 1.8 |  |  |  | (2.3 | ) |  |  | 0.5 |  |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | (283.4 | ) |  |  | 275.6 |  |  |  | 7.8 |  |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (8.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (8.1 | ) |
| Net cash (used in) provided by financing activities |  |  | (140.8 | ) |  |  | 273.1 |  |  |  | 59.5 |  |  |  | — |  |  |  | 191.8 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (81.1 | ) |  |  | (0.9 | ) |  |  | (24.6 | ) |  |  | — |  |  |  | (106.6 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 1.8 |  |  |  | — |  |  |  | 1.8 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 81.1 |  |  |  | 14.7 |  |  |  | 64.2 |  |  |  | — |  |  |  | 160.0 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | — |  |  | $ | 13.8 |  |  | $ | 41.4 |  |  | $ | — |  |  | $ | 55.2 |  |

[0000950123-11-039069:notes:180]
|  |  |  |  |  |  |  |  |  |  | Non- |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Guarantor |  |  | Guarantor |  |  |  |  |  |  |  |
|  |  | Parent |  |  | Subsidiaries |  |  | Subsidiaries |  |  | Eliminations |  |  | Consolidated |  |
| Net cash provided by (used in) operating activities |  | $ | (53.0 | ) |  | $ | 32.4 |  |  | $ | (19.7 | ) |  | $ | — |  |  | $ | (40.3 | ) |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | — |  |  |  | (2.1 | ) |  |  | (8.6 | ) |  |  | — |  |  |  | (10.7 | ) |

[0000950123-11-039069:notes:181]
| Proceeds from sale of business |  |  | — |  |  |  | 0.1 |  |  |  | 3.1 |  |  |  | — |  |  |  | 3.2 |  |
| Acquisition of business |  |  | — |  |  |  | (6.7 | ) |  |  | — |  |  |  | — |  |  |  | (6.7 | ) |
| Restricted cash |  |  | — |  |  |  | — |  |  |  | (25.1 | ) |  |  | — |  |  |  | (25.1 | ) |
| Net cash used in investing activities |  |  | — |  |  |  | (8.7 | ) |  |  | (30.6 | ) |  |  | — |  |  |  | (39.3 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | — |  |  |  | — |  |  |  | 2.1 |  |  |  | — |  |  |  | 2.1 |  |
| Long-term payments |  |  | (35.0 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (35.1 | ) |
| Revolver long-term payments, net |  |  | 93.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 93.0 |  |
| Proceeds from stock option exercises |  |  | 1.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.0 |  |
| Repurchases of common stock |  |  | (39.4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (39.4 | ) |
| Excess tax benefits related to share-based payments |  |  | 2.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.1 |  |
| Intercompany debt |  |  | (0.8 | ) |  |  | 5.2 |  |  |  | (4.4 | ) |  |  | — |  |  |  | — |  |
| Intercompany financing activity |  |  | 38.5 |  |  |  | (27.5 | ) |  |  | (11.0 | ) |  |  | — |  |  |  | — |  |
| Intercompany investments |  |  | (7.9 | ) |  |  | — |  |  |  | 7.9 |  |  |  | — |  |  |  | — |  |
| Intercompany dividends |  |  | 9.0 |  |  |  | — |  |  |  | (9.0 | ) |  |  | — |  |  |  | — |  |
| Cash dividends paid |  |  | (7.9 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (7.9 | ) |
| Net cash (used in) provided by financing activities |  |  | 52.6 |  |  |  | (22.3 | ) |  |  | (14.5 | ) |  |  | — |  |  |  | 15.8 |  |
| INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  |  | (0.4 | ) |  |  | 1.4 |  |  |  | (64.8 | ) |  |  | — |  |  |  | (63.8 | ) |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS |  |  | — |  |  |  | — |  |  |  | 2.5 |  |  |  | — |  |  |  | 2.5 |  |
| CASH AND CASH EQUIVALENTS, beginning of year |  |  | 0.8 |  |  |  | 6.6 |  |  |  | 116.9 |  |  |  | — |  |  |  | 124.3 |  |
| CASH AND CASH EQUIVALENTS, end of year |  | $ | 0.4 |  |  | $ | 8.0 |  |  | $ | 54.6 |  |  | $ | — |  |  | $ | 63.0 |  |
