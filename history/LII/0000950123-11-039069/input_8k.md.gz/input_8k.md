# LII 8-K — 0000950123-11-039024 filed 2011-04-26

## item codes, every 8-K on or before 2011-04-26

- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2011-04-26

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000950123-11-039024:8k_2_02:1]
EX-99.1
2
d81616exv99w1.htm
EX-99.1

[0000950123-11-039024:8k_2_02:2]
exv99w1

[0000950123-11-039024:8k_2_02:3]
Exhibit 99.1

[0000950123-11-039024:8k_2_02:4]
Lennox International Reports First Quarter Results

[0000950123-11-039024:8k_2_02:5]
| • |  | Total revenue up 7%, with organic revenue up 2% |
| • |  | Adjusted loss per share of $0.11 and GAAP loss per share of $0.13 |
| • |  | Reiterating 2011 revenue growth guidance range of 11-14%, including 5-8% organic growth |
| • |  | Reiterating 2011 adjusted EPS guidance range of $2.80 to $3.10, up 17-29% |
| • |  | Repurchased $24 million of stock in the first quarter and targeting more than $100 million in 2011 |

[0000950123-11-039024:8k_2_02:6]
DALLAS, April 26 – Lennox International Inc. (NYSE: LII) today reported financial results for the
first quarter of 2011.

[0000950123-11-039024:8k_2_02:7]
Revenue for the first quarter was $688 million, up 7% from the prior-year quarter including a 2
point positive impact from foreign exchange. Excluding the Kysor/Warren acquisition completed in
January 2011, organic revenue was up 2% in the first quarter. At constant currency, organic revenue
was flat with the prior-year quarter. Diluted loss per share from continuing operations on an
adjusted basis was $0.11, compared to adjusted earnings per share from continuing operations of
$0.06 in the prior-year quarter. Diluted loss per share from continuing operations on a GAAP basis
was $0.13, compared to a $0.02 loss in the prior-year quarter.

[0000950123-11-039024:8k_2_02:8]
“Our Residential business was soft in the first quarter, impacted by the pull forward of demand
into the fourth quarter of last year ahead of announced price increases and the expiration of a
significant government tax credit,” said Todd Bluedorn, CEO of Lennox International. “As previously
mentioned, these effects helped drive 9% Residential revenue growth in the fourth quarter.
Residential revenue was down 4% in the first quarter against the tough comparison of 15% growth a
year ago. Despite volume being down in the first quarter this year, Residential realized a 5%
improvement in price and mix to fully offset commodity headwinds. For 2011, we still expect
Residential shipments for the industry to grow in the low single digit range. Our Commercial
business in the first quarter showed broad strength with 16% revenue growth and 150 basis points of
margin expansion. Refrigeration revenue was also up, with 3% organic growth at constant currency.
In both businesses, backlog looks strong. Beyond the seasonally light first quarter, we believe we
are well positioned across all our businesses moving into the strongest seasonal quarters of the
year. For 2011 overall, we reiterate our revenue growth guidance range of 11-14% and adjusted EPS
growth guidance range of 17-29%.”

[0000950123-11-039024:8k_2_02:9]
FINANCIAL HIGHLIGHTS

[0000950123-11-039024:8k_2_02:10]
Revenue: Revenue for the first quarter was $688 million, up 7% from the prior-year quarter
including a positive 2 point impact from foreign exchange. On an organic basis, revenue at constant
currency was flat with the first quarter a year ago. Volume was down, and price/mix was up from the
prior-year quarter.

[0000950123-11-039024:8k_2_02:11]
Gross Profit: Gross profit for the first quarter was $165 million, down 5% from $174 million in the
prior-year quarter. Gross margin was 24.0% compared to 27.1% in the prior-year quarter. Gross
margin was impacted primarily by higher commodity costs and higher freight costs, with offsets from
improved price/mix and productivity initiatives.

[0000950123-11-039024:8k_2_02:12]
(Loss) Income from Continuing Operations: Adjusted loss from continuing operations in the first
quarter was $5.8 million, or $0.11 diluted loss per share, compared to adjusted earnings from
continuing operations of $3.4 million, or $0.06 diluted earnings per share in the first quarter a
year ago. Adjusted loss from continuing operations for the first quarter of 2011 excludes an
after-tax charge of $0.8 million for restructuring activities, $0.5 million after-tax for the net
change in unrealized losses on open future contracts, and $0.1 million after-tax for acquisition
expenses.

[0000950123-11-039024:8k_2_02:13]
On a GAAP basis, loss from continuing operations for the first quarter was $7.2 million, or $0.13
diluted loss per share, compared to a $1.3 million loss from continuing operations, or $0.02
diluted loss per share in the prior-year quarter.

[0000950123-11-039024:8k_2_02:14]
Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $148 million
compared to net cash used by operations of $40 million in the prior-year quarter. The company
invested $8 million in capital assets in the first quarter. Free cash flow was ($156) million,
compared to ($51) million in the prior-year quarter. Total debt at the end of the first quarter was
$542 million after the $144 million acquisition of Kysor/Warren. The company increased its
quarterly dividend 20% in the first quarter to $0.18 per share and repurchased $24 million of stock
in the quarter. Total cash and cash equivalents were $55 million at the end of the quarter.

[0000950123-11-039024:8k_2_02:15]
BUSINESS SEGMENT HIGHLIGHTS

[0000950123-11-039024:8k_2_02:16]
Residential Heating & Cooling

[0000950123-11-039024:8k_2_02:17]
First quarter 2011 revenue from the Residential Heating & Cooling business segment was $272
million, down 4% from $284 million in the prior-year quarter. At constant currency, revenue was
down 5%. Segment loss was $1 million and segment loss margin was 0.4%, compared to segment profit
of $7 million and segment profit margin of 2.5% in the prior-year quarter. Results were primarily
impacted by lower volume, higher commodity costs, and higher freight expenses, with offsets from
favorable price/mix, productivity initiatives, and lower SG&A expenses.

[0000950123-11-039024:8k_2_02:18]
Commercial Heating & Cooling

[0000950123-11-039024:8k_2_02:19]
Revenue in the Commercial Heating & Cooling business segment was $139 million, up 16% from $120
million in the prior-year quarter. At constant currency, revenue was up 15%. Total segment profit
was $6 million, and segment profit margin was 4.3%, compared to segment profit of $3 million and
segment profit margin of 2.8% in the prior-year quarter. Results were primarily impacted by higher
volume and productivity initiatives, with offsets from higher commodity costs, freight expenses,
and selling expenses.

[0000950123-11-039024:8k_2_02:20]
Service Experts

[0000950123-11-039024:8k_2_02:21]
Revenue in the Service Experts business segment was $117 million in the first quarter, down 8% from
$127 million in the prior-year quarter. At constant currency, revenue was down 9%. Segment loss was
$8 million and segment loss margin was 7.0%, compared to segment loss of $5 million and segment
loss margin of 3.6% in the prior-year quarter. Results were primarily impacted by lower volume,
with an offset from lower SG&A expenses.

[0000950123-11-039024:8k_2_02:22]
Refrigeration

[0000950123-11-039024:8k_2_02:23]
Revenue in the Refrigeration business segment was $175 million in the first quarter, up 33% from
$131 million in the prior-year quarter. At constant currency, revenue was up 28%. Excluding the
Kysor/Warren acquisition, organic revenue was up 3% at constant currency. Segment profit was $14
million and segment profit margin was 7.7% in the first quarter, compared to segment profit of $15
million and segment profit margin of 11.3% in the year-ago quarter. Excluding the Kysor/Warren
acquisition, segment profit margin was down 70 basis points from the prior-year quarter. Results
were primarily impacted by higher volume and productivity initiatives, with offsets from higher
commodity costs, freight expenses, and selling expenses.

[0000950123-11-039024:8k_2_02:24]
FULL-YEAR OUTLOOK

[0000950123-11-039024:8k_2_02:25]
The company reiterates its revenue and EPS guidance ranges for 2011.

[0000950123-11-039024:8k_2_02:26]
|  | • |  | Reiterating revenue growth guidance range of 11-14% for the full year, including 1 point of positive impact from foreign exchange; organic revenue growth of 5-8%. |
|  | • |  | Reiterating adjusted EPS from continuing operations guidance range of $2.80-$3.10. |
|  | • |  | Reiterating GAAP EPS from continuing operations guidance range of $2.75-$3.05. |
|  | • |  | The company now assumes $45-50 million of commodity costs headwind in 2011, compared to $40-45 million previously, and still expects to fully offset this impact on a full-year basis with higher pricing. |
|  | • |  | Reiterating tax rate guidance of approximately 35% for 2011. |
|  | • |  | Reiterating capital expenditure guidance of approximately $65 million in 2011. |

[0000950123-11-039024:8k_2_02:27]
CONFERENCE CALL INFORMATION

[0000950123-11-039024:8k_2_02:28]
A conference call to discuss the company’s first quarter results will be held this morning at 8:30
a.m. Central time. To listen, please call the conference call line at 612-288-0340 at least 10
minutes prior to the scheduled start time and use reservation number 198627. This conference call
will also be webcast on Lennox International’s web site at http://www.lennoxinternational.com.

[0000950123-11-039024:8k_2_02:29]
A replay will be available from 11:00 a.m. Central time on April 26 through May 3, 2011, by dialing
800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 198627. This call will
also be archived on the company’s web site.

[0000950123-11-039024:8k_2_02:30]
Through its subsidiaries, Lennox International Inc. is a global leader in the heating, air
conditioning, and refrigeration markets. Lennox International stock is traded on the New York Stock
Exchange under the symbol “LII.” Additional information is available at:
http://www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor
Relations, at 972-497-6670.

[0000950123-11-039024:8k_2_02:31]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-039024:8k_2_02:32]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950123-11-039024:8k_2_02:33]
(Unaudited, in millions, except per share data)

[0000950123-11-039024:8k_2_02:34]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| NET SALES |  | $ | 687.8 |  |  | $ | 644.1 |  |
| COST OF GOODS SOLD |  |  | 522.6 |  |  |  | 469.8 |  |
| Gross profit |  |  | 165.2 |  |  |  | 174.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 173.9 |  |  |  | 168.9 |  |
| Gains and other expenses, net |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Restructuring charges |  |  | 1.2 |  |  |  | 7.2 |  |
| Income from equity method investments |  |  | (2.6 | ) |  |  | (2.0 | ) |
| Operational (loss) income from continuing operations |  |  | (7.0 | ) |  |  | 0.5 |  |
| INTEREST EXPENSE, net |  |  | 4.1 |  |  |  | 2.5 |  |
| Loss from continuing operations before income taxes |  |  | (11.1 | ) |  |  | (2.0 | ) |
| BENEFIT FROM INCOME TAXES |  |  | (3.9 | ) |  |  | (0.7 | ) |
| Loss from continuing operations |  |  | (7.2 | ) |  |  | (1.3 | ) |
| DISCONTINUED OPERATIONS: |  |  |  |  |  |  |  |  |
| Operational loss from discontinued operations |  |  | — |  |  |  | 0.4 |  |
| Income tax benefit |  |  | — |  |  |  | (0.1 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | 0.3 |  |
| Net loss |  | $ | (7.2 | ) |  | $ | (1.6 | ) |
| LOSS PER SHARE — BASIC AND DILUTED: |  |  |  |  |  |  |  |  |
| Loss from continuing operations |  | $ | (0.13 | ) |  | $ | (0.02 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (0.01 | ) |
| Net loss |  | $ | (0.13 | ) |  | $ | (0.03 | ) |
| AVERAGE SHARES OUTSTANDING — BASIC AND DILUTED |  |  | 53.6 |  |  |  | 56.0 |  |
| CASH DIVIDENDS DECLARED PER SHARE |  | $ | 0.18 |  |  | $ | 0.15 |  |

[0000950123-11-039024:8k_2_02:35]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-039024:8k_2_02:36]
SEGMENT NET SALES AND (LOSS) PROFIT

[0000950123-11-039024:8k_2_02:37]
(Unaudited, in millions)

[0000950123-11-039024:8k_2_02:38]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 272.0 |  |  | $ | 284.2 |  |
| Commercial Heating & Cooling |  |  | 138.8 |  |  |  | 119.7 |  |
| Service Experts |  |  | 116.5 |  |  |  | 127.1 |  |
| Refrigeration |  |  | 175.1 |  |  |  | 131.4 |  |
| Eliminations (A) |  |  | (14.6 | ) |  |  | (18.3 | ) |
|  |  | $ | 687.8 |  |  | $ | 644.1 |  |
| Segment (Loss) Profit (B) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | (1.2 | ) |  | $ | 7.1 |  |
| Commercial Heating & Cooling |  |  | 5.9 |  |  |  | 3.4 |  |
| Service Experts |  |  | (8.2 | ) |  |  | (4.6 | ) |
| Refrigeration |  |  | 13.5 |  |  |  | 14.9 |  |
| Corporate and other |  |  | (14.5 | ) |  |  | (13.2 | ) |
| Eliminations (A) |  |  | (0.4 | ) |  |  | 0.2 |  |
| Subtotal that includes segment (loss) profit and eliminations |  |  | (4.9 | ) |  |  | 7.8 |  |
| Reconciliation to loss from continuing operations before income taxes: |  |  |  |  |  |  |  |  |
| Items in gains and other expenses, net that are excluded from segment (loss) profit (C) |  |  | 0.9 |  |  |  | 0.1 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | 7.2 |  |
| Interest expense, net |  |  | 4.1 |  |  |  | 2.5 |  |
| Loss from continuing operations before income taxes |  | $ | (11.1 | ) |  | $ | (2.0 | ) |

[0000950123-11-039024:8k_2_02:39]
| (A) |  | Eliminations consist of intercompany sales between business segments, such as products sold to Service Experts by the Residential Heating & Cooling segment. |
| (B) |  | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations: |

[0000950123-11-039024:8k_2_02:40]
Excluding:

[0000950123-11-039024:8k_2_02:41]
|  | o |  | Special product quality adjustment. |
|  | o |  | Items within Gains and/or losses and other expenses, net that are noted in (C) . |
|  | o |  | Restructuring charges. |
|  | o |  | Goodwill and equity method investment impairments. |
|  | o |  | Interest expense, net. |
|  | o |  | Other expense, net. |

[0000950123-11-039024:8k_2_02:42]
| (C) |  | Items in Gains and/or losses and other expenses, net that are excluded from segment profit or loss are net change in unrealized gains and/or losses on open future contracts, discount fee on accounts sold, realized gains and/or losses on marketable securities, special legal contingency charge, and other items. |

[0000950123-11-039024:8k_2_02:43]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-039024:8k_2_02:44]
CONSOLIDATED BALANCE SHEETS

[0000950123-11-039024:8k_2_02:45]
(In millions, except share and per share data)

[0000950123-11-039024:8k_2_02:46]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
|  |  | (unaudited) |  |  |  |  |  |
| ASSETS |
| CURRENT ASSETS: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 55.2 |  |  | $ | 160.0 |  |
| Restricted cash |  |  | 10.5 |  |  |  | 12.2 |  |
| Accounts and notes receivable, net of allowances of $16.4 and $12.8 in 2011 and 2010, respectively |  |  | 404.6 |  |  |  | 384.8 |  |
| Inventories, net |  |  | 453.2 |  |  |  | 286.2 |  |
| Deferred income taxes |  |  | 41.2 |  |  |  | 36.7 |  |
| Other assets |  |  | 82.3 |  |  |  | 67.0 |  |
| Total current assets |  |  | 1,047.0 |  |  |  | 946.9 |  |
| PROPERTY, PLANT AND EQUIPMENT, net of accumulated depreciation of $596.3 and $584.7 in 2011 and 2010, respectively |  |  | 348.4 |  |  |  | 324.3 |  |
| GOODWILL |  |  | 321.3 |  |  |  | 271.8 |  |
| DEFERRED INCOME TAXES |  |  | 88.6 |  |  |  | 87.2 |  |
| OTHER ASSETS, net |  |  | 95.1 |  |  |  | 61.8 |  |
| TOTAL ASSETS |  | $ | 1,900.4 |  |  | $ | 1,692.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| CURRENT LIABILITIES: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 2.7 |  |  | $ | 1.4 |  |
| Asset securitization borrowings |  |  | 50.0 |  |  |  | — |  |
| Current maturities of long-term debt |  |  | 0.4 |  |  |  | 0.6 |  |
| Accounts payable |  |  | 340.8 |  |  |  | 273.8 |  |
| Accrued expenses |  |  | 281.8 |  |  |  | 334.5 |  |
| Income taxes payable |  |  | 0.9 |  |  |  | 5.3 |  |
| Total current liabilities |  |  | 676.6 |  |  |  | 615.6 |  |
| LONG-TERM DEBT |  |  | 488.5 |  |  |  | 317.0 |  |
| POSTRETIREMENT BENEFITS, OTHER THAN PENSIONS |  |  | 15.8 |  |  |  | 15.9 |  |
| PENSIONS |  |  | 88.7 |  |  |  | 88.1 |  |
| OTHER LIABILITIES |  |  | 64.4 |  |  |  | 65.7 |  |
| Total liabilities |  |  | 1,334.0 |  |  |  | 1,102.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |  |  |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 86,594,374 shares and 86,480,816 shares issued for 2011 and 2010, respectively |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 870.6 |  |  |  | 863.5 |  |
| Retained earnings |  |  | 625.4 |  |  |  | 642.2 |  |
| Accumulated other comprehensive income |  |  | 41.4 |  |  |  | 30.2 |  |
| Treasury stock, at cost, 33,274,352 shares and 32,784,503 shares for 2011 and 2010, respectively |  |  | (971.9 | ) |  |  | (947.1 | ) |
| Total stockholders’ equity |  |  | 566.4 |  |  |  | 589.7 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 1,900.4 |  |  | $ | 1,692.0 |  |

[0000950123-11-039024:8k_2_02:47]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0000950123-11-039024:8k_2_02:48]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0000950123-11-039024:8k_2_02:49]
(Unaudited, in millions, except per share, ratio, sales growth rate and margin data)

[0000950123-11-039024:8k_2_02:50]
Use of Non-GAAP Financial Measures

[0000950123-11-039024:8k_2_02:51]
To supplement the Company’s consolidated financial statements and segment net sales and profit
presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and
reconciled in the following tables. The Company believes that these non-GAAP financial measures,
when considered together with the GAAP financial measures, provide information that is useful to
investors in understanding period-over-period operating results. The Company believes that these
non-GAAP financial measures enhance the ability of investors to analyze the Company’s business
trends and operating performance.

[0000950123-11-039024:8k_2_02:52]
Reconciliation of Loss From Continuing Operations, a GAAP measure, to Adjusted (Loss) Income From
Continuing Operations,
a Non-GAAP measure

[0000950123-11-039024:8k_2_02:53]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Loss from continuing operations, a GAAP measure |  | $ | (7.2 | ) |  | $ | (1.3 | ) |
| Restructuring charges, after tax |  |  | 0.8 |  |  |  | 4.6 |  |
| Net change in unrealized losses on open future contracts, after tax (a) |  |  | 0.5 |  |  |  | — |  |
| Acquisition expenses, after-tax (a) |  |  | 0.1 |  |  |  | — |  |
| Other items, net, after tax (a) |  |  | — |  |  |  | 0.1 |  |
| Adjusted (loss) income from continuing operations, a non-GAAP measure |  | $ | (5.8 | ) |  | $ | 3.4 |  |
| Loss per share from continuing operations — basic and diluted, a GAAP measure |  | $ | (0.13 | ) |  | $ | (0.02 | ) |
| Restructuring charges |  |  | 0.01 |  |  |  | 0.08 |  |
| Net change in unrealized losses on open future contracts (a) |  |  | 0.01 |  |  |  | — |  |
| Adjusted (loss) earnings per share from continuing operations — basic and diluted, a non-GAAP measure |  | $ | (0.11 | ) |  | $ | 0.06 |  |

[0000950123-11-039024:8k_2_02:54]
| (a) |  | Recorded in Gains and other expenses, net in the Consolidated Statements of Operations |

[0000950123-11-039024:8k_2_02:55]
|  |  | For The Three Months |  |
|  |  | Ended March 31, |  |
| Components of Gains and other expenses, net (pre-tax): |  | 2011 |  |  | 2010 |  |
| Realized gains on settled future contracts (a) |  | $ | (0.6 | ) |  | $ | (0.4 | ) |
| Foreign currency exchange loss (gain) (a) |  |  | 0.1 |  |  |  | (0.1 | ) |
| (Gain) loss on disposal of fixed assets (a) |  |  | (0.7 | ) |  |  | 0.1 |  |
| Net change in unrealized losses on open futures contracts (b) |  |  | 0.7 |  |  |  | — |  |
| Acquisition expenses (b) |  |  | 0.2 |  |  |  | — |  |
| Gain on sale of entity (b) |  |  | — |  |  |  | (0.1 | ) |
| Other items, net (b) |  |  | — |  |  |  | 0.2 |  |
| Gains and other expenses, net (pre-tax) |  | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0000950123-11-039024:8k_2_02:56]
| (a) |  | Included in segment (loss) profit and adjusted (loss) income from continuing operations |
| (b) |  | Excluded from segment (loss) profit and adjusted (loss) income from continuing operations |

[0000950123-11-039024:8k_2_02:57]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations — Diluted, a
Non-GAAP Measure, to
Income per Share from Continuing Operations — Diluted, a GAAP Measure

[0000950123-11-039024:8k_2_02:58]
|  |  | For the |  |
|  |  | Year Ended |  |
|  |  | December 31, |  |
|  |  | 2011 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations — diluted, a Non-GAAP measure |  | $ | 2.80 - $3.10 |  |
| Restructuring charges |  |  | (0.05 | ) |
| Income per share from continuing operations — diluted, a GAAP measure |  | $ | 2.75 - $3.05 |  |

[0000950123-11-039024:8k_2_02:59]
Reconciliation of Net Cash Used in Operating Activities, a GAAP Measure, to Free Cash Flow, a
Non-GAAP Measure

[0000950123-11-039024:8k_2_02:60]
|  |  | For the Three Months |  |
|  |  | Ended March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Net cash used in operating activities, a GAAP measure |  | $ | (148.3 | ) |  | $ | (40.3 | ) |
| Purchase of property, plant and equipment |  |  | (8.2 | ) |  |  | (10.7 | ) |
| Free cash flow, a Non-GAAP measure |  | $ | (156.5 | ) |  | $ | (51.0 | ) |

[0000950123-11-039024:8k_2_02:61]
Calculation of Debt to EBITDA Ratio:

[0000950123-11-039024:8k_2_02:62]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2011 |  |
| EBIT (a) |  | $ | 204.3 |  |
| Depreciation and amortization expense (b) |  |  | 55.4 |  |
| EBITDA (a + b) |  | $ | 259.7 |  |
| Total debt at March 31, 2011 (c) |  | $ | 541.6 |  |
| Total debt to EBITDA ratio ((c / (a + b)) |  |  | 2.1 |  |

[0000950123-11-039024:8k_2_02:63]
Reconciliation of EBIT, a Non-GAAP Measure, to Income From Continuing Operations Before Income
Taxes, a GAAP measure

[0000950123-11-039024:8k_2_02:64]
|  |  | Trailing |  |
|  |  | Twelve |  |
|  |  | Months to |  |
|  |  | March 31, |  |
|  |  | 2011 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 204.3 |  |
| Special product quality adjustment |  |  | (0.2 | ) |
| Items in gains and other expenses, net that are excluded from segment profit |  |  | 12.0 |  |
| Restructuring charges |  |  | 9.6 |  |
| Other expenses, net |  |  | 1.0 |  |
| Interest expense, net |  |  | 14.4 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 167.5 |  |

[0000950123-11-039024:8k_2_02:65]
Reconciliation of Reported Revenue Growth, a GAAP measure, to Organic Revenue Growth, a non-GAAP
measure

[0000950123-11-039024:8k_2_02:66]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Translational |  |  | Net Sales |  |
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |  | Currency |  |  | Growth % |  |
|  |  | For The Three Months |  |  | Net |  |  | Net |  |  | Impact |  |  | Excluding |  |
|  |  | Ended March 31, |  |  | Sales |  |  | Sales |  |  | Favorable |  |  | Currency |  |
|  |  | 2011 |  |  | 2010 |  |  | Variance |  |  | Growth % |  |  | (Unfavorable) |  |  | Impact |  |
| Lennox International Inc. and Subsidiaries |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 687.8 |  |  | $ | 644.1 |  |  | $ | 43.7 |  |  |  | 6.8 | % |  | $ | 10.0 |  |  |  | 5.2 | % |
| Less: Kysor/Warren acquisition |  |  | (34.0 | ) |  |  | — |  |  |  | (34.0 | ) |  |  |  |  |  |  | (0.4 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 653.8 |  |  | $ | 644.1 |  |  | $ | 9.7 |  |  |  | 1.5 | % |  | $ | 9.6 |  |  |  | 0.0 | % |
| Refrigeration Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Sales, as reported — a GAAP measure |  | $ | 175.1 |  |  | $ | 131.4 |  |  | $ | 43.7 |  |  |  | 33.3 | % |  | $ | 6.3 |  |  |  | 28.5 | % |
| Less: Kysor/Warren acquisition |  |  | (34.0 | ) |  |  | — |  |  |  | (34.0 | ) |  |  |  |  |  |  | (0.4 | ) |  |  |  |  |
| Net Sales, organic — a non-GAAP measure |  | $ | 141.1 |  |  | $ | 131.4 |  |  | $ | 9.7 |  |  |  | 7.4 | % |  | $ | 5.9 |  |  |  | 2.9 | % |

[0000950123-11-039024:8k_2_02:67]
Reconciliation of Reported Refrigeration Segment Profit Margin to Organic Segment Profit Margin

[0000950123-11-039024:8k_2_02:68]
|  |  | For the Three Months Ended March 31, 2011 |  |  | For the Three Months Ended March 31, 2010 |  |
|  |  |  |  |  |  |  |  |  |  | Segment |  |  |  |  |  |  |  |  |  |  | Segment |  |
|  |  | Net |  |  | Segment |  |  | Profit |  |  | Net |  |  | Segment |  |  | Profit |  |
|  |  | Sales |  |  | Profit |  |  | Margin |  |  | Sales |  |  | Profit |  |  | Margin |  |
| Refrigeration Segment, as reported |  | $ | 175.1 |  |  | $ | 13.5 |  |  |  | 7.7 | % |  | $ | 131.4 |  |  | $ | 14.9 |  |  |  | 11.3 | % |
| Less: Kysor/Warren acquisition |  |  | (34.0 | ) |  |  | 1.5 |  |  |  | 4.4 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Refrigeration Segment, organic |  | $ | 141.1 |  |  | $ | 15.0 |  |  |  | 10.6 | % |  | $ | 131.4 |  |  | $ | 14.9 |  |  |  | 11.3 | % |

[0000950123-11-039024:8k_2_02:69]
Reconciliation of Operational Working Capital, a Non-GAAP Measure, to GAAP Balance Sheet Line Items

[0000950123-11-039024:8k_2_02:70]
|  |  |  |  |  |  | March 31, |  |  |  |  |  |  | March 31, |  |
|  |  |  |  |  |  | 2011 |  |  |  |  |  |  | 2010 |  |
|  |  | March 31, |  |  | Trailing |  |  | March 31, |  |  | Trailing |  |
|  |  | 2011 (c) |  |  | 12 Mo. Avg. (c) |  |  | 2010 |  |  | 12 Mo. Avg. |  |
| Accounts and Notes Receivable, Net |  | $ | 370.9 |  |  |  |  |  |  | $ | 349.5 |  |  |  |  |  |
| Allowance for Doubtful Accounts |  |  | 13.7 |  |  |  |  |  |  |  | 15.7 |  |  |  |  |  |
| Accounts and Notes Receivable, Gross |  |  | 384.6 |  |  | $ | 412.4 |  |  |  | 365.2 |  |  | $ | 404.6 |  |
| Inventories |  |  | 418.9 |  |  |  |  |  |  |  | 326.4 |  |  |  |  |  |
| Excess of Current Cost Over Last-in, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| First-out |  |  | 70.9 |  |  |  |  |  |  |  | 71.7 |  |  |  |  |  |
| Inventories as Adjusted |  |  | 489.8 |  |  |  | 419.4 |  |  |  | 398.1 |  |  |  | 358.1 |  |
| Accounts Payable |  |  | (321.8 | ) |  |  | (288.5 | ) |  |  | (286.1 | ) |  |  | (259.5 | ) |
| Operating Working Capital (a) |  |  | 552.6 |  |  |  | 543.3 |  |  |  | 477.2 |  |  |  | 503.2 |  |
| Net Sales, Trailing Twelve Months (b) |  |  | 3,106.1 |  |  |  | 3,106.1 |  |  |  | 2,911.0 |  |  |  | 2,911.0 |  |
| Operational Working Capital Ratio (a / b) |  |  | 17.8 | % |  |  | 17.5 | % |  |  | 16.4 | % |  |  | 17.3 | % |

[0000950123-11-039024:8k_2_02:71]
| (c) |  | Excludes the impact of the Kysor/Warren acquisition completed in January 2011. Including the impact of the Kysor/Warren acquisition to the March 31, 2011 operational working capital items above would increase Accounts and Notes Receivable, Gross from $384.6 to $421.0, Inventories as Adjusted from $489.8 to $524.1 and Accounts Payable from $(321.8) to $(340.8). Net Sales, Trailing Twelve Months would increase $34.0 (representing approximately two and a half months of Net Sales) to $3,140.1 resulting in an Operational Working Capital Ratio of 19.2%. |
