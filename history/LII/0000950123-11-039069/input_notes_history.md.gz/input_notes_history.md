# LII note change history — 0000950123-10-096054 → 0000950123-11-039069


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-04-26):
[0000950123-11-039069:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to provide protection against claims relating to contingencies such as workers’
   compensation, general liability, product liability, property damage, aviation liability, directors’
   and officers’ liability, auto liability, physical damage and other exposures. Self-insurance
   expense and liabilities are actuarially determined based on our historical claims information, as
   well as industry factors and trends and because we have a captive insurance company, we are
   required to maintain specified levels of liquid assets from which we must pay claims. The majority
   of our self-insured risks (excluding auto liability and physical damage) will be paid over an
   extended period of time. There have been no material changes since our latest fiscal year-end. We
   also maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued expenses in the
   accompanying Consolidated Balance Sheets were $64.8 million and $61.3 million as of March 31, 2011
   and December 31, 2010, respectively.
  (was, 2010-10-26, similarity 0.994):
[0000950123-10-096054:note_history:1]
We use a combination of third-party insurance and self-insurance plans (large deductible or
   captive) to
   provide protection against claims relating to contingencies such as workers’ compensation,
   general liability, product liability, property damage, aviation liability, directors’ and officers’
   liability, auto liability, physical damage and other exposures. Self-insurance expense and
   liabilities are actuarially determined based on our
   historical claims information, as well as
   industry factors and trends and because we have a captive insurance company, we are required to
   maintain specified levels of liquid assets from which we must pay claims. The majority of our
   self-insured risks (excluding auto liability and physical damage) will be paid over an extended
   period of time. There have been no material changes since our latest fiscal year-end. We also
   maintain third-party insurance coverage for risks not retained within our large deductible or
   captive insurance plans. The self-insurance liabilities recorded in Accrued Expenses in the
   accompanying Consolidated Balance Sheets were $63.3 million and $60.4 million as of September 30,
   2010 and December 31, 2009, respectively.

- changed (2011-04-26):
[0000950123-11-039069:note_history:2]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Accrued expenses |  | $ | 32.8 |  |  | $ | 31.2 |  |
| Other liabilities |  |  | 43.5 |  |  |  | 44.3 |  |
|  |  | $ | 76.3 |  |  | $ | 75.5 |  |
  (was, 2010-10-26, similarity 0.9698):
[0000950123-10-096054:note_history:2]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued Expenses |  | $ | 31.5 |  |  | $ | 31.5 |  |
| Other Liabilities |  |  | 44.6 |  |  |  | 50.0 |  |
|  |  | $ | 76.1 |  |  | $ | 81.5 |  |

- changed (2011-04-26):
[0000950123-11-039069:note_history:3]
The changes in the total warranty liabilities for the first quarter of 2011 were as
   follows (in millions):
  (was, 2010-10-26, similarity 0.9238):
[0000950123-10-096054:note_history:3]
The changes in the total warranty liabilities for the first nine months of 2010 were as
   follows (in millions):

- changed (2011-04-26):
[0000950123-11-039069:note_history:4]
| Total warranty liability as of December 31, 2010 |  | $ | 75.5 |  |
| Payments made in 2011 |  |  | (6.5 | ) |
| Changes resulting from issuance of new warranties |  |  | 5.6 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | 0.2 |  |
| Changes in foreign currency translation rates and other |  |  | 1.5 |  |
| Total warranty liability as of March 31, 2011 |  | $ | 76.3 |  |
  (was, 2010-10-26, similarity 0.7827):
[0000950123-10-096054:note_history:4]
| Total warranty liability as of December 31, 2009 |  | $ | 81.5 |  |
| Payments made in 2010 |  |  | (21.2 | ) |
| Changes resulting from issuance of new warranties |  |  | 20.9 |  |
| Changes in estimates associated with pre-existing liabilities |  |  | (5.3 | ) |
| Changes in foreign currency exchange rates |  |  | 0.2 |  |
| Total warranty liability as of September 30, 2010 |  | $ | 76.1 |  |

- changed (2011-04-26):
[0000950123-11-039069:note_history:5]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our heating, ventilation and air
   conditioning (“HVAC”) warranty liabilities.
  (was, 2010-10-26, similarity 0.6813):
[0000950123-10-096054:note_history:5]
At the end of each accounting period, we evaluate our warranty liabilities and during the
   second quarter of each year, we perform a complete reevaluation of our heating, ventilation and air
   conditioning (“HVAC”) warranty liabilities. As a result of our annual evaluation, we have recorded
   a reduction of $6.3 million in warranty liabilities that is the principal amount contained within
   the changes in estimates associated with pre-existing liabilities.

- changed (2011-04-26):
[0000950123-11-039069:note_history:6]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims also may not be covered by our product
   liability insurance. There have been no material changes in the circumstances since our latest
   fiscal year-end.
  (was, 2010-10-26, similarity 0.9883):
[0000950123-10-096054:note_history:6]
We incur the risk of liability claims for the installation and service of heating and air
   conditioning products, and we maintain liabilities for those claims that we self-insure. We are
   involved in various claims and lawsuits related to our products. Our product liability insurance
   policies have limits that, if exceeded, may result in substantial costs that could have an adverse
   effect on our results of operations. In addition, warranty claims are not covered by our product
   liability insurance and certain product liability claims may also not be covered by our product
   liability insurance. There have been no material changes in the circumstances since our latest
   fiscal year-end.

- changed (2011-04-26):
[0000950123-11-039069:note_history:7]
We may also incur costs related to our products that may not be covered under our warranties
   and are not covered by insurance, and we may, from time to time, repair or replace installed
   products experiencing quality issues in order to satisfy our customers and to protect our brand.
   These product quality issues may be caused by vendor-supplied components that fail to meet required
   specifications.
  (was, 2010-10-26, similarity 0.9799):
[0000950123-10-096054:note_history:7]
We also may incur costs related to our products that may not be covered under our warranties
   and are not covered by insurance, and we may, from time to time, repair or replace installed
   products experiencing quality issues in order to satisfy our customers and to protect our brand.
   These product quality issues may be caused by vendor-supplied components that fail to meet required
   specifications.

- added (2011-04-26):
[0000950123-11-039069:note_history:8]
In addition to normal product warranty, we have identified a product quality issue in a
   heating and cooling product line produced in 2006 and 2007 that we believe results from a
   vendor-supplied materials quality issue. The expense for this product quality issue, and the
   related liability, is not included in the tables related to our estimated warranty liabilities.
   The expense related to this product quality issue was classified in Cost of Goods Sold in the
   Consolidated Statements of Operations and the related liability is included in Accrued Expenses in
   the accompanying Consolidated Balance Sheets. We may incur additional charges in the future as more
   information becomes available. The changes in the accrued product quality issue for the first
   quarter of 2011 were as follows (in millions):

- added (2011-04-26):
[0000950123-11-039069:note_history:9]
| Total accrued product quality issue as of December 31, 2010 |  | $ | 16.0 |  |
| Product quality claims |  |  | (2.0 | ) |
| Total accrued product quality issue as of March 31, 2011 |  | $ | 14.0 |  |

- changed (2011-04-26):
[0000950123-11-039069:note_history:10]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period. We are the
   defendant in a class action lawsuit related to certain hearth products we produced and sold that
   claims such products are hazardous and that consumers were not adequately warned. On August, 23,
   2010, the Company and plaintiffs entered into a binding Memorandum of Understanding (“MOU”) and
   reached tentative terms for settlement of the case. At the parties’ request, the court stayed the
   lawsuit shortly after the MOU was signed. On January 11, 2011, the court granted preliminary
   approval of the settlement. The court set June 2, 2011 as the date for the final approval hearing.
   We had $9.3 million in expenses to date related to this matter with no additional charges during
   the first quarter of 2011.
  (was, 2010-10-26, similarity 0.6713):
[0000950123-10-096054:note_history:10]
We estimate the costs to settle pending litigation based on experience involving similar
   claims and specific facts known. We do not believe that any current or pending or threatened
   litigation will have a material adverse effect on our financial position. Litigation and
   arbitration, however, involve uncertainties and it is possible that the eventual outcome of
   litigation could adversely affect our results of operations for a particular period. We are the
   defendant in a class action lawsuit related to certain hearth products we produced and sold that
   claims such products are hazardous and that consumers were not adequately warned. On August 23,
   2010, the Company and the plaintiffs entered into a binding Memorandum of Understanding (“MOU”) and
   have reached tentative terms for settlement of the case. At the parties’ request, the court has
   stayed the litigation. If the terms of the MOU are fulfilled, as is expected, the parties will
   file a motion for preliminary approval of the settlement with the court by December 1, 2010. Total
   charges related to this matter recorded in the first nine months of 2010 were $8.2 million. We
   recorded charges totaling $2.6 million related to this matter during the third quarter of 2010 and
   we may incur additional charges in the future. These charges are included in Selling, General and
   Administrative Expenses and Losses (Gains) and Other Expenses, Net in the accompanying Consolidated
   Statement of Operations.

- changed (2011-04-26):
[0000950123-11-039069:note_history:11]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We were in compliance with these financial covenants as of March 31, 2011.
  (was, 2010-10-26, similarity 0.8389):
[0000950123-10-096054:note_history:11]
Our obligations under the Lake Park Lease are secured by a pledge of our interest in the
   leased property and are also guaranteed by us and certain of our subsidiaries. The Lake Park Lease,
   as amended, contains restrictive covenants that are consistent with those of our domestic revolving
   credit facility. We are in compliance with these financial covenants as of September 30, 2010.

- removed (2011-04-26):
[0000950123-10-096054:note_history:12]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Accrued product quality issue (not covered under warranty) |  | $ | 17.5 |  |  | $ | 21.6 |  |

- removed (2011-04-26):
[0000950123-10-096054:note_history:13]
We have identified a product quality issue in a heating and cooling product line produced in
   2006 and 2007 that we believe results from a vendor-supplied materials quality issue. We have
   recorded an expense of $24.6 million in 2009 for the portion of the issue that is probable and can
   be reasonably estimated. There were no additional charges recorded in 2010. We may incur
   additional charges in the future as more information becomes available. The expense for this
   product quality issue, and the related liability, is not included in the tables related to our
   estimated warranty liabilities. The expense related to this product quality issue was classified
   in Cost of Goods Sold in the Consolidated Statements of Operations and the related liability is
   included in Accrued Expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-04-26):
[0000950123-11-039069:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2011, the accompanying
   unaudited Consolidated Statements of Operations for the three months ended March 31, 2011 and 2010,
   and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended
   March 31, 2011 and 2010 should be read in conjunction with our audited consolidated financial
   statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31,
   2010. The accompanying unaudited consolidated financial statements have been prepared in
   accordance with generally accepted accounting principles (“GAAP”) for interim financial information
   and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying
   consolidated financial statements contain all material adjustments, consisting principally of
   normal recurring adjustments, necessary for a fair presentation of our financial position, results
   of operations and cash flows. Certain information and footnote disclosures normally included in
   financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to
   applicable rules and regulations, although we believe that the disclosures herein are adequate to
   make the information presented not misleading. The operating results for the interim periods are
   not necessarily indicative of the results that may be expected for a full year.
  (was, 2010-10-26, similarity 0.9045):
[0000950123-10-096054:note_history:14]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2010, the
   accompanying unaudited Consolidated Statements of Operations for the three and nine months ended
   September 30, 2010 and 2009, the accompanying unaudited Consolidated Statement of Stockholders’
   Equity for the nine months ended September 30, 2010 and the accompanying unaudited Consolidated
   Statements of Cash Flows for the nine months ended September 30, 2010 and 2009 should be read in
   conjunction with our audited consolidated financial statements and footnotes included in our Annual
   Report on Form 10-K for the year ended December 31, 2009. The accompanying unaudited consolidated
   financial statements have been prepared in accordance with generally accepted accounting principles
   (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of
   Regulation S-X. The accompanying consolidated financial statements contain all material
   adjustments, consisting principally of normal recurring adjustments, necessary for a fair
   presentation of our financial position, results of operations and cash flows. Certain information
   and footnote disclosures normally included in financial statements prepared in accordance with
   generally accepted accounting principles have been condensed or omitted pursuant to applicable
   rules and regulations, although we believe that the disclosures herein are adequate to make the
   information presented not misleading. The operating results for the interim periods are not
   necessarily indicative of the results that may be expected for the full year.

- changed (2011-04-26):
[0000950123-11-039069:note_history:15]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on
   management’s best estimates and judgment.
  (was, 2010-10-26, similarity 0.9892):
[0000950123-10-096054:note_history:15]
The preparation of financial statements requires us to make estimates and assumptions about
   future events. These estimates and the underlying assumptions affect the amounts of assets and
   liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of
   revenues and expenses. Such estimates include the valuation of accounts receivable, inventories,
   goodwill, intangible assets, and other long-lived assets, contingencies, guarantee obligations,
   indemnifications, and assumptions used in the calculation of income taxes, pension and
   postretirement medical benefits, among others. These estimates and assumptions are based on our
   best estimates and judgment.

- changed (2011-04-26):
[0000950123-11-039069:note_history:16]
We evaluate these estimates and assumptions on an ongoing basis using historical experience
   and other factors, including the current economic environment. We believe these estimates and
   assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when
   facts and circumstances dictate.
  (was, 2010-10-26, similarity 0.9874):
[0000950123-10-096054:note_history:16]
We evaluate our estimates and assumptions on an ongoing basis using historical experience and
   other factors, including the current economic environment. We believe these estimates and
   assumptions to be reasonable under the circumstances and adjust such estimates and assumptions when
   facts and circumstances dictate.

- removed (2011-04-26):
[0000950123-10-096054:note_history:17]
Reclassifications

- removed (2011-04-26):
[0000950123-10-096054:note_history:18]
Certain prior year amounts have been reclassified to conform to the current year presentation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2011-04-26):
[0000950123-11-039069:note_history:19]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Short-Term Debt: |  |  |  |  |  |  |  |  |
| Foreign obligations |  | $ | 2.7 |  |  | $ | 1.4 |  |
| Asset securitization |  |  | 50.0 |  |  |  | — |  |
| Total short-term debt |  | $ | 52.7 |  |  | $ | 1.4 |  |
| Current maturities of long-term debt: |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Long-Term Debt: |  |  |  |  |  |  |  |  |
| Capital lease obligations |  |  | 17.0 |  |  |  | 17.0 |  |
| Domestic revolving credit facility |  |  | 271.5 |  |  |  | 100.0 |  |
| Senior unsecured notes |  |  | 200.0 |  |  |  | 200.0 |  |
| Total long-term debt |  | $ | 488.5 |  |  | $ | 317.0 |  |
| Total debt |  | $ | 541.6 |  |  | $ | 319.0 |  |

- added (2011-04-26):
[0000950123-11-039069:note_history:20]
Short-Term Debt

- added (2011-04-26):
[0000950123-11-039069:note_history:21]
Foreign Obligations

- added (2011-04-26):
[0000950123-11-039069:note_history:22]
Through several of our foreign subsidiaries, we have $10.9 million in committed combined
   foreign facilities to assist in financing seasonal borrowing needs for our foreign locations. We
   had $10.9 million and $10.1 million of available capacity as of March 31, 2011 and December 31,
   2010, respectively. Our foreign obligations of $2.7 million represented borrowings under
   non-committed facilities.

- added (2011-04-26):
[0000950123-11-039069:note_history:23]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash. The arrangement is subject to renewal and contains a provision whereby we
   retained the right to repurchase all of the outstanding beneficial interests transferred. Our
   continued involvement with the transferred assets includes servicing, collection and administration
   of the transferred beneficial interests. The sale of the beneficial interests in our trade
   accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance
   Sheets and proceeds received are included in cash flows from financing activities in the
   accompanying Consolidated Statements of Cash Flows. The ASA provides for a maximum securitization
   amount of $100.0 million or 100% of the net pool balance as defined by the ASA. However,
   eligibility for securitization is limited based on the amount and quality of the qualifying
   accounts receivable and is calculated monthly. The beneficial interest sold cannot exceed the
   maximum amount even if our qualifying accounts receivable is greater than the maximum amount at any
   point in time. In the first quarter of 2011, we sold a beneficial interest in $50.0 million of our
   trade accounts receivable under the ASA. Because the ASA matures in November 2011, we classified
   the related debt as short-term on the Consolidated Balance Sheet. The eligible amounts available
   and beneficial interests sold were as follows (in millions):

- added (2011-04-26):
[0000950123-11-039069:note_history:24]
|  |  | As of |  |  | As of |  |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 94.0 |  |  | $ | 100.0 |  |
| Beneficial interest sold |  |  | 50.0 |  |  |  | — |  |
| Remaining amount available |  | $ | 44.0 |  |  | $ | 100.0 |  |

- changed (2011-04-26):
[0000950123-11-039069:note_history:25]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 0.75%. The rate
   as of March 31, 2011 and December 31, 2010 was 1.06% for both periods. The unused fee is based on
   102% of the maximum available amount less the beneficial interest sold and calculated at a 0.375%
   fixed rate throughout the term of the agreement. We recorded these fees in Selling, General and
   Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):
  (was, 2010-10-26, similarity 0.9327):
[0000950123-10-096054:note_history:25]
Under the ASA, we pay certain discount fees to use the program and have the facility available
   to us. These fees relate to both the used and unused portions of the securitization. The used fee
   is based on the beneficial interest sold and calculated on the average floating commercial paper
   rate determined by the purchaser of the beneficial interest, plus a program fee of 1.15%. The rate
   was 1.45% and 1.38% as of September 30, 2010 and December 31, 2009, respectively. The unused fee is
   based on 102% of the maximum available amount less the beneficial interest sold and calculated at
   0.5% fixed rate throughout the term of the agreement. We recorded these fees in Selling, General
   and Administrative Expenses in the accompanying Consolidated Statements of Operations. The amounts
   recorded were as follows (in millions):

- changed (2011-04-26):
[0000950123-11-039069:note_history:26]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |
  (was, 2010-10-26, similarity 0.729):
[0000950123-10-096054:note_history:26]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |
| Discount fees |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |

- added (2011-04-26):
[0000950123-11-039069:note_history:27]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our domestic revolving credit facility and
   senior unsecured notes. The administrative agent under the ASA is also a participant in our
   domestic revolving credit facility. The participating financial institution has an investment grade
   credit rating. We continue to evaluate its credit rating and have no reason to believe it will not
   perform under the ASA. As of March 31, 2011, we were in compliance with all covenant requirements.

- added (2011-04-26):
[0000950123-11-039069:note_history:28]
Long-Term Debt

- added (2011-04-26):
[0000950123-11-039069:note_history:29]
Domestic Revolving Credit Facility

- added (2011-04-26):
[0000950123-11-039069:note_history:30]
Under the $650 million domestic revolving credit facility, we had outstanding borrowings of
   $271.5 million and $69.5 million committed to standby letters of credit as of March 31, 2011.
   Subject to covenant limitations, $309.0 million was available for future borrowings. Included in
   this facility is a subfacility for swingline loans of up to $50 million and provides for the
   issuance of letters of credit for the full amount of the credit facility. The subfacility is fully
   drawn and is included in our outstanding borrowings. This domestic revolving credit facility
   matures in October 2012.

- added (2011-04-26):
[0000950123-11-039069:note_history:31]
Our weighted average borrowing rate on the facility was as follows:

- added (2011-04-26):
[0000950123-11-039069:note_history:32]
|  |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Weighted average borrowing rate |  |  | 1.05 | % |  |  | 0.96 | % |

- changed (2011-04-26):
[0000950123-11-039069:note_history:33]
Our domestic revolving credit facility contains financial covenants relating to leverage
   and interest coverage. Other covenants contained in the domestic revolving credit facility
   restrict, among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a
   Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The
   required ratios under our domestic revolving credit facility as of March 31, 2011 are detailed
   below:
  (was, 2010-10-26, similarity 0.97):
[0000950123-10-096054:note_history:33]
Our domestic revolving credit facility contains financial covenants relating to leverage and
   interest coverage. Other covenants contained in the domestic revolving credit facility restrict,
   among other things, mergers, asset dispositions, guarantees, debt, liens, acquisitions,
   investments, affiliate transactions and our ability to make restricted payments. The financial
   covenants require us to maintain defined levels of Consolidated Indebtedness to Adjusted EBITDA
   Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.
   The required ratios under our domestic revolving credit facility as of September 30, 2010 are
   detailed below:

- changed (2011-04-26):
[0000950123-11-039069:note_history:34]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will
   automatically terminate). As of March 31, 2011, we were in compliance with all covenant
   requirements.
  (was, 2010-10-26, similarity 0.9294):
[0000950123-10-096054:note_history:34]
If any event of default occurs and is continuing, lenders with a majority of the aggregate
   commitments may require the administrative agent to terminate our right to borrow under our
   domestic revolving credit facility and accelerate amounts due under our domestic revolving credit
   facility (except for a bankruptcy event of default, in which case such amounts will automatically
   become due and payable and the lenders’ commitments will automatically terminate).

- added (2011-04-26):
[0000950123-11-039069:note_history:35]
Senior Unsecured Notes

- added (2011-04-26):
[0000950123-11-039069:note_history:36]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid
   semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.

- changed (2011-04-26):
[0000950123-11-039069:note_history:37]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic
   subsidiaries that guarantee payment by us of any indebtedness under our domestic revolving credit
   facility. The indenture governing the notes contains covenants that, among other things, limit our
   ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into
   certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers
   of substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date. As of March 31, 2011, we were in compliance with all covenant requirements and these
   covenants have not changed from December 31, 2010.
  (was, 2010-10-26, similarity 0.9262):
[0000950123-10-096054:note_history:37]
The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries
   that guarantee payment by us of any indebtedness under our domestic revolving credit facility. The
   indenture governing the notes contains covenants that, among other things, limit our ability and
   the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale
   and leaseback transactions; enter into certain mergers, consolidations and transfers of
   substantially all of our assets; and transfer certain properties. The indenture also contains a
   cross default provision which is triggered if we default on other debt of at least $75 million in
   principal which is then accelerated, and such acceleration is not rescinded within 30 days of the
   notice date.

- added (2011-04-26):
[0000950123-11-039069:note_history:38]
Credit Rating

- added (2011-04-26):
[0000950123-11-039069:note_history:39]
At March 31, 2011, our senior credit ratings were Baa3, with a stable outlook, and BBB-, with
   a stable outlook by Moody’s and Standard & Poor’s Rating Group (“S&P”), respectively.

- added (2011-04-26):
[0000950123-11-039069:note_history:40]
Other Financing Arrangements

- changed (2011-04-26):
[0000950123-11-039069:note_history:41]
In the first quarter 2010, our captive insurance subsidiary entered into an agreement in which
   cash was placed into a trust for the benefit of a third-party insurance provider. The purpose of
   the trust is to pay workers compensation claims for policy years 2003 — 2009 until the liabilities
   are fully extinguished. These policies were written by the third-party insurance provider, and
   then reinsured by our captive insurance subsidiary. As of March 31, 2011 and December 31, 2010, we
   had $10.5 million and $12.2 million in Restricted Cash on the accompanying Consolidated Balance
   Sheets to pay these claims.
  (was, 2010-10-26, similarity 0.7638):
[0000950123-10-096054:note_history:41]
During the first quarter of 2010, our captive insurance subsidiary entered into an agreement
   in which cash was placed into a trust for the benefit of a third-party insurance provider. The
   purpose of the trust is to pay Workers Compensation claims for policy years 2003 – 2009 until the
   liabilities are fully extinguished. These policies were written by the third-party insurance
   provider, and then reinsured by our captive insurance subsidiary. This transaction was classified
   as restricted cash on the accompanying Consolidated Balance Sheets. The balance at September 30,
   2010 was $13.1 million.

- removed (2011-04-26):
[0000950123-10-096054:note_history:42]
Long –Term Debt and Lines of Credit

- removed (2011-04-26):
[0000950123-10-096054:note_history:43]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of September 30, 2010 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic revolving credit facility |  | $ | — |  |  | $ | — |  |  | $ | 145.0 |  |  | $ | 145.0 |  |
| Senior unsecured notes |  |  | — |  |  |  | — |  |  |  | 200.0 |  |  |  | 200.0 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.8 |  |  |  | 17.1 |  |  |  | 17.9 |  |
| Foreign obligations |  |  | 8.2 |  |  |  | — |  |  |  | — |  |  |  | 8.2 |  |
| Total debt |  | $ | 8.2 |  |  | $ | 0.8 |  |  | $ | 362.1 |  |  | $ | 371.1 |  |

- removed (2011-04-26):
[0000950123-10-096054:note_history:44]
| Description of Obligations |  | Short-Term |  |  | Current |  |  | Long-Term |  |  |  |  |
| As of December 31, 2009 |  | Debt |  |  | Maturities |  |  | Maturities |  |  | Total |  |
| Domestic promissory notes (1) |  | $ | — |  |  | $ | 35.0 |  |  | $ | — |  |  | $ | 35.0 |  |
| Domestic revolving credit facility |  |  | — |  |  |  | — |  |  |  | 176.5 |  |  |  | 176.5 |  |
| Capital lease obligations |  |  | — |  |  |  | 0.4 |  |  |  | 17.1 |  |  |  | 17.5 |  |
| Foreign obligations |  |  | 2.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 2.5 |  |
| Total debt |  | $ | 2.2 |  |  | $ | 35.5 |  |  | $ | 193.8 |  |  | $ | 231.5 |  |

- removed (2011-04-26):
[0000950123-10-096054:note_history:45]
| (1) |  | The domestic promissory notes that were due to mature on June 1, 2010 were prepaid during the first quarter of 2010. |

- removed (2011-04-26):
[0000950123-10-096054:note_history:46]
As of September 30, 2010, we had outstanding borrowings of $145.0 million under the $650
   million domestic revolving credit facility and $69.5 million was committed to standby letters of
   credit. All of the remaining $435.5 million was available for future borrowings after
   consideration of covenant limitations. The facility matures in October 2012. As of September 30,
   2010, we were in compliance with all covenant requirements.

- removed (2011-04-26):
[0000950123-10-096054:note_history:47]
We have additional borrowing capacity through several of our foreign subsidiaries used
   primarily to finance seasonal borrowing needs. We had $8.2 million and $2.5 million of obligations
   outstanding through our foreign subsidiaries as of September 30, 2010 and December 31, 2009,
   respectively. Available borrowing capacity at September 30, 2010 and December 31, 2009, under
   foreign facilities was $10.0 million and $12.6 million, respectively.

- removed (2011-04-26):
[0000950123-10-096054:note_history:48]
The domestic revolving credit facility includes a subfacility for swingline loans of up to $50
   million and provides for the issuance of letters of credit for the full amount of the credit
   facility. Our weighted average borrowing rate on the facility was 0.96% and 0.84% as of September
   30, 2010 and December 31, 2009, respectively.

- removed (2011-04-26):
[0000950123-10-096054:note_history:49]
On May 6, 2010, we issued $200.0 million of senior unsecured notes due May 15, 2017 bearing
   fixed interest at 4.90% as a result of a public offering of securities. We received proceeds of
   $199.8 million from the offering
   for a yield of 4.91%. We also paid and capitalized $1.9 million of debt issue costs related
   to the issuance. We will pay interest on the notes semiannually on May 15 and November 15.

- removed (2011-04-26):
[0000950123-10-096054:note_history:50]
Under a revolving period asset securitization arrangement (“ASA”), we are eligible to sell
   beneficial interests in a portion of our trade accounts receivable to participating financial
   institutions for cash.

- removed (2011-04-26):
[0000950123-10-096054:note_history:51]
The ASA contains certain restrictive covenants relating to the quality of our
   accounts receivable and cross-default provisions with our Credit Agreement. The administrative
   agent under the ASA is also a participant in our Credit Agreement. The administrative agent has an
   investment grade credit rating. We continue to evaluate its creditworthiness and have no reason to
   believe it will not perform under the ASA. As of September 30, 2010, we were in compliance with all
   covenant requirements.

- removed (2011-04-26):
[0000950123-10-096054:note_history:52]
The ASA provides for a maximum securitization amount of $100.0 million or 100% of the net pool
   balance as defined by the ASA. However, eligibility for securitization is limited based on the
   amount and quality of the qualifying accounts receivable and is calculated monthly. The beneficial
   interest sold cannot exceed the maximum amount even if our qualifying accounts receivable is
   greater than the maximum amount at any point in time. The eligible amounts available and beneficial
   interests sold were as follows (in millions):

- removed (2011-04-26):
[0000950123-10-096054:note_history:53]
|  |  | As of |  |  | As of |  |
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2010 |  |  | 2009 |  |
| Eligible amount available under the ASA on qualified accounts receivable |  | $ | 93.9 |  |  | $ | 72.5 |  |
| Beneficial interest sold |  |  | — |  |  |  | — |  |
| Remaining amount available |  | $ | 93.9 |  |  | $ | 72.5 |  |
