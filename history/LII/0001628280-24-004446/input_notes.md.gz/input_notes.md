# LII notes — 0001628280-24-004446


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-24-004446:notes:1]
Portions of the registrant’s 2024 Definitive Proxy Statement to be filed with the Securities and Exchange Commission in connection with the registrant’s 2024 Annual Meeting of Stockholders to be held on May 16, 2024 are incorporated by reference into Part III of this report.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-24-004446:notes:2]
2. Summary of Significant Accounting Policies:

[0001628280-24-004446:notes:3]
Principles of Consolidation

[0001628280-24-004446:notes:4]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.

[0001628280-24-004446:notes:5]
Cash and Cash Equivalents

[0001628280-24-004446:notes:6]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.

[0001628280-24-004446:notes:7]
Short-term Investments

[0001628280-24-004446:notes:8]
Short-term investments include all investments, exclusive of cash equivalents, with a stated maturity date of one year or less from the balance sheet date.

[0001628280-24-004446:notes:9]
Accounts and Notes Receivable

[0001628280-24-004446:notes:10]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheet, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.

[0001628280-24-004446:notes:11]
Inventories

[0001628280-24-004446:notes:12]
Inventory costs include material, labor, and capitalized overhead.  Inventories of $438.9 million and $465.5 million as of December 31, 2023 and 2022, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001628280-24-004446:notes:13]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 9 for more information on our inventories.

[0001628280-24-004446:notes:14]
Property, Plant and Equipment

[0001628280-24-004446:notes:15]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001628280-24-004446:notes:16]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001628280-24-004446:notes:17]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 40 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 5 years |
| Vehicles | 3 to 10 years |

[0001628280-24-004446:notes:18]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 9 for additional information on our property, plant and equipment. Based on the expected fair value of the consideration to be received from the sale of our European commercial HVAC and refrigeration businesses, net of our costs to sell, we recorded an impairment on assets held for sale during the third quarter of 2023 which included a $22.6 million impairment of property, plant and equipment.

[0001628280-24-004446:notes:19]
Goodwill and Intangible Assets

[0001628280-24-004446:notes:20]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually during the third quarter and whenever events or changes in circumstances indicate the asset may be impaired.  See Note 9 for additional information on our goodwill.

[0001628280-24-004446:notes:21]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for the Company as a whole and for each reporting unit.

[0001628280-24-004446:notes:22]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.  In the third quarter of 2023, we recorded a $2.3 million impairment of goodwill related to our agreement to sell our European commercial HVAC and refrigeration businesses which was included in our impairment on assets held for sale.

[0001628280-24-004446:notes:23]
Intangible assets such as customer relationships, non-compete agreements and trade names with finite lives are amortized based on the pattern in which the economic benefits of the intangible assets are utilized. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, then straight-line amortization may be used.

[0001628280-24-004446:notes:24]
The range of useful lives approximates the following (in years):

[0001628280-24-004446:notes:25]
| Customer relationships | 2 to 20 years |
| Non-compete agreements | Contracted term |
| Trade names | 2 to 10 years |

[0001628280-24-004446:notes:26]
We assess the recoverability of the carrying amount of our intangible assets with finite lives whenever events or changes in circumstances indicate that the carrying value of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less then the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001628280-24-004446:notes:27]
Product Warranties

[0001628280-24-004446:notes:28]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from 1 to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded in cost of goods sold on the date that revenue is recognized. Our estimates of future warranty costs are determined by product category. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. In most cases, the estimated units to be repaired under warranty are multiplied by the estimated cost of replacement parts to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 5 for more information on our estimated future warranty costs.

[0001628280-24-004446:notes:29]
Pensions and Post-retirement Benefits

[0001628280-24-004446:notes:30]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheet.  Changes in the funded status are recognized in the year in which the changes occur through Accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001628280-24-004446:notes:31]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 10 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001628280-24-004446:notes:32]
Self-Insurance

[0001628280-24-004446:notes:33]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors, and trends.  The self-insurance liabilities as of December 31, 2023 represent the best estimate of the future payments to be made on reported and unreported losses for 2023 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 5 for additional information on our self-insured risks and liabilities.

[0001628280-24-004446:notes:34]
Derivatives

[0001628280-24-004446:notes:35]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheet at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 9 for more information on our derivatives.

[0001628280-24-004446:notes:36]
Leases

[0001628280-24-004446:notes:37]
We lease certain real and personal property under non-cancelable leases including real estate, IT equipment, fleet vehicles and manufacturing and distribution equipment.  At inception of the lease, we determine a lease exists if the contract conveys the right to control an identified asset for a period of time in exchange for consideration.  Control is considered to exist when the lessee has the right to obtain substantially all the economic benefits from the use of an identified asset as well as the right to direct the use of the asset.  If a contract is considered to be a lease, we recognize a lease liability based on the present value of the future minimum lease payments and a right-of-use asset.  For contracts that are 12 months or less, we do not recognize a right-of-use asset or liability.  We do not separate non-lease components from the lease components to which they relate and account for the combined lease and non-lease components as a single lease component.

[0001628280-24-004446:notes:38]
Income Taxes

[0001628280-24-004446:notes:39]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 12 for more information related to income taxes.

[0001628280-24-004446:notes:40]
Revenue Recognition

[0001628280-24-004446:notes:41]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 8 for more information on our revenue recognition practices.

[0001628280-24-004446:notes:42]
Cost of Goods Sold

[0001628280-24-004446:notes:43]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense, and freight and distribution costs.

[0001628280-24-004446:notes:44]
Selling, General and Administrative Expenses

[0001628280-24-004446:notes:45]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation, and rent.

[0001628280-24-004446:notes:46]
Stock-Based Compensation

[0001628280-24-004446:notes:47]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 15 for more information.

[0001628280-24-004446:notes:48]
Translation of Foreign Currencies

[0001628280-24-004446:notes:49]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.

[0001628280-24-004446:notes:50]
Use of Estimates

[0001628280-24-004446:notes:51]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-24-004446:notes:52]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001628280-24-004446:notes:53]
Changes in Accounting Standards Effective for Future Reporting Periods

[0001628280-24-004446:notes:54]
In March 2023, the FASB issued ASU No. 2023-02, Investments – Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Tax Credit Structures using the Proportional Amortization Method. ASU 2023-02 replaces the guidance related to accounting for investments in tax credit structures to allow the use of the proportional amortization method. The amendment permits reporting entities to elect to account for their equity investments in tax credit structures using the proportional amortization method if certain conditions are met. This amendment requires entities to make disclosures about all investments in a tax credit program for which they have elected to account for using the proportional amortization method, including those investments in an elected tax credit program that do not meet the conditions to apply the proportional amortization method. ASU 2023-02 is effective for fiscal years beginning after December 15, 2023, including interim periods within those fiscal years. We are currently evaluating the impact of this standard on our financial statements.

[0001628280-24-004446:notes:55]
In November 2023, the FASB issued ASU No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 updates reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. This is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. We are currently evaluating the impact of this standard on our financial statements.

[0001628280-24-004446:notes:56]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 updates income tax disclosure requirements, primarily through enhanced disclosures regarding income rate reconciliation and income taxes paid. This is effective for fiscal years beginning after December 15, 2024. We are currently evaluating the impact of this standard on our financial statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-24-004446:notes:57]
Components of Property, plant and equipment, net were as follows (in millions):

[0001628280-24-004446:notes:58]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Land | $ | 23.7 |  |  | $ | 24.1 |  |
| Buildings and improvements | 371.9 |  |  | 321.6 |  |
| Machinery and equipment | 965.0 |  |  | 964.7 |  |
| Finance leases | 72.2 |  |  | 66.5 |  |
| Construction in progress and equipment not yet in service | 198.4 |  |  | 92.8 |  |
| Total | 1,631.2 |  |  | 1,469.7 |  |
| Less accumulated depreciation | (910.8) |  |  | (920.8) |  |
| Property, plant and equipment, net | $ | 720.4 |  |  | $ | 548.9 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-004446:notes:59]
3. Reportable Business Segments:

[0001628280-24-004446:notes:60]
Description of Segments

[0001628280-24-004446:notes:61]
We operate in two reportable business segments of the HVACR industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001628280-24-004446:notes:62]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Home Comfort Solutions |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Building Climate Solutions |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products, curb, curb adapters, drop box diffusers, HVAC recycling and salvage service, condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks |  | Light Commercial; Food Preservation; Non-Food Industry |  | United StatesCanada |

[0001628280-24-004446:notes:63]
Prior to January 1, 2023, we operated in three reportable business segments.  In November 2022, we announced the decision to explore strategic alternatives for our European commercial HVAC and refrigeration businesses.  We continue to invest in our Heatcraft Worldwide Refrigeration business which is included in the Building Climate Solutions segment while our European portfolio is presented with Corporate and Other until disposition. The consolidation of our Heatcraft business within the Building Climate Solutions segment provides the opportunity to leverage synergies and create long-term growth opportunities by integrating entities with similar products, end consumers and financial performance metrics under the same management. The change in segment reporting better aligns with how the businesses are managed and evaluated given the change in portfolio.

[0001628280-24-004446:notes:64]
In the fourth quarter of 2023, we successfully completed the divestiture of our European operations.

[0001628280-24-004446:notes:65]
Segment Data

[0001628280-24-004446:notes:66]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001628280-24-004446:notes:67]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.

[0001628280-24-004446:notes:68]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001628280-24-004446:notes:69]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001628280-24-004446:notes:70]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Net Sales (1) |  |  |  |  |  |
| Home Comfort Solutions | $ | 3,222.9 |  |  | $ | 3,198.3 |  |  | $ | 2,775.6 |  |
| Building Climate Solutions (3) | 1,511.4 |  |  | 1,286.4 |  |  | 1,188.8 |  |
| Corporate and Other (3) | 247.6 |  |  | 233.7 |  |  | 229.7 |  |
|  | $ | 4,981.9 |  |  | $ | 4,718.4 |  |  | $ | 4,194.1 |  |
| Segment profit (loss) (2) |  |  |  |  |  |
| Home Comfort Solutions | $ | 610.2 |  |  | $ | 596.9 |  |  | $ | 540.3 |  |
| Building Climate Solutions (3) | 340.8 |  |  | 162.9 |  |  | 164.6 |  |
| Corporate and Other (3) | (93.9) |  |  | (94.0) |  |  | (101.0) |  |
| Total segment profit | 857.1 |  |  | 665.8 |  |  | 603.9 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Gain on sale of businesses (2) | (14.1) |  |  | — |  |  | — |  |
| Impairment of net assets held for sale (2) | 63.2 |  |  | — |  |  | — |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 14.8 |  |  | 8.1 |  |  | 14.3 |  |
| Special product quality adjustments (2) | — |  |  | — |  |  | (2.5) |  |
| Restructuring charges (2) | 3.1 |  |  | 1.5 |  |  | 1.8 |  |
| Operating income | $ | 790.1 |  |  | $ | 656.2 |  |  | $ | 590.3 |  |

[0001628280-24-004446:notes:71]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001628280-24-004446:notes:72]
(2) We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-24-004446:notes:73]
•The following items in Losses (gains) and other expenses, net:

[0001628280-24-004446:notes:74]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001628280-24-004446:notes:75]
◦Environmental liabilities and special litigation charges, and;

[0001628280-24-004446:notes:76]
◦Other items, net

[0001628280-24-004446:notes:77]
•Restructuring charges;

[0001628280-24-004446:notes:78]
•Special product quality adjustments;

[0001628280-24-004446:notes:79]
•Impairment on assets held for sale; and

[0001628280-24-004446:notes:80]
•Gain on sale of businesses.

[0001628280-24-004446:notes:81]
(3)  Previously, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio and that we would continue to invest in our Heatcraft Worldwide Refrigeration business, all of which were previously in our Refrigeration segment.  On January 1, 2023, we adjusted our segment presentation to better align with how the segments are managed and evaluated after the change in portfolio.  Heatcraft Worldwide Refrigeration is now part of the Business Climate Solutions segment while the European portfolio is presented with Corporate and Other until disposition. Amounts presented in this table have been recast to reflect the revised segment presentation. In the fourth quarter of 2023, we successfully completed the divestiture of our European operations.

[0001628280-24-004446:notes:82]
Total assets by segment are shown below (in millions):

[0001628280-24-004446:notes:83]
|  | As of December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Total Assets: |  |  |  |  |  |
| Home Comfort Solutions | $ | 1,449.4 |  |  | $ | 1,456.4 |  |  | $ | 1,149.7 |  |
| Building Climate Solutions | 989.2 |  |  | 730.3 |  |  | 626.7 |  |
| Corporate and Other | 359.7 |  |  | 380.9 |  |  | 395.5 |  |
| Total assets | $ | 2,798.3 |  |  | $ | 2,567.6 |  |  | $ | 2,171.9 |  |

[0001628280-24-004446:notes:84]
The assets in the Corporate and Other segment primarily consist of cash, short-term investments and deferred tax assets as well as the assets in the European portfolio which was disposed of in the fourth quarter of 2023.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001628280-24-004446:notes:85]
Total capital expenditures by segment are shown below (in millions):

[0001628280-24-004446:notes:86]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Capital Expenditures: |  |  |  |  |  |
| Home Comfort Solutions | $ | 59.1 |  |  | $ | 42.4 |  |  | $ | 70.0 |  |
| Building Climate Solutions | 119.6 |  |  | 29.7 |  |  | 9.7 |  |
| Corporate and Other | 71.5 |  |  | 29.0 |  |  | 27.1 |  |
| Total capital expenditures | $ | 250.2 |  |  | $ | 101.1 |  |  | $ | 106.8 |  |

[0001628280-24-004446:notes:87]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001628280-24-004446:notes:88]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Depreciation and Amortization: |  |  |  |  |  |
| Home Comfort Solutions | $ | 35.3 |  |  | $ | 31.5 |  |  | $ | 27.6 |  |
| Building Climate Solutions | 19.4 |  |  | 17.9 |  |  | 17.4 |  |
| Corporate and Other | 31.3 |  |  | 28.5 |  |  | 27.4 |  |
| Total depreciation and amortization | $ | 86.0 |  |  | $ | 77.9 |  |  | $ | 72.4 |  |

[0001628280-24-004446:notes:89]
The income from equity method investments is shown below (in millions):

[0001628280-24-004446:notes:90]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Home Comfort Solutions | $ | 5.5 |  |  | $ | 0.9 |  |  | $ | 6.9 |  |
| Building Climate Solutions | 3.0 |  |  | 4.2 |  |  | 4.9 |  |
| Total income from equity method investments | $ | 8.5 |  |  | $ | 5.1 |  |  | $ | 11.8 |  |

[0001628280-24-004446:notes:91]
Geographic Information

[0001628280-24-004446:notes:92]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001628280-24-004446:notes:93]
|  | As of December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 487.1 |  |  | $ | 408.8 |  |  | $ | 381.0 |  |
| Mexico | 228.7 |  |  | 110.9 |  |  | 102.7 |  |
| Canada | 2.2 |  |  | 2.1 |  |  | 2.1 |  |
| Other international | 2.4 |  |  | 27.1 |  |  | 29.3 |  |
| Total Property, plant and equipment, net | $ | 720.4 |  |  | $ | 548.9 |  |  | $ | 515.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-004446:notes:94]
4. Earnings Per Share:

[0001628280-24-004446:notes:95]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001628280-24-004446:notes:96]
The computations of basic and diluted earnings per share were as follows (in millions, except per share data):

[0001628280-24-004446:notes:97]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Net income | $ | 590.1 |  |  | $ | 497.1 |  |  | $ | 464.0 |  |
| Weighted-average shares outstanding – basic | 35.5 |  |  | 35.7 |  |  | 37.2 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.2 |  |  | 0.1 |  |  | 0.3 |  |
| Weighted-average shares outstanding – diluted | $ | 35.7 |  |  | $ | 35.8 |  |  | $ | 37.5 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Net income | $ | 16.61 |  |  | $ | 13.92 |  |  | $ | 12.47 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Net income | $ | 16.54 |  |  | $ | 13.88 |  |  | $ | 12.39 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001628280-24-004446:notes:98]
5. Commitments and Contingencies:

[0001628280-24-004446:notes:99]
We lease certain real and personal property under non-cancelable leases.  Approximately 82% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-004446:notes:100]
The components of lease expense were as follows (in millions):

[0001628280-24-004446:notes:101]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Finance lease cost: |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 14.5 |  |  | $ | 13.2 |  |  | $ | 11.9 |  |
| Interest on lease liabilities | 1.7 |  |  | 0.7 |  |  | 0.5 |  |
| Operating lease cost | 74.1 |  |  | 67.7 |  |  | 62.2 |  |
| Short-term lease cost | 5.3 |  |  | 5.0 |  |  | 3.8 |  |
| Variable lease cost | 26.8 |  |  | 24.5 |  |  | 21.6 |  |
| Total lease cost | $ | 122.4 |  |  | $ | 111.1 |  |  | $ | 100.0 |  |
| Other information |  |  |  |  |  |
| Cash paid for amounts included in the measurement lease liabilities: |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 70.5 |  |  | $ | 66.0 |  |  | $ | 61.8 |  |
| Financing cash flows from finance leases | $ | 15.8 |  |  | $ | 13.6 |  |  | $ | 12.3 |  |
| Right-of-use assets obtained in exchange for new finance lease liabilities | $ | 21.3 |  |  | $ | 14.4 |  |  | $ | 14.6 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 56.4 |  |  | $ | 98.8 |  |  | $ | 61.8 |  |

[0001628280-24-004446:notes:102]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Finance lease right-of-use assets(1) | $ | 38.4 |  |  | $ | 33.3 |  |
| Operating lease right-of-use assets | $ | 213.6 |  |  | $ | 219.9 |  |
| Finance lease liability, current(2) | $ | 12.1 |  |  | $ | 11.2 |  |
| Finance lease liability, non-current(3) | $ | 32.7 |  |  | $ | 28.3 |  |
| Operating lease liability, current | $ | 57.5 |  |  | $ | 63.3 |  |
| Operating lease liability, non-current | $ | 164.6 |  |  | $ | 161.8 |  |
| Weighted-average remaining lease term – finance leases | 3.4 years |  | 3.6 years |
| Weighted-average remaining lease term – operating leases | 5.0 years |  | 5.1 years |
| Weighted-average discount rate – finance leases | 4.30 | % |  | 1.92 | % |
| Weighted-average discount rate – operating leases | 4.14 | % |  | 3.44 | % |
| (1) Recorded in Property, plant and equipment in Consolidated Balance Sheet |
| (2) Recorded in Current maturities of long-term debt in Consolidated Balance Sheet |
| (3) Recorded in Long-term debt in Consolidated Balance Sheet |

[0001628280-24-004446:notes:103]
Future annual minimum lease payments and finance lease commitments as of December 31, 2023 were as follows (in millions).  We have signed three real estate operating leases which have not yet commenced but create significant rights and obligations amounting to approximately $46.1 million and are excluded from the table below.

[0001628280-24-004446:notes:104]
|  | Operating Leases |  | Finance Leases |
| 2024 | $ | 64.6 |  |  | $ | 13.4 |  |
| 2025 | 51.6 |  |  | 10.8 |  |
| 2026 | 42.9 |  |  | 6.8 |  |
| 2027 | 31.6 |  |  | 3.1 |  |
| 2028 | 22.0 |  |  | 13.1 |  |
| Thereafter | 33.5 |  |  | — |  |
| Total minimum lease payments | $ | 246.2 |  |  | $ | 47.2 |  |
| Less imputed interest | (24.1) |  |  | (2.4) |  |
| Present value of minimum payments | $ | 222.1 |  |  | $ | 44.8 |  |

[0001628280-24-004446:notes:105]
On March 1, 2019, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of five years through March 1, 2024 (the “Lake Park Renewal”). The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  In December 2023, we purchased the property for $41.2 million.

[0001628280-24-004446:notes:106]
Environmental

[0001628280-24-004446:notes:107]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties, properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets. Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001628280-24-004446:notes:108]
Product Warranties and Product Related Contingencies

[0001628280-24-004446:notes:109]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001628280-24-004446:notes:110]
Total product warranty liabilities are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-24-004446:notes:111]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Accrued expenses | $ | 45.4 |  |  | $ | 41.3 |  |
| Other liabilities | 97.4 |  |  | 101.4 |  |
| Total product warranty liabilities | $ | 142.8 |  |  | $ | 142.7 |  |

[0001628280-24-004446:notes:112]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2023 and 2022 were as follows (in millions):

[0001628280-24-004446:notes:113]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Payments made in 2022 | (36.3) |  |
| Changes resulting from issuance of new warranties | 50.5 |  |
| Changes in estimates associated with pre-existing liabilities | (4.7) |  |
| Changes in foreign currency translation rates and other | (1.0) |  |
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Payments made in 2023 | (40.1) |  |
| Changes resulting from issuance of new warranties | 53.9 |  |
| Changes in estimates associated with pre-existing liabilities | (13.9) |  |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of December 31, 2023 | $ | 142.8 |  |

[0001628280-24-004446:notes:114]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures. We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess

[0001628280-24-004446:notes:115]
liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001628280-24-004446:notes:116]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.

[0001628280-24-004446:notes:117]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-24-004446:notes:118]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Accrued expenses | $ | 3.8 |  |  | $ | 3.0 |  |
| Other liabilities | 15.1 |  |  | 14.6 |  |
| Total self-insurance liabilities | $ | 18.9 |  |  | $ | 17.6 |  |

[0001628280-24-004446:notes:119]
Litigation

[0001628280-24-004446:notes:120]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-24-004446:notes:121]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-004446:notes:122]
6. Stock Repurchases:

[0001628280-24-004446:notes:123]
Our Board of Directors have authorized a total of $4 billion to repurchase shares of our common stock (collectively referred to as the “Share Repurchase Plans”), including a $1.0 billion share repurchase authorization in July 2021. The Share Repurchase Plans allow us to repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The Share Repurchase Plans do not require the repurchase of a specific number of shares and may be terminated at any time. As of December 31, 2023, $546 million of shares is available to repurchase shares under the Share Repurchase Plans.

[0001628280-24-004446:notes:124]
We used $300 million to purchase 1.3 million shares of our common stock in 2022 and $600 million to purchase 1.9 million shares of our common stock in 2021. No shares were repurchased in 2023. The shares repurchased are held as treasury shares.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-24-004446:notes:125]
7. Restructuring Charges:

[0001628280-24-004446:notes:126]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 3.

[0001628280-24-004446:notes:127]
We recorded $3.1 million of restructuring charges in 2023 to reorganize or remove duplicative headcount and infrastructure. We recorded restructuring charges of $1.5 million in 2022 and $1.8 million in 2021 from activities initiated in prior years including the economic impact of COVID-19. There is not expected to be a material amount of costs incurred from existing restructuring actions in future periods.  
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-004446:notes:128]
8. Revenue Recognition:

[0001628280-24-004446:notes:129]
The following table disaggregates our revenue by business segment by geography to provide information as to the major sources of revenue.  See Note 3 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001628280-24-004446:notes:130]
|  | For the Year Ended December 31, 2023 |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 3,001.3 |  |  | $ | 1,415.6 |  |  | $ | — |  |  | $ | 4,416.9 |  |
| Canada | 221.6 |  |  | 95.8 |  |  | — |  |  | 317.4 |  |
| International | — |  |  | — |  |  | 247.6 |  |  | 247.6 |  |
| Total | $ | 3,222.9 |  |  | $ | 1,511.4 |  |  | $ | 247.6 |  |  | $ | 4,981.9 |  |

[0001628280-24-004446:notes:131]
|  | For the Year Ended December 31, 2022(1) |
| Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,957.1 |  |  | $ | 1,223.4 |  |  | $ | — |  |  | $ | 4,180.5 |  |
| Canada | 241.2 |  |  | 62.4 |  |  | — |  |  | 303.6 |  |
| International | — |  |  | 0.6 |  |  | 233.7 |  |  | 234.3 |  |
| Total | $ | 3,198.3 |  |  | $ | 1,286.4 |  |  | $ | 233.7 |  |  | $ | 4,718.4 |  |

[0001628280-24-004446:notes:132]
|  |  | For the Year Ended December 31, 2021(1) |
|  | Primary Geographic Markets | Home Comfort Solutions |  | Building Climate Solutions |  | Corporate and Other |  | Consolidated |
|  | United States | $ | 2,532.4 |  |  | $ | 1,114.1 |  |  | $ | — |  |  | $ | 3,646.5 |  |
|  | Canada | 243.2 |  |  | 73.1 |  |  | — |  |  | 316.3 |  |
|  | International | — |  |  | 1.6 |  |  | 229.7 |  |  | 231.3 |  |
|  | Total | $ | 2,775.6 |  |  | $ | 1,188.8 |  |  | $ | 229.7 |  |  | $ | 4,194.1 |  |

[0001628280-24-004446:notes:133]
(1) As discussed in Note 3, on January 1, 2023 we adjusted our segment reporting to include the results of our Heatcraft business in Building Climate Solutions and the results of our European portfolio in Corporate and Other until their disposition. The amounts for the years ended December 31, 2022 and December 31, 2021 have been recast to reflect the revised segment presentation.

[0001628280-24-004446:notes:134]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001628280-24-004446:notes:135]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Building Climate Solutions segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  Revenue from extended warranties is insignificant. See Note 5 for more information on product warranties.

[0001628280-24-004446:notes:136]
Home Comfort Solutions  - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent

[0001628280-24-004446:notes:137]
installing dealers, including through our network of Lennox stores or to independent distributors. For the years ended December 31, 2023, 2022 and 2021, direct sales represented 75%, 70% and 73% of revenues, respectively, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-24-004446:notes:138]
Building Climate Solutions - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name. Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets. We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. AES manufactures curb, curb adapters, drop box diffusers and also offers HVAC recycling and salvage services, as well as focusing on multi-family HVAC replacement for expired mechanical assets.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the years ended December 31, 2023, 2022 and 2021, equipment sales represented 86%, 82% and 82% of revenues, respectively, and the remainder of our revenue was generated from our service business.

[0001628280-24-004446:notes:139]
Corporate and Other - In Europe, we manufactured and marketed equipment for the global commercial refrigeration markets.  We also manufactured and sold unitary heating and cooling products and applied systems. A de minimis amount of segment revenue related to services for start-up and commissioning activities. In the fourth quarter of 2023, we successfully completed the divestiture of our European operations.

[0001628280-24-004446:notes:140]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001628280-24-004446:notes:141]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001628280-24-004446:notes:142]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheets.

[0001628280-24-004446:notes:143]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accrued expenses in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheets.

[0001628280-24-004446:notes:144]
Net contract assets (liabilities) consisted of the following:

[0001628280-24-004446:notes:145]
|  | December 31, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract assets | $ | 2.2 |  |  | $ | — |  |  |  |  |  |
| Contract liabilities - current | (4.7) |  |  | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.5) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (10.0) |  |  | $ | (16.0) |  |  |  |  |  |

[0001628280-24-004446:notes:146]
For the years ended December 31, 2023,  2022, and 2021 we recognized revenue of $7.7 million, $10.1 million and $3.6 million related to our contract liabilities at January 1, 2023, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023, 2022 and 2021.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-004446:notes:147]
The components of inventories are as follows (in millions):

[0001628280-24-004446:notes:148]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Finished goods | $ | 509.4 |  |  | $ | 534.6 |  |
| Work in process | 9.6 |  |  | 8.9 |  |
| Raw materials and parts | 314.2 |  |  | 328.7 |  |
| Total | 833.2 |  |  | 872.2 |  |
| Excess of current cost over last-in, first-out cost | (134.1) |  |  | (119.2) |  |
| Total inventories, net | $ | 699.1 |  |  | $ | 753.0 |  |

[0001628280-24-004446:notes:149]
Reserves for obsolete and slow-moving inventories were $40.2 million and $34.9 million at December 31, 2023 and December 31, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-004446:notes:150]
Goodwill

[0001628280-24-004446:notes:151]
The changes in the carrying amount of goodwill in 2023 and 2022, in total and by segment, are summarized in the table below (in millions):

[0001628280-24-004446:notes:152]
| Segment: | Balance at December 31, 2021 (1) |  |  |  | Changes in foreign currency translation rates |  | Balance at December 31, 2022 |  | Goodwill reallocation (2) |  | Goodwill related to divested entities (3) |  | Goodwill from business acquisition (4) |  | Balance at December 31, 2023 |
| Home Comfort Solutions | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Building Climate Solutions | 61.1 |  |  |  |  | — |  |  | 61.1 |  |  | 94.5 |  |  | — |  |  | 40.4 |  |  | 196.0 |  |
| Historical Refrigeration segment | 99.4 |  |  |  |  | (0.3) |  |  | 99.1 |  |  | (99.1) |  |  | — |  |  | — |  |  | — |  |
| Corporate and Other | — |  |  |  |  | — |  |  | — |  |  | 4.6 |  |  | (4.6) |  |  | — |  |  | — |  |
|  | $ | 186.6 |  |  |  |  | $ | (0.3) |  |  | $ | 186.3 |  |  | $ | — |  |  | $ | (4.6) |  |  | $ | 40.4 |  |  | $ | 222.1 |  |

[0001628280-24-004446:notes:153]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $32.7 million, all of which relate to impairments in periods prior to 2021.

[0001628280-24-004446:notes:154]
(2) As discussed in Note 3, we recast our segment presentation to present our Heatcraft Worldwide Refrigeration business as a component of our Building Climate Solutions segment and our European portfolio as a component of Corporate and Other. Since there is no longer a Refrigeration segment, we allocated goodwill to each segment based upon the relative fair value of the business.

[0001628280-24-004446:notes:155]
(3) There was $4.6 million of goodwill related to our European portfolio. As part of the loss on assets held for sale that was recorded in the third quarter of 2023, we recorded an impairment of $2.3 million for a portion of the goodwill transferred. The remaining goodwill was included in the balance of disposed net assets.

[0001628280-24-004446:notes:156]
(4) On October 25, 2023, we announced the acquisition of AES.  In connection with this acquisition, $40.4 million of goodwill was recorded and included in the Building Climate Solutions reporting unit. AES is included in the Building Climate Solutions segment. See Note 18 for additional information on the AES acquisition. 
A qualitative review of impairment indicators was performed in 2023 for the Home Comfort Solutions and Building Climate Solutions segments.  No impairment charges were recorded in 2023 or 2022, except to the extent of respective goodwill impaired as part of the disposition of our European operations.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-24-004446:notes:157]
No impairment charges were recorded in 2023 or 2022, except to the extent of respective property, plant and equipment  impaired as part of the disposition of our European operations.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-24-004446:notes:158]
Accrued Expenses

[0001628280-24-004446:notes:159]
The significant components of Accrued expenses are presented below (in millions):

[0001628280-24-004446:notes:160]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Accrued rebates and promotions | $ | 121.5 |  |  | $ | 123.3 |  |
| Accrued compensation and benefits | 111.8 |  |  | 84.9 |  |
| Accrued warranties | 45.4 |  |  | 41.3 |  |
| Accrued sales, use, property and VAT taxes | 27.1 |  |  | 26.8 |  |
| Accrued freight | 19.6 |  |  | 19.0 |  |
| Accrued asbestos reserves | 17.9 |  |  | 14.3 |  |
| Accrued interest | 11.3 |  |  | 6.1 |  |
| Accrued pension | 11.2 |  |  | 5.8 |  |
| Derivative contracts | 5.7 |  |  | 9.0 |  |
| Deferred income | 4.7 |  |  | 9.6 |  |
| Self insurance reserves | 3.8 |  |  | 3.0 |  |
| Other | 36.1 |  |  | 33.8 |  |
| Total Accrued expenses | $ | 416.1 |  |  | $ | 376.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-24-004446:notes:161]
Objectives and Strategies for Using Derivative Instruments

[0001628280-24-004446:notes:162]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001628280-24-004446:notes:163]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001628280-24-004446:notes:164]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001628280-24-004446:notes:165]
Cash Flow Hedges

[0001628280-24-004446:notes:166]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2025 and January 2025, respectively. We currently have cash flow hedge contracts with a notional amount of 54.2 million pounds of aluminum and copper. Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 17 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001628280-24-004446:notes:167]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001628280-24-004446:notes:168]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Unrealized losses, net on unsettled contracts | $ | 2.6 |  |  | $ | 6.3 |  |
| Income tax benefit | (0.6) |  |  | (1.4) |  |
| Unrealized losses included in AOCL, net of tax (1) | $ | 2.0 |  |  | $ | 4.9 |  |

[0001628280-24-004446:notes:169]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $2.4 million of derivative losses into earnings within the next 12 months.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-24-004446:notes:170]
Expenses included in our Consolidated Statements of Operations

[0001628280-24-004446:notes:171]
Below is information about expenses included in Selling, general and administrative expenses in our Consolidated Statements of Operations (in millions):

[0001628280-24-004446:notes:172]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Research and development | $ | 94.0 |  |  | $ | 80.3 |  |  | $ | 76.1 |  |
| Advertising, promotions and marketing | 39.5 |  |  | 32.4 |  |  | 26.9 |  |
| Cooperative advertising expenditures | 28.7 |  |  | 28.1 |  |  | 27.6 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001628280-24-004446:notes:173]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-24-004446:notes:174]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | (1.2) |  |
| Foreign currency exchange gains | (4.3) |  |  | (1.3) |  |  | (2.2) |  |
| Gain on disposal of fixed assets | (0.5) |  |  | (1.0) |  |  | (0.2) |  |
| Other operating income | (1.6) |  |  | (1.0) |  |  | (1.5) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.1) |  |  | 0.4 |  |  | — |  |
| Environmental liabilities and special litigation charges | 15.6 |  |  | 7.5 |  |  | 9.6 |  |
| Charges incurred related to COVID-19 pandemic | — |  |  | 0.8 |  |  | 2.2 |  |
| Other items, net | (0.7) |  |  | (0.6) |  |  | 2.5 |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 8.5 |  |  | $ | 4.9 |  |  | $ | 9.2 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001628280-24-004446:notes:175]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001628280-24-004446:notes:176]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest | $ | 56.0 |  |  | $ | 39.8 |  |  | $ | 26.0 |  |
| Less: Interest income | 4.3 |  |  | 1.1 |  |  | 1.0 |  |
| Interest expense, net | $ | 51.7 |  |  | $ | 38.7 |  |  | $ | 25.0 |  |

[0001628280-24-004446:notes:177]
Our provision for income taxes consisted of the following (in millions):

[0001628280-24-004446:notes:178]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Current: |  |  |  |  |  |
| Federal | $ | 131.8 |  |  | $ | 104.0 |  |  | $ | 72.0 |  |
| State | 26.6 |  |  | 21.6 |  |  | 17.0 |  |
| Foreign | 14.5 |  |  | 7.8 |  |  | 13.4 |  |
| Total current | 172.9 |  |  | 133.4 |  |  | 102.4 |  |
| Deferred: |  |  |  |  |  |
| Federal | (22.2) |  |  | (13.9) |  |  | (2.6) |  |
| State | (4.9) |  |  | (3.1) |  |  | (1.5) |  |
| Foreign | 1.6 |  |  | 2.3 |  |  | (2.2) |  |
| Total deferred | (25.5) |  |  | (14.7) |  |  | (6.3) |  |
| Total provision for income taxes | $ | 147.4 |  |  | $ | 118.7 |  |  | $ | 96.1 |  |


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001628280-24-004446:notes:179]
Losses (Gains) and Other Expenses, net


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-24-004446:notes:180]
10. Employee Benefit Plans: 
Many of our defined benefit pension and profit sharing plans have been frozen and replaced with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. We also have several active defined benefit plans that provide benefits based on years of service. Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001628280-24-004446:notes:181]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.

[0001628280-24-004446:notes:182]
Defined Contribution Plans

[0001628280-24-004446:notes:183]
We recorded the following contributions to our defined contribution plans (in millions):

[0001628280-24-004446:notes:184]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Contributions to defined contribution plans | $ | 22.5 |  |  | $ | 22.7 |  |  | $ | 19.9 |  |

[0001628280-24-004446:notes:185]
Pension and Post-retirement Benefit Plans

[0001628280-24-004446:notes:186]
Benefit Obligations, Fair Value of Plan Assets, Funded Status, and Balance Sheet Position

[0001628280-24-004446:notes:187]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001628280-24-004446:notes:188]
|  | Pension Benefits |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Accumulated benefit obligation | $ | 176.9 |  |  | $ | 171.6 |  |  |  |  |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 174.3 |  |  | $ | 269.2 |  |  |  |  |  |
| Service cost | 2.1 |  |  | 3.8 |  |  |  |  |  |
| Interest cost | 8.9 |  |  | 6.2 |  |  |  |  |  |
| Actuarial loss (gain) | 4.5 |  |  | (74.6) |  |  |  |  |  |
| Effect of exchange rates | 1.1 |  |  | (3.4) |  |  |  |  |  |
| Adjustment upon sale of businesses | (4.8) |  |  | — |  |  |  |  |  |
| Settlements | (0.5) |  |  | (21.7) |  |  |  |  |  |
| Benefits paid | (6.5) |  |  | (5.2) |  |  |  |  |  |
| Benefit obligation at end of year | $ | 179.1 |  |  | $ | 174.3 |  |  |  |  |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 131.1 |  |  | $ | 184.3 |  |  |  |  |  |
| Actual return on plan assets | 16.4 |  |  | (45.4) |  |  |  |  |  |
| Employer contributions | 15.0 |  |  | 22.5 |  |  |  |  |  |
| Effect of exchange rates | 1.0 |  |  | (3.4) |  |  |  |  |  |
| Plan settlements | (0.5) |  |  | (21.7) |  |  |  |  |  |
| Benefits paid | (6.5) |  |  | (5.2) |  |  |  |  |  |
| Fair value of plan assets at end of year | 156.5 |  |  | 131.1 |  |  |  |  |  |
| Funded status / net amount recognized | $ | (22.6) |  |  | $ | (43.2) |  |  |  |  |  |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Non-current assets | $ | 11.1 |  |  | $ | 2.7 |  |  |  |  |  |
| Current liability | (11.2) |  |  | (5.8) |  |  |  |  |  |
| Non-current liability | (22.5) |  |  | (40.1) |  |  |  |  |  |
| Net amount recognized | $ | (22.6) |  |  | $ | (43.2) |  |  |  |  |  |

[0001628280-24-004446:notes:189]
Plans with Benefit Obligations in Excess of Plan Assets

[0001628280-24-004446:notes:190]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 38.9 |  |  | $ | 152.1 |  |
| Accumulated benefit obligation | 36.9 |  |  | 149.6 |  |
| Fair value of plan assets | — |  |  | 106.2 |  |

[0001628280-24-004446:notes:191]
Net Periodic Benefit Cost

[0001628280-24-004446:notes:192]
Our U.S.-based pension plans comprised approximately 86% of the projected benefit obligation and 84% of plan assets as of December 31, 2023.

[0001628280-24-004446:notes:193]
|  | Pension Benefits |  |  |
|  | 2023 |  | 2022 |  | 2021 |  |  |  |  |  |  |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 2.1 |  |  | $ | 3.8 |  |  | $ | 6.1 |  |  |  |  |  |  |  |
| Interest cost | 8.9 |  |  | 6.2 |  |  | 5.1 |  |  |  |  |  |  |  |
| Expected return on plan assets | (9.4) |  |  | (9.1) |  |  | (8.6) |  |  |  |  |  |  |  |
| Amortization of prior service costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  |  |  |  |  |  |
| Recognized actuarial loss | 1.1 |  |  | 5.3 |  |  | 7.7 |  |  |  |  |  |  |  |
| Settlements | 0.8 |  |  | (0.2) |  |  | 1.2 |  |  |  |  |  |  |  |
| Other | (0.4) |  |  | (0.1) |  |  | (0.4) |  |  |  |  |  |  |  |
| Net periodic benefit cost | $ | 3.2 |  |  | $ | 6.0 |  |  | $ | 11.3 |  |  |  |  |  |  |  |

[0001628280-24-004446:notes:194]
Amounts recognized in AOCL and Other Comprehensive Income

[0001628280-24-004446:notes:195]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2023 and 2022 (in millions):

[0001628280-24-004446:notes:196]
|  | Pension Benefits |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Amounts recognized in AOCL: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.3) |  |  | $ | (0.4) |  |  |  |  |  |
| Pension adjustments upon sale of businesses | (1.8) |  |  | — |  |  |  |  |  |
| Actuarial loss | (52.6) |  |  | (57.7) |  |  |  |  |  |
| Subtotal | (54.7) |  |  | (58.1) |  |  |  |  |  |
| Deferred taxes | 14.7 |  |  | 15.8 |  |  |  |  |  |
| Net amount recognized | $ | (40.0) |  |  | $ | (42.3) |  |  |  |  |  |
| Changes recognized in other comprehensive loss: |  |  |  |  |  |  |  |
| Current year actuarial gain | (1.8) |  |  | (19.4) |  |  |  |  |  |
| Effect of exchange rates | 0.4 |  |  | (0.9) |  |  |  |  |  |
| Amortization of prior service costs | (0.1) |  |  | (0.1) |  |  |  |  |  |
| Amortization of actuarial loss, including settlements and other | (1.5) |  |  | (5.1) |  |  |  |  |  |
| Total recognized in other comprehensive income (loss) | $ | (3.0) |  |  | $ | (25.5) |  |  |  |  |  |
| Total recognized in net periodic benefit cost and other comprehensive income | $ | 0.2 |  |  | $ | (19.5) |  |  |  |  |  |

[0001628280-24-004446:notes:197]
The estimated prior service costs and actuarial losses for pension benefits that will be amortized from AOCL in 2024 are $0.1 million and $1.4 million, respectively.

[0001628280-24-004446:notes:198]
Assumptions

[0001628280-24-004446:notes:199]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2023 and 2022:

[0001628280-24-004446:notes:200]
|  |  | Pension Benefits |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |  |
| Discount rate |  | 5.23 | % |  | 5.50 | % |  |  |  |  |
| Rate of compensation increase |  | 4.02 | % |  | 4.02 | % |  |  |  |  |

[0001628280-24-004446:notes:201]
|  | Pension Benefits |  |  |
|  | 2023 |  | 2022 |  | 2021 |  |  |  |  |  |  |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 5.39 | % |  | 2.53 | % |  | 1.85 | % |  |  |  |  |  |  |
| Discount rate - interest cost | 5.38 | % |  | 2.48 | % |  | 2.16 | % |  |  |  |  |  |  |
| Expected long-term return on plan assets | 6.50 | % |  | 6.50 | % |  | 6.50 | % |  |  |  |  |  |  |
| Rate of compensation increase | 4.02 | % |  | 4.13 | % |  | 4.13 | % |  |  |  |  |  |  |

[0001628280-24-004446:notes:202]
The change in the discount rate for 2023 was the primary driver in the actuarial gain in the projected benefit obligation during the year.

[0001628280-24-004446:notes:203]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2023 and 2022:

[0001628280-24-004446:notes:204]
|  | Pension Benefits |
|  | 2023 |  | 2022 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 4.30 | % |  | 4.72 | % |
| Rate of compensation increase | 3.07 | % |  | 3.11 | % |

[0001628280-24-004446:notes:205]
|  | Pension Benefits |
|  | 2023 |  | 2022 |  | 2021 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 3.75 | % |  | 0.86 | % |  | 0.42 | % |
| Discount rate - interest cost | 4.79 | % |  | 2.07 | % |  | 1.51 | % |
| Expected long-term return on plan assets | 4.94 | % |  | 2.75 | % |  | 2.10 | % |
| Rate of compensation increase | 3.11 | % |  | 3.14 | % |  | 3.17 | % |

[0001628280-24-004446:notes:206]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 6.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001628280-24-004446:notes:207]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and other post-employment benefits (OPEB) plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001628280-24-004446:notes:208]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001628280-24-004446:notes:209]
|  | 2023 |  | 2022 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2030 |  | 2029 |

[0001628280-24-004446:notes:210]
Expected future benefit payments are shown in the table below (in millions):

[0001628280-24-004446:notes:211]
|  | For the Years Ended December 31, |
|  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029-2033 |
| Pension benefits | $ | 16.7 |  |  | $ | 7.4 |  |  | $ | 8.7 |  |  | $ | 21.8 |  |  | $ | 11.4 |  |  | $ | 57.3 |  |

[0001628280-24-004446:notes:212]
Composition of Pension Plan Assets

[0001628280-24-004446:notes:213]
In the fourth quarter of 2023, based on the strong funded status of our U.S. pension plan, we opted to make a $12.2 million voluntary contribution to the plan to increase the funded status and fully fund the plan.  With the U.S. pension plan fully funded, the asset allocation was changed from a blend of 50% equities and 50% fixed income to 100% fixed income in order to align changes in asset values with changes in liabilities, therefore reducing funded status volatility, which effectively placed the plan in hibernation status.  As a result, we reduced the expected long-term rate of return for our U.S. pension plan assets to 4.5%.  Our U.S. pension plan represents 84%, our Canadian pension plan 7%, and our United Kingdom (“U.K.”) pension plan 9% of the total fair value of our plan assets as of December 31, 2023.

[0001628280-24-004446:notes:214]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2023 and 2022, by asset category, were as follows:

[0001628280-24-004446:notes:215]
|  | Plan Assets as of December 31, |
| Asset Category: | 2023 |  | 2022 |
| U.S. equity | — | % |  | 31.3 | % |
| International equity | — | % |  | 18.7 | % |
| Fixed income | 100.0 | % |  | 49.2 | % |
| Money market/cash | — | % |  | 0.8 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001628280-24-004446:notes:216]
Our U.S. pension plans’ assets were invested according to the following targets:

[0001628280-24-004446:notes:217]
| Asset Category: | Target |
| U.S. equity | — | % |
| International equity | — | % |
| Fixed income | 100.0 | % |

[0001628280-24-004446:notes:218]
Similarly, based on the strong funded status of our Canadian pension plans, the asset allocation was adjusted as well, with the Salaried plan moving from 75% fixed income and 25% equity to 100% fixed income, and the Hourly plan moving from 75% fixed income and 25% equity to 90% fixed income and 10% equity.  As with the U.S. pension plan, this change in asset allocation will greatly reduce funded status volatility.

[0001628280-24-004446:notes:219]
Our U.K. pension plan was invested in fixed income securities, including corporate and government bonds.

[0001628280-24-004446:notes:220]
The fair values of our pension plan assets, by asset category, were as follows (in millions):

[0001628280-24-004446:notes:221]
|  | Fair Value Measurements as of December 31, 2023 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| Fixed income (3) | — |  |  | 130.8 |  |  | — |  |  | 130.8 |  |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |  |
| Fixed income | — |  |  | 11.1 |  |  | — |  |  | 11.1 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (5) | — |  |  | 14.0 |  |  | — |  |  | 14.0 |  |  |
| Total | $ | 0.1 |  |  | $ | 156.4 |  |  | $ | — |  |  | $ | 156.5 |  |  |

[0001628280-24-004446:notes:222]
|  | Fair Value Measurements as of December 31, 2022 |  |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |  |
| Asset Category: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 0.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 33.3 |  |  | — |  |  | 33.3 |  |  |
| International equity (2) | — |  |  | 19.8 |  |  | — |  |  | 19.8 |  |  |
| Fixed income (3) | — |  |  | 52.5 |  |  | — |  |  | 52.5 |  |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |  |
| International equity | — |  |  | 3.3 |  |  | — |  |  | 3.3 |  |  |
| Fixed income | — |  |  | 8.3 |  |  | — |  |  | 8.3 |  |  |
| Pension fund: |  |  |  |  |  |  |  |  |
| Fixed income (5) | — |  |  | 13.0 |  |  | — |  |  | 13.0 |  |  |
| Total | $ | 0.9 |  |  | $ | 130.2 |  |  | $ | — |  |  | $ | 131.1 |  |  |

[0001628280-24-004446:notes:223]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001628280-24-004446:notes:224]
|  | As of December 31, 2023 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| Fixed income (3) | $ | 130.8 |  |  | Daily |  | 5 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 0.5 |  |  | Daily |  | 3-5 days |
| Fixed income | 11.1 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 14.0 |  |  | Daily |  | 1-3 days |
| Total | $ | 156.4 |  |  |  |  |  |

[0001628280-24-004446:notes:225]
|  | As of December 31, 2022 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 33.3 |  |  | Daily |  | 5 days |
| International equity (2) | 19.8 |  |  | Daily |  | 5 days |
| Fixed income (3) | 52.5 |  |  | Daily |  | 5 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 3.3 |  |  | Daily |  | 3-5 days |
| Fixed income | 8.3 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| Fixed income (5) | 13.0 |  |  | Daily |  | 1-3 days |
| Total | $ | 130.2 |  |  |  |  |  |

[0001628280-24-004446:notes:226]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (5) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. The plan also holds a portion of its assets in international instruments, a portion of which may be invested in U.S. securities. |

[0001628280-24-004446:notes:227]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 16 for information about our fair value hierarchies and valuation techniques.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001628280-24-004446:notes:228]
11. Joint Ventures and Other Equity Investments:

[0001628280-24-004446:notes:229]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001628280-24-004446:notes:230]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001628280-24-004446:notes:231]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Equity method investments | $ | 58.4 |  |  | $ | 44.4 |  |

[0001628280-24-004446:notes:232]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001628280-24-004446:notes:233]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Purchases of compressors from joint venture | $ | 148.3 |  |  | $ | 156.2 |  |  | $ | 141.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-004446:notes:234]
12. Income Taxes:

[0001628280-24-004446:notes:235]
Income before income taxes was comprised of the following (in millions):

[0001628280-24-004446:notes:236]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Domestic | $ | 471.4 |  |  | $ | 340.2 |  |  | $ | 307.8 |  |
| Foreign | 266.1 |  |  | 275.6 |  |  | 252.3 |  |
| Total | $ | 737.5 |  |  | $ | 615.8 |  |  | $ | 560.1 |  |

[0001628280-24-004446:notes:237]
The difference between the income tax provision computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001628280-24-004446:notes:238]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Provision at the U.S. statutory rate of 21% | $ | 154.9 |  |  | $ | 129.3 |  |  | $ | 117.6 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 16.4 |  |  | 14.6 |  |  | 12.1 |  |
| Tax credits, net of unrecognized tax benefits | (3.4) |  |  | (8.0) |  |  | (9.3) |  |
| Change in unrecognized tax benefits | 0.4 |  |  | 0.2 |  |  | 0.2 |  |
| Change in valuation allowance | 0.1 |  |  | — |  |  | — |  |
| Foreign taxes at rates other than U.S. statutory rate | (40.3) |  |  | (47.4) |  |  | (43.6) |  |
| Deemed inclusions | 6.1 |  |  | 10.0 |  |  | 7.7 |  |
| Global intangible low-taxed income | 17.5 |  |  | 23.9 |  |  | 18.8 |  |
| Change in rates from the Tax Act & other law changes | 0.2 |  |  | 0.1 |  |  | 0.1 |  |
| Excess tax benefits from stock-based compensation | (5.2) |  |  | (0.6) |  |  | (5.7) |  |
| Miscellaneous other | 0.7 |  |  | (3.4) |  |  | (1.8) |  |
| Total provision for income taxes | $ | 147.4 |  |  | $ | 118.7 |  |  | $ | 96.1 |  |

[0001628280-24-004446:notes:239]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001628280-24-004446:notes:240]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001628280-24-004446:notes:241]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 35.9 |  |  | $ | 34.9 |  |
| Loss carryforwards (foreign, U.S. and state) | 10.9 |  |  | 29.6 |  |
| Post-retirement and pension benefits | 4.7 |  |  | 10.2 |  |
| Inventory reserves | 12.3 |  |  | 9.3 |  |
| Receivables allowance | 6.6 |  |  | 6.0 |  |
| Compensation liabilities | 6.2 |  |  | 5.9 |  |
| Legal reserves | 14.2 |  |  | 10.5 |  |
| Tax credits, net of federal effect | 12.1 |  |  | 11.9 |  |
| Research and development capitalization | 39.7 |  |  | 17.9 |  |
| Other | 9.0 |  |  | 7.1 |  |
| Total deferred tax assets | 151.6 |  |  | 143.3 |  |
| Valuation allowance | (17.8) |  |  | (37.9) |  |
| Total deferred tax assets, net of valuation allowance | 133.8 |  |  | 105.4 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (61.8) |  |  | (58.9) |  |
| Intangibles | (15.9) |  |  | (15.6) |  |
| Insurance liabilities | (2.4) |  |  | (1.4) |  |
| Other | (1.9) |  |  | (2.0) |  |
| Total deferred tax liabilities | (82.0) |  |  | (77.9) |  |
| Net deferred tax assets | $ | 51.8 |  |  | $ | 27.5 |  |

[0001628280-24-004446:notes:242]
As of December 31, 2023 and 2022, we had $10.8 million and $21.5 million in tax-effected foreign net operating loss carryforwards, respectively. The deferred tax asset valuation allowance relates primarily to loss carryforwards. The remainder of the valuation allowance relates to state tax credits.

[0001628280-24-004446:notes:243]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2023.

[0001628280-24-004446:notes:244]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings. An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes, but we expect any amounts to be immaterial.

[0001628280-24-004446:notes:245]
We and our subsidiaries file income tax returns with the U.S. federal government, various U.S. states, and various foreign jurisdictions throughout the world. We regularly engage in discussions and negotiations with tax authorities regarding tax matters, and we continue to defend any and all such claims presented. Our U.S. federal and state tax returns remain open to examination for 2017 through 2023. We are currently under a limited scope audit by the Internal Revenue Service for our 2021 and 2022 tax years. There are also ongoing U.S. state and local audits and other foreign audits covering fiscal years 2017 through 2023. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2016. We have no material uncertain tax provisions recorded as of December 31, 2023. We do not expect the results from any ongoing income tax audit to have a material impact on our consolidated financial condition, results of operations, or cash flows.


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-004446:notes:246]
13. Lines of Credit and Financing Arrangements:

[0001628280-24-004446:notes:247]
The following tables summarize our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-24-004446:notes:248]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Commercial paper: | $ | 150.0 |  |  | $ | — |  |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 12.1 |  |  | 11.2 |  |
| Senior unsecured notes | — |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 12.1 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 32.7 |  |  | 28.3 |  |
| Credit agreement | 20.0 |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (9.6) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,143.1 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,305.2 |  |  | $ | 1,524.8 |  |

[0001628280-24-004446:notes:249]
As of December 31, 2023, the aggregate amounts of required principal payments on total debt excluding finance lease obligations (see Note 5) were as follows (in millions):

[0001628280-24-004446:notes:250]
| 2024 | $ | 150.0 |  |
| 2025 | 300.0 |  |
| 2026 | 20.0 |  |
| 2027 | 300.0 |  |
| 2028 | 500.0 |  |
| Thereafter | — |  |

[0001628280-24-004446:notes:251]
Commercial Paper Program

[0001628280-24-004446:notes:252]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. We had outstanding CP Notes of $150.0 million as of December 31, 2023.

[0001628280-24-004446:notes:253]
Below is a summary of the weighted average interest rate for CP notes as of December 31, 2023 and 2022:

[0001628280-24-004446:notes:254]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Weighted average borrowing rate | 5.66 | % |  | — | % |

[0001628280-24-004446:notes:255]
Long-Term Debt

[0001628280-24-004446:notes:256]
Credit Agreement

[0001628280-24-004446:notes:257]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financings.

[0001628280-24-004446:notes:258]
The Credit Agreement consists of a $1,100.0 million unsecured revolving credit facility that matures in July 2026. We had outstanding borrowings of $20.0 million as well as $1.7 million committed to standby letters of credit as of December 31, 2023. Subject to covenant limitations, $928.3 million was available for future borrowings after taking into consideration outstanding borrowings under our Commercial Paper Program. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-004446:notes:259]
Below is a summary of the weighted average interest rate as of December 31, 2023 and 2022:

[0001628280-24-004446:notes:260]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Weighted average borrowing rate | 6.67 | % |  | 5.57 | % |

[0001628280-24-004446:notes:261]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and its subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of its assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-24-004446:notes:262]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-24-004446:notes:263]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-24-004446:notes:264]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-24-004446:notes:265]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-24-004446:notes:266]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-24-004446:notes:267]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our Credit Agreement.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001628280-24-004446:notes:268]
As of December 31, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-24-004446:notes:269]
Senior Unsecured Notes

[0001628280-24-004446:notes:270]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum (the 2025 Notes, the 2027 Notes, and the 2028 Notes, collectively the “Notes”).

[0001628280-24-004446:notes:271]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2023, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-004446:notes:272]
14. Comprehensive Income:

[0001628280-24-004446:notes:273]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001628280-24-004446:notes:274]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2023 |  | 2022 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Derivative contracts |  | $ | (0.4) |  |  | $ | 9.7 |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax benefit (expense) |  | 0.1 |  |  | (2.2) |  |  | Provision for income taxes |
| Net of tax |  | $ | (0.3) |  |  | $ | 7.5 |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and post-retirement benefits costs |  | $ | (5.5) |  |  | $ | (5.4) |  |  | Cost of goods sold; Selling, general, administrative expenses and other (income) expense, net |
| Pension settlements |  | (0.8) |  |  | 0.2 |  |  | Pension settlements |
| Pension adjustments upon sale of businesses |  | 1.8 |  |  | — |  |  | Gain on sale of businesses |
| Income tax benefit |  | 1.6 |  |  | 1.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | (2.9) |  |  | $ | (3.9) |  |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of businesses |  | $ | (15.8) |  |  | $ | — |  |  | Gain on sale of businesses |
| Income tax expense |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | (15.8) |  |  | $ | — |  |  |  |
| Total reclassifications from AOCL |  | $ | (19.0) |  |  | $ | 3.6 |  |  |  |

[0001628280-24-004446:notes:275]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2023 and 2022 (in millions):

[0001628280-24-004446:notes:276]
|  |  | Gains (Loss) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |
| Other comprehensive income (loss) before reclassifications |  | 2.6 |  |  | 1.1 |  |  | (0.9) |  |  | 11.9 |  |  | 14.7 |  |
| Amounts reclassified from AOCL |  | 0.3 |  |  | — |  |  | 2.9 |  |  | 15.8 |  |  | 19.0 |  |
| Net other comprehensive income |  | 2.9 |  |  | 1.1 |  |  | 2.0 |  |  | 27.7 |  |  | 33.7 |  |
| Balance as of December 31, 2023 |  | $ | (2.0) |  |  | $ | 0.6 |  |  | $ | (44.2) |  |  | $ | (11.3) |  |  | $ | (56.9) |  |

[0001628280-24-004446:notes:277]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2021 |  | $ | 10.7 |  |  | $ | (1.2) |  |  | $ | (68.8) |  |  | $ | (28.8) |  |  | $ | (88.1) |  |
| Other comprehensive (loss) income before reclassifications |  | (8.1) |  |  | 0.7 |  |  | 18.7 |  |  | (10.2) |  |  | 1.1 |  |
| Amounts reclassified from AOCL |  | (7.5) |  |  | — |  |  | 3.9 |  |  | — |  |  | (3.6) |  |
| Net other comprehensive income |  | (15.6) |  |  | 0.7 |  |  | 22.6 |  |  | (10.2) |  |  | (2.5) |  |
| Balance as of December 31, 2022 |  | $ | (4.9) |  |  | $ | (0.5) |  |  | $ | (46.2) |  |  | $ | (39.0) |  |  | $ | (90.6) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-004446:notes:278]
15. Stock-Based Compensation:

[0001628280-24-004446:notes:279]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001628280-24-004446:notes:280]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Compensation expense | $ | 30.1 |  |  | $ | 21.8 |  |  | $ | 24.3 |  |

[0001628280-24-004446:notes:281]
Incentive Plan

[0001628280-24-004446:notes:282]
Under the Lennox International Inc. 2019 Equity and Incentive Compensation Plan, we are authorized to issue awards for 1.7 million shares of common stock. The plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below. As of December 31, 2023, there were 1.6 million shares available for future issuance.

[0001628280-24-004446:notes:283]
Historically our annual equity awards were granted in December.  In 2023, we made the decision to move the annual grant for 2023 to February 2024.  Thus, there were no equity grants in 2023.

[0001628280-24-004446:notes:284]
Performance Share Units

[0001628280-24-004446:notes:285]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001628280-24-004446:notes:286]
Performance share units are classified as equity awards. Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair

[0001628280-24-004446:notes:287]
value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded. Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001628280-24-004446:notes:288]
The following table provides information on our performance share units:

[0001628280-24-004446:notes:289]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Compensation expense for performance share units (in millions) | $ | 15.2 |  |  | $ | 6.9 |  |  | $ | 10.8 |  |
| Weighted-average fair value of grants, per share | $ | — |  |  | $ | 237.68 |  |  | $ | 314.27 |  |
| Payout ratio for shares paid | 131 | % |  | 126 | % |  | 100 | % |

[0001628280-24-004446:notes:290]
A summary of the status of our undistributed performance share units as of December 31, 2023, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-24-004446:notes:291]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2022 | 124.7 |  |  | $ | 257.55 |  |
| Granted | — |  |  | $ | — |  |
| Adjustment to shares paid based on payout ratio | 17.8 |  |  | $ | 265.96 |  |
| Distributed | (30.7) |  |  | $ | 245.06 |  |
| Forfeited | (5.4) |  |  | $ | 270.84 |  |
| Undistributed performance share units as of December 31, 2023 (1) | 106.4 |  |  | $ | 261.91 |  |

[0001628280-24-004446:notes:292]
(1) Undistributed performance share units include approximately 68.8 thousand units with a weighted-average grant date fair value of $259.70 per share that had not yet vested and 37.6 thousand units that have vested but were not yet distributed.

[0001628280-24-004446:notes:293]
As of December 31, 2023, we had $9.2 million of total unrecognized compensation cost related to non-vested performance share units that are expected to be recognized over a weighted-average period of 1.7 years years. Our weighted-average estimated forfeiture rate for these performance share units was 17.9% as of December 31, 2023.

[0001628280-24-004446:notes:294]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-24-004446:notes:295]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Fair value of performance share units distributed | $ | 13.5 |  |  | $ | 6.1 |  |  | $ | 10.8 |  |
| Realized tax benefits from tax deductions | $ | 3.3 |  |  | $ | 1.5 |  |  | $ | 2.7 |  |

[0001628280-24-004446:notes:296]
Restricted Stock Units

[0001628280-24-004446:notes:297]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001628280-24-004446:notes:298]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001628280-24-004446:notes:299]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Compensation expense for restricted stock units | $ | 10.8 |  |  | $ | 11.0 |  |  | $ | 8.7 |  |
| Weighted-average fair value of grants, per share | $ | — |  |  | $ | 240.87 |  |  | $ | 315.70 |  |

[0001628280-24-004446:notes:300]
A summary of our non-vested restricted stock units as of December 31, 2023 and changes during the year then ended is presented below (in thousands, except per share data):

[0001628280-24-004446:notes:301]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2022 | 131.0 |  |  | $ | 270.86 |  |
| Granted | — |  |  | $ | — |  |
| Vested | (39.9) |  |  | $ | 275.58 |  |
| Forfeited | (8.8) |  |  | $ | 272.57 |  |
| Non-vested restricted stock units as of December 31, 2023 (1) | 82.3 |  |  | $ | 268.39 |  |

[0001628280-24-004446:notes:302]
(1) As of December 31, 2023, we had $11.4 million of total unrecognized compensation cost related to non-vested restricted stock units that are expected to be recognized over a weighted-average period of 1.7 years.  Our estimated forfeiture rate for restricted stock units was 20.3% as of December 31, 2023.

[0001628280-24-004446:notes:303]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001628280-24-004446:notes:304]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Fair value of restricted stock units vested | $ | 15.0 |  |  | $ | 9.7 |  |  | $ | 11.0 |  |
| Realized tax benefits from tax deductions | $ | 3.7 |  |  | $ | 2.4 |  |  | $ | 2.7 |  |

[0001628280-24-004446:notes:305]
Stock Appreciation Rights

[0001628280-24-004446:notes:306]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001628280-24-004446:notes:307]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001628280-24-004446:notes:308]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Compensation expense for stock appreciation rights | $ | 4.1 |  |  | $ | 3.9 |  |  | $ | 4.8 |  |
| Weighted-average fair value of grants, per share | $ | — |  |  | $ | 64.54 |  |  | $ | 70.50 |  |

[0001628280-24-004446:notes:309]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001628280-24-004446:notes:310]
The fair value of the stock appreciation rights granted in 2022 and 2021 were estimated on the date of grant using the following assumptions. In 2023 there were no stock appreciation rights granted:

[0001628280-24-004446:notes:311]
|  |  | 2022 |  | 2021 |
| Expected dividend yield |  | 2.01 | % |  | 1.69 | % |
| Risk-free interest rate |  | 3.88 | % |  | 0.88 | % |
| Expected volatility |  | 29.90 | % |  | 29.80 | % |
| Expected life (in years) |  | 4.18 |  | 4.35 |

[0001628280-24-004446:notes:312]
A summary of our stock appreciation rights as of December 31, 2023, and changes during the year then ended, is presented below (in thousands, except per share data):

[0001628280-24-004446:notes:313]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2022 | 487.9 |  |  | $ | 247.77 |  |
| Granted | — |  |  | $ | — |  |
| Exercised | (176.5) |  |  | $ | 212.53 |  |
| Forfeited | (18.9) |  |  | $ | 285.73 |  |
| Outstanding stock appreciation rights as of December 31, 2023 | 292.5 |  |  | $ | 266.57 |  |
| Exercisable stock appreciation rights as of December 31, 2023 | 214.4 |  |  | $ | 263.11 |  |

[0001628280-24-004446:notes:314]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2023 (in millions, except per share data and years; shares in thousands):

[0001628280-24-004446:notes:315]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares (1) |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $156.94 to $214.63 |  | 53.9 |  |  | 1.60 |  | $ | 12.7 |  |  | 53.9 |  |  | 1.60 |  | $ | 12.7 |  |
| $257.08 to $278.00 |  | 93.4 |  |  | 3.52 |  | $ | 16.8 |  |  | 93.4 |  |  | 3.52 |  | $ | 16.8 |  |
| $259.56 to $328.65 |  | 145.2 |  |  | 5.61 |  | $ | 23.4 |  |  | 67.1 |  |  | 5.44 |  | $ | 10.0 |  |

[0001628280-24-004446:notes:316]
(1) Share amounts are rounded but the balance accurately reflects the actual amount of exercisable stock appreciation rights as of December 31, 2023.

[0001628280-24-004446:notes:317]
As of December 31, 2023, we had $5.3 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 1.7 years. Our estimated forfeiture rate for stock appreciation rights was 13.6% as of December 31, 2023.

[0001628280-24-004446:notes:318]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001628280-24-004446:notes:319]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
| Intrinsic value of stock appreciation rights exercised | $ | 19.8 |  |  | $ | 3.5 |  |  | $ | 31.2 |  |
| Realized tax benefits from tax deductions | $ | 4.8 |  |  | $ | 0.9 |  |  | $ | 7.7 |  |

[0001628280-24-004446:notes:320]
Employee Stock Purchase Plan

[0001628280-24-004446:notes:321]
On May 24, 2022, the Company commenced a new Employee Stock Purchase Plan to succeed the prior agreement from 2012. Under the 2022 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 1.0 million shares is authorized for purchase until issuance of all shares available under the plan, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 12,200 shares under the ESPP during the year ended December 31, 2023.  Approximately 0.9 million shares remain available for purchase under the ESPP as of December 31, 2023.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-004446:notes:322]
16. Fair Value Measurements:

[0001628280-24-004446:notes:323]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities. Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001628280-24-004446:notes:324]
Level 1 -      Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-24-004446:notes:325]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-24-004446:notes:326]
Level 3 -   Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-24-004446:notes:327]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2023 and 2022, the measurement dates.

[0001628280-24-004446:notes:328]
The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2023 were the same as those used as of December 31, 2022.

[0001628280-24-004446:notes:329]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001628280-24-004446:notes:330]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001628280-24-004446:notes:331]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 9 for more information related to our derivative instruments.  Refer to Note 10 for more information related to the fair value assumptions related to our pension assets and liabilities.

[0001628280-24-004446:notes:332]
Other Fair Value Disclosures

[0001628280-24-004446:notes:333]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Credit Agreement in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001628280-24-004446:notes:334]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001628280-24-004446:notes:335]
|  | As of December 31, |
|  | 2023 |  | 2022 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 1,079.3 |  |  | $ | 878.0 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-24-004446:notes:336]
17. Divestitures:

[0001628280-24-004446:notes:337]
During the third quarter of 2023, we obtained Board of Directors' approval and signed an agreement with Glen Dimplex Group, a private Irish company, for the sale of our Hyfra operations. The sale was completed on October 31, 2023. The following table summarizes the net gain recognized in connection with this divestiture in the fourth quarter.

[0001628280-24-004446:notes:338]
| (Amounts in millions) | For the Year Ended December 31, 2023 |
| Cash received from the buyer | $ | 31.4 |  |
| Account receivable (1) | 1.8 |  |
| Net assets sold | (18.6) |  |
| AOCI reclassification adjustments, primarily foreign currency translation | (3.1) |  |
| Direct costs to sell | (4.0) |  |
| Gain on sale of business | $ | 7.5 |  |

[0001628280-24-004446:notes:339]
(1) Total gain of $7.5 million includes a $1.8 million working capital true up due to us from the buyer in connection with the disposition.

[0001628280-24-004446:notes:340]
Additionally during the third quarter of 2023, we obtained Board of Directors' approval and signed an agreement with Syntagma Capital Partners, a private Belgium company, for the sale of our European commercial HVAC and refrigeration operations. The sale was completed on December 29, 2023. In the third quarter of 2023 we recorded an impairment of $63.2 million related to the sale. The impairment consisted of a $38.3 million valuation allowance for the difference between the estimated consideration, net of our estimated costs to sell and the carrying value of the net assets, including related amounts in accumulated other comprehensive loss, $22.6 million impairment of property, plant and equipment and $2.3 million impairment of goodwill.

[0001628280-24-004446:notes:341]
Under the terms of the agreement, the consideration to be paid by the buyer consists of the following:

[0001628280-24-004446:notes:342]
•Cash paid at closing;

[0001628280-24-004446:notes:343]
•Note receivable issued by buyer at closing, which is due on the fifth anniversary of the closing date and carries interest at 7.5% per annum. The fair value of the note receivable was estimated as $9.9 million at closing, and;

[0001628280-24-004446:notes:344]
•Contingent consideration related to 2023 and 2024 financial performance of the entities disposed.  We have elected to treat this as a gain contingency under ASC 450, therefore none of the contingent consideration associated with the transaction will be recorded until final settlement of the contingent consideration.

[0001628280-24-004446:notes:345]
The following table summarizes the net gain recognized after the recording of the impairment with this divestiture.

[0001628280-24-004446:notes:346]
| (Amounts in millions) | For the Year Ended December 31, 2023 |
| Cash received from the buyer | $ | 6.7 |  |
| Fair value of note receivable | 9.9 |  |
| Net assets sold | 7.3 |  |
| AOCI reclassification adjustments, primarily foreign currency translation | (10.9) |  |
| Direct costs to sell | (10.2) |  |
| Gain on sale of businesses | $ | 2.8 |  |

[0001628280-24-004446:notes:347]
The total gain on the sale of Hyfra and our European HVAC and refrigeration divestitures of $10.3 million is net of $3.8 million of tax associated with the sale. This $3.8 million tax item is included in Income tax expense in our Statement of Operations. The total gain included in operating income is $14.1 million.  The total cash consideration received from these divestitures was $38.1 million. At the date of closing the divested entities held $14.9 million in cash, thus the net proceeds from the sale of the businesses was $23.2 million.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001628280-24-004446:notes:348]
The following table summarizes the net gain recognized in connection with this divestiture in the fourth quarter.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-004446:notes:349]
18. Acquisition:

[0001628280-24-004446:notes:350]
In October 2023, we completed the acquisition of AES, a company dedicated to service and sustainability in the light commercial market.  The total purchase price consideration, net of cash acquired, for the acquisition of AES was $94.9 million, which was primarily funded by cash and borrowings under our financing arrangements.

[0001628280-24-004446:notes:351]
The purchase price was allocated to the assets acquired and liabilities assumed based on management’s estimate of the respective fair values at the date of acquisition. Goodwill was calculated as the excess of the consideration transferred over the net assets recognized and represents the estimated future economic benefits arising from other assets acquired that could not be individually identified and separately recognized. The factors contributing to the recognition of goodwill were the assembled workforce, high-value service delivery capabilities and strategic benefits that are expected to be realized from the acquisition.

[0001628280-24-004446:notes:352]
Under the terms of the purchase agreement, a final working capital adjustment is due in the first quarter of 2024.  The preliminary allocation of the purchase price as of the acquisition date was as follows:

[0001628280-24-004446:notes:353]
| (Amounts in millions) | Amount |
| Total consideration paid | $ | 94.9 |  |
| Net tangibles assets acquired | 17.6 |  |
| Intangible assets acquired | 36.9 |  |
| Total net assets acquired | 54.5 |  |
| Goodwill as of acquisition date | $ | 40.4 |  |

[0001628280-24-004446:notes:354]
The purchase price allocation includes $36.9 million of acquired identifiable intangible assets, all of which have finite lives. The fair value of the identifiable intangible assets has been estimated using the income approach through a discounted cash flow analysis. The determination of the useful lives is based upon various industry studies, historical acquisition experience, and economic factors.

[0001628280-24-004446:notes:355]
The amounts allocated to intangible assets are as follows:

[0001628280-24-004446:notes:356]
| (Amounts in millions) | Gross Carrying Amount |  | Useful Life |  | Amortization Method |
| Customer relationships | $ | 27.9 |  |  | 10 to 15 years |  | Straight-line |
| Non-compete agreement | 5.8 |  |  | 5 years |  | Straight-line |
| Trade names | 1.8 |  |  | 5 to 10 years |  | Straight-line |
| Backlog | 1.4 |  |  | 1 to 2 years |  | Straight-line |
| Total | $ | 36.9 |  |  |  |  |  |

[0001628280-24-004446:notes:357]
Subsequent to the purchase of AES, we recognized net sales of approximately $13 million and the acquired business contributed approximately $1 million to the Building Climate Solutions segment profit from the date of acquisition through December 31, 2023.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-24-004446:notes:358]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001628280-24-004446:notes:359]
For the Years Ended December 31, 2023, 2022 and 2021

[0001628280-24-004446:notes:360]
(In millions)

[0001628280-24-004446:notes:361]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other(1) |  | Balance at end of year |
| 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 9.6 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 10.7 |  |
| 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 10.7 |  |  | $ | 6.9 |  |  | $ | (0.4) |  |  | $ | — |  |  | $ | (1.7) |  |  | $ | 15.5 |  |
| 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 15.5 |  |  | $ | 9.8 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | (10.7) |  |  | $ | 14.4 |  |
| (1) 2023 consists of the sale of our European businesses and other miscellaneous items. |
