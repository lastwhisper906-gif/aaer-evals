# LII 8-K — 0001628280-24-002634 filed 2024-01-31

## item codes, every 8-K on or before 2024-02-13

- 2024-01-31 0001628280-24-002634 — 2.02, 9.01
- 2023-12-11 0001628280-23-041239 — 5.02, 9.01 — amendment of 0001628280-23-035187
- 2023-12-08 0001628280-23-041128 — 5.02
- 2023-10-26 0001628280-23-035187 — 2.02, 5.02, 7.01, 9.01
- 2023-09-21 0001628280-23-032729 — 8.01, 9.01
- 2023-09-15 0001628280-23-032385 — 1.01, 2.03, 8.01, 9.01
- 2023-09-12 0001628280-23-032078 — 8.01, 9.01
- 2023-08-28 0001628280-23-030777 — 1.01, 2.03, 9.01
- 2023-08-25 0001628280-23-030602 — 8.01, 9.01
- 2023-07-27 0001628280-23-025808 — 2.02, 9.01
- 2023-05-19 0001628280-23-019040 — 5.07
- 2023-04-27 0001193125-23-120058 — 2.02, 9.01
- 2023-04-18 0001193125-23-104192 — 1.01, 2.03, 9.01
- 2023-01-31 0001193125-23-019706 — 2.02, 9.01
- 2022-12-12 0001193125-22-302285 — 5.02, 9.01
- 2022-12-02 0001193125-22-297138 — 5.02
- 2022-11-17 0001193125-22-287244 — 5.02, 7.01, 8.01, 9.01
- 2022-10-27 0001193125-22-270358 — 2.02, 9.01
- 2022-07-28 0001193125-22-204168 — 2.02, 9.01
- 2022-05-23 0001193125-22-157560 — 5.02, 5.07
- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2024-02-13

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-002634:8k_2_02:1]
EX-99.1
2
lii-20231231xexx991pressre.htm
EX-99.1

[0001628280-24-002634:8k_2_02:2]
Document

[0001628280-24-002634:8k_2_02:3]
Exhibit 99.1

[0001628280-24-002634:8k_2_02:4]
Lennox Reports Record Fourth Quarter and Full Year 2023 Results; Increases Long-Term Financial Targets and Provides FY 2024 Guidance

[0001628280-24-002634:8k_2_02:5]
____________________________________________________________________________

[0001628280-24-002634:8k_2_02:6]
Q4 Results Summary

[0001628280-24-002634:8k_2_02:7]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-002634:8k_2_02:8]
•       Revenue up 6% to $1.2 billion; core revenue excluding European Operations up 7% to $1.1 billion

[0001628280-24-002634:8k_2_02:9]
•       GAAP diluted EPS up 52% to $4.04; adjusted diluted EPS up 41% to $3.63

[0001628280-24-002634:8k_2_02:10]
•       Operating cash flow up 132% to $306 million

[0001628280-24-002634:8k_2_02:11]
____________________________________________________________________________

[0001628280-24-002634:8k_2_02:12]
2023 Full Year Highlights

[0001628280-24-002634:8k_2_02:13]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-002634:8k_2_02:14]
•Revenue up 6% to $5 billion; core revenue excluding European Operations up 6% to $4.7 billion

[0001628280-24-002634:8k_2_02:15]
•GAAP diluted EPS up 19% to $16.54; adjusted diluted EPS up 27% to $17.96

[0001628280-24-002634:8k_2_02:16]
•Operating cash flow up 144% to $736 million

[0001628280-24-002634:8k_2_02:17]
DALLAS, January 31, 2024 – Lennox (NYSE: LII), a leader in energy-efficient climate-control solutions, today reported record fourth quarter revenue of $1.2 billion. Operating income was $185 million for the fourth quarter. Operating margin was 16% and GAAP diluted earnings per share was $4.04.

[0001628280-24-002634:8k_2_02:18]
Core revenue, excluding European Operations, grew 7% to $1.1 billion. Adjusted segment profit rose 34% to $175 million. Adjusted segment margin was up 320 basis points to 15.9%. Adjusted earnings per share rose 41% to $3.63.

[0001628280-24-002634:8k_2_02:19]
“In 2023, relentless execution of our Lennox transformation strategy yielded significant financial successes even as we navigated challenging residential end-markets. We successfully implemented the new minimum efficiency regulatory change, improved our factory production, built supply chain resiliency, and initiated our pricing excellence programs,” said Chief Executive Officer, Alok Maskara. “As we step into 2024, we carry a positive momentum and remain committed to overcoming end market uncertainties through disciplined execution.”

[0001628280-24-002634:8k_2_02:20]
In the fourth quarter, our Home Comfort Solutions segment (formerly the Residential segment) experienced a 1% revenue growth. This growth was a result of favorable mix of higher-efficiency products and effective pricing execution, that was partially offset by volume declines. Sales volumes through the 2-step distribution channel continue to experience significant inventory destocking and were down more than 20% but direct-to-contractor sales volumes remained resilient indicating a stable consumer demand environment.

[0001628280-24-002634:8k_2_02:21]
The Building Climate Solutions segment (formerly the Commercial segment) continues to achieve outstanding performance. In the fourth quarter, revenue increased 19%, driven by both pricing and sales volume gains. Revenue growth helped restore previously depressed profit margins, as did productivity through increased factory output and strengthened supply chain resiliency. The AES acquisition integration is advancing smoothly, and customers are expressing strong interest in the full lifecycle value proposition.

[0001628280-24-002634:8k_2_02:22]
FOURTH QUARTER 2023 FINANCIAL HIGHLIGHTS

[0001628280-24-002634:8k_2_02:23]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-002634:8k_2_02:24]
Revenue: $1.2 billion; Core revenue, which excludes European operations, was $1.1 billion, up 7%.  Revenue growth was driven by price and favorable mix and partially offset by lower sales volume.

[0001628280-24-002634:8k_2_02:25]
Operating Income: $185 million, up 41%, with operating profit margin of 16.0%, up 400 bps.

[0001628280-24-002634:8k_2_02:26]
Adjusted Segment Profit: $175 million, up 34%, and adjusted segment profit margin of 15.9%, up 320 basis points. Adjusted segment profit increased $44 million as $69 million of price/mix benefits and $15 million in product costs were partially offset by lower sales volumes and inflation and investment in SG&A and distribution.

[0001628280-24-002634:8k_2_02:27]
Net Income: $145 million, or $4.04 per share, compared to $94 million, or $2.65 per share, in the prior year quarter.

[0001628280-24-002634:8k_2_02:28]
Adjusted Net Income: $130 million, or $3.63 per share, compared to $92 million, or $2.58 per share, in the prior year quarter.

[0001628280-24-002634:8k_2_02:29]
Cash: Operating cash flow was $306 million compared to $132 million in the prior-year quarter. Capital expenditures were $125 million compared to $34 million in the prior-year quarter with the increase driven by the new commercial HVAC factory investment in Saltillo, Mexico. Total debt at the end of the fourth quarter was approximately $1.3 billion. Total cash, cash equivalents and short-term investments were $69 million at the end of the quarter.

[0001628280-24-002634:8k_2_02:30]
Home Comfort Solutions: Business segment revenue was $709 million, up 1%. Segment profit was $115 million, down 4%, and segment margin was 16.2%, down 70 basis points. Segment profit decreased $4 million compared to the prior-year quarter. The decrease was attributed to a $9 million decrease in sales volumes and $25 million impact from inflation and investments in distribution and selling.  However, partially offsetting these factors were the benefits of $30 million in price/mix.

[0001628280-24-002634:8k_2_02:31]
Building Climate Solutions: Business segment revenue was $390 million, up 19%. Segment profit was $91 million, up 98%, and segment margin expanded 930 basis points to 23.2%.  Segment profit increased $45 million compared to prior-year quarter. This improvement was driven by $39 million of price/mix benefits, $3 million in higher sales volumes and $16 million in product cost tailwinds, partially offset by inflationary wage and distribution impacts.

[0001628280-24-002634:8k_2_02:32]
Corporate and Other: Late in the quarter we successfully completed the divestiture of our European operations which had revenue of $56 million and profit of $1.6 million in the quarter. Corporate expenses were $30 million, or down $3 million.

[0001628280-24-002634:8k_2_02:33]
FULL YEAR 2023 FINANCIAL HIGHLIGHTS

[0001628280-24-002634:8k_2_02:34]
(All comparisons are year-over-year, unless otherwise noted)

[0001628280-24-002634:8k_2_02:35]
Revenue: $5 billion; Core revenue, which excludes European operations, was $4.7 billion, up 6%.  Revenue growth was driven by price and favorable mix and partially offset by lower sales volume.

[0001628280-24-002634:8k_2_02:36]
Operating Income: $790 million, up 20%, with operating profit margin of 15.9%, up 195 bps. Operating income includes a one-time net charge of $49 million for the combined divestitures of the European HVAC and Refrigeration businesses.

[0001628280-24-002634:8k_2_02:37]
Adjusted Segment Profit: $850 million, up 27%, and adjusted segment profit margin of 17.9%, up 300 basis points. Adjusted segment profit increased $180 million as $348 million of price and mix benefits were partially offset by lower sales volumes and the impact of inflation and growth investments on SG&A and distribution.

[0001628280-24-002634:8k_2_02:38]
Net Income: $590 million, or $16.54 per share, compared to $497 million, or $13.88 per share, in the prior year.

[0001628280-24-002634:8k_2_02:39]
Adjusted Net Income: $641 million, or $17.96 per share, compared to $508 million, or $14.18 per share, in the prior year.

[0001628280-24-002634:8k_2_02:40]
Cash: Operating cash flow was $736 million compared to $302 million in the prior year. Capital expenditures were $250 million compared to $101 million in the prior year with the increase driven by the new commercial factory investment in Saltillo, Mexico, as well as investments required for the low GWP transition.

[0001628280-24-002634:8k_2_02:41]
Home Comfort Solutions: Business segment revenue was $3.2 billion, up 1%. Segment profit was $610 million, up 2%, and segment margin expanded 20 basis points to 18.9%. Segment profit increased $13 million compared to prior year. The increase was primarily driven by $154 million in price/mix benefits, partially offset by $71 million lower volume.  Additionally, there were headwinds of $73 million due to the impact of inflation on salary wages, distribution rent escalation and sales force investments.

[0001628280-24-002634:8k_2_02:42]
Building Climate Solutions: Business segment revenue was $1.5 billion, up 18%. Segment profit was $341 million, up 109%, and segment margin expanded 980 basis points to 22.5%.  Segment profit increased $178 million compared to prior year, driven by $194 million of price/mix benefits and $3 million generated by higher sales volumes.  Offsetting some of these gains were elevated product costs associated with materials inflation, as well as increased incentive compensation and salary wage inflation.

[0001628280-24-002634:8k_2_02:43]
Corporate and Other: Revenue from European operations was $248 million, up 6%. European operations had $7.6 million in profit compared to a $3.3 million loss in the prior year.  Corporate expenses were $102 million, or up $11 million compared to the prior year as a result of higher incentive compensation and wage inflation.

[0001628280-24-002634:8k_2_02:44]
FULL YEAR 2024 GUIDANCE

[0001628280-24-002634:8k_2_02:45]
For full year 2024, core revenue is anticipated to increase by approximately 7% mostly due to price and mix as sales volumes are forecasted to be relatively flat.

[0001628280-24-002634:8k_2_02:46]
Adjusted earnings per share is expected to be within the range of $18.50 to $20.00.

[0001628280-24-002634:8k_2_02:47]
Capital expenditures are projected to be approximately $175 million, and Free Cash Flow is estimated to fall within the range of $500 million to $600 million.

[0001628280-24-002634:8k_2_02:48]
CONFERENCE CALL INFORMATION

[0001628280-24-002634:8k_2_02:49]
A conference call to discuss the company’s fourth quarter and full year results, as well as 2024 full year guidance, will be held this morning at 8:30 a.m. Central Time. To participate in the earnings conference, please call 800-274-8461 (U.S.) or +1 203-518-9765 (international) at least 10 minutes prior to the scheduled start time and use conference ID LIIQ423. The conference call also will be webcast live on the company’s investor relations web site at investor.lennox.com. A replay of the conference call will be available until February 14, 2024, by calling toll-free 800-839-3736 (U.S.) or +1 402-220-2978 (international). The call will also be archived on the company's investor relations website at investor.lennox.com.

[0001628280-24-002634:8k_2_02:50]
ABOUT LENNOX

[0001628280-24-002634:8k_2_02:51]
Lennox (NYSE: LII) is a leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in innovation with our cooling, heating, indoor air quality, and refrigeration systems. Additional information on Lennox is available at www.lennox.com or by contacting investor@lennox.com.

[0001628280-24-002634:8k_2_02:52]
FORWARD-LOOKING STATEMENTS & NON-GAAP FINANCIAL MEASURES

[0001628280-24-002634:8k_2_02:53]
A reconciliation of non-GAAP financial measures appearing in this document to financial measures prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP) are included in the Annex to this document.

[0001628280-24-002634:8k_2_02:54]
This document includes forward-looking statements regarding core revenue, segment profit, adjusted segment profit, adjusted net income, adjusted earnings per share, free cash flow and Debt to EBITDA, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, changes in environmental liabilities, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. Core revenue, adjusted segment profit, and adjusted earnings per share exclude net sales and profit/(loss) from our European portfolio, which was sold in 4Q 2023.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking

[0001628280-24-002634:8k_2_02:55]
GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on LII’s full year GAAP financial results.

[0001628280-24-002634:8k_2_02:56]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-002634:8k_2_02:57]
Consolidated Statements of Operations

[0001628280-24-002634:8k_2_02:58]
(Unaudited)

[0001628280-24-002634:8k_2_02:59]
| (Amounts in millions, except per share data) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales | $ | 1,154.8 |  |  | $ | 1,093.8 |  |  | $ | 4,981.9 |  |  | $ | 4,718.4 |  |
| Cost of goods sold | 800.0 |  |  | 808.6 |  |  | 3,434.1 |  |  | 3,433.7 |  |
| Gross profit | 354.8 |  |  | 285.2 |  |  | 1,547.8 |  |  | 1,284.7 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 177.8 |  |  | 155.0 |  |  | 705.5 |  |  | 627.2 |  |
| Losses (gains) and other expenses, net | 3.4 |  |  | (0.6) |  |  | 8.5 |  |  | 4.9 |  |
| Restructuring charges | 2.9 |  |  | 0.3 |  |  | 3.1 |  |  | 1.5 |  |
| Impairment on assets held for sale | — |  |  | — |  |  | 63.2 |  |  | — |  |
| Gain on sale of businesses | (14.1) |  |  | — |  |  | (14.1) |  |  | — |  |
| Income from equity method investments | (0.5) |  |  | (1.3) |  |  | (8.5) |  |  | (5.1) |  |
| Operating income | 185.3 |  |  | 131.8 |  |  | 790.1 |  |  | 656.2 |  |
| Pension settlements | 0.2 |  |  | (0.4) |  |  | 0.8 |  |  | (0.2) |  |
| Interest expense, net | 11.3 |  |  | 12.7 |  |  | 51.7 |  |  | 38.7 |  |
| Other expense (income), net | 0.4 |  |  | — |  |  | 0.1 |  |  | 1.9 |  |
| Income before income taxes | 173.4 |  |  | 119.5 |  |  | 737.5 |  |  | 615.8 |  |
| Provision for income taxes | 28.9 |  |  | 25.1 |  |  | 147.4 |  |  | 118.7 |  |
| Net income | $ | 144.5 |  |  | $ | 94.4 |  |  | $ | 590.1 |  |  | $ | 497.1 |  |
| Earnings per share – Basic: | $ | 4.07 |  |  | $ | 2.66 |  |  | $ | 16.61 |  |  | $ | 13.92 |  |
| Earnings per share – Diluted: | $ | 4.04 |  |  | $ | 2.65 |  |  | $ | 16.54 |  |  | $ | 13.88 |  |
| Weighted Average Number of Shares Outstanding - Basic | 35.6 |  |  | 35.4 |  |  | 35.5 |  |  | 35.7 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 35.8 |  |  | 35.6 |  |  | 35.7 |  |  | 35.8 |  |

[0001628280-24-002634:8k_2_02:60]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |  |  |  |
| Segment Net Sales and Profit (Loss) |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |

[0001628280-24-002634:8k_2_02:61]
| (Amounts in millions) | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2023 |  | 2022(2) |  | 2023 |  | 2022(2) |
| Net Sales |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 709.4 |  |  | $ | 703.4 |  |  | $ | 3,222.9 |  |  | $ | 3,198.3 |  |
| Building Climate Solutions (2) | 390.0 |  |  | 327.2 |  |  | 1,511.4 |  |  | 1,286.4 |  |
| Corporate and other (2) | 55.4 |  |  | 63.2 |  |  | 247.6 |  |  | 233.7 |  |
|  | $ | 1,154.8 |  |  | $ | 1,093.8 |  |  | $ | 4,981.9 |  |  | $ | 4,718.4 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |
| Home Comfort Solutions | $ | 115.0 |  |  | $ | 119.2 |  |  | $ | 610.2 |  |  | $ | 596.9 |  |
| Building Climate Solutions (2) | 90.5 |  |  | 45.6 |  |  | 340.8 |  |  | 162.9 |  |
| Corporate and other (2) | (28.7) |  |  | (32.6) |  |  | (93.9) |  |  | (94.0) |  |
| Total segment profit | 176.8 |  |  | 132.2 |  |  | 857.1 |  |  | 665.8 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Gain on sale of businesses | (14.1) |  |  | — |  |  | (14.1) |  |  | — |  |
| Impairment of net assets held for sale | — |  |  | — |  |  | 63.2 |  |  | — |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) | 2.7 |  |  | $ | 0.1 |  |  | 14.8 |  |  | 8.1 |  |
| Restructuring charges | 2.9 |  |  | 0.3 |  |  | 3.1 |  |  | 1.5 |  |
| Operating income | $ | 185.3 |  |  | $ | 131.8 |  |  | $ | 790.1 |  |  | $ | 656.2 |  |

[0001628280-24-002634:8k_2_02:62]
(1)  We define segment profit (loss) as a segment's operating income (loss) included in the accompanying Consolidated Statements of Operations, excluding:

[0001628280-24-002634:8k_2_02:63]
•The following items in Losses (gains) and other expenses, net:

[0001628280-24-002634:8k_2_02:64]
◦Net change in unrealized (gains) losses on unsettled futures contracts,

[0001628280-24-002634:8k_2_02:65]
◦Environmental liabilities and special litigation charges, and;

[0001628280-24-002634:8k_2_02:66]
◦Other items, net

[0001628280-24-002634:8k_2_02:67]
•Restructuring charges,

[0001628280-24-002634:8k_2_02:68]
•Impairment on assets held for sale, and;

[0001628280-24-002634:8k_2_02:69]
•Gain on sale of businesses

[0001628280-24-002634:8k_2_02:70]
(2) Previously, we operated in three reportable business segments. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio and that we would continue to invest in our Heatcraft Worldwide Refrigeration business, all of which were previously in our Refrigeration segment.  On January 1, 2023, we adjusted our segment presentation to better align with how the segments are managed and evaluated after the change in portfolio.  Heatcraft Worldwide Refrigeration is now part of the Business Climate Solutions segment while the European portfolio is presented with Corporate and Other until disposition. Amounts presented in this table have been recast to reflect the revised segment presentation. In 4Q 2023, we successfully completed the divestiture of our European operations.

[0001628280-24-002634:8k_2_02:71]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-002634:8k_2_02:72]
Consolidated Balance Sheets

[0001628280-24-002634:8k_2_02:73]
(Unaudited)

[0001628280-24-002634:8k_2_02:74]
| (Amounts in millions, except shares and par values) | As of December 31, 2023 |  | As of December 31, 2022 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 60.7 |  |  | $ | 52.6 |  |
| Short-term investments | 8.4 |  |  | 8.5 |  |
| Accounts and notes receivable, net of allowances of $14.4 and $15.5 in 2023 and 2022, respectively | 594.6 |  |  | 608.5 |  |
| Inventories, net | 699.1 |  |  | 753.0 |  |
| Other assets | 70.7 |  |  | 73.9 |  |
| Total current assets | 1,433.5 |  |  | 1,496.5 |  |
| Property, plant and equipment, net of accumulated depreciation of $910.8 and $920.8 in 2023 and 2022, respectively | 720.4 |  |  | 548.9 |  |
| Right-of-use assets from operating leases | 213.6 |  |  | 219.9 |  |
| Goodwill | 222.1 |  |  | 186.3 |  |
| Deferred income taxes | 51.8 |  |  | 27.5 |  |
| Other assets, net | 156.9 |  |  | 88.5 |  |
| Total assets | $ | 2,798.3 |  |  | $ | 2,567.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current Liabilities: |  |  |  |
| Commercial paper | $ | 150.0 |  |  | $ | — |  |
| Current maturities of long-term debt | 12.1 |  |  | 710.6 |  |
| Current operating lease liabilities | 57.5 |  |  | 63.3 |  |
| Accounts payable | 374.7 |  |  | 427.3 |  |
| Accrued expenses | 416.1 |  |  | 376.9 |  |
| Income taxes payable | 4.2 |  |  | 17.6 |  |
| Total current liabilities | 1,014.6 |  |  | 1,595.7 |  |
| Long-term debt | 1,143.1 |  |  | 814.2 |  |
| Long-term operating lease liabilities | 164.6 |  |  | 161.8 |  |
| Pensions | 22.5 |  |  | 40.1 |  |
| Other liabilities | 168.2 |  |  | 158.9 |  |
| Total liabilities | 2,513.0 |  |  | 2,770.7 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' equity (deficit): |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,184.6 |  |  | 1,155.2 |  |
| Retained earnings | 3,506.2 |  |  | 3,070.6 |  |
| Accumulated other comprehensive loss | (56.9) |  |  | (90.6) |  |
| Treasury stock, at cost, 51,588,103 shares and 51,700,260 shares for 2023 and 2022, respectively | (4,349.5) |  |  | (4,339.2) |  |
| Total stockholders' equity (deficit) | 285.3 |  |  | (203.1) |  |
| Total liabilities and stockholders' equity (deficit) | $ | 2,798.3 |  |  | $ | 2,567.6 |  |

[0001628280-24-002634:8k_2_02:75]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001628280-24-002634:8k_2_02:76]
Consolidated Statements of Cash Flows

[0001628280-24-002634:8k_2_02:77]
(Unaudited)

[0001628280-24-002634:8k_2_02:78]
| (Amounts in millions) | For the Years Ended December 31, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 590.1 |  |  | $ | 497.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Gain on sale of businesses | (14.1) |  |  | — |  |
| Impairment on net assets held for sale | 63.2 |  |  | — |  |
| Income from equity method investments | (8.5) |  |  | (5.1) |  |
| Dividends from affiliates | 0.5 |  |  | 1.7 |  |
| Restructuring charges, net of cash paid | 2.6 |  |  | 1.0 |  |
| Provision for credit losses | 9.8 |  |  | 6.9 |  |
| Unrealized losses, net on derivative contracts | 6.0 |  |  | 1.7 |  |
| Stock-based compensation expense | 30.1 |  |  | 21.8 |  |
| Depreciation and amortization | 86.0 |  |  | 77.9 |  |
| Deferred income taxes | (26.0) |  |  | (15.2) |  |
| Pension expense | 3.2 |  |  | 6.0 |  |
| Pension contributions | (15.0) |  |  | (22.5) |  |
| Other items, net | (0.5) |  |  | (1.1) |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |
| Accounts and notes receivable | (32.7) |  |  | (112.4) |  |
| Inventories | 11.1 |  |  | (249.3) |  |
| Other current assets | 7.1 |  |  | (7.3) |  |
| Accounts payable | (29.2) |  |  | 28.2 |  |
| Accrued expenses | 65.0 |  |  | 13.7 |  |
| Income taxes payable and receivable, net | (24.1) |  |  | 56.4 |  |
| Leases, net | 3.1 |  |  | 1.7 |  |
| Other, net | 8.5 |  |  | 1.1 |  |
| Net cash provided by operating activities | 736.2 |  |  | 302.3 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 2.1 |  |  | 1.6 |  |
| Purchases of property, plant and equipment | (250.2) |  |  | (101.1) |  |
| Acquisition of business | (94.9) |  |  | — |  |
| Net proceeds from sale of businesses | 23.2 |  |  | — |  |
| Proceeds from (purchases of) short-term investments | 0.1 |  |  | (3.5) |  |
| Net cash used in investing activities | (319.7) |  |  | (103.0) |  |
| Cash flows from financing activities: |  |  |  |
| Commercial paper borrowings | 150.0 |  |  | — |  |
| Asset securitization borrowings | 190.0 |  |  | 407.0 |  |
| Asset securitization payments | (540.0) |  |  | (307.0) |  |
| Long-term debt payments | (364.4) |  |  | (12.9) |  |
| Issuance of senior unsecured notes | 500.0 |  |  | — |  |
| Borrowings from credit facility | 1,721.0 |  |  | 2,537.5 |  |
| Payments on credit facility | (1,893.0) |  |  | (2,352.0) |  |
| Payments of deferred financing costs | (5.4) |  |  | — |  |
| Proceeds from employee stock purchases | 3.9 |  |  | 3.6 |  |
| Repurchases of common stock | — |  |  | (300.0) |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (14.9) |  |  | (8.3) |  |
| Cash dividends paid | (153.4) |  |  | (142.0) |  |
| Net cash used in financing activities | (406.2) |  |  | (174.1) |  |
| Increase in cash and cash equivalents | 10.3 |  |  | 25.2 |  |
| Effect of exchange rates on cash and cash equivalents | (2.2) |  |  | (3.6) |  |
| Cash and cash equivalents, beginning of period | 52.6 |  |  | 31.0 |  |
| Cash and cash equivalents, end of period | $ | 60.7 |  |  | $ | 52.6 |  |
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 50.2 |  |  | $ | 35.4 |  |
| Income taxes paid (net of refunds) | $ | 197.8 |  |  | $ | 77.2 |  |

[0001628280-24-002634:8k_2_02:79]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |  |  |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |  |  |
| (Unaudited, in millions, except per share and ratio data) |  |  |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit (loss) presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results and enhance the ability of investors to analyze the Company's business trends and operating performance. In November 2022, we announced the decision to explore strategic alternatives for our European portfolio. The results from operations for these businesses have been shown in the tables below as "Non-Core business results." The prior period results have been updated to provide period-over-period comparability. |  |  |
| Reconciliation of Net income, a GAAP measure, to Adjusted net income, a Non-GAAP measure |  |  |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |  |  |
|  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  | Amount after tax | Per Diluted Share |  |  |  |  |  |  |
| Net income, a GAAP measure | $ | 144.5 |  | $ | 4.04 |  |  | $ | 94.4 |  | $ | 2.65 |  |  | $ | 590.1 |  | $ | 16.54 |  |  | $ | 497.1 |  | $ | 13.88 |  |  |  |  |  |  |  |
| Restructuring charges | 2.2 |  | 0.06 |  |  | 0.2 |  | 0.01 |  |  | 2.4 |  | 0.07 |  |  | 1.2 |  | 0.03 |  |  |  |  |  |  |  |
| Pension settlements | — |  | — |  |  | (0.3) |  | (0.01) |  |  | 0.3 |  | 0.01 |  |  | (0.1) |  | — |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) | 1.5 |  | 0.05 |  |  | — |  | — |  |  | 11.1 |  | 0.31 |  |  | 6.6 |  | 0.19 |  |  |  |  |  |  |  |
| Excess tax benefit from share-based compensation (b) | (2.8) |  | (0.08) |  |  | (0.9) |  | (0.03) |  |  | (5.2) |  | (0.15) |  |  | (0.6) |  | (0.02) |  |  |  |  |  |  |  |
| Other tax items, net (b) | (4.1) |  | (0.11) |  |  | 0.2 |  | 0.01 |  |  | (3.7) |  | (0.10) |  |  | (0.5) |  | (0.01) |  |  |  |  |  |  |  |
| Impairment on assets held for sale | — |  | — |  |  | — |  | — |  |  | 62.0 |  | 1.74 |  |  | — |  | — |  |  |  |  |  |  |  |
| Gain on sale of businesses | (11.1) |  | (0.31) |  |  | — |  | — |  |  | (11.1) |  | (0.31) |  |  | — |  | — |  |  |  |  |  |  |  |
| Non-core business results (c) | (0.6) |  | (0.02) |  |  | (1.9) |  | (0.05) |  |  | (5.4) |  | (0.15) |  |  | 4.3 |  | 0.11 |  |  |  |  |  |  |  |
| Adjusted net income, a non-GAAP measure | $ | 129.6 |  | $ | 3.63 |  |  | $ | 91.7 |  | $ | 2.58 |  |  | $ | 640.5 |  | $ | 17.96 |  |  | $ | 508.0 |  | $ | 14.18 |  |  |  |  |  |  |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (b) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (c) Non-core business results represent activity related to our business operations in Europe not included elsewhere in the reconciliations |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-24-002634:8k_2_02:80]
| Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net cash provided by operating activities | $ | 306.3 |  |  | $ | 132.2 |  |  | $ | 736.2 |  |  | $ | 302.3 |  |
| Purchases of property, plant and equipment | (125.2) |  |  | (34.1) |  |  | (250.2) |  |  | (101.1) |  |
| Proceeds from the disposal of property, plant and equipment | 0.5 |  |  | 0.4 |  |  | 2.1 |  |  | 1.6 |  |
| Free cash flow, a Non-GAAP measure | $ | 181.6 |  |  | $ | 98.5 |  |  | $ | 488.1 |  |  | $ | 202.8 |  |

[0001628280-24-002634:8k_2_02:81]
| Reconciliation of Net sales, a GAAP measure to Core net sales, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 55.4 |  |  | $ | 63.2 |  |  | $ | 1,154.8 |  |  | $ | 1,093.8 |  |
| Net sales from non-core businesses (a) | (55.4) |  |  | (63.2) |  |  | (55.4) |  |  | (63.2) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 1,099.4 |  |  | $ | 1,030.6 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Years Ended December 31, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales, a GAAP measure | $ | 247.6 |  |  | $ | 233.7 |  |  | $ | 4,981.9 |  |  | $ | 4,718.4 |  |
| Net sales from non-core businesses (a) | (247.6) |  |  | (233.7) |  |  | (247.6) |  |  | (233.7) |  |
| Core net sales, a Non-GAAP measure | $ | — |  |  | $ | — |  |  | $ | 4,734.3 |  |  | $ | 4,484.7 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
| Reconciliation of Segment profit (loss), a Non-GAAP measure to Adjusted Segment profit (loss), a Non-GAAP measure |
|  | For the Three Months Ended December 31, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (28.7) |  |  | $ | (32.6) |  |  | $ | 176.8 |  |  | $ | 132.2 |  |
| Profit from non-core businesses (a) | 1.6 |  |  | 1.1 |  |  | 1.6 |  |  | 1.1 |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (30.3) |  |  | $ | (33.7) |  |  | $ | 175.2 |  |  | $ | 131.1 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
|  | For the Years Ended December 31, |
|  | Corporate and other |  | Consolidated |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss), a Non-GAAP measure | $ | (93.9) |  |  | $ | (94.0) |  |  | $ | 857.1 |  |  | $ | 665.8 |  |
| Profit (loss) from non-core businesses (a) | 7.6 |  |  | (3.3) |  |  | 7.6 |  |  | (3.3) |  |
| Adjusted Segment profit (loss), a Non-GAAP measure | $ | (101.5) |  |  | $ | (90.7) |  |  | $ | 849.5 |  |  | $ | 669.1 |  |
| (a) Non-Core businesses represent our business operations in Europe |  |  |  |  |
