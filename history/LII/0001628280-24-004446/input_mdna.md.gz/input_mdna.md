# LII MD&A — 0001628280-24-004446


## mdna

[0001628280-24-004446:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-24-004446:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the Consolidated Financial Statements and related Notes to the Consolidated Financial Statements in Item 8, “Other Financial Statement Details,” of this Annual Report on Form 10-K.

[0001628280-24-004446:mdna:3]
18

[0001628280-24-004446:mdna:4]
Forward-Looking Statements

[0001628280-24-004446:mdna:5]
The following are some of the factors that could cause actual results to differ materially from those expressed or implied in forward-looking statements:

[0001628280-24-004446:mdna:6]
•competition in the HVACR business;

[0001628280-24-004446:mdna:7]
•our ability to successfully develop and market new products or execute our business strategy, including the implementation of price increases for products and services;

[0001628280-24-004446:mdna:8]
•our ability to meet and anticipate customer demands;

[0001628280-24-004446:mdna:9]
•our ability to continue to license or enforce our intellectual property rights;

[0001628280-24-004446:mdna:10]
•our ability to attract, motivate, develop and retain our employees, as well as labor relations problems;

[0001628280-24-004446:mdna:11]
•a decline in new construction activity and related demand for our products and services;

[0001628280-24-004446:mdna:12]
•the impact of weather on our business;

[0001628280-24-004446:mdna:13]
•the impact of higher raw material prices and significant supply interruptions;

[0001628280-24-004446:mdna:14]
•changes in environmental and climate-related legislation or government regulations or policies;

[0001628280-24-004446:mdna:15]
•changes in tax legislation;

[0001628280-24-004446:mdna:16]
•the impact of new or increased trade tariffs;

[0001628280-24-004446:mdna:17]
•warranty, intellectual property infringement, product liability and other claims;

[0001628280-24-004446:mdna:18]
•litigation risks;

[0001628280-24-004446:mdna:19]
•general economic conditions in the United States and abroad;

[0001628280-24-004446:mdna:20]
•extraordinary events beyond our controls, such as conflicts, wars, natural disasters, public health crises, or terrorist acts;

[0001628280-24-004446:mdna:21]
•foreign currency fluctuations and changes in local government regulation associated with our international operations;

[0001628280-24-004446:mdna:22]
•cyber attacks and other disruptions or misuse of information systems;

[0001628280-24-004446:mdna:23]
•our ability to successfully realize, complete and integrate acquisitions; and

[0001628280-24-004446:mdna:24]
•impairment of the value of our goodwill.

[0001628280-24-004446:mdna:25]
Business Overview

[0001628280-24-004446:mdna:26]
We operate in two reportable business segments of the HVACR industry, Home Comfort Solutions and Building Climate Solutions.  In addition to the two major business segments, Corporate and Other is also reported as a segment.  For more detailed information regarding our reportable segments, see Note 3 in the Notes to the Consolidated Financial Statements.

[0001628280-24-004446:mdna:27]
In fourth quarter 2023, we completed the sale of our European businesses.  The European businesses are presented with the Corporate and Other business segment.

[0001628280-24-004446:mdna:28]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and can be significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and

[0001628280-24-004446:mdna:29]
consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001628280-24-004446:mdna:30]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, aluminum and copper.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of certain commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001628280-24-004446:mdna:31]
Financial Highlights

[0001628280-24-004446:mdna:32]
•Net sales increased $264 million, or 6%, to $4,982 million in 2023 from $4,718 million in 2022.

[0001628280-24-004446:mdna:33]
•Operating income in 2023 was $790 million compared to $656 million in 2022.

[0001628280-24-004446:mdna:34]
•Net income in 2023 increased to $590 million from $497 million in 2022.

[0001628280-24-004446:mdna:35]
•Diluted earnings per share was $16.54 per share in 2023 compared to $13.88 per share in 2022.

[0001628280-24-004446:mdna:36]
•We generated $736 million of cash flow from operating activities in 2023 compared to $302 million in 2022.

[0001628280-24-004446:mdna:37]
•We returned $153 million to shareholders through dividend payments in 2023.

[0001628280-24-004446:mdna:38]
•We received $23 million in net proceeds from the sale of our European businesses in 2023.

[0001628280-24-004446:mdna:39]
•We purchased AES, a company dedicated to service and sustainability in the light commercial market, for $95 million in 2023.

[0001628280-24-004446:mdna:40]
Overview of Results

[0001628280-24-004446:mdna:41]
The Home Comfort Solutions segment experienced a 1% increase in net sales and a $13 million increase in segment profit in 2023 compared to 2022 as favorable price and mix were partially offset by lower sales volumes.  Our Building Climate Solutions segment saw an increase in net sales of 18% and a $178 million increase in segment profit in 2023 compared to 2022, primarily due to favorable price and mix.

[0001628280-24-004446:mdna:42]
Results of Operations

[0001628280-24-004446:mdna:43]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001628280-24-004446:mdna:44]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |  | 2021 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 4,981.9 |  |  | 100.0 | % |  | $ | 4,718.4 |  |  | 100.0 | % |  | $ | 4,194.1 |  |  | 100.0 | % |
| Cost of goods sold | 3,434.1 |  |  | 68.9 | % |  | 3,433.7 |  |  | 72.8 | % |  | 3,005.7 |  |  | 71.7 | % |
| Gross profit | 1,547.8 |  |  | 31.1 | % |  | 1,284.7 |  |  | 27.2 | % |  | 1,188.4 |  |  | 28.3 | % |
| Selling, general and administrative expenses | 705.5 |  |  | 14.2 | % |  | 627.2 |  |  | 13.3 | % |  | 598.9 |  |  | 14.3 | % |
| Losses (gains) and other expenses, net | 8.5 |  |  | 0.2 | % |  | 4.9 |  |  | 0.1 | % |  | 9.2 |  |  | 0.2 | % |
| Restructuring charges | 3.1 |  |  | 0.1 | % |  | 1.5 |  |  | — | % |  | 1.8 |  | — | % |
| Impairment on assets held for sale | 63.2 |  |  | 1.3 | % |  | — |  |  | — | % |  | — |  |  | — | % |
| Gain on sale of businesses | (14.1) |  |  | (0.3) | % |  | — |  |  | — | % |  | — |  |  | — | % |
| Income from equity method investments | (8.5) |  |  | (0.2) | % |  | (5.1) |  |  | (0.1) | % |  | (11.8) |  |  | (0.3) | % |
| Operating income | $ | 790.1 |  |  | 15.9 | % |  | $ | 656.2 |  |  | 13.9 | % |  | $ | 590.3 |  |  | 14.1 | % |
| Net income | $ | 590.1 |  |  | 11.8 | % |  | $ | 497.1 |  |  | 10.5 | % |  | $ | 464.0 |  |  | 11.1 | % |

[0001628280-24-004446:mdna:45]
Year Ended December 31, 2023 Compared to Year Ended December 31, 2022 - Consolidated Results

[0001628280-24-004446:mdna:46]
Net Sales

[0001628280-24-004446:mdna:47]
Net sales increased 6% in 2023 compared to 2022 as favorable mix of 5% and favorable price of 5% were partially offset by unfavorable sales volume of 4%.

[0001628280-24-004446:mdna:48]
Gross Profit

[0001628280-24-004446:mdna:49]
Gross profit margins for 2023 increased 390 basis points (“bps”) to 31.1% compared to 27.2% in 2022.  Gross profit margin increased 340 bps from favorable price, 100 bps from favorable mix, 90 bps from lower commodity costs and 10 bps from miscellaneous other items.  Partially offsetting these margin increases were 70 bps from higher distribution costs, 50 bps from higher other product costs including LIFO and 30 bps from higher component costs.

[0001628280-24-004446:mdna:50]
Selling, General and Administrative Expenses

[0001628280-24-004446:mdna:51]
SG&A expenses increased by $78 million in 2023 compared to 2022.  As a percentage of net sales, SG&A expenses increased 90 bps from 13.3% to 14.2% in the same periods primarily due to higher discretionary expenditures.

[0001628280-24-004446:mdna:52]
Losses (Gains) and Other Expenses, Net

[0001628280-24-004446:mdna:53]
Losses (gains) and other expenses, net for 2023 and 2022 included the following (in millions):

[0001628280-24-004446:mdna:54]
|  | For the Years Ended December 31, |
|  | 2023 |  | 2022 |
| Realized losses (gains) on settled future contracts | $ | 0.1 |  |  | $ | 0.1 |  |
| Foreign currency exchange gains | (4.3) |  |  | (1.3) |  |
| Gain on disposal of fixed assets | (0.5) |  |  | (1.0) |  |
| Other operating income | (1.6) |  |  | (1.0) |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.1) |  |  | 0.4 |  |
| Environmental liabilities and special litigation charges | 15.6 |  |  | 7.5 |  |
| Charges incurred related to COVID-19 pandemic | — |  |  | 0.8 |  |
| Other items, net | (0.7) |  |  | (0.6) |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 8.5 |  |  | $ | 4.9 |  |

[0001628280-24-004446:mdna:55]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange gains increased in 2023 primarily due to changes in foreign exchange rates in our primary markets.  Environmental liabilities and special legal contingency charges in 2023 relate to estimated remediation costs at some of our facilities and outstanding legal settlements including asbestos.  Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001628280-24-004446:mdna:56]
Restructuring Charges

[0001628280-24-004446:mdna:57]
Restructuring charges were $3.1 million in 2023 compared to $1.5 million in 2022. Charges in 2023 were related to the reorganization or removal of duplicative headcount and infrastructure.   For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-24-004446:mdna:58]
Goodwill

[0001628280-24-004446:mdna:59]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2023.  Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill. In 2023, we recorded a $2.3 million impairment of goodwill related to our agreement to sell our European commercial HVAC and refrigeration businesses.

[0001628280-24-004446:mdna:60]
Asset Impairments

[0001628280-24-004446:mdna:61]
In the third quarter of 2023, we recorded a $22.6 million impairment of property, plant and equipment related to our agreement to sell our European commercial HVAC and refrigeration businesses.

[0001628280-24-004446:mdna:62]
Pension Settlement

[0001628280-24-004446:mdna:63]
We did not have significant pension buyout activity in 2023 and 2022.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-24-004446:mdna:64]
Income from Equity Method Investments

[0001628280-24-004446:mdna:65]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $8 million in 2023 compared to $5 million in 2022.  The increase is due to better operating results at the investees.

[0001628280-24-004446:mdna:66]
Interest Expense, net

[0001628280-24-004446:mdna:67]
Net interest expense of $52 million in 2023 increased from $39 million in 2022 primarily due to higher borrowing costs.

[0001628280-24-004446:mdna:68]
Income Taxes

[0001628280-24-004446:mdna:69]
The income tax provision was $147 million in 2023 compared to $119 million in 2022, and the effective tax rate was 20.0% in 2023 compared to 19.3% in 2022.  The 2023 and 2022 effective tax rates differ from the statutory rate of 21% primarily due to foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-24-004446:mdna:70]
Year Ended December 31, 2023 Compared to Year Ended December 31, 2022 - Results by Segment

[0001628280-24-004446:mdna:71]
Home Comfort Solutions

[0001628280-24-004446:mdna:72]
The following table presents our Home Comfort Solutions segment’s net sales and profit for 2023 and 2022 (dollars in millions):

[0001628280-24-004446:mdna:73]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 3,222.9 |  |  | $ | 3,198.3 |  |  | $ | 24.6 |  |  | 1% |
| Profit | $ | 610.2 |  |  | $ | 596.9 |  |  | $ | 13.3 |  |  | 2% |
| % of net sales | 18.9 | % |  | 18.7 | % |  |  |  |  |

[0001628280-24-004446:mdna:74]
Net sales increased 1% in 2023 compared to 2022 as a 6% increase in product mix and a 2% increase in price were partially offset by a 7% decrease in sales volume.

[0001628280-24-004446:mdna:75]
Segment profit in 2023 increased $13 million compared to 2022 primarily due to $82 million from favorable mix, $72 million from higher price, $35 million from lower commodity costs, $5 million from favorable freight, $5 million from lower other product costs including LIFO and $7 million from miscellaneous other items.  Partially offsetting these increases were $71 million from lower sales volume, $51 million from higher SG&A costs due primarily to higher discretionary spend and inflationary pressures, $30 million from higher factory inefficiencies, $31 million from higher distributions costs and $10 million from higher component costs.

[0001628280-24-004446:mdna:76]
Building Climate Solutions

[0001628280-24-004446:mdna:77]
The following table presents our Building Climate Solutions segment’s net sales and profit for 2023 and 2022 (dollars in millions):

[0001628280-24-004446:mdna:78]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 1,511.4 |  |  | $ | 1,286.3 |  |  | $ | 225.1 |  |  | 18 | % |
| Profit | $ | 340.8 |  |  | $ | 162.9 |  |  | $ | 177.9 |  |  | 109 | % |
| % of net sales | 22.5 | % |  | 12.7 | % |  |  |  |  |

[0001628280-24-004446:mdna:79]
Net sales increased 18% in 2023 compared to 2022 primarily due to an 11% increase in price, a 4% increase in product mix, a 2% increase in sales volume and 1% from our acquisition of AES.

[0001628280-24-004446:mdna:80]
Segment profit in 2023 increased $178 million compared to 2022 primarily due to $147 million from favorable price, $47 million from favorable product mix and $9 million from lower commodity costs.  Partially offsetting these increases were $15 million from higher SG&A costs, $7 million from higher product warranty costs and $3 million from miscellaneous other items.

[0001628280-24-004446:mdna:81]
Corporate and Other

[0001628280-24-004446:mdna:82]
The following table presents our Corporate and Other segment’s net sales and loss for 2023 and 2022 (dollars in millions):

[0001628280-24-004446:mdna:83]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | Difference |  | % Change |
| Net sales | $ | 247.6 |  | $ | 233.7 |  |  | $ | 13.9 |  |  | 6 | % |
| Loss | $ | (93.9) |  |  | $ | (94.0) |  |  | $ | 0.1 |  |  | — | % |
| % of net sales | (37.9) | % |  | (40.2) | % |  |  |  |  |

[0001628280-24-004446:mdna:84]
Net sales increased 6% in 2023 as compared to 2022 due to revenue growth in our European businesses.

[0001628280-24-004446:mdna:85]
Segment loss was unchanged in 2023 compared to 2022 as unfavorable SG&A costs of $7 million and unfavorable foreign currency of $4 million were offset by $11 million of higher segment profit from our European businesses due primarily from favorable price.

[0001628280-24-004446:mdna:86]
Year Ended December 31, 2022 Compared to Year Ended December 31, 2021 - Consolidated Results

[0001628280-24-004446:mdna:87]
Net Sales

[0001628280-24-004446:mdna:88]
Net sales increased 13% in 2022 compared to 2021 as favorable price of 10%, favorable product mix of 2% and 2% from higher sales volume were partially offset by 1% from unfavorable foreign currency.

[0001628280-24-004446:mdna:89]
Gross Profit

[0001628280-24-004446:mdna:90]
Gross profit margins for 2022 declined 110 bps to 27.2% compared to 28.3% in 2021. Gross profit margin decreased 240 bps from higher commodity costs, 170 bps from higher component costs, 140 bps from higher other product costs including LIFO, 90 bps from higher factory inefficiencies, 80 bps from higher freight and distribution costs and 60 bps from unfavorable product mix. Partially offsetting these margin decreases were 650 bps from favorable price and 20 bps from lower product warranty costs.

[0001628280-24-004446:mdna:91]
Selling, General and Administrative Expenses

[0001628280-24-004446:mdna:92]
SG&A expenses increased by $28 million in 2022 compared to 2021. As a percentage of net sales, SG&A expenses decreased 100 bps from 14.3% to 13.3% in the same periods primarily due to lower discretionary expenditures.

[0001628280-24-004446:mdna:93]
Losses (Gains) and Other Expenses, Net

[0001628280-24-004446:mdna:94]
Losses (gains) and other expenses, net for 2022 and 2021 included the following (in millions):

[0001628280-24-004446:mdna:95]
|  | For the Years Ended December 31, |
|  | 2022 |  | 2021 |
| Realized losses (gains) on settled futures contracts | $ | 0.1 |  |  | $ | (1.2) |  |
| Foreign currency exchange gains | (1.3) |  |  | (2.2) |  |
| Gain on disposal of fixed assets | (1.0) |  |  | (0.2) |  |
| Other operating income | (1.0) |  |  | (1.5) |  |
| Net change in unrealized losses on unsettled futures contracts | 0.4 |  |  | — |  |
| Environmental liabilities and special litigation charges | 7.5 |  |  | 9.6 |  |
| Charges incurred related to COVID-19 pandemic | 0.8 |  |  | 2.2 |  |
| Other items, net | (0.6) |  |  | 2.5 |  |
| Losses (gains) and other expenses, net | $ | 4.9 |  |  | $ | 9.2 |  |

[0001628280-24-004446:mdna:96]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices. For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements. Foreign currency exchange gains decreased in 2022 primarily due to changes in foreign exchange rates in our primary markets. Environmental liabilities and special legal contingency charges in 2022 relate to estimated remediation costs at some of our facilities and outstanding legal settlements including asbestos. Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities. The charges incurred related to the COVID-19 pandemic related primarily to facility cleaning costs and sanitization supplies to support the health and safety of our employees.

[0001628280-24-004446:mdna:97]
Restructuring Charges

[0001628280-24-004446:mdna:98]
Restructuring charges were $1.5 million in 2022 compared to $1.8 million in 2021. Charges in 2022 were related to ongoing cost reduction actions taken in prior years. For more information on our restructuring activities, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001628280-24-004446:mdna:99]
Goodwill

[0001628280-24-004446:mdna:100]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2022.  We did not record any goodwill impairments in 2022 or 2021.  Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001628280-24-004446:mdna:101]
Asset Impairments

[0001628280-24-004446:mdna:102]
We did not have any impairments of assets in 2022 or 2021.

[0001628280-24-004446:mdna:103]
Pension Settlement

[0001628280-24-004446:mdna:104]
We did not have significant pension buyout activity in 2022 and 2021.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001628280-24-004446:mdna:105]
Income from Equity Method Investments

[0001628280-24-004446:mdna:106]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting. Income from equity method investments was $5 million in 2022 compared to $12 million in 2021. The decrease was due to lower operating results at the investees due to higher material costs.

[0001628280-24-004446:mdna:107]
Interest Expense, net

[0001628280-24-004446:mdna:108]
Net interest expense of $39 million in 2022 increased from $25 million in 2021 primarily due to higher borrowing costs.

[0001628280-24-004446:mdna:109]
Income Taxes

[0001628280-24-004446:mdna:110]
The income tax provision was $119 million in 2022 compared to $96 million in 2021, and the effective tax rate was 19.3% in 2022 compared to 17.2% in 2021. The 2022 and 2021 effective tax rates differ from the statutory rate of 21% primarily due to foreign taxes. Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on income taxes.

[0001628280-24-004446:mdna:111]
Year Ended December 31, 2022 Compared to Year Ended December 31, 2021 - Results by Segment

[0001628280-24-004446:mdna:112]
Home Comfort Solutions

[0001628280-24-004446:mdna:113]
The following table presents our Home Comfort Solutions segment’s net sales and profit for 2022 and 2021 (dollars in millions):

[0001628280-24-004446:mdna:114]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 3,198.3 |  | $ | 2,775.6 |  | $ | 422.7 |  |  | 15% |
| Profit | $ | 596.9 |  | $ | 540.3 |  | $ | 56.6 |  |  | 10% |
| % of net sales | 18.7 | % |  | 19.5 | % |  |  |  |  |

[0001628280-24-004446:mdna:115]
Net sales increased 15% in 2022 compared to 2021 due to an increase in price of 11%, an increase in sales volume of 4%, and 1% from favorable product mix.  Partially offsetting these increases was 1% from unfavorable foreign currency.

[0001628280-24-004446:mdna:116]
Segment profit in 2022 increased $57 million compared to 2021 due to $297 million from higher price, $33 million from higher sales volume, and $9 million from lower product warranty costs. Partially offsetting these increases were $85 million from higher commodity costs, $49 million from higher component costs, $47 million higher other product costs including LIFO, unfavorable product mix of $34 million, $33 million from higher freight and distribution charges, $20 million from higher SG&A costs, $7 million from factory inefficiencies, $5 million from unfavorable foreign currency, and $2 million from miscellaneous other items.

[0001628280-24-004446:mdna:117]
Building Climate Solutions

[0001628280-24-004446:mdna:118]
The following table presents our Building Climate Solutions segment’s net sales and profit for 2022 and 2021 (dollars in millions):

[0001628280-24-004446:mdna:119]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 1,286.4 |  | $ | 1,188.8 |  | $ | 97.6 |  |  | 8% |
| Profit | $ | 162.9 |  | $ | 164.6 |  | $ | (1.7) |  |  | (1)% |
| % of net sales | 12.7 | % |  | 13.8 | % |  |  |  |  |

[0001628280-24-004446:mdna:120]
Net sales increased 8% in 2022 compared to 2021 due to an increase in product mix of 9% and an increase in price of 5%.  Partially offsetting these increases was lower sales volume of 6%.

[0001628280-24-004446:mdna:121]
Segment profit in 2022 decreased $2 million compared to 2021 due to $30 million from higher factory inefficiencies, $29 million in higher component costs, $23 million in higher commodity costs, $22 million in lower sales volume, $21 million from higher other product costs including LIFO, $16 million in higher SG&A costs, $4 million from higher freight and distribution costs and $2 million from miscellaneous other items.  Partially offsetting these decreases was an increase in price of $107 million, $36 million increase in product mix, $1 million in lower product warranty costs and $1 million in favorable foreign currency translation.

[0001628280-24-004446:mdna:122]
Corporate and Other

[0001628280-24-004446:mdna:123]
The following table presents our Corporate and Other segment’s net sales and loss for 2022 and 2021 (dollars in millions):

[0001628280-24-004446:mdna:124]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 233.7 |  |  | $ | 229.7 |  |  | $ | 4.0 |  |  | 2 | % |
| Loss | $ | (94.0) |  |  | $ | (101.0) |  |  | $ | 7.0 |  |  | (7) | % |
| % of net sales | (40.2) | % |  | (44.0) | % |  |  |  |  |

[0001628280-24-004446:mdna:125]
Net sales increased 2% in 2022 compared to 2021 due to our European businesses.

[0001628280-24-004446:mdna:126]
Segment loss decreased by $7 million in 2022 compared to 2021 due primarily to a $7 million reduction in SG&A costs.

[0001628280-24-004446:mdna:127]
Accounting for Futures Contracts

[0001628280-24-004446:mdna:128]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 9 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 3 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001628280-24-004446:mdna:129]
Liquidity and Capital Resources

[0001628280-24-004446:mdna:130]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and our commercial paper program.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001628280-24-004446:mdna:131]
Statement of Cash Flows

[0001628280-24-004446:mdna:132]
The following table summarizes our cash flow activity for the years ended December 31, 2023, 2022 and 2021 (in millions):

[0001628280-24-004446:mdna:133]
|  | 2023 |  | 2022 |  | 2021 |
| Net cash provided by operating activities | $ | 736.2 |  |  | $ | 302.3 |  |  | $ | 515.5 |  |
| Net cash used in investing activities | $ | (319.7) |  |  | $ | (103.0) |  |  | $ | (106.4) |  |
| Net cash used in financing activities | $ | (406.2) |  |  | $ | (174.1) |  |  | $ | (498.7) |  |

[0001628280-24-004446:mdna:134]
Net Cash Provided By Operating Activities - Net cash provided by operating activities activities increased $434 million to $736 million in 2023 compared to $302 million in 2022.  The increase was primarily attributable to efforts to better manage working capital levels and an increase in net income of $93 million.

[0001628280-24-004446:mdna:135]
Net Cash Used In Investing Activities -  Net cash used in investing activities increased $217 million from 2022 to 2023 primarily due to higher capital expenditures and $95 million related to our acquisition of AES. Capital expenditures were $250 million, $101 million and $107 million in 2023, 2022 and 2021, respectively.  Capital expenditures in 2023 were primarily related to the expansion of our manufacturing capacity including investments in our commercial HVAC factory in Mexico, equipment, and investments in systems and software to support the overall enterprise.

[0001628280-24-004446:mdna:136]
Net Cash Used In Financing Activities - Net cash used in financing activities was $406 million in 2023 and $174 million in 2022.  The increase was primarily due to paydown of our debt balances during 2023.  We did not repurchase any shares in 2023 compared to $300 million of share repurchases in 2022. We also returned $153 million to shareholders through dividend payments in 2023.

[0001628280-24-004446:mdna:137]
Debt Position

[0001628280-24-004446:mdna:138]
The following table details our lines of credit and financing arrangements as of December 31, 2023 (in millions):

[0001628280-24-004446:mdna:139]
|  | Outstanding Borrowings |
| Commercial paper: | $ | 150.0 |  |
| Current maturities of long-term debt: |  |
| Finance lease obligations | $ | 12.1 |  |
| Total current maturities of long-term debt | $ | 12.1 |  |
| Long-term debt: |  |
| Finance lease obligations | $ | 32.7 |  |
| Credit agreement (1) | 20.0 |  |
| Senior unsecured notes | 1,100.0 |  |
| Debt issuance costs | (9.6) |  |
| Total long-term debt | $ | 1,143.1 |  |
| Total debt | $ | 1,305.2 |  |

[0001628280-24-004446:mdna:140]
(1)The total capacity on the facility is $1,100.0 million.  The amount available for future borrowings on our Credit Agreement is $928 million after being reduced by the outstanding borrowings under our Commercial Paper Program and $2 million in outstanding standby letters of credit as of December 31, 2023.

[0001628280-24-004446:mdna:141]
Commercial Paper Program

[0001628280-24-004446:mdna:142]
On October 25, 2023, we established a commercial paper program (the “Program”), as a replacement to our Asset Securitization Program which expired in November 2023, pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. CP Notes currently outstanding under the Program totaled $150 million as of December 31, 2023.

[0001628280-24-004446:mdna:143]
Credit Agreement

[0001628280-24-004446:mdna:144]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto. Under the Second Amendment, the revolving commitments were increased by $350 million

[0001628280-24-004446:mdna:145]
and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financings.

[0001628280-24-004446:mdna:146]
Our Credit Agreement consists of a $1,100.0 million unsecured revolving credit facility that matures in July 2026. We had outstanding borrowings of $20.0 million as well as $1.7 million committed to standby letters of credit as of December 31, 2023. Subject to covenant limitations, $928.3 million was available for future borrowings. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

[0001628280-24-004446:mdna:147]
Senior Unsecured Notes

[0001628280-24-004446:mdna:148]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%. We issued two series of senior unsecured

[0001628280-24-004446:mdna:149]
notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum (the 2025 Notes, the 2027 Notes, and the 2028 Notes, collectively the “Notes”).

[0001628280-24-004446:mdna:150]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement. The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of December 31, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-24-004446:mdna:151]
Financial Leverage

[0001628280-24-004446:mdna:152]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001628280-24-004446:mdna:153]
We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our Share Repurchase Plans.  Our book value of debt-to-total-capital ratio decreased to 82% at December 31, 2023 compared to 115% at December 31, 2022.

[0001628280-24-004446:mdna:154]
As of December 31, 2023, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001628280-24-004446:mdna:155]
Liquidity

[0001628280-24-004446:mdna:156]
We believe our cash and cash equivalents of $61 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2023 was $30 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments. Our cash and cash equivalents held in foreign locations is generally available for use in our U.S. operations and could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-24-004446:mdna:157]
No contributions are required to be made to our U.S. defined benefit plans in 2024. We made $15.0 million in total contributions to our pension plans in 2023.

[0001628280-24-004446:mdna:158]
Dividend payments were $153 million in 2023 compared to $142 million in 2022. On May 15, 2023, our Board of Directors approved a 4% increase in our quarterly dividend on common stock from $1.06 to $1.10 per share effective with the July 2023 dividend payment.

[0001628280-24-004446:mdna:159]
Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001628280-24-004446:mdna:160]
We expect capital expenditures of approximately $175 million in 2024, which includes final spending for our new commercial HVAC factory in Mexico and the 2025 low GWP refrigerant transition.

[0001628280-24-004446:mdna:161]
Financial Covenants related to our Debt

[0001628280-24-004446:mdna:162]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-24-004446:mdna:163]
Our Credit Agreement contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001628280-24-004446:mdna:164]
•We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-24-004446:mdna:165]
•We are in default in the performance of, or compliance with any term of any other indebtedness in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-24-004446:mdna:166]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our Credit Agreement or our senior unsecured notes were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-24-004446:mdna:167]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001628280-24-004446:mdna:168]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our Credit Agreement.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001628280-24-004446:mdna:169]
As of December 31, 2023, we believe we were in compliance with all covenant requirements.

[0001628280-24-004446:mdna:170]
Leasing Commitments

[0001628280-24-004446:mdna:171]
Refer to Note 5 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001628280-24-004446:mdna:172]
Guarantees related to our Debt Obligations

[0001628280-24-004446:mdna:173]
Our senior unsecured notes were issued by Lennox International Inc. (the “Parent”) and are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not secured by our other subsidiaries.  The Guarantor Subsidiaries are 100% owned and consolidated, all guarantees are full and unconditional, and all guarantees are joint and several.

[0001628280-24-004446:mdna:174]
Off Balance Sheet Arrangements

[0001628280-24-004446:mdna:175]
We have no off-balance sheet arrangements that we believe may have a material current or future effect on our financial condition, liquidity or results of operations.

[0001628280-24-004446:mdna:176]
Contractual Obligations

[0001628280-24-004446:mdna:177]
Contractual obligations arise in the normal course of business and include debt and related interest payments, leases, purchase obligations, pension and post-retirement benefits and warranty liabilities.  For additional information regarding our contractual obligations, see Note 5 of the Notes to the Consolidated Financial Statements.  See Note 10 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.  See Note 13 of the Notes to the Consolidated Financial Statements for more information on our debt obligations.

[0001628280-24-004446:mdna:178]
Fair Value Measurements

[0001628280-24-004446:mdna:179]
Fair value is the price that would be received to sell an asset or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001628280-24-004446:mdna:180]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001628280-24-004446:mdna:181]
Level 1 -          Quoted prices for identical instruments in active markets at the measurement date.

[0001628280-24-004446:mdna:182]
Level 2 -     Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument.

[0001628280-24-004446:mdna:183]
Level 3 -     Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances.

[0001628280-24-004446:mdna:184]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2023 and 2022, the measurement dates.  See Note 16 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001628280-24-004446:mdna:185]
Market Risk

[0001628280-24-004446:mdna:186]
Commodity Price Risk

[0001628280-24-004446:mdna:187]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001628280-24-004446:mdna:188]
| Notional amount (pounds of aluminum and copper) | 53.3 |  |
| Carrying amount and fair value of net asset | $ | (0.1) |  |
| Change in fair value from 10% change in forward prices | $ | 9.1 |  |

[0001628280-24-004446:mdna:189]
Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001628280-24-004446:mdna:190]
Interest Rate Risk

[0001628280-24-004446:mdna:191]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $2.3 million, $1.7 million and $0.4 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001628280-24-004446:mdna:192]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments when interest rates are low.  As of December 31, 2023 and 2022, no interest rate swaps were in effect.

[0001628280-24-004446:mdna:193]
Foreign Currency Exchange Rate Risk

[0001628280-24-004446:mdna:194]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  Our primary exposure to foreign currencies are the Canadian dollar, Mexican Peso, and the Euro.  During 2023, 2022 and 2021, net sales from outside the U.S. represented 11.3%, 11.4% and 13.1%, respectively, of our total net sales.  For the years ended December 31, 2023,  2022, and 2021, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $5.6 million, $3.5 million and $2.7 million impact to net income for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001628280-24-004446:mdna:195]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001628280-24-004446:mdna:196]
Critical Accounting Estimates

[0001628280-24-004446:mdna:197]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following describes our critical accounting estimate related to product warranties and product-related contingencies and how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements. This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001628280-24-004446:mdna:198]
Product Warranties and Product-Related Contingencies

[0001628280-24-004446:mdna:199]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.

[0001628280-24-004446:mdna:200]
From time to time, we may also incur costs to repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.  These product-related costs may not be covered under our warranties and are not covered by insurance.

[0001628280-24-004446:mdna:201]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 5 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001628280-24-004446:mdna:202]
Recent Accounting Pronouncements

[0001628280-24-004446:mdna:203]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
