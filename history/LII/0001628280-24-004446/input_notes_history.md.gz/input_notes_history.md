# LII note change history — 0001628280-23-025847 → 0001628280-23-035265


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001628280-23-035265:note_history:1]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions) as of:
  (was, 2023-07-27, similarity 0.9839):
[0001628280-23-025847:note_history:1]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

- changed (2023-10-26):
[0001628280-23-035265:note_history:2]
|  | September 30, 2023 |  | December 31, 2022 |
| Accrued expenses | $ | 44.0 |  |  | $ | 41.3 |  |
| Other liabilities | 100.6 |  |  | 101.4 |  |
| Total warranty liability | $ | 144.6 |  |  | $ | 142.7 |  |
  (was, 2023-07-27, similarity 0.9381):
[0001628280-23-025847:note_history:2]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Accrued expenses | $ | 44.2 |  |  | $ | 41.3 |  |
| Other liabilities | 102.5 |  |  | 101.4 |  |
| Total warranty liability | $ | 146.7 |  |  | $ | 142.7 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2023 were as follows (in millions):
  (was, 2023-07-27, similarity 0.9444):
[0001628280-23-025847:note_history:3]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2023 were as follows (in millions):

- changed (2023-10-26):
[0001628280-23-035265:note_history:4]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (33.2) |  |
| Changes resulting from issuance of new warranties | 44.7 |  |
| Changes in estimates associated with pre-existing liabilities | (5.2) |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Warranty liability reclassified as liabilities held for sale | (4.3) |  |
| Total warranty liability as of September 30, 2023 | $ | 144.6 |  |
  (was, 2023-07-27, similarity 0.8359):
[0001628280-23-025847:note_history:4]
| Total warranty liability as of December 31, 2022 | $ | 142.7 |  |
| Warranty claims paid | (19.3) |  |
| Changes resulting from issuance of new warranties | 28.5 |  |
| Changes in estimates associated with pre-existing liabilities | (5.5) |  |
| Changes in foreign currency translation rates and other | 0.3 |  |
| Total warranty liability as of June 30, 2023 | $ | 146.7 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:5]
We are involved in a number of claims and lawsuits incidental to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.
  (was, 2023-07-27, similarity 0.9968):
[0001628280-23-025847:note_history:5]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-10-26):
[0001628280-23-035265:note_history:6]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and nine months ended September 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.

- removed (2023-10-26):
[0001628280-23-025847:note_history:7]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2023, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2023 and 2022, the accompanying unaudited Consolidated Statements of Stockholders' Equity (Deficit) for the three and six months ended June 30, 2023 and 2022, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2023 and 2022 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2022.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001628280-23-035265:note_history:8]
Our weighted average borrowing rate on the facility was as follows as of:
  (was, 2023-07-27, similarity 0.9571):
[0001628280-23-025847:note_history:8]
Our weighted average borrowing rate on the facility was as follows:

- changed (2023-10-26):
[0001628280-23-035265:note_history:9]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average borrowing rate | — | % |  | 5.57 | % |
  (was, 2023-07-27, similarity 0.877):
[0001628280-23-025847:note_history:9]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.46 | % |  | 5.57 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001628280-23-035265:note_history:10]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:
  (was, 2023-07-27, similarity 0.9805):
[0001628280-23-025847:note_history:10]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2023-10-26):
[0001628280-23-035265:note_history:11]
|  | September 30, 2023 |  | December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.6 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.9 |  |  | 28.3 |  |
| Credit agreement | — |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (10.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,121.6 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,483.2 |  |  | $ | 1,524.8 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2023.
  (was, 2023-07-27, similarity 0.9378):
[0001628280-23-025847:note_history:12]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of June 30, 2023 or December 31, 2022 and there were no borrowings or repayments on these facilities during the six months ended June 30, 2023.

- changed (2023-10-26):
[0001628280-23-035265:note_history:13]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions) as of:
  (was, 2023-07-27, similarity 0.9947):
[0001628280-23-025847:note_history:13]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

- added (2023-10-26):
[0001628280-23-035265:note_history:14]
|  | September 30, 2023 |  | December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | — |  |  | (350.0) |  |
| Remaining amount available | $ | 400.0 |  |  | $ | — |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:15]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on the floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2023 and December 31, 2022 were 0.00% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2023-07-27, similarity 0.9697):
[0001628280-23-025847:note_history:15]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2023 and December 31, 2022 were 5.98% and 5.17%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2023-10-26):
[0001628280-23-035265:note_history:16]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of September 30, 2023, we were in compliance with all covenant requirements.  The ASP will expire according to its terms in November 2023 and we do not intend to renew it.
  (was, 2023-07-27, similarity 0.9056):
[0001628280-23-025847:note_history:16]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement (as defined below), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Credit Agreement, as defined below. The participating financial institutions have investment grade credit ratings.  As of June 30, 2023, we were in compliance with all covenant requirements.

- added (2023-10-26):
[0001628280-23-035265:note_history:17]
Second Amendment to the Credit Agreement

- added (2023-10-26):
[0001628280-23-035265:note_history:18]
In August 2023, we entered into the Second Amendment (the “Second Amendment”) to our existing Credit Agreement, dated as of July 14, 2021 (as amended, the "Credit Agreement"), with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.  Under the Second Amendment, the revolving commitments were increased by $350 million and certain representations required to be made as conditions precedent to borrowing were revised to provide us greater flexibility to enter into additional future financing.

- changed (2023-10-26):
[0001628280-23-035265:note_history:19]
The Credit Agreement consists of a $1.1 billion unsecured revolving credit facility.  We had outstanding borrowings of $0.0 million as well as $1.7 million committed to standby letters of credit as of September 30, 2023. Subject to covenant limitations, $1,098.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.
  (was, 2023-07-27, similarity 0.9874):
[0001628280-23-025847:note_history:19]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $192.0 million as well as $1.7 million committed to standby letters of credit as of June 30, 2023. Subject to covenant limitations, $556.3 million was available for future borrowings.  The Credit Agreement includes a subfacility for swingline loans up to $65.0 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement.

- changed (2023-10-26):
[0001628280-23-035265:note_history:20]
Our weighted average borrowing rate on the facility was as follows as of:
  (was, 2023-07-27, similarity 0.9571):
[0001628280-23-025847:note_history:20]
Our weighted average borrowing rate on the facility was as follows:

- changed (2023-10-26):
[0001628280-23-035265:note_history:21]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average borrowing rate | — | % |  | 5.57 | % |
  (was, 2023-07-27, similarity 0.877):
[0001628280-23-025847:note_history:21]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Weighted average borrowing rate | 6.46 | % |  | 5.57 | % |

- changed (2023-10-26):
[0001628280-23-035265:note_history:22]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2023-07-27, similarity 0.7372):
[0001628280-23-025847:note_history:22]
substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

- changed (2023-10-26):
[0001628280-23-035265:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of September 30, 2023, we were in compliance with all covenant requirements.
  (was, 2023-07-27, similarity 0.9516):
[0001628280-23-025847:note_history:23]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Credit Agreement and accelerate amounts due under our Credit Agreement (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of June 30, 2023, we were in compliance with all covenant requirements.

- added (2023-10-26):
[0001628280-23-035265:note_history:24]
In September 2023, we issued $500.0 million of senior unsecured notes, which will mature in September 2028 (the "2028 Notes") with interest being paid semi-annually in March and September at 5.50%.  We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually in February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes, 2027 Notes, and the 2028 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.

- added (2023-10-26):
[0001628280-23-035265:note_history:25]
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2023, we believe we were in compliance with all covenant requirements.

- added (2023-10-26):
[0001628280-23-035265:note_history:26]
Commercial Paper Program

- added (2023-10-26):
[0001628280-23-035265:note_history:27]
On October 25, 2023, we established a commercial paper program (the “Program”) pursuant to which we may issue short-term, unsecured commercial paper notes (the “CP Notes”) under the exemption from registration contained in Section 4(a)(2) of the Securities Act of 1933, as amended. Amounts available under the Program may be borrowed, repaid, and re-borrowed from time to time, with the aggregate face or principal amount of the CP Notes outstanding under the Program at any time not to exceed $500.0 million. The CP Notes will have maturities of up to 397 days from the date of issue. The CP Notes will rank pari passu with all of our other unsecured and unsubordinated indebtedness. The net proceeds of the issuances of the CP Notes are expected to be used for general corporate purposes. We plan to use our revolving credit facility as a liquidity backstop for the repayment of CP Notes outstanding under the Program. No CP Notes are currently outstanding under the Program.

- removed (2023-10-26):
[0001628280-23-025847:note_history:28]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.5 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.0 |  |  | 28.3 |  |
| Credit agreement | 192.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 817.7 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,579.0 |  |  | $ | 1,524.8 |  |

- removed (2023-10-26):
[0001628280-23-025847:note_history:29]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 400.0 |  |  | $ | 350.0 |  |
| Less: Beneficial interest transferred | (400.0) |  |  | (350.0) |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- removed (2023-10-26):
[0001628280-23-025847:note_history:30]
Credit Agreement

- removed (2023-10-26):
[0001628280-23-025847:note_history:31]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

- removed (2023-10-26):
[0001628280-23-025847:note_history:32]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or

- removed (2023-10-26):
[0001628280-23-025847:note_history:33]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of June 30, 2023, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001628280-23-035265:note_history:34]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions) as of:
  (was, 2023-07-27, similarity 0.9805):
[0001628280-23-025847:note_history:34]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

- added (2023-10-26):
[0001628280-23-035265:note_history:35]
|  | September 30, 2023 |  | December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | — |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.6 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | — |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 361.6 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.9 |  |  | 28.3 |  |
| Credit agreement | — |  |  | 192.0 |  |
| Senior unsecured notes | 1,100.0 |  |  | 600.0 |  |
| Debt issuance costs | (10.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 1,121.6 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,483.2 |  |  | $ | 1,524.8 |  |

- removed (2023-10-26):
[0001628280-23-025847:note_history:36]
|  | As of June 30, 2023 |  | As of December 31, 2022 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 400.0 |  |  | $ | 350.0 |  |
| Finance lease obligations | 11.5 |  |  | 11.2 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (0.2) |  |  | (0.6) |  |
| Total current maturities of long-term debt | $ | 761.3 |  |  | $ | 710.6 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 31.0 |  |  | 28.3 |  |
| Credit agreement | 192.0 |  |  | 192.0 |  |
| Senior unsecured notes | 600.0 |  |  | 600.0 |  |
| Debt issuance costs | (5.3) |  |  | (6.1) |  |
| Total long-term debt | $ | 817.7 |  |  | $ | 814.2 |  |
| Total debt | $ | 1,579.0 |  |  | $ | 1,524.8 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001628280-23-035265:note_history:37]
|  | For the Three Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 842.1 |  |  | $ | 376.8 |  |  | $ | — |  |  | $ | 1,218.9 |  |
| Canada | 54.2 |  |  | 28.7 |  |  | — |  |  | 82.9 |  |
| Other international | — |  |  | — |  |  | 64.5 |  |  | 64.5 |  |
| Total | $ | 896.3 |  |  | $ | 405.5 |  |  | $ | 64.5 |  |  | $ | 1,366.3 |  |
  (was, 2023-07-27, similarity 0.7872):
[0001628280-23-025847:note_history:37]
|  | For the Three Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 868.5 |  |  | $ | 382.2 |  |  | $ | — |  |  | $ | 1,250.7 |  |
| Canada | 67.7 |  |  | 25.3 |  |  | — |  |  | 93.0 |  |
| Other international | — |  |  | — |  |  | 67.7 |  |  | 67.7 |  |
| Total | $ | 936.2 |  |  | $ | 407.5 |  |  | $ | 67.7 |  |  | $ | 1,411.4 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:38]
|  | For the Three Months Ended September 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 779.8 |  |  | $ | 331.9 |  |  | $ | — |  |  | $ | 1,111.7 |  |
| Canada | 55.5 |  |  | 20.3 |  |  | — |  |  | 75.8 |  |
| Other international | — |  |  | 0.1 |  |  | 57.3 |  |  | 57.4 |  |
| Total | $ | 835.3 |  |  | $ | 352.3 |  |  | $ | 57.3 |  |  | $ | 1,244.9 |  |
  (was, 2023-07-27, similarity 0.7293):
[0001628280-23-025847:note_history:38]
|  | For the Six Months Ended June 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,531.4 |  |  | $ | 583.6 |  |  | $ | — |  |  | $ | 2,115.0 |  |
| Canada | 128.2 |  |  | 22.8 |  |  | — |  |  | 151.0 |  |
| Other international | — |  |  | 0.5 |  |  | 113.2 |  |  | 113.7 |  |
| Total | $ | 1,659.6 |  |  | $ | 606.9 |  |  | $ | 113.2 |  |  | $ | 2,379.7 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:39]
|  | For the Nine Months Ended September 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,350.0 |  |  | $ | 1,053.5 |  |  | $ | — |  |  | $ | 3,403.5 |  |
| Canada | 163.6 |  |  | 68.0 |  |  | — |  |  | 231.6 |  |
| Other international | — |  |  | — |  |  | 192.0 |  |  | 192.0 |  |
| Total | $ | 2,513.6 |  |  | $ | 1,121.5 |  |  | $ | 192.0 |  |  | $ | 3,827.1 |  |
  (was, 2023-07-27, similarity 0.7374):
[0001628280-23-025847:note_history:39]
|  | For the Six Months Ended June 30, 2023 |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 1,507.8 |  |  | $ | 676.7 |  |  | $ | — |  |  | $ | 2,184.5 |  |
| Canada | 109.4 |  |  | 39.4 |  |  | — |  |  | 148.8 |  |
| Other international | — |  |  | — |  |  | 127.4 |  |  | 127.4 |  |
| Total | $ | 1,617.2 |  |  | $ | 716.1 |  |  | $ | 127.4 |  |  | $ | 2,460.7 |  |

- added (2023-10-26):
[0001628280-23-035265:note_history:40]
|  | For the Nine Months Ended September 30, 2022 (1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 2,311.2 |  |  | $ | 915.4 |  |  | $ | — |  |  | $ | 3,226.6 |  |
| Canada | 183.7 |  |  | 43.2 |  |  | — |  |  | 226.9 |  |
| Other international | — |  |  | 0.6 |  |  | 170.5 |  |  | 171.1 |  |
| Total | $ | 2,494.9 |  |  | $ | 959.2 |  |  | $ | 170.5 |  |  | $ | 3,624.6 |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:41]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and nine months ended September 30, 2022 have been recast to reflect the revised segment presentation.
  (was, 2023-07-27, similarity 0.8045):
[0001628280-23-025847:note_history:41]
(1) As discussed in Note 2, we adjusted our segment reporting to include the results of our Heatcraft businesses in Commercial and the results of our European portfolio in Corporate and Other.  The amounts for the three and six months ended June 30, 2022 have been recast to reflect the revised segment presentation.

- changed (2023-10-26):
[0001628280-23-035265:note_history:42]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2023 and 2022, direct sales represented 77% and 72% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2023 and 2022, direct sales represented 75% and 70% of revenues, and sales to independent distributors represented the remainder.
  (was, 2023-07-27, similarity 0.8174):
[0001628280-23-025847:note_history:42]
Residential - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended June 30, 2023 and 2022, direct sales represented 76% and 70% of revenues, and sales to independent distributors represented the remainder. For the six months ended June 30, 2023 and 2022, direct sales represented 73% and 69% of revenues, and sales to independent distributors represented the remainder.

- changed (2023-10-26):
[0001628280-23-035265:note_history:43]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended September 30, 2023 and 2022, equipment sales represented 88% and 88% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2023 and 2022, equipment sales represented 87% and 87% of revenues and the remainder of our revenue was generated from our service business.
  (was, 2023-07-27, similarity 0.6464):
[0001628280-23-025847:note_history:43]
Commercial - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets. We manufacture and market equipment for the commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well

- changed (2023-10-26):
[0001628280-23-035265:note_history:44]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Net contract liabilities consisted of the following (in millions) as of:
  (was, 2023-07-27, similarity 0.9375):
[0001628280-23-025847:note_history:44]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Net contract liabilities consisted of the following:

- added (2023-10-26):
[0001628280-23-035265:note_history:45]
|  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (4.9) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (7.2) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (12.1) |  |  | $ | (16.0) |  |  |  |  |  |

- changed (2023-10-26):
[0001628280-23-035265:note_history:46]
For the three months ended September 30, 2023 and 2022, we recognized revenue of $2.8 million and $3.6 million and for the nine months ended we recognized revenue of $7.0 million and $9.5 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.
  (was, 2023-07-27, similarity 0.9707):
[0001628280-23-025847:note_history:46]
For the three months ended June 30, 2023 and 2022, we recognized revenue of $1.2 million and $2.1 million and for the six months ended we recognized revenue of $4.2 million and $5.9 million related to our contract liabilities at January 1, 2023 and 2022, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in 2023 and 2022.

- removed (2023-10-26):
[0001628280-23-025847:note_history:47]
|  | For the Three Months Ended June 30, 2022(1) |
| Primary Geographic Markets | Residential |  | Commercial |  | Corporate and Other |  | Consolidated |
| United States | $ | 901.8 |  |  | $ | 315.0 |  |  | $ | — |  |  | $ | 1,216.8 |  |
| Canada | 75.7 |  |  | 12.4 |  |  | — |  |  | 88.1 |  |
| Other international | — |  |  | — |  |  | 61.4 |  |  | 61.4 |  |
| Total | $ | 977.5 |  |  | $ | 327.4 |  |  | $ | 61.4 |  |  | $ | 1,366.3 |  |

- removed (2023-10-26):
[0001628280-23-025847:note_history:48]
as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. For the three months ended June 30, 2023 and 2022, equipment sales represented 87% and 88% of revenues and the remainder of our revenue was generated from our service business. For the six months ended June 30, 2023 and 2022, equipment sales represented 86% and 87% of revenues and the remainder of our revenue was generated from our service business.

- removed (2023-10-26):
[0001628280-23-025847:note_history:49]
|  | As of June 30, 2023 |  | As of December 31, 2022 |  |  |  |  |
| Contract liabilities - current | $ | (13.4) |  |  | $ | (9.6) |  |  |  |  |  |
| Contract liabilities - noncurrent | (6.9) |  |  | (6.4) |  |  |  |  |  |
| Total | $ | (20.3) |  |  | $ | (16.0) |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-10-26):
[0001628280-23-035265:note_history:50]
14. Subsequent Event:On October 25, 2023, we announced the acquisition of AES, a company dedicated to service and sustainability in the light commercial markets.  Across North America, AES provides installation services, adapter curbs, and recycling services.  AES will become part of the Commercial segment.
