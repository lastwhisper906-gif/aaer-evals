# LII notes — 0001069202-18-000013


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-18-000013:notes:1]
[same as prior period, unchanged from 0001069202-18-000009:notes:1]


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-18-000013:notes:2]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000013:notes:3]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-18-000013:notes:4]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-18-000013:notes:5]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.27 | % |  | 2.76 | % |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001069202-18-000013:notes:6]
[same as prior period, unchanged from 0001069202-18-000009:notes:6]

[0001069202-18-000013:notes:7]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

[0001069202-18-000013:notes:8]
[same as prior period, unchanged from 0001069202-18-000009:notes:8]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-18-000013:notes:9]
Commitments and Contingencies:

[0001069202-18-000013:notes:10]
Product Warranties and Product Related Contingencies

[0001069202-18-000013:notes:11]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in assumptions, as necessary.

[0001069202-18-000013:notes:12]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000013:notes:13]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 35.0 |  |  | $ | 34.8 |  |
| Other liabilities | 75.4 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.4 |  |  | $ | 109.9 |  |

[0001069202-18-000013:notes:14]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2018 were as follows (in millions):

[0001069202-18-000013:notes:15]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (21.7 | ) |
| Changes resulting from issuance of new warranties | 24.2 |  |
| Changes in estimates associated with pre-existing liabilities | (3.3 | ) |
| Changes in foreign currency translation rates and other | 2.7 |  |
| Warranty liability from assets held for sale | (1.4 | ) |
| Total warranty liability as of June 30, 2018 | $ | 110.4 |  |

[0001069202-18-000013:notes:16]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities, for such quality related issues, are not material.

[0001069202-18-000013:notes:17]
Litigation

[0001069202-18-000013:notes:18]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-18-000013:notes:19]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2018 and 2017, expense for asbestos-related litigation was $1.9 million and $2.4 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations. For the three months ended  June 30, 2018 and 2017,  expense for asbestos-related litigation was $(0.2) million and $0.7 million, respectively, net of probable insurance recoveries.

[0001069202-18-000013:notes:20]
In October 2016, we self-reported to the Securities and Exchange Commission ("SEC") and the Department of Justice ("DOJ") an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We concluded our investigation and communicated our findings to the SEC and the DOJ. We fully cooperated with the SEC and the DOJ regarding this matter. The  DOJ has declined to prosecute this matter.

[0001069202-18-000013:notes:21]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows.  Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-18-000013:notes:22]
[same as prior period, unchanged from 0001069202-18-000009:notes:22]

[0001069202-18-000013:notes:23]
[same as prior period, unchanged from 0001069202-18-000009:notes:23]

[0001069202-18-000013:notes:24]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |  |  |  |  |
| Commodity futures contracts |  | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 7.2 |  |  | $ | 5.9 |  |  | Cost of goods sold |
| Income tax expense |  | (0.6 | ) |  | (1.0 | ) |  | (1.6 | ) |  | (2.1 | ) |  | Provision for income taxes |
| Net of tax |  | $ | 2.0 |  |  | $ | 1.8 |  |  | $ | 5.6 |  |  | $ | 3.8 |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (2.4 | ) |  | $ | (1.9 | ) |  | $ | (4.7 | ) |  | $ | (3.6 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 0.6 |  |  | 0.6 |  |  | 1.2 |  |  | 1.1 |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.8 | ) |  | $ | (1.3 | ) |  | $ | (3.5 | ) |  | $ | (2.5 | ) |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of business or transfer to assets held for sale |  | $ | (22.9 | ) |  | $ | — |  |  | $ | (22.9 | ) |  | $ | — |  |  | (Gain) loss, net on sale of business and related property or transfer to assets held for sale |
| Income tax benefit |  | — |  |  | — |  |  | — |  |  | — |  |  | Provision for income taxes |
| Net of tax |  | $ | (22.9 | ) |  | $ | — |  |  | $ | (22.9 | ) |  | $ | — |  |  |  |
| Total reclassifications from AOCL |  | $ | (22.7 | ) |  | $ | 0.5 |  |  | $ | (20.8 | ) |  | $ | 1.3 |  |  |  |

[0001069202-18-000013:notes:25]
The following table provides information on changes in AOCL, by component (net of tax), for the six months ended June 30, 2018 (in millions):

[0001069202-18-000013:notes:26]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains on Available-for-Sale Securities |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |
| Other comprehensive (loss) income before reclassifications |  | (2.5 | ) |  | (1.8 | ) |  | (27.2 | ) |  | (12.9 | ) |  | (44.4 | ) |
| Amounts reclassified from AOCL |  | (5.6 | ) |  | — |  |  | 3.5 |  |  | 22.9 |  |  | 20.8 |  |
| Net other comprehensive (loss) income |  | (8.1 | ) |  | (1.8 | ) |  | (23.7 | ) |  | 10.0 |  |  | (23.6 | ) |
| Balance as of June 30, 2018 |  | $ | (0.7 | ) |  | $ | — |  |  | $ | (151.2 | ) |  | $ | (29.1 | ) |  | $ | (181.0 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-18-000013:notes:27]
[same as prior period, unchanged from 0001069202-18-000009:notes:27]

[0001069202-18-000013:notes:28]
Our senior unsecured notes are unconditionally guaranteed by certain of our subsidiaries (the “Guarantor Subsidiaries”) and are not guaranteed by our other subsidiaries (the “Non-Guarantor Subsidiaries”).  The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several.  As a result of the guarantee arrangements, we are required to present the following condensed consolidating financial statements.

[0001069202-18-000013:notes:29]
The condensed consolidating financial statements reflect our investments in our subsidiaries using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions. Our condensed consolidating financial statements and our Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of June 30, 2018 and December 31, 2017, and for the three and six months ended June 30, 2018 and 2017 are shown on the following pages.

[0001069202-18-000013:notes:30]
[same as prior period, unchanged from 0001069202-18-000009:notes:30]

[0001069202-18-000013:notes:31]
[same as prior period, unchanged from 0001069202-18-000009:notes:31]

[0001069202-18-000013:notes:32]
As of June 30, 2018

[0001069202-18-000013:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 22.6 |  |  | $ | 15.2 |  |  | $ | — |  |  | $ | 39.4 |  |
| Accounts and notes receivable, net | — |  |  | 67.5 |  |  | 673.8 |  |  | — |  |  | 741.3 |  |
| Inventories, net | — |  |  | 442.9 |  |  | 102.5 |  |  | (5.2 | ) |  | 540.2 |  |
| Assets held for sale | — |  |  | — |  |  | 11.6 |  |  | — |  |  | 11.6 |  |
| Other assets | 4.0 |  |  | 27.5 |  |  | 55.5 |  |  | (33.7 | ) |  | 53.3 |  |
| Total current assets | 5.6 |  |  | 560.5 |  |  | 858.6 |  |  | (38.9 | ) |  | 1,385.8 |  |
| Property, plant and equipment, net | — |  |  | 260.7 |  |  | 114.2 |  |  | (3.9 | ) |  | 371.0 |  |
| Goodwill | — |  |  | 166.2 |  |  | 20.6 |  |  | — |  |  | 186.8 |  |
| Investment in subsidiaries | 1,668.2 |  |  | 598.5 |  |  | (0.5 | ) |  | (2,266.2 | ) |  | — |  |
| Deferred income taxes | 7.4 |  |  | 69.0 |  |  | 25.0 |  |  | (12.2 | ) |  | 89.2 |  |
| Other assets, net | 1.5 |  |  | 46.9 |  |  | 19.7 |  |  | (1.5 | ) |  | 66.6 |  |
| Intercompany (payables) receivables, net | (771.2 | ) |  | 718.9 |  |  | 126.0 |  |  | (73.7 | ) |  | — |  |
| Total assets | $ | 911.5 |  |  | $ | 2,420.7 |  |  | $ | 1,163.6 |  |  | $ | (2,396.4 | ) |  | $ | 2,099.4 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |  | $ | 3.8 |  |
| Current maturities of long-term debt | 29.4 |  |  | 0.1 |  |  | 0.3 |  |  | — |  |  | 29.8 |  |
| Accounts payable | 25.8 |  |  | 301.1 |  |  | 110.6 |  |  | — |  |  | 437.5 |  |
| Accrued expenses | 4.3 |  |  | 208.5 |  |  | 40.8 |  |  | — |  |  | 253.6 |  |
| Liabilities held for sale | — |  |  | — |  |  | 7.4 |  |  | — |  |  | 7.4 |  |
| Income taxes payable (receivable) | 14.8 |  |  | 11.4 |  |  | 36.7 |  |  | (50.9 | ) |  | 12.0 |  |
| Total current liabilities | 74.3 |  |  | 521.1 |  |  | 199.6 |  |  | (50.9 | ) |  | 744.1 |  |
| Long-term debt | 1,017.4 |  |  | 11.6 |  |  | 290.0 |  |  | — |  |  | 1,319.0 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Pensions | — |  |  | 77.8 |  |  | 8.7 |  |  | — |  |  | 86.5 |  |
| Other liabilities | — |  |  | 119.7 |  |  | 7.8 |  |  | — |  |  | 127.5 |  |
| Total liabilities | 1,091.7 |  |  | 732.7 |  |  | 506.1 |  |  | (50.9 | ) |  | 2,279.6 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | (180.2 | ) |  | 1,688.0 |  |  | 657.5 |  |  | (2,345.5 | ) |  | (180.2 | ) |
| Total liabilities and stockholders' equity | $ | 911.5 |  |  | $ | 2,420.7 |  |  | $ | 1,163.6 |  |  | $ | (2,396.4 | ) |  | $ | 2,099.4 |  |

[0001069202-18-000013:notes:34]
[same as prior period, unchanged from 0001069202-18-000009:notes:34]

[0001069202-18-000013:notes:35]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net | — |  |  | 35.3 |  |  | 471.2 |  |  | — |  |  | 506.5 |  |
| Inventories, net | — |  |  | 355.7 |  |  | 131.9 |  |  | (3.4 | ) |  | 484.2 |  |
| Other assets | 16.2 |  |  | 23.1 |  |  | 67.5 |  |  | (28.4 | ) |  | 78.4 |  |
| Total current assets | 17.8 |  |  | 442.1 |  |  | 709.2 |  |  | (31.8 | ) |  | 1,137.3 |  |
| Property, plant and equipment, net | — |  |  | 257.6 |  |  | 144.4 |  |  | (4.2 | ) |  | 397.8 |  |
| Goodwill | — |  |  | 134.9 |  |  | 65.6 |  |  | — |  |  | 200.5 |  |
| Investment in subsidiaries | 1,257.7 |  |  | 365.8 |  |  | (0.6 | ) |  | (1,622.9 | ) |  | — |  |
| Deferred income taxes | 3.9 |  |  | 69.1 |  |  | 33.6 |  |  | (12.2 | ) |  | 94.4 |  |
| Other assets, net | 2.1 |  |  | 41.3 |  |  | 19.6 |  |  | (1.5 | ) |  | 61.5 |  |
| Intercompany (payables) receivables, net | (559.3 | ) |  | 554.7 |  |  | 107.4 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 32.6 |  |
| Accounts payable | 21.3 |  |  | 228.0 |  |  | 99.3 |  |  | — |  |  | 348.6 |  |
| Accrued expenses | 3.1 |  |  | 209.4 |  |  | 57.8 |  |  | — |  |  | 270.3 |  |
| Income taxes (receivable) payable | (64.5 | ) |  | 56.5 |  |  | 60.9 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | (10.7 | ) |  | 496.8 |  |  | 219.2 |  |  | (50.8 | ) |  | 654.5 |  |
| Long-term debt | 682.8 |  |  | 11.7 |  |  | 276.0 |  |  | — |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.6 |  |  | — |  |  | — |  |  | 2.6 |  |
| Pensions | — |  |  | 74.7 |  |  | 9.8 |  |  | — |  |  | 84.5 |  |
| Other liabilities | — |  |  | 120.6 |  |  | 8.7 |  |  | — |  |  | 129.3 |  |
| Total liabilities | 672.1 |  |  | 706.4 |  |  | 513.7 |  |  | (50.8 | ) |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 50.1 |  |  | 1,159.1 |  |  | 565.5 |  |  | (1,724.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders' equity | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |

[0001069202-18-000013:notes:36]
[same as prior period, unchanged from 0001069202-18-000009:notes:36]

[0001069202-18-000013:notes:37]
For the Three Months Ended June 30, 2018

[0001069202-18-000013:notes:38]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 1,057.8 |  |  | $ | 303.8 |  |  | $ | (186.2 | ) |  | $ | 1,175.4 |  |
| Cost of goods sold | — |  |  | 745.0 |  |  | 255.3 |  |  | (186.5 | ) |  | 813.8 |  |
| Gross profit | — |  |  | 312.8 |  |  | 48.5 |  |  | 0.3 |  |  | 361.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 151.0 |  |  | 10.7 |  |  | (0.3 | ) |  | 161.4 |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | (3.3 | ) |  | 3.3 |  |  | (0.1 | ) |  | 0.2 |  |
| Restructuring charges | — |  |  | — |  |  | 0.5 |  |  | — |  |  | 0.5 |  |
| (Gain) loss, net on sale of business and related property | — |  |  | (0.9 | ) |  | (21.2 | ) |  | — |  |  | (22.1 | ) |
| Loss on assets held for sale | — |  |  | — |  |  | 31.4 |  |  | — |  |  | 31.4 |  |
| Income from equity method investments | (139.6 | ) |  | (17.1 | ) |  | (3.7 | ) |  | 155.5 |  |  | (4.9 | ) |
| Operating income | 139.3 |  |  | 183.1 |  |  | 27.5 |  |  | (154.8 | ) |  | 195.1 |  |
| Interest expense, net | 2.4 |  |  | 5.2 |  |  | 2.2 |  |  | — |  |  | 9.8 |  |
| Other expense, net | — |  |  | 0.7 |  |  | 0.1 |  |  | — |  |  | 0.8 |  |
| Income (loss) from continuing operations before income taxes | 136.9 |  |  | 177.2 |  |  | 25.2 |  |  | (154.8 | ) |  | 184.5 |  |
| Provision for income tax (benefit) expense | (0.7 | ) |  | 43.8 |  |  | 2.3 |  |  | (0.1 | ) |  | 45.3 |  |
| Income (loss) from continuing operations | 137.6 |  |  | 133.4 |  |  | 22.9 |  |  | (154.7 | ) |  | 139.2 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (1.6 | ) |  | — |  |  | (1.6 | ) |
| Net income (loss) | $ | 137.6 |  |  | $ | 133.4 |  |  | $ | 21.3 |  |  | $ | (154.7 | ) |  | $ | 137.6 |  |
| Other comprehensive (loss) income, net of tax | (2.3 | ) |  | 11.9 |  |  | (9.3 | ) |  | — |  |  | 0.3 |  |
| Comprehensive income (loss) | $ | 135.3 |  |  | $ | 145.3 |  |  | $ | 12.0 |  |  | $ | (154.7 | ) |  | $ | 137.9 |  |

[0001069202-18-000013:notes:39]
For the Three Months Ended June 30, 2017

[0001069202-18-000013:notes:40]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 968.7 |  |  | $ | 310.9 |  |  | $ | (177.5 | ) |  | $ | 1,102.1 |  |
| Cost of goods sold | — |  |  | 672.7 |  |  | 264.5 |  |  | (175.9 | ) |  | 761.3 |  |
| Gross profit | — |  |  | 296.0 |  |  | 46.4 |  |  | (1.6 | ) |  | 340.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 147.9 |  |  | 20.8 |  |  | (0.2 | ) |  | 168.5 |  |
| Losses (gains) and other expenses, net | 0.3 |  |  | 1.9 |  |  | 0.2 |  |  | (0.1 | ) |  | 2.3 |  |
| Restructuring charges | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income from equity method investments | (120.6 | ) |  | (17.5 | ) |  | (4.5 | ) |  | 137.1 |  |  | (5.5 | ) |
| Operating income | 120.3 |  |  | 163.7 |  |  | 29.8 |  |  | (138.4 | ) |  | 175.4 |  |
| Interest expense, net | 7.4 |  |  | (0.8 | ) |  | 1.6 |  |  | — |  |  | 8.2 |  |
| Other expense, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 112.9 |  |  | 164.5 |  |  | 28.3 |  |  | (138.4 | ) |  | 167.3 |  |
| Provision for income tax (benefit) expense | (2.6 | ) |  | 47.2 |  |  | 6.5 |  |  | (0.2 | ) |  | 50.9 |  |
| Income from continuing operations | 115.5 |  |  | 117.3 |  |  | 21.8 |  |  | (138.2 | ) |  | 116.4 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (0.9 | ) |  | — |  |  | (0.9 | ) |
| Net income | $ | 115.5 |  |  | $ | 117.3 |  |  | $ | 20.9 |  |  | $ | (138.2 | ) |  | $ | 115.5 |  |
| Other comprehensive (loss) income, net of tax | (1.5 | ) |  | 0.3 |  |  | 10.2 |  |  | 1.1 |  |  | 10.1 |  |
| Comprehensive (loss) income | $ | 114.0 |  |  | $ | 117.6 |  |  | $ | 31.1 |  |  | $ | (137.1 | ) |  | $ | 125.6 |  |

[0001069202-18-000013:notes:41]
[same as prior period, unchanged from 0001069202-18-000009:notes:41]

[0001069202-18-000013:notes:42]
For the Six Months Ended June 30, 2018

[0001069202-18-000013:notes:43]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 87.2 |  |  | $ | (7.9 | ) |  | $ | (114.3 | ) |  | $ | — |  |  | $ | (35.0 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (33.0 | ) |  | (10.4 | ) |  | — |  |  | (43.4 | ) |
| Proceeds from sale of businesses | — |  |  | — |  |  | 111.8 |  |  | — |  |  | 111.8 |  |
| Net cash (used in) provided by investing activities | — |  |  | (33.0 | ) |  | 101.5 |  |  | — |  |  | 68.5 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | 2.9 |  |  | — |  |  | 2.9 |  |
| Asset securitization borrowings | — |  |  | — |  |  | 65.0 |  |  | — |  |  | 65.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (51.0 | ) |  | — |  |  | (51.0 | ) |
| Long-term debt payments | (15.0 | ) |  | (2.7 | ) |  | (0.1 | ) |  | — |  |  | (17.8 | ) |
| Long-term borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 1,391.0 |  |  | — |  |  | — |  |  | — |  |  | 1,391.0 |  |
| Payments on credit facility | (1,042.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,042.0 | ) |
| Proceeds from employee stock purchases | 1.2 |  |  | — |  |  | — |  |  | — |  |  | 1.2 |  |
| Repurchases of common stock | (350.2 | ) |  | — |  |  | — |  |  | — |  |  | (350.2 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (18.6 | ) |  | — |  |  | — |  |  | — |  |  | (18.6 | ) |
| Intercompany debt | (53.0 | ) |  | 83.5 |  |  | (30.5 | ) |  | — |  |  | — |  |
| Intercompany financing activity | 41.8 |  |  | (45.3 | ) |  | 3.5 |  |  | — |  |  | — |  |
| Cash dividends paid | (42.4 | ) |  | — |  |  | — |  |  | — |  |  | (42.4 | ) |
| Net cash (used in) provided by financing activities | (87.2 | ) |  | 35.5 |  |  | (10.2 | ) |  | — |  |  | (61.9 | ) |
| Decrease in cash and cash equivalents | — |  |  | (5.4 | ) |  | (23.0 | ) |  | — |  |  | (28.4 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Cash and cash equivalents, beginning of period | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of period | $ | 1.6 |  |  | $ | 22.6 |  |  | $ | 15.2 |  |  | $ | — |  |  | $ | 39.4 |  |

[0001069202-18-000013:notes:44]
For the Six Months Ended June 30, 2017

[0001069202-18-000013:notes:45]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities | $ | 326.1 |  |  | $ | (191.4 | ) |  | $ | (183.0 | ) |  | $ | — |  |  | $ | (48.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (37.2 | ) |  | (6.2 | ) |  | — |  |  | (43.4 | ) |
| Net cash used in investing activities | — |  |  | (37.1 | ) |  | (6.1 | ) |  | — |  |  | (43.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.1 | ) |  | — |  |  | (1.1 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 200.0 |  |  | — |  |  | 200.0 |  |
| Asset securitization payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt payments | (200.0 | ) |  | (0.2 | ) |  | (0.3 | ) |  | — |  |  | (200.5 | ) |
| Borrowings from credit facility | 1,352.5 |  |  | — |  |  | — |  |  | — |  |  | 1,352.5 |  |
| Payments on credit facility | (1,031.0 | ) |  | — |  |  | — |  |  | — |  |  | (1,031.0 | ) |
| Proceeds from employee stock purchases | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |
| Repurchases of common stock | (175.0 | ) |  | — |  |  | — |  |  | — |  |  | (175.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (14.1 | ) |  | — |  |  | — |  |  | — |  |  | (14.1 | ) |
| Intercompany debt | (25.5 | ) |  | 6.4 |  |  | 19.1 |  |  | — |  |  | — |  |
| Intercompany financing activity | (195.4 | ) |  | 230.1 |  |  | (34.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (36.9 | ) |  | — |  |  | — |  |  | — |  |  | (36.9 | ) |
| Net cash (used in) provided by financing activities | (323.9 | ) |  | 236.3 |  |  | 183.0 |  |  | — |  |  | 95.4 |  |
| Increase (decrease) in cash and cash equivalents | 2.2 |  |  | 7.8 |  |  | (6.1 | ) |  | — |  |  | 3.9 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 7.2 |  |  | — |  |  | 7.2 |  |
| Cash and cash equivalents, beginning of period | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 3.4 |  |  | $ | 24.9 |  |  | $ | 33.0 |  |  | $ | — |  |  | $ | 61.3 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001069202-18-000013:notes:46]
[same as prior period, unchanged from 0001069202-18-000009:notes:46]

[0001069202-18-000013:notes:47]
|  | June 30, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (5.0 | ) |  | (7.3 | ) |  | 2.3 |  |  | (31.5 | )% |
| Contract liabilities - noncurrent | (5.6 | ) |  | (5.5 | ) |  | (0.1 | ) |  | 1.8 | % |
| Total | $ | (7.1 | ) |  | $ | (10.7 | ) |  | $ | 3.6 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001069202-18-000013:notes:48]
Lines of Credit and Financing Arrangements:

[0001069202-18-000013:notes:49]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000013:notes:50]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 3.8 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 671.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.9 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,319.0 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,352.6 |  |  | $ | 1,004.0 |  |

[0001069202-18-000013:notes:51]
Short-Term Debt

[0001069202-18-000013:notes:52]
Foreign Obligations

[0001069202-18-000013:notes:53]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $3.8 million and $0.9 million of foreign obligations outstanding as of June 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $21.3 million  and $0.8 million during the six months ended June 30, 2018 and 2017, respectively. Repayments on the facilities were $15.6 million and $1.8 million during the six months ended June 30, 2018 and 2017, respectively.

[0001069202-18-000013:notes:54]
Asset Securitization Program

[0001069202-18-000013:notes:55]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001069202-18-000013:notes:56]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period. The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-18-000013:notes:57]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |

[0001069202-18-000013:notes:58]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2018 and December 31, 2017 were 2.93% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-18-000013:notes:59]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000013:notes:60]
Long-Term Debt

[0001069202-18-000013:notes:61]
Domestic Credit Facility

[0001069202-18-000013:notes:62]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $701.0 million, of which $205.0 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of June 30, 2018. Subject to covenant limitations, $151.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-18-000013:notes:63]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000013:notes:64]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-18-000013:notes:65]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-18-000013:notes:66]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-18-000013:notes:67]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-18-000013:notes:68]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-18-000013:notes:69]
Senior Unsecured Notes

[0001069202-18-000013:notes:70]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-18-000013:notes:71]
[same as prior period, unchanged from 0001069202-18-000009:notes:71]

[0001069202-18-000013:notes:72]
[same as prior period, unchanged from 0001069202-18-000009:notes:72]

[0001069202-18-000013:notes:73]
[same as prior period, unchanged from 0001069202-18-000009:notes:73]

[0001069202-18-000013:notes:74]
[same as prior period, unchanged from 0001069202-18-000009:notes:74]

[0001069202-18-000013:notes:75]
[same as prior period, unchanged from 0001069202-18-000009:notes:75]

[0001069202-18-000013:notes:76]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 intends to simplify the application of hedge accounting guidance and better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results. The amendments expand and refine hedge accounting for both nonfinancial and financial risk components and align the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. We early adopted ASU No. 2017-12 during the first quarter of 2018. The adoption of ASU No. 2017-12 did not have a material impact on our consolidated results of operations, cash flows, and statement of financial position. With the early adoption of ASU No. 2017-12 we began entering into commodity futures contracts designated as cash flow hedges related to aluminum purchases.

[0001069202-18-000013:notes:77]
[same as prior period, unchanged from 0001069202-18-000009:notes:77]

[0001069202-18-000013:notes:78]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through December 2018 and November 2019, respectively.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001069202-18-000013:notes:79]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Unrealized losses (gains) on unsettled contracts | $ | 0.8 |  |  | $ | (11.3 | ) |
| Income tax (benefit) expense | (0.1 | ) |  | 3.9 |  |
| Losses (Gains) included in AOCL, net of tax (1) | $ | 0.7 |  |  | $ | (7.4 | ) |

[0001069202-18-000013:notes:80]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $0.2 million of derivative losses into earnings within the next 12 months.

[0001069202-18-000013:notes:81]
[same as prior period, unchanged from 0001069202-18-000009:notes:81]

[0001069202-18-000013:notes:82]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Copper | 18.2 |  |  | 20.6 |  |
| Aluminum | 24.2 |  |  | — |  |

[0001069202-18-000013:notes:83]
[same as prior period, unchanged from 0001069202-18-000009:notes:83]

[0001069202-18-000013:notes:84]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Mexican Peso | 96.9 |  |  | 207.3 |  |
| Canadian Dollar | 30.3 |  |  | 68.6 |  |

[0001069202-18-000013:notes:85]
[same as prior period, unchanged from 0001069202-18-000009:notes:85]

[0001069202-18-000013:notes:86]
[same as prior period, unchanged from 0001069202-18-000009:notes:86]

[0001069202-18-000013:notes:87]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Copper | 1.4 |  |  | 1.8 |  |
| Aluminum | 1.4 |  |  | 1.8 |  |

[0001069202-18-000013:notes:88]
[same as prior period, unchanged from 0001069202-18-000009:notes:88]

[0001069202-18-000013:notes:89]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Notional Amounts (in local currency): |  |  |  |
| Chinese Yuan | 7.5 |  |  | 73.8 |  |
| Mexican Peso | 47.0 |  |  | 136.6 |  |
| Euro | 28.0 |  |  | 64.4 |  |
| Canadian Dollar | 12.0 |  |  | 27.3 |  |
| British Pound | 3.9 |  |  | 4.5 |  |
| Singapore Dollar | — |  |  | 7.0 |  |
| Australian Dollar | — |  |  | 107.0 |  |
| New Zealand Dollar | — |  |  | 5.0 |  |
| Indian Rupee | — |  |  | 39.8 |  |

[0001069202-18-000013:notes:90]
[same as prior period, unchanged from 0001069202-18-000009:notes:90]

[0001069202-18-000013:notes:91]
[same as prior period, unchanged from 0001069202-18-000009:notes:91]

[0001069202-18-000013:notes:92]
|  | Fair Values of Derivative Instruments (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated as Hedging Instruments |
|  | As of June 30, 2018 |  | As of December 31, 2017 |  | As of June 30, 2018 |  | As of December 31, 2017 |
| Current Assets: |  |  |  |  |  |  |  |
| Other Assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 0.7 |  |  | $ | 11.0 |  |  | $ | — |  |  | $ | 1.2 |  |
| Foreign currency forward contracts | 1.4 |  |  | 0.1 |  |  | — |  |  | 0.9 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other Assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | — |  |  | 0.6 |  |  | — |  |  | 0.1 |  |
| Total Assets | $ | 2.1 |  |  | $ | 11.7 |  |  | $ | — |  |  | $ | 2.2 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued Expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 2.3 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |
| Foreign currency forward contracts | — |  |  | 0.3 |  |  | 0.2 |  |  | 1.1 |  |
| Non-Current Liabilities: |  |  |  |  |  |  |  |
| Other Liabilities |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Total Liabilities | $ | 2.8 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |

[0001069202-18-000013:notes:93]
[same as prior period, unchanged from 0001069202-18-000009:notes:93]

[0001069202-18-000013:notes:94]
| Derivatives Designated as Cash Flow Hedges |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amount of Gain reclassified from AOCL into Income (effective portion) (1) |  | $ | (2.6 | ) |  | $ | (2.8 | ) |  | $ | (7.2 | ) |  | $ | (5.9 | ) |
| Amount of Loss recognized in Net income (ineffective portion) (2)(3) |  | — |  |  | — |  |  | $ | — |  |  | $ | 1.1 |  |

[0001069202-18-000013:notes:95]
| Derivatives Not Designated as Hedging Instruments |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amount of (Gain)/Loss Recognized in Net Income: |  |  |  |  |  |  |  |  |
| Commodity futures contracts (2) |  | $ | (0.1 | ) |  | $ | (0.2 | ) |  | $ | 0.6 |  |  | $ | (1.1 | ) |
| Foreign currency forward contracts (2) |  | 0.2 |  |  | (3.1 | ) |  | (0.2 | ) |  | (3.9 | ) |
|  |  | $ | 0.1 |  |  | $ | (3.3 | ) |  | $ | 0.4 |  |  | $ | (5.0 | ) |

[0001069202-18-000013:notes:96]
[same as prior period, unchanged from 0001069202-18-000009:notes:96]

[0001069202-18-000013:notes:97]
[same as prior period, unchanged from 0001069202-18-000009:notes:97]

[0001069202-18-000013:notes:98]
(3) ASU 2017-12 eliminates the requirement to disclose the amount of hedge ineffectiveness prospectively because this        amount is no longer separately measured and reported.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-18-000013:notes:99]
[same as prior period, unchanged from 0001069202-18-000009:notes:99]

[0001069202-18-000013:notes:100]
[same as prior period, unchanged from 0001069202-18-000009:notes:100]

[0001069202-18-000013:notes:101]
|  | For the Three Months Ended June 30, | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 | 2018 |  | 2017 |
| Stock-based compensation expense (1) | $ | 8.8 |  |  | $ | 7.6 |  | $ | 13.6 |  |  | $ | 12.5 |  |

[0001069202-18-000013:notes:102]
[same as prior period, unchanged from 0001069202-18-000009:notes:102]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-18-000013:notes:103]
:

[0001069202-18-000013:notes:104]
Australia, New Zealand and Asia Divestiture:

[0001069202-18-000013:notes:105]
During the first quarter of 2018, we obtained board approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia, New Zealand and Asia business except for the Milperra property. We completed the sale to Beijer Ref AB in the second quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-18-000013:notes:106]
| (Amounts in millions) | For the Six Months Ended June 30, 2018 |
| Cash received from the buyer | $ | 80.1 |  |
| Net assets sold (1) | (83.4 | ) |
| AOCI reclassification adjustments, primarily foreign currency translation | (3.2 | ) |
| Direct costs to sell | (5.5 | ) |
| Loss on sale of business | $ | (12.0 | ) |

[0001069202-18-000013:notes:107]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia, New Zealand and Asia business.

[0001069202-18-000013:notes:108]
The Milperra property was sold during the quarter ended June 30, 2018. We received net cash proceeds of $37.2 million net of direct costs to sell of $1.5 million. The net gain recognized in connection with this sale was $23.8 million.

[0001069202-18-000013:notes:109]
Brazil Divestiture:

[0001069202-18-000013:notes:110]
During the second quarter of 2018, we obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale is subject to Brazilian antitrust approval and is expected to close later this year.

[0001069202-18-000013:notes:111]
The following table presents the assets and liabilities associated with our Brazilian businesses classified as held for sale as of June 30, 2018, which included $19.7 million of foreign currency translation losses reclassified out of AOCI.

[0001069202-18-000013:notes:112]
| (Amounts in millions) | As of June 30, 2018 |
| Assets held for sale |  |
| Accounts and notes receivable, net of allowances | $ | 4.5 |  |
| Inventories, net | 5.0 |  |
| Other assets | 2.1 |  |
| Total assets held for sale | $ | 11.6 |  |
| Liabilities held for sale |  |
| Short-term debt | $ | 1.4 |  |
| Accounts payable | 2.2 |  |
| Accrued expenses | 3.5 |  |
| Income taxes payable | 0.1 |  |
| Other liabilities | 0.2 |  |
| Total liabilities held for sale | $ | 7.4 |  |

[0001069202-18-000013:notes:113]
Based on the expected proceeds from the sale, net of selling costs, we recorded a loss on the assets held for sale of $31.4 million during the quarter ended June 30, 2018.


## us-gaap:EarningsPerShareTextBlock

[0001069202-18-000013:notes:114]
[same as prior period, unchanged from 0001069202-18-000009:notes:108]

[0001069202-18-000013:notes:115]
[same as prior period, unchanged from 0001069202-18-000009:notes:109]

[0001069202-18-000013:notes:116]
[same as prior period, unchanged from 0001069202-18-000009:notes:110]

[0001069202-18-000013:notes:117]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income | $ | 137.6 |  |  | $ | 115.5 |  |  | $ | 175.5 |  |  | $ | 159.0 |  |
| Add: Loss from discontinued operations | 1.6 |  |  | 0.9 |  |  | 1.6 |  |  | 0.9 |  |
| Income from continuing operations | $ | 139.2 |  |  | $ | 116.4 |  |  | $ | 177.1 |  |  | $ | 159.9 |  |
| Weighted-average shares outstanding – basic | 40.7 |  |  | 42.3 |  |  | 41.1 |  |  | 42.6 |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.4 |  |  | 0.6 |  |  | 0.5 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 41.1 |  |  | 42.9 |  |  | 41.6 |  |  | 43.2 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.42 |  |  | $ | 2.75 |  |  | $ | 4.31 |  |  | $ | 3.76 |  |
| Loss from discontinued operations | (0.04 | ) |  | (0.02 | ) |  | (0.04 | ) |  | (0.02 | ) |
| Net income | $ | 3.38 |  |  | $ | 2.73 |  |  | $ | 4.27 |  |  | $ | 3.74 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 3.39 |  |  | $ | 2.71 |  |  | $ | 4.26 |  |  | $ | 3.70 |  |
| Loss from discontinued operations | (0.04 | ) |  | (0.02 | ) |  | (0.04 | ) |  | (0.02 | ) |
| Net income | $ | 3.35 |  |  | $ | 2.69 |  |  | $ | 4.22 |  |  | $ | 3.68 |  |

[0001069202-18-000013:notes:118]
[same as prior period, unchanged from 0001069202-18-000009:notes:112]

[0001069202-18-000013:notes:119]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Weighted-average number of shares | 0.2 |  |  | — |  |  | 0.2 |  |  | 0.2 |  |
| Price per share | $ | 205.53 |  |  | $ | — |  |  | $ | 205.53 |  |  | $ | 156.94 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-18-000013:notes:120]
[same as prior period, unchanged from 0001069202-18-000009:notes:114]

[0001069202-18-000013:notes:121]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Senior unsecured notes | $ | 292.4 |  |  | $ | 308.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-18-000013:notes:122]
[same as prior period, unchanged from 0001069202-18-000009:notes:116]

[0001069202-18-000013:notes:123]
[same as prior period, unchanged from 0001069202-18-000009:notes:117]

[0001069202-18-000013:notes:124]
The methodologies used to determine the fair value of our financial assets and liabilities at June 30, 2018 were the same as those used at December 31, 2017.

[0001069202-18-000013:notes:125]
[same as prior period, unchanged from 0001069202-18-000009:notes:119]

[0001069202-18-000013:notes:126]
[same as prior period, unchanged from 0001069202-18-000009:notes:120]

[0001069202-18-000013:notes:127]
[same as prior period, unchanged from 0001069202-18-000009:notes:121]

[0001069202-18-000013:notes:128]
[same as prior period, unchanged from 0001069202-18-000009:notes:122]

[0001069202-18-000013:notes:129]
The following table presents the fair value of an investment in marketable equity securities, classified as Level 1 and related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions). This investment was sold as part of our divestiture of our Australia, New Zealand and Asia business. Refer to Note 14 for details regarding divestiture of the business.

[0001069202-18-000013:notes:130]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Investment in marketable equity securities | $ | — |  |  | $ | 4.1 |  |

[0001069202-18-000013:notes:131]
[same as prior period, unchanged from 0001069202-18-000009:notes:125]

[0001069202-18-000013:notes:132]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-18-000013:notes:133]
[same as prior period, unchanged from 0001069202-18-000009:notes:127]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-18-000013:notes:134]
[same as prior period, unchanged from 0001069202-18-000009:notes:128]

[0001069202-18-000013:notes:135]
The changes in the carrying amount of goodwill for the first six months of 2018, in total and by segment, are summarized in the table below (in millions):

[0001069202-18-000013:notes:136]
|  | Balance at December 31, 2017 |  | Transfer to assets held for sale |  | Changes in foreign currency translation rates |  | Balance at June 30, 2018 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 62.2 |  |  | — |  |  | (0.6 | ) |  | 61.6 |  |
| Refrigeration | 112.2 |  |  | (11.5 | ) |  | (1.6 | ) |  | 99.1 |  |
| Total Goodwill | $ | 200.5 |  |  | $ | (11.5 | ) |  | $ | (2.2 | ) |  | $ | 186.8 |  |

[0001069202-18-000013:notes:137]
We perform our annual goodwill impairment test in the fourth quarter of each year.  We continue to monitor our reporting units for indicators of impairment throughout the year to determine if a change in facts or circumstances warrants a re-evaluation of our goodwill.  In the current year, as a part of the completed sale of our Australia, New Zealand and Asia business and the planned sale of our Brazil business (discussed further in Note 14 of the Notes to the Consolidated Financial Statements) we transferred $11.5 million of goodwill to assets held for sale.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-18-000013:notes:138]
[same as prior period, unchanged from 0001069202-18-000009:notes:132]

[0001069202-18-000013:notes:139]
As of June 30, 2018, we had approximately $0.3 million in total gross unrecognized tax benefits and of this amount, all if recognized, would be recorded through the Consolidated Statement of Operations.  As of June 30, 2018, we had an insignificant amount in interest recognized in income tax expense in accordance with FASB Accounting Standards Codification (“ASC”) Topic 740.

[0001069202-18-000013:notes:140]
We are currently under examination for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2018, and 2017 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as France, India and Germany. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2011.

[0001069202-18-000013:notes:141]
[same as prior period, unchanged from 0001069202-18-000009:notes:135]

[0001069202-18-000013:notes:142]
On October 24, 2016, the FASB issued ASU No. 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory, which requires companies to recognize the income tax effects of intercompany sales and transfers of assets other than inventory in the period in which the transfer occurs.  Prior to ASU 2016-16, companies were required to defer the income tax effects of intercompany transfers of assets until the asset had been sold to an outside party or otherwise recognized.  The new guidance is effective for public business entities for annual periods beginning after December 15, 2017 and interim periods within those annual periods.  The guidance requires companies to apply a modified retrospective approach with a cumulative catch-up adjustment to opening retained earnings in the period of adoption.  Accordingly, we recorded a $5.1 million decrease to opening retained earnings in the period ending March 31, 2018.

[0001069202-18-000013:notes:143]
[same as prior period, unchanged from 0001069202-18-000009:notes:137]

[0001069202-18-000013:notes:144]
On February 14, 2018, the FASB issued ASU No. 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits companies to reclassify stranded tax effects caused by 2017 tax reform between accumulated other comprehensive income (“AOCI”) and retained earnings.  We have elected to adopt ASU 2018-02 to reclassify the income tax effects of the 2017 Act from AOCI to retained earnings for the period ending March 31, 2018.  Accordingly, we recorded a $22.7 million increase to opening retained earnings in the period ending March 31, 2018 to reclassify the effect of the change in the U.S. federal corporate income tax rate, including the reduction in the federal benefit associated with state taxes, on the gross deferred tax amounts and related valuation allowances at the date of enactment of the Tax Cuts and Jobs Act related to items remaining in AOCI.

[0001069202-18-000013:notes:145]
The SEC staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements.  If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001069202-18-000013:notes:146]
Due to the Tax Act, several applications for changes in accounting method have been filed with the IRS to accelerate deductions into the 2017 U.S. federal income tax return.  As of June 30, 2018 we have recognized discrete tax benefits of $3.8 million associated with the finalization of the calculations for accounting method changes for prepaid expenses, IBNR medical expenses and depreciable asset reclassifications and repairs.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-18-000013:notes:147]
[same as prior period, unchanged from 0001069202-18-000009:notes:139]

[0001069202-18-000013:notes:148]
[same as prior period, unchanged from 0001069202-18-000009:notes:140]

[0001069202-18-000013:notes:149]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Finished goods | $ | 365.3 |  |  | $ | 331.9 |  |
| Work in process | 6.4 |  |  | 5.5 |  |
| Raw materials and parts | 221.0 |  |  | 199.2 |  |
| Subtotal | 592.7 |  |  | 536.6 |  |
| Excess of current cost over last-in, first-out cost | (52.5 | ) |  | (52.4 | ) |
| Total inventories, net | $ | 540.2 |  |  | $ | 484.2 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001069202-18-000013:notes:150]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative assessment of our lease portfolio and are in the process of implementing a new system, collecting data and designing processes and controls to account for our leases in accordance with the new standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001069202-18-000013:notes:151]
[same as prior period, unchanged from 0001069202-18-000009:notes:143]

[0001069202-18-000013:notes:152]
[same as prior period, unchanged from 0001069202-18-000009:notes:144]

[0001069202-18-000013:notes:153]
[same as prior period, unchanged from 0001069202-18-000009:notes:145]

[0001069202-18-000013:notes:154]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-18-000013:notes:155]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment. We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate. Volatile equity, foreign currency and commodity markets combine to increase the uncertainty inherent in such estimates and assumptions. Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates. Changes in these estimates will be reflected in the financial statements in future periods.

[0001069202-18-000013:notes:156]
[same as prior period, unchanged from 0001069202-18-000009:notes:148]

[0001069202-18-000013:notes:157]
[same as prior period, unchanged from 0001069202-18-000009:notes:149]

[0001069202-18-000013:notes:158]
Recently Adopted Accounting Guidance

[0001069202-18-000013:notes:159]
In August 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees. For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017. This standard did not have a material impact on our consolidated financial statements.

[0001069202-18-000013:notes:160]
We also adopted other new accounting standards during the first quarter of 2018. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.

[0001069202-18-000013:notes:161]
[same as prior period, unchanged from 0001069202-18-000009:notes:153]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-18-000013:notes:162]
[same as prior period, unchanged from 0001069202-18-000009:notes:154]

[0001069202-18-000013:notes:163]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year's disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-18-000013:notes:164]
[same as prior period, unchanged from 0001069202-18-000009:notes:156]

[0001069202-18-000013:notes:165]
|  | For the Three Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 3.1 |  |  | 3.1 |  |  | — |  |  | — |  |
| Expected return on plan assets | (4.7 | ) |  | (5.4 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.3 | ) |  | (0.6 | ) |
| Recognized actuarial loss | 2.3 |  |  | 2.0 |  |  | 0.3 |  |  | 0.4 |  |
| Settlements and curtailments | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 2.1 |  |  | $ | 1.3 |  |  | $ | — |  |  | $ | (0.2 | ) |

[0001069202-18-000013:notes:166]
|  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Pension Benefits |  | Other Benefits |
| Service cost | $ | 2.7 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 6.2 |  |  | 6.4 |  |  | — |  |  | — |  |
| Expected return on plan assets | (9.4 | ) |  | (10.7 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | (0.7 | ) |  | (1.2 | ) |
| Recognized actuarial loss | 4.6 |  |  | 4.0 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements and curtailments | — |  |  | 0.6 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 4.2 |  |  | $ | 2.9 |  |  | $ | — |  |  | $ | (0.5 | ) |

[0001069202-18-000013:notes:167]
[same as prior period, unchanged from 0001069202-18-000009:notes:158]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-18-000013:notes:168]
[same as prior period, unchanged from 0001069202-18-000009:notes:159]

[0001069202-18-000013:notes:169]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 716.0 |  |  | $ | 653.5 |  |  | $ | 1,169.7 |  |  | $ | 1,073.3 |  |
| Commercial Heating & Cooling | 292.2 |  |  | 258.6 |  |  | 497.7 |  |  | 454.1 |  |
| Refrigeration | 167.2 |  |  | 190.0 |  |  | 342.8 |  |  | 368.2 |  |
|  | $ | 1,175.4 |  |  | $ | 1,102.1 |  |  | $ | 2,010.2 |  |  | $ | 1,895.6 |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 153.6 |  |  | $ | 140.5 |  |  | $ | 204.9 |  |  | $ | 182.9 |  |
| Commercial Heating & Cooling | 52.6 |  |  | 44.7 |  |  | 72.1 |  |  | 63.8 |  |
| Refrigeration | 21.9 |  |  | 21.6 |  |  | 33.0 |  |  | 35.7 |  |
| Corporate and other | (22.8 | ) |  | (23.9 | ) |  | (33.9 | ) |  | (34.8 | ) |
| Total segment profit | 205.3 |  |  | 182.9 |  |  | 276.1 |  |  | 247.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| One time inventory write down | — |  |  | — |  |  | 0.2 |  |  | — |  |
| Special product quality adjustment | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |
| (Gain) loss, net on sale of business and related property | (22.1 | ) |  | — |  |  | (11.8 | ) |  | — |  |
| Loss on assets held for sale | 31.4 |  |  | — |  |  | 31.4 |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 0.4 |  |  | 2.2 |  |  | 6.9 |  |  | 6.0 |  |
| Restructuring charges | 0.5 |  |  | 0.1 |  |  | 1.3 |  |  | 0.2 |  |
| Operating income | $ | 195.1 |  |  | $ | 175.4 |  |  | $ | 248.1 |  |  | $ | 236.2 |  |

[0001069202-18-000013:notes:170]
[same as prior period, unchanged from 0001069202-18-000009:notes:161]

[0001069202-18-000013:notes:171]
[same as prior period, unchanged from 0001069202-18-000009:notes:162]

[0001069202-18-000013:notes:172]
[same as prior period, unchanged from 0001069202-18-000009:notes:163]

[0001069202-18-000013:notes:173]
| ◦ | Special legal contingency charges, |

[0001069202-18-000013:notes:174]
| ◦ | Asbestos-related litigation, |

[0001069202-18-000013:notes:175]
[same as prior period, unchanged from 0001069202-18-000009:notes:166]

[0001069202-18-000013:notes:176]
[same as prior period, unchanged from 0001069202-18-000009:notes:167]

[0001069202-18-000013:notes:177]
| ◦ | Divestiture costs, |

[0001069202-18-000013:notes:178]
[same as prior period, unchanged from 0001069202-18-000009:notes:169]

[0001069202-18-000013:notes:179]
[same as prior period, unchanged from 0001069202-18-000009:notes:170]

[0001069202-18-000013:notes:180]
| • | (Gain) loss, net on sale of business and related property, |

[0001069202-18-000013:notes:181]
[same as prior period, unchanged from 0001069202-18-000009:notes:171]

[0001069202-18-000013:notes:182]
[same as prior period, unchanged from 0001069202-18-000009:notes:172]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-18-000013:notes:183]
[same as prior period, unchanged from 0001069202-18-000009:notes:173]

[0001069202-18-000013:notes:184]
[same as prior period, unchanged from 0001069202-18-000009:notes:174]

[0001069202-18-000013:notes:185]
[same as prior period, unchanged from 0001069202-18-000009:notes:175]

[0001069202-18-000013:notes:186]
[same as prior period, unchanged from 0001069202-18-000009:notes:176]

[0001069202-18-000013:notes:187]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Severance and related expense | $ | 0.3 |  |  | $ | 11.6 |  |  | $ | 11.6 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | 0.7 |  |  | 0.9 |  |  | 0.9 |  |
| Other | 0.3 |  |  | 4.4 |  |  | 5.7 |  |
| Total restructuring charges | $ | 1.3 |  |  | $ | 20.1 |  |  | $ | 21.4 |  |

[0001069202-18-000013:notes:188]
[same as prior period, unchanged from 0001069202-18-000009:notes:178]

[0001069202-18-000013:notes:189]
|  | Charges Incurred in 2018 |  | Charges Incurred to Date |  | Total Charges Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.3 |  |  | $ | 1.7 |  |  | $ | 3.0 |  |
| Commercial Heating & Cooling | 0.7 |  |  | 2.7 |  |  | 2.7 |  |
| Refrigeration | 0.3 |  |  | 13.4 |  |  | 13.4 |  |
| Corporate & Other | — |  |  | 2.3 |  |  | 2.3 |  |
| Total restructuring charges | $ | 1.3 |  |  | $ | 20.1 |  |  | $ | 21.4 |  |

[0001069202-18-000013:notes:190]
[same as prior period, unchanged from 0001069202-18-000009:notes:180]

[0001069202-18-000013:notes:191]
|  | Balance as ofDecember 31, 2017 |  | Included inEarnings |  | CashUtilization |  | Non-Cash Utilization and Other |  | Balance as of June 30,2018 |
| Severance and related expense | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | (0.4 | ) |  | $ | — |  |  | $ | 0.1 |  |
| Lease termination | — |  |  | 0.7 |  |  | — |  |  | (0.2 | ) |  | 0.5 |  |
| Other | — |  |  | 0.3 |  |  | (0.3 | ) |  | — |  |  | — |  |
| Total restructuring accruals | $ | 0.2 |  |  | $ | 1.3 |  |  | $ | (0.7 | ) |  | $ | (0.2 | ) |  | $ | 0.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-18-000013:notes:192]
[same as prior period, unchanged from 0001069202-18-000009:notes:182]

[0001069202-18-000013:notes:193]
On January 1, 2018, we adopted the new accounting standard ASC 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

[0001069202-18-000013:notes:194]
[same as prior period, unchanged from 0001069202-18-000009:notes:184]

[0001069202-18-000013:notes:195]
[same as prior period, unchanged from 0001069202-18-000009:notes:185]

[0001069202-18-000013:notes:196]
[same as prior period, unchanged from 0001069202-18-000009:notes:186]

[0001069202-18-000013:notes:197]
|  | June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 741.3 |  |  | $ | 730.5 |  |  | $ | 10.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 437.5 |  |  | 424.2 |  |  | 13.3 |  |
| Retained earnings | 1,722.8 |  |  | 1,725.3 |  |  | (2.5 | ) |
|  | For the Three Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,175.4 |  |  | $ | 1,175.5 |  |  | $ | (0.1 | ) |
| Net income | 137.6 |  |  | 137.6 |  |  | — |  |

[0001069202-18-000013:notes:198]
|  | For the Six Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 2,010.2 |  |  | $ | 2,010.4 |  |  | $ | (0.2 | ) |
| Net income | 175.5 |  |  | 175.5 |  |  | — |  |

[0001069202-18-000013:notes:199]
[same as prior period, unchanged from 0001069202-18-000009:notes:188]

[0001069202-18-000013:notes:200]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 716.0 |  |  | $ | 252.1 |  |  | $ | 127.6 |  |  | $ | 1,095.7 |  |
| Europe | — |  |  | 40.1 |  |  | 29.0 |  |  | 69.1 |  |
| Asia Pacific | — |  |  | — |  |  | 10.6 |  |  | 10.6 |  |
| Total | $ | 716.0 |  |  | 292.2 |  |  | 167.2 |  |  | 1,175.4 |  |

[0001069202-18-000013:notes:201]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,169.7 |  |  | $ | 431.2 |  |  | $ | 237.4 |  |  | $ | 1,838.3 |  |
| Europe | — |  |  | 66.5 |  |  | 55.7 |  |  | 122.2 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,169.7 |  |  | 497.7 |  |  | 342.8 |  |  | 2,010.2 |  |

[0001069202-18-000013:notes:202]
[same as prior period, unchanged from 0001069202-18-000009:notes:190]

[0001069202-18-000013:notes:203]
[same as prior period, unchanged from 0001069202-18-000009:notes:191]

[0001069202-18-000013:notes:204]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and six months ended June 30, 2018, direct sales represent approximately $546.7 million and $886.3 million of revenues and sales to independent distributors represent approximately $169.3 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-18-000013:notes:205]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and six months ended June 30, 2018, equipment sales represent approximately $279.3 million and $457.2 million of revenues while $12.9 million and $40.5 million of our revenue is generated from our service business, respectively.

[0001069202-18-000013:notes:206]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $165.4 million and $339 million for the three and six months ended June 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-18-000013:notes:207]
[same as prior period, unchanged from 0001069202-18-000009:notes:195]

[0001069202-18-000013:notes:208]
[same as prior period, unchanged from 0001069202-18-000009:notes:196]

[0001069202-18-000013:notes:209]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

[0001069202-18-000013:notes:210]
[same as prior period, unchanged from 0001069202-18-000009:notes:198]

[0001069202-18-000013:notes:211]
For the three and six months ended June 30, 2018, we recognized revenue of $1.3 million and $2.9 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2018.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-18-000013:notes:212]
The following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001069202-18-000013:notes:213]
[same as prior period, unchanged from 0001069202-18-000009:notes:200]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-18-000013:notes:214]
[same as prior period, unchanged from 0001069202-18-000009:notes:201]

[0001069202-18-000013:notes:215]
| Segment |  | Product or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment |  | Light Commercial |  | United StatesCanadaEuropeCentral AmericaSouth America |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial;Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia Pacific*South AmericaCentral America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-18-000013:notes:216]
[same as prior period, unchanged from 0001069202-18-000009:notes:203]

[0001069202-18-000013:notes:217]
[same as prior period, unchanged from 0001069202-18-000009:notes:204]

[0001069202-18-000013:notes:218]
*Our business in the Asia Pacific area was sold in the second quarter of 2018. Refer to Note 14 for details regarding the divestiture of the business.

[0001069202-18-000013:notes:219]
[same as prior period, unchanged from 0001069202-18-000009:notes:205]

[0001069202-18-000013:notes:220]
[same as prior period, unchanged from 0001069202-18-000009:notes:206]

[0001069202-18-000013:notes:221]
[same as prior period, unchanged from 0001069202-18-000009:notes:207]

[0001069202-18-000013:notes:222]
[same as prior period, unchanged from 0001069202-18-000009:notes:208]

[0001069202-18-000013:notes:223]
[same as prior period, unchanged from 0001069202-18-000009:notes:209]

[0001069202-18-000013:notes:224]
[same as prior period, unchanged from 0001069202-18-000009:notes:210]

[0001069202-18-000013:notes:225]
Except for the seasonal increase in total assets across all reportable segments, there have not been any material changes in the composition of total assets by segment since December 31, 2017; however, during the quarter we have sold our Australia, New Zealand and Asia business and reclassified assets and liabilities related to our Brazil business as Assets held for sale in our Consolidated Balance Sheet. Refer to Note 14 for details regarding divestiture of businesses.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001069202-18-000013:notes:226]
[same as prior period, unchanged from 0001069202-18-000009:notes:212]

[0001069202-18-000013:notes:227]
Our Board of Directors has authorized a total of $2.5 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $500 million share repurchase authorization in  March 2018. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of June 30, 2018, $546 million of shares may yet be repurchased under the Share Repurchase Plans.

[0001069202-18-000013:notes:228]
[same as prior period, unchanged from 0001069202-18-000009:notes:214]

[0001069202-18-000013:notes:229]
We repurchased 1.0 million shares for $200.2 million from open market transactions during the second quarter of 2018.

[0001069202-18-000013:notes:230]
We also repurchased 0.1 million shares for $18.6 million during the six months ended June 30, 2018 from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the exercise of long-term incentive awards.


## us-gaap:SubsequentEventsTextBlock

[0001069202-18-000013:notes:231]
Subsequent Event:

[0001069202-18-000013:notes:232]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado. The extent of damage to the facility is being assessed and we currently do not have an estimate of the financial or operational impact of the damage, including any potential insurance recoveries.
