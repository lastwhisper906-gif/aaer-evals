# LII MD&A — 0001069202-18-000013


## mdna

[0001069202-18-000013:mdna:1]
[same as prior period, unchanged from 0001069202-18-000009:mdna:1]

[0001069202-18-000013:mdna:2]
[same as prior period, unchanged from 0001069202-18-000009:mdna:2]

[0001069202-18-000013:mdna:3]
[same as prior period, unchanged from 0001069202-18-000009:mdna:3]

[0001069202-18-000013:mdna:4]
[same as prior period, unchanged from 0001069202-18-000009:mdna:4]

[0001069202-18-000013:mdna:5]
[same as prior period, unchanged from 0001069202-18-000009:mdna:5]

[0001069202-18-000013:mdna:6]
[same as prior period, unchanged from 0001069202-18-000009:mdna:6]

[0001069202-18-000013:mdna:7]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado. The extent of damage to the facility is being assessed and we currently do not have an estimate of the financial or operational impact of the damage, including any potential insurance recoveries.

[0001069202-18-000013:mdna:8]
[same as prior period, unchanged from 0001069202-18-000009:mdna:7]

[0001069202-18-000013:mdna:9]
In the second quarter of 2018, the Commercial Heating & Cooling segment led our overall operational performance with a 13% increase in net sales and had $8 million in increased segment profit compared to the second quarter of 2017.  The primary growth driver for this segment was volume gains. Our Residential Heating & Cooling segment had a 10% increase in net sales and had $13 million in increased segment profit compared to the second quarter of 2017.  This segment's profits were up largely due to higher volumes and favorable price and mix combined.  Sales in our Refrigeration segment decreased by 12% due to the sale of our Australia, New Zealand and Asia business and segment profit was relatively flat compared to the the second quarter of 2017.

[0001069202-18-000013:mdna:10]
[same as prior period, unchanged from 0001069202-18-000009:mdna:10]

[0001069202-18-000013:mdna:11]
| • | Net sales increased $73 million, or 7%, to $1,175 million in the the second quarter of 2018 compared to the the second quarter of 2017. |

[0001069202-18-000013:mdna:12]
| • | Operating income in the the second quarter of 2018 increased $20 million to $195 million. |

[0001069202-18-000013:mdna:13]
| • | Net income for the the second quarter of 2018 increased $22 million to $138 million, including the $31 million loss on assets held for sale in the the second quarter of 2018 partially offset by the benefit of $22 million of gain (loss), net on sale of business and related property. |

[0001069202-18-000013:mdna:14]
| • | Diluted earnings per share from continuing operations were $3.39 per share in the the second quarter of 2018 compared to $2.71 per share in the the second quarter of 2017. |

[0001069202-18-000013:mdna:15]
| • | During the six months ended June 30, 2018, we returned $42 million to shareholders through dividend payments and have repurchased $350 million of common stock. We also received $112 million in proceeds from the sale of our businesses in Australia, New Zealand and Asia along with the sale of the related property. |

[0001069202-18-000013:mdna:16]
Second Quarter of 2018 Compared to Second Quarter of 2017 - Consolidated Results

[0001069202-18-000013:mdna:17]
[same as prior period, unchanged from 0001069202-18-000009:mdna:17]

[0001069202-18-000013:mdna:18]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 1,175.4 |  |  | $ | 1,102.1 |  |  | 6.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 813.8 |  |  | 761.3 |  |  | (6.9 | ) |  | 69.2 |  |  | 69.1 |  |
| Gross profit | 361.6 |  |  | 340.8 |  |  | 6.1 |  |  | 30.8 |  |  | 30.9 |  |
| Selling, general and administrative expenses | 161.4 |  |  | 168.5 |  |  | 4.2 |  |  | 13.7 |  |  | 15.3 |  |
| Losses and other expenses, net | 0.2 |  |  | 2.3 |  |  | 91.3 |  |  | — |  |  | 0.2 |  |
| Restructuring charges | 0.5 |  |  | 0.1 |  |  | (400.0 | ) |  | — |  |  | — |  |
| (Gain) loss, net on sale of business and related property | (22.1 | ) |  | — |  |  | N/A |  | (1.9 | ) |  | — |  |
| Loss on assets held for sale | 31.4 |  |  | — |  |  | N/A |  | 2.7 |  |  | — |  |
| Income from equity method investments | (4.9 | ) |  | (5.5 | ) |  | (10.9 | ) |  | (0.4 | ) |  | (0.5 | ) |
| Operating income | $ | 195.1 |  |  | $ | 175.4 |  |  | 11.2 | % |  | 16.6 | % |  | 15.9 | % |

[0001069202-18-000013:mdna:19]
[same as prior period, unchanged from 0001069202-18-000009:mdna:19]

[0001069202-18-000013:mdna:20]
Net sales increased 7% in the the second quarter of 2018 compared to the the second quarter of 2017, primarily from 7% higher sales volumes, 2% from favorable price and 1% from favorable foreign currency exchange rates.  These increases were partially offset by 1% lower mix and 2% related to our divested businesses in Australia, New Zealand and Asia.  The Residential Heating & Cooling segment delivered higher volume from increased replacement equipment, new construction business and increased parts and supplies sales.  The Commercial Heating & Cooling segment delivered higher volume from our North American equipment business as well as higher volume from our North American Service business. The Refrigeration sales declined due to our divested businesses in Australia, New Zealand and Asia.

[0001069202-18-000013:mdna:21]
[same as prior period, unchanged from 0001069202-18-000009:mdna:21]

[0001069202-18-000013:mdna:22]
Gross profit margin in the the second quarter of 2018 decreased to 30.8% compared to 30.9% in the the second quarter of 2017.

[0001069202-18-000013:mdna:23]
We saw decreases in profit margin of 110 basis points ("bps") from higher commodity prices, 100 bps from higher freight and distribution costs, 20 bps from other costs and 10 bps from product warranties.  Partially offsetting these decreases were positive margin increases of 100 bps from favorable price, 70 bps from lower material costs, 50 bps related to a product quality issue from the prior year, and 10 bps from favorable foreign currency exchange rates.

[0001069202-18-000013:mdna:24]
[same as prior period, unchanged from 0001069202-18-000009:mdna:23]

[0001069202-18-000013:mdna:25]
Selling, general and administrative expenses, or SG&A, was $161 million in the the second quarter of 2018 compared to $169 million in the the second quarter of 2017, and as a percentage of net sales decreased 160 bps to 13.7%.  SG&A decreased primarily due to decreased discretionary spending.

[0001069202-18-000013:mdna:26]
[same as prior period, unchanged from 0001069202-18-000009:mdna:25]

[0001069202-18-000013:mdna:27]
Losses and other expenses, net for the the second quarter of 2018 and 2017 included the following (in millions):

[0001069202-18-000013:mdna:28]
|  | For the Three Months Ended June 30, |
|  | 2018 |  | 2017 |
| Realized gains on settled future contracts | $ | (0.2 | ) |  | $ | (0.4 | ) |
| Foreign currency exchange (gains) losses | (0.1 | ) |  | 0.5 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized losses on unsettled futures contracts | 0.1 |  |  | 0.1 |  |
| Special legal contingency charges | 1.5 |  |  | 1.2 |  |
| Asbestos-related litigation | (0.2 | ) |  | 0.7 |  |
| Environmental liabilities | 0.9 |  |  | 0.2 |  |
| Divestiture costs | (2.5 | ) |  | — |  |
| Other items, net | 0.6 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 0.2 |  |  | $ | 2.3 |  |

[0001069202-18-000013:mdna:29]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Divestiture costs related to costs incurred to sell our businesses in Australia, New Zealand, China and Brazil.  Divestiture costs incurred in Q1 2018 related to the sales of the Australia and Asia business and the related property were reclassified to (Gain) loss, net on sale of business and related property in Q2 2018.  See Note 14 in the Notes to the Consolidated Financial Statements for further details.

[0001069202-18-000013:mdna:30]
[same as prior period, unchanged from 0001069202-18-000009:mdna:29]

[0001069202-18-000013:mdna:31]
Restructuring charges were less than $1 million in the the second quarter of 2018. The charges in 2018 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000013:mdna:32]
[same as prior period, unchanged from 0001069202-18-000009:mdna:31]

[0001069202-18-000013:mdna:33]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $5 million in the the second quarter of 2018 was relatively flat when compared to the the second quarter of 2017.

[0001069202-18-000013:mdna:34]
[same as prior period, unchanged from 0001069202-18-000009:mdna:33]

[0001069202-18-000013:mdna:35]
Interest expense, net of $10 million in the the second quarter of 2018 was up from $8 million in the second quarter of 2017 due to an increase in our average net borrowings and rising interest rates.

[0001069202-18-000013:mdna:36]
[same as prior period, unchanged from 0001069202-18-000009:mdna:35]

[0001069202-18-000013:mdna:37]
We expect our annual effective tax rate to be between 22% and 24%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-18-000013:mdna:38]
Our  effective tax rate was 24.6% for the three months ended June 30, 2018, after the impact of excess tax benefits, compared to 30.4% for the three months ended June 30, 2017, after the impact of excess tax benefits.  The rate for the three months ended June 30, 2018 is lower as compared to the three months ended June 30, 2017 primarily due to the reduced U.S. federal corporate tax rate from enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001069202-18-000013:mdna:39]
Second Quarter of 2018 Compared to Second Quarter of 2017 - Results by Segment

[0001069202-18-000013:mdna:40]
[same as prior period, unchanged from 0001069202-18-000009:mdna:39]

[0001069202-18-000013:mdna:41]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the the second quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:42]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 716.0 |  |  | $ | 653.5 |  |  | $ | 62.5 |  |  | 9.6 | % |
| Profit | $ | 153.6 |  |  | $ | 140.5 |  |  | $ | 13.1 |  |  | 9.3 | % |
| % of net sales | 21.5 | % |  | 21.5 | % |  |  |  |  |

[0001069202-18-000013:mdna:43]
Net sales increased in the the second quarter of 2018 compared to the the second quarter of 2017.  Sales volume increased by 8% and price and mix combined increased by 1%.

[0001069202-18-000013:mdna:44]
Segment profit in the the second quarter of 2018 increased $13 million compared to the the second quarter of 2017 due to $17 million from higher sales volume, $10 million from higher price and mix combined, $3 million from sourcing and engineering-led cost reductions, $2 million from lower SG&A expenses, and $1 million from favorable foreign currency exchange rates.  Partially offsetting these increases was $9 million of freight and costs associated with distribution investments, $8 million in higher commodity costs, and $3 million in higher other product costs.

[0001069202-18-000013:mdna:45]
[same as prior period, unchanged from 0001069202-18-000009:mdna:44]

[0001069202-18-000013:mdna:46]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:47]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 292.2 |  |  | $ | 258.6 |  |  | $ | 33.6 |  |  | 13.0 | % |
| Profit | $ | 52.6 |  |  | $ | 44.7 |  |  | $ | 7.9 |  |  | 17.7 | % |
| % of net sales | 18.0 | % |  | 17.3 | % |  |  |  |  |

[0001069202-18-000013:mdna:48]
Net sales increased by 13% in the second quarter of 2018 compared to the second quarter of 2017.  Sales volume increased 10%, price and mix combined increased by 2%, and favorable foreign currency exchange rates contributed 1%.

[0001069202-18-000013:mdna:49]
Segment profit in the second quarter of 2018 increased by $8 million compared to the second quarter of 2017 due to $8 million from higher sales volume, $4 million from higher price, and $2 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases was $2 million in higher commodity costs, $2 million of freight and costs associated with distribution investments, and $2 million of unfavorable mix.

[0001069202-18-000013:mdna:50]
[same as prior period, unchanged from 0001069202-18-000009:mdna:49]

[0001069202-18-000013:mdna:51]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:52]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 167.2 |  |  | $ | 190.0 |  |  | $ | (22.8 | ) |  | (12.0 | )% |
| Profit | $ | 21.9 |  |  | $ | 21.6 |  |  | $ | 0.3 |  |  | 1.4 | % |
| % of net sales | 13.1 | % |  | 11.4 | % |  |  |  |  |

[0001069202-18-000013:mdna:53]
Net sales decreased 12% in the second quarter of 2018 compared to the second quarter of 2017.  The loss of sales from the divested Asia Pacific business contributed 12%, unfavorable mix decreased sales by 2% which was partially offset by 1% higher price and 1% from favorable foreign currency exchange rates.

[0001069202-18-000013:mdna:54]
Segment profit was relatively flat in the second quarter of 2018 compared to the second quarter of 2017 primarily due to a benefit of $2 million from selling refrigerant allocations in Europe,  $1 million from sourcing and engineering-led cost reductions, $1 million in higher price, and $1 million from favorable foreign currency exchange rates.  Offsetting these increases was $2 million of unfavorable mix, $1 million in higher commodity costs, $1 million in higher freight and distribution cost, and $1 million of lost profit from the divested businesses.

[0001069202-18-000013:mdna:55]
[same as prior period, unchanged from 0001069202-18-000009:mdna:54]

[0001069202-18-000013:mdna:56]
Corporate and other expenses were $1 million lower in the second quarter of 2018 compared to the second quarter of 2017 due to a non-recurring foreign currency hedge loss in 2017.

[0001069202-18-000013:mdna:57]
Year-to-Date through June 30, 2018 Compared to Year-to-Date through June 30, 2017 - Consolidated Results

[0001069202-18-000013:mdna:58]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-18-000013:mdna:59]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 2,010.2 |  |  | $ | 1,895.6 |  |  | 6.0 |  |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,425.5 |  |  | 1,343.8 |  |  | (6.1 | ) |  | 70.9 |  |  | 70.9 |  |
| Gross profit | 584.7 |  |  | 551.8 |  |  | 6.0 |  |  | 29.1 |  |  | 29.1 |  |
| Selling, general and administrative expenses | 316.6 |  |  | 320.9 |  |  | 1.3 |  |  | 15.7 |  |  | 16.9 |  |
| Losses and other expenses, net | 7.5 |  |  | 5.4 |  |  | (38.9 | ) |  | 0.4 |  |  | 0.3 |  |
| Restructuring charges | 1.3 |  |  | 0.2 |  |  | (550.0 | ) |  | 0.1 |  |  | — |  |
| (Gain) loss, net on sale of business and related property | (11.8 | ) |  | — |  |  | N/A |  |  | (0.6 | ) |  | — |  |
| Loss on assets held for sale | 31.4 |  |  | — |  |  | N/A |  |  | 1.6 |  |  | — |  |
| Income from equity method investments | (8.4 | ) |  | (10.9 | ) |  | (22.9 | ) |  | (0.4 | ) |  | (0.6 | ) |
| Operating income | $ | 248.1 |  |  | $ | 236.2 |  |  | 5.0 |  |  | 12.3 | % |  | 12.5 | % |

[0001069202-18-000013:mdna:60]
Net Sales

[0001069202-18-000013:mdna:61]
Net sales increased 6% in the first six months of 2018 compared to the first six months of 2016 due to a 5% increase in sales volumes, 1% from favorable price and 1% from favorable foreign currency exchange rates.  These increases were partially offset by 1% related to our divested businesses in Australia, New Zealand and Asia.  The Residential Heating & Cooling segment delivered higher volume from increased replacement equipment, new construction business and increased parts and supplies sales.  The Commercial Heating & Cooling segment delivered higher volume from our North American equipment business as well as higher volume from our North American Service business. The Refrigeration sales declined due to our divested businesses in Australia, New Zealand and Asia.

[0001069202-18-000013:mdna:62]
Gross Profit

[0001069202-18-000013:mdna:63]
Gross profit margins in the first six months of 2018 was flat at 29.1% when compared to the first six months of 2017.  Our profit margin increased 100 bps from favorable price and mix combined, 90 bps from material cost savings, and 30 bps related to a product quality issue from the prior year.  Offsetting these increases were decreases of 110 bps from higher commodity costs and 110 bps from freight and distribution.

[0001069202-18-000013:mdna:64]
Selling, General and Administrative Expenses

[0001069202-18-000013:mdna:65]
SG&A was $317 million for the first six months of 2018 compared to $321 million for the first six months of 2017, and as a percentage of net sales, decreased 120 bps to 15.7% from 16.9%. SG&A decreased due to decreased discretionary spending.

[0001069202-18-000013:mdna:66]
Losses and Other Expenses, Net

[0001069202-18-000013:mdna:67]
Losses and other expenses, net for the first six months of 2018 and 2017 included the following (in millions):

[0001069202-18-000013:mdna:68]
|  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |
| Realized gains on settled future contracts | $ | (0.7 | ) |  | $ | (0.8 | ) |
| Foreign currency exchange losses | 1.2 |  |  | 0.2 |  |
| Loss on disposal of fixed assets | 0.1 |  |  | — |  |
| Net change in unrealized losses on unsettled futures contracts | 1.3 |  |  | 0.9 |  |
| Special legal contingency charges | 1.7 |  |  | 2.0 |  |
| Asbestos-related litigation | 1.9 |  |  | 2.4 |  |
| Environmental liabilities | 1.2 |  |  | 0.7 |  |
| Other items, net | 0.8 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 7.5 |  |  | $ | 5.4 |  |

[0001069202-18-000013:mdna:69]
The net change in unrealized losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 5 in the Notes to the Consolidated Financial Statements.  For more information on special legal contingency charges and asbestos-related litigation, see Note 7 in the Notes to the Consolidated Financial Statements. The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.

[0001069202-18-000013:mdna:70]
Restructuring Charges

[0001069202-18-000013:mdna:71]
Restructuring charges were $1 million in the first six months of 2018. The charges in 2018 were primarily for projects to realign resources and enhance distribution capabilities.  For additional information on our restructuring activities, refer to Note 13 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000013:mdna:72]
Income from Equity Method Investments

[0001069202-18-000013:mdna:73]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $8 million in the first six months of 2018 was down from $11 million when compared to the first six months of 2017.

[0001069202-18-000013:mdna:74]
Interest Expense, net

[0001069202-18-000013:mdna:75]
Interest expense, net of $18 million in the first six months of 2018 increased from $16 million in the first six months of 2017 due to an increase in our average net borrowings and rising interest rates.

[0001069202-18-000013:mdna:76]
Income Taxes

[0001069202-18-000013:mdna:77]
We expect our annual effective tax rate to be between 22% and 24%, excluding the impact of excess tax benefits recorded as a reduction of income taxes under ASU No. 2016-09.

[0001069202-18-000013:mdna:78]
Our  effective tax rate was 22.5% for the six months ended June 30, 2018, after the impact of excess tax benefits, compared to 27.5% for the six months ended June 30, 2017, after the impact of excess tax benefits.  The rate for the six months ended June 30, 2018 is lower as compared to the six months ended June 30, 2017 primarily due to the reduced U.S. federal corporate tax rate from enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001069202-18-000013:mdna:79]
Year-to-Date through June 30, 2018 Compared to Year-to-Date through June 30, 2017 - Results by Segment

[0001069202-18-000013:mdna:80]
Residential Heating & Cooling

[0001069202-18-000013:mdna:81]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first six months of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:82]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 1,169.7 |  |  | $ | 1,073.3 |  |  | $ | 96.4 |  |  | 9.0 | % |
| Profit | $ | 204.9 |  |  | $ | 182.9 |  |  | $ | 22.0 |  |  | 12.0 | % |
| % of net sales | 17.5 | % |  | 17.0 | % |  |  |  |  |

[0001069202-18-000013:mdna:83]
Net sales increased by 9%  in the first six months of 2018 compared to the first six months of 2017.  Sales volumes increased 7%, and price increased 2%.

[0001069202-18-000013:mdna:84]
Segment profit for the first six months of 2018 increased $22 million compared to the first six months of 2017 due to the benefits of $23 million in higher sales volume, $23 million from favorable price and mix, $8 million from sourcing and engineering-led cost reductions, $1 million from lower other product costs, $1 million from improved factory productivity, and $1 million from favorable foreign currency exchange rates.  Partially offsetting these increases was $18 million of freight and costs associated with distribution investments, $14 million higher commodity costs, $2 million lower income from equity method investments, and $1 million from SG&A expenses.

[0001069202-18-000013:mdna:85]
Commercial Heating & Cooling

[0001069202-18-000013:mdna:86]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first six months of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:87]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 497.7 |  |  | $ | 454.1 |  |  | $ | 43.6 |  |  | 9.6 | % |
| Profit | $ | 72.1 |  |  | $ | 63.8 |  |  | $ | 8.3 |  |  | 13.0 | % |
| % of net sales | 14.5 | % |  | 14.0 | % |  |  |  |  |

[0001069202-18-000013:mdna:88]
Commercial Heating & Cooling net sales increased by 10% in the first six months of 2018 compared to the first six months of 2017.  Sales volumes increased 7%, favorable foreign currency exchange rates contributed 2%, and price increased 1%.

[0001069202-18-000013:mdna:89]
Segment profit in the first six months of 2018 increased $8 million compared to the first six months of 2017 due to the benefits of $9 million in higher sales volume, $6 million from higher price, $3 million from sourcing and engineering-led cost reductions, $2 million from lower SG&A expenses, and $1 million from lower other product costs.  Partially offsetting these increases was $6 million from unfavorable mix, $4 million in higher commodity costs, and $3 million of freight and costs associated with distribution investments.

[0001069202-18-000013:mdna:90]
Refrigeration

[0001069202-18-000013:mdna:91]
The following table presents our Refrigeration segment's net sales and profit for the first six months of 2018 and 2017 (dollars in millions):

[0001069202-18-000013:mdna:92]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 342.8 |  |  | $ | 368.2 |  |  | $ | (25.4 | ) |  | (6.9 | )% |
| Profit | $ | 33.0 |  |  | $ | 35.7 |  |  | $ | (2.7 | ) |  | (7.6 | )% |
| % of net sales | 9.6 | % |  | 9.7 | % |  |  |  |  |

[0001069202-18-000013:mdna:93]
Refrigeration net sales decreased 7% in the first six months of 2018 compared to the first six months of 2017.   The loss of sales from the divested Asia Pacific business contributed 7%, sales volume was lower by 2%, partially offset by 2% from favorable foreign currency exchange rates.

[0001069202-18-000013:mdna:94]
Segment profit for the first six months of 2018 decreased $3 million compared to the first six months of 2017.  The decrease was driven by $3 million of unfavorable mix, $3 million from factory inefficiencies, $2 million from higher commodity costs, $1 million of lost profit from the divested Asia Pacific business, $2 million from lower sales volume, $1 million in higher freight and distribution cost, and $1 million from lower equity method investments.  Partially offsetting these decreases was $3 million of sourcing and engineering-led cost reductions, a benefit of $2 million from selling refrigerant allocations in Europe,  $2 million of higher price, $1 million of lower other product costs, $1 million of lower SG&A expenses, and $1 million from favorable foreign currency exchange rates.

[0001069202-18-000013:mdna:95]
Corporate and Other

[0001069202-18-000013:mdna:96]
Corporate and other expenses decreased $1 million to $34 million in the first six months of 2018 from $35 million in the first six months of 2017 due primarily to a non-recurring foreign currency hedge loss in 2017.

[0001069202-18-000013:mdna:97]
[same as prior period, unchanged from 0001069202-18-000009:mdna:56]

[0001069202-18-000013:mdna:98]
[same as prior period, unchanged from 0001069202-18-000009:mdna:57]

[0001069202-18-000013:mdna:99]
[same as prior period, unchanged from 0001069202-18-000009:mdna:58]

[0001069202-18-000013:mdna:100]
The following table summarizes our cash flow activity for the six months ended June 30, 2018 and 2017 (in millions):

[0001069202-18-000013:mdna:101]
|  | For the Six Months Ended June 30, |
|  | 2018 |  | 2017 |
| Net cash used in operating activities | $ | (35.0 | ) |  | $ | (48.3 | ) |
| Net cash provided by (used in) investing activities | 68.5 |  |  | (43.2 | ) |
| Net cash (used in) provided by financing activities | (61.9 | ) |  | 95.4 |  |

[0001069202-18-000013:mdna:102]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first three months of 2018 and 2017 reflects the seasonal increase in working capital requirements. The decrease in cash used in operating activities in the first six months of 2018 as compared to 2017 was mainly due to the timing of working capital payments.

[0001069202-18-000013:mdna:103]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $43 million in the first six months of both 2018 and 2017.  Capital expenditures in 2018 were primarily related to expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $112 million were provided by the sale of our business in the Asia Pacific area along with the related property.

[0001069202-18-000013:mdna:104]
Net Cash (Used in) Provided by Financing Activities - Net cash used in financing activities in the first six months of 2018 was$62 million as compared to $95 million provided by financing activities in the first six months of 2017.  Cash continues to be provided by an increase in net borrowings and we continue to make share repurchases and dividend payments.  During the first six months of 2018, we repurchased $350 million of shares as compared to $175 million of shares in the first six months of 2017.

[0001069202-18-000013:mdna:105]
We also we returned $42 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 11 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000013:mdna:106]
[same as prior period, unchanged from 0001069202-18-000009:mdna:64]

[0001069202-18-000013:mdna:107]
The following table details our lines of credit and financing arrangements as of June 30, 2018 (in millions):

[0001069202-18-000013:mdna:108]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign obligations | $ | 3.8 |  |
| Total short-term debt | $ | 3.8 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 0.4 |  |
| Domestic credit facility (1) | 30.0 |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 290.0 |  |
| Capital lease obligations | 11.9 |  |
| Domestic credit facility (1) | 671.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (3.9 | ) |
| Total long-term debt | 1,319.0 |  |
| Total debt | $ | 1,352.6 |  |

[0001069202-18-000013:mdna:109]
(1) The available future borrowings on our domestic credit facility are $151.1 million after being reduced by the outstanding borrowings and $2.9 million in outstanding standby letters of credit.  We also had $32.1 million in outstanding standby letters of credit outside of the domestic credit facility as of June 30, 2018.

[0001069202-18-000013:mdna:110]
[same as prior period, unchanged from 0001069202-18-000009:mdna:68]

[0001069202-18-000013:mdna:111]
[same as prior period, unchanged from 0001069202-18-000009:mdna:69]

[0001069202-18-000013:mdna:112]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 115.4% at June 30, 2018 from 95.2% at December 31, 2017.

[0001069202-18-000013:mdna:113]
As of June 30, 2018, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-18-000013:mdna:114]
[same as prior period, unchanged from 0001069202-18-000009:mdna:72]

[0001069202-18-000013:mdna:115]
We believe our cash and cash equivalents of $39 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, potential dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $39 million as of June 30, 2018 was $15.2 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States. An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-18-000013:mdna:116]
Our expected capital expenditures for 2018 are $100 million.  We also continue to increase shareholder value through our share repurchase programs and dividend payments, with the completion of $350 million of share repurchases in the first six months of 2018 and the declaration of $42 million of cash dividends in the first six months of 2018.

[0001069202-18-000013:mdna:117]
[same as prior period, unchanged from 0001069202-18-000009:mdna:75]

[0001069202-18-000013:mdna:118]
[same as prior period, unchanged from 0001069202-18-000009:mdna:76]

[0001069202-18-000013:mdna:119]
Commitments, Contingencies and Guarantees

[0001069202-18-000013:mdna:120]
For information regarding our commitments, contingencies and guarantees, see Note 7 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000013:mdna:121]
[same as prior period, unchanged from 0001069202-18-000009:mdna:79]

[0001069202-18-000013:mdna:122]
[same as prior period, unchanged from 0001069202-18-000009:mdna:80]
