# LII note change history — 0001069202-18-000009 → 0001069202-18-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:1]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 35.0 |  |  | $ | 34.8 |  |
| Other liabilities | 75.4 |  |  | 75.1 |  |
| Total warranty liability | $ | 110.4 |  |  | $ | 109.9 |  |
  (was, 2018-04-23, similarity 0.9741):
[0001069202-18-000009:note_history:1]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Accrued expenses | $ | 34.5 |  |  | $ | 34.8 |  |
| Other liabilities | 74.3 |  |  | 75.1 |  |
| Total warranty liability | $ | 108.8 |  |  | $ | 109.9 |  |

- changed (2018-07-23):
[0001069202-18-000013:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2018 were as follows (in millions):
  (was, 2018-04-23, similarity 0.9404):
[0001069202-18-000009:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2018 were as follows (in millions):

- changed (2018-07-23):
[0001069202-18-000013:note_history:3]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (21.7 | ) |
| Changes resulting from issuance of new warranties | 24.2 |  |
| Changes in estimates associated with pre-existing liabilities | (3.3 | ) |
| Changes in foreign currency translation rates and other | 2.7 |  |
| Warranty liability from assets held for sale | (1.4 | ) |
| Total warranty liability as of June 30, 2018 | $ | 110.4 |  |
  (was, 2018-04-23, similarity 0.9864):
[0001069202-18-000009:note_history:3]
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Warranty claims paid | (5.0 | ) |
| Changes resulting from issuance of new warranties | 7.4 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | — |  |
| Warranty liability from assets held for sale | (0.9 | ) |
| Total warranty liability as of March 31, 2018 | $ | 108.8 |  |

- changed (2018-07-23):
[0001069202-18-000013:note_history:4]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2018 and 2017, expense for asbestos-related litigation was $1.9 million and $2.4 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations. For the three months ended  June 30, 2018 and 2017,  expense for asbestos-related litigation was $(0.2) million and $0.7 million, respectively, net of probable insurance recoveries.
  (was, 2018-04-23, similarity 0.9175):
[0001069202-18-000009:note_history:4]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2018 and 2017, expense for asbestos-related litigation was $2.1 million and $1.7 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:5]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2018, the accompanying unaudited Consolidated Statements of Operations for the three and six months ended June 30, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2018-04-23, similarity 0.9537):
[0001069202-18-000009:note_history:5]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2018, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2018 and 2017, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2018 and 2017, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2018 and 2017 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2017. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2018-07-23):
[0001069202-18-000013:note_history:6]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative assessment of our lease portfolio and are in the process of implementing a new system, collecting data and designing processes and controls to account for our leases in accordance with the new standard.
  (was, 2018-04-23, similarity 0.7921):
[0001069202-18-000009:note_history:6]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We will adopt the standard using the prospective approach and are still determining the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:7]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.27 | % |  | 2.76 | % |
  (was, 2018-04-23, similarity 0.9538):
[0001069202-18-000009:note_history:7]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.03 | % |  | 2.76 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:8]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 3.8 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 671.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.9 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,319.0 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,352.6 |  |  | $ | 1,004.0 |  |
  (was, 2018-04-23, similarity 0.9941):
[0001069202-18-000009:note_history:8]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 0.9 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 225.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 675.5 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.1 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,258.3 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,289.1 |  |  | $ | 1,004.0 |  |

- changed (2018-07-23):
[0001069202-18-000013:note_history:9]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $3.8 million and $0.9 million of foreign obligations outstanding as of June 30, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $21.3 million  and $0.8 million during the six months ended June 30, 2018 and 2017, respectively. Repayments on the facilities were $15.6 million and $1.8 million during the six months ended June 30, 2018 and 2017, respectively.
  (was, 2018-04-23, similarity 0.912):
[0001069202-18-000009:note_history:9]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.9 million and $0.9 million of foreign obligations outstanding as of March 31, 2018 and December 31, 2017, respectively, that were primarily borrowings under non-committed facilities. Proceeds on these facilities were $0.3 million  and $0.3 million during the three months ended March 31, 2018 and 2017, respectively. Repayments on the facilities were $0.4 million and $1.1 million during the three months ended March 31, 2018 and 2017, respectively.

- changed (2018-07-23):
[0001069202-18-000013:note_history:10]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.
  (was, 2018-04-23, similarity 0.6199):
[0001069202-18-000009:note_history:10]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

- changed (2018-07-23):
[0001069202-18-000013:note_history:11]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (290.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |
  (was, 2018-04-23, similarity 0.9567):
[0001069202-18-000009:note_history:11]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 225.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest sold | (225.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | — |  |  | $ | 14.0 |  |

- changed (2018-07-23):
[0001069202-18-000013:note_history:12]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of June 30, 2018 and December 31, 2017 were 2.93% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2018-04-23, similarity 0.9852):
[0001069202-18-000009:note_history:12]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2018 and December 31, 2017 were 2.63% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2018-07-23):
[0001069202-18-000013:note_history:13]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-04-23, similarity 0.8904):
[0001069202-18-000009:note_history:13]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.

- changed (2018-07-23):
[0001069202-18-000013:note_history:14]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $701.0 million, of which $205.0 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of June 30, 2018. Subject to covenant limitations, $151.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.
  (was, 2018-04-23, similarity 0.9954):
[0001069202-18-000009:note_history:14]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $705.5 million, of which $212.5 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of March 31, 2018. Subject to covenant limitations, $154.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million. The revolving credit facility includes a subfacility for swingline loans of up to $65.0 million.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2018-07-23):
[0001069202-18-000013:note_history:15]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.27 | % |  | 2.76 | % |
  (was, 2018-04-23, similarity 0.9538):
[0001069202-18-000009:note_history:15]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Weighted average borrowing rate | 3.03 | % |  | 2.76 | % |

- changed (2018-07-23):
[0001069202-18-000013:note_history:16]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-04-23, similarity 0.9914):
[0001069202-18-000009:note_history:16]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of March 31, 2018, we believe we were in compliance with all covenant requirements.

- changed (2018-07-23):
[0001069202-18-000013:note_history:17]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2018, we believe we were in compliance with all covenant requirements.
  (was, 2018-04-23, similarity 0.9954):
[0001069202-18-000009:note_history:17]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2018, we believe we were in compliance with all covenant requirements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:18]
|  | As of June 30, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 3.8 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.4 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 290.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 671.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.9 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,319.0 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,352.6 |  |  | $ | 1,004.0 |  |
  (was, 2018-04-23, similarity 0.9941):
[0001069202-18-000009:note_history:18]
|  | As of March 31, 2018 |  | As of December 31, 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | 0.9 |  |  | $ | 0.9 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 0.5 |  |  | $ | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 29.9 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 225.0 |  |  | $ | 276.0 |  |
| Capital lease obligations | 11.9 |  |  | 11.9 |  |
| Domestic credit facility | 675.5 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.1 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 1,258.3 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,289.1 |  |  | $ | 1,004.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-07-23):
[0001069202-18-000013:note_history:19]
On January 1, 2018, we adopted the new accounting standard ASC 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.
  (was, 2018-04-23, similarity 0.9675):
[0001069202-18-000009:note_history:19]
On January 1, 2018, we adopted the new accounting standard Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

- changed (2018-07-23):
[0001069202-18-000013:note_history:20]
|  | June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 741.3 |  |  | $ | 730.5 |  |  | $ | 10.8 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 437.5 |  |  | 424.2 |  |  | 13.3 |  |
| Retained earnings | 1,722.8 |  |  | 1,725.3 |  |  | (2.5 | ) |
|  | For the Three Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 1,175.4 |  |  | $ | 1,175.5 |  |  | $ | (0.1 | ) |
| Net income | 137.6 |  |  | 137.6 |  |  | — |  |
  (was, 2018-04-23, similarity 0.9858):
[0001069202-18-000009:note_history:20]
|  | March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 528.5 |  |  | $ | 521.8 |  |  | $ | 6.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Accounts payable | 405.6 |  |  | 397.3 |  |  | 8.3 |  |
| Retained earnings | 1,609.6 |  |  | 1,611.2 |  |  | (1.6 | ) |
|  | For the Three Months Ended March 31, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 834.8 |  |  | $ | 834.9 |  |  | $ | (0.1 | ) |
| Net income | 37.9 |  |  | 37.9 |  |  | — |  |

- added (2018-07-23):
[0001069202-18-000013:note_history:21]
|  | For the Six Months Ended June 30, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 2,010.2 |  |  | $ | 2,010.4 |  |  | $ | (0.2 | ) |
| Net income | 175.5 |  |  | 175.5 |  |  | — |  |

- added (2018-07-23):
[0001069202-18-000013:note_history:22]
|  | For the Three Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 716.0 |  |  | $ | 252.1 |  |  | $ | 127.6 |  |  | $ | 1,095.7 |  |
| Europe | — |  |  | 40.1 |  |  | 29.0 |  |  | 69.1 |  |
| Asia Pacific | — |  |  | — |  |  | 10.6 |  |  | 10.6 |  |
| Total | $ | 716.0 |  |  | 292.2 |  |  | 167.2 |  |  | 1,175.4 |  |

- added (2018-07-23):
[0001069202-18-000013:note_history:23]
|  | For the Six Months Ended June 30, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 1,169.7 |  |  | $ | 431.2 |  |  | $ | 237.4 |  |  | $ | 1,838.3 |  |
| Europe | — |  |  | 66.5 |  |  | 55.7 |  |  | 122.2 |  |
| Asia Pacific | — |  |  | — |  |  | 49.7 |  |  | 49.7 |  |
| Total | $ | 1,169.7 |  |  | 497.7 |  |  | 342.8 |  |  | 2,010.2 |  |

- changed (2018-07-23):
[0001069202-18-000013:note_history:24]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the three and six months ended June 30, 2018, direct sales represent approximately $546.7 million and $886.3 million of revenues and sales to independent distributors represent approximately $169.3 million and $283.4 million of revenues, respectively. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2018-04-23, similarity 0.7357):
[0001069202-18-000009:note_history:24]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment for the three months ended March 31, 2018, direct sales represent approximately $339.5 million of revenues and sales to independent distributors represent approximately $114.2 million of revenues.  Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- changed (2018-07-23):
[0001069202-18-000013:note_history:25]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the three and six months ended June 30, 2018, equipment sales represent approximately $279.3 million and $457.2 million of revenues while $12.9 million and $40.5 million of our revenue is generated from our service business, respectively.
  (was, 2018-04-23, similarity 0.9479):
[0001069202-18-000009:note_history:25]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, equipment sales represent approximately $177.9 million of revenues while $27.6 million of our revenue is generated from our service business.

- changed (2018-07-23):
[0001069202-18-000013:note_history:26]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $165.4 million and $339 million for the three and six months ended June 30, 2018 and and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.
  (was, 2018-04-23, similarity 0.955):
[0001069202-18-000009:note_history:26]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $173.6 million and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

- changed (2018-07-23):
[0001069202-18-000013:note_history:27]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.
  (was, 2018-04-23, similarity 0.9948):
[0001069202-18-000009:note_history:27]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods are transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

- changed (2018-07-23):
[0001069202-18-000013:note_history:28]
|  | June 30, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 3.5 |  |  | $ | 2.1 |  |  | $ | 1.4 |  |  | 66.7 | % |
| Contract liabilities - current | (5.0 | ) |  | (7.3 | ) |  | 2.3 |  |  | (31.5 | )% |
| Contract liabilities - noncurrent | (5.6 | ) |  | (5.5 | ) |  | (0.1 | ) |  | 1.8 | % |
| Total | $ | (7.1 | ) |  | $ | (10.7 | ) |  | $ | 3.6 |  |  |  |
  (was, 2018-04-23, similarity 0.9149):
[0001069202-18-000009:note_history:28]
|  | March 31, 2018 |  | December 31, 2017 |  | $ change |  | % change |
| Contract assets | $ | 2.1 |  |  | $ | 2.1 |  |  | $ | — |  |  | — | % |
| Contract liabilities - current | (6.5 | ) |  | (7.3 | ) |  | 0.8 |  |  | (11.0 | )% |
| Contract liabilities - noncurrent | (5.4 | ) |  | (5.5 | ) |  | 0.1 |  |  | (1.8 | )% |
| Total | $ | (9.8 | ) |  | $ | (10.7 | ) |  | $ | 0.9 |  |  |  |

- added (2018-07-23):
[0001069202-18-000013:note_history:29]
For the three and six months ended June 30, 2018, we recognized revenue of $1.3 million and $2.9 million related to our contract liabilities at January 1, 2018, respectively.   Impairment losses recognized in our receivables and contract assets were de minimis in the second quarter of 2018.

- removed (2018-07-23):
[0001069202-18-000009:note_history:30]
|  | For the Three Months Ended March 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| Americas | $ | 453.7 |  |  | $ | 179.1 |  |  | $ | 109.8 |  |  | $ | 742.6 |  |
| Europe | — |  |  | 26.4 |  |  | 26.8 |  |  | 53.2 |  |
| Asia Pacific | — |  |  | — |  |  | 39.0 |  |  | 39.0 |  |
| Total | $ | 453.7 |  |  | $ | 205.5 |  |  | $ | 175.6 |  |  | $ | 834.8 |  |

- removed (2018-07-23):
[0001069202-18-000009:note_history:31]
For the three months ended March, 31, 2018, we recognized revenue of $1.6 million related to our contract liabilities at January 1, 2018.   Impairment losses recognized in our receivables and contract assets were de minimis in the first quarter of 2018.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-07-23):
[0001069202-18-000013:note_history:32]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado. The extent of damage to the facility is being assessed and we currently do not have an estimate of the financial or operational impact of the damage, including any potential insurance recoveries.

- removed (2018-07-23):
[0001069202-18-000009:note_history:33]
During the second quarter of 2018, we obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale is subject to Brazilian antitrust approval and is expected to close later this year.  We expect to take a non-cash charge of approximately $30 million during the second quarter of 2018 related to the sale of this business.
