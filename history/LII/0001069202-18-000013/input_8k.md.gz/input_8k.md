# LII 8-K — 0001193125-18-223176 filed 2018-07-23

## item codes, every 8-K on or before 2018-07-23

- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2018-07-23

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-223176:8k_2_02:1]
EX-99.1
2
d548276dex991.htm
EX-99.1

[0001193125-18-223176:8k_2_02:2]
EX-99.1

[0001193125-18-223176:8k_2_02:3]
Exhibit 99.1

[0001193125-18-223176:8k_2_02:4]
Lennox International Reports Record Revenue and Profit in Second Quarter

[0001193125-18-223176:8k_2_02:5]
|  | • |  | GAAP revenue up 7%; adjusted revenue up 9% excluding non-core Refrigeration businesses being divested in 2018 |

[0001193125-18-223176:8k_2_02:6]
|  | • |  | GAAP EPS from continuing operations up 25% to record $3.39 |

[0001193125-18-223176:8k_2_02:7]
|  | • |  | Adjusted EPS from continuing operations up 30% to record $3.67 |

[0001193125-18-223176:8k_2_02:8]
|  | • |  | $200 million of stock repurchases in the second quarter |

[0001193125-18-223176:8k_2_02:9]
|  | • |  | Updating 2018 guidance for GAAP revenue growth from 4-8%, with a 1% benefit from foreign exchange, to 4-6% to reflect the timing of Refrigeration divestitures and neutral foreign exchange |

[0001193125-18-223176:8k_2_02:10]
|  | • |  | Raising 2018 guidance for adjusted revenue growth from 4-8%, with a 1% benefit from foreign exchange, to 6-8%, with neutral foreign exchange |

[0001193125-18-223176:8k_2_02:11]
|  | • |  | Raising 2018 guidance for GAAP EPS from continuing operations from $8.79-$9.39 to $9.43-$9.83 |

[0001193125-18-223176:8k_2_02:12]
|  | • |  | Raising 2018 guidance for adjusted EPS from continuing operations from $9.75-$10.35 to $9.95-$10.35 |

[0001193125-18-223176:8k_2_02:13]
|  | • |  | Raising 2018 stock repurchase guidance from $350 million to $450 million |

[0001193125-18-223176:8k_2_02:14]
DALLAS,
July 23, 2018 – Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2018. All comparisons are to the prior-year period. Adjusted revenue and profit exclude the
non-core Refrigeration businesses being divested in 2018, as previously announced. The company closed on the sale of its Australia and Asia refrigeration businesses in the second quarter, as well as on the
sale of real estate in the Sydney area, and continues to expect the sale of its South America business to be closed in the second half of 2018. The company had $17 million of revenue and $0.5 million of operating loss from these businesses
in the second quarter of 2018.

[0001193125-18-223176:8k_2_02:15]
Lennox International reported record GAAP revenue of $1.18 billion in the second quarter, up 7%. Adjusted revenue was
up 9% to a record $1.16 billion. Foreign exchange had 1% positive impact on revenue.

[0001193125-18-223176:8k_2_02:16]
GAAP operating income was a record $195 million in the
second quarter, up 11%. GAAP earnings per share from continuing operations was a record $3.39, up 25%. On an adjusted basis in the second quarter, total segment profit increased 13% to a record $206 million. Total segment margin expanded 50
basis points to a record 17.8%. Adjusted EPS from continuing operations rose 30% to a record $3.67.

[0001193125-18-223176:8k_2_02:17]
“Lennox International posted record revenue, profit and margin in the second quarter led by broad strength
in our Residential and Commercial businesses,” said Chairman and CEO Todd Bluedorn. “In Residential, revenue and profit hit new highs on strength in both replacement and new construction business. Residential revenue was up 9% at constant
currency, and profit rose 9% as segment margin remained at the record 21.5% level. In Commercial, revenue and profit also set new highs. Commercial revenue was up 12% at constant currency on strength in North America equipment and services.
Commercial profit rose 18% as segment margin expanded 70 basis points to 18.0%. In Refrigeration, revenue was up 1% at constant currency, and profit rose 5% as segment margin expanded 40 basis points to 14.9%.

[0001193125-18-223176:8k_2_02:18]
“With the record first half for the company and strong start in the third quarter, we are raising our outlook for 2018 as we continue to expect another
record year for Lennox International. We now expect adjusted revenue growth of 6-8% in 2018 and adjusted EPS from continuing operations of $9.95-$10.35. In addition, we
are raising our stock repurchase guidance to a total of $450 million for the full year.”

[0001193125-18-223176:8k_2_02:19]
FINANCIAL HIGHLIGHTS

[0001193125-18-223176:8k_2_02:20]
Revenue: On a GAAP basis, revenue was a record $1.18 billion, up 7%. On an adjusted basis, revenue was a record $1.16 billion, up 9%. Foreign
exchange had a positive 1% impact to revenue on a GAAP and adjusted basis. Volume and price were up, and mix was unfavorable.

[0001193125-18-223176:8k_2_02:21]
Gross Profit: On a
GAAP basis, gross profit was $362 million, up 6%. Gross margin was 30.8%, down 10 basis points. On an adjusted basis, gross profit was $357 million, up 7%. Adjusted gross margin was 30.8%, down 70 basis points. Gross profit on a GAAP and
adjusted basis was positively impacted by higher volume, favorable price, sourcing and engineering-led cost reductions, and favorable foreign exchange. Partial offsets included unfavorable mix, higher
commodity and freight costs, and distribution investments.

[0001193125-18-223176:8k_2_02:22]
Income from Continuing Operations: On a GAAP basis, income from continuing operations
for the second quarter was $139.2 million, or $3.39 per share, compared to $116.4 million, or $2.71 per share, in the prior-year quarter.

[0001193125-18-223176:8k_2_02:23]
Adjusted income from continuing operations in the second quarter was $150.5 million, or $3.67 per share, compared to $121.0 million, or $2.83 per
share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2018 excludes net after-tax charges of $11.3 million: a $31.4 million asset write-down associated
with Refrigeration divestitures, a net gain of $18.0 million from the sale of the Australia and Asia businesses and Sydney-area real estate, and a net gain of $2.1 million for various other items.

[0001193125-18-223176:8k_2_02:24]
Cash from Operations, Free Cash Flow and Total Debt: Net cash from operations in the second quarter was
$49 million compared to $59 million in the prior-year quarter. Capital expenditures were $21 million compared to $19 million in the prior-year quarter. Free cash flow was $28 million compared to approximately
$41 million in the second quarter a year ago. Total debt at the end of the second quarter was $1.353 billion. Total cash and cash equivalents were $39 million at the end of June. In the second quarter, the company paid
$21 million in dividends and $200 million for stock repurchases.

[0001193125-18-223176:8k_2_02:25]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-18-223176:8k_2_02:26]
Residential Heating & Cooling

[0001193125-18-223176:8k_2_02:27]
Revenue in the
Residential Heating & Cooling business segment rose 10% to a record $716 million. At constant currency, revenue was up 9%. Segment profit was a record $154 million, up 9%. Segment margin was flat at the record 21.5% level. Results
were positively impacted by higher volume, higher price, sourcing and engineering-led cost reductions, lower SG&A expense, and favorable foreign exchange. Offsets included unfavorable mix, higher commodity
and freight costs, distribution investments, a smaller favorable warranty adjustment than in the prior-year quarter, and higher other product costs.

[0001193125-18-223176:8k_2_02:28]
Commercial Heating & Cooling

[0001193125-18-223176:8k_2_02:29]
Revenue in the
Commercial Heating & Cooling business segment was up 13% to a record $292 million. At constant currency, revenue was up 12%. Segment profit rose 18% to a record $53 million. Segment margin expanded 70 basis points to 18.0%.
Results were positively impacted by higher volume, higher price, sourcing and engineering-led cost reductions, and favorable warranty. Partial offsets included unfavorable mix, higher commodity and freight
costs, and higher other product costs.

[0001193125-18-223176:8k_2_02:30]
Refrigeration

[0001193125-18-223176:8k_2_02:31]
On an adjusted basis for the Refrigeration business segment, revenue was $150 million, up 2%. At constant currency, revenue was up 1%. Segment profit was
up 5% to $22 million. Segment margin expanded 40 basis points to 14.9%. Results were positively impacted by higher volume, higher price, engineering-led cost reductions and sourcing benefits including
selling refrigerant allocations in Europe, and favorable foreign exchange. Partial offsets included unfavorable mix, and higher commodity, freight, and other product costs.

[0001193125-18-223176:8k_2_02:32]
FULL-YEAR OUTLOOK

[0001193125-18-223176:8k_2_02:33]
|  | • |  | Updating 2018 guidance for GAAP revenue growth from 4-8%, with a 1% benefit from foreign exchange, to 4-6% to reflect the timing of Refrigeration divestitures and neutral foreign exchange. |

[0001193125-18-223176:8k_2_02:34]
|  | • |  | Raising 2018 guidance for adjusted revenue growth from 4-8%, with a 1% benefit from foreign exchange, to 6-8%, with neutral foreign exchange. |

[0001193125-18-223176:8k_2_02:35]
|  | • |  | Raising 2018 guidance for GAAP EPS from continuing operations from $8.79-$9.39 to $9.43-$9.83 to incorporate second-quarter financial results and special items, including the gain on the sale of Sydney-area real estate not previously assumed in the GAAP guidance range. |

[0001193125-18-223176:8k_2_02:36]
|  | • |  | Raising 2018 guidance for adjusted EPS from continuing operations from $9.75-$10.35 to $9.95-$10.35. |

[0001193125-18-223176:8k_2_02:37]
|  | • |  | Reiterating corporate expense guidance of approximately $85 million. |

[0001193125-18-223176:8k_2_02:38]
|  | • |  | Reiterating guidance for an effective tax rate of 22-24% on an adjusted basis for the full year. |

[0001193125-18-223176:8k_2_02:39]
|  | • |  | Reiterating capital expenditures of approximately $100 million. |

[0001193125-18-223176:8k_2_02:40]
|  | • |  | Raising 2018 stock repurchase guidance from $350 million to $450 million and updating guidance for the company’s average diluted share count from a range of 41-42 million shares to approximately 41 million shares on a full-year basis. |

[0001193125-18-223176:8k_2_02:41]
CONFERENCE CALL INFORMATION

[0001193125-18-223176:8k_2_02:42]
A conference call to discuss
the company’s second-quarter results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-326-1011 at least 10
minutes prior to the scheduled start time and use reservation number 451539. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on
July 23 through August 7, 2018 by dialing 800-475-6701 (U.S.) or 320-365-3844
(international) and using access code 451539. The call also will be archived on the company’s website.

[0001193125-18-223176:8k_2_02:43]
About Lennox International

[0001193125-18-223176:8k_2_02:44]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York
Stock Exchange and traded under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-18-223176:8k_2_02:45]
FORWARD-LOOKING STATEMENTS

[0001193125-18-223176:8k_2_02:46]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-223176:8k_2_02:47]
Consolidated Statements of Operations

[0001193125-18-223176:8k_2_02:48]
(Unaudited)

[0001193125-18-223176:8k_2_02:49]
| (Amounts in millions, except per share data) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 1,175.4 |  |  | $ | 1,102.1 |  |  | $ | 2,010.2 |  |  | $ | 1,895.6 |  |
| Cost of goods sold |  |  | 813.8 |  |  |  | 761.3 |  |  |  | 1,425.5 |  |  |  | 1,343.8 |  |
| Gross profit |  |  | 361.6 |  |  |  | 340.8 |  |  |  | 584.7 |  |  |  | 551.8 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 161.4 |  |  |  | 168.5 |  |  |  | 316.6 |  |  |  | 320.9 |  |
| Losses and other expenses, net |  |  | 0.2 |  |  |  | 2.3 |  |  |  | 7.5 |  |  |  | 5.4 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 0.1 |  |  |  | 1.3 |  |  |  | 0.2 |  |
| (Gain) loss, net on sale of business and related property |  |  | (22.1 | ) |  |  | — |  |  |  | (11.8 | ) |  |  | — |  |
| Loss on assets held for sale |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |
| Income from equity method investments |  |  | (4.9 | ) |  |  | (5.5 | ) |  |  | (8.4 | ) |  |  | (10.9 | ) |
| Operating income |  |  | 195.1 |  |  |  | 175.4 |  |  |  | 248.1 |  |  |  | 236.2 |  |
| Interest expense, net |  |  | 9.8 |  |  |  | 8.2 |  |  |  | 18.2 |  |  |  | 15.7 |  |
| Other expense (income), net |  |  | 0.8 |  |  |  | (0.1 | ) |  |  | 1.4 |  |  |  | (0.1 | ) |
| Income from continuing operations before income taxes |  |  | 184.5 |  |  |  | 167.3 |  |  |  | 228.5 |  |  |  | 220.6 |  |
| Provision for income taxes |  |  | 45.3 |  |  |  | 50.9 |  |  |  | 51.4 |  |  |  | 60.7 |  |
| Income from continuing operations |  |  | 139.2 |  |  |  | 116.4 |  |  |  | 177.1 |  |  |  | 159.9 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes |  |  | 0.4 |  |  |  | (1.5 | ) |  |  | 0.4 |  |  |  | (1.5 | ) |
| Income tax expense (benefit) |  |  | 2.0 |  |  |  | (0.6 | ) |  |  | 2.0 |  |  |  | (0.6 | ) |
| Loss from discontinued operations |  |  | (1.6 | ) |  |  | (0.9 | ) |  |  | (1.6 | ) |  |  | (0.9 | ) |
| Net income |  | $ | 137.6 |  |  | $ | 115.5 |  |  | $ | 175.5 |  |  | $ | 159.0 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 3.42 |  |  | $ | 2.75 |  |  | $ | 4.31 |  |  | $ | 3.76 |  |
| Loss from discontinued operations |  |  | (0.04 | ) |  |  | (0.02 | ) |  |  | (0.04 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 3.38 |  |  | $ | 2.73 |  |  | $ | 4.27 |  |  | $ | 3.74 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 3.39 |  |  | $ | 2.71 |  |  | $ | 4.26 |  |  | $ | 3.70 |  |
| Loss from discontinued operations |  |  | (0.04 | ) |  |  | (0.02 | ) |  |  | (0.04 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 3.35 |  |  | $ | 2.69 |  |  | $ | 4.22 |  |  | $ | 3.68 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 40.7 |  |  |  | 42.3 |  |  |  | 41.1 |  |  |  | 42.6 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 41.1 |  |  |  | 42.9 |  |  |  | 41.6 |  |  |  | 43.2 |  |
| Cash dividends declared per share |  | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 1.15 |  |  | $ | 0.94 |  |

[0001193125-18-223176:8k_2_02:50]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-223176:8k_2_02:51]
Adjusted Segment Net Sales and Profit (Loss)

[0001193125-18-223176:8k_2_02:52]
(Unaudited)

[0001193125-18-223176:8k_2_02:53]
| (Amounts in millions) |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Adjusted Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 716.0 |  |  | $ | 653.5 |  |  | $ | 1,169.7 |  |  | $ | 1,073.3 |  |
| Commercial Heating & Cooling |  |  | 292.2 |  |  |  | 258.6 |  |  |  | 497.7 |  |  |  | 454.1 |  |
| Refrigeration (1) |  |  | 150.1 |  |  |  | 147.2 |  |  |  | 278.7 |  |  |  | 278.3 |  |
|  |  | $ | 1,158.3 |  |  | $ | 1,059.3 |  |  | $ | 1,946.1 |  |  | $ | 1,805.7 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 153.6 |  |  | $ | 140.5 |  |  | $ | 204.9 |  |  | $ | 182.9 |  |
| Commercial Heating & Cooling |  |  | 52.6 |  |  |  | 44.7 |  |  |  | 72.1 |  |  |  | 63.8 |  |
| Refrigeration (1) |  |  | 22.4 |  |  |  | 21.4 |  |  |  | 31.8 |  |  |  | 32.4 |  |
| Corporate and other |  |  | (22.8 | ) |  |  | (23.9 | ) |  |  | (33.9 | ) |  |  | (34.8 | ) |
| Total adjusted segment profit |  |  | 205.8 |  |  |  | 182.7 |  |  |  | 274.9 |  |  |  | 244.3 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| One time inventory write down |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Special product quality adjustment |  |  | — |  |  |  | 5.2 |  |  |  | — |  |  |  | 5.2 |  |
| (Gain) loss, net on sale of business and related property |  |  | (22.1 | ) |  |  | — |  |  |  | (11.8 | ) |  |  | — |  |
| Loss on assets held for sale |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) |  |  | 0.4 |  |  |  | 2.2 |  |  |  | 6.9 |  |  |  | 6.0 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 0.1 |  |  |  | 1.3 |  |  |  | 0.2 |  |
| Operating income from non-core businesses |  |  | 0.5 |  |  |  | (0.2 | ) |  |  | (1.2 | ) |  |  | (3.3 | ) |
| Operating income |  | $ | 195.1 |  |  | $ | 175.4 |  |  | $ | 248.1 |  |  | $ | 236.2 |  |

[0001193125-18-223176:8k_2_02:54]
| (1) | Excludes the non-core business results related to our business operations in Australia, Asia, and South America for 2018 and 2017. |

[0001193125-18-223176:8k_2_02:55]
| (2) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-18-223176:8k_2_02:56]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-18-223176:8k_2_02:57]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-18-223176:8k_2_02:58]
|  | • |  | Special legal contingency charges, |

[0001193125-18-223176:8k_2_02:59]
|  | • |  | Asbestos-related litigation, |

[0001193125-18-223176:8k_2_02:60]
|  | • |  | Contractor tax payments, |

[0001193125-18-223176:8k_2_02:61]
|  | • |  | Environmental liabilities, |

[0001193125-18-223176:8k_2_02:62]
|  | • |  | Divestiture costs, |

[0001193125-18-223176:8k_2_02:63]
|  | • |  | Other items, net, |

[0001193125-18-223176:8k_2_02:64]
|  | • |  | One time inventory write down, |

[0001193125-18-223176:8k_2_02:65]
|  | • |  | (Gain) loss, net on sale of business and related property, |

[0001193125-18-223176:8k_2_02:66]
|  | • |  | Loss on assets held for sale, |

[0001193125-18-223176:8k_2_02:67]
|  | • |  | Operating income from non-core businesses; and, |

[0001193125-18-223176:8k_2_02:68]
|  | • |  | Restructuring charges. |

[0001193125-18-223176:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-223176:8k_2_02:70]
Consolidated Balance Sheets

[0001193125-18-223176:8k_2_02:71]
| (Amounts in millions, except shares and par values) |  | As of June 30, 2018 |  |  | As of December 31, 2017 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 39.4 |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net of allowances of $6.2 and $5.9 in 2018 and 2017, respectively |  |  | 741.3 |  |  |  | 506.5 |  |
| Inventories, net |  |  | 540.2 |  |  |  | 484.2 |  |
| Assets held for sale |  |  | 11.6 |  |  |  | — |  |
| Other assets |  |  | 53.3 |  |  |  | 78.4 |  |
| Total current assets |  |  | 1,385.8 |  |  |  | 1,137.3 |  |
| Property, plant and equipment, net of accumulated depreciation of $757.0 and $774.2 in 2018 and 2017, respectively |  |  | 371.0 |  |  |  | 397.8 |  |
| Goodwill |  |  | 186.8 |  |  |  | 200.5 |  |
| Deferred income taxes |  |  | 89.2 |  |  |  | 94.4 |  |
| Other assets, net |  |  | 66.6 |  |  |  | 61.5 |  |
| Total assets |  | $ | 2,099.4 |  |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 3.8 |  |  | $ | 0.9 |  |
| Current maturities of long-term debt |  |  | 29.8 |  |  |  | 32.6 |  |
| Accounts payable |  |  | 437.5 |  |  |  | 348.6 |  |
| Accrued expenses |  |  | 253.6 |  |  |  | 270.3 |  |
| Liabilities held for sale |  |  | 7.4 |  |  |  | — |  |
| Income taxes payable |  |  | 12.0 |  |  |  | 2.1 |  |
| Total current liabilities |  |  | 744.1 |  |  |  | 654.5 |  |
| Long-term debt |  |  | 1,319.0 |  |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions |  |  | 2.5 |  |  |  | 2.6 |  |
| Pensions |  |  | 86.5 |  |  |  | 84.5 |  |
| Other liabilities |  |  | 127.5 |  |  |  | 129.3 |  |
| Total liabilities |  |  | 2,279.6 |  |  |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,068.4 |  |  |  | 1,061.5 |  |
| Retained earnings |  |  | 1,722.8 |  |  |  | 1,575.9 |  |
| Accumulated other comprehensive loss |  |  | (181.0 | ) |  |  | (157.4 | ) |
| Treasury stock, at cost, 46,920,057 shares and 45,361,145 shares as of June 30, 2018 and December 31, 2017, respectively |  |  | (2,791.3 | ) |  |  | (2,430.8 | ) |
| Total stockholders’ equity |  |  | (180.2 | ) |  |  | 50.1 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,099.4 |  |  | $ | 1,891.5 |  |

[0001193125-18-223176:8k_2_02:72]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-223176:8k_2_02:73]
Consolidated Statements of Cash Flows

[0001193125-18-223176:8k_2_02:74]
(Unaudited)

[0001193125-18-223176:8k_2_02:75]
| (Amounts in millions) |  | For the Six Months EndedJune 30, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 175.5 |  |  | $ | 159.0 |  |
| Gain on sale of Australia property |  |  | (23.8 | ) |  |  | — |  |
| Loss on the sale of Australia business |  |  | 12.0 |  |  |  | — |  |
| Loss on Brazil assets held for sale |  |  | 31.4 |  |  |  | — |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (8.4 | ) |  |  | (10.9 | ) |
| Dividend from Affiliates |  |  | 2.2 |  |  |  | 2.5 |  |
| Restructuring charges, net of cash paid |  |  | 0.6 |  |  |  | — |  |
| Provision for bad debts |  |  | 3.3 |  |  |  | 2.7 |  |
| Unrealized losses (gains) on derivative contracts |  |  | 1.3 |  |  |  | (3.0 | ) |
| Stock-based compensation expense |  |  | 13.6 |  |  |  | 12.5 |  |
| Depreciation and amortization |  |  | 32.8 |  |  |  | 32.0 |  |
| Deferred income taxes |  |  | (6.2 | ) |  |  | (4.9 | ) |
| Pension expense |  |  | 4.2 |  |  |  | 2.4 |  |
| Pension contributions |  |  | (2.2 | ) |  |  | (0.4 | ) |
| Other items, net |  |  | 0.2 |  |  |  | 0.2 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (272.1 | ) |  |  | (213.8 | ) |
| Inventories |  |  | (115.5 | ) |  |  | (114.1 | ) |
| Other current assets |  |  | (2.2 | ) |  |  | (5.7 | ) |
| Accounts payable |  |  | 109.2 |  |  |  | 81.3 |  |
| Accrued expenses |  |  | 3.2 |  |  |  | (9.9 | ) |
| Income taxes payable and receivable |  |  | 15.1 |  |  |  | 16.2 |  |
| Other |  |  | (9.2 | ) |  |  | 5.6 |  |
| Net cash used in operating activities |  |  | (35.0 | ) |  |  | (48.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.1 |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | (43.4 | ) |  |  | (43.4 | ) |
| Net proceeds from sale of business and related property |  |  | 111.8 |  |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | 68.5 |  |  |  | (43.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | 2.9 |  |  |  | (1.1 | ) |
| Asset securitization borrowings |  |  | 65.0 |  |  |  | 200.0 |  |
| Asset securitization payments |  |  | (51.0 | ) |  |  | — |  |
| Long-term debt payments |  |  | (17.8 | ) |  |  | (200.5 | ) |
| Borrowings from credit facility |  |  | 1,391.0 |  |  |  | 1,352.5 |  |
| Payments on credit facility |  |  | (1,042.0 | ) |  |  | (1,031.0 | ) |
| Proceeds from employee stock purchases |  |  | 1.2 |  |  |  | 1.5 |  |
| Repurchases of common stock |  |  | (350.2 | ) |  |  | (175.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (18.6 | ) |  |  | (14.1 | ) |
| Cash dividends paid |  |  | (42.4 | ) |  |  | (36.9 | ) |
| Net cash (used in) provided by financing activities |  |  | (61.9 | ) |  |  | 95.4 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (28.4 | ) |  |  | 3.9 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | (0.4 | ) |  |  | 7.2 |  |
| Cash and cash equivalents, beginning of period |  |  | 68.2 |  |  |  | 50.2 |  |
| Cash and cash equivalents, end of period |  | $ | 39.4 |  |  | $ | 61.3 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 18.3 |  |  | $ | 17.1 |  |
| Income taxes paid (net of refunds) |  | $ | 45.0 |  |  | $ | 47.8 |  |

[0001193125-18-223176:8k_2_02:76]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-223176:8k_2_02:77]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-18-223176:8k_2_02:78]
(Unaudited, in millions, except per share and ratio data)

[0001193125-18-223176:8k_2_02:79]
Use of Non-GAAP Financial Measures

[0001193125-18-223176:8k_2_02:80]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The results from operations for these businesses
have been shown in the tables below as “Non-core business results”. The sales of our business in Australia and Asia and the related property was completed in the second quarter of 2018. The prior
period results have been updated to provide period-over-period comparability.

[0001193125-18-223176:8k_2_02:81]
Reconciliation of Income from Continuing Operations, a GAAP measure, to
Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-18-223176:8k_2_02:82]
|  |  | For the Three Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 184.5 |  |  | $ | (45.3 | ) |  | $ | 139.2 |  |  | $ | 167.3 |  |  | $ | (50.9 | ) |  | $ | 116.4 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Loss on assets held for sale |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special product quality adjustments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.2 |  |  |  | (1.8 | ) |  |  | 3.4 |  |
| Special legal contingency charges (a) |  |  | 1.5 |  |  |  | (0.3 | ) |  |  | 1.2 |  |  |  | 1.2 |  |  |  | (0.2 | ) |  |  | 1.0 |  |
| Asbestos-related litigation (a) |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | — |  |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Environmental liabilities (a) |  |  | 0.9 |  |  |  | (0.3 | ) |  |  | 0.6 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | — |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | (2.3 | ) |  |  | (2.3 | ) |  |  | — |  |  |  | — |  |  |  |  |  |
| (Gain) loss, net on sale of business and related property |  |  | (22.1 | ) |  |  | 4.1 |  |  |  | (18.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Divestiture costs (a),(g) |  |  | (2.5 | ) |  |  | 0.6 |  |  |  | (1.9 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (a) |  |  | 0.6 |  |  |  | (0.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-core business results (f) |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 195.3 |  |  | $ | (44.8 | ) |  | $ | 150.5 |  |  | $ | 174.8 |  |  | $ | (53.8 | ) |  | $ | 121.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.39 |  |  |  |  |  |  |  |  |  |  | $ | 2.71 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Loss on assets held for sale |  |  |  |  |  |  |  |  |  |  | 0.77 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| (Gain) loss, net on sale of business and related property |  |  |  |  |  |  |  |  |  |  | (0.44 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Divestiture costs (a),(g) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 3.67 |  |  |  |  |  |  |  |  |  |  | $ | 2.83 |  |

[0001193125-18-223176:8k_2_02:83]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:84]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:85]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:86]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-18-223176:8k_2_02:87]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-18-223176:8k_2_02:88]
| (f) | Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |

[0001193125-18-223176:8k_2_02:89]
| (g) | Divestiture costs incurred in Q1 2018 related to the sales of the Australia and Asia business and the related property were reclassified to (Gain) loss, net on sale of business and related property in Q2 2018. |

[0001193125-18-223176:8k_2_02:90]
|  |  | For the Six Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (e) |  |  | After Tax |  |
| Income from continuing operations, a GAAP measure |  | $ | 228.5 |  |  | $ | (51.4 | ) |  | $ | 177.1 |  |  | $ | 220.6 |  |  | $ | (60.7 | ) |  | $ | 159.9 |  |
| Restructuring charges |  |  | 1.3 |  |  |  | (0.3 | ) |  |  | 1.0 |  |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |
| Loss on assets held for sale |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special product quality adjustments (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.2 |  |  |  | (1.8 | ) |  |  | 3.4 |  |
| Special legal contingency charges (a) |  |  | 1.7 |  |  |  | (0.4 | ) |  |  | 1.3 |  |  |  | 2.0 |  |  |  | (0.1 | ) |  |  | 1.9 |  |
| Asbestos-related litigation (a) |  |  | 1.9 |  |  |  | (0.4 | ) |  |  | 1.5 |  |  |  | 2.4 |  |  |  | (0.8 | ) |  |  | 1.6 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 1.3 |  |  |  | (0.3 | ) |  |  | 1.0 |  |  |  | 0.9 |  |  |  | (0.4 | ) |  |  | 0.5 |  |
| Inventory write down (b) |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Environmental liabilities (a) |  |  | 1.2 |  |  |  | (0.3 | ) |  |  | 0.9 |  |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (4.9 | ) |  |  | (4.9 | ) |  |  | — |  |  |  | (8.1 | ) |  |  | (8.1 | ) |
| Other tax items, net (c) |  |  | — |  |  |  | (3.2 | ) |  |  | (3.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| (Gain) loss, net on sale of business and related property |  |  | (11.8 | ) |  |  | 4.1 |  |  |  | (7.7 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (a) |  |  | 0.8 |  |  |  | (0.6 | ) |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-core business results (f) |  |  | (1.1 | ) |  |  | 0.2 |  |  |  | (0.9 | ) |  |  | (2.7 | ) |  |  | 0.6 |  |  |  | (2.1 | ) |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 255.4 |  |  | $ | (57.5 | ) |  | $ | 197.9 |  |  | $ | 229.3 |  |  | $ | (71.5 | ) |  | $ | 157.8 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 4.26 |  |  |  |  |  |  |  |  |  |  | $ | 3.70 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Loss on assets held for sale |  |  |  |  |  |  |  |  |  |  | 0.76 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.08 |  |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Inventory write down (b) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.12 | ) |  |  |  |  |  |  |  |  |  |  | (0.19 | ) |
| Other tax items, net (c) |  |  |  |  |  |  |  |  |  |  | (0.07 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| (Gain) loss, net on sale of business and related property |  |  |  |  |  |  |  |  |  |  | (0.19 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 4.78 |  |  |  |  |  |  |  |  |  |  | $ | 3.67 |  |

[0001193125-18-223176:8k_2_02:91]
| (a) | Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:92]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:93]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-18-223176:8k_2_02:94]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-18-223176:8k_2_02:95]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-18-223176:8k_2_02:96]
| (f) | Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |

[0001193125-18-223176:8k_2_02:97]
|  |  | For the Three Months EndedJune 30, |  |  | For the Six Months EndedJune 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Components of (Gains) Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized gains on settled future contracts (a) |  | $ | (0.2 | ) |  | $ | (0.4 | ) |  | $ | (0.7 | ) |  | $ | (0.8 | ) |
| Foreign currency exchange (gains) losses (a) |  |  | (0.1 | ) |  |  | 0.5 |  |  |  | 1.2 |  |  |  | 0.2 |  |
| Loss on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Net change in unrealized losses on unsettled futures contracts (b) |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 1.3 |  |  |  | 0.9 |  |
| Special legal contingency charges (b) |  |  | 1.5 |  |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 2.0 |  |
| Asbestos-related litigation (b) |  |  | (0.2 | ) |  |  | 0.7 |  |  |  | 1.9 |  |  |  | 2.4 |  |
| Environmental liabilities (b) |  |  | 0.9 |  |  |  | 0.2 |  |  |  | 1.2 |  |  |  | 0.7 |  |
| Divestiture costs (b),(c) |  |  | (2.5 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Other items, net (b) |  |  | 0.6 |  |  |  | — |  |  |  | 0.8 |  |  |  | — |  |
| Losses and other expenses, net (pre-tax) |  | $ | 0.2 |  |  | $ | 2.3 |  |  | $ | 7.5 |  |  | $ | 5.4 |  |

[0001193125-18-223176:8k_2_02:98]
| (a) | Included in both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-223176:8k_2_02:99]
| (b) | Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-223176:8k_2_02:100]
| (c) | Divestiture costs incurred in Q1 2018 related to the sales of the Australia and Asia business and the related property were reclassified to (Gain) loss, net on sale of business and related property in Q2 2018. |

[0001193125-18-223176:8k_2_02:101]
Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated
Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure

[0001193125-18-223176:8k_2_02:102]
|  |  | For the Year EndedDecember 31, 2018ESTIMATED |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $ | 9.43 - $9.83 |  |
| Loss on assets held for sale, charges associated with the divestiture of the Australia and Asia business and other items partially offset by gain on sale of property and excess tax benefits from share-based compensation |  |  | 0.52 |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 9.95 - $10.35 |  |

[0001193125-18-223176:8k_2_02:103]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a
Non-GAAP measure (shares in millions):

[0001193125-18-223176:8k_2_02:104]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 41.1 |  |  |  | 42.9 |  |  |  | 41.6 |  |  |  | 43.2 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Adjusted average shares outstanding - diluted, a Non- GAAP measure |  |  | 41.0 |  |  |  | 42.7 |  |  |  | 41.4 |  |  |  | 43.0 |  |

[0001193125-18-223176:8k_2_02:105]
Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP
measure

[0001193125-18-223176:8k_2_02:106]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Three MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales, a GAAP measure |  | $ | 167.2 |  |  | $ | 190.0 |  |  | $ | 1,175.4 |  |  | $ | 1,102.1 |  |
| Net sales from non-core businesses (a) |  |  | 17.1 |  |  |  | 42.8 |  |  |  | 17.1 |  |  |  | 42.8 |  |
| Adjusted net sales, a Non- GAAP measure |  | $ | 150.1 |  |  | $ | 147.2 |  |  | $ | 1,158.3 |  |  | $ | 1,059.3 |  |

[0001193125-18-223176:8k_2_02:107]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:108]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Six MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales, a GAAP measure |  | $ | 342.8 |  |  | $ | 368.2 |  |  | $ | 2,010.2 |  |  | $ | 1,895.6 |  |
| Net sales from non-core businesses (a) |  |  | 64.1 |  |  |  | 89.9 |  |  |  | 64.1 |  |  |  | 89.9 |  |
| Adjusted net sales, a Non- GAAP measure |  | $ | 278.7 |  |  | $ | 278.3 |  |  | $ | 1,946.1 |  |  | $ | 1,805.7 |  |

[0001193125-18-223176:8k_2_02:109]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:110]
Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure

[0001193125-18-223176:8k_2_02:111]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Three MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross profit, a GAAP measure |  | $ | 51.0 |  |  | $ | 57.7 |  |  | $ | 361.6 |  |  | $ | 340.8 |  |
| Non-GAAP adjustments to gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5.2 | ) |
| Gross profit from non-core businesses (a) |  |  | 4.3 |  |  |  | 12.4 |  |  |  | 4.3 |  |  |  | 12.4 |  |
| Adjusted Gross profit, a Non- GAAP measure |  | $ | 46.7 |  |  | $ | 45.3 |  |  | $ | 357.3 |  |  | $ | 333.6 |  |

[0001193125-18-223176:8k_2_02:112]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:113]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Six MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross profit, a GAAP measure |  | $ | 99.4 |  |  | $ | 109.5 |  |  | $ | 584.7 |  |  | $ | 551.8 |  |
| Non-GAAP adjustments to gross profit |  |  | (0.2 | ) |  |  | — |  |  |  | (0.2 | ) |  |  | (5.2 | ) |
| Gross profit from non-core businesses (a) |  |  | 17.9 |  |  |  | 27.3 |  |  |  | 17.9 |  |  |  | 27.3 |  |
| Adjusted Gross profit, a Non- GAAP measure |  | $ | 81.7 |  |  | $ | 82.2 |  |  | $ | 567.0 |  |  | $ | 529.7 |  |

[0001193125-18-223176:8k_2_02:114]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:115]
Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a
Non-GAAP measure

[0001193125-18-223176:8k_2_02:116]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Three MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Segment profit, a GAAP measure |  | $ | 21.9 |  |  | $ | 21.6 |  |  | $ | 205.3 |  |  | $ | 182.9 |  |
| Gross profit from non-core businesses (a) |  |  | (0.5 | ) |  |  | 0.2 |  |  |  | (0.5 | ) |  |  | 0.2 |  |
| Adjusted Segment profit, a Non- GAAP measure |  | $ | 22.4 |  |  | $ | 21.4 |  |  | $ | 205.8 |  |  | $ | 182.7 |  |

[0001193125-18-223176:8k_2_02:117]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:118]
|  |  | RefrigerationSegment |  |  | Consolidated |  |
|  |  | For the Six MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Segment profit, a GAAP measure |  | $ | 33.0 |  |  | $ | 35.7 |  |  | $ | 276.1 |  |  | $ | 247.6 |  |
| Gross profit from non-core businesses (a) |  |  | 1.2 |  |  |  | 3.3 |  |  |  | 1.2 |  |  |  | 3.3 |  |
| Adjusted Segment profit, a Non- GAAP measure |  | $ | 31.8 |  |  | $ | 32.4 |  |  | $ | 274.9 |  |  | $ | 244.3 |  |

[0001193125-18-223176:8k_2_02:119]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:120]
Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure

[0001193125-18-223176:8k_2_02:121]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Selling, general and administrative expenses, a GAAP measure |  | $ | 161.4 |  |  | $ | 168.5 |  |  | $ | 316.6 |  |  | $ | 320.9 |  |
| Selling, general and administrative expenses from non-core businesses (a) |  |  | 5.3 |  |  |  | 12.3 |  |  |  | 17.2 |  |  |  | 24.0 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure |  | $ | 156.1 |  |  | $ | 156.2 |  |  | $ | 299.4 |  |  | $ | 296.9 |  |

[0001193125-18-223176:8k_2_02:122]
| (a) | Non-Core business represent our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:123]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a
Non-GAAP measure (dollars in millions)

[0001193125-18-223176:8k_2_02:124]
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 48.5 |  |  | $ | 59.3 |  |  | $ | (35.0 | ) |  | $ | (48.3 | ) |
| Purchases of property, plant and equipment |  |  | (20.7 | ) |  |  | (18.5 | ) |  |  | (43.4 | ) |  |  | (43.4 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.2 |  |
| Free cash flow, a Non-GAAP measure |  |  | 27.8 |  |  |  | 40.9 |  |  |  | (78.3 | ) |  |  | (91.5 | ) |

[0001193125-18-223176:8k_2_02:125]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelve Months toJune 30,2018 |  |
| Adjusted EBIT(a) (a) |  | $ | 538.7 |  |
| Depreciation and amortization expense (b) |  |  | 63.9 |  |
| EBITDA (a + b) |  | $ | 602.6 |  |
| Total debt at June 30, 2018 (c) |  | $ | 1,352.6 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.2 |  |

[0001193125-18-223176:8k_2_02:126]
| (a) | Adjusted EBIT excludes the non-core business results related to our business operations in Australia, Asia, and South America. |

[0001193125-18-223176:8k_2_02:127]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a
GAAP measure (dollars in millions)

[0001193125-18-223176:8k_2_02:128]
|  |  | TrailingTwelve Months toJune 30,2018 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 538.7 |  |
| Special product quality adjustments |  |  | 0.2 |  |
| Items in Losses and other expenses, net that are excluded from segment profit |  |  | 12.3 |  |
| Inventory write down |  |  | 0.2 |  |
| Restructuring charges |  |  | 4.4 |  |
| Interest expense, net |  |  | 33.1 |  |
| (Gain) loss, net on sale of business and related property |  |  | (11.8 | ) |
| Loss on assets held for sale |  |  | 31.4 |  |
| Non-core business results (a) |  |  | (4.4 | ) |
| Other expenses, net |  |  | 1.4 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 471.9 |  |

[0001193125-18-223176:8k_2_02:129]
| (a) | Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
