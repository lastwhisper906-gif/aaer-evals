# LII 8-K — 0001193125-18-032739 filed 2018-02-06

## item codes, every 8-K on or before 2018-02-16

- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2018-02-16

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-032739:8k_2_02:1]
EX-99.1
2
d513321dex991.htm
EX-99.1

[0001193125-18-032739:8k_2_02:2]
EX-99.1

[0001193125-18-032739:8k_2_02:3]
Exhibit 99.1

[0001193125-18-032739:8k_2_02:4]
Lennox International Reports Record Fourth Quarter Margin and Profit to Cap Record Year and Raises 2018 EPS Guidance for U.S. Tax Legislation

[0001193125-18-032739:8k_2_02:5]
| • |  | 2017 revenue up 5% to record $3.84 billion |

[0001193125-18-032739:8k_2_02:6]
| • |  | 2017 GAAP EPS from continuing operations up 13% to record $7.17, and adjusted EPS from continuing operations up 14% to record $7.92 |

[0001193125-18-032739:8k_2_02:7]
| • |  | Including the impact from 6% fewer days in the quarter, fourth-quarter revenue reported down 1%; GAAP EPS from continuing operations up 9% to fourth-quarter record $1.02, and adjusted EPS from continuing operations up 12% to fourth-quarter record $1.68 |

[0001193125-18-032739:8k_2_02:8]
| • |  | Reiterating 2018 guidance for revenue growth of 3-7% |

[0001193125-18-032739:8k_2_02:9]
| • |  | Raising 2018 guidance for EPS from continuing operations from $8.65-$9.25 to $9.75-$10.35, incorporating the net benefits from U.S. tax legislation |

[0001193125-18-032739:8k_2_02:10]
| • |  | Updating 2018 effective tax rate guidance from 31-32% to 22-24% |

[0001193125-18-032739:8k_2_02:11]
| • |  | Raising 2018 guidance for stock repurchases from $300 million to $350 million |

[0001193125-18-032739:8k_2_02:12]
DALLAS,
February 6, 2018 – Lennox International Inc. (NYSE: LII) today reported fourth-quarter and full-year 2017 results. All comparisons are against the prior-year period. As previously noted, the first quarter of 2017 had 6% more days and the
fourth quarter of 2017 had 6% fewer days than their respective prior-year periods.

[0001193125-18-032739:8k_2_02:13]
For the fourth quarter, revenue was $892 million, down 1%. At
constant currency, revenue was down 2%. GAAP operating income was $104 million, up 53%. GAAP earnings per share from continuing operations was $1.02, up 9%. Total segment profit increased 1% to a fourth-quarter record $106 million, and
margin expanded 20 basis points to a fourth-quarter record 11.9%. Adjusted earnings per share from continuing operations rose 12% to a fourth-quarter record $1.68.

[0001193125-18-032739:8k_2_02:14]
For the full year, revenue was $3.84 billion, up 5%. Foreign exchange was neutral to revenue. GAAP operating income was a record $495 million, up
15%. GAAP earnings per share from continuing operations was a record $7.17, up 13%. Total segment profit increased 10% to a record $515 million as total segment margin expanded 50 basis points to a record 13.4%. Adjusted earnings per share from
continuing operations for the full year rose 14% to a record $7.92.

[0001193125-18-032739:8k_2_02:15]
“Lennox International posted a record year of revenue, margin, and profit in
2017, and the company is well-positioned for another year of strong growth and margin expansion in 2018,” said Chairman and CEO Todd Bluedorn. “The company’s performance was led by our Residential business, which set new highs for
revenue, margin, and profit. Our Commercial business set new highs for revenue and profit, and we continued to see improvement in our Refrigeration segment with margin and profit up for the second consecutive year.

[0001193125-18-032739:8k_2_02:16]
“In the fourth quarter, the reported results were impacted from having 6% fewer days in the quarter.
Residential revenue was relatively flat at fourth-quarter record levels. Segment profit was down 7%, and margin declined 120 basis points to 16.0% on lower factory absorption than a year ago, the timing of other product costs, and unfavorable mix
with replacement business down slightly and new construction up. In Commercial, revenue, margin, and profit established new fourth-quarter highs. Commercial revenue was up 1% at constant currency, and segment profit rose 12% as margin expanded 150
basis points to 17.4%. In Refrigeration, revenue declined 9% at constant currency, but segment profit rose 8% and margin expanded 140 basis points to 10.2% as the business hit its margin target for the year of 10.0%, up 50 basis points.

[0001193125-18-032739:8k_2_02:17]
“Looking ahead, we are reiterating 2018 guidance for revenue growth of 3-7% and are raising EPS guidance by
$1.10, incorporating the net benefits from U.S. tax legislation, to a new range of $9.75-$10.35 for the full year. After generating $227 million of free cash flow in 2017, below guidance of approximately
$285 million, the company is raising 2018 free cash flow guidance from approximately $330 million to $395 million to align with working capital timing between the two years, as well as the cash benefit from U.S. tax legislation in
2018. We will continue to invest in the business to drive growth and profitability, grow the dividend with earnings over time, and repurchase stock. For 2018, we are increasing our stock repurchase plans from $300 million to
$350 million.”

[0001193125-18-032739:8k_2_02:18]
FOURTH QUARTER 2017 FINANCIAL HIGHLIGHTS

[0001193125-18-032739:8k_2_02:19]
Revenue: Revenue for the fourth quarter was $892 million, down 1%. Foreign exchange was favorable to revenue growth by 1 percentage point. Volume
and mix were down, and price was up from the fourth quarter a year ago.

[0001193125-18-032739:8k_2_02:20]
Gross Profit: Gross profit in the fourth quarter was $260 million,
down 3%. Gross margin was 29.1%, down 70 basis points. Gross profit was impacted by lower volume and factory absorption, unfavorable mix, higher commodity costs, the timing of other product costs, and investments in distribution. Partial offsets
included higher price, sourcing and engineering-led cost reductions, and favorable foreign exchange.

[0001193125-18-032739:8k_2_02:21]
Income
from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $43.1 million, or $1.02 diluted earnings per share, compared to $40.7 million, or $0.94 diluted earnings per share, in the prior-year
quarter. The fourth quarter of 2017 included a non-cash, after-tax charge of $40.2 million, or $0.95 per share, related to U.S. tax legislation and the associated write-down of deferred tax assets. The
fourth quarter of 2016 included a $20.5 million after-tax charge, or $0.47 per share, for a one-time, lump-sum pension
buyout program to certain vested participants.

[0001193125-18-032739:8k_2_02:22]
For the fourth quarter of 2017, adjusted income from continuing operations was $71.0 million, or
$1.68 diluted earnings per share, compared to $65.2 million, or $1.50 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth quarter of 2017 excludes net
after-tax charges of $27.9 million: $40.2 million related to U.S. tax legislation and the associated write-down of deferred tax assets, $1.7 million for other items, net, and a benefit of
$14.0 million for excess tax benefits from share-based compensation.

[0001193125-18-032739:8k_2_02:23]
FULL YEAR 2017 FINANCIAL HIGHLIGHTS

[0001193125-18-032739:8k_2_02:24]
Revenue: For the full year, revenue was $3.84 billion, up 5%. Foreign exchange was neutral to revenue. Volume and price were up, and mix was down
from the prior year.

[0001193125-18-032739:8k_2_02:25]
Gross Profit: Gross profit for the full year was $1.13 billion, up 5%. Gross margin was 29.3%, down 30 basis points.
Gross profit was impacted by unfavorable mix, higher commodity costs, lower factory productivity, investments in distribution expansion, and other product costs. Partial offsets included higher volume, higher price, sourcing and engineering-led cost reductions, and favorable foreign exchange.

[0001193125-18-032739:8k_2_02:26]
Income from Continuing Operations: On a GAAP
basis, income from continuing operations for 2017 was $307 million, or $7.17 diluted earnings per share, compared to $279 million, or $6.34 diluted earnings per share, in the prior year. The year 2017 included a non-cash, after-tax charge of $40.2 million, or $0.94 per share, related to U.S. tax legislation and the associated write-down of deferred tax assets. The year 2016 included a $20.5 million after-tax charge, or $0.47 per share, for a one-time, lump-sum pension buyout program to certain vested participants.

[0001193125-18-032739:8k_2_02:27]
Adjusted income from continuing operations for 2017 was $338 million, or $7.92 diluted earnings per share, compared to $306 million, or $6.95
diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2017 excludes net after-tax charges of $30.8 million: $40.2 million related to U.S. tax legislation and the
associated write-down of deferred tax assets, $3.5 million for special product quality adjustments, $3.3 million for special legal contingency charges, a total of $7.4 million for other items, and a benefit of $23.6 million for
excess tax benefits from share-based compensation.

[0001193125-18-032739:8k_2_02:28]
Free Cash Flow and Total Debt: For the full year, cash from operations was $325 million
compared to $374 million in the prior year. Capital expenditures were $98 million compared to $84 million in the prior year. Free cash flow was $227 million for the full year compared to $290 million in the prior year. In
2017, the company paid approximately $80 million in dividends and repurchased $250 million of company stock. Ending the year, total debt was $1.0 billion, and the company’s debt-to-EBITDA ratio stood at 1.7. Total cash and cash equivalents were $68 million at the end of the year.

[0001193125-18-032739:8k_2_02:29]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001193125-18-032739:8k_2_02:30]
Residential Heating and Cooling

[0001193125-18-032739:8k_2_02:31]
| • |  | 4Q17 revenue a fourth-quarter record $477 million, flat; neutral foreign exchange |

[0001193125-18-032739:8k_2_02:32]
| • |  | 4Q17 segment profit $76 million, down 7% |

[0001193125-18-032739:8k_2_02:33]
| • |  | 4Q17 segment margin 16.0%, down 120 basis points |

[0001193125-18-032739:8k_2_02:34]
| • |  | 2017 revenue a record $2.14 billion, up 7%; neutral foreign exchange |

[0001193125-18-032739:8k_2_02:35]
| • |  | 2017 segment profit a record $374 million, up 7% |

[0001193125-18-032739:8k_2_02:36]
| • |  | 2017 segment margin a record 17.5%, up 10 basis points |

[0001193125-18-032739:8k_2_02:37]
Fourth-quarter results were impacted by lower factory
absorption than a year ago, unfavorable mix, higher commodity costs, the timing of other product costs, and distribution investments. Partial offsets included higher price, sourcing and engineering-led cost
reductions, lower SG&A, and favorable foreign exchange. Full-year results were positively impacted by higher volume, higher price, sourcing and engineering-led cost reductions, lower warranty expense, and
favorable foreign exchange. Partial offsets included unfavorable mix, higher commodity and other product costs, investments in distribution expansion, and investments in research and development, information technology and other SG&A.

[0001193125-18-032739:8k_2_02:38]
Commercial Heating and Cooling

[0001193125-18-032739:8k_2_02:39]
| • |  | 4Q17 revenue a fourth-quarter record $250 million, up 3%; up 1% at constant currency |

[0001193125-18-032739:8k_2_02:40]
| • |  | 4Q17 segment profit a fourth-quarter record $44 million, up 12% |

[0001193125-18-032739:8k_2_02:41]
| • |  | 4Q17 segment margin a fourth-quarter record 17.4%, up 150 basis points |

[0001193125-18-032739:8k_2_02:42]
| • |  | 2017 revenue a record $974 million, up 6%; up 5% at constant currency |

[0001193125-18-032739:8k_2_02:43]
| • |  | 2017 segment profit a record $157 million, up 5% |

[0001193125-18-032739:8k_2_02:44]
| • |  | 2017 segment margin 16.2%, down 10 basis points |

[0001193125-18-032739:8k_2_02:45]
Fourth-quarter results were positively impacted by higher
volume, higher price, sourcing and engineering-led cost reductions, lower other product costs, and lower SG&A. Partial offsets included higher commodity costs and warranty expense. Full-year results were
positively impacted by higher volume, higher price, and sourcing and engineering-led cost reductions. Offsets included unfavorable mix, higher commodity and other product costs, factory productivity, higher
warranty expense, investments in distribution, and higher SG&A.

[0001193125-18-032739:8k_2_02:46]
Refrigeration

[0001193125-18-032739:8k_2_02:47]
| • |  | 4Q17 revenue $165 million, down 7%; down 9% at constant currency |

[0001193125-18-032739:8k_2_02:48]
| • |  | 4Q17 segment profit $17 million, up 8% |

[0001193125-18-032739:8k_2_02:49]
| • |  | 4Q17 segment margin 10.2%, up 140 basis points |

[0001193125-18-032739:8k_2_02:50]
| • |  | 2017 revenue $725 million, up slightly; down 1% at constant currency |

[0001193125-18-032739:8k_2_02:51]
| • |  | 2017 segment profit $73 million, up 5% |

[0001193125-18-032739:8k_2_02:52]
| • |  | 2017 segment margin 10.0%, up 50 basis points |

[0001193125-18-032739:8k_2_02:53]
Fourth-quarter results were positively impacted by favorable
mix, sourcing and engineering-led cost reductions, lower other product costs, and lower SG&A. Partial offsets included lower volume and factory absorption, and higher commodity costs. Full-year results
were positively impacted by higher price and favorable mix, sourcing and engineering-led cost reductions, and lower other product costs. Partial offsets included higher commodity costs, factory productivity,
higher freight and distribution costs, and higher SG&A.

[0001193125-18-032739:8k_2_02:54]
2018 FULL-YEAR OUTLOOK

[0001193125-18-032739:8k_2_02:55]
The company is raising 2018 guidance for EPS from continuing operations due to a lower effective tax rate following U.S. tax legislation and increasing the
stock repurchase amount planned for the year.

[0001193125-18-032739:8k_2_02:56]
| • |  | Reiterating revenue growth of 3-7%, with a minimal impact from foreign exchange |

[0001193125-18-032739:8k_2_02:57]
| • |  | Raising GAAP and adjusted EPS from continuing operations from $8.65-$9.25 to $9.75-$10.35 |

[0001193125-18-032739:8k_2_02:58]
| • |  | Reiterating corporate expenses of approximately $85 million |

[0001193125-18-032739:8k_2_02:59]
| • |  | Lowering the effective tax rate from 31-32% to 22-24% on a full-year basis |

[0001193125-18-032739:8k_2_02:60]
| • |  | Reiterating capital expenditures of approximately $100 million |

[0001193125-18-032739:8k_2_02:61]
| • |  | Increasing 2018 stock repurchase plans from $300 million to $350 million |

[0001193125-18-032739:8k_2_02:62]
CONFERENCE CALL
INFORMATION

[0001193125-18-032739:8k_2_02:63]
A conference call to discuss the company’s fourth-quarter and full-year 2017 results will be held this morning at 8:30 a.m. Central
time. To listen, call the conference call line at 612-288-0329 at least 10 minutes prior to the scheduled start time and use reservation number 442711. The conference
call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on February 6 through February 20, 2018, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 442711. The call also will be archived on the
company’s web site.

[0001193125-18-032739:8k_2_02:64]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox
International stock is listed on the New York Stock Exchange and traded under the symbol “LII”. Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President,
Investor Relations, at 972-497-6670.

[0001193125-18-032739:8k_2_02:65]
FORWARD-LOOKING STATEMENTS

[0001193125-18-032739:8k_2_02:66]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-032739:8k_2_02:67]
Consolidated Statements of Operations

[0001193125-18-032739:8k_2_02:68]
| (Amounts in millions, except per share data) |  | For the ThreeMonths EndedDecember 31,(Unaudited) |  |  | For the Years EndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net sales |  | $ | 891.8 |  |  | $ | 897.3 |  |  | $ | 3,839.6 |  |  | $ | 3,641.6 |  |
| Cost of goods sold |  |  | 632.0 |  |  |  | 629.7 |  |  |  | 2,714.4 |  |  |  | 2,565.1 |  |
| Gross profit |  |  | 259.8 |  |  |  | 267.6 |  |  |  | 1,125.2 |  |  |  | 1,076.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 158.2 |  |  |  | 164.9 |  |  |  | 637.7 |  |  |  | 621.0 |  |
| (Gains) Losses and other expenses, net |  |  | (0.4 | ) |  |  | 5.8 |  |  |  | 8.2 |  |  |  | 11.3 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | 0.7 |  |  |  | 3.2 |  |  |  | 1.8 |  |
| Pension settlement |  |  | — |  |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |
| Income from equity method investments |  |  | (2.9 | ) |  |  | (3.2 | ) |  |  | (18.4 | ) |  |  | (18.4 | ) |
| Operating income |  |  | 103.7 |  |  |  | 68.0 |  |  |  | 494.5 |  |  |  | 429.4 |  |
| Interest expense, net |  |  | 7.3 |  |  |  | 7.4 |  |  |  | 30.6 |  |  |  | 27.0 |  |
| Other income, net |  |  | — |  |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |
| Income from continuing operations before income taxes |  |  | 96.4 |  |  |  | 60.7 |  |  |  | 464.0 |  |  |  | 402.7 |  |
| Provision for income taxes |  |  | 53.3 |  |  |  | 20.0 |  |  |  | 156.9 |  |  |  | 124.1 |  |
| Income from continuing operations |  |  | 43.1 |  |  |  | 40.7 |  |  |  | 307.1 |  |  |  | 278.6 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (Loss) from discontinued operations before income taxes |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | (2.2 | ) |  |  | (1.3 | ) |
| Provision for (Benefit from) income taxes |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | (0.8 | ) |  |  | (0.5 | ) |
| Loss from discontinued operations |  |  | — |  |  |  | (0.3 | ) |  |  | (1.4 | ) |  |  | (0.8 | ) |
| Net income |  | $ | 43.1 |  |  | $ | 40.4 |  |  | $ | 305.7 |  |  | $ | 277.8 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.03 |  |  | $ | 0.95 |  |  | $ | 7.28 |  |  | $ | 6.41 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.01 | ) |  |  | (0.03 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 1.03 |  |  | $ | 0.94 |  |  | $ | 7.25 |  |  | $ | 6.39 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.02 |  |  | $ | 0.94 |  |  | $ | 7.17 |  |  | $ | 6.34 |  |
| Loss from discontinued operations |  |  | — |  |  |  | (0.01 | ) |  |  | (0.03 | ) |  |  | (0.02 | ) |
| Net income |  | $ | 1.02 |  |  | $ | 0.93 |  |  | $ | 7.14 |  |  | $ | 6.32 |  |
| Weighted Average Number of Shares Outstanding—Basic |  |  | 41.8 |  |  |  | 42.9 |  |  |  | 42.2 |  |  |  | 43.4 |  |
| Weighted Average Number of Shares Outstanding—Diluted |  |  | 42.5 |  |  |  | 43.4 |  |  |  | 42.8 |  |  |  | 44.0 |  |
| Cash dividends declared per share |  | $ | 0.51 |  |  | $ | 0.43 |  |  | $ | 1.96 |  |  | $ | 1.65 |  |

[0001193125-18-032739:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-032739:8k_2_02:70]
Segment Net Sales and Profit (Loss)

[0001193125-18-032739:8k_2_02:71]
| (Amounts in millions) |  | For the ThreeMonths EndedDecember 31,(Unaudited) |  |  | For the Years EndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 476.6 |  |  | $ | 476.3 |  |  | $ | 2,140.4 |  |  | $ | 2,000.8 |  |
| Commercial Heating & Cooling |  |  | 250.3 |  |  |  | 243.3 |  |  |  | 973.8 |  |  |  | 917.9 |  |
| Refrigeration |  |  | 164.9 |  |  |  | 177.7 |  |  |  | 725.4 |  |  |  | 722.9 |  |
|  |  | $ | 891.8 |  |  | $ | 897.3 |  |  | $ | 3,839.6 |  |  | $ | 3,641.6 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 76.2 |  |  | $ | 81.9 |  |  | $ | 373.9 |  |  | $ | 348.8 |  |
| Commercial Heating & Cooling |  |  | 43.5 |  |  |  | 38.7 |  |  |  | 157.3 |  |  |  | 149.3 |  |
| Refrigeration |  |  | 16.9 |  |  |  | 15.6 |  |  |  | 72.6 |  |  |  | 68.9 |  |
| Corporate and other |  |  | (30.6 | ) |  |  | (31.6 | ) |  |  | (89.2 | ) |  |  | (97.4 | ) |
| Total segment profit |  |  | 106.0 |  |  |  | 104.6 |  |  |  | 514.6 |  |  |  | 469.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.3 | ) |  |  | — |  |  |  | 5.4 |  |  |  | (0.4 | ) |
| Items in (Gains) Losses and other expenses, net that are excluded from segment profit (loss) (1) |  |  | 1.4 |  |  |  | 4.5 |  |  |  | 11.5 |  |  |  | 7.4 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | 0.7 |  |  |  | 3.2 |  |  |  | 1.8 |  |
| Pension settlement |  |  | — |  |  |  | 31.4 |  |  |  | — |  |  |  | 31.4 |  |
| Operating income |  | $ | 103.7 |  |  | $ | 68.0 |  |  | $ | 494.5 |  |  | $ | 429.4 |  |

[0001193125-18-032739:8k_2_02:72]
| (1) | The Company defines segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-18-032739:8k_2_02:73]
|  | • |  | Special product quality adjustments; |

[0001193125-18-032739:8k_2_02:74]
|  | • |  | The following items in (Gains) Losses and other expenses, net: |

[0001193125-18-032739:8k_2_02:75]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-18-032739:8k_2_02:76]
|  | • |  | Special legal contingency charges, |

[0001193125-18-032739:8k_2_02:77]
|  | • |  | Asbestos-related litigation, |

[0001193125-18-032739:8k_2_02:78]
|  | • |  | Environmental liabilities, |

[0001193125-18-032739:8k_2_02:79]
|  | • |  | Contractor tax payments, |

[0001193125-18-032739:8k_2_02:80]
|  | • |  | Acquisition/disposition costs, and |

[0001193125-18-032739:8k_2_02:81]
|  | • |  | Other items, net; |

[0001193125-18-032739:8k_2_02:82]
|  | • |  | Restructuring charges; and |

[0001193125-18-032739:8k_2_02:83]
|  | • |  | Pension settlement. |

[0001193125-18-032739:8k_2_02:84]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-032739:8k_2_02:85]
Consolidated Balance Sheets

[0001193125-18-032739:8k_2_02:86]
| (Amounts in millions, except shares and par values) |  | As ofDecember 31,2017 |  |  | As ofDecember 31,2016 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 68.2 |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net of allowances of $5.9 and $6.7 in 2017 and 2016, respectively |  |  | 506.5 |  |  |  | 469.8 |  |
| Inventories, net |  |  | 484.2 |  |  |  | 418.5 |  |
| Other assets |  |  | 78.4 |  |  |  | 67.4 |  |
| Total current assets |  |  | 1,137.3 |  |  |  | 1,005.9 |  |
| Property, plant and equipment, net of accumulated depreciation of $774.2 and $717.2 in 2017 and 2016, respectively |  |  | 397.8 |  |  |  | 361.4 |  |
| Goodwill |  |  | 200.5 |  |  |  | 195.1 |  |
| Deferred income taxes |  |  | 94.4 |  |  |  | 136.7 |  |
| Other assets, net |  |  | 61.5 |  |  |  | 61.2 |  |
| Total assets |  | $ | 1,891.5 |  |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 0.9 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt |  |  | 32.6 |  |  |  | 200.1 |  |
| Accounts payable |  |  | 348.6 |  |  |  | 361.2 |  |
| Accrued expenses |  |  | 270.3 |  |  |  | 265.9 |  |
| Income taxes payable |  |  | 2.1 |  |  |  | 9.0 |  |
| Total current liabilities |  |  | 654.5 |  |  |  | 888.6 |  |
| Long-term debt |  |  | 970.5 |  |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions |  |  | 2.6 |  |  |  | 2.8 |  |
| Pensions |  |  | 84.5 |  |  |  | 87.5 |  |
| Other liabilities |  |  | 129.3 |  |  |  | 127.7 |  |
| Total liabilities |  |  | 1,841.4 |  |  |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,061.5 |  |  |  | 1,046.2 |  |
| Retained earnings |  |  | 1,575.9 |  |  |  | 1,353.0 |  |
| Accumulated other comprehensive loss |  |  | (157.4 | ) |  |  | (195.1 | ) |
| Treasury stock, at cost, 45,361,145 shares and 44,195,250 shares for 2017 and 2016, respectively |  |  | (2,430.8 | ) |  |  | (2,167.4 | ) |
| Noncontrolling interests |  |  | — |  |  |  | 0.4 |  |
| Total stockholders’ equity |  |  | 50.1 |  |  |  | 38.0 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,891.5 |  |  | $ | 1,760.3 |  |

[0001193125-18-032739:8k_2_02:87]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-032739:8k_2_02:88]
Consolidated Statements of Cash Flow

[0001193125-18-032739:8k_2_02:89]
| (Amounts in millions) |  | For the Years EndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 305.7 |  |  | $ | 277.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (18.4 | ) |  |  | (18.4 | ) |
| Dividends from affiliates |  |  | 14.7 |  |  |  | 14.9 |  |
| Restructuring expenses, net of cash paid |  |  | 0.8 |  |  |  | (0.8 | ) |
| Provision for bad debts |  |  | 3.9 |  |  |  | 2.4 |  |
| Unrealized gains, net on derivative contracts |  |  | (2.0 | ) |  |  | (0.7 | ) |
| Stock-based compensation expense |  |  | 24.9 |  |  |  | 31.7 |  |
| Depreciation and amortization |  |  | 64.6 |  |  |  | 58.1 |  |
| Deferred income taxes |  |  | 43.3 |  |  |  | (4.0 | ) |
| Pension expense |  |  | 5.3 |  |  |  | 37.7 |  |
| Pension contributions |  |  | (3.5 | ) |  |  | (53.9 | ) |
| Other items, net |  |  | 1.3 |  |  |  | 0.9 |  |
| Changes in assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (28.4 | ) |  |  | (50.6 | ) |
| Inventories |  |  | (56.4 | ) |  |  | 0.3 |  |
| Other current assets |  |  | (6.1 | ) |  |  | 0.1 |  |
| Accounts payable |  |  | (18.5 | ) |  |  | 40.1 |  |
| Accrued expenses |  |  | 0.3 |  |  |  | 36.2 |  |
| Income taxes payable and receivable |  |  | (6.7 | ) |  |  | (0.1 | ) |
| Other, net |  |  | 0.3 |  |  |  | 2.2 |  |
| Net cash provided by operating activities |  |  | 325.1 |  |  |  | 373.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.2 |  |  |  | 0.2 |  |
| Purchases of property, plant and equipment |  |  | (98.3 | ) |  |  | (84.3 | ) |
| Net cash used in investing activities |  |  | (98.1 | ) |  |  | (84.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (1.5 | ) |  |  | (2.4 | ) |
| Asset securitization borrowings |  |  | 315.0 |  |  |  | 145.0 |  |
| Asset securitization payments |  |  | (89.0 | ) |  |  | (295.0 | ) |
| Long-term debt borrowings |  |  | — |  |  |  | 350.0 |  |
| Long-term debt payments |  |  | (200.9 | ) |  |  | (58.8 | ) |
| Borrowings from credit facility |  |  | 2,376.5 |  |  |  | 2,336.5 |  |
| Payments on credit facility |  |  | (2,265.5 | ) |  |  | (2,346.0 | ) |
| Payments of deferred financing costs |  |  | (0.2 | ) |  |  | (4.2 | ) |
| Proceeds from employee stock purchases |  |  | 3.1 |  |  |  | 2.6 |  |
| Repurchases of common stock |  |  | (250.0 | ) |  |  | (300.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (26.1 | ) |  |  | (33.3 | ) |
| Cash dividends paid |  |  | (79.7 | ) |  |  | (69.0 | ) |
| Net cash used in financing activities |  |  | (218.3 | ) |  |  | (274.6 | ) |
| Increase in cash and cash equivalents |  |  | 8.7 |  |  |  | 15.2 |  |
| Effect of exchange rates on cash and cash equivalents |  |  | 9.3 |  |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of year |  |  | 50.2 |  |  |  | 38.9 |  |
| Cash and cash equivalents, end of year |  | $ | 68.2 |  |  | $ | 50.2 |  |
| Supplementary disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid during the year for: |  |  |  |  |  |  |  |  |
| Interest, net |  | $ | 32.4 |  |  | $ | 26.3 |  |
| Income taxes (net of refunds) |  | $ | 119.3 |  |  | $ | 127.4 |  |

[0001193125-18-032739:8k_2_02:90]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-18-032739:8k_2_02:91]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-18-032739:8k_2_02:92]
(Unaudited, in millions, except per share and ratio data)

[0001193125-18-032739:8k_2_02:93]
Use of Non-GAAP Financial Measures

[0001193125-18-032739:8k_2_02:94]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-18-032739:8k_2_02:95]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted
Income from Continuing Operations, a Non-GAAP measure

[0001193125-18-032739:8k_2_02:96]
|  |  | For the Three Months Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |
| Income from continuing operations, a GAAP measure |  |  | 96.4 |  |  |  | (53.3 | ) |  |  | 43.1 |  |  | $ | 60.7 |  |  | $ | (20.0 | ) |  | $ | 40.7 |  |
| Restructuring charges |  |  | 1.2 |  |  |  | (0.5 | ) |  |  | 0.7 |  |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Special product quality adjustments (b) |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.4 |  |  |  | — |  |  |  | 1.4 |  |
| Asbestos-related litigation (a) |  |  | (0.3 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | 4.0 |  |  |  | (1.4 | ) |  |  | 2.6 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | — |  |  |  | (1.7 | ) |  |  | 0.6 |  |  |  | (1.1 | ) |
| Environmental liabilities (a) |  |  | 0.9 |  |  |  | (0.2 | ) |  |  | 0.7 |  |  |  | 0.8 |  |  |  | (0.2 | ) |  |  | 0.6 |  |
| Contractor tax payments (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (14.0 | ) |  |  | (14.0 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Tax legislation impact (c) |  |  | — |  |  |  | 40.2 |  |  |  | 40.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Pension settlement charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 31.4 |  |  |  | (10.9 | ) |  |  | 20.5 |  |
| Other items, net (a) |  |  | 0.8 |  |  |  | (0.2 | ) |  |  | 0.6 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 98.7 |  |  | $ | (27.7 | ) |  | $ | 71.0 |  |  | $ | 97.3 |  |  | $ | (32.1 | ) |  | $ | 65.2 |  |
| Earnings per share from continuing operations – diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 1.02 |  |  |  |  |  |  |  |  |  |  | $ | 0.94 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.06 |  |
| Net change in unrealized (gains) losses on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | (0.02 | ) |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.33 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Tax legislation impact (c) |  |  |  |  |  |  |  |  |  |  | 0.95 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Pension settlement charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.47 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations – diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 1.68 |  |  |  |  |  |  |  |  |  |  | $ | 1.50 |  |

[0001193125-18-032739:8k_2_02:97]
| (a) | Recorded in (Gains) Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:98]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:99]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:100]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-18-032739:8k_2_02:101]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-18-032739:8k_2_02:102]
|  |  | For the Years Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |  | Pre-Tax |  |  | TaxImpact (e) |  |  | AfterTax |  |
| Income from continuing operations, a GAAP measure |  | $ | 464.0 |  |  | $ | (156.9 | ) |  | $ | 307.1 |  |  | $ | 402.7 |  |  | $ | (124.1 | ) |  | $ | 278.6 |  |
| Restructuring charges |  |  | 3.2 |  |  |  | (1.1 | ) |  |  | 2.1 |  |  |  | 1.8 |  |  |  | (0.6 | ) |  |  | 1.2 |  |
| Special product quality adjustments (b) |  |  | 5.4 |  |  |  | (1.9 | ) |  |  | 3.5 |  |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |
| Special legal contingency charges (a) |  |  | 3.7 |  |  |  | (0.4 | ) |  |  | 3.3 |  |  |  | 1.9 |  |  |  | (0.1 | ) |  |  | 1.8 |  |
| Asbestos-related litigation (a) |  |  | 3.5 |  |  |  | (1.2 | ) |  |  | 2.3 |  |  |  | 6.3 |  |  |  | (2.2 | ) |  |  | 4.1 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  | 0.9 |  |  |  | (0.3 | ) |  |  | 0.6 |  |  |  | (3.6 | ) |  |  | 1.3 |  |  |  | (2.3 | ) |
| Environmental liabilities (a) |  |  | 2.2 |  |  |  | (0.6 | ) |  |  | 1.6 |  |  |  | 1.9 |  |  |  | (0.5 | ) |  |  | 1.4 |  |
| Contractor tax payments (a) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.6 |  |  |  | (0.2 | ) |  |  | 0.4 |  |
| Excess tax benefits from share-based compensation (c) |  |  | — |  |  |  | (23.6 | ) |  |  | (23.6 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Tax legislation impact (c) |  |  | — |  |  |  | 40.2 |  |  |  | 40.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Pension settlement charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 31.4 |  |  |  | (10.9 | ) |  |  | 20.5 |  |
| Other items, net (a) |  | $ | 1.1 |  |  | $ | (0.4 | ) |  | $ | 0.7 |  |  |  | 0.4 |  |  |  | (0.2 | ) |  |  | 0.2 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 484.1 |  |  | $ | (146.2 | ) |  | $ | 337.9 |  |  | $ | 443.0 |  |  | $ | (137.4 | ) |  | $ | 305.6 |  |
| Earnings per share from continuing operations – diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 7.17 |  |  |  |  |  |  |  |  |  |  | $ | 6.34 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.05 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Special product quality adjustments (b) |  |  |  |  |  |  |  |  |  |  | 0.08 |  |  |  |  |  |  |  |  |  |  |  | (0.01 | ) |
| Special legal contingency charges (a) |  |  |  |  |  |  |  |  |  |  | 0.08 |  |  |  |  |  |  |  |  |  |  |  | 0.04 |  |
| Asbestos-related litigation (a) |  |  |  |  |  |  |  |  |  |  | 0.05 |  |  |  |  |  |  |  |  |  |  |  | 0.09 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (a) |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | (0.05 | ) |
| Environmental liabilities (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Contractor tax payments (a) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.01 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | (0.55 | ) |  |  |  |  |  |  |  |  |  |  | — |  |
| Tax legislation impact (c) |  |  |  |  |  |  |  |  |  |  | 0.94 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Pension settlement charges |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.47 |  |
| Other items, net (a) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Change in share counts from share-based compensation (d) |  |  |  |  |  |  |  |  |  |  | 0.03 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share from continuing operations – diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 7.92 |  |  |  |  |  |  |  |  |  |  | $ | 6.95 |  |

[0001193125-18-032739:8k_2_02:103]
| (a) | Recorded in (Gains) Losses and other expenses, net in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:104]
| (b) | Recorded in Cost of goods sold in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:105]
| (c) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-18-032739:8k_2_02:106]
| (d) | The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |

[0001193125-18-032739:8k_2_02:107]
| (e) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-18-032739:8k_2_02:108]
|  |  | For the ThreeMonths EndedDecember 31,(Unaudited) |  |  | For the YearsEndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Components of (Gains) Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | (0.5 | ) |  | $ | (0.2 | ) |  | $ | (1.7 | ) |  | $ | 1.1 |  |
| Foreign currency exchange losses (a) |  |  | (1.4 | ) |  |  | 1.2 |  |  |  | (1.8 | ) |  |  | 2.2 |  |
| Losses on disposal of fixed assets (a) |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.5 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.1 | ) |  |  | (1.7 | ) |  |  | 0.9 |  |  |  | (3.6 | ) |
| Special legal contingency charges (b) |  |  | — |  |  |  | 1.4 |  |  |  | 3.7 |  |  |  | 1.9 |  |
| Asbestos-related litigation (b) |  |  | (0.3 | ) |  |  | 4.0 |  |  |  | 3.5 |  |  |  | 6.3 |  |
| Environmental liabilities (b) |  |  | 0.9 |  |  |  | 0.8 |  |  |  | 2.2 |  |  |  | 1.9 |  |
| Contractor tax payments (b) |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.6 |  |
| Acquisition/disposition expenses (b) |  |  | 1.1 |  |  |  | — |  |  |  | 1.1 |  |  |  | 0.4 |  |
| Other items, net (b) |  |  | (0.3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| (Gains) Losses and other expenses, net (pre-tax) |  | $ | (0.4 | ) |  | $ | 5.8 |  |  | $ | 8.2 |  |  | $ | 11.3 |  |

[0001193125-18-032739:8k_2_02:109]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-032739:8k_2_02:110]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-18-032739:8k_2_02:111]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations – Diluted, a Non-GAAP measure, to Income per Share from Continuing Operations – Diluted, a GAAP measure

[0001193125-18-032739:8k_2_02:112]
|  |  | For the YearEndedDecember 31,2018ESTIMATED |  |
| Income per share from continuing operations – diluted, a GAAP measure |  | $ | 9.75-$10.35 |  |
| Reconciling items |  |  | 0.00 |  |
| Adjusted income per share from continuing operations – diluted, a Non-GAAP measure |  | $ | 9.75-$10.35 |  |

[0001193125-18-032739:8k_2_02:113]
Reconciliation of Average Shares Outstanding – Diluted, a GAAP measure, to Adjusted Average Shares Outstanding –
Diluted, a Non-GAAP measure (shares in millions):

[0001193125-18-032739:8k_2_02:114]
|  |  | For theThreeMonthsEndedDecember 31, |  |  | For theTwelveMonthsEndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Average shares outstanding – diluted, a GAAP measure |  |  | 42.5 |  |  |  | 43.4 |  |  |  | 42.8 |  |  |  | 44.0 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.2 | ) |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Adjusted average shares outstanding – diluted, a Non- GAAP measure |  |  | 42.3 |  |  |  | 43.4 |  |  |  | 42.6 |  |  |  | 44.0 |  |

[0001193125-18-032739:8k_2_02:115]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-18-032739:8k_2_02:116]
|  |  | For the ThreeMonths EndedDecember 31, |  |  | For the YearsEndedDecember 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities, a GAAP measure |  | $ | 196.1 |  |  | $ | 247.0 |  |  | $ | 325.1 |  |  | $ | 373.9 |  |
| Purchases of property, plant and equipment |  |  | (37.8 | ) |  |  | (24.9 | ) |  |  | (98.3 | ) |  |  | (84.3 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Free cash flow, a Non-GAAP measure |  | $ | 158.3 |  |  | $ | 222.3 |  |  | $ | 227.0 |  |  | $ | 289.8 |  |

[0001193125-18-032739:8k_2_02:117]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  | TrailingTwelve Months to December 31,2017 |  |
| Adjusted EBIT (a) |  | $ | 514.6 |  |
| Depreciation and amortization expense (b) |  |  | 63.5 |  |
| EBITDA (a + b) |  | $ | 578.1 |  |
| Total debt at December 31, 2017 (c) |  | $ | 1,004.0 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 1.7 |  |

[0001193125-18-032739:8k_2_02:118]
Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing
Operations Before Income Taxes, a GAAP measure (dollars in millions)

[0001193125-18-032739:8k_2_02:119]
|  |  | TrailingTwelve Months to December 31,2017 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  | $ | 514.6 |  |
| Special product quality adjustments |  |  | 5.4 |  |
| Items in (Gains) Losses and other expenses, net that are excluded from segment profit |  |  | 11.5 |  |
| Restructuring charges |  |  | 3.2 |  |
| Interest expense, net |  |  | 30.6 |  |
| Other expenses, net |  |  | (0.1 | ) |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 464.0 |  |
