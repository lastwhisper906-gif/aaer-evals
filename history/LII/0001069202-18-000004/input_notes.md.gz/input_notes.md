# LII notes — 0001069202-18-000004


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-18-000004:notes:1]
The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-18-000004:notes:2]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 250.0 |  |
| Beneficial interest sold | (276.0 | ) |  | (50.0 | ) |
| Remaining amount available | $ | 14.0 |  |  | $ | 200.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-18-000004:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000004:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:ScheduleOfFairValueOfPerformanceShareUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-18-000004:notes:5]
The total fair value of performance share units distributed and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-18-000004:notes:6]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Fair value of performance share units distributed | $ | 64.3 |  |  | $ | 39.4 |  |  | $ | 44.9 |  |
| Realized tax benefits from tax deductions | $ | 24.5 |  |  | $ | 15.0 |  |  | $ | 17.1 |  |


## lii:ScheduleOfFairValueOfRestrictedStockUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-18-000004:notes:7]
The total fair value of restricted stock units vested and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-18-000004:notes:8]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Fair value of restricted stock units vested | $ | 19.0 |  |  | $ | 17.0 |  |  | $ | 19.7 |  |
| Realized tax benefits from tax deductions | 7.2 |  |  | 6.5 |  |  | 7.5 |  |


## lii:ScheduleOfIntrinsicValueAndTaxBenefitsRelatedToStockAppreciationRightsTableTextBlock

[0001069202-18-000004:notes:9]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-18-000004:notes:10]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Intrinsic value of stock appreciation rights exercised | $ | 25.1 |  |  | $ | 36.9 |  |  | $ | 27.3 |  |
| Realized tax benefits from tax deductions | $ | 9.6 |  |  | $ | 14.1 |  |  | $ | 10.4 |  |


## lii:ScheduleOfShareBasedCompensationSharesAuthorizedUnderEquityInstrumentOtherThanOptionPlansByExercisePriceRangeTableTextBlock

[0001069202-18-000004:notes:11]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2017 (in millions, except per share data and years):

[0001069202-18-000004:notes:12]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $34.06 to $81.14 |  | 0.3 |  |  | 2.21 |  | $ | 49.3 |  |  | 0.3 |  |  | 2.21 |  | $ | 49.3 |  |
| $92.64 to $ 131.94 |  | 0.3 |  |  | 4.52 |  | $ | 31.9 |  |  | 0.3 |  |  | 4.42 |  | $ | 27.5 |  |
| $156.94 to $205.53 |  | 0.4 |  |  | 6.45 |  | $ | 12.1 |  |  | 0.1 |  |  | 6.00 |  | $ | 3.9 |  |


## lii:SummaryOfTargetAllocationPercentageOfAssetsTableTextBlock

[0001069202-18-000004:notes:13]
U.S. pension plan assets are invested according to the following targets:

[0001069202-18-000004:notes:14]
| Asset Category: | Target |
| U.S. equity | 12.5 | % |
| International equity | 12.5 | % |
| Fixed income | 73.0 | % |
| Money market/cash | 2.0 | % |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-18-000004:notes:15]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-18-000004:notes:16]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Weighted average borrowing rate | 2.76 | % |  | 2.00 | % |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-18-000004:notes:17]
Accrued Expenses:

[0001069202-18-000004:notes:18]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-18-000004:notes:19]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Accrued compensation and benefits | $ | 80.7 |  |  | $ | 89.8 |  |
| Accrued rebates and promotions | 70.3 |  |  | 64.6 |  |
| Accrued warranties | 34.8 |  |  | 30.0 |  |
| Accrued sales, use, property and VAT taxes | 21.6 |  |  | 20.2 |  |
| Accrued asbestos reserves | 8.5 |  |  | 9.8 |  |
| Self insurance reserves | 7.3 |  |  | 8.2 |  |
| Deferred income | 7.3 |  |  | 6.4 |  |
| Derivative contracts | 1.4 |  |  | 4.0 |  |
| Other | 38.4 |  |  | 32.9 |  |
| Total Accrued expenses | $ | 270.3 |  |  | $ | 265.9 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-18-000004:notes:20]
Supplemental Information:

[0001069202-18-000004:notes:21]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-18-000004:notes:22]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Research and development | $ | 73.6 |  |  | $ | 64.6 |  |  | $ | 62.3 |  |
| Advertising, promotions and marketing (1) | 45.0 |  |  | 41.0 |  |  | 42.5 |  |
| Cooperative advertising expenditures (2) | 18.6 |  |  | 14.7 |  |  | 13.7 |  |
| Rent expense | 57.7 |  |  | 57.9 |  |  | 53.5 |  |

[0001069202-18-000004:notes:23]
(1) Cooperative advertising expenditures were not included in these amounts.

[0001069202-18-000004:notes:24]
(2) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-18-000004:notes:25]
Interest Expense, net

[0001069202-18-000004:notes:26]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-18-000004:notes:27]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Interest expense, net of capitalized interest | $ | 32.1 |  |  | $ | 28.1 |  |  | $ | 25.2 |  |
| Interest income | 1.5 |  |  | 1.1 |  |  | 1.6 |  |
| Interest expense, net | $ | 30.6 |  |  | $ | 27.0 |  |  | $ | 23.6 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-18-000004:notes:28]
Cash and Cash Equivalents

[0001069202-18-000004:notes:29]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-18-000004:notes:30]
Commitments and Contingencies:

[0001069202-18-000004:notes:31]
Leases

[0001069202-18-000004:notes:32]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-18-000004:notes:33]
Future annual minimum lease payments and capital lease commitments as of December 31, 2017 were as follows (in millions):

[0001069202-18-000004:notes:34]
|  | Operating Leases |  | Capital Leases |
| 2018 | $ | 55.3 |  |  | $ | 3.5 |  |
| 2019 | 42.4 |  |  | 0.6 |  |
| 2020 | 28.4 |  |  | 0.4 |  |
| 2021 | 18.3 |  |  | 0.1 |  |
| 2022 | 17.7 |  |  | — |  |
| Thereafter | 13.8 |  |  | 12.0 |  |
| Total minimum lease payments | $ | 175.9 |  |  | $ | 16.6 |  |
| Less amount representing interest |  |  | 0.2 |  |
| Present value of minimum payments |  |  | $ | 16.4 |  |

[0001069202-18-000004:notes:35]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above.

[0001069202-18-000004:notes:36]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our Sixth Amended and Restated Credit Facility Agreement.  We believe we were in compliance with these financial covenants as of December 31, 2017.

[0001069202-18-000004:notes:37]
Environmental

[0001069202-18-000004:notes:38]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000004:notes:39]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Accrued expenses | $ | 3.5 |  |  | $ | 1.2 |  |
| Other liabilities | 3.1 |  |  | 4.4 |  |
| Total environmental accruals | $ | 6.6 |  |  | $ | 5.6 |  |

[0001069202-18-000004:notes:40]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-18-000004:notes:41]
Product Warranties and Product Related Contingencies

[0001069202-18-000004:notes:42]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-18-000004:notes:43]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000004:notes:44]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Accrued expenses | $ | 34.8 |  |  | $ | 30.0 |  |
| Other liabilities | 75.1 |  |  | 71.1 |  |
| Total product warranty liabilities | $ | 109.9 |  |  | $ | 101.1 |  |

[0001069202-18-000004:notes:45]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2017 and 2016 were as follows (in millions):

[0001069202-18-000004:notes:46]
| Total warranty liability as of December 31, 2015 | $ | 92.3 |  |
| Payments made in 2016 | (24.7 | ) |
| Changes resulting from issuance of new warranties | 36.2 |  |
| Changes in estimates associated with pre-existing liabilities | (2.6 | ) |
| Changes in foreign currency translation rates and other | (0.1 | ) |
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Payments made in 2017 | (28.8 | ) |
| Changes resulting from issuance of new warranties | 41.1 |  |
| Changes in estimates associated with pre-existing liabilities | (4.8 | ) |
| Changes in foreign currency translation rates and other | 1.3 |  |
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |

[0001069202-18-000004:notes:47]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001069202-18-000004:notes:48]
During the second quarter of 2017, we identified a product quality issue in a defective vendor-supplied component affecting a product line in the Residential Heating & Cooling segment. This defect has been isolated, the vendor is supplying corrected components, and we are manufacturing product with the corrected components.  We have also implemented a program for our dealers to install corrected components in the field. We recorded an expense of $5.7 million for the twelve months ended December 31, 2017, relating to estimated repair costs. The expense related to this product quality issue has been classified in Cost of goods sold in the Consolidated Statements of Operations and the related liability is included in Accrued expenses on the Consolidated Balance Sheet.

[0001069202-18-000004:notes:49]
Self-Insurance

[0001069202-18-000004:notes:50]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers' compensation/employers' liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors' and officers' liability, property damage and certain other insurance programs.    For directors' and officers' liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-18-000004:notes:51]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-18-000004:notes:52]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000004:notes:53]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Accrued expenses | $ | 7.3 |  |  | $ | 8.2 |  |
| Other liabilities | 21.6 |  |  | 22.7 |  |
| Total self-insurance liabilities | $ | 28.9 |  |  | $ | 30.9 |  |

[0001069202-18-000004:notes:54]
Litigation

[0001069202-18-000004:notes:55]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-18-000004:notes:56]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  We currently estimate our probable liability for known and future asbestos-related litigation cases to be between $28.5 million and $46.5 million before consideration of probable insurance recoveries with all amounts in that range equally likely.  We have accrued $8.5 million in Accrued expenses and $20.0 million in Other liabilities in the Consolidated Balance at December 31, 2017.  For the years ended December 31, 2017, 2016 and 2015, we recorded expense of $3.5 million, $6.3 million and $0.9 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation  and is recorded in Losses and other expenses, net in the Consolidated Statements of Operations.

[0001069202-18-000004:notes:57]
In October 2016, we self-reported to the Securities and Exchange Commission (SEC) and the Department of Justice (DOJ) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We continue to fully cooperate with the SEC and the DOJ regarding this matter. We do not anticipate any material adverse effect on our business or financial condition as a result of this matter.

[0001069202-18-000004:notes:58]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-18-000004:notes:59]
Comprehensive Income:

[0001069202-18-000004:notes:60]
The following table provides information on items not reclassified in their entirety from AOCI to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-18-000004:notes:61]
|  |  | For the Years Ended December 31, |  |  |
| AOCI Component |  | 2017 |  | 2016 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | 13.7 |  |  | $ | (12.3 | ) |  | Cost of goods sold |
| Income tax benefit |  | (5.0 | ) |  | 4.3 |  |  | Provision for income taxes |
| Net of tax |  | $ | 8.7 |  |  | $ | (8.0 | ) |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (7.3 | ) |  | $ | (6.3 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 2.8 |  |  | 2.2 |  |  | Provision for income taxes |
| Net of tax |  | $ | (4.5 | ) |  | $ | (4.1 | ) |  |  |
| Total reclassifications from AOCI |  | $ | 4.2 |  |  | $ | (12.1 | ) |  |  |

[0001069202-18-000004:notes:62]
The following tables provide information on changes in AOCI, by component (net of tax), for the years ended December 31, 2017 and 2016 (in millions):

[0001069202-18-000004:notes:63]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |
| Other comprehensive income (loss) before reclassifications |  | 10.5 |  |  | (0.5 | ) |  | (2.0 | ) |  | 33.9 |  |  | 41.9 |  |
| Amounts reclassified from AOCI |  | (8.7 | ) |  | — |  |  | 4.5 |  |  | — |  |  | (4.2 | ) |
| Net other comprehensive income (loss) |  | 1.8 |  |  | (0.5 | ) |  | 2.5 |  |  | 33.9 |  |  | 37.7 |  |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |

[0001069202-18-000004:notes:64]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCI |
| Balance as of December 31, 2015 |  | $ | (8.4 | ) |  | $ | 4.4 |  |  | $ | (139.3 | ) |  | $ | (61.4 | ) |  | $ | (204.7 | ) |
| Other comprehensive income (loss) before reclassifications |  | 6.0 |  |  | (2.1 | ) |  | 5.2 |  |  | (11.6 | ) |  | (2.5 | ) |
| Amounts reclassified from AOCI |  | 8.0 |  |  | — |  |  | 4.1 |  |  | — |  |  | 12.1 |  |
| Net other comprehensive income (loss) |  | 14.0 |  |  | (2.1 | ) |  | 9.3 |  |  | (11.6 | ) |  | 9.6 |  |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-18-000004:notes:65]
Condensed Consolidating Financial Statements:

[0001069202-18-000004:notes:66]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-18-000004:notes:67]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-18-000004:notes:68]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-18-000004:notes:69]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2017 and December 31, 2016 and for the years ended December 31, 2017, 2016 and 2015 are shown on the following pages.

[0001069202-18-000004:notes:70]
Condensed Consolidating Balance Sheets

[0001069202-18-000004:notes:71]
As of December 31, 2017

[0001069202-18-000004:notes:72]
(In millions)

[0001069202-18-000004:notes:73]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net | — |  |  | 35.3 |  |  | 471.2 |  |  | — |  |  | 506.5 |  |
| Inventories, net | — |  |  | 355.7 |  |  | 131.9 |  |  | (3.4 | ) |  | 484.2 |  |
| Other assets | 16.2 |  |  | 23.1 |  |  | 67.5 |  |  | (28.4 | ) |  | 78.4 |  |
| Total current assets | 17.8 |  |  | 442.1 |  |  | 709.2 |  |  | (31.8 | ) |  | 1,137.3 |  |
| Property, plant and equipment, net | — |  |  | 257.6 |  |  | 144.4 |  |  | (4.2 | ) |  | 397.8 |  |
| Goodwill | — |  |  | 134.9 |  |  | 65.6 |  |  | — |  |  | 200.5 |  |
| Investment in subsidiaries | 1,257.7 |  |  | 365.8 |  |  | (0.6 | ) |  | (1,622.9 | ) |  | — |  |
| Deferred income taxes | 3.9 |  |  | 69.1 |  |  | 33.6 |  |  | (12.2 | ) |  | 94.4 |  |
| Other assets, net | 2.1 |  |  | 41.3 |  |  | 19.6 |  |  | (1.5 | ) |  | 61.5 |  |
| Intercompany receivables (payables), net | (559.3 | ) |  | 554.7 |  |  | 107.4 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 32.6 |  |
| Accounts payable | 21.3 |  |  | 228.0 |  |  | 99.3 |  |  | — |  |  | 348.6 |  |
| Accrued expenses | 3.1 |  |  | 209.4 |  |  | 57.8 |  |  | — |  |  | 270.3 |  |
| Income taxes payable | (64.5 | ) |  | 56.5 |  |  | 60.9 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | (10.7 | ) |  | 496.8 |  |  | 219.2 |  |  | (50.8 | ) |  | 654.5 |  |
| Long-term debt | 682.8 |  |  | 11.7 |  |  | 276.0 |  |  | — |  |  | 970.5 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.6 |  |  | — |  |  | — |  |  | 2.6 |  |
| Pensions | — |  |  | 74.7 |  |  | 9.8 |  |  | — |  |  | 84.5 |  |
| Other liabilities | — |  |  | 120.6 |  |  | 8.7 |  |  | — |  |  | 129.3 |  |
| Total liabilities | 672.1 |  |  | 706.4 |  |  | 513.7 |  |  | (50.8 | ) |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 50.1 |  |  | 1,159.1 |  |  | 565.5 |  |  | (1,724.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders' equity | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |

[0001069202-18-000004:notes:74]
As of December 31, 2016

[0001069202-18-000004:notes:75]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |
| Accounts and notes receivable, net | — |  |  | 30.6 |  |  | 439.2 |  |  | — |  |  | 469.8 |  |
| Inventories, net | — |  |  | 314.7 |  |  | 108.9 |  |  | (5.1 | ) |  | 418.5 |  |
| Other assets | 12.8 |  |  | 48.8 |  |  | 67.5 |  |  | (61.7 | ) |  | 67.4 |  |
| Total current assets | 14.0 |  |  | 411.2 |  |  | 647.5 |  |  | (66.8 | ) |  | 1,005.9 |  |
| Property, plant and equipment, net | — |  |  | 237.6 |  |  | 123.8 |  |  | — |  |  | 361.4 |  |
| Goodwill | — |  |  | 134.9 |  |  | 60.2 |  |  | — |  |  | 195.1 |  |
| Investment in subsidiaries | 1,166.9 |  |  | 524.7 |  |  | (0.5 | ) |  | (1,691.1 | ) |  | — |  |
| Deferred income taxes | 6.8 |  |  | 113.5 |  |  | 31.1 |  |  | (14.7 | ) |  | 136.7 |  |
| Other assets, net | 3.6 |  |  | 40.0 |  |  | 19.0 |  |  | (1.4 | ) |  | 61.2 |  |
| Intercompany receivables (payables), net | (382.4 | ) |  | 375.2 |  |  | 80.4 |  |  | (73.2 | ) |  | — |  |
| Total assets | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | — |  |  | $ | 52.4 |  |
| Current maturities of long-term debt | 199.3 |  |  | 0.4 |  |  | 0.4 |  |  | — |  |  | 200.1 |  |
| Accounts payable | 18.5 |  |  | 248.5 |  |  | 94.2 |  |  | — |  |  | 361.2 |  |
| Accrued expenses | 6.3 |  |  | 206.3 |  |  | 53.3 |  |  | — |  |  | 265.9 |  |
| Income taxes payable | (54.0 | ) |  | 89.8 |  |  | 52.5 |  |  | (79.3 | ) |  | 9.0 |  |
| Total current liabilities | 170.1 |  |  | 545.0 |  |  | 252.8 |  |  | (79.3 | ) |  | 888.6 |  |
| Long-term debt | 600.9 |  |  | 14.5 |  |  | 0.3 |  |  | — |  |  | 615.7 |  |
| Post-retirement benefits, other than pensions | — |  |  | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |
| Pensions | — |  |  | 75.5 |  |  | 12.0 |  |  | — |  |  | 87.5 |  |
| Other liabilities | — |  |  | 119.1 |  |  | 11.1 |  |  | (2.5 | ) |  | 127.7 |  |
| Total liabilities | 771.0 |  |  | 756.9 |  |  | 276.2 |  |  | (81.8 | ) |  | 1,722.3 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders' equity | 37.9 |  |  | 1,080.2 |  |  | 685.3 |  |  | (1,765.4 | ) |  | 38.0 |  |
| Total liabilities and stockholders' equity | $ | 808.9 |  |  | $ | 1,837.1 |  |  | $ | 961.5 |  |  | $ | (1,847.2 | ) |  | $ | 1,760.3 |  |

[0001069202-18-000004:notes:76]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-18-000004:notes:77]
For the Year Ended December 31, 2017

[0001069202-18-000004:notes:78]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,295.8 |  |  | $ | 1,144.2 |  |  | $ | (600.4 | ) |  | $ | 3,839.6 |  |
| Cost of goods sold | — |  |  | 2,359.6 |  |  | 953.6 |  |  | (598.8 | ) |  | 2,714.4 |  |
| Gross profit | — |  |  | 936.2 |  |  | 190.6 |  |  | (1.6 | ) |  | 1,125.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 553.6 |  |  | 85.0 |  |  | (0.9 | ) |  | 637.7 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 4.4 |  |  | 1.9 |  |  | (0.1 | ) |  | 8.2 |  |
| Restructuring charges | — |  |  | 2.1 |  |  | 1.1 |  |  | — |  |  | 3.2 |  |
| Goodwill impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| (Income) loss from equity method investments | (324.3 | ) |  | (74.9 | ) |  | (14.5 | ) |  | 395.3 |  |  | (18.4 | ) |
| Operational income | 322.3 |  |  | 451.0 |  |  | 117.1 |  |  | (395.9 | ) |  | 494.5 |  |
| Interest expense, net | 26.9 |  |  | (2.7 | ) |  | 6.4 |  |  | — |  |  | 30.6 |  |
| Other income, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 295.4 |  |  | 453.7 |  |  | 110.8 |  |  | (395.9 | ) |  | 464.0 |  |
| Provision for income taxes | (10.3 | ) |  | 136.2 |  |  | 31.2 |  |  | (0.2 | ) |  | 156.9 |  |
| Income from continuing operations | 305.7 |  |  | 317.5 |  |  | 79.6 |  |  | (395.7 | ) |  | 307.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Net income | $ | 305.7 |  |  | $ | 317.5 |  |  | $ | 78.2 |  |  | $ | (395.7 | ) |  | $ | 305.7 |  |
| Other comprehensive income (loss) | $ | 1.7 |  |  | $ | 5.5 |  |  | $ | 30.5 |  |  | $ | — |  |  | $ | 37.7 |  |
| Comprehensive Income | $ | 307.4 |  |  | $ | 323.0 |  |  | $ | 108.7 |  |  | $ | (395.7 | ) |  | $ | 343.4 |  |

[0001069202-18-000004:notes:79]
For the Year Ended December 31, 2016

[0001069202-18-000004:notes:80]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 3,117.6 |  |  | $ | 728.0 |  |  | $ | (204.0 | ) |  | $ | 3,641.6 |  |
| Cost of goods sold | — |  |  | 2,203.8 |  |  | 564.5 |  |  | (203.2 | ) |  | 2,565.1 |  |
| Gross profit | — |  |  | 913.8 |  |  | 163.5 |  |  | (0.8 | ) |  | 1,076.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 524.3 |  |  | 96.7 |  |  | — |  |  | 621.0 |  |
| Losses (gains) and other expenses, net | (3.3 | ) |  | 9.7 |  |  | 5.1 |  |  | (0.2 | ) |  | 11.3 |  |
| Restructuring charges | — |  |  | 1.9 |  |  | (0.1 | ) |  | — |  |  | 1.8 |  |
| Goodwill Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement | — |  |  | 30.5 |  |  | 0.9 |  |  | — |  |  | 31.4 |  |
| (Income) loss from equity method investments | (292.4 | ) |  | (40.7 | ) |  | (14.4 | ) |  | 329.1 |  |  | (18.4 | ) |
| Operational income | 295.7 |  |  | 388.1 |  |  | 75.3 |  |  | (329.7 | ) |  | 429.4 |  |
| Interest expense, net | 24.4 |  |  | (2.2 | ) |  | 4.8 |  |  | — |  |  | 27.0 |  |
| Other income, net | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Income from continuing operations before income taxes | 271.3 |  |  | 390.3 |  |  | 70.8 |  |  | (329.7 | ) |  | 402.7 |  |
| Provision for income taxes | (6.5 | ) |  | 108.2 |  |  | 22.6 |  |  | (0.2 | ) |  | 124.1 |  |
| Income from continuing operations | 277.8 |  |  | 282.1 |  |  | 48.2 |  |  | (329.5 | ) |  | 278.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Net income | $ | 277.8 |  |  | $ | 282.1 |  |  | $ | 47.4 |  |  | $ | (329.5 | ) |  | $ | 277.8 |  |
| Other comprehensive income (loss) | $ | 14.0 |  |  | $ | 8.5 |  |  | $ | (14.2 | ) |  | $ | 1.3 |  |  | $ | 9.6 |  |
| Comprehensive income | $ | 291.8 |  |  | $ | 290.6 |  |  | $ | 33.2 |  |  | $ | (328.2 | ) |  | $ | 287.4 |  |

[0001069202-18-000004:notes:81]
For the Year Ended December 31, 2015

[0001069202-18-000004:notes:82]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 2,950.6 |  |  | $ | 701.8 |  |  | $ | (185.0 | ) |  | $ | 3,467.4 |  |
| Cost of goods sold | — |  |  | 2,150.9 |  |  | 556.4 |  |  | (187.3 | ) |  | 2,520.0 |  |
| Gross profit | — |  |  | 799.7 |  |  | 145.4 |  |  | 2.3 |  |  | 947.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 485.6 |  |  | 94.9 |  |  | — |  |  | 580.5 |  |
| Losses (gains) and other expenses, net | 0.7 |  |  | 13.7 |  |  | 7.5 |  |  | (0.2 | ) |  | 21.7 |  |
| Restructuring charges | — |  | — |  | (0.5 | ) |  | 3.7 |  |  | — |  |  | 3.2 |  |
| Goodwill impairment | — |  |  | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Asset impairment | — |  |  | 44.5 |  |  | — |  |  | — |  |  | 44.5 |  |
| Pension settlement | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| (Income) loss from equity method investments | (201.8 | ) |  | (5.9 | ) |  | (10.5 | ) |  | 204.8 |  |  | (13.4 | ) |
| Operational income | 201.1 |  |  | 256.8 |  |  | 49.8 |  |  | (202.3 | ) |  | 305.4 |  |
| Interest expense, net | 22.4 |  |  | (2.0 | ) |  | 3.2 |  |  | — |  |  | 23.6 |  |
| Other income, net | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Income from continuing operations before income taxes | 178.7 |  |  | 258.8 |  |  | 47.4 |  |  | (202.3 | ) |  | 282.6 |  |
| Provision for income taxes | (7.8 | ) |  | 87.9 |  |  | 14.3 |  |  | 1.0 |  |  | 95.4 |  |
| Income from continuing operations | 186.5 |  |  | 170.9 |  |  | 33.1 |  |  | (203.3 | ) |  | 187.2 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Net income | $ | 186.5 |  |  | $ | 170.9 |  |  | $ | 32.5 |  |  | $ | (203.3 | ) |  | $ | 186.6 |  |
| Other comprehensive income (loss) | $ | (3.5 | ) |  | $ | (3.3 | ) |  | $ | (40.4 | ) |  | $ | (4.0 | ) |  | $ | (51.2 | ) |
| Comprehensive Income | $ | 183.0 |  |  | $ | 167.6 |  |  | $ | (7.9 | ) |  | $ | (207.3 | ) |  | $ | 135.4 |  |

[0001069202-18-000004:notes:83]
Condensed Consolidating Statements of Cash Flows

[0001069202-18-000004:notes:84]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 467.4 |  |  | $ | 31.1 |  |  | $ | (173.4 | ) |  | $ | — |  |  | $ | 325.1 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (70.7 | ) |  | (27.6 | ) |  | — |  |  | (98.3 | ) |
| Net cash used in investing activities | — |  |  | (70.6 | ) |  | (27.5 | ) |  | — |  |  | (98.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.5 | ) |  | — |  |  | (1.5 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 315.0 |  |  | — |  |  | 315.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (89.0 | ) |  | — |  |  | (89.0 | ) |
| Long-term debt borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from credit facility | 2,376.5 |  |  | — |  |  | — |  |  | — |  |  | 2,376.5 |  |
| Long-term debt payments | (200.0 | ) |  | (0.3 | ) |  | (0.6 | ) |  | — |  |  | (200.9 | ) |
| Payments on credit facility | (2,265.5 | ) |  | — |  |  | — |  |  | — |  |  | (2,265.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Proceeds from employee stock purchases | 3.1 |  |  | — |  |  | — |  |  | — |  |  | 3.1 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.1 | ) |  | — |  |  | — |  |  | — |  |  | (26.1 | ) |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Excess tax benefits related to share-based payments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Intercompany debt | 56.4 |  |  | (34.9 | ) |  | (21.5 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (81.7 | ) |  | 85.6 |  |  | (3.9 | ) |  | — |  |  | — |  |
| Cash dividends paid | (79.7 | ) |  | — |  |  | — |  |  | — |  |  | (79.7 | ) |
| Net cash provided by (used in) financing activities | (467.0 | ) |  | 50.4 |  |  | 198.3 |  |  | — |  |  | (218.3 | ) |
| Increase (decrease) in cash and cash equivalents | 0.4 |  |  | 10.9 |  |  | (2.6 | ) |  | — |  |  | 8.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 9.3 |  |  | — |  |  | 9.3 |  |
| Cash and cash equivalents, beginning of year | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of year | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |

[0001069202-18-000004:notes:85]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 17.8 |  |  | $ | 218.5 |  |  | $ | 137.6 |  |  | $ | — |  |  | $ | 373.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (71.5 | ) |  | (12.8 | ) |  | — |  |  | (84.3 | ) |
| Net cash used in investing activities | — |  |  | (71.5 | ) |  | (12.6 | ) |  | — |  |  | (84.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (2.4 | ) |  | — |  |  | (2.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 145.0 |  |  | — |  |  | 145.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (295.0 | ) |  | — |  |  | (295.0 | ) |
| Long-term debt borrowings | 350.0 |  |  | — |  |  | — |  |  | — |  |  | 350.0 |  |
| Borrowings from credit facility | 2,336.5 |  |  | — |  |  | — |  |  | — |  |  | 2,336.5 |  |
| Long-term debt payments | (57.5 | ) |  | (0.9 | ) |  | (0.4 | ) |  | — |  |  | (58.8 | ) |
| Payments on credit facility | (2,346.0 | ) |  | — |  |  | — |  |  | — |  |  | (2,346.0 | ) |
| Payments of deferred financing costs | (4.2 | ) |  | — |  |  | — |  |  | — |  |  | (4.2 | ) |
| Proceeds from employee stock purchases | 2.6 |  |  | — |  |  | — |  |  | — |  |  | 2.6 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (33.3 | ) |  | — |  |  | — |  |  | — |  |  | (33.3 | ) |
| Repurchases of common stock | (300.0 | ) |  | — |  |  | — |  |  | — |  |  | (300.0 | ) |
| Intercompany debt | 30.0 |  |  | (65.8 | ) |  | 35.8 |  |  | — |  |  | — |  |
| Intercompany financing activity | 73.8 |  |  | (71.0 | ) |  | (2.8 | ) |  | — |  |  | — |  |
| Cash dividends paid | (69.0 | ) |  | — |  |  | — |  |  | — |  |  | (69.0 | ) |
| Net cash provided by (used in) financing activities | (17.1 | ) |  | (137.7 | ) |  | (119.8 | ) |  | — |  |  | (274.6 | ) |
| Increase (decrease) in cash and cash equivalents | 0.7 |  |  | 9.3 |  |  | 5.2 |  |  | — |  |  | 15.2 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.9 | ) |  | — |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of year | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of year | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |

[0001069202-18-000004:notes:86]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 249.3 |  |  | $ | 49.3 |  |  | $ | 55.0 |  |  | $ | — |  |  | $ | 353.6 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (60.2 | ) |  | (9.7 | ) |  | — |  |  | (69.9 | ) |
| Net cash used in investing activities | — |  |  | (60.1 | ) |  | (9.7 | ) |  | — |  |  | (69.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.7 | ) |  | — |  |  | (1.7 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 40.0 |  |  | — |  |  | 40.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (60.0 | ) |  | — |  |  | (60.0 | ) |
| Long-term debt borrowings | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Borrowings from revolving credit facility | 1,671.0 |  |  | — |  |  | — |  |  | — |  |  | 1,671.0 |  |
| Long-term debt payments | (22.5 | ) |  | (1.2 | ) |  | (0.3 | ) |  | — |  |  | (24.0 | ) |
| Payments on revolving credit facility | (1,807.5 | ) |  | — |  |  | — |  |  | — |  |  | (1,807.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Proceeds from employee stock purchases | 2.4 |  |  | — |  |  | — |  |  | — |  |  | 2.4 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (32.0 | ) |  | — |  |  | — |  |  | — |  |  | (32.0 | ) |
| Repurchases of common stock | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Intercompany debt | (9.4 | ) |  | 7.1 |  |  | 2.3 |  |  | — |  |  | — |  |
| Intercompany financing activity | 7.5 |  |  | 1.2 |  |  | (8.7 | ) |  | — |  |  | — |  |
| Cash dividends paid | (59.3 | ) |  | — |  |  | — |  |  | — |  |  | (59.3 | ) |
| Net cash provided by (used in) financing activities | (249.8 | ) |  | 7.1 |  |  | (28.4 | ) |  | — |  |  | (271.1 | ) |
| Decrease in cash and cash equivalents | (0.5 | ) |  | (3.7 | ) |  | 16.9 |  |  | — |  |  | 12.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (11.3 | ) |  | — |  |  | (11.3 | ) |
| Cash and cash equivalents, beginning of year | 1.0 |  |  | 11.5 |  |  | 25.0 |  |  | — |  |  | 37.5 |  |
| Cash and cash equivalents, end of year | $ | 0.5 |  |  | $ | 7.8 |  |  | $ | 30.6 |  |  | $ | — |  |  | $ | 38.9 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-18-000004:notes:87]
Principles of Consolidation

[0001069202-18-000004:notes:88]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-18-000004:notes:89]
Cost of Goods Sold

[0001069202-18-000004:notes:90]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-18-000004:notes:91]
Lines of Credit and Financing Arrangements:

[0001069202-18-000004:notes:92]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000004:notes:93]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | — |  |  | $ | 50.0 |  |
| Foreign obligations | 0.9 |  |  | 2.4 |  |
| Total short-term debt | $ | 0.9 |  |  | $ | 52.4 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 3.2 |  |  | $ | 0.8 |  |
| Domestic credit facility | 30.0 |  |  | — |  |
| Senior unsecured notes | — |  |  | 200.0 |  |
| Debt issuance costs | (0.6 | ) |  | (0.7 | ) |
| Total current maturities of long-term debt | $ | 32.6 |  |  | $ | 200.1 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 276.0 |  |  | $ | — |  |
| Capital lease obligations | 11.9 |  |  | 15.0 |  |
| Domestic credit facility | 337.0 |  |  | 256.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (4.4 | ) |  | (5.3 | ) |
| Total long-term debt | $ | 970.5 |  |  | $ | 615.7 |  |
| Total debt | $ | 1,004.0 |  |  | $ | 868.2 |  |

[0001069202-18-000004:notes:94]
As of December 31, 2017, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-18-000004:notes:95]
| 2018 | $ | 34.1 |  |
| 2019 | 306.3 |  |
| 2020 | 30.0 |  |
| 2021 | 277.0 |  |
| 2022 | — |  |
| Thereafter | 361.6 |  |

[0001069202-18-000004:notes:96]
Short-Term Debt

[0001069202-18-000004:notes:97]
Foreign Obligations

[0001069202-18-000004:notes:98]
Through several of our foreign subsidiaries, we have available to us facilities to assist in financing seasonal borrowing needs for our foreign locations. We had $0.9 million and $2.4 million of foreign obligations as of December 31, 2017 and 2016, respectively, that were primarily borrowings under non-committed facilities.  Proceeds on these facilities were $30.4 million, $28.4 million and $79.0 million during the years ended December 31, 2017, 2016 and 2015, respectively. Repayments on the facilities were $31.9 million, $30.8 million and $85.4 million during the years ended December 31, 2017, 2016 and 2015, respectively.

[0001069202-18-000004:notes:99]
Asset Securitization Program

[0001069202-18-000004:notes:100]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to participating financial institutions for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables sold under the ASP.  The fair values assigned to the retained and transferred interests are based on the sold accounts receivable carrying value given the short term to maturity and low credit risk.  The sale of the beneficial interests in our trade accounts receivable are reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows.

[0001069202-18-000004:notes:101]
Prior to the amendment on November 13, 2017, the ASP provided for a maximum securitization amount ranging from $200.0 million to $325.0 million, depending on the period.  The ASP was amended effective as of November 13, 2017 to increase the maximum securitization range from $225.0 million to $380.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-18-000004:notes:102]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of December 31, 2017 and 2016 were 2.60% and 1.66%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-18-000004:notes:103]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of December 31, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-18-000004:notes:104]
Long-Term Debt

[0001069202-18-000004:notes:105]
Domestic Credit Facility

[0001069202-18-000004:notes:106]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the "Maturity Date"). Under our Domestic Credit Facility, we had outstanding borrowings of $367.0 million, of which $220.0 million was the term loan balance, as well as $2.9 million committed to standby letters of credit as of December 31, 2017.  Subject to covenant limitations, $500.1 million was available for future borrowings. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning in March 2017; however, we made $30.0 million of required principal repayments for 2017 in November 2016.  The revolving credit facility allows up to $100.0 million of letters of credit to be issued and also includes a subfacility for swingline loans of up to $65.0 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million as long as existing or new lenders agree to provide such additional commitments.

[0001069202-18-000004:notes:107]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-18-000004:notes:108]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our Domestic Credit Facility could occur if:

[0001069202-18-000004:notes:109]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-18-000004:notes:110]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-18-000004:notes:111]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-18-000004:notes:112]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2017, we believe we were in compliance with all covenant requirements.

[0001069202-18-000004:notes:113]
Senior Unsecured Notes

[0001069202-18-000004:notes:114]
We issued $350.0 million of senior unsecured notes in November 2016 (the "Notes") which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually.  We also repaid  $200.0 million of senior unsecured notes issued in 2010 which matured on May 15, 2017.  The Notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2017, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-18-000004:notes:115]
Derivatives:

[0001069202-18-000004:notes:116]
Objectives and Strategies for Using Derivative Instruments

[0001069202-18-000004:notes:117]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-18-000004:notes:118]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-18-000004:notes:119]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-18-000004:notes:120]
Cash Flow Hedges

[0001069202-18-000004:notes:121]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2019 and December 2018, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCI and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities at the settlement dates.

[0001069202-18-000004:notes:122]
We recorded the following amounts related to our cash flow hedges in AOCI (in millions):

[0001069202-18-000004:notes:123]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Unrealized gains on unsettled contracts | $ | (11.3 | ) |  | $ | (8.9 | ) |
| Income tax expense | 3.9 |  |  | 3.3 |  |
| Gains included in AOCI, net of tax (1) | $ | (7.4 | ) |  | $ | (5.6 | ) |

[0001069202-18-000004:notes:124]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $7.1 million of derivative gains into earnings within the next 12 months.

[0001069202-18-000004:notes:125]
We had the following outstanding commodity futures contracts designated as cash flow hedges (in millions of pounds):

[0001069202-18-000004:notes:126]
|  | As of December 31, |
| Notional Amounts | 2017 |  | 2016 |
| Copper | 20.6 |  |  | 30.4 |  |

[0001069202-18-000004:notes:127]
We had the following outstanding foreign exchange forward contracts designated as cash flow hedges (in millions):

[0001069202-18-000004:notes:128]
|  | As of December 31, |
| Notional Amounts (in local currency): | 2017 |  | 2016 |
| Mexican Peso | 207.3 |  |  | 310.1 |  |
| Canadian Dollar | 68.6 |  |  | 24.9 |  |

[0001069202-18-000004:notes:129]
Derivatives not Designated as Cash Flow Hedges

[0001069202-18-000004:notes:130]
For commodity derivatives not designated as cash flow hedges, we follow the same hedging strategy as derivatives designated as cash flow hedges, except that we elect not to designate them as cash flow hedges at the inception of the arrangement. We had

[0001069202-18-000004:notes:131]
the following outstanding commodity futures contracts not designated as cash flow hedges (in millions of pounds):

[0001069202-18-000004:notes:132]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Copper | 1.8 |  |  | 2.4 |  |
| Aluminum | 1.8 |  |  | 2.6 |  |

[0001069202-18-000004:notes:133]
We had the following outstanding foreign currency forward contracts not designated as cash flow hedges (in millions):

[0001069202-18-000004:notes:134]
|  | As of December 31, |
| Notional amounts (in local currency): | 2017 |  | 2016 |
| Chinese Yuan | 73.8 |  |  | 10.5 |  |
| Mexican Peso | 136.6 |  |  | 64.5 |  |
| Euro | 64.4 |  |  | 46.9 |  |
| British Pound | 4.5 |  |  | 1.3 |  |
| Indian Rupee | 39.8 |  |  | 584.6 |  |
| Singapore Dollar | 7.0 |  |  | — |  |
| Australian Dollar | 107.0 |  |  | — |  |
| New Zealand Dollar | 5.0 |  |  | — |  |
| Canadian Dollar | 27.3 |  |  | — |  |

[0001069202-18-000004:notes:135]
Information About the Locations and Amounts of Derivative Instruments

[0001069202-18-000004:notes:136]
The following tables provide the locations and amounts of derivative fair values in the Consolidated Balance Sheets and derivative gains and losses in the Consolidated Statements of Operations (in millions):

[0001069202-18-000004:notes:137]
|  | Fair Values of Derivative Instruments as of December 31 (1) |
|  | Derivatives Designated as Hedging Instruments |  | Derivatives Not Designated asHedging Instruments |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Current Assets: |  |  |  |  |  |  |  |
| Other assets |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | 11.0 |  |  | $ | 8.7 |  |  | $ | 1.2 |  |  | $ | 0.7 |  |
| Foreign currency forward contracts | 0.1 |  |  | 0.5 |  |  | 0.9 |  |  | 0.2 |  |
| Non-Current Assets: |  |  |  |  |  |  |  |
| Other assets, net |  |  |  |  |  |  |  |
| Commodity futures contracts | 0.6 |  |  | 1.9 |  |  | 0.1 |  |  | 0.2 |  |
| Foreign currency forward contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total Assets | $ | 11.7 |  |  | $ | 11.1 |  |  | $ | 2.2 |  |  | $ | 1.1 |  |
| Current Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses |  |  |  |  |  |  |  |
| Commodity futures contracts | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward contracts | 0.3 |  |  | 0.8 |  |  | 1.1 |  |  | 3.2 |  |
| Total Liabilities | $ | 0.3 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |  | $ | 3.2 |  |

[0001069202-18-000004:notes:138]
(1) All derivative instruments are classified as Level 2 within the fair value hierarchy. See Note 19 for more information on fair value measurements.

[0001069202-18-000004:notes:139]
| Derivatives in Cash Flow Hedging Relationships |
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Amount of (Gain) Loss Reclassified from AOCI into Income (Effective Portion): |  |  |  |  |  |
| Commodity futures contracts (1) | $ | (13.7 | ) |  | $ | 12.3 |  |  | $ | 12.5 |  |
| Amount of Loss (Gain) Recognized in Income on Derivatives (Ineffective Portion): |  |  |  |  |  |
| Commodity futures contracts (2) | $ | 1.0 |  |  | $ | (1.6 | ) |  | $ | 0.1 |  |

[0001069202-18-000004:notes:140]
| Derivatives Not Designated as Hedging Instruments |
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Amount of (Gain) Loss Recognized in Income on Derivatives: |  |  |  |  |  |
| Commodity futures contracts (2) | $ | (1.9 | ) |  | $ | (0.9 | ) |  | $ | 2.5 |  |
| Foreign currency forward contracts (2) | (5.7 | ) |  | 4.3 |  |  | 0.3 |  |
|  | $ | (7.6 | ) |  | $ | 3.4 |  |  | $ | 2.8 |  |

[0001069202-18-000004:notes:141]
(1) The (gain) loss was recorded in Cost of goods sold in the accompanying Consolidated Statements of Operations.

[0001069202-18-000004:notes:142]
(2) The (gain) loss was recorded in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-18-000004:notes:143]
Derivatives

[0001069202-18-000004:notes:144]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 8 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-18-000004:notes:145]
Stock-Based Compensation:

[0001069202-18-000004:notes:146]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-18-000004:notes:147]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Compensation expense(1) | $ | 24.9 |  |  | $ | 31.7 |  |  | $ | 26.6 |  |

[0001069202-18-000004:notes:148]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.

[0001069202-18-000004:notes:149]
Incentive Plan

[0001069202-18-000004:notes:150]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-18-000004:notes:151]
As of December 31, 2017, awards for 13.5 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.4 million shares available for future issuance.

[0001069202-18-000004:notes:152]
Performance Share Units

[0001069202-18-000004:notes:153]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII's performance over the three-year performance period.

[0001069202-18-000004:notes:154]
Performance share units are classified as equity awards.  Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-18-000004:notes:155]
The following table provides information on our performance share units:

[0001069202-18-000004:notes:156]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Compensation expense for performance share units (in millions) | $ | 12.2 |  |  | $ | 18.1 |  |  | $ | 13.6 |  |
| Weighted-average fair value of grants, per share | $ | 197.54 |  |  | $ | 150.21 |  |  | $ | 126.31 |  |
| Payout ratio for shares paid | 185.9 | % |  | 200.0 | % |  | 200.0 | % |

[0001069202-18-000004:notes:157]
A summary of the status of our undistributed performance share units as of December 31, 2017, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-18-000004:notes:158]
|  | Shares (2) |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2016 | 0.4 |  |  | $ | 101.03 |  |
| Granted | 0.1 |  |  | 197.54 |  |
| Adjustment to shares paid based on payout ratio | 0.1 |  |  | 88.26 |  |
| Distributed | (0.2 | ) |  | 81.17 |  |
| Forfeited | — |  |  | — |  |
| Undistributed performance share units as of December 31, 2017 (1) | 0.3 |  |  | $ | 123.80 |  |

[0001069202-18-000004:notes:159]
(1) Undistributed performance share units include approximately 0.2 million units with a weighted-average grant date fair value of $154.90 per share that had not yet vested and 0.2 million units that have vested but were not yet distributed.

[0001069202-18-000004:notes:160]
(2) Share amounts are rounded but the balance of undistributed performance share units as of December 31, 2017                      accurately reflects actual units undistributed.

[0001069202-18-000004:notes:161]
As of December 31, 2017, we had $20.7 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.2 years. Our estimated forfeiture rate for these performance share units was 15.1% as of December 31, 2017.

[0001069202-18-000004:notes:162]
Restricted Stock Units

[0001069202-18-000004:notes:163]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-18-000004:notes:164]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-18-000004:notes:165]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Compensation expense for restricted stock units | $ | 8.3 |  |  | $ | 9.0 |  |  | $ | 8.3 |  |
| Weighted-average fair value of grants, per share | $ | 197.54 |  |  | $ | 150.14 |  |  | $ | 126.15 |  |

[0001069202-18-000004:notes:166]
A summary of our non-vested restricted stock units as of December 31, 2017 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-18-000004:notes:167]
|  | Shares(2) |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2016 | 0.3 |  |  | $ | 118.38 |  |
| Granted | 0.1 |  |  | 197.54 |  |
| Distributed | (0.1 | ) |  | 89.33 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2017(1) | 0.2 |  |  | $ | 156.16 |  |

[0001069202-18-000004:notes:168]
(1) As of December 31, 2017, we had $18.8 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.4 years.  Our estimated forfeiture rate for restricted stock units was 18.2% as of December 31, 2017.

[0001069202-18-000004:notes:169]
(2) Share amounts are rounded but the balance of undistributed performance share units as of December 31, 2017 accurately reflects actual units undistributed.

[0001069202-18-000004:notes:170]
Stock Appreciation Rights

[0001069202-18-000004:notes:171]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-18-000004:notes:172]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-18-000004:notes:173]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Compensation expense for stock appreciation rights | $ | 4.4 |  |  | $ | 4.6 |  |  | $ | 4.7 |  |
| Weighted-average fair value of grants, per share | 32.32 |  |  | 22.93 |  |  | 22.74 |  |

[0001069202-18-000004:notes:174]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-18-000004:notes:175]
The fair value of the stock appreciation rights granted in 2017, 2016 and 2015 were estimated on the date of grant using the following assumptions:

[0001069202-18-000004:notes:176]
|  | 2017 |  | 2016 |  | 2015 |
| Expected dividend yield | 1.47 | % |  | 1.62 | % |  | 1.61 | % |
| Risk-free interest rate | 2.02 | % |  | 1.66 | % |  | 1.36 | % |
| Expected volatility | 19.97 | % |  | 19.60 | % |  | 23.78 | % |
| Expected life (in years) | 3.95 |  |  | 3.99 |  |  | 4.00 |  |

[0001069202-18-000004:notes:177]
A summary of our stock appreciation rights as of December 31, 2017, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-18-000004:notes:178]
|  | Shares |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2016 | 1.1 |  |  | $ | 98.35 |  |
| Granted | 0.2 |  |  | 205.53 |  |
| Exercised | (0.2 | ) |  | 70.00 |  |
| Forfeited | — |  |  | — |  |
| Outstanding stock appreciation rights as of December 31, 2017 | 1.1 |  |  | $ | 121.63 |  |
| Exercisable stock appreciation rights as of December 31, 2017 | 0.7 |  |  | $ | 90.43 |  |

[0001069202-18-000004:notes:179]
As of December 31, 2017, we had $9.6 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.40 years. Our estimated forfeiture rate for stock appreciation rights was 14.2% as of December 31, 2017.

[0001069202-18-000004:notes:180]
Employee Stock Purchase Plan

[0001069202-18-000004:notes:181]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 16,000 shares under the ESPP during the year ended December 31, 2017.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2017.


## us-gaap:EarningsPerShareTextBlock

[0001069202-18-000004:notes:182]
Earnings Per Share:

[0001069202-18-000004:notes:183]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-18-000004:notes:184]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-18-000004:notes:185]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net income | $ | 305.7 |  |  | $ | 277.8 |  |  | $ | 186.6 |  |
| Add: Loss from discontinued operations | 1.4 |  |  | 0.8 |  |  | 0.6 |  |
| Income from continuing operations | $ | 307.1 |  |  | $ | 278.6 |  |  | $ | 187.2 |  |
| Weighted-average shares outstanding – basic | 42.2 |  |  | 43.4 |  |  | 44.9 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.6 |  |  | 0.6 |  |  | 0.7 |  |
| Weighted-average shares outstanding – diluted | 42.8 |  |  | 44.0 |  |  | 45.6 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 7.28 |  |  | $ | 6.41 |  |  | $ | 4.17 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.02 | ) |  | (0.01 | ) |
| Net income | $ | 7.25 |  |  | $ | 6.39 |  |  | $ | 4.16 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 7.17 |  |  | $ | 6.34 |  |  | $ | 4.11 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.02 | ) |  | (0.02 | ) |
| Net income | $ | 7.14 |  |  | $ | 6.32 |  |  | $ | 4.09 |  |

[0001069202-18-000004:notes:186]
An insignificant number of stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-18-000004:notes:187]
Joint Ventures and Other Equity Investments:

[0001069202-18-000004:notes:188]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-18-000004:notes:189]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-18-000004:notes:190]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Equity method investments | $ | 33.3 |  |  | $ | 30.7 |  |

[0001069202-18-000004:notes:191]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-18-000004:notes:192]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Purchases of compressors from joint venture | $ | 106.4 |  |  | $ | 97.7 |  |  | $ | 103.5 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-18-000004:notes:193]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-18-000004:notes:194]
|  | Fair Value Measurements as of December 31, 2017 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 3.9 |  |  | — |  |  | — |  |  | 3.9 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 34.7 |  |  | — |  |  | 34.7 |  |
| International equity (2) | — |  |  | 42.2 |  |  | — |  |  | 42.2 |  |
| Fixed income (3) | — |  |  | 197.9 |  |  | — |  |  | 197.9 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Fixed income | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 3.3 |  |  | — |  |  | 3.3 |  |
| Fixed income (6) | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |
| Blend (7) | — |  |  | 12.5 |  |  | — |  |  | 12.5 |  |
| Total | 3.9 |  |  | 314.7 |  |  | — |  |  | 318.6 |  |

[0001069202-18-000004:notes:195]
|  | Fair Value Measurements as of December 31, 2016 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | 5.3 |  |  | — |  |  | — |  |  | 5.3 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 69.5 |  |  | — |  |  | 69.5 |  |
| International equity (2) | — |  |  | 47.6 |  |  | — |  |  | 47.6 |  |
| Fixed income (3) | — |  |  | 134.9 |  |  | — |  |  | 134.9 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Fixed income | — |  |  | 11.9 |  |  | — |  |  | 11.9 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 13.5 |  |  | — |  |  | 13.5 |  |
| Fixed income (6) | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total | 5.3 |  |  | 287.2 |  |  | — |  |  | 292.5 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-18-000004:notes:196]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-18-000004:notes:197]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 308.1 |  |  | $ | 499.3 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-18-000004:notes:198]
Fair Value Measurements:

[0001069202-18-000004:notes:199]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-18-000004:notes:200]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-18-000004:notes:201]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-18-000004:notes:202]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-18-000004:notes:203]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2017 and 2016, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2017 were the same as those used as of December 31, 2016.

[0001069202-18-000004:notes:204]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-18-000004:notes:205]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-18-000004:notes:206]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty's creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 8 for more information related to our derivative instruments.

[0001069202-18-000004:notes:207]
Marketable Equity Securities

[0001069202-18-000004:notes:208]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-18-000004:notes:209]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | 4.1 |  |  | $ | 4.4 |  |

[0001069202-18-000004:notes:210]
Other Fair Value Disclosures

[0001069202-18-000004:notes:211]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-18-000004:notes:212]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-18-000004:notes:213]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-18-000004:notes:214]
|  | As of December 31, 2017 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 34.7 |  |  | Daily |  | 5 days |
| International equity (2) | 42.2 |  |  | Daily |  | 5 days |
| Fixed income (3) | 197.9 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.6 |  |  | Daily |  | 3-5 days |
| Fixed income | 13.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 3.3 |  |  | Daily |  | 1-3 days |
| Fixed income (6) | 5.9 |  |  | Daily |  | 1-7 days |
| Blend (7) | 12.5 |  |  | Daily |  | 1-3 days |
| Total | $ | 314.7 |  |  |  |  |  |

[0001069202-18-000004:notes:215]
|  | As of December 31, 2016 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 69.5 |  |  | Daily |  | 5 days |
| International equity (2) | 47.6 |  |  | Daily |  | 5 days |
| Fixed income (3) | 134.9 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.7 |  |  | Daily |  | 3-5 days |
| Fixed income | 11.9 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 13.5 |  |  | Daily |  | 1-7 days |
| Fixed income (6) | 5.1 |  |  | Daily |  | 1-7 days |
| Total | $ | 287.2 |  |  |  |  |  |

[0001069202-18-000004:notes:216]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the fund are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The fund also holds a portion of its assets in international equities. |
| (5) | This category includes investments in international equity securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. |
| (7) | This category includes investments in pooled funds where the fund manager has discretion for the asset allocation and can invest in a wide range of international and US asset classes including equity, credit markets, sovereign debt and alternative assets (including derivative-based strategies). |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001069202-18-000004:notes:217]
Amortization expense related to these intangible and other assets was as follows (in millions):

[0001069202-18-000004:notes:218]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Amortization expense (1) | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 2.7 |  |

[0001069202-18-000004:notes:219]
(1) Included in the amortization expense in 2015 are amounts relating to customer relationships that were written off during the fourth quarter of 2015.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-18-000004:notes:220]
Translation of Foreign Currencies

[0001069202-18-000004:notes:221]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCI in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-18-000004:notes:222]
Goodwill and Intangible Assets:

[0001069202-18-000004:notes:223]
Goodwill

[0001069202-18-000004:notes:224]
The changes in the carrying amount of goodwill in 2017 and 2016, in total and by segment, are summarized in the table below (in millions):

[0001069202-18-000004:notes:225]
| Segment: | Balance at December 31, 2015 (1) |  | Change in foreign currency translation rate |  | Balance at December 31, 2016 |  | Change in foreign currency translation rate |  | Balance at December 31, 2017 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.6 |  |  | (0.5 | ) |  | 60.1 |  |  | 2.1 |  |  | 62.2 |  |
| Refrigeration | 108.4 |  |  | 0.5 |  |  | 108.9 |  |  | 3.3 |  |  | 112.2 |  |
|  | $ | 195.1 |  |  | $ | — |  |  | $ | 195.1 |  |  | $ | 5.4 |  |  | $ | 200.5 |  |

[0001069202-18-000004:notes:226]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $21.2 million, all of which relate to impairments in periods prior to 2016.

[0001069202-18-000004:notes:227]
We reviewed our reporting unit structure as part of our annual goodwill impairment testing.  We identified several components one level below our operating segments which were determined to be reporting units.  We then performed our analysis to determine the proper aggregation of our reporting units, which considered similar economic and other characteristics, including product types, gross profits, production processes, customer types, distribution processes, and regulatory environments.  Our analysis incorporated qualitative and quantitative measures to evaluate economic similarity  and concluded that our reporting units continue to be equivalent to our operating segments except that we began evaluating our North America supermarket display cases and systems business separately beginning in 2015.

[0001069202-18-000004:notes:228]
A qualitative review of impairment indicators was performed in 2017 for the Residential Heating & Cooling, the Commercial Heating & Cooling, and the Refrigeration segments and we determined that it was not more likely than not that the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, a quantitative impairment analysis was not performed for these segments. No indicators of goodwill impairment were identified during the current year.  Also, we did not record any goodwill impairments related to continuing operations in 2016. During the fourth quarter of 2015 we performed a quantitative impairment analysis of our North American supermarket display cases and systems business. Based on the results of the quantitative impairment test, we recorded impairment of $5.5 million in "Goodwill impairment" in the Consolidated Statement of Operations.

[0001069202-18-000004:notes:229]
Intangible Assets

[0001069202-18-000004:notes:230]
As of December 31, 2017 and 2016, there were $4.3 million and $4.3 million, respectively, of indefinite-lived intangible assets recorded in Other assets, net in the accompanying Consolidated Balance Sheets.  These intangible assets consisted primarily of trademarks and are not subject to amortization.

[0001069202-18-000004:notes:231]
Identifiable intangible and other assets subject to amortization were recorded in Other assets, net in the accompanying Consolidated Balance Sheets and were comprised of the following (in millions):

[0001069202-18-000004:notes:232]
|  | As of December 31, |
|  | 2017 |  | 2016 |
|  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships | 15.8 |  |  | (15.1 | ) |  | 0.7 |  |  | 15.9 |  |  | (14.9 | ) |  | 1.0 |  |
| Patents and others | 14.3 |  |  | (6.4 | ) |  | 7.9 |  |  | 12.7 |  |  | (6.4 | ) |  | 6.3 |  |
| Total | $ | 30.1 |  |  | $ | (21.5 | ) |  | $ | 8.6 |  |  | $ | 28.6 |  |  | $ | (21.3 | ) |  | $ | 7.3 |  |

[0001069202-18-000004:notes:233]
Estimated amortization expense for the next five years and thereafter is as follows (in millions):

[0001069202-18-000004:notes:234]
| Estimated Future Amortization Expense: |  |
| 2018 | $ | 0.5 |  |
| 2019 | 0.5 |  |
| 2020 | 0.4 |  |
| 2021 | 0.2 |  |
| 2022 | 0.2 |  |
| Thereafter | 6.8 |  |

[0001069202-18-000004:notes:235]
During the fourth quarter of 2015, we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that intangible assets relating to the North American supermarket display case business trade name and its customer relationships were impaired and we recorded a charge of $21.2 million in "Asset impairment" in the Consolidated Statement of Operations. We did not have any impairments of intangible assets related to continuing operations in 2017 or 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-18-000004:notes:236]
Income Taxes:

[0001069202-18-000004:notes:237]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; (4) requiring a current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations; (5) repeal of the domestic production activity deduction; and (6) limitations on the deductibility of certain executive compensation.

[0001069202-18-000004:notes:238]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-18-000004:notes:239]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Current: |  |  |  |  |  |
| Federal | $ | 86.1 |  |  | $ | 106.0 |  |  | $ | 101.0 |  |
| State | 12.5 |  |  | 14.5 |  |  | 13.1 |  |
| Foreign | 15.0 |  |  | 9.7 |  |  | 3.6 |  |
| Total current | 113.6 |  |  | 130.2 |  |  | 117.7 |  |
| Deferred: |  |  |  |  |  |
| Federal | 43.8 |  |  | (4.5 | ) |  | (21.4 | ) |
| State | 0.9 |  |  | (1.2 | ) |  | (0.6 | ) |
| Foreign | (1.4 | ) |  | (0.4 | ) |  | (0.3 | ) |
| Total deferred | 43.3 |  |  | (6.1 | ) |  | (22.3 | ) |
| Total provision for income taxes | $ | 156.9 |  |  | $ | 124.1 |  |  | $ | 95.4 |  |

[0001069202-18-000004:notes:240]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-18-000004:notes:241]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Domestic | $ | 402.5 |  |  | $ | 374.8 |  |  | $ | 276.7 |  |
| Foreign | 61.5 |  |  | 27.9 |  |  | 5.9 |  |
| Total | $ | 464.0 |  |  | $ | 402.7 |  |  | $ | 282.6 |  |

[0001069202-18-000004:notes:242]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-18-000004:notes:243]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Provision at the U.S. statutory rate of 35% | $ | 162.4 |  |  | $ | 141.0 |  |  | $ | 98.9 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 9.2 |  |  | 12.8 |  |  | 8.0 |  |
| Domestic manufacturing deduction | (9.6 | ) |  | (9.2 | ) |  | (9.9 | ) |
| Tax credits, net of unrecognized tax benefits | (8.6 | ) |  | (27.9 | ) |  | (0.7 | ) |
| Change in unrecognized tax benefits | (0.1 | ) |  | (0.3 | ) |  | (0.9 | ) |
| Change in valuation allowance | 6.4 |  |  | (4.3 | ) |  | (0.6 | ) |
| Foreign taxes at rates other than 35% | (9.0 | ) |  | (1.3 | ) |  | 0.3 |  |
| Deemed inclusions | 0.3 |  |  | 16.9 |  |  | 0.6 |  |
| Change in rates from the Tax Act & other law changes | 31.8 |  |  | (0.6 | ) |  | 0.8 |  |
| Excess tax benefits from stock-based compensation | (23.6 | ) |  | — |  |  | — |  |
| Miscellaneous other | (2.3 | ) |  | (3.0 | ) |  | (1.1 | ) |
| Total provision for income taxes | $ | 156.9 |  |  | $ | 124.1 |  |  | $ | 95.4 |  |

[0001069202-18-000004:notes:244]
The SEC staff issued Staff Accounting Bulletin No. 118 ("SAB 118"), which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements.  If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001069202-18-000004:notes:245]
Our accounting for the following elements of the Tax Act is incomplete. However, we were able to make reasonable estimates of certain effects and, therefore, recorded provisional adjustments as follows:

[0001069202-18-000004:notes:246]
| • | The Tax Act reduced the corporate tax rate to 21 percent, effective January 1, 2018. For our net federal deferred tax assets ("DTA"), we have recorded a provisional decrease of $32.1 million, with a corresponding net adjustment to deferred income tax expense of $32.1 million for the year ended December 31, 2017. This adjustment is based on a reasonable estimate of the impact of the reduction in the corporate tax rate on our DTA's as of December 22, 2017. While we are able to make a reasonable estimate of the impact of the reduction in the corporate tax rate, our DTA's may be affected by other analyses related to the Tax Act, including our calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences. |

[0001069202-18-000004:notes:247]
| • | The Deemed Repatriation Transition Tax (Transition Tax) is a tax on previously untaxed accumulated and current earnings and profits (E&P) of certain of our foreign subsidiaries. To assess the amount of the Transition Tax, we must determine, in addition to other factors, the amount of post-1986 E&P of the relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings. We are able to make a reasonable estimate of the Transition Tax and currently estimate that we will not have a Transition Tax obligation. However, we are continuing to review additional information regarding our accumulated E&P and non-U.S. income taxes paid to more precisely compute the amount of the Transition Tax, if any. In addition, based on current state tax law, we estimate the state impact of the Transition Tax to be insignificant. This estimate will be revised based on a calculation of our final Transition Tax as well as any updated guidance on state treatment of the deemed repatriation. |

[0001069202-18-000004:notes:248]
| • | We must assess whether our valuation allowance analyses are affected by various aspects of the Tax Act (e.g., deemed repatriation of deferred foreign income, global intangible low-taxed income ("GILTI") inclusions, new categories of foreign tax credits ("FTCs"), and share-based compensation). Since, as discussed herein, we have recorded provisional amounts related to certain portions of the Tax Act, any corresponding determination of the need for or change in a valuation allowance is also provisional. Due to the limitation on the utilization of future foreign tax credits, we recorded a provisional valuation allowance against our FTC carryforwards of $4.3 million. While we believe this is a reasonable estimate, the realizability of deferred tax assets related to share-based compensation may also be impacted by the Tax Act. |

[0001069202-18-000004:notes:249]
| • | While we have not yet completed all of the computations necessary or completed a detailed inventory of our 2017 expenditures that qualify for immediate expensing, we have recorded a provisional benefit of $4.1 million based on our current intent to fully expense all qualifying expenditures. This resulted in a decrease of approximately $1.4 million to our current income tax payable and a corresponding increase in our deferred tax liabilities ("DTLs") of approximately $0.9 million (after considering the effects of the reduction in income tax rates). This provisional benefit will be refined as we complete the detailed analysis of qualifying expenditures. |

[0001069202-18-000004:notes:250]
Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the Tax Act and the application of ASC 740.  Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  Our selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be.  We are not currently able to reasonably estimate the effect of the new GILTI tax rules on future U.S. inclusions in taxable income as the expected future impact of this provision of the Tax Act depends on our current structure and business.  Therefore, we have not made any adjustments related to potential GILTI tax in our financial statements and have not made a policy decision regarding whether to record deferred taxes on GILTI.

[0001069202-18-000004:notes:251]
The effect of the tax rate change for items originally recognized in other comprehensive income was properly recorded in tax expense from continuing operations.  This results in stranded tax effects in accumulated other comprehensive income at December 31, 2017.  Companies can make a policy election to reclassify from accumulated other comprehensive income to retained earnings the stranded tax effects directly arising from the change in the federal corporate tax rate.  We will determine whether or not to make such a policy election in fiscal 2018.

[0001069202-18-000004:notes:252]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-18-000004:notes:253]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-18-000004:notes:254]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 27.3 |  |  | $ | 36.3 |  |
| Loss carryforwards (foreign, U.S. and state) | 21.0 |  |  | 19.8 |  |
| Post-retirement and pension benefits | 23.3 |  |  | 33.9 |  |
| Inventory reserves | 7.5 |  |  | 9.6 |  |
| Receivables allowance | 3.5 |  |  | 4.5 |  |
| Compensation liabilities | 11.1 |  |  | 20.6 |  |
| Deferred income | 0.7 |  |  | 1.5 |  |
| Insurance liabilities | 5.1 |  |  | 6.5 |  |
| Legal reserves | 7.6 |  |  | 12.0 |  |
| Tax credits, net of federal effect | 21.3 |  |  | 18.4 |  |
| Other | 7.5 |  |  | 5.4 |  |
| Total deferred tax assets | 135.9 |  |  | 168.5 |  |
| Valuation allowance | (24.9 | ) |  | (17.1 | ) |
| Total deferred tax assets, net of valuation allowance | 111.0 |  |  | 151.4 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (5.9 | ) |  | (3.3 | ) |
| Hedges | (3.6 | ) |  | (3.2 | ) |
| Intangibles | (4.9 | ) |  | (4.9 | ) |
| Other | (2.2 | ) |  | (3.3 | ) |
| Total deferred tax liabilities | (16.6 | ) |  | (14.7 | ) |
| Net deferred tax assets | $ | 94.4 |  |  | $ | 136.7 |  |

[0001069202-18-000004:notes:255]
As of December 31, 2017 and 2016, we had $0.8 million and $ 1.6 million in tax-effected state net operating loss carryforwards, respectively, and $19.8 million and $16.8 million  in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards began expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards European and Asian tax jurisdictions.  The remainder of the valuation allowance relates to state tax credits.

[0001069202-18-000004:notes:256]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of December 31, 2017.  To realize the net foreign deferred tax asset, we will need to generate future foreign taxable income of approximately $71.3 million during the periods in which those temporary differences become deductible.

[0001069202-18-000004:notes:257]
As of December 31, 2017, we had foreign tax credit carryforwards in U.S. of $10.6 million.  Due to the Tax Act, we no longer believe we will realize the full benefit of these credits due to the new limitation of utilizing foreign tax credits to reduce U.S. income tax.  Therefore, we recorded a valuation allowance of $4.3 million.

[0001069202-18-000004:notes:258]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries' earnings.  These earnings were approximately $87.0 million as of December 31, 2017.  An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-18-000004:notes:259]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001069202-18-000004:notes:260]
| Balance as of December 31, 2015 | $ | 0.5 |  |
| Increases related to prior year tax positions | 1.0 |  |
| Increases related to current year tax positions | 1.4 |  |
| Settlement | (0.5 | ) |
| Balance as of December 31, 2016 | 2.4 |  |
| Increases related to prior year tax positions | 0.1 |  |
| Decreases related to prior year tax positions | (2.5 | ) |
| Balance as of December 31, 2017 | $ | — |  |

[0001069202-18-000004:notes:261]
As of December 31, 2017, we no longer had any unrecognized tax benefits.

[0001069202-18-000004:notes:262]
We are currently under examination for our U.S. federal income taxes for 2017 and 2016 and are subject to examination by numerous other taxing authorities in the U.S. and in jurisdictions such as France, Canada, India and Germany.  We are generally no longer subject to U.S., state and local or non-U.S. income tax examinations by taxing authorities for years before 2011.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-18-000004:notes:263]
Income Taxes

[0001069202-18-000004:notes:264]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 9 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-18-000004:notes:265]
Inventories:

[0001069202-18-000004:notes:266]
The components of inventories are as follows (in millions):

[0001069202-18-000004:notes:267]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Finished goods | $ | 331.9 |  |  | $ | 287.2 |  |
| Work in process | 5.5 |  |  | 5.1 |  |
| Raw materials and parts | 199.2 |  |  | 183.4 |  |
| Total | 536.6 |  |  | 475.7 |  |
| Excess of current cost over last-in, first-out cost | (52.4 | ) |  | (57.2 | ) |
| Total inventories, net | $ | 484.2 |  |  | $ | 418.5 |  |

[0001069202-18-000004:notes:268]
The Company recorded no pre-tax loss in 2017, pre-tax loss of $0.2 million in 2016 and pre-tax loss of $0.2 million in 2015 from LIFO inventory liquidations.   Reserve balances, primarily related to obsolete and slow-moving inventories, were $20.1 million and $19.7 million at December 31, 2017 and December 31, 2016, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001069202-18-000004:notes:269]
Inventories

[0001069202-18-000004:notes:270]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $274.5 million and $221.4 million as of December 31, 2017 and 2016, respectively, were valued at the lower of cost or market using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or market with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-18-000004:notes:271]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 3 for more information on our inventories.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001069202-18-000004:notes:272]
Recently Adopted Accounting Guidance

[0001069202-18-000004:notes:273]
On March 30, 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting, which changes the accounting for certain aspects of share-based payments to employees. The new guidance requires entities to record all tax effects related to share-based payments at settlement or expiration through the income statement and the excess tax benefit to be recorded when it arises, subject to normal valuation allowance considerations.  This is in comparison to the prior requirement that these excess tax benefits be recognized in additional paid-in capital. The new guidance also requires excess tax benefits to be classified along with other income tax cash flows as an operating activity in the statement of cash flows rather than, as previously required, a financing activity.

[0001069202-18-000004:notes:274]
We have adopted ASU 2016-09 effective January 1, 2017 on a prospective basis where permitted by the new standard. As a result of this adoption:

[0001069202-18-000004:notes:275]
| • | We recognized discrete tax benefits of $23.6 million in the income taxes line item of our consolidated statements of operations for the twelve months ended December 31, 2017 related to excess tax benefits upon vesting or settlement in that period. |

[0001069202-18-000004:notes:276]
| • | We elected to adopt the cash flow presentation of the excess tax benefits retrospectively where these benefits are classified along with other income tax cash flows as operating cash flows. |

[0001069202-18-000004:notes:277]
| • | We have elected to continue to estimate the number of stock-based awards expected to vest, rather than electing to account for forfeitures as they occur to determine the amount of compensation cost to be recognized in each period. |

[0001069202-18-000004:notes:278]
| • | We excluded the excess tax benefits from the assumed proceeds available to repurchase shares in the computation of our diluted earnings per share for the year ended December 31, 2017. |

[0001069202-18-000004:notes:279]
Recent Accounting Pronouncements

[0001069202-18-000004:notes:280]
On May 28, 2014, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2018. Early application is not permitted. We have substantially completed our evaluation of the effect that ASU 2014-09 will have on our Consolidated Financial Statements and related disclosures. The ASU will not have a material impact on the amount and timing of revenue recognition, but it will require us to enhance our disclosures to provide additional information relating to disaggregated revenue, contract assets and liabilities, and remaining performance obligations.  We are currently in the process of preparing these additional disclosures, including updating our internal controls related to the additional data and disclosures to be provided upon adoption of the new standard.  We will adopt the new standard using the modified retrospective approach.

[0001069202-18-000004:notes:281]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability. It will be critical to identify leases embedded in a contract to avoid misstating the lessee’s balance sheet. For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. We will adopt the standard using the prospective approach and are still determining the effect of the standard on our ongoing financial reporting.  As a result of the new standard, all of our leases greater than one year in duration will be recognized on our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.

[0001069202-18-000004:notes:282]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees.  For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017.  This standard is not expected to have a material impact on our consolidated financial statements.

[0001069202-18-000004:notes:283]
On October 24, 2016, the FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory. The new ASU eliminates the existing exception from recognition of the tax consequences of intercompany sales of assets other than inventory.  Under the new standard, when an asset (other than inventory) is sold from one consolidated entity to another, the tax consequences to the seller will be recognized currently as a component of the current tax provision.  The new guidance will be effective for public business entities in fiscal years beginning after December 15, 2017, including interim periods within those years.  In accordance with the ASU, our previously deferred tax costs and unrecognized deferred tax assets related to intra-entity asset transfers will need to be recognized at the date of transition through a cumulative effect adjustment to opening retained earnings upon adoption of the standard.

[0001069202-18-000004:notes:284]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other Income, net. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. The ASU will not have a material impact on our financial results.

[0001069202-18-000004:notes:285]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 intends to better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results. The amendments expand and refine hedge accounting for both nonfinancial and financial risk components and align the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance in ASU 2017-12 is required for annual reporting periods beginning after December 15, 2018, with early adoption permitted. We intend to adopt this guidance in 2018 as it will allow us to designate certain aluminum commodity futures contracts as cash flow hedges.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-18-000004:notes:286]
Losses and Other Expenses, net:

[0001069202-18-000004:notes:287]
Losses and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-18-000004:notes:288]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Realized (gains) losses on settled futures contracts | $ | (1.7 | ) |  | $ | 1.1 |  |  | $ | 1.9 |  |
| Foreign currency exchange (gains) losses | (1.8 | ) |  | 2.2 |  |  | 3.6 |  |
| Losses on disposal of fixed assets | 0.2 |  |  | 0.5 |  |  | 0.6 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 0.9 |  |  | (3.6 | ) |  | 0.6 |  |
| Asbestos-related litigation | 3.5 |  |  | 6.3 |  |  | 3.0 |  |
| Acquisition/disposition expenses | 1.1 |  |  | 0.4 |  |  | 1.0 |  |
| Special legal contingency charges | 3.7 |  |  | 1.9 |  |  | 7.4 |  |
| Environmental liabilities | 2.2 |  |  | 1.9 |  |  | 1.0 |  |
| Contractor tax payments | 0.1 |  |  | 0.6 |  |  | 2.6 |  |
| Losses and other expenses, net | $ | 8.2 |  |  | $ | 11.3 |  |  | $ | 21.7 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-18-000004:notes:289]
Employee Benefit Plans:

[0001069202-18-000004:notes:290]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  We also have several active defined benefit plans that provide benefits based on years of service.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001069202-18-000004:notes:291]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2016, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-18-000004:notes:292]
Effective for fiscal year 2016, we adopted the full yield curve approach for estimating the service cost and interest cost components of expense for plans that use a yield curve to determine the discount rate. The new method applies the specific spot rates along the yield curve used in the most recent measurement of the benefit obligation, resulting in a more precise estimate of expense. The impact for fiscal year 2016 was a decrease in expense of approximately $3.2 million.

[0001069202-18-000004:notes:293]
In 2016, we offered certain former employees with vested pension benefits a lump sum payout in an effort to reduce our long-term pension obligations.  As a result, for 2016, the net periodic benefit cost for our pension plans included a non-cash settlement charge of $31.4 million and the projected benefit obligation decreased by $50.6 million. We did not have similar funding of pension buyout activity in 2017.

[0001069202-18-000004:notes:294]
Defined Contribution Plans

[0001069202-18-000004:notes:295]
We recorded the following expenses related to our contributions to the defined contribution plans (in millions):

[0001069202-18-000004:notes:296]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Contributions to defined contribution plans | $ | 18.1 |  |  | $ | 16.3 |  |  | $ | 16.1 |  |

[0001069202-18-000004:notes:297]
Pension and Post-retirement Benefit Plans

[0001069202-18-000004:notes:298]
The following tables set forth amounts recognized in our financial statements and the plans' funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-18-000004:notes:299]
|  | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Accumulated benefit obligation | $ | 401.5 |  |  | $ | 374.1 |  |  | N/A |  |  | N/A |  |
| Changes in projected benefit obligation: |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year | $ | 381.6 |  |  | $ | 415.4 |  |  | $ | 3.3 |  |  | $ | 4.9 |  |
| Service cost | 5.0 |  |  | 4.4 |  |  | — |  |  | — |  |
| Interest cost | 12.6 |  |  | 15.3 |  |  | 0.1 |  |  | 0.1 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.3 |  |  | 0.3 |  |
| Amendments | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Actuarial (gain) loss | 22.1 |  |  | 22.8 |  |  | (0.1 | ) |  | (0.7 | ) |
| Effect of exchange rates | 4.3 |  |  | (3.8 | ) |  | — |  |  | — |  |
| Settlements and curtailments | (1.3 | ) |  | (50.6 | ) |  | — |  |  | — |  |
| Benefits paid | (18.8 | ) |  | (22.0 | ) |  | (0.5 | ) |  | (1.3 | ) |
| Benefit obligation at end of year | $ | 405.5 |  |  | $ | 381.6 |  |  | $ | 3.1 |  |  | $ | 3.3 |  |
| Changes in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 292.5 |  |  | $ | 293.0 |  |  | $ | — |  |  | $ | — |  |
| Actual gain (loss) return on plan assets | 39.8 |  |  | 21.0 |  |  | — |  |  | — |  |
| Employer contribution | 3.5 |  |  | 53.9 |  |  | 0.3 |  |  | 1.0 |  |
| Plan participants' contributions | — |  |  | — |  |  | 0.2 |  |  | 0.3 |  |
| Effect of exchange rates | 2.9 |  |  | (2.8 | ) |  | — |  |  | — |  |
| Plan settlements | (1.3 | ) |  | (50.6 | ) |  | — |  |  | — |  |
| Benefits paid | (18.8 | ) |  | (22.0 | ) |  | (0.5 | ) |  | (1.3 | ) |
| Fair value of plan assets at end of year | 318.6 |  |  | 292.5 |  |  | — |  |  | — |  |
| Funded status / net amount recognized | $ | (86.9 | ) |  | $ | (89.1 | ) |  | $ | (3.1 | ) |  | $ | (3.3 | ) |
| Net amount recognized consists of: |  |  |  |  |  |  |  |
| Noncurrent assets | $ | 1.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current liability | (4.0 | ) |  | (1.6 | ) |  | (0.5 | ) |  | (0.5 | ) |
| Non-current liability | (84.5 | ) |  | (87.5 | ) |  | (2.6 | ) |  | (2.8 | ) |
| Net amount recognized | $ | (86.9 | ) |  | $ | (89.1 | ) |  | $ | (3.1 | ) |  | $ | (3.3 | ) |

[0001069202-18-000004:notes:300]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 394.4 |  |  | $ | 370.2 |  |
| Accumulated benefit obligation | 390.4 |  |  | 362.9 |  |
| Fair value of plan assets | 305.9 |  |  | 280.8 |  |

[0001069202-18-000004:notes:301]
Our U.S.-based pension plans comprised approximately 88%  of the projected benefit obligation and 87% of plan assets as of December 31, 2017.

[0001069202-18-000004:notes:302]
|  | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 5.0 |  |  | $ | 4.4 |  |  | $ | 4.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 12.6 |  |  | 15.3 |  |  | 17.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on plan assets | (21.3 | ) |  | (21.5 | ) |  | (21.4 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.2 |  |  | 0.3 |  |  | 0.2 |  |  | (2.4 | ) |  | (3.0 | ) |  | (3.1 | ) |
| Recognized actuarial loss | 8.1 |  |  | 7.6 |  |  | 9.5 |  |  | 1.4 |  |  | 1.4 |  |  | 1.5 |  |
| Settlements and curtailments(1) | 0.7 |  |  | 31.6 |  |  | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 5.3 |  |  | $ | 37.7 |  |  | $ | 10.7 |  |  | $ | (0.9 | ) |  | $ | (1.5 | ) |  | $ | (1.4 | ) |

[0001069202-18-000004:notes:303]
(1)  The Consolidated Statements of Operations discloses $31.4 million related to pension settlement charges that represent the lump-sum payments made in the fourth quarter of 2016.

[0001069202-18-000004:notes:304]
The following table sets forth amounts recognized in AOCI and Other comprehensive income (loss) in our financial statements for 2017 and 2016 (in millions):

[0001069202-18-000004:notes:305]
|  | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amounts recognized in AOCI: |  |  |  |  |  |  |  |
| Prior service costs | $ | (0.8 | ) |  | $ | (0.9 | ) |  | $ | 9.5 |  |  | $ | 12.0 |  |
| Actuarial loss | (194.6 | ) |  | (197.3 | ) |  | (14.7 | ) |  | (16.3 | ) |
| Subtotal | (195.4 | ) |  | (198.2 | ) |  | (5.2 | ) |  | (4.3 | ) |
| Deferred taxes | 71.2 |  |  | 71.0 |  |  | 1.9 |  |  | 1.6 |  |
| Net amount recognized | $ | (124.2 | ) |  | $ | (127.2 | ) |  | $ | (3.3 | ) |  | $ | (2.7 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |
| Current year prior service costs | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
| Current year actuarial (gain) loss | 3.7 |  |  | 23.3 |  |  | (0.1 | ) |  | (0.7 | ) |
| Effect of exchange rates | 1.7 |  |  | (1.5 | ) |  | — |  |  | — |  |
| Amortization of prior service (costs) credits | (0.2 | ) |  | (0.3 | ) |  | 2.4 |  |  | 3.1 |  |
| Amortization of actuarial loss | (8.8 | ) |  | (39.2 | ) |  | (1.4 | ) |  | (1.4 | ) |
| Total recognized in other comprehensive income (loss) | $ | (3.5 | ) |  | $ | (17.6 | ) |  | $ | 0.9 |  |  | $ | 1.0 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 1.8 |  |  | $ | 20.1 |  |  | $ | — |  |  | $ | (0.5 | ) |

[0001069202-18-000004:notes:306]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCI in 2018 are $(0.1) million  and (9.3) million, respectively, for pension benefits and $1.4 million  and $(1.3) million, respectively, for other benefits.

[0001069202-18-000004:notes:307]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2017 and 2016:

[0001069202-18-000004:notes:308]
|  | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |  |  |  |  |
| Discount rate | 3.66 | % |  | 4.17 | % |  | 3.25 | % |  | 3.50 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |

[0001069202-18-000004:notes:309]
|  | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate - service cost | 3.96 | % |  | 4.30 | % |  | 3.97 | % |  | 4.61 | % |  | 4.95 | % |  | 3.23 | % |
| Discount rate - interest cost | 3.51 | % |  | 3.76 | % |  | 3.97 | % |  | 2.56 | % |  | 2.49 | % |  | 3.23 | % |
| Expected long-term return on plan assets | 7.50 | % |  | 7.50 | % |  | 7.50 | % |  | — |  |  | — |  |  | — |  |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |  | — |  |  | — |  |  | — |  |

[0001069202-18-000004:notes:310]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2017 and 2016:

[0001069202-18-000004:notes:311]
|  | Pension Benefits |
|  | 2017 |  | 2016 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 2.58 | % |  | 2.83 | % |
| Rate of compensation increase | 3.63 | % |  | 3.78 | % |

[0001069202-18-000004:notes:312]
|  | Pension Benefits |
|  | 2017 |  | 2016 |  | 2015 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 1.34 | % |  | 2.04 | % |  | 4.12 | % |
| Discount rate - interest cost | 2.75 | % |  | 3.45 | % |  | 4.12 | % |
| Expected long-term return on plan assets | 4.40 | % |  | 4.87 | % |  | 5.22 | % |
| Rate of compensation increase | 3.78 | % |  | 3.70 | % |  | 3.48 | % |

[0001069202-18-000004:notes:313]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 7.5% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-18-000004:notes:314]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and OPEB plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001069202-18-000004:notes:315]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-18-000004:notes:316]
|  | 2017 |  | 2016 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2021 |  |  | 2020 |  |

[0001069202-18-000004:notes:317]
A one percentage-point change in assumed healthcare cost trend rates would have the following effects (in millions):

[0001069202-18-000004:notes:318]
|  | 1-Percentage-Point Increase |  | 1-Percentage-Point Decrease |
| Effect on total of service and interest cost | $ | — |  |  | $ | — |  |
| Effect on the post-retirement benefit obligation | 0.1 |  |  | (0.1 | ) |

[0001069202-18-000004:notes:319]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-18-000004:notes:320]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023-2027 |
| Pension benefits | $ | 21.8 |  |  | $ | 19.3 |  |  | $ | 19.9 |  |  | $ | 26.0 |  |  | $ | 20.4 |  |  | $ | 146.4 |  |
| Other benefits | 0.5 |  |  | 0.5 |  |  | 0.4 |  |  | 0.3 |  |  | 0.3 |  |  | 0.9 |  |

[0001069202-18-000004:notes:321]
Pension Plan Assets

[0001069202-18-000004:notes:322]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the second quarter of 2017, in order to decrease volatility, we changed the targeted allocations for our plan assets. The targeted allocation for fixed income, money market and cash investments was changed to 75%, and the targeted allocation for equity investments was changed to 25%. Our targeted exposure to International equity including emerging markets was changed to 12.5% of total assets and our exposure to domestic equity was changed to 12.5%. Our U.S. pension plan represents 87%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 7% of the total fair value of our plan assets as of December 31, 2017.

[0001069202-18-000004:notes:323]
Our U.S. pension plans' weighted-average asset allocations as of December 31, 2017 and 2016, by asset category, are as follows:

[0001069202-18-000004:notes:324]
|  | Plan Assets as of December 31, |
| Asset Category: | 2017 |  | 2016 |
| U.S. equity | 12.5 | % |  | 27.0 | % |
| International equity | 15.1 | % |  | 18.5 | % |
| Fixed income | 71.1 | % |  | 52.5 | % |
| Money market/cash | 1.3 | % |  | 2.0 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-18-000004:notes:325]
Our Canadian pension plans were invested approximately 75% in Canadian bonds and 25% in international equities. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K. and international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-18-000004:notes:326]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund's NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust's underlying assets divided by the number of units owned.  See Note 19 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-18-000004:notes:327]
Property, Plant and Equipment:

[0001069202-18-000004:notes:328]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-18-000004:notes:329]
|  | As of December 31, |
|  | 2017 |  | 2016 |
| Land | $ | 35.7 |  |  | $ | 33.9 |  |
| Buildings and improvements | 234.4 |  |  | 218.2 |  |
| Machinery and equipment | 804.4 |  |  | 742.1 |  |
| Capital leases | 27.5 |  |  | 27.3 |  |
| Construction in progress and equipment not yet in service | 70.0 |  |  | 57.1 |  |
| Total | 1,172.0 |  |  | 1,078.6 |  |
| Less accumulated depreciation | (774.2 | ) |  | (717.2 | ) |
| Property, plant and equipment, net | $ | 397.8 |  |  | $ | 361.4 |  |

[0001069202-18-000004:notes:330]
During the fourth quarter of 2015, we completed a strategic review of our North American supermarket display cases and systems business.  As a result, we performed an impairment analysis using a market approach and determined that property, plant and equipment relating to the North American supermarket display case  business unit were impaired and we recorded a charge of $23.3 million in "Asset impairment" in the Consolidated Statement of Operations. No impairment charges were recorded in 2017 or 2016.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-18-000004:notes:331]
Property, Plant and Equipment

[0001069202-18-000004:notes:332]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-18-000004:notes:333]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-18-000004:notes:334]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 33 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 10 years |
| Vehicles | 2 to 8 years |

[0001069202-18-000004:notes:335]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 5 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-18-000004:notes:336]
Selected Quarterly Financial Information (unaudited):

[0001069202-18-000004:notes:337]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-18-000004:notes:338]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (1) |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| First Quarter | $ | 793.4 |  |  | $ | 715.2 |  |  | $ | 210.9 |  |  | $ | 183.6 |  |  | $ | 43.5 |  |  | $ | 24.9 |  |
| Second Quarter | 1,102.1 |  |  | 1,019.2 |  |  | 340.8 |  |  | 315.0 |  |  | 115.5 |  |  | 110.7 |  |
| Third Quarter | 1,052.3 |  |  | 1,010.0 |  |  | 313.7 |  |  | 310.3 |  |  | 103.5 |  |  | 101.7 |  |
| Fourth Quarter | 891.8 |  |  | 897.3 |  |  | 259.8 |  |  | 267.6 |  |  | 43.1 |  |  | 40.4 |  |

[0001069202-18-000004:notes:339]
|  | Basic Earnings per Share (2) |  | Diluted Earnings per Share (2) |  | Cash Dividends per Common Share |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| First Quarter | $ | 1.02 |  |  | $ | 0.57 |  |  | $ | 1.00 |  |  | $ | 0.56 |  |  | $ | 0.43 |  |  | $ | 0.36 |  |
| Second Quarter | 2.73 |  |  | 2.54 |  |  | 2.69 |  |  | 2.51 |  |  | 0.51 |  |  | 0.43 |  |
| Third Quarter | 2.47 |  |  | 2.35 |  |  | 2.44 |  |  | 2.33 |  |  | 0.51 |  |  | 0.43 |  |
| Fourth Quarter | 1.03 |  |  | 0.94 |  |  | 1.02 |  |  | 0.93 |  |  | 0.51 |  |  | 0.43 |  |

[0001069202-18-000004:notes:340]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-18-000004:notes:341]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-18-000004:notes:342]
Summary of 2017 Quarterly Results

[0001069202-18-000004:notes:343]
The following unusual or infrequent pre-tax items were included in the 2017 quarterly results:

[0001069202-18-000004:notes:344]
1st Quarter.  No significant unusual or infrequent items.

[0001069202-18-000004:notes:345]
2nd Quarter.  No significant unusual or infrequent items.

[0001069202-18-000004:notes:346]
3rd Quarter.  No significant unusual or infrequent items.

[0001069202-18-000004:notes:347]
4th Quarter. As a result of recent tax legislation, we recorded a one-time charge of $31.8 million in the fourth quarter to revalue our deferred tax assets and liabilities.

[0001069202-18-000004:notes:348]
Summary of 2016 Quarterly Results

[0001069202-18-000004:notes:349]
The following unusual or infrequent pre-tax items were included in the 2016 quarterly results:

[0001069202-18-000004:notes:350]
3rd Quarter.   No significant unusual or infrequent items.

[0001069202-18-000004:notes:351]
4th Quarter. As part of our ongoing strategy to de-risk our pension plan obligations, we completed a one-time, lump sum pension buyout in the fourth quarter of 2016 for certain vested participants. As a result of the pension buy-out, we recorded a pension settlement charge of $31.4 million in the fourth quarter.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-18-000004:notes:352]
Accounts and Notes Receivable

[0001069202-18-000004:notes:353]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management's judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management's review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-18-000004:notes:354]
Total assets by segment are shown below (in millions):

[0001069202-18-000004:notes:355]
|  | As of December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 771.3 |  |  | $ | 673.4 |  |  | $ | 628.3 |  |
| Commercial Heating & Cooling | 443.9 |  |  | 385.8 |  |  | 363.6 |  |
| Refrigeration | 506.9 |  |  | 442.8 |  |  | 444.9 |  |
| Corporate and other | 169.4 |  |  | 258.3 |  |  | 240.6 |  |
| Total assets | $ | 1,891.5 |  |  | $ | 1,760.3 |  |  | $ | 1,677.4 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-18-000004:notes:356]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-18-000004:notes:357]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 2,140.4 |  |  | $ | 2,000.8 |  |  | $ | 1,866.9 |  |
| Commercial Heating & Cooling | 973.8 |  |  | 917.9 |  |  | 887.2 |  |
| Refrigeration | 725.4 |  |  | 722.9 |  |  | 713.3 |  |
|  | $ | 3,839.6 |  |  | $ | 3,641.6 |  |  | $ | 3,467.4 |  |
| Segment Profit (Loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 373.9 |  |  | $ | 348.8 |  |  | $ | 278.4 |  |
| Commercial Heating & Cooling | 157.3 |  |  | 149.3 |  |  | 130.4 |  |
| Refrigeration | 72.6 |  |  | 68.9 |  |  | 52.9 |  |
| Corporate and other | (89.2 | ) |  | (97.4 | ) |  | (84.1 | ) |
| Subtotal segment profit | 514.6 |  |  | 469.6 |  |  | 377.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special product quality adjustments | 5.4 |  |  | (0.4 | ) |  | (2.2 | ) |
| Items in (Gains) Losses and other expenses, net that are excluded from segment profit (loss) (2) | 11.5 |  |  | 7.4 |  |  | 15.6 |  |
| Restructuring charges | 3.2 |  |  | 1.8 |  |  | 3.2 |  |
| Pension settlement | — |  |  | 31.4 |  |  | — |  |
| Goodwill impairment | — |  |  | — |  |  | 5.5 |  |
| Asset impairment | — |  |  | — |  |  | 44.5 |  |
| One time inventory write down | — |  |  | — |  |  | 5.6 |  |
| Operating income | $ | 494.5 |  |  | $ | 429.4 |  |  | $ | 305.4 |  |

[0001069202-18-000004:notes:358]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-18-000004:notes:359]
(2) The Company defines segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-18-000004:notes:360]
| • | Special product quality adjustments; |

[0001069202-18-000004:notes:361]
| • | The following items in (Gains) Losses and other expenses, net: |

[0001069202-18-000004:notes:362]
| ◦ | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001069202-18-000004:notes:363]
| ◦ | Special legal contingency charges, |

[0001069202-18-000004:notes:364]
| ◦ | Asbestos-related litigation, |

[0001069202-18-000004:notes:365]
| ◦ | Environmental liabilities, |

[0001069202-18-000004:notes:366]
| ◦ | Contractor tax payments, |

[0001069202-18-000004:notes:367]
| ◦ | Acquisition/disposition costs, and |

[0001069202-18-000004:notes:368]
| ◦ | Other items, net; |

[0001069202-18-000004:notes:369]
| • | Restructuring charges; |

[0001069202-18-000004:notes:370]
| • | Pension settlement; |

[0001069202-18-000004:notes:371]
| • | Goodwill and asset impairments; and |

[0001069202-18-000004:notes:372]
| • | One time inventory write down. |


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-18-000004:notes:373]
Total capital expenditures by segment are shown below (in millions):

[0001069202-18-000004:notes:374]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 38.9 |  |  | $ | 36.7 |  |  | $ | 28.1 |  |
| Commercial Heating & Cooling | 18.5 |  |  | 11.5 |  |  | 8.6 |  |
| Refrigeration | 8.0 |  |  | 12.1 |  |  | 11.4 |  |
| Corporate and other | 32.9 |  |  | 24.0 |  |  | 21.8 |  |
| Total capital expenditures (1) | $ | 98.3 |  |  | $ | 84.3 |  |  | $ | 69.9 |  |

[0001069202-18-000004:notes:375]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2017, 2016 or 2015.

[0001069202-18-000004:notes:376]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-18-000004:notes:377]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 24.9 |  |  | $ | 21.0 |  |  | $ | 20.7 |  |
| Commercial Heating & Cooling | 10.1 |  |  | 9.8 |  |  | 9.7 |  |
| Refrigeration | 9.9 |  |  | 9.7 |  |  | 15.5 |  |
| Corporate and other | 19.7 |  |  | 17.6 |  |  | 16.9 |  |
| Total depreciation and amortization | $ | 64.6 |  |  | $ | 58.1 |  |  | $ | 62.8 |  |

[0001069202-18-000004:notes:378]
The equity method investments are shown below (in millions):

[0001069202-18-000004:notes:379]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 2.8 |  |
| Residential | 11.7 |  |  | 11.5 |  |  | 8.0 |  |
| Commercial | 2.8 |  |  | 2.9 |  |  | 2.6 |  |
| Total income from equity method investments | $ | 18.4 |  |  | $ | 18.4 |  |  | $ | 13.4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-18-000004:notes:380]
Restructuring Charges:

[0001069202-18-000004:notes:381]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 18.

[0001069202-18-000004:notes:382]
Restructuring Activities in 2017

[0001069202-18-000004:notes:383]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-18-000004:notes:384]
|  | Incurred in 2017 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 2.0 |  |  | $ | 11.3 |  |  | $ | 11.5 |  |
| Asset write-offs and accelerated depreciation | 0.8 |  |  | 3.2 |  |  | 3.2 |  |
| Equipment moves | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | 0.2 |  |  | 0.2 |  |
| Other | 0.4 |  |  | 4.1 |  |  | 4.5 |  |
| Total | $ | 3.2 |  |  | $ | 18.8 |  |  | $ | 19.4 |  |

[0001069202-18-000004:notes:385]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-18-000004:notes:386]
|  | Incurred in 2017 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.5 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |
| Commercial Heating & Cooling | 0.9 |  |  | 2.0 |  |  | 2.1 |  |
| Refrigeration | 1.2 |  |  | 13.1 |  |  | 13.1 |  |
| Corporate & Other | 0.6 |  |  | 2.3 |  |  | 2.8 |  |
| Total | $ | 3.2 |  |  | $ | 18.8 |  |  | $ | 19.4 |  |

[0001069202-18-000004:notes:387]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.  The activity within the restructuring accruals is summarized in the tables below (in millions):

[0001069202-18-000004:notes:388]
| Description of Reserves: | Balance as of December 31, 2016 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2017 |
| Severance and related expense | $ | — |  |  | $ | 2.0 |  |  | $ | (1.8 | ) |  | $ | — |  |  | $ | 0.2 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.8 |  |  | (0.2 | ) |  | (0.6 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | 0.4 |  |  | (0.4 | ) |  | — |  |  | — |  |
| Total restructuring reserves | $ | — |  |  | $ | 3.2 |  |  | $ | (2.4 | ) |  | $ | (0.6 | ) |  | $ | 0.2 |  |

[0001069202-18-000004:notes:389]
| Description of Reserves: | Balance as of December 31, 2015 |  | Charged to Earnings |  | Cash Utilization |  | Non-Cash Utilization and Other |  | Balance as of December 31, 2016 |
| Severance and related expense | $ | 0.7 |  |  | $ | (0.2 | ) |  | $ | (0.5 | ) |  | $ | — |  |  | $ | — |  |
| Asset write-offs and accelerated depreciation | — |  |  | 0.3 |  |  | (0.2 | ) |  | (0.1 | ) |  | — |  |
| Equipment moves | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Lease termination | 0.2 |  |  | — |  |  | (0.2 | ) |  | — |  |  | — |  |
| Other | — |  |  | 1.7 |  |  | (1.8 | ) |  | 0.1 |  |  | — |  |
| Total restructuring reserves | $ | 0.9 |  |  | $ | 1.8 |  |  | $ | (2.7 | ) |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-18-000004:notes:390]
Revenue Recognition

[0001069202-18-000004:notes:391]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where title and risk of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.

[0001069202-18-000004:notes:392]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for equipment sales is recognized in line with shipping terms, revenue for installation services is recognized when completed, and revenue related to maintenance and repair services is recognized when such services are performed.

[0001069202-18-000004:notes:393]
We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to Selling, general and administrative (“SG&A”) expenses.  All other advertising, promotions and marketing costs are expensed as incurred.  See Note 22 for more information on these costs.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-18-000004:notes:394]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-18-000004:notes:395]
|  | As of December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 257.6 |  |  | $ | 237.6 |  |  | $ | 224.8 |  |
| Mexico | 79.8 |  |  | 69.4 |  |  | 60.0 |  |
| Canada | 1.7 |  |  | 1.4 |  |  | 1.2 |  |
| International | 58.7 |  |  | 53.0 |  |  | 53.6 |  |
| Total Property, plant and equipment, net | $ | 397.8 |  |  | $ | 361.4 |  |  | $ | 339.6 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-18-000004:notes:396]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-18-000004:notes:397]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-18-000004:notes:398]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-18-000004:notes:399]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 3,128.7 |  |  | $ | 2,966.8 |  |  | $ | 2,793.4 |  |
| Canada | 237.8 |  |  | 218.8 |  |  | 217.7 |  |
| International | 473.1 |  |  | 456.0 |  |  | 456.3 |  |
| Total net sales to external customers | $ | 3,839.6 |  |  | $ | 3,641.6 |  |  | $ | 3,467.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-18-000004:notes:400]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-18-000004:notes:401]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia PacificSouth America |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-18-000004:notes:402]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-18-000004:notes:403]
For the Years Ended December 31, 2017, 2016 and 2015

[0001069202-18-000004:notes:404]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2015: |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 7.9 |  |  | $ | 2.8 |  |  | $ | (4.9 | ) |  | $ | 1.1 |  |  | $ | (0.6 | ) |  | $ | 6.3 |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.3 |  |  | $ | 2.4 |  |  | $ | (2.7 | ) |  | $ | 0.9 |  |  | $ | (0.2 | ) |  | $ | 6.7 |  |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.7 |  |  | $ | 3.9 |  |  | $ | (5.6 | ) |  | $ | 0.9 |  |  | $ | — |  |  | $ | 5.9 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-18-000004:notes:405]
Reportable Business Segments:

[0001069202-18-000004:notes:406]
Description of Segments

[0001069202-18-000004:notes:407]
Segment Data

[0001069202-18-000004:notes:408]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-18-000004:notes:409]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term share-based incentive awards provided to employees throughout LII.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-18-000004:notes:410]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-18-000004:notes:411]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-18-000004:notes:412]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-18-000004:notes:413]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information and industry factors and trends.  The self-insurance liabilities as of December 31, 2017 represent the best estimate of the future payments to be made on reported and unreported losses for 2017 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 10 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-18-000004:notes:414]
Selling, General and Administrative Expenses

[0001069202-18-000004:notes:415]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-18-000004:notes:416]
Summary of Significant Accounting Policies:

[0001069202-18-000004:notes:417]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired (See Note 4 for additional information on our goodwill).  The annual goodwill impairment test was performed during the fourth quarter of 2017.

[0001069202-18-000004:notes:418]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-18-000004:notes:419]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.

[0001069202-18-000004:notes:420]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-18-000004:notes:421]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets. See Note 4 for additional information on our intangible assets.

[0001069202-18-000004:notes:422]
Product Warranties

[0001069202-18-000004:notes:423]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 10 for more information on our estimated future warranty costs.

[0001069202-18-000004:notes:424]
Pensions and Post-retirement Benefits

[0001069202-18-000004:notes:425]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive income (“AOCI”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-18-000004:notes:426]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management's estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 12 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-18-000004:notes:427]
Stock-Based Compensation

[0001069202-18-000004:notes:428]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 14 for more information.

[0001069202-18-000004:notes:429]
Use of Estimates

[0001069202-18-000004:notes:430]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-18-000004:notes:431]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-18-000004:notes:432]
Reclassifications

[0001069202-18-000004:notes:433]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:TreasuryStockTextBlock

[0001069202-18-000004:notes:434]
Stock Repurchases:

[0001069202-18-000004:notes:435]
Our Board of Directors has authorized a total of $2 billion towards the repurchase of shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $550 million share repurchase authorization in 2016. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of December 31, 2017, $396.0 million of shares may still be repurchased under the Share Repurchase Plans.

[0001069202-18-000004:notes:436]
On February 9, 2017, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with Morgan Stanley, to effect an accelerated stock buyback of our common stock.  Under the ASR Agreement, on February 9, 2017, we paid Morgan Stanley an initial purchase price of $75 million, and Morgan Stanley delivered to us common stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement was completed in the second quarter and Morgan Stanley delivered additional shares for a total of 0.5 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-18-000004:notes:437]
On April 28, 2017, we entered into another Fixed Dollar ASR Agreement (the "Second ASR Agreement") with J.P. Morgan Chase Bank to effect an accelerated stock buyback of common stock.  Under the Second ASR Agreement, on April 28, 2017, we paid J.P. Morgan Chase Bank an initial purchase price of $100 million, and J.P. Morgan Chase Bank delivered to us common stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR Agreement was completed in the third quarter and J.P. Morgan Chase Bank delivered additional shares for a total of 0.6 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-18-000004:notes:438]
On July 27, 2017, we entered into another Fixed Dollar ASR Agreement (the "Third ASR Agreement") with Bank of America to effect an accelerated stock buyback of common stock.  Under the Third ASR Agreement, on July 27, 2017, we paid Bank of America an initial purchase price of $75 million, and Bank of America delivered to us common stock, representing approximately 85% of the shares expected to be purchased under the third ASR Agreement.  The ASR Agreement was completed in the fourth quarter and Bank of America delivered additional shares for a total of 0.4 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-18-000004:notes:439]
We also repurchased 0.1 million  shares for $26.1 million and 0.2 million shares for $33.3 million for the years ended December 31, 2017 and 2016, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligations upon the vesting of stock-based compensation awards.
