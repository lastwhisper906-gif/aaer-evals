# LII MD&A — 0001069202-18-000004


## mdna

[0001069202-18-000004:mdna:1]
Item 7.  Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-18-000004:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the consolidated financial statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001069202-18-000004:mdna:3]
Business Overview

[0001069202-18-000004:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 18 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000004:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-18-000004:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-18-000004:mdna:7]
Financial Highlights

[0001069202-18-000004:mdna:8]
| • | Net sales increased $198 million, or 5.4%, to $3,840 million in 2017 from $3,642 million in 2016. |

[0001069202-18-000004:mdna:9]
| • | Operating income in 2017 was $495 million compared to $429 million in 2016. The increase was primarily due to increased sales, sourcing and engineering-led cost reductions, and a reduction in pension settlement costs partially offset by an increase in commodities in 2017. |

[0001069202-18-000004:mdna:10]
| • | Net income in 2017 increased to $306 million from $278 million in 2016. |

[0001069202-18-000004:mdna:11]
| • | Diluted earnings per share from continuing operations were $7.17 per share in 2017 compared to $6.34 per share in 2016. |

[0001069202-18-000004:mdna:12]
| • | We generated $325 million of cash flow from operating activities in 2017 compared to $374 million in 2016. The decrease was primarily due to an increase in working capital, partially offset by a reduction in pension contributions and an increase in net income. |

[0001069202-18-000004:mdna:13]
| • | In 2017, we returned $80 million to shareholders through dividend payments and we used $250.0 million to purchase 1.5 million shares of stock under our share repurchase plans. |

[0001069202-18-000004:mdna:14]
Overview of Results

[0001069202-18-000004:mdna:15]
The Residential Heating & Cooling segment led our overall financial performance in 2017, with a 7.0% increase in net sales and a $25 million increase in segment profit compared to 2016.  This segment's results benefited from market growth in the replacement and new construction markets and favorable foreign currency exchange rates.  Our Commercial Heating & Cooling segment also performed well in 2017 with a 6.1% increase in net sales and a $8 million increase in segment profit compared to 2016.  This segment's results benefited from market growth in North America.  Sales in our Refrigeration segment were up slightly and segment profit increased $4 million compared to 2016.  This segment's profit benefited from sourcing and engineering-led cost reductions partially offset by lower factory productivity.

[0001069202-18-000004:mdna:16]
On a consolidated basis, our gross profit margins decreased to 29.3% in 2017 due primarily to unfavorable commodities, factory inefficiencies, and continued investment in distribution expansion.  These declines were partially offset by favorable price and mix and sourcing and engineering-led cost reductions across our business.

[0001069202-18-000004:mdna:17]
Results of Operations

[0001069202-18-000004:mdna:18]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-18-000004:mdna:19]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,839.6 |  |  | 100.0 | % |  | $ | 3,641.6 |  |  | 100.0 | % |  | $ | 3,467.4 |  |  | 100.0 | % |
| Cost of goods sold | 2,714.4 |  |  | 70.7 | % |  | 2,565.1 |  |  | 70.4 | % |  | 2,520.0 |  |  | 72.7 | % |
| Gross profit | 1,125.2 |  |  | 29.3 | % |  | 1,076.5 |  |  | 29.6 | % |  | 947.4 |  |  | 27.3 | % |
| Selling, general and administrative expenses | 637.7 |  |  | 16.6 | % |  | 621.0 |  |  | 17.1 | % |  | 580.5 |  |  | 16.7 | % |
| Losses and other expenses, net | 8.2 |  |  | 0.2 | % |  | 11.3 |  |  | 0.3 | % |  | 21.7 |  |  | 0.6 | % |
| Restructuring charges | 3.2 |  |  | 0.1 | % |  | 1.8 |  |  | — | % |  | 3.2 |  |  | 0.1 | % |
| Goodwill impairment | — |  |  | — | % |  | — |  |  | — | % |  | 5.5 |  |  | 0.2 | % |
| Impairment of assets | — |  |  | — | % |  | — |  |  | — | % |  | 44.5 |  |  | 1.3 | % |
| Pension settlement | — |  |  | — | % |  | 31.4 |  |  | 0.9 | % |  | — |  |  | — | % |
| Income from equity method investments | (18.4 | ) |  | (0.5 | )% |  | (18.4 | ) |  | (0.5 | )% |  | (13.4 | ) |  | (0.4 | )% |
| Operating income | $ | 494.5 |  |  | 12.9 | % |  | $ | 429.4 |  |  | 11.8 | % |  | $ | 305.4 |  |  | 8.8 | % |
| Loss from discontinued operations | (1.4 | ) |  | — | % |  | (0.8 | ) |  | — | % |  | (0.6 | ) |  | — | % |
| Net income | $ | 305.7 |  |  | 8.0 | % |  | $ | 277.8 |  |  | 7.6 | % |  | $ | 186.6 |  |  | 5.4 | % |

[0001069202-18-000004:mdna:20]
The following table provides net sales by geographic market (dollars in millions):

[0001069202-18-000004:mdna:21]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net Sales by Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. | $ | 3,128.7 |  |  | 81.5 | % |  | $ | 2,966.8 |  |  | 81.5 | % |  | $ | 2,793.4 |  |  | 80.6 | % |
| Canada | 237.8 |  |  | 6.2 |  |  | 218.8 |  |  | 6.0 |  |  | 217.7 |  |  | 6.3 |  |
| International | 473.1 |  |  | 12.3 |  |  | 456.0 |  |  | 12.5 |  |  | 456.3 |  |  | 13.1 |  |
| Total net sales | $ | 3,839.6 |  |  | 100.0 | % |  | $ | 3,641.6 |  |  | 100.0 | % |  | $ | 3,467.4 |  |  | 100.0 | % |

[0001069202-18-000004:mdna:22]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016 - Consolidated Results

[0001069202-18-000004:mdna:23]
Net Sales

[0001069202-18-000004:mdna:24]
Net sales increased 5.4% in 2017 compared to 2016, primarily driven by volume increases.  The increase in volume was primarily due to market growth in our Residential Heating and Cooling and Commercial Heating and Cooling segments.  Changes in foreign currency exchange rates and the effects of price and mix also had positive impacts on net sales.

[0001069202-18-000004:mdna:25]
Gross Profit

[0001069202-18-000004:mdna:26]
Gross profit margins for 2017 decreased 30 basis points ("bps") to 29.3% compared to 29.6% in 2016.  We saw margin decreases of 80 bps from higher commodity costs, 50 bps for investments in distribution expansion, and 40 bps from other product costs.  These decreases were offset by increases of 100 bps from sourcing and engineering-led cost reductions and 40 bps from favorable price and mix.

[0001069202-18-000004:mdna:27]
Selling, General and Administrative Expenses

[0001069202-18-000004:mdna:28]
SG&A expenses increased by $17 million in 2017 compared to 2016.  As a percentage of net sales, SG&A expenses decreased 50 bps from 17.1% to 16.6% in the same periods.  SG&A increased due to general wage inflation, increased healthcare costs and increased investment in information technology and research and development partially offset by decreases in incentive compensation.

[0001069202-18-000004:mdna:29]
Losses and Other Expenses, Net

[0001069202-18-000004:mdna:30]
Losses and other expenses, net for 2017 and 2016 included the following (in millions):

[0001069202-18-000004:mdna:31]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |
| Realized (gains) losses, net on settled futures contracts | $ | (1.7 | ) |  | $ | 1.1 |  |
| Foreign currency exchange (gains) losses, net | (1.8 | ) |  | 2.2 |  |
| Losses on disposal of fixed assets | 0.2 |  |  | 0.5 |  |
| Net change in unrealized losses (gains), net on unsettled futures contracts | 0.9 |  |  | (3.6 | ) |
| Asbestos-related litigation | 3.5 |  |  | 6.3 |  |
| Acquisition expenses | 1.1 |  |  | 0.4 |  |
| Special legal contingency charge | 3.7 |  |  | 1.9 |  |
| Environmental liabilities | 2.2 |  |  | 1.9 |  |
| Contractor tax payments | 0.1 |  |  | 0.6 |  |
| Losses and other expenses, net | $ | 8.2 |  |  | $ | 11.3 |  |

[0001069202-18-000004:mdna:32]
The realized gains on settled futures contracts in 2017 was attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2017 relative to 2016.  Additionally, the change in unrealized losses, net on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000004:mdna:33]
Foreign currency exchange gains increased in 2017 primarily due to improvement in foreign exchange rates in our primary markets.  The special legal contingency charges increased primarily due to costs associated with the matter reported to the Securities and Exchange Commission and Department of Justice.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  The contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-18-000004:mdna:34]
Restructuring Charges

[0001069202-18-000004:mdna:35]
Restructuring charges were $3.2 million in 2017 compared to $1.8 million in 2016.  The charges in 2017 and 2016 were primarily for projects to realign resources and enhance distribution capabilities.  For more information on our restructuring activities, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000004:mdna:36]
Goodwill

[0001069202-18-000004:mdna:37]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment through December 31, 2017. Also, we did not record any goodwill impairments in 2016. Refer to Note 4 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-18-000004:mdna:38]
Asset Impairment

[0001069202-18-000004:mdna:39]
We did not have any impairments of assets related to continuing operations in 2017 and 2016.

[0001069202-18-000004:mdna:40]
Pension Settlement

[0001069202-18-000004:mdna:41]
In 2016 our unfunded pension liability declined by $33 million to $89 million as the favorable impact of our $50 million discretionary contribution was partially offset by lower discount rates across all plans.  In addition, we recorded a pension settlement charge of $31 million in the fourth quarter of 2016.  We did not have similar funding or pension buyout activity in 2017.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-18-000004:mdna:42]
Income from Equity Method Investments

[0001069202-18-000004:mdna:43]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $18 million in 2017 compared to $18 million in 2016 due to flat earnings from our joint ventures.

[0001069202-18-000004:mdna:44]
Interest Expense, net

[0001069202-18-000004:mdna:45]
Net interest expense of $31 million in 2017 increased from $27 million in 2016 primarily due to an increase in our average borrowings.

[0001069202-18-000004:mdna:46]
Income Taxes

[0001069202-18-000004:mdna:47]
The income tax provision was $157 million in 2017 compared to $124 million in 2016, and the effective tax rate was 34% in 2017 compared to 31% in 2016.  The 2017 effective tax rate was negatively impacted by recent changes in U.S. tax legislation that reduced the value of our deferred tax assets by $31.8 million, partially offset by the benefit from the impact of excess tax benefits of $23.6 million.  The 2016 effective tax rate was not impacted by either U.S. tax rate changes or the impact of excess tax benefits.  We expect our effective tax rate will be between 22% and 24% in future years due to the changes in U.S. tax legislation excluding the impact of excess tax benefits.  Refer to Note 9 in the Notes to the Consolidated Financial Statements for more information on the impact of recent changes in tax legislation.

[0001069202-18-000004:mdna:48]
Loss from Discontinued Operations

[0001069202-18-000004:mdna:49]
The $2 million of pre-tax losses incurred in 2017 and $1 million of pre-tax losses in 2016 primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-18-000004:mdna:50]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016 - Results by Segment

[0001069202-18-000004:mdna:51]
Residential Heating & Cooling

[0001069202-18-000004:mdna:52]
The following table presents our Residential Heating & Cooling segment's net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-18-000004:mdna:53]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 2,140.4 |  |  | $ | 2,000.8 |  |  | $ | 139.6 |  |  | 7.0 | % |
| Profit | $ | 373.9 |  |  | $ | 348.8 |  |  | $ | 25.1 |  |  | 7.2 | % |
| % of net sales | 17.5 | % |  | 17.4 | % |  |  |  |  |

[0001069202-18-000004:mdna:54]
Residential Heating & Cooling net sales increased 7% in 2017 compared to 2016. Sales volume increased by 7% primarily due to market growth.

[0001069202-18-000004:mdna:55]
Segment profit in 2017 increased $25 million due to $39 million from higher sales volume, $21 million from sourcing and engineering-led cost reductions, $15 million from favorable price, $5 million from favorable foreign currency, $2 million from lower warranty expense, and $1 million from higher income from equity method investments.  Partially offsetting these increases was $20 million in higher commodity costs, $15 million in SG&A expenses to support investments in technology and research and development, incremental headcount and higher personnel costs, $12 million in freight and distribution investments, $6 million from unfavorable mix, and $5 million from increases in other product costs.

[0001069202-18-000004:mdna:56]
Commercial Heating & Cooling

[0001069202-18-000004:mdna:57]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-18-000004:mdna:58]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 973.8 |  |  | $ | 917.9 |  |  | $ | 55.9 |  |  | 6.1 | % |
| Profit | $ | 157.3 |  |  | $ | 149.3 |  |  | $ | 8.0 |  |  | 5.4 | % |
| % of net sales | 16.2 | % |  | 16.3 | % |  |  |  |  |

[0001069202-18-000004:mdna:59]
Commercial Heating & Cooling net sales increased 6% in 2017 compared to 2016.  Sales volume increased by 5% primarily due to market growth and 1% from favorable foreign currency.

[0001069202-18-000004:mdna:60]
Segment profit in 2017 increased $8 million compared to 2016 due to $14 million from higher sales volume, $7 million from sourcing and engineering-led cost reductions, and $1 million in favorable foreign currency.  Partially offsetting these increases was $5 million from warranty and other product costs, $4 million of higher commodity costs, $3 million from factory inefficiencies, $1 million in higher SG&A expenses, and $1 million in freight and distribution investments.

[0001069202-18-000004:mdna:61]
Refrigeration

[0001069202-18-000004:mdna:62]
The following table presents our Refrigeration segment's net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-18-000004:mdna:63]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 725.4 |  |  | $ | 722.9 |  |  | $ | 2.5 |  |  | 0.3 | % |
| Profit | $ | 72.6 |  |  | $ | 68.9 |  |  | $ | 3.7 |  |  | 5.4 | % |
| % of net sales | 10.0 | % |  | 9.5 | % |  |  |  |  |

[0001069202-18-000004:mdna:64]
Net sales in 2017 were flat compared to 2016.  Favorable foreign currency increased sales by 1% offset by lower sales volume of 1% primarily from our North America supermarket business.

[0001069202-18-000004:mdna:65]
Segment profit in 2017 increased $4 million compared to 2016 due to $9 million from sourcing and engineering-led cost reductions, $3 million from favorable price and mix, and $3 million in lower other product costs.  Partially offsetting these increases was $5 million from factory inefficiencies, $2 million from freight and distribution, $2 million from higher commodity costs, and $2 million from higher SG&A expense.

[0001069202-18-000004:mdna:66]
Corporate and Other

[0001069202-18-000004:mdna:67]
Corporate and other expenses decreased by $8 million in 2017 primarily due from lower incentive compensation with a partial offset from general wage inflation and information technology investments.

[0001069202-18-000004:mdna:68]
Year Ended December 31, 2016 Compared to Year Ended December 31, 2015 - Consolidated Results

[0001069202-18-000004:mdna:69]
Net Sales

[0001069202-18-000004:mdna:70]
Net sales increased 5% in 2016 compared to 2015, with sales volume up approximately 5%.  The increase in volume was driven by all our business segments.  The effects of both changes in foreign currency exchange rates and the effects of price and mix were neutral to net sales.

[0001069202-18-000004:mdna:71]
Gross Profit

[0001069202-18-000004:mdna:72]
Gross profit margins for 2016 increased 230 basis points ("bps") to 29.6% compared to 27.3% in 2015.  Lower material costs increased our profit margin by 260 bps, increased factory productivity increased our profit margin by 30 bps, and other items contributed 10 bps. Offsetting these increases were decreases of 20 bps from unfavorable mix, 20 bps from unfavorable foreign

[0001069202-18-000004:mdna:73]
currency adjustments, 20 bps for investments in distribution and other growth initiatives, and increased product warranty costs decreased our profit margin by 10 bps.

[0001069202-18-000004:mdna:74]
Selling, General and Administrative Expenses

[0001069202-18-000004:mdna:75]
SG&A expenses increased by $41 million in 2016 compared to 2015.  As a percentage of net sales, SG&A expenses increased 40 bps from 16.7% to 17.1% in the same periods.  The dollar increase in SG&A expenses was principally due to increased incentive compensation and general wage inflation.

[0001069202-18-000004:mdna:76]
Losses and Other Expenses, Net

[0001069202-18-000004:mdna:77]
Losses and other expenses, net for 2016 and 2015 included the following (in millions):

[0001069202-18-000004:mdna:78]
|  | For the Years Ended December 31, |
|  | 2016 |  | 2015 |
| Realized losses on settled futures contracts | $ | 1.1 |  |  | $ | 1.9 |  |
| Foreign currency exchange losses | 2.2 |  |  | 3.6 |  |
| Loss on disposal of fixed assets | 0.5 |  |  | 0.6 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (3.6 | ) |  | 0.6 |  |
| Asbestos charge | 6.3 |  |  | 3.0 |  |
| Acquisition expenses | 0.4 |  |  | 1.0 |  |
| Special legal contingency charge | 1.9 |  |  | 7.4 |  |
| Environmental liabilities | 1.9 |  |  | 1.0 |  |
| Contractor tax payments | 0.6 |  |  | 2.6 |  |
| Other items, net | — |  |  | — |  |
| Losses and other expenses, net | $ | 11.3 |  |  | $ | 21.7 |  |

[0001069202-18-000004:mdna:79]
The decrease in realized losses on settled futures contracts in 2016 was attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2016 relative to 2015.  Additionally, the change in unrealized gains and losses on unsettled futures contracts was primarily due to higher commodity prices relative to the unsettled futures contract prices creating unrealized gains on unsettled future contracts.  For more information on our derivatives, see Note 8 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000004:mdna:80]
Foreign currency exchange losses decreased in 2016 primarily due to stabilization in foreign exchange rates in our primary markets.  The special legal contingency charges primarily decreased as we settled an attempted class action lawsuit in 2015.  The asbestos-related litigation relates to known and estimated future asbestos matters and the increase is a result of higher estimated future claims and decreasing insurance reserves related to these claims.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  The contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-18-000004:mdna:81]
Restructuring Charges

[0001069202-18-000004:mdna:82]
Restructuring charges were $2 million in 2016 compared to $3 million in 2015.  The charges in 2016 and 2015 were primarily for projects to realign resources and enhance distribution capabilities in our Refrigeration segment.  For more information on our restructuring activities, see Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-18-000004:mdna:83]
Goodwill

[0001069202-18-000004:mdna:84]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment through December 31, 2016. However in 2015 based on the results of the quantitative impairment test, we recorded goodwill impairment of $5.5 million related to our refrigerated display case business. Refer to Note 4 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-18-000004:mdna:85]
Asset Impairment

[0001069202-18-000004:mdna:86]
We did not have any impairments of assets related to continuing operations in 2016. During the fourth quarter of 2015 we completed a strategic review of our refrigerated display case business.  As a result, we performed an impairment analysis using a market approach and determined that intangible and certain long-lived assets relating to that business were impaired and we recorded a charge of $45 million in "Asset Impairment" in the Consolidated Statement of Operations.

[0001069202-18-000004:mdna:87]
Pension Settlement

[0001069202-18-000004:mdna:88]
In 2016 our unfunded pension liability declined by $33 million to $89 million as the favorable impact of our $50 million discretionary contribution was partially offset by lower discount rates across all plans.  In addition, as part of our ongoing strategy to de-risk our pension plan obligations, we completed a one-time, lump sum pension buyout in the fourth quarter of 2016 for certain vested participants.  As a result of the pension buy-out, we recorded a pension settlement charge of $31 million in the fourth quarter.

[0001069202-18-000004:mdna:89]
Income from Equity Method Investments

[0001069202-18-000004:mdna:90]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments increased to $18 million in 2016 compared to $13 million in 2015 due to increases in earnings from our joint ventures.

[0001069202-18-000004:mdna:91]
Interest Expense, net

[0001069202-18-000004:mdna:92]
Net interest expense of $27 million in 2016 increased from $24 million in 2015 primarily due to an increase in our average borrowings.

[0001069202-18-000004:mdna:93]
Income Taxes

[0001069202-18-000004:mdna:94]
The income tax provision was $124 million in 2016 compared to $95 million in 2015, and the effective tax rate was 30.8% in 2016 compared to 33.8% in 2015.  Our effective tax rate declined in 2016 due to the benefit from a repatriation of earnings recognized in the second quarter.

[0001069202-18-000004:mdna:95]
Loss from Discontinued Operations

[0001069202-18-000004:mdna:96]
The $1 million of pre-tax losses incurred in 2016 primarily relates to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012. In 2015, there were $1 million of pre-tax losses incurred primarily related to changes in retained product liabilities and general liabilities for Service Experts and Hearth.

[0001069202-18-000004:mdna:97]
Year Ended December 31, 2016 Compared to Year Ended December 31, 2015 - Results by Segment

[0001069202-18-000004:mdna:98]
Residential Heating & Cooling

[0001069202-18-000004:mdna:99]
The following table presents our Residential Heating & Cooling segment's net sales and profit for 2016 and 2015 (dollars in millions):

[0001069202-18-000004:mdna:100]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 2,000.8 |  |  | $ | 1,866.9 |  |  | $ | 133.9 |  |  | 7.2 | % |
| Profit | $ | 348.8 |  |  | $ | 278.4 |  |  | $ | 70.4 |  |  | 25.3 | % |
| % of net sales | 17.4 | % |  | 14.9 | % |  |  |  |  |

[0001069202-18-000004:mdna:101]
Residential Heating & Cooling net sales increased 7% in 2016 compared to 2015. Sales volume increased net sales by 6% due to industry growth and market share gains and the benefits of favorable price and mix contributed 1%.

[0001069202-18-000004:mdna:102]
Segment profit in 2016 increased $70 million due to $51 million in lower commodities and material costs, $33 million from higher sales volume and $12 million from favorable factory productivity which includes the addition of a second factory in Mexico, and $5 million in other product costs. Partially offsetting these increases was $6 million from unfavorable price and mix combined,

[0001069202-18-000004:mdna:103]
$4 million of unfavorable foreign currency exchange rates, $11 million in distribution investments, and $10 million of SG&A expenses to support wage inflation and investments in information technology and research and development.

[0001069202-18-000004:mdna:104]
Commercial Heating & Cooling

[0001069202-18-000004:mdna:105]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for 2016 and 2015 (dollars in millions):

[0001069202-18-000004:mdna:106]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 917.9 |  |  | $ | 887.2 |  |  | $ | 30.7 |  |  | 3.5 | % |
| Profit | $ | 149.3 |  |  | $ | 130.4 |  |  | $ | 18.9 |  |  | 14.5 | % |
| % of net sales | 16.3 | % |  | 14.7 | % |  |  |  |  |

[0001069202-18-000004:mdna:107]
Commercial Heating & Cooling net sales increased 3% in 2016 compared to 2015.  Sales volume increased net sales by 3%,  price and mix increased net sales by 1% and changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-18-000004:mdna:108]
Segment profit in 2016 increased $19 million compared to 2015.  The benefits of $9 million from incremental volume, $18 million from lower commodities and material costs, $4 million from combined price and mix and $1 million from lower freight expenses were partially offset by $6 million in other product costs and unfavorable factory productivity, $6 million of higher SG&A expenses, and $1 million for investments in infrastructure for our North American Service business.

[0001069202-18-000004:mdna:109]
Refrigeration

[0001069202-18-000004:mdna:110]
The following table presents our Refrigeration segment's net sales and profit for 2016 and 2015 (dollars in millions):

[0001069202-18-000004:mdna:111]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Difference |  | % Change |
| Net sales | $ | 722.9 |  |  | $ | 713.3 |  |  | $ | 9.6 |  |  | 1.3 | % |
| Profit | $ | 68.9 |  |  | $ | 52.9 |  |  | $ | 16.0 |  |  | 30.2 | % |
| % of net sales | 9.5 | % |  | 7.4 | % |  |  |  |  |

[0001069202-18-000004:mdna:112]
Refrigeration net sales increased 1% in 2016 compared to 2015 primarily due to 3% volume growth which was partially offset by a 1% impact from unfavorable foreign exchange rates and a 1% impact from mix and price reductions.

[0001069202-18-000004:mdna:113]
Segment profit in 2016 compared to 2015 increased $16 million compared to 2015 primarily due to $7 million from increased sales volume, $21 million in lower commodities and material costs, $6 million from lower depreciation and amortization due to the impairment of our refrigerated display case business recorded in 2015.  Partially offsetting these increases were $8 million from unfavorable price and mix combined, $8 million from higher SG&A expenses, $1 million from other product costs, and $1 million from changes in foreign currency exchange rates.

[0001069202-18-000004:mdna:114]
Corporate and Other

[0001069202-18-000004:mdna:115]
Corporate and other expenses increased $13 million in 2016 as compared to 2015 due primarily to higher incentive compensation, general wage inflation, and consulting fees.  Partially offsetting these increases were decreases in health care costs.

[0001069202-18-000004:mdna:116]
Accounting for Futures Contracts

[0001069202-18-000004:mdna:117]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 8 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 18 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001069202-18-000004:mdna:118]
Liquidity and Capital Resources

[0001069202-18-000004:mdna:119]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-18-000004:mdna:120]
Statement of Cash Flows

[0001069202-18-000004:mdna:121]
The following table summarizes our cash flow activity for the years ended December 31, 2017, 2016 and 2015 (in millions):

[0001069202-18-000004:mdna:122]
|  | 2017 |  | 2016 |  | 2015 |
| Net cash provided by operating activities | $ | 325.1 |  |  | $ | 373.9 |  |  | $ | 353.6 |  |
| Net cash used in investing activities | (98.1 | ) |  | (84.1 | ) |  | (69.8 | ) |
| Net cash used in financing activities | (218.3 | ) |  | (274.6 | ) |  | (271.1 | ) |

[0001069202-18-000004:mdna:123]
Net Cash Provided by Operating Activities - Net cash provided by operating activities decreased $49 million to $325 million in 2017 compared to $374 million in 2016.  This decrease was primarily attributable to the increases in working capital, partially offset by a reduction in pension contributions and an increase in net income.

[0001069202-18-000004:mdna:124]
Net Cash Used in Investing Activities - Capital expenditures were $98 million, $84 million and $70 million in 2017, 2016 and 2015, respectively.  Capital expenditures in 2017 were primarily related to an expansion of manufacturing capacity and equipment, investments in systems and software to support the overall enterprise, and continued investments in our distribution network.

[0001069202-18-000004:mdna:125]
Net Cash Used in Financing Activities - Net cash used in financing activities decreased to $218 million in 2017 from $275 million in 2016, primarily attributable to a decrease in the amount of share repurchases in 2017 as compared to 2016.  Cash continues to be provided by an increase in net borrowings and used to fund share repurchases and dividend payments.  We used $250.0 million in 2017 to purchase 1.5 million shares of stock under our share repurchase plans.

[0001069202-18-000004:mdna:126]
Debt Position

[0001069202-18-000004:mdna:127]
The following table details our lines of credit and financing arrangements as of December 31, 2017 (in millions):

[0001069202-18-000004:mdna:128]
|  | Outstanding Borrowings |
| Short-term debt: |  |
| Foreign Obligations | $ | 0.9 |  |
| Asset Securitization Program (1) | — |  |
| Total short-term debt | $ | 0.9 |  |
| Current maturities of long-term debt: |  |
| Capital lease obligations | 3.2 |  |
| Domestic credit facility (2) | 30.0 |  |
| Senior unsecured notes | — |  |
| Debt issuance costs | (0.6 | ) |
| Total current maturities of long-term debt | $ | 32.6 |  |
| Long-term debt: |  |
| Asset Securitization Program (1) | 276.0 |  |
| Capital lease obligations | 11.9 |  |
| Domestic credit facility (2) | 337.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (4.4 | ) |
| Total long-term debt | 970.5 |  |
| Total debt | $ | 1,004.0 |  |

[0001069202-18-000004:mdna:129]
| (1) | The maximum securitization amount ranges from $225.0 million to $380.0 million, depending on the period, after consideration of the November 13, 2017 amendment. The maximum capacity of the Asset Securitization Program ("ASP") is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-18-000004:mdna:130]
| (2) | The available future borrowings on our domestic credit facility are $500.1 million after being reduced by the outstanding borrowings and $2.9 million in outstanding standby letters of credit. We also had $34.7 million in outstanding standby letters of credit outside of the domestic credit facility as of December 31, 2017. |

[0001069202-18-000004:mdna:131]
Financial Leverage

[0001069202-18-000004:mdna:132]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-18-000004:mdna:133]
As of December 31, 2017, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001069202-18-000004:mdna:134]
Our debt-to-total-capital ratio decreased to 95.2% at December 31, 2017 compared to 95.8% at December 31, 2016.  The decrease in the ratio in 2017 is primarily due to the increase in Total stockholders' equity.  We evaluate our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.

[0001069202-18-000004:mdna:135]
Liquidity

[0001069202-18-000004:mdna:136]
We believe our cash and cash equivalents of $68 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $68 million as of December 31,

[0001069202-18-000004:mdna:137]
2017 was $39 million of cash held in foreign locations, although that amount can fluctuate widely depending on the timing of cash receipts and payments.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.  In the first quarter of 2018 we expect to repatriate $40 million of cash on a tax-free basis.

[0001069202-18-000004:mdna:138]
No contributions are required to be made to our U.S. defined benefit plans in 2018. We made $3.5 million in total contributions to pension plans in 2017.

[0001069202-18-000004:mdna:139]
On May 17, 2017, our Board of Directors approved a 19% increase in our quarterly dividend on common stock from $0.43 to $0.51 per share effective with the May 2017 dividend payment.  Dividend payments were $80 million in 2017 compared to $69 million in 2016, with the increase due primarily to the increase in dividends approved by the Board of Directors.

[0001069202-18-000004:mdna:140]
We also continued to increase shareholder value through our share repurchase programs.  We returned $250.0 million to our investors through share repurchases in 2017 and expect to return another $350.0 million in 2018.  An additional $396 million of repurchases are still available under the programs as we enter 2018.

[0001069202-18-000004:mdna:141]
Financial Covenants related to our Debt

[0001069202-18-000004:mdna:142]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Net Interest Expense Ratio.  The required ratios under our domestic credit facility are detailed below:

[0001069202-18-000004:mdna:143]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Net Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-18-000004:mdna:144]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-18-000004:mdna:145]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization of at least $75.0 million; or |

[0001069202-18-000004:mdna:146]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount of at least $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-18-000004:mdna:147]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our domestic credit facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-18-000004:mdna:148]
If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders' commitments will automatically terminate).

[0001069202-18-000004:mdna:149]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-18-000004:mdna:150]
As of December 31, 2017, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001069202-18-000004:mdna:151]
Leasing Commitments

[0001069202-18-000004:mdna:152]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the "Lake Park Renewal").  The agreement contains customary lease covenants and events of default as well as financial covenants consistent with our credit agreement and we believe we were in compliance with those covenants as of December 31, 2017.

[0001069202-18-000004:mdna:153]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from industrial development bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and have oustanding letters of credit totaling $14.3 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the trustee.  As of December 31, 2017 and 2016, we had capital lease obligations of $14.3 million related to these transactions, with $2.6 million of payments due in 2018.

[0001069202-18-000004:mdna:154]
Refer to Note 10 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-18-000004:mdna:155]
Off Balance Sheet Arrangements

[0001069202-18-000004:mdna:156]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Rent expense for these leases was $58 million, $58 million, and $54 million in 2017, 2016, and 2015, respectively.  Refer to Notes 10 and 22 of the Notes to the Consolidated Financial Statements for more information on our lease commitments and rent expense, respectively.

[0001069202-18-000004:mdna:157]
Contractual Obligations

[0001069202-18-000004:mdna:158]
Summarized below are our contractual obligations as of December 31, 2017 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-18-000004:mdna:159]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 1,009.0 |  |  | $ | 34.1 |  |  | $ | 336.3 |  |  | $ | 277.0 |  |  | $ | 361.6 |  |
| Estimated interest payments on debt obligations (2) | 97.4 |  |  | 22.1 |  |  | 36.1 |  |  | 27.6 |  |  | 11.6 |  |
| Operating leases | 175.9 |  |  | 55.3 |  |  | 70.8 |  |  | 36.0 |  |  | 13.8 |  |
| Purchase obligations (3) | 31.1 |  |  | 31.1 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 1,313.4 |  |  | $ | 142.6 |  |  | $ | 443.2 |  |  | $ | 340.6 |  |  | $ | 387.0 |  |

[0001069202-18-000004:mdna:160]
(1) Contractual obligations related to capital leases are included as part of long-term debt.

[0001069202-18-000004:mdna:161]
(2) Estimated interest payments are based on current contractual requirements and do not reflect seasonal changes in the balance of our domestic credit facility.

[0001069202-18-000004:mdna:162]
(3) Purchase obligations consist of inventory that is part of our third party logistics programs.

[0001069202-18-000004:mdna:163]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded.  For additional information regarding our contractual obligations, see Notes 10 and 11 of the Notes to the Consolidated Financial Statements.  See Note 12 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-18-000004:mdna:164]
Fair Value Measurements

[0001069202-18-000004:mdna:165]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-18-000004:mdna:166]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-18-000004:mdna:167]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-18-000004:mdna:168]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-18-000004:mdna:169]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity's own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-18-000004:mdna:170]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party's creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2017 and 2016, the measurement dates.

[0001069202-18-000004:mdna:171]
See Note 19 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-18-000004:mdna:172]
Market Risk

[0001069202-18-000004:mdna:173]
Commodity Price Risk

[0001069202-18-000004:mdna:174]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-18-000004:mdna:175]
| Notional amount (pounds of aluminum and copper) | 24.2 |  |
| Carrying amount and fair value of net liability | $ | 12.9 |  |
| Change in fair value from 10% change in forward prices | $ | 7.6 |  |

[0001069202-18-000004:mdna:176]
Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-18-000004:mdna:177]
Interest Rate Risk

[0001069202-18-000004:mdna:178]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $1.8 million, $2.0 million and $2.1 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001069202-18-000004:mdna:179]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2017 and 2016, no interest rate swaps were in effect.

[0001069202-18-000004:mdna:180]
Foreign Currency Exchange Rate Risk

[0001069202-18-000004:mdna:181]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2017, 2016 and 2015, net sales from outside the U.S. represented 18.5%, 18.5% and 19.4% , respectively, of our total net sales.  For the years ended December 31, 2017 and 2016, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $5.2 million, $4.0  million and $2.5 million impact to net income for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001069202-18-000004:mdna:182]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 8 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-18-000004:mdna:183]
Critical Accounting Estimates

[0001069202-18-000004:mdna:184]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following are our critical accounting estimates and describe how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements:

[0001069202-18-000004:mdna:185]
| • | Product warranties and product-related contingencies; |

[0001069202-18-000004:mdna:186]
| • | Self-insurance expense; |

[0001069202-18-000004:mdna:187]
| • | Pension benefits; and |

[0001069202-18-000004:mdna:188]
| • | Derivative accounting. |

[0001069202-18-000004:mdna:189]
This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-18-000004:mdna:190]
Product Warranties and Product-Related Contingencies

[0001069202-18-000004:mdna:191]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.  We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.

[0001069202-18-000004:mdna:192]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 10 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-18-000004:mdna:193]
Self-Insurance Expense

[0001069202-18-000004:mdna:194]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers' compensation/employers' liability, general liability, product liability, auto liability, auto physical damage and other exposures.  Many of these plans have large deductibles and may also include per occurrence and annual aggregate limits.  As a result, we expect to incur costs related to these types of claims in future periods.

[0001069202-18-000004:mdna:195]
The estimates for self-insurance expense and liabilities involve assumptions about the amount, timing and nature of future claim costs.  We estimate these amounts actuarially based primarily on our historical claims information and industry factors and trends.  The amounts and timing of payments for future claims may vary depending on numerous factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience differ from historical rates, our liabilities may change.  The self-insurance liabilities as of December 31, 2017 represent the best

[0001069202-18-000004:mdna:196]
estimate of the future payments to be made on reported and unreported losses.  See Note 10 in the Notes to the Consolidated Financial Statements for additional information on our self-insurance expense and liabilities.

[0001069202-18-000004:mdna:197]
Pension Benefits

[0001069202-18-000004:mdna:198]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans. We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen. Our defined contribution plans generally include both company and employee contributions based on predetermined percentages of compensation earned by the employee. We also have several active defined benefit plans that provide benefits based on years of service. In the years ended December 31, 2017, December 31, 2016 and December 31, 2015, we contributed $3.5 million, $53.9 and $3.9 million to our pension plans, respectively.

[0001069202-18-000004:mdna:199]
We make several assumptions to calculate our liability and the expense for these benefit plans, including the discount rate and expected return on assets. We used an assumed discount rate of 3.66% for pension benefits of our U.S.-based plans as of December 31, 2017. Our discount rates were selected using the yield curve for high-quality corporate bonds, which is dependent upon risk-free interest rates and current credit market conditions. In 2017 and 2016, we utilized an assumed long-term rate of return on assets of 7.50% in both years for our U.S.-based plans. These are long-term estimates of equity and fixed income values and are not dependent on short-term variations of the equity and bond markets. Differences between actual experience and our assumptions are quantified as actuarial gains and losses. These actuarial gains and losses do not immediately impact our earnings as they are deferred in accumulated other comprehensive income (“AOCI”) and are amortized into net periodic benefit cost over the estimated service period.  During 2015, we adopted the new mortality tables, MP-2015, from the Society of Actuaries, which reflects increasing life expectancies in the United States. In 2016, we adopted the additional revisions to the mortality tables included in MP-2016.  In 2017, we adopted the additional revisions to the mortality tables included in MP-2017.

[0001069202-18-000004:mdna:200]
The assumed long-term rate of return on assets and the discount rate have significant effects on the amounts reported for our defined benefit plans. A 25 bps decrease in the long-term rate of return on assets or discount rate would have the following effects (in millions):

[0001069202-18-000004:mdna:201]
|  | 25 Basis Point Decrease in Long-Term Rate of Return |  | 25 Basis Point Decrease in Discount Rate |
| Increase to net periodic benefit cost for U.S. pension plans | $ | 0.7 |  |  | $ | 0.5 |  |
| Increase to the pension benefit obligations for U.S. pension plans | n/a |  |  | 11.8 |  |

[0001069202-18-000004:mdna:202]
Should actual results differ from our estimates and assumptions, revisions to the benefit plan liabilities and the related expenses would be required.  In the second quarter of 2017, in order to decrease volatility, we changed the targeted allocations for our U.S.-based plan assets.  The targeted allocation for fixed income, money market and cash investments was changed to 75% and the targeted allocation for equity investments was changed to 25%.  Based on this current asset allocation, it is likely that we will adjust our estimated rate of return downward.  We periodically review our asset allocation and may reallocate assets as necessary.  Refer to Note 12 in the Notes to the Consolidated Financial Statements for more information on our pension benefits.

[0001069202-18-000004:mdna:203]
Derivative Accounting

[0001069202-18-000004:mdna:204]
We use futures contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices in the ordinary course of business.  Fluctuations in metal commodity prices impact the value of the derivative instruments that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases and conversely, when commodity prices fall, the fair value of our futures contracts decreases.  We are required to prepare and maintain contemporaneous documentation for futures contracts that are formally designated as cash flow hedges.  Our failure to comply with the strict documentation requirements could result in the de-designation of cash flow hedges, which may significantly impact our consolidated financial statements.  Refer to "Market Risk" above and to Note 8 in the Notes to the Consolidated Financial Statements for more information on our derivatives.

[0001069202-18-000004:mdna:205]
Recent Accounting Pronouncements

[0001069202-18-000004:mdna:206]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
