# LII notes — 0001628280-22-010108


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-22-010108:notes:1]
[same as prior period, unchanged from 0001628280-21-020422:notes:3]

[0001628280-22-010108:notes:2]
[same as prior period, unchanged from 0001628280-21-020422:notes:4]

[0001628280-22-010108:notes:3]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2022, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001628280-22-010108:notes:4]
[same as prior period, unchanged from 0001628280-21-020422:notes:6]

[0001628280-22-010108:notes:5]
[same as prior period, unchanged from 0001628280-21-020422:notes:7]

[0001628280-22-010108:notes:6]
[same as prior period, unchanged from 0001628280-21-020422:notes:8]

[0001628280-22-010108:notes:7]
The preparation of financial statements requires us to make estimates and assumptions about future events. These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenues and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, self-insurance and warranty reserves, and stock-based compensation, among others. These estimates and assumptions are based on our best estimates and judgment.

[0001628280-22-010108:notes:8]
[same as prior period, unchanged from 0001628280-21-020422:notes:10]

[0001628280-22-010108:notes:9]
[same as prior period, unchanged from 0001628280-21-020422:notes:11]

[0001628280-22-010108:notes:10]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

[0001628280-22-010108:notes:11]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus become more

[0001628280-22-010108:notes:12]
dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001628280-22-010108:notes:13]
Executive Leadership Transition
On March 23, 2022, the Board of Directors appointed Alok Maskara as CEO effective May 9, 2022.  Mr. Maskara succeeds Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and will serve as interim CEO until Mr. Maskara assumes the role as CEO.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-010108:notes:14]
[same as prior period, unchanged from 0001628280-21-020422:notes:17]

[0001628280-22-010108:notes:15]
[same as prior period, unchanged from 0001628280-21-020422:notes:18]

[0001628280-22-010108:notes:16]
[same as prior period, unchanged from 0001628280-21-020422:notes:19]

[0001628280-22-010108:notes:17]
[same as prior period, unchanged from 0001628280-21-020422:notes:20]

[0001628280-22-010108:notes:18]
[same as prior period, unchanged from 0001628280-21-020422:notes:21]

[0001628280-22-010108:notes:19]
[same as prior period, unchanged from 0001628280-21-020422:notes:22]

[0001628280-22-010108:notes:20]
[same as prior period, unchanged from 0001628280-21-020422:notes:23]

[0001628280-22-010108:notes:21]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 682.2 |  |  | $ | 606.3 |  |  |  |  |  |
| Commercial Heating & Cooling | 187.7 |  |  | 199.2 |  |  |  |  |  |
| Refrigeration | 143.5 |  |  | 125.0 |  |  |  |  |  |
|  | $ | 1,013.4 |  |  | $ | 930.5 |  |  |  |  |  |
| Segment profit (loss) (1) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 107.6 |  |  | $ | 96.4 |  |  |  |  |  |
| Commercial Heating & Cooling | 6.3 |  |  | 27.4 |  |  |  |  |  |
| Refrigeration | 14.1 |  |  | 7.9 |  |  |  |  |  |
| Corporate and other | (13.4) |  |  | (16.0) |  |  |  |  |  |
| Total segment profit | 114.6 |  |  | 115.7 |  |  |  |  |  |
| Reconciliation to Operating income: |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) | 2.2 |  |  | 1.5 |  |  |  |  |  |
| Restructuring charges | 0.5 |  |  | 0.1 |  |  |  |  |  |
| Operating income | $ | 111.9 |  |  | $ | 114.1 |  |  |  |  |  |

[0001628280-22-010108:notes:22]
[same as prior period, unchanged from 0001628280-21-020422:notes:25]

[0001628280-22-010108:notes:23]
[same as prior period, unchanged from 0001628280-21-020422:notes:26]

[0001628280-22-010108:notes:24]
[same as prior period, unchanged from 0001628280-21-020422:notes:27]

[0001628280-22-010108:notes:25]
▪Special legal contingency charges,

[0001628280-22-010108:notes:26]
▪Asbestos-related litigation,

[0001628280-22-010108:notes:27]
[same as prior period, unchanged from 0001628280-21-020422:notes:30]

[0001628280-22-010108:notes:28]
[same as prior period, unchanged from 0001628280-21-020422:notes:31]

[0001628280-22-010108:notes:29]
[same as prior period, unchanged from 0001628280-21-020422:notes:32]

[0001628280-22-010108:notes:30]
◦Special product quality adjustments, and

[0001628280-22-010108:notes:31]
[same as prior period, unchanged from 0001628280-21-020422:notes:35]


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-010108:notes:32]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period. Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.
The computations of basic and diluted earnings per share were as follows (in millions, except per share data):

[0001628280-22-010108:notes:33]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net income | $ | 83.6 |  |  | $ | 84.2 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 36.3 |  |  | 38.0 |  |  |  |  |  |
| Add: Potential effect of dilutive securities attributable to stock-based payments | 0.2 |  |  | 0.2 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 36.5 |  |  | 38.2 |  |  |  |  |  |
| Earnings per share - Basic | $ | 2.30 |  |  | $ | 2.22 |  |  |  |  |  |
| Earnings per share - diluted | $ | 2.29 |  |  | $ | 2.20 |  |  |  |  |  |

[0001628280-22-010108:notes:34]
[same as prior period, unchanged from 0001628280-21-020422:notes:38]

[0001628280-22-010108:notes:35]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Weighted-average number of shares | 0.2 |  |  | 0.1 |  |  |  |  |  |
| Price per share | $278.00-$328.65 |  | $278.00 |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-22-010108:notes:36]
Leases

[0001628280-22-010108:notes:37]
We determine if an arrangement is a lease at inception. Operating leases are included in our Consolidated Balance Sheets as Right-of-use assets from operating leases, Current operating lease liabilities and Long-term operating lease liabilities.  Finance leases are included in Property, plant and equipment, Current maturities of long-term debt and Long-term debt in our Consolidated Balance Sheets.   We do not recognize a right-of-use asset and lease liability for leases with a term of 12 months or less. We do not separate non-lease components from lease components to which they relate and have accounted for the combined lease and non-lease components as a single lease component.

[0001628280-22-010108:notes:38]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

[0001628280-22-010108:notes:39]
In determining our right-of-use assets and lease liabilities, we apply a discount rate to the minimum lease payments within each lease agreement.  ASC 842 requires us to use the rate of interest that a lessee would have to pay to borrow on a collateralized basis over a similar term an amount equal to the lease payments in a similar economic environment.  When we cannot readily determine the discount rate implicit in the lease agreement, we utilize our incremental borrowing rate. To estimate our specific incremental borrowing rates over various tenors (ranging from 1-year through 30-years), a comparable market yield curve consistent with our credit quality was calibrated to our publicly outstanding debt instruments.

[0001628280-22-010108:notes:40]
We lease certain real and personal property under non-cancelable operating leases. Approximately 79% of our right-of-use assets and lease liabilities relate to our leases of real estate with the remaining amounts primarily relating to our leases of IT equipment, fleet vehicles and manufacturing and distribution equipment.

[0001628280-22-010108:notes:41]
Product Warranties and Product Related Contingencies

[0001628280-22-010108:notes:42]
We provide warranties to customers for some of our products and record liabilities for the estimated future warranty-related costs based on failure rates, cost experience and other factors.  We periodically review the assumptions used to determine the product warranty liabilities and will adjust the liabilities in future periods for changes in experience, as necessary.

[0001628280-22-010108:notes:43]
Liabilities for estimated product warranty costs related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001628280-22-010108:notes:44]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 38.5 |  |  | $ | 37.2 |  |
| Other liabilities | 104.7 |  |  | 97.0 |  |
| Total warranty liability | $ | 143.2 |  |  | $ | 134.2 |  |

[0001628280-22-010108:notes:45]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2022 were as follows (in millions):

[0001628280-22-010108:notes:46]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (7.1) |  |
| Changes resulting from issuance of new warranties | 12.7 |  |
| Changes in estimates associated with pre-existing liabilities | 3.5 |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Total warranty liability as of March 31, 2022 | $ | 143.2 |  |

[0001628280-22-010108:notes:47]
Litigation

[0001628280-22-010108:notes:48]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001628280-22-010108:notes:49]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

[0001628280-22-010108:notes:50]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Loss for asbestos-related litigation, net | $ | 1.7 |  |  | $ | 1.1 |  |  |  |  |  |

[0001628280-22-010108:notes:51]
It is management's opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations for a particular period.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-010108:notes:52]
Our Board of Directors has authorized a total of $4.0 billion to repurchase shares of our common stock (collectively referred to as the "Share Repurchase Plans"), including a $1.0 billion share repurchase authorization in July 2021. Under this program, we may repurchase shares from time to time in open market transactions and in privately negotiated transactions based on business, market, applicable legal requirements and other considerations. The repurchase program does not require the repurchase of a specific number of shares and may be terminated at any time. As of March 31, 2022, $646 million was available for repurchase under the Share Repurchase Plans.

[0001628280-22-010108:notes:53]
In February 2022, we entered into a fixed dollar accelerated share repurchase transaction (the "ASR Agreement") with Wells Fargo Bank, to effect an accelerated stock buyback of our common stock.  Under the ASR Agreement, we paid Wells Fargo Bank $200.0 million and Wells Fargo Bank delivered to us 0.6 million shares of common stock representing approximately 87% of the shares expected to be purchased under this ASR Agreement. The ASR was completed in April 2022 and Wells Fargo Bank delivered an additional 0.2 million shares of common stock for a total of 0.8 million shares of common stock repurchased under this ASR Agreement.  We recorded $173.0 million in Treasury Stock and the remaining $27.0 million in Additional Paid-In Capital until the transaction was settled in April 2022.

[0001628280-22-010108:notes:54]
We also repurchased shares for $4.9 million during the three months ended March 31, 2022 from employees who tendered their shares to satisfy minimum tax withholding obligations upon the vesting and exercise of stock-based compensation awards.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-010108:notes:55]
The following table disaggregates our revenue by business segment by geography which provides information as to the major source of revenue. See Note 2 for additional information on our reportable business segments and the products and services sold in each segment.

[0001628280-22-010108:notes:56]
|  | For the Three Months Ended March 31, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 629.7 |  |  | $ | 176.8 |  |  | $ | 91.8 |  |  | $ | 898.3 |  |
| Canada | 52.5 |  |  | 10.4 |  |  | — |  |  | 62.9 |  |
| Other international | — |  |  | 0.5 |  |  | 51.7 |  |  | 52.2 |  |
| Total | $ | 682.2 |  |  | $ | 187.7 |  |  | $ | 143.5 |  |  | $ | 1,013.4 |  |

[0001628280-22-010108:notes:57]
|  | For the Three Months Ended March 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 558.8 |  |  | $ | 182.3 |  |  | $ | 75.6 |  |  | $ | 816.7 |  |
| Canada | 47.5 |  |  | 16.9 |  |  | — |  |  | 64.4 |  |
| Other international | — |  |  | — |  |  | 49.4 |  |  | 49.4 |  |
| Total | $ | 606.3 |  |  | $ | 199.2 |  |  | $ | 125.0 |  |  | $ | 930.5 |  |

[0001628280-22-010108:notes:58]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2022 and 2021, direct sales represented 66% and 67% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001628280-22-010108:notes:59]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in

[0001628280-22-010108:notes:60]
time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2022 and 2021, equipment sales represented 80% and 83% of revenues and the remainder of our revenue was generated from our service business.

[0001628280-22-010108:notes:61]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.

[0001628280-22-010108:notes:62]
[same as prior period, unchanged from 0001628280-21-020422:notes:74]

[0001628280-22-010108:notes:63]
[same as prior period, unchanged from 0001628280-21-020422:notes:75]

[0001628280-22-010108:notes:64]
[same as prior period, unchanged from 0001628280-21-020422:notes:76]

[0001628280-22-010108:notes:65]
[same as prior period, unchanged from 0001628280-21-020422:notes:77]

[0001628280-22-010108:notes:66]
[same as prior period, unchanged from 0001628280-21-020422:notes:78]

[0001628280-22-010108:notes:67]
|  | March 31, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (14.0) |  |  | $ | (10.2) |  |  | $ | (3.8) |  |  | 36.9 | % |
| Contract liabilities - noncurrent | (5.4) |  |  | (5.5) |  |  | 0.1 |  |  | (1.2) | % |
| Total | $ | (19.4) |  |  | $ | (15.7) |  |  | $ | (3.7) |  |  |  |

[0001628280-22-010108:notes:68]
For the three months ended March 31, 2022 and 2021, we recognized revenue of $3.7 million and $1.6 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-22-010108:notes:69]
[same as prior period, unchanged from 0001628280-21-020422:notes:81]

[0001628280-22-010108:notes:70]
[same as prior period, unchanged from 0001628280-21-020422:notes:82]

[0001628280-22-010108:notes:71]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Finished goods | $ | 430.4 |  |  | $ | 310.8 |  |
| Work in process | 10.8 |  |  | 12.4 |  |
| Raw materials and parts | 311.8 |  |  | 262.1 |  |
| Subtotal | 753.0 |  |  | 585.3 |  |
| Excess of current cost over last-in, first-out cost | (74.1) |  |  | (74.4) |  |
| Total inventories, net | $ | 678.9 |  |  | $ | 510.9 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-22-010108:notes:72]
[same as prior period, unchanged from 0001628280-21-020422:notes:84]

[0001628280-22-010108:notes:73]
The changes in the carrying amount of goodwill in 2022, in total and by segment, are summarized in the table below (in millions):

[0001628280-22-010108:notes:74]
|  | Balance at December 31, 2021 |  |  |  | Changes in foreign currency translation rates |  | Balance at March 31, 2022 |
| Residential Heating & Cooling | $ | 26.1 |  |  |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 61.1 |  |  |  |  | — |  |  | 61.1 |  |
| Refrigeration | 99.4 |  |  |  |  | (0.2) |  |  | 99.2 |  |
| Total Goodwill | $ | 186.6 |  |  |  |  | $ | (0.2) |  |  | $ | 186.4 |  |

[0001628280-22-010108:notes:75]
[same as prior period, unchanged from 0001628280-21-020422:notes:87]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-22-010108:notes:76]
[same as prior period, unchanged from 0001628280-21-020422:notes:88]

[0001628280-22-010108:notes:77]
[same as prior period, unchanged from 0001628280-21-020422:notes:89]

[0001628280-22-010108:notes:78]
[same as prior period, unchanged from 0001628280-21-020422:notes:90]

[0001628280-22-010108:notes:79]
[same as prior period, unchanged from 0001628280-21-020422:notes:91]

[0001628280-22-010108:notes:80]
[same as prior period, unchanged from 0001628280-21-020422:notes:92]

[0001628280-22-010108:notes:81]
[same as prior period, unchanged from 0001628280-21-020422:notes:93]

[0001628280-22-010108:notes:82]
We have foreign exchange forward contracts and commodity futures contracts designated as cash flow hedges that are scheduled to mature through August 2023.  Unrealized gains or losses from our cash flow hedges are included in Accumulated other comprehensive loss (“AOCL”) and are expected to be reclassified into earnings within the next 18 months based on the

[0001628280-22-010108:notes:83]
prices of the commodities and foreign currencies at the settlement dates.  We recorded the following amounts in AOCL related to our cash flow hedges (in millions):

[0001628280-22-010108:notes:84]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Unrealized gains on unsettled contracts | $ | (25.5) |  |  | $ | (13.4) |  |
| Income tax expense | 5.8 |  |  | 2.7 |  |
| Gains included in AOCL, net of tax (1) | $ | (19.7) |  |  | $ | (10.7) |  |

[0001628280-22-010108:notes:85]
(1) Assuming commodity prices and foreign currency exchange rates remain constant, we expect to reclassify $19.6 million of derivative gains as of March 31, 2022 into earnings within the next 12 months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-22-010108:notes:86]
[same as prior period, unchanged from 0001628280-21-020422:notes:98]

[0001628280-22-010108:notes:87]
[same as prior period, unchanged from 0001628280-21-020422:notes:99]

[0001628280-22-010108:notes:88]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Stock-based compensation expense (1) | $ | 4.7 |  |  | $ | 8.5 |  |  |  |  |  |

[0001628280-22-010108:notes:89]
[same as prior period, unchanged from 0001628280-21-020422:notes:101]


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001628280-22-010108:notes:90]
[same as prior period, unchanged from 0001628280-21-020422:notes:102]

[0001628280-22-010108:notes:91]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Service cost | $ | 1.1 |  |  | $ | 1.5 |  |  |  |  |  |
| Interest cost | 1.5 |  |  | 1.5 |  |  |  |  |  |
| Expected return on plan assets | (2.3) |  |  | (2.7) |  |  |  |  |  |
| Amortization of prior service cost | — |  |  | 0.1 |  |  |  |  |  |
| Recognized actuarial loss | 1.5 |  |  | 2.1 |  |  |  |  |  |
| Other | (0.1) |  |  | (0.2) |  |  |  |  |  |
| Settlements and curtailments | 0.1 |  |  | 0.7 |  |  |  |  |  |
| Net periodic benefit cost | $ | 1.8 |  |  | $ | 3.0 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-010108:notes:92]
, we had approximately $3.5 million in total gross unrecognized tax benefits. All of this amount, if recognized, would be recorded through the Consolidated Statements of Operations.We are currently in the Bridge program for our U.S. federal income taxes under the Internal Revenue Service's Compliance Assurance Program for 2022 and 2021.  As a result, our returns for those years will not be examined.  However, we are subject to examination by numerous other taxing authorities in the U.S. and in foreign jurisdictions. We are generally no longer subject to U.S. federal, state and local, or non-U.S. income tax examinations by taxing authorities for years prior to 2015.


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-010108:notes:93]
The following table summarizes our outstanding debt obligations and their classification in the accompanying Consolidated Balance Sheets (in millions):

[0001628280-22-010108:notes:94]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 279.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 31.4 |  |  | 29.0 |  |
| Domestic credit facility | 347.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.4) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,599.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,611.3 |  |  | $ | 1,237.8 |  |

[0001628280-22-010108:notes:95]
Short-Term Debt

[0001628280-22-010108:notes:96]
Foreign Obligations

[0001628280-22-010108:notes:97]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2022.

[0001628280-22-010108:notes:98]
Long-Term Debt

[0001628280-22-010108:notes:99]
Asset Securitization Program

[0001628280-22-010108:notes:100]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale. Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.

[0001628280-22-010108:notes:101]
We renewed the ASP in November 2021, extending its term to November 2023 and increasing the maximum securitization amount to a range from $300.0 million to $450.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly. The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001628280-22-010108:notes:102]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 279.4 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (279.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 0.4 |  |  | $ | 85.6 |  |

[0001628280-22-010108:notes:103]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2022 and December 31, 2021 were 1.19% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging

[0001628280-22-010108:notes:104]
between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001628280-22-010108:notes:105]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-010108:notes:106]
Domestic Credit Facility

[0001628280-22-010108:notes:107]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-22-010108:notes:108]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $347.5 million as well as $2.0 million committed to standby letters of credit as of March 31, 2022. Subject to covenant limitations, $400.5 million was available for future borrowings.

[0001628280-22-010108:notes:109]
Our weighted average borrowing rate on the facility was as follows:

[0001628280-22-010108:notes:110]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 1.62 | % |  | 1.38 | % |

[0001628280-22-010108:notes:111]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).

[0001628280-22-010108:notes:112]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Credit Facility could occur if:

[0001628280-22-010108:notes:113]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

[0001628280-22-010108:notes:114]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

[0001628280-22-010108:notes:115]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001628280-22-010108:notes:116]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2022, we believe we were in compliance with all covenant requirements.

[0001628280-22-010108:notes:117]
Senior Unsecured Notes

[0001628280-22-010108:notes:118]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2022, we believe we were in compliance with all covenant requirements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-010108:notes:119]
The following table provides information on items reclassified from AOCL to Net income in the accompanying Consolidated Statements of Operations (in millions):

[0001628280-22-010108:notes:120]
|  |  | For the Three Months Ended March 31, |  |  |  | Affected Line Item(s) in the Consolidated Statements of Operations |
|  |  | 2022 |  | 2021 |  |  |  |  |  |
| (Losses) Gains on Cash Flow Hedges: |  |  |  |  |  |  |  |  |  |  |
| Derivatives contracts |  | $ | 7.5 |  |  | $ | 4.4 |  |  |  |  |  |  | Cost of goods sold; Losses (gains) and other expenses, net |
| Income tax expense |  | (1.7) |  |  | (1.0) |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | 5.8 |  |  | $ | 3.4 |  |  |  |  |  |  |  |
| Defined Benefit Plan items: |  |  |  |  |  |  |  |  |  |  |
| Pension and post-retirement benefit costs |  | $ | (1.3) |  |  | $ | (2.2) |  |  |  |  |  |  | Cost of goods sold; Selling, general and administrative expenses |
| Pension settlements |  | (0.1) |  |  | (0.7) |  |  |  |  |  |  | Pension settlements |
| Income tax benefit |  | 0.2 |  |  | 0.7 |  |  |  |  |  |  | Provision for income taxes |
| Net of tax |  | $ | (1.2) |  |  | $ | (2.2) |  |  |  |  |  |  |  |
| Total reclassifications from AOCL |  | $ | 4.6 |  |  | $ | 1.2 |  |  |  |  |  |  |  |

[0001628280-22-010108:notes:121]
The following table provides information on changes in AOCL, by component (net of tax), for the three months ended March 31, 2022 (in millions):

[0001628280-22-010108:notes:122]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Share of equity method investments other comprehensive income |  | Defined Benefit Pension Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2021 |  | $ | 10.7 |  |  | $ | (1.2) |  |  | $ | (68.8) |  |  | $ | (28.8) |  |  | $ | (88.1) |  |
| Other comprehensive income (loss) before reclassifications |  | 14.8 |  |  | — |  |  | (1.4) |  |  | (1.2) |  |  | 12.2 |  |
| Amounts reclassified from AOCL |  | (5.8) |  |  | — |  |  | 1.2 |  |  | — |  |  | (4.6) |  |
| Net other comprehensive income (loss) |  | 9.0 |  |  | — |  |  | (0.2) |  |  | (1.2) |  |  | 7.6 |  |
| Balance as of March 31, 2022 |  | $ | 19.7 |  |  | $ | (1.2) |  |  | $ | (69.0) |  |  | $ | (30.0) |  |  | $ | (80.5) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-010108:notes:123]
[same as prior period, unchanged from 0001628280-21-020422:notes:131]

[0001628280-22-010108:notes:124]
The methodologies used to determine the fair value of our financial assets and liabilities at March 31, 2022 were the same as those used at December 31, 2021.

[0001628280-22-010108:notes:125]
[same as prior period, unchanged from 0001628280-21-020422:notes:133]

[0001628280-22-010108:notes:126]
[same as prior period, unchanged from 0001628280-21-020422:notes:134]

[0001628280-22-010108:notes:127]
[same as prior period, unchanged from 0001628280-21-020422:notes:135]

[0001628280-22-010108:notes:128]
The carrying amounts of Cash and cash equivalents, Short-term investments, Accounts and notes receivable, net, Accounts payable, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001628280-22-010108:notes:129]
[same as prior period, unchanged from 0001628280-21-020422:notes:137]

[0001628280-22-010108:notes:130]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Senior unsecured notes | $ | 913.9 |  |  | $ | 959.2 |  |
