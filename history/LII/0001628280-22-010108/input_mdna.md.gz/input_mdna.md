# LII MD&A — 0001628280-22-010108


## mdna

[0001628280-22-010108:mdna:1]
[same as prior period, unchanged from 0001628280-21-020422:mdna:1]

[0001628280-22-010108:mdna:2]
[same as prior period, unchanged from 0001628280-21-020422:mdna:2]

[0001628280-22-010108:mdna:3]
[same as prior period, unchanged from 0001628280-21-020422:mdna:3]

[0001628280-22-010108:mdna:4]
[same as prior period, unchanged from 0001628280-21-020422:mdna:4]

[0001628280-22-010108:mdna:5]
[same as prior period, unchanged from 0001628280-21-020422:mdna:5]

[0001628280-22-010108:mdna:6]
[same as prior period, unchanged from 0001628280-21-020422:mdna:6]

[0001628280-22-010108:mdna:7]
[same as prior period, unchanged from 0001628280-21-020422:mdna:7]

[0001628280-22-010108:mdna:8]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

[0001628280-22-010108:mdna:9]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus become more

[0001628280-22-010108:mdna:10]
dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

[0001628280-22-010108:mdna:11]
Executive Leadership Transition

[0001628280-22-010108:mdna:12]
On March 23, 2022, the Board of Directors appointed Alok Maskara as CEO effective May 9, 2022.  Mr. Maskara succeeds Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and will serve as interim CEO until Mr. Maskara assumes the role as CEO.

[0001628280-22-010108:mdna:13]
[same as prior period, unchanged from 0001628280-21-020422:mdna:11]

[0001628280-22-010108:mdna:14]
Results for the first quarter of 2022 were driven by overall year over year sales increases while operating income decreased.  Net sales increased 13% and segment profit increased $11 million for the Residential Heating & Cooling segment. Net sales decreased 6% and segment profit decreased $21 million for the Commercial Heating & Cooling segment. Net sales increased 15% and segment profit increased $6 million for the Refrigeration segment.

[0001628280-22-010108:mdna:15]
[same as prior period, unchanged from 0001628280-21-020422:mdna:13]

[0001628280-22-010108:mdna:16]
•Net sales increased $83 million to $1,013 million in the first quarter of 2022 driven by favorable price and mix partially offset by lower sales volume.

[0001628280-22-010108:mdna:17]
•Operating income in the first quarter of 2022 decreased $2 million to $112 million primarily driven by rising costs partially offset by higher net sales.

[0001628280-22-010108:mdna:18]
•Net income for the first quarter of 2022 was $84 million.

[0001628280-22-010108:mdna:19]
•Diluted earnings per share was $2.29 per share in the first quarter of 2022 compared to $2.20 per share in the first quarter of 2021.

[0001628280-22-010108:mdna:20]
•For the three months ended March 31, 2022, we returned $34 million to shareholders through dividend payments and repurchased $200 million of common stock through our share repurchase program.

[0001628280-22-010108:mdna:21]
Three Months Ended March 31, 2022 Compared to Three Months Ended March 31, 2021 - Consolidated Results

[0001628280-22-010108:mdna:22]
[same as prior period, unchanged from 0001628280-21-020422:mdna:20]

[0001628280-22-010108:mdna:23]
|  | For the Three Months Ended March 31, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales | $ | 1,013.4 |  |  | $ | 930.5 |  |  | 8.9 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 745.2 |  |  | 674.0 |  |  | (10.6) |  |  | 73.5 |  |  | 72.4 |  |
| Gross profit | 268.2 |  |  | 256.5 |  |  | 4.6 |  |  | 26.5 |  |  | 27.6 |  |
| Selling, general and administrative expenses | 155.3 |  |  | 145.3 |  |  | (6.9) |  |  | 15.3 |  |  | 15.6 |  |
| Losses (gains) and other expenses, net | 0.4 |  |  | 0.3 |  |  | (33.3) |  |  | — |  |  | — |  |
| Restructuring charges | 0.5 |  |  | 0.1 |  |  | (400.0) |  |  | — |  |  | — |  |
| Income from equity method investments | 0.1 |  |  | (3.3) |  |  | (103.0) |  |  | — |  |  | (0.4) |  |
| Operating income | $ | 111.9 |  |  | $ | 114.1 |  |  | (1.9) | % |  | 11.0 | % |  | 12.3 | % |

[0001628280-22-010108:mdna:24]
[same as prior period, unchanged from 0001628280-21-020422:mdna:22]

[0001628280-22-010108:mdna:25]
Net sales for the first quarter of 2022 compared to the first quarter of 2021 were impacted by favorable price of 9% and favorable mix of 2%, which was partially offset by lower sales volume of 2%.

[0001628280-22-010108:mdna:26]
[same as prior period, unchanged from 0001628280-21-020422:mdna:24]

[0001628280-22-010108:mdna:27]
Gross profit margins in the first quarter of 2022 decreased 110 basis points ("bps") to 26.5% compared to 27.6% in the first quarter of 2021. Gross margin decreased 300 bps from higher commodity costs, 190 bps from higher component costs, 120 bps from higher freight and distribution costs, 100 bps from factory inefficiencies, and 30 bps from increased warranty costs.  Partially offsetting these decreases were 600 bps from favorable price, 20 bps from favorable mix, and 10 bps from lower tariff

[0001628280-22-010108:mdna:28]
costs.

[0001628280-22-010108:mdna:29]
[same as prior period, unchanged from 0001628280-21-020422:mdna:26]

[0001628280-22-010108:mdna:30]
Selling, general and administrative expenses ("SG&A") increased $10 million to $155 million in the first quarter of 2022 compared to $145 million in the first quarter of 2021 due to higher employee costs. As a percentage of net sales, SG&A decreased 30 bps to 15.3%.

[0001628280-22-010108:mdna:31]
[same as prior period, unchanged from 0001628280-21-020422:mdna:28]

[0001628280-22-010108:mdna:32]
Losses (gains) losses and other expenses, net for the first quarter of 2022 and 2021 included the following (in millions):

[0001628280-22-010108:mdna:33]
|  | For the Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |  |  |
| Realized (gains) losses on settled futures contracts | $ | (0.3) |  |  | $ | (0.3) |  |  |  |  |  |  |  |
| Foreign currency exchange gains | (0.3) |  |  | (0.3) |  |  |  |  |  |  |  |
| Gain on disposal of fixed assets | (0.9) |  |  | (0.3) |  |  |  |  |  |  |  |
| Other operating income | (0.3) |  |  | (0.3) |  |  |  |  |  |  |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | (0.7) |  |  | (0.2) |  |  |  |  |  |  |  |
| Special legal contingency charges | 0.3 |  |  | 0.2 |  |  |  |  |  |  |  |
| Asbestos-related litigation | 1.7 |  |  | 1.1 |  |  |  |  |  |  |  |
| Environmental liabilities | 0.1 |  |  | 0.6 |  |  |  |  |  |  |  |
| Charges incurred related to COVID-19 pandemic | 0.3 |  |  | 0.6 |  |  |  |  |  |  |  |
| Other items, net | 0.5 |  |  | (0.8) |  |  |  |  |  |  |  |
| Losses (gains) and other expenses, net (pre-tax) | $ | 0.4 |  |  | $ | 0.3 |  |  |  |  |  |  |  |

[0001628280-22-010108:mdna:34]
The net change in unrealized (gains) losses on unsettled futures contracts was due to changes in commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 7 in the Notes to the Consolidated Financial Statements.  For more information on asbestos-related litigation, see Note 4 in the Notes to the Consolidated Financial Statements. The environmental liabilities related to estimated remediation costs for contamination at some of our facilities.

[0001628280-22-010108:mdna:35]
[same as prior period, unchanged from 0001628280-21-020422:mdna:32]

[0001628280-22-010108:mdna:36]
Restructuring charges were immaterial in the first quarter of 2022 and 2021.  Restructuring charges related to ongoing cost reduction actions taken in prior periods.

[0001628280-22-010108:mdna:37]
Loss (Income) from Equity Method Investments

[0001628280-22-010108:mdna:38]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownership, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  We incurred a loss from equity method investments of $0.1 million in the first quarter of 2022 and generated income of $3.3 million in the first quarter of 2021.  The change was due to rising costs at our equity method investments.

[0001628280-22-010108:mdna:39]
[same as prior period, unchanged from 0001628280-21-020422:mdna:38]

[0001628280-22-010108:mdna:40]
Interest expense, net increased to $7 million in the first quarter of 2022 from $6 million in the first quarter of 2021 due to higher borrowings during the period.

[0001628280-22-010108:mdna:41]
[same as prior period, unchanged from 0001628280-21-020422:mdna:40]

[0001628280-22-010108:mdna:42]
Our effective tax rate was 19.9% for the first quarter of 2022 compared to 20.9% for the first quarter of 2021. The rate decreased primarily due a favorable mix of income in lower tax jurisdictions.

[0001628280-22-010108:mdna:43]
We expect our annual effective tax rate in 2022 to be 18-20%, excluding the impact of excess tax benefits recorded under ASU No. 2016-09.

[0001628280-22-010108:mdna:44]
First Quarter of 2022 Compared to First Quarter of 2021 - Results by Segment

[0001628280-22-010108:mdna:45]
[same as prior period, unchanged from 0001628280-21-020422:mdna:44]

[0001628280-22-010108:mdna:46]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-010108:mdna:47]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 682.2 |  |  | $ | 606.3 |  |  | $ | 75.9 |  |  | 12.5 | % |
| Profit | $ | 107.6 |  |  | $ | 96.4 |  |  | $ | 11.2 |  |  | 11.6 | % |
| % of net sales | 15.8 | % |  | 15.9 | % |  |  |  |  |

[0001628280-22-010108:mdna:48]
Net sales increased 13% in the first quarter of 2022 compared to 2021, as price increased 11% and product mix increased 2%.  Sales volume was flat during the period.

[0001628280-22-010108:mdna:49]
Segment profit in the first quarter of 2022 compared to 2021 increased $11 million due to $68 million from higher price and $3 million from favorable product mix.  Partially offsetting these increases were $22 million from higher commodity costs, $10 million from higher SG&A, $9 million from higher component costs, $8 million from unfavorable freight and distribution costs, $4 million from higher warranty costs, $4 million from factory inefficiencies, and $3 million from lower income from equity method investments.

[0001628280-22-010108:mdna:50]
[same as prior period, unchanged from 0001628280-21-020422:mdna:49]

[0001628280-22-010108:mdna:51]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-010108:mdna:52]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 187.7 |  |  | $ | 199.2 |  |  | $ | (11.5) |  |  | (5.8) | % |
| Profit | $ | 6.3 |  |  | $ | 27.4 |  |  | $ | (21.1) |  |  | (77.0) | % |
| % of net sales | 3.4 | % |  | 13.8 | % |  |  |  |  |

[0001628280-22-010108:mdna:53]
Net sales decreased 6% in the first quarter of 2022 compared to the first quarter of 2021.  Sales volume was 16% lower, which was partially offset by increased price of 7% and favorable mix of 3%.

[0001628280-22-010108:mdna:54]
Segment profit in the first quarter of 2022 compared to 2021 decreased $21 million due to $10 million from lower sales volume, $8 million from higher component costs, $6 million from higher factory inefficiencies, $2 million for higher SG&A, $3 million from higher freight and distribution costs, $2 million for higher other product costs, and $2 million from higher commodity costs.  Partially offsetting these decreases were $6 million from improved product mix and $6 million from improved price.

[0001628280-22-010108:mdna:55]
[same as prior period, unchanged from 0001628280-21-020422:mdna:54]

[0001628280-22-010108:mdna:56]
The following table presents our Refrigeration segment's net sales and profit for the first quarter of 2022 and 2021 (dollars in millions):

[0001628280-22-010108:mdna:57]
|  | For the Three Months Ended March 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | Difference |  | % Change |
| Net sales | $ | 143.5 |  |  | $ | 125.0 |  |  | $ | 18.5 |  |  | 14.8 | % |
| Profit | $ | 14.1 |  |  | $ | 7.9 |  |  | $ | 6.2 |  |  | 78.5 | % |
| % of net sales | 9.8 | % |  | 6.3 | % |  |  |  |  |

[0001628280-22-010108:mdna:58]
Net sales increased 15% in the first quarter of 2022 compared to the first quarter of 2021. Sales volume was 11% higher and price increased 8%.  Partially offsetting these increases were 3% from unfavorable foreign currency and 1% from unfavorable mix.

[0001628280-22-010108:mdna:59]
Segment profit in the first quarter of 2022 compared to 2021 increased $6 million compared to 2021 due to $11 million from improved price, $5 million from higher sales volume, $1 million from lower other product costs, and $1 million from lower tariffs, which was partially offset by $5 million from higher commodity costs, $3 million from higher component costs, $3 million from higher SG&A, and $1 million from unfavorable mix.

[0001628280-22-010108:mdna:60]
[same as prior period, unchanged from 0001628280-21-020422:mdna:59]

[0001628280-22-010108:mdna:61]
Corporate and other expenses decreased $3 million in the first quarter of 2022 compared to 2021 primarily due to the timing of variable incentive compensation costs.

[0001628280-22-010108:mdna:62]
[same as prior period, unchanged from 0001628280-21-020422:mdna:103]

[0001628280-22-010108:mdna:63]
[same as prior period, unchanged from 0001628280-21-020422:mdna:104]

[0001628280-22-010108:mdna:64]
[same as prior period, unchanged from 0001628280-21-020422:mdna:105]

[0001628280-22-010108:mdna:65]
The following table summarizes our cash flow activity for the three months ended March 31, 2022 and 2021 (in millions):

[0001628280-22-010108:mdna:66]
|  | For the Three Months Ended March 31, |
|  | 2022 |  | 2021 |
| Net cash used in operating activities | $ | (97.9) |  |  | $ | (17.5) |  |
| Net cash used in investing activities | (25.7) |  |  | (23.8) |  |
| Net cash provided by (used in) financing activities | 129.1 |  |  | (45.5) |  |

[0001628280-22-010108:mdna:67]
Net Cash Used In Operating Activities -  The change in net cash used in operating activities for the three months ended March 31, 2022 compared to the same period in 2021 reflects less favorable changes in working capital.

[0001628280-22-010108:mdna:68]
Net Cash Used in Investing Activities - Capital expenditures were $26 million for the three months ended March 31, 2022 compared to $25 million in the same period of 2021.  Capital expenditures in 2022 were primarily related to the expansion of manufacturing capacity and equipment, and investments in systems and software to support the overall enterprise.

[0001628280-22-010108:mdna:69]
Net Cash Provided by (Used in) Financing Activities - Net cash provided by financing activities for the three months ended March 31, 2022 increased to $129 million compared to $46 million used in financing activity in the same period of 2021.  The change was primarily due to increased net borrowings in the current year compared to the prior year.  We repurchased $200 million of shares for the three months ended March 31, 2022 and returned $34 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 5 in the Notes to the Consolidated Financial Statements.

[0001628280-22-010108:mdna:70]
[same as prior period, unchanged from 0001628280-21-020422:mdna:112]

[0001628280-22-010108:mdna:71]
The following table details our lines of credit and financing arrangements as of March 31, 2022 (in millions):

[0001628280-22-010108:mdna:72]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Total current maturities of long-term debt | $ | 11.8 |  |
| Long-term debt: |  |
| Asset Securitization Program (2) | 279.0 |  |
| Finance lease obligations | 31.4 |  |
| Domestic credit facility (1) | 347.5 |  |
| Senior unsecured notes | 950.0 |  |
| Debt issuance costs | (8.4) |  |
| Total long-term debt | 1,599.5 |  |
| Total debt | $ | 1,611.3 |  |

[0001628280-22-010108:mdna:73]
(1)   The available future borrowings on our domestic credit facility are $400.5 million, after being reduced by the outstanding borrowings and $2.0 million in outstanding standby letters of credit.  Refer to Note 10 in the Notes to the Consolidated Financial Statements related to the terms of the Domestic Credit Facility.

[0001628280-22-010108:mdna:74]
(2)    The maximum securitization amount ranges from $300.0 million to $450.0 million, depending on the period.  The maximum capacity of the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information.

[0001628280-22-010108:mdna:75]
[same as prior period, unchanged from 0001628280-21-020422:mdna:117]

[0001628280-22-010108:mdna:76]
In July 2021, we entered into the Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.

[0001628280-22-010108:mdna:77]
[same as prior period, unchanged from 0001628280-21-020422:mdna:119]

[0001628280-22-010108:mdna:78]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.

[0001628280-22-010108:mdna:79]
[same as prior period, unchanged from 0001628280-21-020422:mdna:121]

[0001628280-22-010108:mdna:80]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 134% at March 31, 2022 from 128% at December 31, 2021.

[0001628280-22-010108:mdna:81]
As of March 31, 2022, our senior credit ratings were Baa2 with a stable outlook, and BBB with a stable outlook, by Moody's Investors Service, Inc. ("Moody's") and Standard & Poor's Rating Group ("S&P"), respectively.  The security ratings are not a

[0001628280-22-010108:mdna:82]
recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody's and S&P to help ensure the capital markets remain available to us.

[0001628280-22-010108:mdna:83]
[same as prior period, unchanged from 0001628280-21-020422:mdna:125]

[0001628280-22-010108:mdna:84]
We believe our cash and cash equivalents of $34 million, future cash generated from operations and available borrowing capacity are sufficient to fund operations, planned capital expenditures, future contractual obligations, potential share repurchases and dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $34 million as of March 31, 2022 was $15 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001628280-22-010108:mdna:85]
[same as prior period, unchanged from 0001628280-21-020422:mdna:127]

[0001628280-22-010108:mdna:86]
[same as prior period, unchanged from 0001628280-21-020422:mdna:128]

[0001628280-22-010108:mdna:87]
[same as prior period, unchanged from 0001628280-21-020422:mdna:129]

[0001628280-22-010108:mdna:88]
[same as prior period, unchanged from 0001628280-21-020422:mdna:130]

[0001628280-22-010108:mdna:89]
[same as prior period, unchanged from 0001628280-21-020422:mdna:131]

[0001628280-22-010108:mdna:90]
Commitments, Contingencies and Guarantees

[0001628280-22-010108:mdna:91]
For information regarding our commitments, contingencies and guarantees, see Note 4 in the Notes to the Consolidated Financial Statements.

[0001628280-22-010108:mdna:92]
[same as prior period, unchanged from 0001628280-21-020422:mdna:134]

[0001628280-22-010108:mdna:93]
There were no recent accounting pronouncements that are expected to have a material impact on our financial statements and disclosures.
