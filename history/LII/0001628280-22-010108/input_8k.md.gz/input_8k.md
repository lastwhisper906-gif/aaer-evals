# LII 8-K — 0001193125-22-116340 filed 2022-04-25

## item codes, every 8-K on or before 2022-04-25

- 2022-04-25 0001193125-22-116340 — 2.02, 9.01
- 2022-03-23 0001193125-22-082198 — 5.02, 7.01, 9.01
- 2022-02-01 0001193125-22-024009 — 2.02, 9.01
- 2021-12-14 0001193125-21-356791 — 5.02, 9.01
- 2021-11-17 0001193125-21-332601 — 1.01, 2.03, 9.01
- 2021-10-25 0001193125-21-306031 — 2.02, 9.01
- 2021-07-26 0001069202-21-000026 — 2.02, 9.01
- 2021-07-15 0001193125-21-216428 — 1.01, 1.02, 2.03, 9.01
- 2021-07-14 0001193125-21-214688 — 5.02, 7.01, 9.01
- 2021-05-24 0001069202-21-000020 — 5.02, 5.07, 9.01
- 2021-04-26 0001069202-21-000016 — 2.02, 9.01
- 2021-02-02 0001069202-21-000004 — 2.02, 9.01
- 2020-10-19 0001069202-20-000042 — 2.02, 9.01
- 2020-07-30 0001193125-20-203588 — 1.01, 2.03, 8.01, 9.01
- 2020-07-20 0001069202-20-000037 — 2.02, 9.01
- 2020-07-16 0001069202-20-000032 — 5.02, 9.01
- 2020-05-27 0001069202-20-000026 — 5.07, 9.01
- 2020-05-05 0001069202-20-000021 — 8.01
- 2020-04-20 0001069202-20-000013 — 2.02, 9.01
- 2020-02-04 0001069202-20-000002 — 2.02, 9.01
- 2019-11-19 0001193125-19-295555 — 1.01, 2.03, 9.01
- 2019-10-21 0001069202-19-000034 — 2.02, 9.01
- 2019-07-22 0001069202-19-000027 — 2.02, 9.01
- 2019-07-15 0001069202-19-000023 — 5.02, 9.01
- 2019-05-24 0001193125-19-157041 — 5.02, 5.07, 9.01
- 2019-04-22 0001069202-19-000018 — 2.02, 9.01
- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2022-04-25

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-116340:8k_2_02:1]
EX-99.1
2
d342199dex991.htm
EX-99.1

[0001193125-22-116340:8k_2_02:2]
EX-99.1

[0001193125-22-116340:8k_2_02:3]
Exhibit 99.1

[0001193125-22-116340:8k_2_02:4]
Lennox International Reports Record First Quarter Revenue and Earnings Per Share

[0001193125-22-116340:8k_2_02:5]
| • |  | Revenue up 9% to first-quarter record $1.01 billion |

[0001193125-22-116340:8k_2_02:6]
| • |  | GAAP EPS up 4% to first-quarter record $2.29 |

[0001193125-22-116340:8k_2_02:7]
| • |  | Adjusted EPS up 4% to first-quarter record $2.36 |

[0001193125-22-116340:8k_2_02:8]
| • |  | Repurchased $200 million of stock in the quarter |

[0001193125-22-116340:8k_2_02:9]
| • |  | Raising 2022 guidance for revenue growth from 5-10% to 7-11% |

[0001193125-22-116340:8k_2_02:10]
| • |  | Reiterating 2022 guidance for GAAP and adjusted EPS of $13.50-$14.50 |

[0001193125-22-116340:8k_2_02:11]
| • |  | Reiterating guidance for $400 million of stock repurchases for the full year |

[0001193125-22-116340:8k_2_02:12]
DALLAS, April 25, 2022 – Lennox International Inc. (NYSE: LII), a global leader in energy-efficient climate-control solutions, today reported
financial results for the first quarter of 2022. All comparisons are to the prior-year period.

[0001193125-22-116340:8k_2_02:13]
Lennox International reported record first-quarter revenue
of $1.01 billion, up 9%. GAAP operating income was $112 million, down 2%. GAAP earnings per share was a first-quarter record $2.29, up 4%.

[0001193125-22-116340:8k_2_02:14]
Total segment profit was $115 million, down 1%, and total segment margin was 11.3%, down 110 basis points. Adjusted earnings per share was a
first-quarter record $2.36, up 4%.

[0001193125-22-116340:8k_2_02:15]
“Lennox International posted record first-quarter revenue and EPS, led by strong growth in our Residential and
Refrigeration businesses,” said Chairman and Interim CEO Todd Teske. “Both Residential and Refrigeration set new first-quarter highs for revenue and profit. In Residential, revenue was up 13%, led by double-digit growth in both replacement
and new construction business. Segment profit rose 12% as segment margin was down slightly to 15.8%. In Refrigeration, revenue was up 15% as reported and up 18% at constant currency, led by more than 20% growth in North America. Refrigeration profit
rose 78% as segment margin expanded 350 basis points to 9.8%.

[0001193125-22-116340:8k_2_02:16]
“In Commercial, demand remained strong, but the business continued to be hit the
hardest on the production front with labor constraints and global supply chain disruptions. Commercial revenue was down 6% and profit was down 77% in the first quarter as segment margin contracted 1,040 basis points to 3.4%. The Commercial team
continues to take aggressive actions to resolve tight labor market, supply chain and production challenges, and we are seeing signs of improvement from these initiatives.

[0001193125-22-116340:8k_2_02:17]
“Looking ahead for the company overall, demand remains strong, and we have announced a second round of price increases for 2022 to continue to offset
broad inflationary pressures. We are raising 2022 revenue growth guidance from 5-10% to 7-11% and reiterating EPS guidance of $13.50-$14.50. We repurchased
$200 million of stock in the first quarter and are reiterating plans for $400 million of stock repurchases for the full year.”

[0001193125-22-116340:8k_2_02:18]
FINANCIAL HIGHLIGHTS

[0001193125-22-116340:8k_2_02:19]
Revenue: Revenue was a first-quarter record $1.01 billion, up 9%. Volume was down, and price and mix were up. Foreign exchange was neutral to
revenue.

[0001193125-22-116340:8k_2_02:20]
Gross Profit: Gross profit was $268 million, up 5%. Gross margin was 26.5%, down 110 basis points. Gross profit was positively
impacted by price and mix. Partial offsets included lower volume due to global supply chain disruptions and labor constraints, factory inefficiencies, and higher material, freight, distribution, and warranty costs.

[0001193125-22-116340:8k_2_02:21]
Net Income: On a GAAP basis, net income for the first quarter was $83.6 million, or $2.29 per share, compared to $84.2 million, or $2.20 per
share, in the prior-year quarter.

[0001193125-22-116340:8k_2_02:22]
Adjusted net income in the first quarter was $86.1 million, or $2.36 per share, compared to $86.9 million, or
$2.27 per share, in the prior-year quarter. Adjusted net income for the first quarter of 2022 excludes after-tax charges of $2.5 million, consisting of: a net charge of $1.5 million for items
excluded from segment profit, $0.5 million for excess tax expense from share-based compensation, and a total of $0.5 million for restructuring charges and pension settlements.

[0001193125-22-116340:8k_2_02:23]
Cash from Operations, Free Cash Flow and Total Debt: Net cash used in operations in the first quarter was $98 million compared to $18 million
in the prior-year quarter. Capital expenditures were approximately $25 million in the first quarter compared to $24 million in the prior-year quarter. Free cash flow was ($123) million compared to ($42) million in the first quarter a year
ago. Total debt at the end of the first quarter was $1.61 billion. Total cash, cash equivalents and short-term investments were $40 million at the end of the quarter. The company paid approximately $34 million in dividends in the
first quarter and repurchased $200 million of stock.

[0001193125-22-116340:8k_2_02:24]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-22-116340:8k_2_02:25]
Residential Heating & Cooling

[0001193125-22-116340:8k_2_02:26]
Revenue in the
Residential Heating & Cooling business segment was a first-quarter record $682 million, up 13%. Foreign exchange was neutral to revenue. Segment profit was a first-quarter record $108 million, up 12%. Segment margin was 15.8%,
down 10 basis points. Residential results were primarily impacted by favorable price and mix. Partial offsets included higher material, freight, and warranty costs, global supply chain disruptions and factory inefficiencies, lower joint venture
income, distribution investments, and higher SG&A.

[0001193125-22-116340:8k_2_02:27]
Commercial Heating & Cooling

[0001193125-22-116340:8k_2_02:28]
Revenue in the Commercial Heating & Cooling business segment was $188 million, down 6%. Foreign exchange was neutral to revenue. Segment profit
was $6 million, down 77%, and segment margin was 3.4%, down 1,040 basis points. Commercial results were primarily impacted by lower volume and factory inefficiencies due to labor constraints and global supply chain disruptions, higher material,
freight, distribution, and other product costs, and higher SG&A. Partial offsets included favorable price and mix.

[0001193125-22-116340:8k_2_02:29]
Refrigeration

[0001193125-22-116340:8k_2_02:30]
Revenue in the Refrigeration business segment was up 15% to $144 million. Foreign exchange had a 3% negative impact to revenue growth. Segment profit rose
78% to $14 million. Segment revenue and profit were both first-quarter records, adjusted for historical divestitures. Segment margin expanded 350 basis points to 9.8%. Refrigeration results were primarily impacted by higher volume and favorable
price and tariffs. Partial offsets included unfavorable mix, global supply chain disruptions, and higher material, freight and SG&A costs.

[0001193125-22-116340:8k_2_02:31]
FULL-YEAR GUIDANCE

[0001193125-22-116340:8k_2_02:32]
For 2022, the company is raising
revenue growth guidance and reiterating EPS guidance.

[0001193125-22-116340:8k_2_02:33]
| • |  | Raising guidance for revenue growth from 5-10 to 7-11%; neutral foreign exchange. |

[0001193125-22-116340:8k_2_02:34]
| • |  | Reiterating GAAP and adjusted EPS guidance of $13.50-$14.50. |

[0001193125-22-116340:8k_2_02:35]
| • |  | Reiterating corporate expense guidance of approximately $95 million. |

[0001193125-22-116340:8k_2_02:36]
| • |  | Reiterating effective tax rate guidance of 18-20% on an adjusted basis for the full year. |

[0001193125-22-116340:8k_2_02:37]
| • |  | Reiterating capital expenditures guidance of approximately $125 million. |

[0001193125-22-116340:8k_2_02:38]
| • |  | Reiterating free cash flow guidance of approximately $400 million. |

[0001193125-22-116340:8k_2_02:39]
| • |  | Reiterating stock repurchase guidance of $400 million for the full year. |

[0001193125-22-116340:8k_2_02:40]
CONFERENCE CALL INFORMATION

[0001193125-22-116340:8k_2_02:41]
A conference call to discuss the company’s first-quarter results and outlook will be held this morning at 8:30 a.m. Central time. To listen, call the
conference call line at 844-291-6356 (U.S.) or 234-720-6989 (international) at least 10
minutes prior to the scheduled start time and use participant code 5188402. The conference call also will be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay will be available from approximately 11:00 a.m.
Central time on April 25 through May 9, 2022 by dialing 866-207-1041 (U.S.) or
402-970-0847 (international) and using access code 1972402. The call also will be archived on the company’s website.

[0001193125-22-116340:8k_2_02:42]
ABOUT LENNOX INTERNATIONAL

[0001193125-22-116340:8k_2_02:43]
Lennox International Inc. is
a global leader in energy-efficient climate-control solutions. Dedicated to sustainability and creating comfortable and healthier environments for our residential and commercial customers while reducing their carbon footprint, we lead the field in
innovation with our air conditioning, heating, indoor air quality, and refrigeration systems. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol LII. Additional information on Lennox International is
available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-22-116340:8k_2_02:44]
FORWARD-LOOKING STATEMENTS

[0001193125-22-116340:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-116340:8k_2_02:46]
Consolidated Statements of Operations

[0001193125-22-116340:8k_2_02:47]
(Unaudited)

[0001193125-22-116340:8k_2_02:48]
| (Amounts in millions, except per share data) |  | For the Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,013.4 |  |  | $ | 930.5 |  |
| Cost of goods sold |  |  | 745.2 |  |  |  | 674.0 |  |
| Gross profit |  |  | 268.2 |  |  |  | 256.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 155.3 |  |  |  | 145.3 |  |
| Losses (gains) and other expenses, net |  |  | 0.4 |  |  |  | 0.3 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 0.1 |  |
| Loss (income) from equity method investments |  |  | 0.1 |  |  |  | (3.3 | ) |
| Operating income |  |  | 111.9 |  |  |  | 114.1 |  |
| Pension settlements |  |  | 0.1 |  |  |  | 0.7 |  |
| Interest expense, net |  |  | 6.8 |  |  |  | 6.0 |  |
| Other expense (income), net |  |  | 0.6 |  |  |  | 1.0 |  |
| Net income before income taxes |  |  | 104.4 |  |  |  | 106.4 |  |
| Provision for income taxes |  |  | 20.8 |  |  |  | 22.2 |  |
| Net income |  | $ | 83.6 |  |  | $ | 84.2 |  |
| Earnings per share – Basic: |  | $ | 2.30 |  |  | $ | 2.22 |  |
| Earnings per share – Diluted: |  | $ | 2.29 |  |  | $ | 2.20 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 36.3 |  |  |  | 38.0 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 36.5 |  |  |  | 38.2 |  |

[0001193125-22-116340:8k_2_02:49]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-116340:8k_2_02:50]
Segment Net Sales and Profit (Loss)

[0001193125-22-116340:8k_2_02:51]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | (Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 682.2 |  |  | $ | 606.3 |  |
| Commercial Heating & Cooling |  |  | 187.7 |  |  |  | 199.2 |  |
| Refrigeration |  |  | 143.5 |  |  |  | 125.0 |  |
|  |  | $ | 1,013.4 |  |  | $ | 930.5 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 107.6 |  |  | $ | 96.4 |  |
| Commercial Heating & Cooling |  |  | 6.3 |  |  |  | 27.4 |  |
| Refrigeration |  |  | 14.1 |  |  |  | 7.9 |  |
| Corporate and other |  |  | (13.4 | ) |  |  | (16.0 | ) |
| Total segment profit |  |  | 114.6 |  |  |  | 115.7 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (1) |  |  | 2.2 |  |  |  | 1.5 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | 0.1 |  |
| Operating income |  | $ | 111.9 |  |  | $ | 114.1 |  |

[0001193125-22-116340:8k_2_02:52]
| (1) | We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-22-116340:8k_2_02:53]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-22-116340:8k_2_02:54]
|  | • |  | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001193125-22-116340:8k_2_02:55]
|  | • |  | Special legal contingency charges, |

[0001193125-22-116340:8k_2_02:56]
|  | • |  | Asbestos-related litigation, |

[0001193125-22-116340:8k_2_02:57]
|  | • |  | Environmental liabilities, |

[0001193125-22-116340:8k_2_02:58]
|  | • |  | Charges incurred related to COVID-19 pandemic; |

[0001193125-22-116340:8k_2_02:59]
|  | • |  | Other items, net, |

[0001193125-22-116340:8k_2_02:60]
|  | • |  | Special product quality adjustments; and |

[0001193125-22-116340:8k_2_02:61]
|  | • |  | Restructuring charges. |

[0001193125-22-116340:8k_2_02:62]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-116340:8k_2_02:63]
Consolidated Balance Sheets

[0001193125-22-116340:8k_2_02:64]
| (Amounts in millions, except shares and par values) |  | As of March 31, |  |  | As of December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | (Unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 34.3 |  |  | $ | 31.0 |  |
| Short-term investments |  |  | 5.7 |  |  |  | 5.5 |  |
| Accounts and notes receivable, net of allowances of $11.7 and $10.7 in 2022 and 2021, respectively |  |  | 603.0 |  |  |  | 508.3 |  |
| Inventories, net |  |  | 678.9 |  |  |  | 510.9 |  |
| Other assets |  |  | 115.3 |  |  |  | 119.7 |  |
| Total current assets |  |  | 1,437.2 |  |  |  | 1,175.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $902.2 and $888.8 in 2022 and 2021, respectively |  |  | 518.3 |  |  |  | 515.1 |  |
| Right-of-use assets from operating leases |  |  | 212.1 |  |  |  | 196.1 |  |
| Goodwill |  |  | 186.4 |  |  |  | 186.6 |  |
| Deferred income taxes |  |  | 13.3 |  |  |  | 11.3 |  |
| Other assets, net |  |  | 89.6 |  |  |  | 87.4 |  |
| Total assets |  | $ | 2,456.9 |  |  | $ | 2,171.9 |  |
| LIABILITIES AND STOCKHOLDERS’ DEFICIT |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 11.8 |  |  | $ | 11.3 |  |
| Current operating lease liabilities |  |  | 58.8 |  |  |  | 54.8 |  |
| Accounts payable |  |  | 457.3 |  |  |  | 402.1 |  |
| Accrued expenses |  |  | 325.1 |  |  |  | 358.9 |  |
| Income taxes payable |  |  | 6.4 |  |  |  | — |  |
| Total current liabilities |  |  | 859.4 |  |  |  | 827.1 |  |
| Long-term debt |  |  | 1,599.5 |  |  |  | 1,226.5 |  |
| Long-term operating lease liabilities |  |  | 157.4 |  |  |  | 145.0 |  |
| Pensions |  |  | 84.3 |  |  |  | 83.3 |  |
| Other liabilities |  |  | 166.5 |  |  |  | 159.0 |  |
| Total liabilities |  |  | 2,867.1 |  |  |  | 2,440.9 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ deficit: |  |  |  |  |  |  |  |  |
| Preferred stock, $0.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $0.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 1,110.4 |  |  |  | 1,133.7 |  |
| Retained earnings |  |  | 2,769.8 |  |  |  | 2,719.3 |  |
| Accumulated other comprehensive loss |  |  | (80.5 | ) |  |  | (88.1 | ) |
| Treasury stock, at cost, 51,127,988 shares and 50,536,125 shares for 2022 and 2021, respectively |  |  | (4,210.8 | ) |  |  | (4,034.8 | ) |
| Total stockholders’ deficit |  |  | (410.2 | ) |  |  | (269.0 | ) |
| Total liabilities and stockholders’ deficit |  | $ | 2,456.9 |  |  | $ | 2,171.9 |  |

[0001193125-22-116340:8k_2_02:65]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-116340:8k_2_02:66]
Consolidated Statements of Cash Flows

[0001193125-22-116340:8k_2_02:67]
(Unaudited)

[0001193125-22-116340:8k_2_02:68]
| (Amounts in millions) |  | For the Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 83.6 |  |  | $ | 84.2 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Loss (income) from equity method investments |  |  | 0.1 |  |  |  | (3.3 | ) |
| Restructuring charges, net of cash paid |  |  | 0.5 |  |  |  | 0.3 |  |
| Provision for credit losses |  |  | 1.4 |  |  |  | 2.0 |  |
| Unrealized losses (gains) on derivative contracts |  |  | 0.1 |  |  |  | (0.2 | ) |
| Stock-based compensation expense |  |  | 4.7 |  |  |  | 8.5 |  |
| Depreciation and amortization |  |  | 18.8 |  |  |  | 17.4 |  |
| Deferred income taxes |  |  | (5.3 | ) |  |  | 1.0 |  |
| Pension expense |  |  | 1.4 |  |  |  | 3.0 |  |
| Pension contributions |  |  | (0.1 | ) |  |  | (0.4 | ) |
| Other items, net |  |  | (0.9 | ) |  |  | (0.1 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (96.9 | ) |  |  | (77.5 | ) |
| Inventories |  |  | (168.8 | ) |  |  | (62.5 | ) |
| Other current assets |  |  | 1.1 |  |  |  | (9.5 | ) |
| Accounts payable |  |  | 67.5 |  |  |  | 41.2 |  |
| Accrued expenses |  |  | (33.0 | ) |  |  | (41.8 | ) |
| Income taxes payable and receivable, net |  |  | 20.8 |  |  |  | 14.0 |  |
| Leases, net |  |  | 0.5 |  |  |  | (0.7 | ) |
| Other, net |  |  | 6.6 |  |  |  | 6.9 |  |
| Net cash used in operating activities |  |  | (97.9 | ) |  |  | (17.5 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.3 |  |  |  | 0.4 |  |
| Purchases of property, plant and equipment |  |  | (25.8 | ) |  |  | (24.7 | ) |
| (Purchases of) proceeds from short-term investments, net |  |  | (0.2 | ) |  |  | 0.5 |  |
| Net cash used in investing activities |  |  | (25.7 | ) |  |  | (23.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Asset securitization borrowings |  |  | 90.0 |  |  |  | 155.0 |  |
| Asset securitization payments |  |  | (61.0 | ) |  |  | — |  |
| Long-term debt payments |  |  | (3.2 | ) |  |  | (2.9 | ) |
| Borrowings from credit facility |  |  | 722.5 |  |  |  | 202.0 |  |
| Payments on credit facility |  |  | (381.5 | ) |  |  | (165.0 | ) |
| Proceeds from employee stock purchases |  |  | 0.9 |  |  |  | 0.9 |  |
| Repurchases of common stock |  |  | (200.0 | ) |  |  | (200.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (4.9 | ) |  |  | (6.0 | ) |
| Cash dividends paid |  |  | (33.7 | ) |  |  | (29.5 | ) |
| Net cash provided by (used in) financing activities |  |  | 129.1 |  |  |  | (45.6 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 4.6 |  |  |  | (86.8 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | (2.2 | ) |  |  | (1.6 | ) |
| Cash and cash equivalents, beginning of period |  |  | 31.0 |  |  |  | 123.9 |  |
| Cash and cash equivalents, end of period |  | $ | 34.3 |  |  | $ | 35.5 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 5.8 |  |  | $ | 5.5 |  |
| Income taxes paid (net of refunds) |  | $ | 5.2 |  |  | $ | 8.2 |  |

[0001193125-22-116340:8k_2_02:69]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-22-116340:8k_2_02:70]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-22-116340:8k_2_02:71]
(Unaudited, in millions, except per share and ratio data)

[0001193125-22-116340:8k_2_02:72]
Use of Non-GAAP Financial Measures

[0001193125-22-116340:8k_2_02:73]
To supplement the Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at
constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial
measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to
analyze the Company’s business trends and operating performance.

[0001193125-22-116340:8k_2_02:74]
Reconciliation of Net Income, a GAAP measure, to Adjusted Net Income, a Non-GAAP measure

[0001193125-22-116340:8k_2_02:75]
|  |  | For the Three Months Ended March 31, |  |
|  |  | (Unaudited) |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |  | Pre-Tax |  |  | Tax Impact (d) |  |  | After Tax |  |
| Net income, a GAAP measure |  | $ | 104.4 |  |  | $ | (20.8 | ) |  | $ | 83.6 |  |  | $ | 106.4 |  |  | $ | (22.2 | ) |  | $ | 84.2 |  |
| Restructuring charges |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | — |  |
| Pension settlements |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.7 |  |  |  | (0.1 | ) |  |  | 0.6 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  | 2.2 |  |  |  | (0.7 | ) |  |  | 1.5 |  |  |  | 1.5 |  |  |  | (0.2 | ) |  |  | 1.3 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  | — |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | — |  |  |  | (1.2 | ) |  |  | (1.2 | ) |
| Other tax items, net (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.0 |  |  |  | 2.0 |  |
| Adjusted net income, a non-GAAP measure |  | $ | 107.2 |  |  | $ | (21.1 | ) |  | $ | 86.1 |  |  | $ | 108.7 |  |  | $ | (21.8 | ) |  | $ | 86.9 |  |
| Earnings per share - diluted, a GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.29 |  |  |  |  |  |  |  |  |  |  | $ | 2.20 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Pension settlements |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.02 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit (loss) (a) |  |  |  |  |  |  |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  | 0.03 |  |
| Excess tax expense (benefits) from share-based compensation (b) |  |  |  |  |  |  |  |  |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  | (0.03 | ) |
| Other tax items, net (b) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | 0.05 |  |
| Change in share counts from share-based compensation (c) |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Adjusted earnings per share - diluted, a non-GAAP measure |  |  |  |  |  |  |  |  |  | $ | 2.36 |  |  |  |  |  |  |  |  |  |  | $ | 2.27 |  |

[0001193125-22-116340:8k_2_02:76]
| (a) | Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |

[0001193125-22-116340:8k_2_02:77]
| (b) | Recorded in Provision for income taxes in the Consolidated Statements of Operations |

[0001193125-22-116340:8k_2_02:78]
| (c) | The impact of excess tax benefits from the change in share-based compensation also impacts the Company’s diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this amount. |

[0001193125-22-116340:8k_2_02:79]
| (d) | Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |

[0001193125-22-116340:8k_2_02:80]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
|  |  | (Unaudited) |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |
| Realized gains on settled futures contracts (a) |  | $ | (0.3 | ) |  | $ | (0.3 | ) |
| Foreign currency exchange gains (a) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Gain on disposal of fixed assets (a) |  |  | (0.9 | ) |  |  | (0.3 | ) |
| Other operating income (a) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Net change in unrealized gains on unsettled futures contracts (b) |  |  | (0.7 | ) |  |  | (0.2 | ) |
| Special legal contingency charges (b) |  |  | 0.3 |  |  |  | 0.2 |  |
| Asbestos-related litigation (b) |  |  | 1.7 |  |  |  | 1.1 |  |
| Environmental liabilities (b) |  |  | 0.1 |  |  |  | 0.6 |  |
| Charges incurred related to COVID-19 pandemic (b) |  |  | 0.3 |  |  |  | 0.6 |  |
| Other items, net (b) |  |  | 0.5 |  |  |  | (0.8 | ) |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | 0.4 |  |  | $ | 0.3 |  |

[0001193125-22-116340:8k_2_02:81]
| (a) | Included in both segment profit (loss) and Adjusted net income |

[0001193125-22-116340:8k_2_02:82]
| (b) | Excluded from both segment profit (loss) and Adjusted net income |

[0001193125-22-116340:8k_2_02:83]
Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares
Outstanding - Diluted, a Non-GAAP measure (shares in millions):

[0001193125-22-116340:8k_2_02:84]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Average shares outstanding - diluted, a GAAP measure |  |  | 36.5 |  |  |  | 38.2 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation |  |  | (0.1 | ) |  |  | — |  |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure |  |  | 36.4 |  |  |  | 38.2 |  |

[0001193125-22-116340:8k_2_02:85]
Reconciliation of Net Cash Provided by Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions)

[0001193125-22-116340:8k_2_02:86]
|  |  | For the Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net cash used in operating activities |  | $ | (97.9 | ) |  | $ | (17.5 | ) |
| Purchases of property, plant and equipment |  |  | (25.8 | ) |  |  | (24.7 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | 0.3 |  |  |  | 0.4 |  |
| Free cash flow, a Non-GAAP measure |  | $ | (123.4 | ) |  | $ | (41.8 | ) |

[0001193125-22-116340:8k_2_02:87]
|  |  | Trailing TwelveMonths toMarch 31, 2022 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |
| Adjusted EBIT (a) |  | $ | 602.8 |  |
| Depreciation and amortization expense (b) |  |  | 71.4 |  |
| EBITDA (a + b) |  | $ | 674.2 |  |
| Total debt at March 31, 2022 (c) |  | $ | 1,611.3 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  | 2.4 |  |

[0001193125-22-116340:8k_2_02:88]
Reconciliation of Net Income Before Income Taxes, a GAAP measure to Adjusted EBIT, a
Non-GAAP measure

[0001193125-22-116340:8k_2_02:89]
|  |  | Trailing TwelveMonths toMarch 31, 2022 |  |
| Net income before income taxes, a GAAP measure |  |  | 558.1 |  |
| Items in Losses (gains) and other expenses, net which are excluded from segment profit |  |  | 15.0 |  |
| Special product quality adjustments |  |  | (2.5 | ) |
| Restructuring charges |  |  | 2.2 |  |
| Interest expense, net |  |  | 25.8 |  |
| Pension settlements |  |  | 0.6 |  |
| Other expense (income), net |  |  | 3.6 |  |
| Adjusted EBIT per above, a Non-GAAP measure |  |  | 602.8 |  |
