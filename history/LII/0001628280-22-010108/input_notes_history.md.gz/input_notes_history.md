# LII note change history — 0001628280-21-020422 → 0001628280-22-010108


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.
  (was, 2021-10-25, similarity 0.9079):
[0001628280-21-020422:note_history:1]
Many of our lease agreements contain renewal options; however, we do not recognize right-of-use assets or lease liabilities for renewal periods unless it is determined that we are reasonably certain of renewing the lease at inception or when a triggering event occurs.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions. We recognize our minimum rental expense on a straight-line basis based on the fixed components of a lease arrangement. We amortize this expense over the term of the lease beginning with the date of initial possession. Variable lease components represent amounts that are not fixed in nature and are not tied to an index or rate, and are recognized as incurred.  Under certain of our third-party service agreements, we control a specific space or

- changed (2022-04-25):
[0001628280-22-010108:note_history:2]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Accrued expenses | $ | 38.5 |  |  | $ | 37.2 |  |
| Other liabilities | 104.7 |  |  | 97.0 |  |
| Total warranty liability | $ | 143.2 |  |  | $ | 134.2 |  |
  (was, 2021-10-25, similarity 0.9716):
[0001628280-21-020422:note_history:2]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Accrued expenses | $ | 38.4 |  |  | $ | 37.7 |  |
| Other liabilities | 94.7 |  |  | 82.1 |  |
| Total warranty liability | $ | 133.1 |  |  | $ | 119.8 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:3]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2022 were as follows (in millions):
  (was, 2021-10-25, similarity 0.9416):
[0001628280-21-020422:note_history:3]
The changes in product warranty liabilities related to continuing operations for the nine months ended September 30, 2021 were as follows (in millions):

- changed (2022-04-25):
[0001628280-22-010108:note_history:4]
| Total warranty liability as of December 31, 2021 | $ | 134.2 |  |
| Warranty claims paid | (7.1) |  |
| Changes resulting from issuance of new warranties | 12.7 |  |
| Changes in estimates associated with pre-existing liabilities | 3.5 |  |
| Changes in foreign currency translation rates and other | (0.1) |  |
| Total warranty liability as of March 31, 2022 | $ | 143.2 |  |
  (was, 2021-10-25, similarity 0.8642):
[0001628280-21-020422:note_history:4]
| Total warranty liability as of December 31, 2020 | $ | 119.8 |  |
| Warranty claims paid | (28.1) |  |
| Changes resulting from issuance of new warranties | 37.2 |  |
| Changes in estimates associated with pre-existing liabilities | 4.2 |  |
| Changes in foreign currency translation rates and other | — |  |
| Total warranty liability as of September 30, 2021 | $ | 133.1 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):
  (was, 2021-10-25, similarity 0.8646):
[0001628280-21-020422:note_history:5]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products. We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of these asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment. The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate. Our defense costs for asbestos-related claims are generally covered by insurance.  However, our insurance coverage for settlements and judgments for asbestos-related claims varies depending on several factors and are subject to policy limits.  We may have greater financial exposure for future

- added (2022-04-25):
[0001628280-22-010108:note_history:6]
|  | For the Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Loss for asbestos-related litigation, net | $ | 1.7 |  |  | $ | 1.1 |  |  |  |  |  |

- removed (2022-04-25):
[0001628280-21-020422:note_history:7]
underlying asset used in providing the service by the third-party service provider. These arrangements meet the definition under ASC 842 and therefore are accounted for under ASC 842.

- removed (2022-04-25):
[0001628280-21-020422:note_history:8]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the tables immediately above. Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements. Liabilities for such quality related issues are not material.

- removed (2022-04-25):
[0001628280-21-020422:note_history:9]
settlements and judgments.  The following table summarizes the expenses, net of probable insurance recoveries, for known and future asbestos-related litigation recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations (in millions):

- removed (2022-04-25):
[0001628280-21-020422:note_history:10]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Loss (gain) for asbestos-related litigation, net | $ | 1.8 |  |  | $ | 2.4 |  |  | $ | 4.5 |  |  | $ | 1.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:11]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2022, the accompanying unaudited Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2022 and 2021, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three months ended March 31, 2022 and 2021, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2022 and 2021 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2021.
  (was, 2021-10-25, similarity 0.8524):
[0001628280-21-020422:note_history:11]
The accompanying unaudited Consolidated Balance Sheet as of September 30, 2021, the accompanying unaudited Consolidated Statements of Operations for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2021 and 2020, the accompanying unaudited Consolidated Statements of Stockholders' Deficit for the three and nine months ended September 30, 2021 and 2020, and the accompanying unaudited Consolidated Statements of Cash Flows for the nine months ended September 30, 2021 and 2020 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2020.

- changed (2022-04-25):
[0001628280-22-010108:note_history:12]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world. In March 2020, the World Health Organization declared COVID-19 a pandemic. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.
  (was, 2021-10-25, similarity 0.7364):
[0001628280-21-020422:note_history:12]
A novel strain of coronavirus (“COVID-19”) has surfaced and spread around the world, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic. Currently the COVID-19 pandemic has disrupted our business operations and caused a significant unfavorable impact on our results of operations in 2020. The COVID-19 pandemic is creating supply chain disruptions and higher employee absenteeism in our factories and distribution locations.

- changed (2022-04-25):
[0001628280-22-010108:note_history:13]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also remains unclear how various national, state, and local governments will react if new variants of the virus become more
  (was, 2021-10-25, similarity 0.8033):
[0001628280-21-020422:note_history:13]
As the COVID-19 pandemic continues, health concern risks remain. We cannot predict whether any of our manufacturing, operational or distribution facilities will experience any future disruptions, or how long such disruptions would last.  It also

- changed (2022-04-25):
[0001628280-22-010108:note_history:14]
dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.
  (was, 2021-10-25, similarity 0.6753):
[0001628280-21-020422:note_history:14]
remains unclear how various national, state, and local governments will react if the distribution of vaccines is slower than expected or new variants of the virus become more dominant.  If the COVID-19 pandemic worsens or the pandemic continues longer than presently expected, COVID 19 could impact our results of operations, financial position and cash flows.

- added (2022-04-25):
[0001628280-22-010108:note_history:15]
Executive Leadership Transition
On March 23, 2022, the Board of Directors appointed Alok Maskara as CEO effective May 9, 2022.  Mr. Maskara succeeds Todd Bluedorn, who announced in July 2021 his plans to step down by mid-2022 as Chairman and CEO.  Todd J. Teske was appointed Chairman of the Board and will serve as interim CEO until Mr. Maskara assumes the role as CEO.

- removed (2022-04-25):
[0001628280-21-020422:note_history:16]
Recently Adopted Accounting Guidance

- removed (2022-04-25):
[0001628280-21-020422:note_history:17]
In December 2019, the FASB issued ASU No. 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.  ASU 2019-02, in an effort to reduce complexity in accounting for income taxes, removes certain exceptions for measuring intraperiod tax allocations, foreign subsidiary equity method investments and interim period tax losses.  ASU 2019-12 is effective for calendar year-end public business entities on January 1, 2021.  The adoption of ASU 2019-12 did not have a material impact on our financial statements.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:18]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 1.62 | % |  | 1.38 | % |
  (was, 2021-10-25, similarity 0.94):
[0001628280-21-020422:note_history:18]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.38 | % |  | — | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:19]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 279.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 31.4 |  |  | 29.0 |  |
| Domestic credit facility | 347.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.4) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,599.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,611.3 |  |  | $ | 1,237.8 |  |
  (was, 2021-10-25, similarity 0.8056):
[0001628280-21-020422:note_history:19]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 290.0 |  |  | $ | — |  |
| Finance lease obligations | 10.6 |  |  | 10.1 |  |
| Debt issuance costs | — |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 300.6 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 29.3 |  |
| Domestic credit facility | 9.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (9.2) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.6 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,278.2 |  |  | $ | 980.6 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of March 31, 2022 or December 31, 2021 and there were no borrowings or repayments on these facilities during the three months ended March 31, 2022.
  (was, 2021-10-25, similarity 0.727):
[0001628280-21-020422:note_history:20]
Through several of our foreign subsidiaries, we have facilities available to assist us in financing seasonal borrowing needs for our foreign locations. We had no outstanding foreign obligations as of September 30, 2021 or December 31, 2020 and there were no borrowings or repayments on these facilities during the nine months ended September 30, 2021.

- added (2022-04-25):
[0001628280-22-010108:note_history:21]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 279.4 |  |  | $ | 335.6 |  |
| Less: Beneficial interest transferred | (279.0) |  |  | (250.0) |  |
| Remaining amount available | $ | 0.4 |  |  | $ | 85.6 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:22]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of March 31, 2022 and December 31, 2021 were 1.19% and 0.82%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging
  (was, 2021-10-25, similarity 0.8643):
[0001628280-21-020422:note_history:22]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interests sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of September 30, 2021 and December 31, 2020 were 0.78% and zero%, respectively. The unused

- changed (2022-04-25):
[0001628280-22-010108:note_history:23]
between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.
  (was, 2021-10-25, similarity 0.7594):
[0001628280-21-020422:note_history:23]
fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a rate ranging between 0.25% and 0.35%, depending on the available borrowings, throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2022-04-25):
[0001628280-22-010108:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Credit Agreement ("Domestic Credit Facility"), senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Credit Facility. The participating financial institutions have investment grade credit ratings.  As of March 31, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2021-10-25, similarity 0.9339):
[0001628280-21-020422:note_history:24]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our existing credit facility, senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our existing credit facility. The participating financial institutions have investment grade credit ratings.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.

- changed (2022-04-25):
[0001628280-22-010108:note_history:25]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility.
  (was, 2021-10-25, similarity 0.8173):
[0001628280-21-020422:note_history:25]
In July 2021, we entered into a new Credit Agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto, which refinanced and replaced the Seventh Amended and Restated Credit Facility, among the Company, JPMorgan Chase Bank, N.A., as administrative agent, and the other lenders party thereto.

- changed (2022-04-25):
[0001628280-22-010108:note_history:26]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $347.5 million as well as $2.0 million committed to standby letters of credit as of March 31, 2022. Subject to covenant limitations, $400.5 million was available for future borrowings.
  (was, 2021-10-25, similarity 0.9755):
[0001628280-21-020422:note_history:26]
The Credit Agreement consists of a $750.0 million unsecured revolving credit facility.  We had outstanding borrowings of $9.0 million as well as $2.0 million committed to standby letters of credit as of September 30, 2021. Subject to covenant limitations, $739.0 million was available for future borrowings.

- changed (2022-04-25):
[0001628280-22-010108:note_history:27]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Weighted average borrowing rate | 1.62 | % |  | 1.38 | % |
  (was, 2021-10-25, similarity 0.94):
[0001628280-21-020422:note_history:27]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Weighted average borrowing rate | 1.38 | % |  | — | % |

- changed (2022-04-25):
[0001628280-22-010108:note_history:28]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00).
  (was, 2021-10-25, similarity 0.6993):
[0001628280-21-020422:note_history:28]
The Credit Agreement is guaranteed by certain of our subsidiaries and contains customary covenants applicable to us and our subsidiaries including limitations on indebtedness, liens, dividends, stock repurchases, mergers and sales of all or substantially all of our assets. In addition, the Credit Agreement contains a financial covenant requiring us to maintain, as of the last day of each fiscal quarter for the four prior fiscal quarters, a Total Net Leverage Ratio of no more than 3.50 to 1.00 (or, at our election, on up to two occasions following a material acquisition, 4.00 to 1.00). The Credit Agreement is subject to customary events of default, including non-payment of principal or other amounts under the Credit Agreement, material inaccuracy of representations and warranties, breach of covenants, cross-default to other indebtedness in excess of $75 million, judgements in excess of $75 million, certain voluntary and involuntary bankruptcy events, and the occurrence of a change of control.  As of September 30, 2021, we believe we were in compliance with all covenant requirements.

- added (2022-04-25):
[0001628280-22-010108:note_history:29]
The Credit Agreement contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy. A cross default under our Domestic Credit Facility could occur if:

- added (2022-04-25):
[0001628280-22-010108:note_history:30]
• We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or

- added (2022-04-25):
[0001628280-22-010108:note_history:31]
• We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity.

- added (2022-04-25):
[0001628280-22-010108:note_history:32]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

- added (2022-04-25):
[0001628280-22-010108:note_history:33]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of March 31, 2022, we believe we were in compliance with all covenant requirements.

- changed (2022-04-25):
[0001628280-22-010108:note_history:34]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of March 31, 2022, we believe we were in compliance with all covenant requirements.
  (was, 2021-10-25, similarity 0.9946):
[0001628280-21-020422:note_history:34]
We issued two series of senior unsecured notes on July 30, 2020 for $300.0 million each, which will mature on August 1, 2025 (the "2025 Notes") and August 1, 2027 (the "2027 Notes") with interest being paid semi-annually on February and August at 1.35% and 1.70% respectively, per annum. We also issued $350.0 million of senior unsecured notes in November 2016 (the "2023 Notes," and together with the 2025 Notes and the 2027 Notes, the "Notes") which will mature on November 15, 2023 with interest being paid semi-annually on May 15 and November 15 at 3.00% per annum.  
All the Notes are guaranteed, on a senior unsecured basis, by certain of our subsidiaries that guarantee indebtedness under our Credit Agreement.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date. As of September 30, 2021, we believe we were in compliance with all covenant requirements.

- removed (2022-04-25):
[0001628280-21-020422:note_history:35]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 369.8 |  |  | $ | 279.1 |  |
| Less: Beneficial interest transferred | (290.0) |  |  | — |  |
| Remaining amount available | $ | 79.8 |  |  | $ | 279.1 |  |

- removed (2022-04-25):
[0001628280-21-020422:note_history:36]
The Credit Agreement provides for revolving credit commitments of $750 million with sublimits for swingline loans of up to $65 million, letters of credit up to $100 million and revolving loans in certain non-U.S. currencies up to the U.S. dollar equivalent of $40 million. The Credit Agreement will expire and outstanding loans will be required to be repaid in July 2026, unless maturity is extended by the lenders pursuant to two one-year extension options that we may request under the Credit Agreement. At our request and subject to certain conditions, the revolving credit commitments under the Credit Agreement may be increased by up to a total of $350 million to the extent that existing or new lenders agree to provide additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:37]
|  | As of March 31, 2022 |  | As of December 31, 2021 |
| Current maturities of long-term debt: |  |  |  |
| Total current maturities of long-term debt | $ | 11.8 |  |  | $ | 11.3 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 279.0 |  |  | $ | 250.0 |  |
| Finance lease obligations | 31.4 |  |  | 29.0 |  |
| Domestic credit facility | 347.5 |  |  | 6.5 |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (8.4) |  |  | (9.0) |  |
| Total long-term debt | $ | 1,599.5 |  |  | $ | 1,226.5 |  |
| Total debt | $ | 1,611.3 |  |  | $ | 1,237.8 |  |
  (was, 2021-10-25, similarity 0.8056):
[0001628280-21-020422:note_history:37]
|  | As of September 30, 2021 |  | As of December 31, 2020 |
| Current maturities of long-term debt: |  |  |  |
| Asset securitization program | $ | 290.0 |  |  | $ | — |  |
| Finance lease obligations | 10.6 |  |  | 10.1 |  |
| Debt issuance costs | — |  |  | (0.2) |  |
| Total current maturities of long-term debt | $ | 300.6 |  |  | $ | 9.9 |  |
| Long-Term Debt: |  |  |  |
| Finance lease obligations | 27.8 |  |  | 29.3 |  |
| Domestic credit facility | 9.0 |  |  | — |  |
| Senior unsecured notes | 950.0 |  |  | 950.0 |  |
| Debt issuance costs | (9.2) |  |  | (8.6) |  |
| Total long-term debt | $ | 977.6 |  |  | $ | 970.7 |  |
| Total debt | $ | 1,278.2 |  |  | $ | 980.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-25):
[0001628280-22-010108:note_history:38]
|  | For the Three Months Ended March 31, 2022 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 629.7 |  |  | $ | 176.8 |  |  | $ | 91.8 |  |  | $ | 898.3 |  |
| Canada | 52.5 |  |  | 10.4 |  |  | — |  |  | 62.9 |  |
| Other international | — |  |  | 0.5 |  |  | 51.7 |  |  | 52.2 |  |
| Total | $ | 682.2 |  |  | $ | 187.7 |  |  | $ | 143.5 |  |  | $ | 1,013.4 |  |
  (was, 2021-10-25, similarity 0.959):
[0001628280-21-020422:note_history:38]
|  | For the Three Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 655.0 |  |  | $ | 194.0 |  |  | $ | 81.2 |  |  | $ | 930.2 |  |
| Canada | 56.0 |  |  | 16.8 |  |  | — |  |  | 72.8 |  |
| Other international | — |  |  | 0.7 |  |  | 56.2 |  |  | 56.9 |  |
| Total | $ | 711.0 |  |  | $ | 211.5 |  |  | $ | 137.4 |  |  | $ | 1,059.9 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:39]
|  | For the Three Months Ended March 31, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 558.8 |  |  | $ | 182.3 |  |  | $ | 75.6 |  |  | $ | 816.7 |  |
| Canada | 47.5 |  |  | 16.9 |  |  | — |  |  | 64.4 |  |
| Other international | — |  |  | — |  |  | 49.4 |  |  | 49.4 |  |
| Total | $ | 606.3 |  |  | $ | 199.2 |  |  | $ | 125.0 |  |  | $ | 930.5 |  |
  (was, 2021-10-25, similarity 0.7615):
[0001628280-21-020422:note_history:39]
|  | For the Three Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 665.6 |  |  | $ | 184.6 |  |  | $ | 67.2 |  |  | $ | 917.4 |  |
| Canada | 56.4 |  |  | 22.7 |  |  | — |  |  | 79.1 |  |
| Other international | — |  |  | 0.6 |  |  | 57.9 |  |  | 58.5 |  |
| Total | $ | 722.0 |  |  | $ | 207.9 |  |  | $ | 125.1 |  |  | $ | 1,055.0 |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:40]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended March 31, 2022 and 2021, direct sales represented 66% and 67% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.
  (was, 2021-10-25, similarity 0.9088):
[0001628280-21-020422:note_history:40]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox stores or to independent distributors. For the three months ended September 30, 2021 and 2020, direct sales represented 73% and 74% of revenues, and sales to independent distributors represented the remainder. For the nine months ended September 30, 2021 and 2020, direct sales represented 72% and 75% of revenues, and sales to independent distributors represented the remainder. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

- added (2022-04-25):
[0001628280-22-010108:note_history:41]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in

- added (2022-04-25):
[0001628280-22-010108:note_history:42]
time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended March 31, 2022 and 2021, equipment sales represented 80% and 83% of revenues and the remainder of our revenue was generated from our service business.

- changed (2022-04-25):
[0001628280-22-010108:note_history:43]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.
  (was, 2021-10-25, similarity 0.8651):
[0001628280-21-020422:note_history:43]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users. In Europe, we also manufacture and sell unitary heating and cooling products and applied systems. Substantially all segment revenue was related to these types of equipment and systems and is recognized at a

- added (2022-04-25):
[0001628280-22-010108:note_history:44]
|  | March 31, 2022 |  | December 31, 2021 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (14.0) |  |  | $ | (10.2) |  |  | $ | (3.8) |  |  | 36.9 | % |
| Contract liabilities - noncurrent | (5.4) |  |  | (5.5) |  |  | 0.1 |  |  | (1.2) | % |
| Total | $ | (19.4) |  |  | $ | (15.7) |  |  | $ | (3.7) |  |  |  |

- changed (2022-04-25):
[0001628280-22-010108:note_history:45]
For the three months ended March 31, 2022 and 2021, we recognized revenue of $3.7 million and $1.6 million related to our contract liabilities at January 1, 2022 and 2021, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2022 and 2021.
  (was, 2021-10-25, similarity 0.8154):
[0001628280-21-020422:note_history:45]
For the three months ended September 30, 2021 and 2020, we recognized revenue of $0.6 million and $1.4 million and for the nine months ended September 30, 2021 and 2020 we recognized revenue of $2.9 million and $5.9 million related to our contract liabilities at January 1, 2021 and 2020, respectively. Impairment losses recognized in our receivables and contract assets were de minimis in  2021 and 2020.

- removed (2022-04-25):
[0001628280-21-020422:note_history:46]
|  | For the Nine Months Ended September 30, 2021 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,976.8 |  |  | $ | 605.0 |  |  | $ | 239.1 |  |  | $ | 2,820.9 |  |
| Canada | 178.5 |  |  | 57.6 |  |  | — |  |  | 236.1 |  |
| Other international | — |  |  | 0.8 |  |  | 171.5 |  |  | 172.3 |  |
| Total | $ | 2,155.3 |  |  | $ | 663.4 |  |  | $ | 410.6 |  |  | $ | 3,229.3 |  |

- removed (2022-04-25):
[0001628280-21-020422:note_history:47]
|  | For the Nine Months Ended September 30, 2020 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 1,681.8 |  |  | $ | 518.9 |  |  | $ | 188.0 |  |  | $ | 2,388.7 |  |
| Canada | 127.0 |  |  | 54.8 |  |  | — |  |  | 181.8 |  |
| Other international | — |  |  | 0.9 |  |  | 148.7 |  |  | 149.6 |  |
| Total | $ | 1,808.8 |  |  | $ | 574.6 |  |  | $ | 336.7 |  |  | $ | 2,720.1 |  |

- removed (2022-04-25):
[0001628280-21-020422:note_history:48]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment. Lennox National Account Services provides installation, service and preventive maintenance for HVAC national account customers in the United States and Canada. Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided. For the three months ended September 30, 2021 and 2020, equipment sales represented 81% and 83% of revenues and the remainder of our revenue was generated from our service business. For the nine months ended September 30, 2021 and 2020, equipment sales represented 83% and 84% of revenues and the remainder of our revenue was generated from our service business.

- removed (2022-04-25):
[0001628280-21-020422:note_history:49]
point in time when control transfers to the customer, which is generally at time of shipment.  Less than 1% of segment revenue relates to services for start-up and commissioning activities.

- removed (2022-04-25):
[0001628280-21-020422:note_history:50]
|  | September 30, 2021 |  | December 31, 2020 |  | $ Change |  | % Change |
| Contract liabilities - current | $ | (8.3) |  |  | $ | (5.5) |  |  | $ | (2.8) |  |  | 50.9 | % |
| Contract liabilities - noncurrent | (5.2) |  |  | (5.6) |  |  | 0.4 |  |  | (7.1) | % |
| Total | $ | (13.5) |  |  | $ | (11.1) |  |  | $ | (2.4) |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-04-25):
[0001628280-21-020422:note_history:51]
On July 8, 2021, Todd M. Bluedorn, our Chairman of the Board and Chief Executive Officer advised our Board of Directors that he intended to resign as Chief Executive Officer and as Chairman and a member of our Board of Directors in mid-2022.

- removed (2022-04-25):
[0001628280-21-020422:note_history:52]
The Board of Directors has commenced a search for our next chief executive officer.
