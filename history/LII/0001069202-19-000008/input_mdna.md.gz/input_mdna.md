# LII MD&A — 0001069202-19-000008


## mdna

[0001069202-19-000008:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001069202-19-000008:mdna:2]
The following discussion should be read in conjunction with the other sections of this report, including the consolidated financial statements and related notes contained in Item 8 of this Annual Report on Form 10-K.

[0001069202-19-000008:mdna:3]
Business Overview

[0001069202-19-000008:mdna:4]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry. Our reportable segments are Residential Heating & Cooling, Commercial Heating & Cooling, and Refrigeration.  For more detailed information regarding our reportable segments, see Note 20 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000008:mdna:5]
We sell our products and services through a combination of direct sales, distributors and company-owned stores. The demand for our products and services is seasonal and significantly impacted by the weather.  Warmer than normal summer temperatures generate demand for replacement air conditioning and refrigeration products and services, and colder than normal winter temperatures have a similar effect on heating products and services.  Conversely, cooler than normal summers and warmer than normal winters depress the demand for HVACR products and services.  In addition to weather, demand for our products and services is influenced by national and regional economic and demographic factors, such as interest rates, the availability of financing, regional population and employment trends, new construction, general economic conditions and consumer spending habits and confidence.  A substantial portion of the sales in each of our business segments is attributable to replacement business, with the balance comprised of new construction business.

[0001069202-19-000008:mdna:6]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.  The principal raw materials used in our manufacturing processes are steel, copper and aluminum.  In recent years, pricing volatility for these commodities and related components has impacted us and the HVACR industry in general.  We seek to mitigate the impact of commodity price volatility through a combination of pricing actions, vendor contracts, improved production efficiency and cost reduction initiatives. We also partially mitigate volatility in the prices of these commodities by entering into futures contracts and fixed forward contracts.

[0001069202-19-000008:mdna:7]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss.  We are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we suffered. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered.  For the year ended December 31, 2018 we incurred expenses of $86.0 million related to damages caused by the tornado, which included the write-off of damaged property, equipment and inventory, freight to move product to other warehouses and professional fees to secure and maintain the site.  We have received insurance recoveries of $124.3 million for the year ended December 31, 2018.  We have allocated the first $96.9 million of insurance recoveries to cover our expenses and rebuilding costs incurred to date which is included in Gain from insurance recoveries, net of losses incurred in the Consolidated Statements of Operations.  The remaining $27.4 million of insurance recoveries represents amounts for lost profits and is shown in Insurance proceeds for lost profits in the Consolidated Statements of Operations.  In 2019, we expect to receive approximately $83 million of insurance proceeds related to lost profits and $149 million of insurance proceeds to fund the reconstruction of the facility and as reimbursement for other losses and expenses expected to be incurred.  As part of our recovery efforts, we have shifted production of certain products that were previously only produced at our Marshalltown facility to our other facilities.  We believe this provides increased manufacturing flexibility.

[0001069202-19-000008:mdna:8]
Financial Highlights

[0001069202-19-000008:mdna:9]
| • | Net sales increased $44 million, or 1.2%, to $3,884 million in 2018 from $3,840 million in 2017. |

[0001069202-19-000008:mdna:10]
| • | Operating income in 2018 was $510 million compared to $495 million in 2017. The increase was primarily due to increased sales, reductions in SG&A expenses, and insurance proceeds received for third-quarter lost profits, partially offset by lower gross profit. |

[0001069202-19-000008:mdna:11]
| • | Net income in 2018 increased to $359 million from $306 million in 2017. |

[0001069202-19-000008:mdna:12]
| • | Diluted earnings per share from continuing operations were $8.77 per share in 2018 compared to $7.17 per share in 2017. |

[0001069202-19-000008:mdna:13]
| • | We generated $496 million of cash flow from operating activities in 2018 compared to $325 million in 2017. The increase was primarily due to a decrease in working capital and an increase in net income. |

[0001069202-19-000008:mdna:14]
| • | In 2018, we returned $94 million to shareholders through dividend payments and we used $450 million to purchase 2.3 million shares of stock under our Share Repurchase Plans. We also received $115 million in net proceeds from the sale of our businesses in Australia, Asia and South America along with the sale of the related property. |

[0001069202-19-000008:mdna:15]
Overview of Results

[0001069202-19-000008:mdna:16]
Despite the impact of the tornado at our Marshalltown facility the Residential Heating & Cooling segment performed well in 2018, with a 4.0% increase in net sales and a $26 million increase in segment profit compared to 2017, including the insurance proceeds received for lost profits in 2018.  Our Commercial Heating & Cooling segment also performed well in 2018 with a 7.2% increase in net sales and a $2 million increase in segment profit compared to 2017.  This segment’s results were driven by volume and price gains.  Sales in our Refrigeration segment decreased 15% and segment profit decreased $7 million compared to 2017 mostly due to the sale of our Australia, Asia and South America businesses.

[0001069202-19-000008:mdna:17]
On a consolidated basis, our gross profit margins decreased to 28.6% in 2018 due primarily to unfavorable commodities, factory inefficiencies due to disruption caused by the tornado at our Marshalltown facility, and higher freight and distribution costs.  These declines were partially offset by favorable price and mix and sourcing and engineering-led cost reductions across our business.

[0001069202-19-000008:mdna:18]
17

[0001069202-19-000008:mdna:19]
Results of Operations

[0001069202-19-000008:mdna:20]
The following table provides a summary of our financial results, including information presented as a percentage of net sales (dollars in millions):

[0001069202-19-000008:mdna:21]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net sales | $ | 3,883.9 |  |  | 100.0 | % |  | $ | 3,839.6 |  |  | 100.0 | % |  | $ | 3,641.6 |  |  | 100.0 | % |
| Cost of goods sold | 2,772.7 |  |  | 71.4 | % |  | 2,714.4 |  |  | 70.7 | % |  | 2,565.1 |  |  | 70.4 | % |
| Gross profit | 1,111.2 |  |  | 28.6 | % |  | 1,125.2 |  |  | 29.3 | % |  | 1,076.5 |  |  | 29.6 | % |
| Selling, general and administrative expenses | 608.2 |  |  | 15.7 | % |  | 637.7 |  |  | 16.6 | % |  | 621.0 |  |  | 17.1 | % |
| Losses (gains) and other expenses, net | 13.4 |  |  | 0.3 | % |  | 7.1 |  |  | 0.2 | % |  | 11.3 |  |  | 0.3 | % |
| Restructuring charges | 3.0 |  |  | 0.1 | % |  | 3.2 |  |  | 0.1 | % |  | 1.8 |  |  | — | % |
| Loss (gain), net on sale of businesses and related property | 27.0 |  |  | 0.7 | % |  | 1.1 |  |  | — | % |  | — |  |  | — | % |
| Gain from insurance recoveries, net of losses incurred | (10.9 | ) |  | (0.3 | )% |  | — |  |  | — | % |  | — |  |  | — | % |
| Insurance proceeds for lost profits | (27.4 | ) |  | (0.7 | )% |  | — |  |  | — | % |  | — |  |  | — | % |
| Pension settlement | 0.4 |  |  | — | % |  | — |  |  | — | % |  | 31.4 |  |  | 0.9 | % |
| Income from equity method investments | (12.0 | ) |  | (0.3 | )% |  | (18.4 | ) |  | (0.5 | )% |  | (18.4 | ) |  | (0.5 | )% |
| Operating income | $ | 509.5 |  |  | 13.1 | % |  | $ | 494.5 |  |  | 12.9 | % |  | $ | 429.4 |  |  | 11.8 | % |
| Loss from discontinued operations | (1.3 | ) |  | — | % |  | (1.4 | ) |  | — | % |  | (0.8 | ) |  | — | % |
| Net income | $ | 359.0 |  |  | 9.2 | % |  | $ | 305.7 |  |  | 8.0 | % |  | $ | 277.8 |  |  | 7.6 | % |

[0001069202-19-000008:mdna:22]
The following table provides net sales by geographic market (dollars in millions):

[0001069202-19-000008:mdna:23]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | Dollars |  | Percent |  | Dollars |  | Percent |  | Dollars |  | Percent |
| Net Sales by Geographic Market: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. | $ | 3,275.9 |  |  | 84.3 | % |  | $ | 3,128.7 |  |  | 81.5 | % |  | $ | 2,966.8 |  |  | 81.5 | % |
| Canada | 254.8 |  |  | 6.6 |  |  | 237.8 |  |  | 6.2 |  |  | 218.8 |  |  | 6.0 |  |
| International | 353.2 |  |  | 9.1 |  |  | 473.1 |  |  | 12.3 |  |  | 456.0 |  |  | 12.5 |  |
| Total net sales | $ | 3,883.9 |  |  | 100.0 | % |  | $ | 3,839.6 |  |  | 100.0 | % |  | $ | 3,641.6 |  |  | 100.0 | % |

[0001069202-19-000008:mdna:24]
Year Ended December 31, 2018 Compared to Year Ended December 31, 2018 - Consolidated Results

[0001069202-19-000008:mdna:25]
Net Sales

[0001069202-19-000008:mdna:26]
Net sales increased 1.2% in 2018 compared to 2017, primarily driven by volume and price increases.  The increase in volume was primarily due to market growth in our Residential Heating and Cooling and Commercial Heating and Cooling segments.  These increases were partially offset by the impact due to the sale of our Australia, Asia and South America businesses in our Refrigeration segment.

[0001069202-19-000008:mdna:27]
Gross Profit

[0001069202-19-000008:mdna:28]
Gross profit margins for 2018 decreased 70 basis points (“bps”) to 28.6% compared to 29.3% in 2017.  We saw margin decreases of 120 bps from higher commodity costs, 100 bps from higher freight and distribution costs, and 50 bps from other product costs.  These decreases were offset by increases of 130 bps from favorable price and mix and 70 bps from sourcing and engineering-led cost reductions.

[0001069202-19-000008:mdna:29]
Selling, General and Administrative Expenses

[0001069202-19-000008:mdna:30]
SG&A expenses decreased by $30 million in 2018 compared to 2017.  As a percentage of net sales, SG&A expenses decreased 90 bps from 16.6% to 15.7% in the same periods.  SG&A decreased primarily due to the sale of our divested businesses in Australia,  Asia and South America.

[0001069202-19-000008:mdna:31]
Losses (Gains) and Other Expenses, Net

[0001069202-19-000008:mdna:32]
Losses (gains) and other expenses, net for 2018 and 2017 included the following (in millions):

[0001069202-19-000008:mdna:33]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |
| Realized gains, net on settled futures contracts | $ | (0.4 | ) |  | $ | (1.7 | ) |
| Foreign currency exchange losses (gains), net | 1.7 |  |  | (1.8 | ) |
| Losses on disposal of fixed assets | 0.7 |  |  | 0.2 |  |
| Net change in unrealized losses, net on unsettled futures contracts | 1.5 |  |  | 0.9 |  |
| Asbestos-related litigation | 4.0 |  |  | 3.5 |  |
| Special legal contingency charge | 1.9 |  |  | 3.7 |  |
| Environmental liabilities | 2.2 |  |  | 2.2 |  |
| Contractor tax payments | — |  |  | 0.1 |  |
| Other items, net | 1.8 |  |  | — |  |
| Losses (gains) and other expenses, net | $ | 13.4 |  |  | $ | 7.1 |  |

[0001069202-19-000008:mdna:34]
The realized gains on settled futures contracts in 2018 was attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2018 relative to 2017.  Additionally, the change in unrealized losses, net on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.  For more information on our derivatives, see Note 9 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000008:mdna:35]
Foreign currency exchange losses increased in 2018 primarily due to weakening in foreign exchange rates in our primary markets.  The special legal contingency charges decreased primarily due to lower legal costs associated with outstanding legal settlements.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-19-000008:mdna:36]
Restructuring Charges

[0001069202-19-000008:mdna:37]
Restructuring charges were $3.0 million in 2018 compared to $3.2 million in 2017.  The charges in 2018 and 2017 were primarily for projects to realign resources and enhance manufacturing and distribution capabilities.  For more information on our restructuring activities, see Note 18 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000008:mdna:38]
Goodwill

[0001069202-19-000008:mdna:39]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment for the year ended December 31, 2018. In the current year, we wrote off $11.5 million of goodwill as a part of the completed sales of our Australia, Asia and South America businesses (discussed further in Note 17 of the Notes to the Consolidated Financial Statements).  Also, we did not record any goodwill impairments in 2017. Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-19-000008:mdna:40]
Asset Impairment

[0001069202-19-000008:mdna:41]
We did not have any impairments of assets related to continuing operations in 2018 or 2017.

[0001069202-19-000008:mdna:42]
Pension Settlement

[0001069202-19-000008:mdna:43]
We did not have significant pension buyout activity in 2018 or 2017.  Refer to Note 13 in the Notes to the Consolidated Financial Statements for more information on pensions and employee benefit plans.

[0001069202-19-000008:mdna:44]
Income from Equity Method Investments

[0001069202-19-000008:mdna:45]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $12 million in 2018 compared to $18 million in 2017.  The decrease is because the joint ventures have experienced increased costs related to commodities and components and have not passed these increased costs on through price increases.

[0001069202-19-000008:mdna:46]
Interest Expense, net

[0001069202-19-000008:mdna:47]
Net interest expense of $38 million in 2018 increased from $31 million in 2017 primarily due to an increase in our average borrowings and rising interest rates.

[0001069202-19-000008:mdna:48]
Income Taxes

[0001069202-19-000008:mdna:49]
The income tax provision was $108 million in 2018 compared to $157 million in 2017, and the effective tax rate was 23% in 2018 compared to 34% in 2017.  The 2018 effective tax rate differs from the statutory rate of 21% primarily due to state and foreign taxes. The 2017 effective tax rate was negatively impacted by changes in U.S. tax legislation that reduced the value of our deferred tax assets by $31.8 million, partially offset by the benefit from the impact of excess tax benefits of $23.6 million.  We expect our effective tax rate will be between 22% and 23% in future years excluding the impact of excess tax benefits.  Refer to Note 10 in the Notes to the Consolidated Financial Statements for more information on the impact of recent changes in tax legislation.

[0001069202-19-000008:mdna:50]
Loss from Discontinued Operations

[0001069202-19-000008:mdna:51]
The $1 million of pre-tax income incurred in 2018 and $2 million of pre-tax losses in 2017 primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-19-000008:mdna:52]
Year Ended December 31, 2018 Compared to Year Ended December 31, 2017 - Results by Segment

[0001069202-19-000008:mdna:53]
Residential Heating & Cooling

[0001069202-19-000008:mdna:54]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-19-000008:mdna:55]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 2,225.0 |  |  | $ | 2,140.4 |  |  | $ | 84.6 |  |  | 4.0 | % |
| Profit | $ | 399.4 |  |  | $ | 373.9 |  |  | $ | 25.5 |  |  | 6.8 | % |
| % of net sales | 18.0 | % |  | 17.5 | % |  |  |  |  |

[0001069202-19-000008:mdna:56]
Residential Heating & Cooling net sales increased 4% in 2018 compared to 2017. Sales volume increased 2% and price and mix combined increased 2%.

[0001069202-19-000008:mdna:57]
Segment profit in 2018 increased $26 million due to $52 million of combined price and mix, $27 million of insurance proceeds for the third quarter 2018 lost profits from the Marshalltown tornado, $14 million from higher sales volume, $12 million from sourcing and engineering-led cost reductions, and $5 million of higher factory productivity.  Partially offsetting these increases is $35 million of higher commodity costs, $32 million of higher freight and distribution expenses, $9 million of higher other product costs, $4 million from lower equity method income, $3 million from unfavorable foreign exchange rates, and $1 million from higher SG&A.

[0001069202-19-000008:mdna:58]
Commercial Heating & Cooling

[0001069202-19-000008:mdna:59]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-19-000008:mdna:60]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 1,043.5 |  |  | $ | 973.8 |  |  | $ | 69.7 |  |  | 7.2 | % |
| Profit | $ | 159.5 |  |  | $ | 157.3 |  |  | $ | 2.2 |  |  | 1.4 | % |
| % of net sales | 15.3 | % |  | 16.2 | % |  |  |  |  |

[0001069202-19-000008:mdna:61]
Commercial Heating & Cooling net sales increased 7% in 2018 compared to 2017.  Sales volume increased 5% and price and mix combined increased 2%.

[0001069202-19-000008:mdna:62]
Segment profit in 2018 increased $2 million compared to 2017 due to $15 million from higher sales volume, $11 million of combined price and mix, and $4 million from sourcing and engineering-led cost reductions.  Partially offsetting these increases is $9 million of higher commodity costs, $8 million of higher other product costs, $5 million of higher freight and distribution expense, $3 million of lower factory productivity, $2 million of higher SG&A expense, and $1 million of lower equity method income.

[0001069202-19-000008:mdna:63]
Refrigeration

[0001069202-19-000008:mdna:64]
The following table presents our Refrigeration segment’s net sales and profit for 2018 and 2017 (dollars in millions):

[0001069202-19-000008:mdna:65]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Difference |  | % Change |
| Net sales | $ | 615.4 |  |  | $ | 725.4 |  |  | $ | (110.0 | ) |  | (15.2 | )% |
| Profit | $ | 66.1 |  |  | $ | 72.6 |  |  | $ | (6.5 | ) |  | (9.0 | )% |
| % of net sales | 10.7 | % |  | 10.0 | % |  |  |  |  |

[0001069202-19-000008:mdna:66]
Net sales decreased 15% in 2018 compared to 2017.  The loss of sales from the divested Australia, Asia and South America businesses contributed 16% and price and mix combined was 1% lower partially offset by sales volume increases of 1% and 1% from foreign currency exchange rates.

[0001069202-19-000008:mdna:67]
Segment profit in 2018 decreased $7 million compared to 2017 due to $6 million of higher commodity costs, $6 million of lower profit due to the divested Australia, Asia and South America businesses, $2 million of lower factory productivity, $2 million of higher freight and distribution expense, $2 million of lower equity method income, and $1 million of higher other product costs.  Partially offsetting these decreases is $6 million of sourcing and engineering-led cost reductions, $2 million from selling refrigerant allocations in Europe, $2 million of lower SG&A expense, $1 million from higher sales volume, and $1 million of favorable foreign currency exchange rates.

[0001069202-19-000008:mdna:68]
Corporate and Other

[0001069202-19-000008:mdna:69]
Corporate and other expenses decreased by $5 million in 2018 primarily due to $2 million of non-recurring discretionary expenses in 2017, $2 million of pension expense that was reclassified out of operating income due to a change in accounting rules, and $1 million of lower health and welfare expense.

[0001069202-19-000008:mdna:70]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016 - Consolidated Results

[0001069202-19-000008:mdna:71]
Net Sales

[0001069202-19-000008:mdna:72]
Net sales increased 5.4% in 2017 compared to 2016, primarily driven by volume increases.  The increase in volume was primarily due to market growth in our Residential Heating and Cooling and Commercial Heating and Cooling segments.  Changes in foreign currency exchange rates and the effects of price and mix also had positive impacts on net sales.

[0001069202-19-000008:mdna:73]
Gross Profit

[0001069202-19-000008:mdna:74]
Gross profit margins for 2017 decreased 30 basis points (“bps”) to 29.3% compared to 29.6% in 2016.  We saw margin decreases of 80 bps from higher commodity costs, 50 bps for investments in distribution expansion, and 40 bps from other product costs.  These decreases were offset by increases of 100 bps from sourcing and engineering-led cost reductions and 40 bps from favorable price and mix.

[0001069202-19-000008:mdna:75]
Selling, General and Administrative Expenses

[0001069202-19-000008:mdna:76]
SG&A expenses increased by $17 million in 2017 compared to 2016.  As a percentage of net sales, SG&A expenses decreased 50 bps from 17.1% to 16.6% in the same periods.  SG&A increased due to general wage inflation, increased healthcare costs and increased investment in information technology and research and development partially offset by decreases in incentive compensation.

[0001069202-19-000008:mdna:77]
Losses (Gains) and Other Expenses, Net

[0001069202-19-000008:mdna:78]
Losses (gains) and other expenses, net for 2017 and 2016 included the following (in millions):

[0001069202-19-000008:mdna:79]
|  | For the Years Ended December 31, |
|  | 2017 |  | 2016 |
| Realized (gains) losses, net on settled futures contracts | $ | (1.7 | ) |  | $ | 1.1 |  |
| Foreign currency exchange (gains) losses, net | (1.8 | ) |  | 2.2 |  |
| Losses on disposal of fixed assets | 0.2 |  |  | 0.5 |  |
| Net change in unrealized losses (gains), net on unsettled futures contracts | 0.9 |  |  | (3.6 | ) |
| Asbestos-related litigation | 3.5 |  |  | 6.3 |  |
| Special legal contingency charge | 3.7 |  |  | 1.9 |  |
| Environmental liabilities | 2.2 |  |  | 1.9 |  |
| Contractor tax payments | 0.1 |  |  | 0.6 |  |
| Other items, net | — |  |  | 0.4 |  |
| Losses (gains) and other expenses, net | $ | 7.1 |  |  | $ | 11.3 |  |

[0001069202-19-000008:mdna:80]
The realized gains on settled futures contracts in 2017 was attributable to changes in commodity prices relative to our settled futures contract prices, as commodity prices have increased in 2017 relative to 2016.  Additionally, the change in unrealized losses, net on unsettled futures contracts was due to lower commodity prices relative to the unsettled futures contract prices.

[0001069202-19-000008:mdna:81]
Foreign currency exchange gains increased in 2017 primarily due to improvement in foreign exchange rates in our primary markets.  The special legal contingency charges increased primarily due to costs associated with the matter reported to the Securities and Exchange Commission and Department of Justice.  The asbestos-related litigation relates to known and estimated future asbestos matters.  The environmental liabilities relate to estimated remediation costs for contamination at some of our facilities.  The contractor tax payments relate to a charge for underpaid contractor taxes at one of our non-U.S. subsidiaries.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on litigation, including the asbestos-related litigation, and the environmental liabilities.

[0001069202-19-000008:mdna:82]
Restructuring Charges

[0001069202-19-000008:mdna:83]
Restructuring charges were $3.2 million in 2017 compared to $1.8 million in 2016.  The charges in 2017 and 2016 were primarily for projects to realign resources and enhance distribution capabilities.

[0001069202-19-000008:mdna:84]
Goodwill

[0001069202-19-000008:mdna:85]
We performed a qualitative impairment analysis and noted no indicators of goodwill impairment through December 31, 2017. Also, we did not record any goodwill impairments in 2016. Refer to Note 5 in the Notes to the Consolidated Financial Statements for more information on goodwill.

[0001069202-19-000008:mdna:86]
Pension Settlement

[0001069202-19-000008:mdna:87]
In 2016 our unfunded pension liability declined by $33 million to $89 million as the favorable impact of our $50 million discretionary contribution was partially offset by lower discount rates across all plans.  In addition, we recorded a pension settlement charge of $31 million in the fourth quarter of 2016.  We did not have similar funding or pension buyout activity in 2017.

[0001069202-19-000008:mdna:88]
Income from Equity Method Investments

[0001069202-19-000008:mdna:89]
Investments over which we do not exercise control but have significant influence are accounted for using the equity method of accounting.  Income from equity method investments was $18 million in 2017 compared to $18 million in 2016 due to flat earnings from our joint ventures.

[0001069202-19-000008:mdna:90]
Interest Expense, net

[0001069202-19-000008:mdna:91]
Net interest expense of $31 million in 2017 increased from $27 million in 2016 primarily due to an increase in our average borrowings.

[0001069202-19-000008:mdna:92]
Income Taxes

[0001069202-19-000008:mdna:93]
The income tax provision was $157 million in 2017 compared to $124 million in 2016, and the effective tax rate was 34% in 2017 compared to 31% in 2016.  The 2017 effective tax rate was negatively impacted by recent changes in U.S. tax legislation that reduced the value of our deferred tax assets by $31.8 million, partially offset by the benefit from the impact of excess tax benefits of $23.6 million.  The 2016 effective tax rate was not impacted by either U.S. tax rate changes or the impact of excess tax benefits.

[0001069202-19-000008:mdna:94]
Loss from Discontinued Operations

[0001069202-19-000008:mdna:95]
The $2 million of pre-tax losses incurred in 2017 and $1 million of pre-tax losses in 2016 primarily relate to changes in retained product liabilities and general liabilities for the Service Experts business sold in 2013 and the Hearth business sold in 2012.

[0001069202-19-000008:mdna:96]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016 - Results by Segment

[0001069202-19-000008:mdna:97]
Residential Heating & Cooling

[0001069202-19-000008:mdna:98]
The following table presents our Residential Heating & Cooling segment’s net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-19-000008:mdna:99]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 2,140.4 |  |  | $ | 2,000.8 |  |  | $ | 139.6 |  |  | 7.0 | % |
| Profit | $ | 373.9 |  |  | $ | 348.8 |  |  | $ | 25.1 |  |  | 7.2 | % |
| % of net sales | 17.5 | % |  | 17.4 | % |  |  |  |  |

[0001069202-19-000008:mdna:100]
Residential Heating & Cooling net sales increased 7% in 2017 compared to 2016. Sales volume increased by 7% primarily due to market growth.

[0001069202-19-000008:mdna:101]
Segment profit in 2017 increased $25 million due to $39 million from higher sales volume, $21 million from sourcing and engineering-led cost reductions, $15 million from favorable price, $5 million from favorable foreign currency, $2 million from lower warranty expense, and $1 million from higher income from equity method investments.  Partially offsetting these increases was $20 million in higher commodity costs, $15 million in SG&A expenses to support investments in technology and research and development, incremental headcount and higher personnel costs, $12 million in freight and distribution investments, $6 million from unfavorable mix, and $5 million from increases in other product costs.

[0001069202-19-000008:mdna:102]
Commercial Heating & Cooling

[0001069202-19-000008:mdna:103]
The following table presents our Commercial Heating & Cooling segment’s net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-19-000008:mdna:104]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 973.8 |  |  | $ | 917.9 |  |  | $ | 55.9 |  |  | 6.1 | % |
| Profit | $ | 157.3 |  |  | $ | 149.3 |  |  | $ | 8.0 |  |  | 5.4 | % |
| % of net sales | 16.2 | % |  | 16.3 | % |  |  |  |  |

[0001069202-19-000008:mdna:105]
Commercial Heating & Cooling net sales increased 6% in 2017 compared to 2016.  Sales volume increased by 5% primarily due to market growth and 1% from favorable foreign currency.

[0001069202-19-000008:mdna:106]
Segment profit in 2017 increased $8 million compared to 2016 due to $14 million from higher sales volume, $7 million from sourcing and engineering-led cost reductions, and $1 million in favorable foreign currency.  Partially offsetting these increases was $5 million from warranty and other product costs, $4 million of higher commodity costs, $3 million from factory inefficiencies, $1 million in higher SG&A expenses, and $1 million in freight and distribution investments.

[0001069202-19-000008:mdna:107]
Refrigeration

[0001069202-19-000008:mdna:108]
The following table presents our Refrigeration segment’s net sales and profit for 2017 and 2016 (dollars in millions):

[0001069202-19-000008:mdna:109]
|  | For the Years Ended December 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Difference |  | % Change |
| Net sales | $ | 725.4 |  |  | $ | 722.9 |  |  | $ | 2.5 |  |  | 0.3 | % |
| Profit | $ | 72.6 |  |  | $ | 68.9 |  |  | $ | 3.7 |  |  | 5.4 | % |
| % of net sales | 10.0 | % |  | 9.5 | % |  |  |  |  |

[0001069202-19-000008:mdna:110]
Net sales in 2017 were flat compared to 2016.  Favorable foreign currency increased sales by 1% offset by lower sales volume of 1% primarily from our North America supermarket business.

[0001069202-19-000008:mdna:111]
Segment profit in 2017 increased $4 million compared to 2016 due to $9 million from sourcing and engineering-led cost reductions, $3 million from favorable price and mix, and $3 million in lower other product costs.  Partially offsetting these increases was $5 million from factory inefficiencies, $2 million from freight and distribution, $2 million from higher commodity costs, and $2 million from higher SG&A expense.

[0001069202-19-000008:mdna:112]
Corporate and Other

[0001069202-19-000008:mdna:113]
Corporate and other expenses decreased by $8 million in 2017 primarily due from lower incentive compensation with a partial offset from general wage inflation and information technology investments.

[0001069202-19-000008:mdna:114]
Accounting for Futures Contracts

[0001069202-19-000008:mdna:115]
Realized gains and losses on settled futures contracts are a component of segment profit (loss). Unrealized gains and losses on unsettled futures contracts are excluded from segment profit (loss) as they are subject to changes in fair value until their settlement date.  Both realized and unrealized gains and losses on futures contracts are a component of Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.  See Note 9 of the Notes to Consolidated Financial Statements for more information on our derivatives and Note 20 of the Notes to the Consolidated Financial Statements for more information on our segments and for a reconciliation of segment profit to operating income.

[0001069202-19-000008:mdna:116]
Liquidity and Capital Resources

[0001069202-19-000008:mdna:117]
Our working capital and capital expenditure requirements are generally met through internally generated funds, bank lines of credit and an asset securitization arrangement.  Working capital needs are generally greater in the first and second quarters due to the seasonal nature of our business cycle.

[0001069202-19-000008:mdna:118]
Statement of Cash Flows

[0001069202-19-000008:mdna:119]
The following table summarizes our cash flow activity for the years ended December 31, 2018, 2017 and 2016 (in millions):

[0001069202-19-000008:mdna:120]
|  | 2018 |  | 2017 |  | 2016 |
| Net cash provided by operating activities | $ | 495.5 |  |  | $ | 325.1 |  |  | $ | 373.9 |  |
| Net cash provided by (used in) investing activities | 30.5 |  |  | (98.1 | ) |  | (84.1 | ) |
| Net cash used in financing activities | $ | (537.8 | ) |  | $ | (218.3 | ) |  | $ | (274.6 | ) |

[0001069202-19-000008:mdna:121]
Net Cash Provided by Operating Activities - Net cash provided by operating activities increased $170 million to $496 million in 2018 compared to $325 million in 2017.  This increase was primarily attributable to the decrease in working capital and an increase in net income.

[0001069202-19-000008:mdna:122]
Net Cash Provided by (Used in) Investing Activities - Capital expenditures were $95 million, $98 million and $84 million in 2018, 2017 and 2016, respectively.  Capital expenditures in 2018 were primarily related to expansion of our manufacturing capacity and equipment and investments in systems and software to support the overall enterprise.  Net proceeds of $115 million were provided by the sale of our businesses in Australia and Asia along with the related property as well as the sale of our business in South America.

[0001069202-19-000008:mdna:123]
Net Cash Used in Financing Activities - Net cash used in financing activities increased to $538 million in 2018 from $218 million in 2017.  The increase in cash used in financing activities is largely due to an increase in share repurchases.  During 2018 we repurchased $450 million of shares as compared to $250 million of shares in 2017.  We also returned $94 million to shareholders through dividend payments. For additional information on share repurchases, refer to Note 16 in the Notes to the Consolidated Financial Statements.

[0001069202-19-000008:mdna:124]
Debt Position

[0001069202-19-000008:mdna:125]
The following table details our lines of credit and financing arrangements as of December 31, 2018 (in millions):

[0001069202-19-000008:mdna:126]
|  | Outstanding Borrowings |
| Current maturities of long-term debt: |  |
| Asset Securitization Program (1) | $ | 268.0 |  |
| Capital lease obligations | 3.5 |  |
| Domestic credit facility (2) | 30.0 |  |
| Debt issuance costs | (0.7 | ) |
| Total current maturities of long-term debt | $ | 300.8 |  |
| Long-term debt: |  |
| Capital lease obligations | $ | 15.7 |  |
| Domestic credit facility (2) | 378.0 |  |
| Senior unsecured notes | 350.0 |  |
| Debt issuance costs | (3.2 | ) |
| Total long-term debt | 740.5 |  |
| Total debt | $ | 1,041.3 |  |

[0001069202-19-000008:mdna:127]
| (1) | The maximum securitization amount ranges from $225.0 million to $380.0 million, depending on the period. The maximum capacity of the Asset Securitization Program (“ASP”) is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined under the ASP. |

[0001069202-19-000008:mdna:128]
| (2) | The available future borrowings on our domestic credit facility are $429.5 million after being reduced by the outstanding borrowings and $2.5 million in outstanding standby letters of credit. We also had $30.7 million in outstanding standby letters of credit outside of the domestic credit facility as of December 31, 2018. In January 2019, we increased the maximum revolving credit commitments by $350 million as permitted under the Domestic Credit Facility bringing the total maximum revolving credit commitments to $1.0 billion. |

[0001069202-19-000008:mdna:129]
Financial Leverage

[0001069202-19-000008:mdna:130]
We periodically review our capital structure, including our primary bank facility, to ensure the appropriate levels of liquidity and leverage and to take advantage of favorable interest rate environments or other market conditions.  We consider various other financing alternatives and may, from time to time, access the capital markets.

[0001069202-19-000008:mdna:131]
As of December 31, 2018, our senior credit ratings were Baa3 with a stable outlook, and BBB with a stable outlook, by Moody’s Investors Service, Inc. (“Moody’s”) and Standard & Poor’s Rating Group (“S&P”), respectively.  The security ratings are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal at any time by the assigning rating agency.  Each rating should be evaluated independently of any other rating.  Our goal is to maintain investment grade ratings from Moody’s and S&P to help ensure the capital markets remain available to us.

[0001069202-19-000008:mdna:132]
Our debt-to-total-capital ratio increased to 116.8% at December 31, 2018 compared to 95.2% at December 31, 2017.  The increase in the ratio in 2018 is primarily due to the decrease in equity.  We evaluate our debt-to-EBITDA ratio in order to determine the appropriate targets for share repurchases under our share repurchase programs.

[0001069202-19-000008:mdna:133]
Liquidity

[0001069202-19-000008:mdna:134]
We believe our cash and cash equivalents of $46 million, future cash generated from operations and available future borrowings are sufficient to fund our operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents as of December 31, 2018 was $29 million of cash held in foreign locations, although that amount can fluctuate significantly depending on the timing of cash receipts and payments.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we generally do not have the need or intent to repatriate those funds to the United States.  An actual repatriation in the future from our non-U.S. subsidiaries could be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-19-000008:mdna:135]
No contributions are required to be made to our U.S. defined benefit plans in 2019. We made $21 million in total contributions to pension plans in 2018.

[0001069202-19-000008:mdna:136]
On May 16, 2018, our Board of Directors approved a 25% increase in our quarterly dividend on common stock from $0.51 to $0.64 per share effective with the May 2018 dividend payment.  Dividend payments were $94 million in 2018 compared to $80 million in 2017, with the increase due primarily to the increase in dividends approved by the Board of Directors.

[0001069202-19-000008:mdna:137]
We also continued to increase shareholder value through our share repurchase programs.  We returned $450 million to our investors through share repurchases in 2018 and expect to return another $350 million in 2019.  An additional $446 million of repurchases are still available under the programs at December 31, 2018.

[0001069202-19-000008:mdna:138]
We expect capital expenditures of approximately $215 million in 2019, including $115 million to complete the reconstruction of the Marshalltown, Iowa manufacturing facility.  We expect the reconstruction of our Iowa facility to be funded by insurance proceeds.

[0001069202-19-000008:mdna:139]
Financial Covenants related to our Debt

[0001069202-19-000008:mdna:140]
Our domestic credit facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage.  Other covenants contained in the domestic credit facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions.  The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio.  The required ratios under our domestic credit facility are detailed below:

[0001069202-19-000008:mdna:141]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |

[0001069202-19-000008:mdna:142]
Our domestic credit facility contains customary events of default. These events of default include nonpayment of principal or other amounts, material inaccuracy of representations and warranties, breach of covenants, default on certain other indebtedness or receivables securitizations (cross default), certain voluntary and involuntary bankruptcy events and the occurrence of a change in control. A cross default under our credit facility could occur if:

[0001069202-19-000008:mdna:143]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or |

[0001069202-19-000008:mdna:144]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million, or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-19-000008:mdna:145]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a cross default). If a cross default under our domestic credit facility, our senior unsecured notes, or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-19-000008:mdna:146]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our domestic credit facility and accelerate amounts due under our domestic credit facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).

[0001069202-19-000008:mdna:147]
In the event of a credit rating downgrade below investment grade resulting from a change of control, holders of our senior unsecured notes will have the right to require us to repurchase all or a portion of the senior unsecured notes at a repurchase price equal to 101% of the principal amount of the notes, plus accrued and unpaid interest, if any. The notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee payment by us of any indebtedness under our domestic credit facility.  The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.

[0001069202-19-000008:mdna:148]
As of December 31, 2018, we believe we were in compliance with all covenant requirements. Delaware law limits the ability to pay dividends to surplus or, if there is no surplus, out of net profits for the fiscal year in which the dividend is declared and/or the preceding fiscal year.  In addition, stock repurchases can only be made out of surplus and only if our capital would not be impaired.

[0001069202-19-000008:mdna:149]
Leasing Commitments

[0001069202-19-000008:mdna:150]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The agreement contains customary lease covenants and events of default as well as financial covenants consistent with our credit agreement and we believe we were in compliance with those covenants as of December 31, 2018.   We are in the process of finalizing the renewal of our lease that expires on March 1, 2019 and expect the terms and conditions to be similar to the existing lease.

[0001069202-19-000008:mdna:151]
In 2008, we expanded our Tifton, Georgia manufacturing facility using the proceeds from industrial development bonds (“IDBs”). We entered into a lease agreement with the owner of the property and the issuer of the IDBs, and through our lease payments fund the interest payments to investors in the IDBs. We also guaranteed the repayment of the IDBs and have outstanding letters of credit totaling $11.7 million to fund a potential repurchase of the IDBs in the event investors exercised their right to tender the IDBs to the trustee.  We had capital lease obligations of $11.7 million and $14.3 million related to these transactions as of December 31, 2018 and 2017, as we made $2.6 million of payments in 2018.

[0001069202-19-000008:mdna:152]
Refer to Note 11 in the Notes to the Consolidated Financial Statements for more details on our leasing commitments.

[0001069202-19-000008:mdna:153]
Off Balance Sheet Arrangements

[0001069202-19-000008:mdna:154]
In addition to the credit facilities, promissory notes and leasing commitments described above, we also lease real estate and machinery and equipment pursuant to operating leases that are not capitalized on the balance sheet, including high-turnover equipment such as autos and service vehicles and short-lived equipment such as personal computers.  Rent expense for these leases was $59 million, $58 million, and $58 million in 2018, 2017 and 2016, respectively.  Refer to Notes 11 and 24 of the Notes to the Consolidated Financial Statements for more information on our lease commitments and rent expense, respectively.

[0001069202-19-000008:mdna:155]
Contractual Obligations

[0001069202-19-000008:mdna:156]
Summarized below are our contractual obligations as of December 31, 2018 and their expected impact on our liquidity and cash flows in future periods (in millions):

[0001069202-19-000008:mdna:157]
|  | Payments Due by Period |
|  | Total |  | 1 Year or Less |  | 1 - 3 Years |  | 3 - 5 Years |  | More than 5 Years |
| Total long-term debt obligations (1) | $ | 1,045.2 |  |  | $ | 301.5 |  |  | $ | 381.9 |  |  | $ | 350.1 |  |  | $ | 11.7 |  |
| Estimated interest payments on debt obligations (2) | $ | 98.3 |  |  | 33.5 |  |  | 43.9 |  |  | 20.0 |  |  | 0.9 |  |
| Operating leases | 159.7 |  |  | 47.4 |  |  | 65.6 |  |  | 30.6 |  |  | 16.1 |  |
| Purchase obligations (3) | 27.2 |  |  | 27.2 |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 1,330.4 |  |  | $ | 409.6 |  |  | $ | 491.4 |  |  | $ | 400.7 |  |  | $ | 28.7 |  |

[0001069202-19-000008:mdna:158]
(1) Contractual obligations related to capital leases are included as part of long-term debt.

[0001069202-19-000008:mdna:159]
(2) Estimated interest payments are based on current contractual requirements and do not reflect seasonal changes in the balance of our domestic credit facility.

[0001069202-19-000008:mdna:160]
(3) Purchase obligations consist of inventory that is part of our third party logistics programs.

[0001069202-19-000008:mdna:161]
The table above does not include pension, post-retirement benefit and warranty liabilities because it is not certain when these liabilities will be funded.  For additional information regarding our contractual obligations, see Notes 11 and 12 of the Notes to the Consolidated Financial Statements.  See Note 13 of the Notes to the Consolidated Financial Statements for more information on our pension and post-retirement benefits obligations.

[0001069202-19-000008:mdna:162]
Fair Value Measurements

[0001069202-19-000008:mdna:163]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on a three-level hierarchy for fair value measurements.

[0001069202-19-000008:mdna:164]
The three-level fair value hierarchy for disclosure of fair value measurements is defined as follows:

[0001069202-19-000008:mdna:165]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-19-000008:mdna:166]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-19-000008:mdna:167]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-19-000008:mdna:168]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.

[0001069202-19-000008:mdna:169]
Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2018 and 2017, the measurement dates.

[0001069202-19-000008:mdna:170]
See Note 21 of the Notes to the Consolidated Financial Statements for more information on the assets and liabilities measured at fair value.

[0001069202-19-000008:mdna:171]
Market Risk

[0001069202-19-000008:mdna:172]
Commodity Price Risk

[0001069202-19-000008:mdna:173]
We enter into commodity futures contracts to stabilize prices expected to be paid for raw materials and parts containing high copper and aluminum content. These contracts are for quantities equal to or less than quantities expected to be consumed in future production.  Fluctuations in metal commodity prices impact the value of the futures contracts that we hold.  When metal commodity prices rise, the fair value of our futures contracts increases.  Conversely, when commodity prices fall, the fair value of our futures contracts decreases.  Information about our exposure to metal commodity price market risks and a sensitivity analysis related to our metal commodity hedges is presented below (in millions):

[0001069202-19-000008:mdna:174]
| Notional amount (pounds of aluminum and copper) | 19.4 |  |
| Carrying amount and fair value of net liability | $ | (10.8 | ) |
| Change in fair value from 10% change in forward prices | $ | 8.6 |  |

[0001069202-19-000008:mdna:175]
Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our commodity futures contracts.

[0001069202-19-000008:mdna:176]
Interest Rate Risk

[0001069202-19-000008:mdna:177]
Our results of operations can be affected by changes in interest rates due to variable rates of interest on our debt facilities, cash, cash equivalents and short-term investments.  A 10% adverse movement in the levels of interest rates across the entire yield curve would have resulted in an increase to pre-tax interest expense of approximately $2.7 million, $1.8 million and $2.0 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001069202-19-000008:mdna:178]
From time to time, we may use an interest rate swap hedging strategy to eliminate the variability of cash flows in a portion of our interest payments.  This strategy, when employed, allows us to fix a portion of our interest payments while also taking advantage of historically low interest rates.  As of December 31, 2018 and 2017, no interest rate swaps were in effect.

[0001069202-19-000008:mdna:179]
Foreign Currency Exchange Rate Risk

[0001069202-19-000008:mdna:180]
Our results of operations are affected by changes in foreign currency exchange rates.  Net sales and expenses in foreign currencies are translated into U.S. dollars for financial reporting purposes based on the average exchange rate for the period.  During 2018, 2017 and 2016, net sales from outside the U.S. represented 15.7%, 18.5% and 18.5% , respectively, of our total net sales.  For the years ended December 31, 2018 and 2017, foreign currency transaction gains and losses did not have a material impact to our results of operations.  A 10% change in foreign exchange rates would have had an estimated $2.1 million, $5.2  million and $4.0 million impact to net income for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001069202-19-000008:mdna:181]
We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.  By entering into forward contracts, we lock in exchange rates that would otherwise cause losses should the U.S. dollar appreciate and gains should the U.S. dollar depreciate.  Refer to Note 9 of the Notes to the Consolidated Financial Statements for additional information regarding our foreign currency forward contracts.

[0001069202-19-000008:mdna:182]
Critical Accounting Estimates

[0001069202-19-000008:mdna:183]
A critical accounting estimate is one that requires difficult, subjective or complex estimates and assessments and is fundamental to our results of operations and financial condition.  The following are our critical accounting estimates and describe how we develop our judgments, assumptions and estimates about future events and how such policies can impact our financial statements:

[0001069202-19-000008:mdna:184]
| • | Product warranties and product-related contingencies; and |

[0001069202-19-000008:mdna:185]
| • | Self-insurance expense. |

[0001069202-19-000008:mdna:186]
This discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in “Item 8. Financial Statements and Supplementary Data.”

[0001069202-19-000008:mdna:187]
Product Warranties and Product-Related Contingencies

[0001069202-19-000008:mdna:188]
The estimate of our liability for future warranty costs requires us to make assumptions about the amount, timing and nature of future product-related costs.  Some of the warranties we issue extend 10 years or more in duration and a relatively small adjustment to an assumption may have a significant impact on our overall liability.  We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and protect our brand.

[0001069202-19-000008:mdna:189]
We periodically review the assumptions used to determine the liabilities for product warranties and product-related contingencies and we adjust our assumptions based upon factors such as actual failure rates and cost experience.  Numerous factors could affect actual failure rates and cost experience, including the amount and timing of new product introductions, changes in manufacturing techniques or locations, components or suppliers used.  Should actual costs differ from our estimates, we may be required to adjust the liabilities and to record expense in future periods.  See Note 11 in the Notes to the Consolidated Financial Statements for more information on our product warranties and product-related contingencies.

[0001069202-19-000008:mdna:190]
Self-Insurance Expense

[0001069202-19-000008:mdna:191]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures.  Many of these plans have large deductibles and may also include per occurrence and annual aggregate limits.  As a result, we expect to incur costs related to these types of claims in future periods.

[0001069202-19-000008:mdna:192]
The estimates for self-insurance expense and liabilities involve assumptions about the amount, timing and nature of future claim costs.  We estimate these amounts actuarially based primarily on our historical claims information and industry factors and trends.  The amounts and timing of payments for future claims may vary depending on numerous factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience differ from historical rates, our liabilities may change.  The self-insurance liabilities as of December 31, 2018 represent the best estimate of the future payments to be made on reported and unreported losses.  See Note 11 in the Notes to the Consolidated Financial Statements for additional information on our self-insurance expense and liabilities.

[0001069202-19-000008:mdna:193]
Recent Accounting Pronouncements

[0001069202-19-000008:mdna:194]
See Note 2 in the Notes to the Consolidated Financial Statements for disclosure of recent accounting pronouncements and the potential impact on our financial statements and disclosures.
