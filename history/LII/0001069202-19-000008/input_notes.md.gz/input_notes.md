# LII notes — 0001069202-19-000008


## lii:EligibleAmountsAvailableAndBeneficialInterestsSoldTableTextBlock

[0001069202-19-000008:notes:1]
The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-19-000008:notes:2]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 290.0 |  |  | $ | 290.0 |  |
| Less: Beneficial interest transferred | (268.0 | ) |  | (276.0 | ) |
| Remaining amount available | $ | 22.0 |  |  | $ | 14.0 |  |


## lii:FinancialCovenantsLeverageAndInterestCoverageTableTextBlock

[0001069202-19-000008:notes:3]
The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-19-000008:notes:4]
| Consolidated Indebtedness to Adjusted EBITDA Ratio no greater than | 3.5 : 1.0 |
| Cash Flow to Interest Expense Ratio no less than | 3.0 : 1.0 |


## lii:ScheduleOfFairValueOfPerformanceShareUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-19-000008:notes:5]
The total fair value of performance share units distributed and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-19-000008:notes:6]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Fair value of performance share units distributed | $ | 21.1 |  |  | $ | 64.3 |  |  | $ | 39.4 |  |
| Realized tax benefits from tax deductions | $ | 5.3 |  |  | $ | 24.5 |  |  | $ | 15.0 |  |


## lii:ScheduleOfFairValueOfRestrictedStockUnitsAndRelatedTaxDeductionsTableTextBlock

[0001069202-19-000008:notes:7]
The total fair value of restricted stock units vested and the resulting tax deductions to realized tax benefits were as follows (in millions):

[0001069202-19-000008:notes:8]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Fair value of restricted stock units vested | $ | 9.7 |  |  | $ | 19.0 |  |  | $ | 17.0 |  |
| Realized tax benefits from tax deductions | 2.4 |  |  | 7.2 |  |  | 6.5 |  |


## lii:ScheduleOfIntrinsicValueAndTaxBenefitsRelatedToStockAppreciationRightsTableTextBlock

[0001069202-19-000008:notes:9]
The total intrinsic value of stock appreciation rights exercised and the resulting tax deductions to realize tax benefits were as follows (in millions):

[0001069202-19-000008:notes:10]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Intrinsic value of stock appreciation rights exercised | $ | 35.9 |  |  | $ | 25.1 |  |  | $ | 36.9 |  |
| Realized tax benefits from tax deductions | $ | 8.9 |  |  | $ | 9.6 |  |  | $ | 14.1 |  |


## lii:ScheduleOfShareBasedCompensationSharesAuthorizedUnderEquityInstrumentOtherThanOptionPlansByExercisePriceRangeTableTextBlock

[0001069202-19-000008:notes:11]
The following table summarizes information about stock appreciation rights outstanding as of December 31, 2018 (in millions, except per share data and years):

[0001069202-19-000008:notes:12]
|  |  | Stock Appreciation Rights Outstanding |  | Stock Appreciation Rights Exercisable |
| Range of Exercise Prices |  | Shares |  | Weighted-Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |  | Shares |  | Weighted-Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| $51.11 to $92.64 |  | 0.3 |  |  | 2.22 |  | $ | 37.8 |  |  | 0.3 |  |  | 2.22 |  | $ | 37.8 |  |
| $124.97 to $156.94 |  | 0.3 |  |  | 4.58 |  | $ | 24.1 |  |  | 0.3 |  |  | 4.48 |  | $ | 20.2 |  |
| $205.53 to $214.63 |  | 0.3 |  |  | 6.46 |  | $ | 3.0 |  |  | 0.1 |  |  | 6.00 |  | $ | 0.8 |  |


## lii:SummaryOfTargetAllocationPercentageOfAssetsTableTextBlock

[0001069202-19-000008:notes:13]
U.S. pension plan assets are invested according to the following targets:

[0001069202-19-000008:notes:14]
| Asset Category: | Target |
| U.S. equity | 25.0 | % |
| International equity | 15.0 | % |
| Fixed income | 60.0 | % |


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock

[0001069202-19-000008:notes:15]
Our weighted average borrowing rate on the facility was as follows:

[0001069202-19-000008:notes:16]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Weighted average borrowing rate | 3.74 | % |  | 2.76 | % |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001069202-19-000008:notes:17]
Condensed Consolidating Balance Sheets

[0001069202-19-000008:notes:18]
As of December 31, 2018

[0001069202-19-000008:notes:19]
(In millions)

[0001069202-19-000008:notes:20]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |
| Accounts and notes receivable, net | — |  |  | 44.3 |  |  | 428.4 |  |  | — |  |  | 472.7 |  |
| Inventories, net | — |  |  | 411.4 |  |  | 103.9 |  |  | (5.5 | ) |  | 509.8 |  |
| Other assets | 3.3 |  |  | 36.2 |  |  | 54.7 |  |  | (33.6 | ) |  | 60.6 |  |
| Total current assets | 5.1 |  |  | 507.3 |  |  | 616.1 |  |  | (39.1 | ) |  | 1,089.4 |  |
| Property, plant and equipment, net | — |  |  | 293.3 |  |  | 118.6 |  |  | (3.6 | ) |  | 408.3 |  |
| Goodwill | — |  |  | 166.1 |  |  | 20.5 |  |  | — |  |  | 186.6 |  |
| Investment in subsidiaries | 1,311.9 |  |  | 357.8 |  |  | (0.5 | ) |  | (1,669.2 | ) |  | — |  |
| Deferred income taxes | 1.4 |  |  | 54.4 |  |  | 23.4 |  |  | (12.2 | ) |  | 67.0 |  |
| Other assets, net | 1.5 |  |  | 48.1 |  |  | 17.8 |  |  | (1.5 | ) |  | 65.9 |  |
| Intercompany (payables) receivables, net | (715.5 | ) |  | 675.8 |  |  | 142.6 |  |  | (102.9 | ) |  | — |  |
| Total assets | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.8 |  |  | 268.6 |  |  | — |  |  | 300.8 |  |
| Accounts payable | 25.5 |  |  | 295.7 |  |  | 112.1 |  |  | — |  |  | 433.3 |  |
| Accrued expenses | 12.1 |  |  | 213.8 |  |  | 46.4 |  |  | — |  |  | 272.3 |  |
| Income taxes payable | (38.5 | ) |  | 40.6 |  |  | 50.8 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | 28.5 |  |  | 552.9 |  |  | 477.9 |  |  | (50.8 | ) |  | 1,008.5 |  |
| Long-term debt | 724.9 |  |  | 15.0 |  |  | 0.6 |  |  | — |  |  | 740.5 |  |
| Pensions | — |  |  | 75.1 |  |  | 7.7 |  |  | — |  |  | 82.8 |  |
| Other liabilities | 0.6 |  |  | 126.4 |  |  | 8.0 |  |  | — |  |  | 135.0 |  |
| Total liabilities | 754.0 |  |  | 769.4 |  |  | 494.2 |  |  | (50.8 | ) |  | 1,966.8 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders’ (deficit) equity | (149.6 | ) |  | 1,333.4 |  |  | 444.3 |  |  | (1,777.7 | ) |  | (149.6 | ) |
| Total liabilities and stockholders’ (deficit) equity | $ | 604.4 |  |  | $ | 2,102.8 |  |  | $ | 938.5 |  |  | $ | (1,828.5 | ) |  | $ | 1,817.2 |  |

[0001069202-19-000008:notes:21]
As of December 31, 2017

[0001069202-19-000008:notes:22]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| ASSETS |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net | — |  |  | 35.3 |  |  | 471.2 |  |  | — |  |  | 506.5 |  |
| Inventories, net | — |  |  | 355.7 |  |  | 131.9 |  |  | (3.4 | ) |  | 484.2 |  |
| Other assets | 16.2 |  |  | 23.1 |  |  | 67.5 |  |  | (28.4 | ) |  | 78.4 |  |
| Total current assets | 17.8 |  |  | 442.1 |  |  | 709.2 |  |  | (31.8 | ) |  | 1,137.3 |  |
| Property, plant and equipment, net | — |  |  | 257.6 |  |  | 144.4 |  |  | (4.2 | ) |  | 397.8 |  |
| Goodwill | — |  |  | 134.9 |  |  | 65.6 |  |  | — |  |  | 200.5 |  |
| Investment in subsidiaries | 1,257.7 |  |  | 365.8 |  |  | (0.6 | ) |  | (1,622.9 | ) |  | — |  |
| Deferred income taxes | 3.9 |  |  | 69.1 |  |  | 33.6 |  |  | (12.2 | ) |  | 94.4 |  |
| Other assets, net | 2.1 |  |  | 41.3 |  |  | 19.6 |  |  | (1.5 | ) |  | 61.5 |  |
| Intercompany (payables) receivables, net | (559.3 | ) |  | 554.7 |  |  | 107.4 |  |  | (102.8 | ) |  | — |  |
| Total assets | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 29.4 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 32.6 |  |
| Accounts payable | 21.3 |  |  | 228.0 |  |  | 99.3 |  |  | — |  |  | 348.6 |  |
| Accrued expenses | 3.1 |  |  | 209.4 |  |  | 57.8 |  |  | — |  |  | 270.3 |  |
| Income taxes payable | (64.5 | ) |  | 56.5 |  |  | 60.9 |  |  | (50.8 | ) |  | 2.1 |  |
| Total current liabilities | (10.7 | ) |  | 496.8 |  |  | 219.2 |  |  | (50.8 | ) |  | 654.5 |  |
| Long-term debt | 682.8 |  |  | 11.7 |  |  | 276.0 |  |  | — |  |  | 970.5 |  |
| Pensions | — |  |  | 74.7 |  |  | 9.8 |  |  | — |  |  | 84.5 |  |
| Other liabilities | — |  |  | 123.2 |  |  | 8.7 |  |  | — |  |  | 131.9 |  |
| Total liabilities | 672.1 |  |  | 706.4 |  |  | 513.7 |  |  | (50.8 | ) |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |  |
| Total stockholders’ equity (deficit) | 50.1 |  |  | 1,159.1 |  |  | 565.5 |  |  | (1,724.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 722.2 |  |  | $ | 1,865.5 |  |  | $ | 1,079.2 |  |  | $ | (1,775.4 | ) |  | $ | 1,891.5 |  |


## srt:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001069202-19-000008:notes:23]
Condensed Consolidating Statements of Cash Flows

[0001069202-19-000008:notes:24]
For the Year Ended December 31, 2018

[0001069202-19-000008:notes:25]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 53.7 |  |  | $ | 477.9 |  |  | $ | (36.1 | ) |  | $ | — |  |  | $ | 495.5 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Purchases of property, plant and equipment | — |  |  | (76.0 | ) |  | (19.2 | ) |  | — |  |  | (95.2 | ) |
| Net proceeds from sale of businesses and related property | — |  |  | 2.7 |  |  | 112.0 |  |  | — |  |  | 114.7 |  |
| Insurance recoveries received for property damage incurred from natural disaster | — |  |  | 10.9 |  |  | — |  |  | — |  |  | 10.9 |  |
| Net cash used in investing activities | — |  |  | (62.4 | ) |  | 92.9 |  |  | — |  |  | 30.5 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset securitization borrowings | — |  |  | — |  |  | 155.0 |  |  | — |  |  | 155.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (163.0 | ) |  | — |  |  | (163.0 | ) |
| Long-term debt payments | (30.0 | ) |  | (2.9 | ) |  | (0.1 | ) |  | — |  |  | (33.0 | ) |
| Borrowings from credit facility | 2,435.9 |  |  | — |  |  | — |  |  | — |  |  | 2,435.9 |  |
| Payments on credit facility | (2,365.0 | ) |  | — |  |  | — |  |  | — |  |  | (2,365.0 | ) |
| Proceeds from employee stock purchases | 3.3 |  |  | — |  |  | — |  |  | — |  |  | 3.3 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.9 | ) |  | — |  |  | — |  |  | — |  |  | (26.9 | ) |
| Repurchases of common stock | (450.2 | ) |  | — |  |  | — |  |  | — |  |  | (450.2 | ) |
| Intercompany debt | (14.5 | ) |  | 83.3 |  |  | (68.8 | ) |  | — |  |  | — |  |
| Intercompany financing activity | 487.8 |  |  | (508.5 | ) |  | 20.7 |  |  | — |  |  | — |  |
| Cash dividends paid | (93.9 | ) |  | — |  |  | — |  |  | — |  |  | (93.9 | ) |
| Net cash provided by (used in) financing activities | (53.5 | ) |  | (428.1 | ) |  | (56.2 | ) |  | — |  |  | (537.8 | ) |
| Increase (decrease) in cash and cash equivalents | 0.2 |  |  | (12.6 | ) |  | 0.6 |  |  | — |  |  | (11.8 | ) |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (10.1 | ) |  | — |  |  | (10.1 | ) |
| Cash and cash equivalents, beginning of year | 1.6 |  |  | 28.0 |  |  | 38.6 |  |  | — |  |  | 68.2 |  |
| Cash and cash equivalents, end of year | $ | 1.8 |  |  | $ | 15.4 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | 46.3 |  |

[0001069202-19-000008:notes:26]
For the Year Ended December 31, 2017

[0001069202-19-000008:notes:27]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 467.4 |  |  | $ | 31.1 |  |  | $ | (173.4 | ) |  | $ | — |  |  | $ | 325.1 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (70.7 | ) |  | (27.6 | ) |  | — |  |  | (98.3 | ) |
| Net cash used in investing activities | — |  |  | (70.6 | ) |  | (27.5 | ) |  | — |  |  | (98.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (1.5 | ) |  | — |  |  | (1.5 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 315.0 |  |  | — |  |  | 315.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (89.0 | ) |  | — |  |  | (89.0 | ) |
| Borrowings from credit facility | 2,376.5 |  |  | — |  |  | — |  |  | — |  |  | 2,376.5 |  |
| Long-term debt payments | (200.0 | ) |  | (0.3 | ) |  | (0.6 | ) |  | — |  |  | (200.9 | ) |
| Payments on credit facility | (2,265.5 | ) |  | — |  |  | — |  |  | — |  |  | (2,265.5 | ) |
| Payments of deferred financing costs | — |  |  | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Proceeds from employee stock purchases | 3.1 |  |  | — |  |  | — |  |  | — |  |  | 3.1 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.1 | ) |  | — |  |  | — |  |  | — |  |  | (26.1 | ) |
| Repurchases of common stock | (250.0 | ) |  | — |  |  | — |  |  | — |  |  | (250.0 | ) |
| Intercompany debt | 56.4 |  |  | (34.9 | ) |  | (21.5 | ) |  | — |  |  | — |  |
| Intercompany financing activity | (81.7 | ) |  | 85.6 |  |  | (3.9 | ) |  | — |  |  | — |  |
| Cash dividends paid | (79.7 | ) |  | — |  |  | — |  |  | — |  |  | (79.7 | ) |
| Net cash provided by (used in) financing activities | (467.0 | ) |  | 50.4 |  |  | 198.3 |  |  | — |  |  | (218.3 | ) |
| Increase (decrease) in cash and cash equivalents | 0.4 |  |  | 10.9 |  |  | (2.6 | ) |  | — |  |  | 8.7 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | 9.3 |  |  | — |  |  | 9.3 |  |
| Cash and cash equivalents, beginning of year | 1.2 |  |  | 17.1 |  |  | 31.9 |  |  | — |  |  | 50.2 |  |
| Cash and cash equivalents, end of year | $ | 1.6 |  |  | $ | 28.0 |  |  | $ | 38.6 |  |  | $ | — |  |  | $ | 68.2 |  |

[0001069202-19-000008:notes:28]
For the Year Ended December 31, 2016

[0001069202-19-000008:notes:29]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Cash flows from operating activities: | $ | 17.8 |  |  | $ | 218.5 |  |  | $ | 137.6 |  |  | $ | — |  |  | $ | 373.9 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Purchases of property, plant and equipment | — |  |  | (71.5 | ) |  | (12.8 | ) |  | — |  |  | (84.3 | ) |
| Net cash used in investing activities | — |  |  | (71.5 | ) |  | (12.6 | ) |  | — |  |  | (84.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |
| Short-term borrowings, net | — |  |  | — |  |  | (2.4 | ) |  | — |  |  | (2.4 | ) |
| Asset securitization borrowings | — |  |  | — |  |  | 145.0 |  |  | — |  |  | 145.0 |  |
| Asset securitization payments | — |  |  | — |  |  | (295.0 | ) |  | — |  |  | (295.0 | ) |
| Long-term debt borrowings | 350.0 |  |  | — |  |  | — |  |  | — |  |  | 350.0 |  |
| Borrowings from credit facility | 2,336.5 |  |  | — |  |  | — |  |  | — |  |  | 2,336.5 |  |
| Long-term debt payments | (57.5 | ) |  | (0.9 | ) |  | (0.4 | ) |  | — |  |  | (58.8 | ) |
| Payments on credit facility | (2,346.0 | ) |  | — |  |  | — |  |  | — |  |  | (2,346.0 | ) |
| Payments of deferred financing costs | (4.2 | ) |  | — |  |  | — |  |  | — |  |  | (4.2 | ) |
| Proceeds from employee stock purchases | 2.6 |  |  | — |  |  | — |  |  | — |  |  | 2.6 |  |
| Repurchases of common stock to satisfy employee withholding tax obligations | (33.3 | ) |  | — |  |  | — |  |  | — |  |  | (33.3 | ) |
| Repurchases of common stock | (300.0 | ) |  | — |  |  | — |  |  | — |  |  | (300.0 | ) |
| Intercompany debt | 30.0 |  |  | (65.8 | ) |  | 35.8 |  |  | — |  |  | — |  |
| Intercompany financing activity | 73.8 |  |  | (71.0 | ) |  | (2.8 | ) |  | — |  |  | — |  |
| Cash dividends paid | (69.0 | ) |  | — |  |  | — |  |  | — |  |  | (69.0 | ) |
| Net cash provided by (used in) financing activities | (17.1 | ) |  | (137.7 | ) |  | (119.8 | ) |  | — |  |  | (274.6 | ) |
| Increase (decrease) in cash and cash equivalents | 0.7 |  |  | 9.3 |  |  | 5.2 |  |  | — |  |  | 15.2 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (3.9 | ) |  | — |  |  | (3.9 | ) |
| Cash and cash equivalents, beginning of year | 0.5 |  |  | 7.8 |  |  | 30.6 |  |  | — |  |  | 38.9 |  |
| Cash and cash equivalents, end of year | $ | 1.2 |  |  | $ | 17.1 |  |  | $ | 31.9 |  |  | $ | — |  |  | $ | 50.2 |  |


## srt:ScheduleOfCondensedIncomeStatementTableTextBlock

[0001069202-19-000008:notes:30]
Condensed Consolidating Statements of Operations and Comprehensive Income

[0001069202-19-000008:notes:31]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,473.2 |  |  | $ | 1,129.6 |  |  | $ | (718.9 | ) |  | $ | 3,883.9 |  |
| Cost of goods sold | — |  |  | 2,500.6 |  |  | 988.7 |  |  | (716.6 | ) |  | 2,772.7 |  |
| Gross profit | — |  |  | 972.6 |  |  | 140.9 |  |  | (2.3 | ) |  | 1,111.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 555.3 |  |  | 53.6 |  |  | (0.7 | ) |  | 608.2 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 5.4 |  |  | 6.3 |  |  | (0.3 | ) |  | 13.4 |  |
| Restructuring charges | — |  |  | 1.1 |  |  | 1.9 |  |  | — |  |  | 3.0 |  |
| Pension settlement | — |  |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 40.3 |  |  | (13.3 | ) |  | — |  |  | 27.0 |  |
| Insurance proceeds for lost profits | — |  |  | (27.4 | ) |  | — |  |  | — |  |  | (27.4 | ) |
| Gain from insurance recoveries, net of losses incurred | — |  |  | (10.9 | ) |  | — |  |  | — |  |  | (10.9 | ) |
| Income from equity method investments | (367.4 | ) |  | (70.3 | ) |  | (9.9 | ) |  | 435.6 |  |  | (12.0 | ) |
| Operating income | 365.4 |  |  | 479.1 |  |  | 101.9 |  |  | (436.9 | ) |  | 509.5 |  |
| Interest expense, net | 9.0 |  |  | 18.5 |  |  | 10.8 |  |  | — |  |  | 38.3 |  |
| Other expense (income), net | — |  |  | 1.5 |  |  | 1.8 |  |  | — |  |  | 3.3 |  |
| Income from continuing operations before income taxes | 356.4 |  |  | 459.1 |  |  | 89.3 |  |  | (436.9 | ) |  | 467.9 |  |
| Provision for income taxes | (2.6 | ) |  | 92.1 |  |  | 18.0 |  |  | 0.1 |  |  | 107.6 |  |
| Income from continuing operations | 359.0 |  |  | 367.0 |  |  | 71.3 |  |  | (437.0 | ) |  | 360.3 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (1.3 | ) |  | — |  |  | (1.3 | ) |
| Net income | $ | 359.0 |  |  | $ | 367.0 |  |  | $ | 70.0 |  |  | $ | (437.0 | ) |  | $ | 359.0 |  |
| Other comprehensive (loss) income | $ | (15.4 | ) |  | $ | (15.3 | ) |  | $ | (0.7 | ) |  | $ | — |  |  | $ | (31.4 | ) |
| Comprehensive Income | $ | 343.6 |  |  | $ | 351.7 |  |  | $ | 69.3 |  |  | $ | (437.0 | ) |  | $ | 327.6 |  |

[0001069202-19-000008:notes:32]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net sales | $ | — |  |  | $ | 3,295.8 |  |  | $ | 1,144.2 |  |  | $ | (600.4 | ) |  | $ | 3,839.6 |  |
| Cost of goods sold | — |  |  | 2,359.6 |  |  | 953.6 |  |  | (598.8 | ) |  | 2,714.4 |  |
| Gross profit | — |  |  | 936.2 |  |  | 190.6 |  |  | (1.6 | ) |  | 1,125.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 553.6 |  |  | 85.0 |  |  | (0.9 | ) |  | 637.7 |  |
| Losses (gains) and other expenses, net | 2.0 |  |  | 3.3 |  |  | 1.9 |  |  | (0.1 | ) |  | 7.1 |  |
| Restructuring charges | — |  |  | 2.1 |  |  | 1.1 |  |  | — |  |  | 3.2 |  |
| Loss (gain), net on sale of businesses and related property | — |  |  | 1.1 |  |  | — |  |  | — |  |  | 1.1 |  |
| (Income) loss from equity method investments | (324.3 | ) |  | (74.9 | ) |  | (14.5 | ) |  | 395.3 |  |  | (18.4 | ) |
| Operational income | 322.3 |  |  | 451.0 |  |  | 117.1 |  |  | (395.9 | ) |  | 494.5 |  |
| Interest expense, net | 26.9 |  |  | (2.7 | ) |  | 6.4 |  |  | — |  |  | 30.6 |  |
| Other income, net | — |  |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 295.4 |  |  | 453.7 |  |  | 110.8 |  |  | (395.9 | ) |  | 464.0 |  |
| Provision for income taxes | (10.3 | ) |  | 136.2 |  |  | 31.2 |  |  | (0.2 | ) |  | 156.9 |  |
| Income from continuing operations | 305.7 |  |  | 317.5 |  |  | 79.6 |  |  | (395.7 | ) |  | 307.1 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Net income | $ | 305.7 |  |  | $ | 317.5 |  |  | $ | 78.2 |  |  | $ | (395.7 | ) |  | $ | 305.7 |  |
| Other comprehensive income | $ | 1.7 |  |  | $ | 5.5 |  |  | $ | 30.5 |  |  | $ | — |  |  | $ | 37.7 |  |
| Comprehensive income | $ | 307.4 |  |  | $ | 323.0 |  |  | $ | 108.7 |  |  | $ | (395.7 | ) |  | $ | 343.4 |  |

[0001069202-19-000008:notes:33]
| (Amounts in millions) | Parent |  | GuarantorSubsidiaries |  | Non-GuarantorSubsidiaries |  | Eliminations |  | Consolidated |
| Net Sales | $ | — |  |  | $ | 3,117.6 |  |  | $ | 728.0 |  |  | $ | (204.0 | ) |  | $ | 3,641.6 |  |
| Cost of goods sold | — |  |  | 2,203.8 |  |  | 564.5 |  |  | (203.2 | ) |  | 2,565.1 |  |
| Gross profit | — |  |  | 913.8 |  |  | 163.5 |  |  | (0.8 | ) |  | 1,076.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | — |  |  | 524.3 |  |  | 96.7 |  |  | — |  |  | 621.0 |  |
| (Gains) losses and other expenses, net | (3.3 | ) |  | 9.7 |  |  | 5.1 |  |  | (0.2 | ) |  | 11.3 |  |
| Restructuring charges | — |  |  | 1.9 |  |  | (0.1 | ) |  | — |  |  | 1.8 |  |
| Pension settlement | — |  |  | 30.5 |  |  | 0.9 |  |  | — |  |  | 31.4 |  |
| (Income) loss from equity method investments | (292.4 | ) |  | (40.7 | ) |  | (14.4 | ) |  | 329.1 |  |  | (18.4 | ) |
| Operational income | 295.7 |  |  | 388.1 |  |  | 75.3 |  |  | (329.7 | ) |  | 429.4 |  |
| Interest expense, net | 24.4 |  |  | (2.2 | ) |  | 4.8 |  |  | — |  |  | 27.0 |  |
| Other income, net | — |  |  | — |  |  | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Income from continuing operations before income taxes | 271.3 |  |  | 390.3 |  |  | 70.8 |  |  | (329.7 | ) |  | 402.7 |  |
| Provision for income taxes | (6.5 | ) |  | 108.2 |  |  | 22.6 |  |  | (0.2 | ) |  | 124.1 |  |
| Income from continuing operations | 277.8 |  |  | 282.1 |  |  | 48.2 |  |  | (329.5 | ) |  | 278.6 |  |
| Loss from discontinued operations | — |  |  | — |  |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Net income | $ | 277.8 |  |  | $ | 282.1 |  |  | $ | 47.4 |  |  | $ | (329.5 | ) |  | $ | 277.8 |  |
| Other comprehensive income (loss) | $ | 14.0 |  |  | $ | 8.5 |  |  | $ | (14.2 | ) |  | $ | 1.3 |  |  | $ | 9.6 |  |
| Comprehensive Income | $ | 291.8 |  |  | $ | 290.6 |  |  | $ | 33.2 |  |  | $ | (328.2 | ) |  | $ | 287.4 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001069202-19-000008:notes:34]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001069202-19-000008:notes:35]
For the Years Ended December 31, 2018, 2017 and 2016

[0001069202-19-000008:notes:36]
|  | Balance at beginning of year |  | Additions charged to cost and expenses |  | Write-offs |  | Recoveries |  | Other |  | Balance at end of year |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.3 |  |  | $ | 2.4 |  |  | $ | (2.7 | ) |  | $ | 0.9 |  |  | $ | (0.2 | ) |  | $ | 6.7 |  |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 6.7 |  |  | $ | 3.9 |  |  | $ | (5.6 | ) |  | $ | 0.9 |  |  | $ | — |  |  | $ | 5.9 |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 5.9 |  |  | $ | 4.8 |  |  | $ | (3.7 | ) |  | $ | 0.6 |  |  | $ | (1.3 | ) |  | $ | 6.3 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001069202-19-000008:notes:37]
Accrued Expenses:

[0001069202-19-000008:notes:38]
The significant components of Accrued expenses are presented below (in millions):

[0001069202-19-000008:notes:39]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Accrued rebates and promotions | $ | 70.8 |  |  | $ | 70.3 |  |
| Accrued compensation and benefits | 69.0 |  |  | 80.7 |  |
| Accrued warranties | 37.9 |  |  | 34.8 |  |
| Accrued sales, use, property and VAT taxes | 20.7 |  |  | 21.6 |  |
| Deferred income | 13.0 |  |  | 7.3 |  |
| Derivative contracts | 10.2 |  |  | 1.4 |  |
| Accrued asbestos reserves | 9.7 |  |  | 8.5 |  |
| Self insurance reserves | 6.0 |  |  | 7.3 |  |
| Other | 35.0 |  |  | 38.4 |  |
| Total Accrued expenses | $ | 272.3 |  |  | $ | 270.3 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001069202-19-000008:notes:40]
Supplemental Information:

[0001069202-19-000008:notes:41]
Below is information about expenses included in our Consolidated Statements of Operations (in millions):

[0001069202-19-000008:notes:42]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Research and development | $ | 72.2 |  |  | $ | 73.6 |  |  | $ | 64.6 |  |
| Advertising, promotions and marketing (1) | 42.5 |  |  | 45.0 |  |  | 41.0 |  |
| Cooperative advertising expenditures (2) | 16.8 |  |  | 18.6 |  |  | 14.7 |  |
| Rent expense | 58.5 |  |  | 57.7 |  |  | 57.9 |  |

[0001069202-19-000008:notes:43]
(1) Cooperative advertising expenditures were not included in these amounts.

[0001069202-19-000008:notes:44]
(2) Cooperative advertising expenditures were included in Selling, general and administrative expenses in the Consolidated Statements of Operations.

[0001069202-19-000008:notes:45]
Interest Expense, net

[0001069202-19-000008:notes:46]
The components of Interest expense, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-19-000008:notes:47]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest | $ | 39.1 |  |  | $ | 32.1 |  |  | $ | 28.1 |  |
| Interest income | 0.8 |  |  | 1.5 |  |  | 1.1 |  |
| Interest expense, net | $ | 38.3 |  |  | $ | 30.6 |  |  | $ | 27.0 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001069202-19-000008:notes:48]
Cash and Cash Equivalents

[0001069202-19-000008:notes:49]
We consider all highly liquid temporary investments with original maturity dates of three months or less to be cash equivalents.  Cash and cash equivalents consisted primarily of bank deposits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001069202-19-000008:notes:50]
Commitments and Contingencies:

[0001069202-19-000008:notes:51]
Leases

[0001069202-19-000008:notes:52]
We lease certain real and personal property under non-cancelable operating leases.  Some of our lease agreements contain rent escalation clauses (including index-based escalations), rent holidays, capital improvement funding or other lease concessions.  We recognize our minimum rental expense on a straight-line basis.  We amortize this expense over the term of the lease beginning with the date of initial possession, which is the date we enter the leased space and begin to make improvements in preparation for its intended use.

[0001069202-19-000008:notes:53]
Future annual minimum lease payments and capital lease commitments as of December 31, 2018 were as follows (in millions):

[0001069202-19-000008:notes:54]
|  | Operating Leases |  | Capital Leases |
| 2019 | $ | 47.4 |  |  | $ | 6.6 |  |
| 2020 | 38.4 |  |  | 5.4 |  |
| 2021 | 27.2 |  |  | 3.8 |  |
| 2022 | 17.9 |  |  | 2.1 |  |
| 2023 | 12.7 |  |  | 0.9 |  |
| Thereafter | 16.1 |  |  | 12.8 |  |
| Total minimum lease payments | $ | 159.7 |  |  | $ | 31.6 |  |
| Less amount representing interest |  |  | 2.1 |  |
| Present value of minimum payments |  |  | $ | 29.5 |  |

[0001069202-19-000008:notes:55]
On March 22, 2013, we entered into an agreement with a financial institution to renew the lease of our corporate headquarters in Richardson, Texas for a term of approximately six years through March 1, 2019 (the “Lake Park Renewal”).  The leased property consists of an office building of approximately 192,000 square feet, land and related improvements.  During the lease term, the Lake Park Renewal requires us to pay base rent in quarterly installments, payable in arrears.  At the end of the lease term, we must do one of the following: (i) purchase the property for $41.2 million; (ii) vacate the property and return it in good condition; (iii) arrange for the sale of the leased property to a third party; or (iv) renew the lease under mutually agreeable terms.  If we elect to sell the property to a third party and the sales proceeds are less than the lease balance, we must pay any such deficit to the financial institution.  Any such deficit payment cannot exceed 86% of the lease balance.  The Lake Park Renewal is classified as an operating lease and its future annual minimum lease payments are included in the table above. We are in the process of finalizing the renewal of our lease that expires on March 1, 2019 and expect the terms and conditions to be similar to the existing lease.

[0001069202-19-000008:notes:56]
Our obligations under the Lake Park Renewal are secured by a pledge of our interest in the leased property.  The Lake Park Renewal contains customary lease covenants and events of default as well as events of default if (i) indebtedness of $75 million or more is not paid when due, (ii) there is a change of control or (iii) we fail to comply with certain covenants incorporated from our existing credit facility agreement.  We believe we were in compliance with these financial covenants as of December 31, 2018.

[0001069202-19-000008:notes:57]
Environmental

[0001069202-19-000008:notes:58]
Environmental laws and regulations in the locations we operate can potentially impose obligations to remediate hazardous substances at our properties,  properties formerly owned or operated by us, and facilities to which we have sent or send waste for treatment or disposal.  We are aware of contamination at some facilities; however, we do not believe that any future remediation  related to those facilities will be material to our results of operations.  Total environmental accruals are included Accrued expenses and Other liabilities on the accompanying Consolidated Balance Sheets.

[0001069202-19-000008:notes:59]
Future environmental costs are estimates and may be subject to change due to changes in environmental remediation regulations, technology or site-specific requirements.

[0001069202-19-000008:notes:60]
Product Warranties and Product Related Contingencies

[0001069202-19-000008:notes:61]
We incur the risk of liability for claims related to the installation and service of heating and air conditioning products, and we maintain liabilities for those claims that we self-insure.  We are involved in various claims and lawsuits related to our products.  Our product liability insurance policies have limits that, if exceeded, may result in substantial costs that could have an adverse effect on our results of operations.  In addition, warranty claims and certain product liability claims are not covered by our product liability insurance.

[0001069202-19-000008:notes:62]
Total product warranty liabilities related to continuing operations are included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000008:notes:63]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Accrued expenses | $ | 37.9 |  |  | $ | 34.8 |  |
| Other liabilities | 73.7 |  |  | 75.1 |  |
| Total product warranty liabilities | $ | 111.6 |  |  | $ | 109.9 |  |

[0001069202-19-000008:notes:64]
The changes in product warranty liabilities related to continuing operations for the years ended December 31, 2018 and 2017 were as follows (in millions):

[0001069202-19-000008:notes:65]
| Total warranty liability as of December 31, 2016 | $ | 101.1 |  |
| Payments made in 2017 | (28.8 | ) |
| Changes resulting from issuance of new warranties | 41.1 |  |
| Changes in estimates associated with pre-existing liabilities | (4.8 | ) |
| Changes in foreign currency translation rates and other | 1.3 |  |
| Total warranty liability as of December 31, 2017 | $ | 109.9 |  |
| Payments made in 2018 | (31.6 | ) |
| Changes resulting from issuance of new warranties | 36.8 |  |
| Changes in estimates associated with pre-existing liabilities | (1.5 | ) |
| Changes in foreign currency translation rates and other | (0.8 | ) |
| Warranty liability from divestitures | (1.2 | ) |
| Total warranty liability as of December 31, 2018 | $ | 111.6 |  |

[0001069202-19-000008:notes:66]
We have incurred, and will likely continue to incur, product costs not covered by insurance or our suppliers’ warranties, which are not included in the table above.  Also, to satisfy our customers and protect our brands, we have repaired or replaced installed products experiencing quality-related issues, and will likely continue such repairs and replacements.

[0001069202-19-000008:notes:67]
Self-Insurance

[0001069202-19-000008:notes:68]
We use a combination of third-party insurance and self-insurance plans to provide protection against claims relating to workers’ compensation/employers’ liability, general liability, product liability, auto liability, auto physical damage and other exposures.  We use large deductible insurance plans, written through third-party insurance providers, for workers’ compensation/employers’ liability, general liability, product liability and auto liability.  We also carry umbrella or excess liability insurance for all third-party and self-insurance plans, except for directors’ and officers’ liability, property damage and certain other insurance programs.    For directors’ and officers’ liability, property damage and certain other exposures, we use third-party insurance plans that may include per occurrence and annual aggregate limits.  We believe the deductibles and liability limits for all of our insurance policies are appropriate for our business and are adequate for companies of our size in our industry.

[0001069202-19-000008:notes:69]
We maintain safety and manufacturing programs that are designed to remove risk, improve the effectiveness of our business processes and reduce the likelihood and significance of our various retained and insured risks.  In recent years, our actual claims experience has collectively trended favorably and, as a result, both self-insurance expense and the related liability have decreased.

[0001069202-19-000008:notes:70]
Total self-insurance liabilities were included in the following captions on the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000008:notes:71]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Accrued expenses | $ | 6.0 |  |  | $ | 7.3 |  |
| Other liabilities | 19.5 |  |  | 21.6 |  |
| Total self-insurance liabilities | $ | 25.5 |  |  | $ | 28.9 |  |

[0001069202-19-000008:notes:72]
Litigation

[0001069202-19-000008:notes:73]
We are involved in a number of claims and lawsuits incident to the operation of our businesses. Insurance coverages are maintained and estimated costs are recorded for such claims and lawsuits, including costs to settle claims and lawsuits, based on experience involving similar matters and specific facts known.

[0001069202-19-000008:notes:74]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors, and are subject to policy limits, so we may have greater financial exposure for future settlements and judgments.  We currently estimate our probable liability for known cases is $9.7 million and it is recorded in Accrued expenses in the Consolidated Balance Sheet.  We currently estimate future asbestos-related litigation cases to be between $19.3 million and $34.6 million before consideration of probable insurance recoveries with all amounts in that range equally likely.  We have accrued $19.3 million in Other liabilities in the Consolidated Balance Sheet at December 31, 2018.  For the years ended December 31, 2018, 2017 and 2016, we recorded expense of $4.0 million, $3.5 million and $6.3 million, respectively, net of probable insurance recoveries, for known and future asbestos-related litigation and is recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations.

[0001069202-19-000008:notes:75]
In October 2016, we self-reported to the Securities and Exchange Commission (“SEC”) and the Department of Justice (“DOJ”) an alleged payment in the amount of 30,000 rubles (approximately US $475) to a Russian customs broker or official. Under the oversight of our Audit Committee, we initiated an investigation into this matter with the assistance of external legal counsel and external forensic accountants.The scope of the investigation was later expanded to include our operations in Poland and Ukraine. The investigation raised questions regarding possible irregularities with respect to non-compliance with customs documents and procedures related to these operations. We concluded our investigation and communicated our findings to the SEC and the DOJ. The  DOJ has declined to prosecute this matter and we continue to fully cooperate with the SEC regarding this matter.

[0001069202-19-000008:notes:76]
It is management’s opinion that none of these claims or lawsuits or any threatened litigation will have a material adverse effect, individually or in the aggregate, on our financial condition, results of operations or cash flows. Claims and lawsuits, however, involve uncertainties and it is possible that their eventual outcome could adversely affect our results of operations in a future period.

[0001069202-19-000008:notes:77]
Marshalltown Tornado and Recovery

[0001069202-19-000008:notes:78]
On July 19, 2018 our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado.  Insurance covers the repair or replacement of our assets that suffered damage or loss, and we are working closely with our insurance carriers and claims adjusters to ascertain the full amount of insurance recoveries due to us as a result of the damage and loss we incurred. Our insurance policies also provide business interruption coverage, including lost profits, and reimbursement for other expenses and costs that have been incurred relating to the damages and losses suffered. These costs and insurance recoveries are shown in Gain from insurance recoveries, net of losses incurred and Insurance proceeds for lost profits in the Consolidated Statements of Operations.

[0001069202-19-000008:notes:79]
The following table summarizes the gain from insurance recoveries, net of losses incurred:

[0001069202-19-000008:notes:80]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Insurance recoveries received | $ | 124.3 |  |
| Less losses and expenses incurred: |  |
| Site clean-up and remediation | 50.9 |  |
| Factory inefficiencies due to lower productivity | 7.4 |  |
| Write-off of property, plant and equipment | 4.2 |  |
| Write-off of inventory | 5.8 |  |
| Other | 17.7 |  |
| Total losses and expenses | $ | 86.0 |  |
| Gain from insurance recoveries | $ | 38.3 |  |
| Presentation in the Consolidated Statements of Operations: |  |
| Gain from insurance recoveries, net of losses incurred | $ | 10.9 |  |
| Insurance proceeds for lost profits | $ | 27.4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001069202-19-000008:notes:81]
Comprehensive Income:

[0001069202-19-000008:notes:82]
The following table provides information on items not reclassified in their entirety from AOCL to Net Income in the accompanying Consolidated Statements of Operations (in millions):

[0001069202-19-000008:notes:83]
|  |  | For the Years Ended December 31, |  |  |
| AOCL Component |  | 2018 |  | 2017 |  | Affected Line Item(s) in the Consolidated Statements of Operations |
| Gains/(Losses) on cash flow hedges: |  |  |  |  |  |  |
| Commodity derivative contracts |  | $ | 6.1 |  |  | $ | 13.7 |  |  | Cost of goods sold |
| Income tax benefit |  | (1.4 | ) |  | (5.0 | ) |  | Provision for income taxes |
| Net of tax |  | $ | 4.7 |  |  | $ | 8.7 |  |  |  |
| Defined Benefit Plan Items: |  |  |  |  |  |  |
| Pension and Post-Retirement Benefits costs |  | $ | (9.3 | ) |  | $ | (7.3 | ) |  | Cost of goods sold; Selling, general and administrative expenses |
| Income tax benefit |  | 2.3 |  |  | 2.8 |  |  | Provision for income taxes |
| Net of tax |  | $ | (7.0 | ) |  | $ | (4.5 | ) |  |  |
| Foreign currency translation adjustments: |  |  |  |  |  |  |
| Foreign currency adjustments upon sale of business |  | (27.9 | ) |  | — |  |  | Loss (gain), net on sale of businesses and related property |
| Net of tax |  | (27.9 | ) |  | — |  |  |  |
| Total reclassifications from AOCL |  | $ | (30.2 | ) |  | $ | 4.2 |  |  |  |

[0001069202-19-000008:notes:84]
The following tables provide information on changes in AOCL, by component (net of tax), for the years ended December 31, 2018 and 2017 (in millions):

[0001069202-19-000008:notes:85]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |
| Other comprehensive loss before reclassifications |  | (8.9 | ) |  | (1.8 | ) |  | (34.0 | ) |  | (16.9 | ) |  | (61.6 | ) |
| Amounts reclassified from AOCL |  | (4.7 | ) |  | — |  |  | 7.0 |  |  | 27.9 |  |  | 30.2 |  |
| Net other comprehensive (loss) income |  | (13.6 | ) |  | (1.8 | ) |  | (27.0 | ) |  | 11.0 |  |  | (31.4 | ) |
| Balance as of December 31, 2018 |  | $ | (6.2 | ) |  | $ | — |  |  | $ | (154.5 | ) |  | $ | (28.1 | ) |  | $ | (188.8 | ) |

[0001069202-19-000008:notes:86]
|  |  | Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Securities |  | Defined Benefit Plan Items |  | Foreign Currency Translation Adjustments |  | Total AOCL |
| Balance as of December 31, 2016 |  | $ | 5.6 |  |  | $ | 2.3 |  |  | $ | (130.0 | ) |  | $ | (73.0 | ) |  | $ | (195.1 | ) |
| Other comprehensive (loss) income before reclassifications |  | 10.5 |  |  | (0.5 | ) |  | (2.0 | ) |  | 33.9 |  |  | 41.9 |  |
| Amounts reclassified from AOCI |  | (8.7 | ) |  | — |  |  | 4.5 |  |  | — |  |  | (4.2 | ) |
| Net other comprehensive (loss) income |  | 1.8 |  |  | (0.5 | ) |  | 2.5 |  |  | 33.9 |  |  | 37.7 |  |
| Balance as of December 31, 2017 |  | $ | 7.4 |  |  | $ | 1.8 |  |  | $ | (127.5 | ) |  | $ | (39.1 | ) |  | $ | (157.4 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001069202-19-000008:notes:87]
Condensed Consolidating Financial Statements:

[0001069202-19-000008:notes:88]
The Company’s senior unsecured notes are unconditionally guaranteed by certain of the Company’s subsidiaries (the “Guarantor

[0001069202-19-000008:notes:89]
Subsidiaries”) and are not secured by our other subsidiaries (the “Non-Guarantor Subsidiaries”). The Guarantor Subsidiaries are 100% owned, all guarantees are full and unconditional, and all guarantees are joint and several. As a result of the guarantee arrangements, we are required to present condensed consolidating financial statements.

[0001069202-19-000008:notes:90]
The condensed consolidating financial statements reflect the investments in subsidiaries of the Company using the equity method of accounting.  The principal elimination entries eliminate investments in subsidiaries and intercompany balances and transactions.

[0001069202-19-000008:notes:91]
Condensed consolidating financial statements of the Company, its Guarantor Subsidiaries and Non-Guarantor Subsidiaries as of December 31, 2018 and December 31, 2017 and for the years ended December 31, 2018, 2017 and 2016 are shown on the following pages.


## us-gaap:ConsolidationPolicyTextBlock

[0001069202-19-000008:notes:92]
Principles of Consolidation

[0001069202-19-000008:notes:93]
The consolidated financial statements include the accounts of Lennox International Inc. and our majority-owned subsidiaries.  All intercompany transactions, profits and balances have been eliminated.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001069202-19-000008:notes:94]
Net contract assets (liabilities) consisted of the following:

[0001069202-19-000008:notes:95]
|  | December 31, 2018 |  | December 31, 2017 |  | $ Change |  | % Change |
| Contract assets | $ | 2.5 |  |  | $ | 2.1 |  |  | $ | 0.4 |  |  | 19.0 | % |
| Contract liabilities - current | (13.0 | ) |  | (7.3 | ) |  | (5.7 | ) |  | 78.1 | % |
| Contract liabilities - noncurrent | (5.9 | ) |  | (5.5 | ) |  | (0.4 | ) |  | 7.3 | % |
| Total | $ | (16.4 | ) |  | $ | (10.7 | ) |  | $ | (5.7 | ) |  |  |


## us-gaap:CostOfSalesPolicyTextBlock

[0001069202-19-000008:notes:96]
Cost of Goods Sold

[0001069202-19-000008:notes:97]
The principal elements of cost of goods sold are components, raw materials, factory overhead, labor, estimated costs of warranty expense and freight and distribution costs.


## us-gaap:DebtDisclosureTextBlock

[0001069202-19-000008:notes:98]
Lines of Credit and Financing Arrangements:

[0001069202-19-000008:notes:99]
The following tables summarize our outstanding debt obligations and the classification in the accompanying Consolidated Balance Sheets (in millions):

[0001069202-19-000008:notes:100]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Short-Term Debt: |  |  |  |
| Foreign obligations | $ | — |  |  | $ | 0.9 |  |
| Total short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Asset Securitization Program | $ | 268.0 |  |  | $ | — |  |
| Capital lease obligations | 3.5 |  |  | 3.2 |  |
| Domestic credit facility | 30.0 |  |  | 30.0 |  |
| Debt issuance costs | (0.7 | ) |  | (0.6 | ) |
| Total current maturities of long-term debt | $ | 300.8 |  |  | $ | 32.6 |  |
| Long-Term Debt: |  |  |  |
| Asset Securitization Program | $ | — |  |  | $ | 276.0 |  |
| Capital lease obligations | 15.7 |  |  | 11.9 |  |
| Domestic credit facility | 378.0 |  |  | 337.0 |  |
| Senior unsecured notes | 350.0 |  |  | 350.0 |  |
| Debt issuance costs | (3.2 | ) |  | (4.4 | ) |
| Total long-term debt | $ | 740.5 |  |  | $ | 970.5 |  |
| Total debt | $ | 1,041.3 |  |  | $ | 1,004.0 |  |

[0001069202-19-000008:notes:101]
As of December 31, 2018, the aggregate amounts of required principal payments on total debt were as follows (in millions):

[0001069202-19-000008:notes:102]
| 2019 | $ | 301.5 |  |
| 2020 | 32.6 |  |
| 2021 | 349.3 |  |
| 2022 | 0.1 |  |
| 2023 | 350.0 |  |
| Thereafter | 11.7 |  |

[0001069202-19-000008:notes:103]
Short-Term Debt

[0001069202-19-000008:notes:104]
Foreign Obligations

[0001069202-19-000008:notes:105]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $0.0 million and $0.9 million of foreign obligations as of December 31, 2018 and 2017, respectively, that were primarily borrowings under non-committed facilities.  Proceeds from these facilities were $40.3 million, $30.4 million and $28.4 million during the years ended December 31, 2018, 2017 and 2016, respectively. Repayments on the facilities were $41.2 million, $31.9 million and $30.8 million during the years ended December 31, 2018, 2017 and 2016, respectively.

[0001069202-19-000008:notes:106]
Asset Securitization Program

[0001069202-19-000008:notes:107]
Under the Asset Securitization Program (“ASP”), we are eligible to sell beneficial interests in a portion of our trade accounts receivable to a financial institution for cash. The ASP contains a provision whereby we retain the right to repurchase all of the outstanding beneficial interests transferred. As a result of the repurchase right, the transfer of the receivables under the ASP is not accounted for as a sale.  Accordingly, the cash received from the transfer of the beneficial interests in our trade accounts receivable is reflected as secured borrowings in the accompanying Consolidated Balance Sheets and proceeds received are included in Cash flows from financing activities in the accompanying Consolidated Statements of Cash Flows. Our continued involvement with the transferred assets includes servicing, collection and administration of the transferred beneficial interests.  The accounts receivable securitized under the ASP are high-quality domestic customer accounts that have not aged significantly.  The receivables represented by the retained interest that we service are exposed to the risk of loss for any uncollectible amounts in the pool of receivables transferred under the ASP.   The ASP will expire in November 2019 and we intend to renew the ASP prior to the expiration.

[0001069202-19-000008:notes:108]
The ASP provides for a maximum securitization amount ranging from $225.0 million to $380.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

[0001069202-19-000008:notes:109]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on either the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.70%. The average rates as of December 31, 2018 and 2017 were 3.27% and 2.60%, respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest transferred and is calculated at a 0.35% fixed rate throughout the term of the agreement.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

[0001069202-19-000008:notes:110]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and cross-default provisions with our Sixth Amended and Restated Credit Facility Agreement (“Domestic Credit Facility”), senior unsecured notes and any other indebtedness we may have over  $75.0 million.  The administrative agent under the ASP is also a participant in our Domestic Credit Facility.  The participating financial institutions have investment grade credit ratings.  As of December 31, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-19-000008:notes:111]
Long-Term Debt

[0001069202-19-000008:notes:112]
Domestic Credit Facility

[0001069202-19-000008:notes:113]
On August 30, 2016, we replaced an earlier credit facility with the Domestic Credit Facility, which consists of a $650.0 million unsecured revolving credit facility and a $250.0 million unsecured term loan and matures in August 2021 (the “Maturity Date”). Under our Domestic Credit Facility, we had outstanding borrowings of $408.0 million, of which $190.0 million was the term loan balance, as well as $2.5 million committed to standby letters of credit as of December 31, 2018.  Subject to covenant limitations, $429.5 million was available for future borrowings at that date. The unsecured term loan also matures on the Maturity Date and requires quarterly principal repayments of $7.5 million beginning in March 2017.  The revolving credit facility includes uncommitted subfacilities for swingline loans of up to $65.0 million and letters of credit up to $100.0 million. Additionally, at our request and subject to certain conditions, the commitments under the Domestic Credit Facility may be increased by a maximum of $350.0 million provided existing or new lenders agree to provide such additional commitments.  In January 2019, we increased the maximum revolving credit commitments by $350.0 million as permitted under the Domestic Credit Facility bringing the total maximum revolving credit commitments to $1.0 billion.

[0001069202-19-000008:notes:114]
Our Domestic Credit Facility is guaranteed by certain of our subsidiaries and contains financial covenants relating to leverage and interest coverage. Other covenants contained in the Domestic Credit Facility restrict, among other things, certain mergers, asset dispositions, guarantees, debt, liens, and affiliate transactions. The financial covenants require us to maintain a defined Consolidated Indebtedness to Adjusted EBITDA Ratio and a Cash Flow (defined as EBITDA minus capital expenditures) to Interest Expense Ratio. The required ratios under our Domestic Credit Facility are detailed below:

[0001069202-19-000008:notes:115]
Our Domestic Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Credit Facility could occur if:

[0001069202-19-000008:notes:116]
| • | We fail to pay any principal or interest when due on any other indebtedness or receivables securitization exceeding $75.0 million; or |

[0001069202-19-000008:notes:117]
| • | We are in default in the performance of, or compliance with any term of any other indebtedness or receivables securitization in an aggregate principal amount exceeding $75.0 million or any other condition exists which would give the holders the right to declare such indebtedness due and payable prior to its stated maturity. |

[0001069202-19-000008:notes:118]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a “cross default”). If a cross default under the Domestic Credit Facility, our senior unsecured notes, our lease of our corporate headquarters in Richardson, Texas (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.

[0001069202-19-000008:notes:119]
If any event of default occurs and is continuing, the administrative agent, or lenders with a majority of the aggregate commitments may require the administrative agent to, terminate our right to borrow under our Domestic Credit Facility and accelerate amounts due under our Domestic Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate). As of December 31, 2018, we believe we were in compliance with all covenant requirements.

[0001069202-19-000008:notes:120]
Senior Unsecured Notes

[0001069202-19-000008:notes:121]
We issued $350.0 million of senior unsecured notes in November 2016 (the “Notes”) which will mature on November 15, 2023 with interest being paid on May 15 and November 15 at 3.00% per annum semiannually. The Notes are guaranteed, on a senior unsecured basis, by each of our subsidiaries that guarantee indebtedness under our Domestic Credit Facility.  The indenture governing the Notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; and enter into certain mergers, consolidations and transfers of substantially all of our assets. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of December 31, 2018, we believe we were in compliance with all covenant requirements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001069202-19-000008:notes:122]
Derivatives:

[0001069202-19-000008:notes:123]
Objectives and Strategies for Using Derivative Instruments

[0001069202-19-000008:notes:124]
Commodity Price Risk.  We utilize a cash flow hedging program to mitigate our exposure to volatility in the prices of metal commodities used in our production processes.  Our hedging program includes the use of futures contracts to lock in prices, and as a result, we are subject to derivative losses should the metal commodity prices decrease and gains should the prices increase.  We utilize a dollar cost averaging strategy so that a higher percentage of commodity price exposures are hedged near-term with lower percentages hedged at future dates.  This strategy allows for protection against near-term price volatility while allowing us to adjust to market price movements over time.

[0001069202-19-000008:notes:125]
Interest Rate Risk.  A portion of our debt bears interest at variable interest rates, and as a result, we are subject to variability in the cash paid for interest.  To mitigate a portion of that risk, we may choose to engage in an interest rate swap hedging strategy to eliminate the variability of interest payment cash flows. We are not currently hedged against interest rate risk.

[0001069202-19-000008:notes:126]
Foreign Currency Risk.  Foreign currency exchange rate movements create a degree of risk by affecting the U.S. dollar value of assets and liabilities arising in foreign currencies.  We seek to mitigate the impact of currency exchange rate movements on certain short-term transactions by periodically entering into foreign currency forward contracts.

[0001069202-19-000008:notes:127]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 intends to simplify the application of hedge accounting guidance and better align an entity’s risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results. The amendments expand and refine hedge accounting for both nonfinancial and financial risk components and align the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. We early adopted ASU No. 2017-12 during the first quarter of 2018. The adoption of ASU No. 2017-12 did not have a material impact on our consolidated results of operations, cash flows, and statement of financial position. With the early adoption of ASU No. 2017-12 we began entering into commodity futures contracts designated as cash flow hedges related to aluminum purchases.

[0001069202-19-000008:notes:128]
Cash Flow Hedges

[0001069202-19-000008:notes:129]
We have commodity futures contracts and foreign exchange forward contracts designated as cash flows hedges that are scheduled to mature through May 2020 and January 2020, respectively.  Unrealized gains or losses from our cash flow hedges are included in AOCL and are expected to be reclassified into earnings within the next 18 months based on the prices of the commodities and foreign currencies at the settlement dates.

[0001069202-19-000008:notes:130]
We recorded the following amounts related to our cash flow hedges in AOCL (in millions):

[0001069202-19-000008:notes:131]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Unrealized losses (gains) on unsettled contracts | $ | 8.4 |  |  | $ | (11.3 | ) |
| Income tax (benefit) expense | (2.2 | ) |  | 3.9 |  |
| Losses (Gains) included in AOCL, net of tax (1) | $ | 6.2 |  |  | $ | (7.4 | ) |

[0001069202-19-000008:notes:132]
(1) Assuming commodity and foreign currency prices remain constant, we expect to reclassify $6.2 million of derivative losses into earnings within the next 12 months.


## us-gaap:DerivativesPolicyTextBlock

[0001069202-19-000008:notes:133]
Derivatives

[0001069202-19-000008:notes:134]
We use futures contracts, forward contracts and fixed forward contracts to mitigate our exposure to volatility in metal commodity prices and foreign exchange rates.  We hedge only exposures in the ordinary course of business and do not hold or trade derivatives for profit. All derivatives are recognized in the Consolidated Balance Sheets at fair value and the classification of each derivative instrument is based upon whether the maturity of the instrument is less than or greater than 12 months.  See Note 9 for more information on our derivatives.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001069202-19-000008:notes:135]
Stock-Based Compensation:

[0001069202-19-000008:notes:136]
Stock-based compensation expense related to continuing operations was included in Selling, general and administrative expenses in the accompanying Consolidated Statements of Operations as follows (in millions):

[0001069202-19-000008:notes:137]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Compensation expense(1) | $ | 26.3 |  |  | $ | 24.9 |  |  | $ | 31.7 |  |

[0001069202-19-000008:notes:138]
(1) Stock-based compensation expense was recorded in our Corporate and other business segment.

[0001069202-19-000008:notes:139]
Incentive Plan

[0001069202-19-000008:notes:140]
Under the Lennox International Inc. 2010 Incentive Plan, as amended and restated (the “2010 Incentive Plan”), we are authorized to issue awards for 24.3 million shares of common stock.  The 2010 Incentive Plan provides for various long-term incentive awards, including performance share units, restricted stock units and stock appreciation rights.  A description of these long-term incentive awards and related activity within each award category is provided below.

[0001069202-19-000008:notes:141]
As of December 31, 2018, awards for 9.9 million shares of common stock had been granted, net of cancellations and repurchases, and there were 3.5 million shares available for future issuance.

[0001069202-19-000008:notes:142]
Performance Share Units

[0001069202-19-000008:notes:143]
Performance share units are granted to certain employees at the discretion of the Board of Directors with a three-year performance period beginning January 1st of each year.  Upon meeting the performance and vesting criteria, performance share units are converted to an equal number of shares of our common stock.  Performance share units vest if, at the end of the three-year performance period, at least the threshold performance level has been attained.  To the extent that the payout level attained is less than 100%, the difference between 100% and the units earned and distributed will be forfeited.  Eligible participants may also earn additional units of our common stock, which would increase the potential payout up to 200% of the units granted, depending on LII’s performance over the three-year performance period.

[0001069202-19-000008:notes:144]
Performance share units are classified as equity awards.  Compensation expense is recognized on an earnings curve over the period and is based on the expected number of units to be earned and the fair value of the stock at the date of grant.  The fair value of units is calculated as the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period.  The number of units expected to be earned will be adjusted in future periods as necessary to reflect changes in the estimated number of award to be issued and, upon vesting, the actual number of units awarded.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy performance share unit distributions.

[0001069202-19-000008:notes:145]
The following table provides information on our performance share units:

[0001069202-19-000008:notes:146]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Compensation expense for performance share units (in millions) | $ | 12.3 |  |  | $ | 12.2 |  |  | $ | 18.1 |  |
| Weighted-average fair value of grants, per share | $ | 204.64 |  |  | $ | 197.54 |  |  | $ | 150.21 |  |
| Payout ratio for shares paid | 173.2 | % |  | 185.9 | % |  | 200.0 | % |

[0001069202-19-000008:notes:147]
A summary of the status of our undistributed performance share units as of December 31, 2018, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-19-000008:notes:148]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Undistributed performance share units as of December 31, 2017 | 0.3 |  |  | $ | 123.80 |  |
| Granted | 0.1 |  |  | 204.64 |  |
| Distributed | (0.2 | ) |  | 88.26 |  |
| Undistributed performance share units as of December 31, 2018 (1) | 0.2 |  |  | $ | 160.69 |  |

[0001069202-19-000008:notes:149]
(1) Undistributed performance share units include approximately 0.2 million units with a weighted-average grant date fair value of $182.06 per share that had not yet vested and 0.1 million units that have vested but were not yet distributed.

[0001069202-19-000008:notes:150]
As of December 31, 2018, we had $21.3 million of total unrecognized compensation cost related to non-vested performance share units that is expected to be recognized over a weighted-average period of 2.2 years. Our estimated forfeiture rate for these performance share units was 12.4% as of December 31, 2018.

[0001069202-19-000008:notes:151]
Restricted Stock Units

[0001069202-19-000008:notes:152]
Restricted stock units are issued to attract and retain key employees.  Generally, at the end of a three-year retention period, the units will vest and be distributed in shares of our common stock to the participant.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy restricted stock unit vestings.  Restricted stock units are classified as equity awards.  The fair value of units granted is the average of the high and low market price of the stock on the date of grant discounted by the expected dividend rate over the service period. Units are amortized to compensation expense ratably over the service period.

[0001069202-19-000008:notes:153]
The following table provides information on our restricted stock units (in millions, except per share data):

[0001069202-19-000008:notes:154]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Compensation expense for restricted stock units | $ | 9.2 |  |  | $ | 8.3 |  |  | $ | 9.0 |  |
| Weighted-average fair value of grants, per share | $ | 204.64 |  |  | $ | 197.54 |  |  | $ | 150.14 |  |

[0001069202-19-000008:notes:155]
A summary of our non-vested restricted stock units as of December 31, 2018 and changes during the year then ended is presented below (in millions, except per share data):

[0001069202-19-000008:notes:156]
|  | Shares |  | Weighted- Average Grant Date Fair Value per Share |
| Non-vested restricted stock units as of December 31, 2017 | 0.2 |  |  | $ | 156.16 |  |
| Granted | 0.1 |  |  | 204.64 |  |
| Vested | (0.1 | ) |  | 125.46 |  |
| Forfeited | — |  |  | — |  |
| Non-vested restricted stock units as of December 31, 2018 (1) | 0.2 |  |  | $ | 182.84 |  |

[0001069202-19-000008:notes:157]
(1) As of December 31, 2018, we had $19.5 million of total unrecognized compensation cost related to non-vested restricted stock units that is expected to be recognized over a weighted-average period of 2.3 years.  Our estimated forfeiture rate for restricted stock units was 16.0% as of December 31, 2018.

[0001069202-19-000008:notes:158]
Stock Appreciation Rights

[0001069202-19-000008:notes:159]
Stock appreciation rights are issued to certain key employees.  Each recipient is given the “right” to receive compensation, paid in shares of our common stock, equal to the future appreciation of our common stock price.  Stock appreciation rights generally vest in one-third increments beginning on the first anniversary date after the grant date and expire after seven years.  Our practice is to issue new shares of common stock or utilize treasury stock to satisfy the exercise of stock appreciation rights.

[0001069202-19-000008:notes:160]
The following table provides information on our stock appreciation rights (in millions, except per share data):

[0001069202-19-000008:notes:161]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Compensation expense for stock appreciation rights | $ | 4.8 |  |  | $ | 4.4 |  |  | $ | 4.6 |  |
| Weighted-average fair value of grants, per share | 35.57 |  |  | 32.32 |  |  | 22.93 |  |

[0001069202-19-000008:notes:162]
Compensation expense for stock appreciation rights is based on the fair value on the date of grant, estimated using the Black-Scholes-Merton valuation model, and is recognized over the service period.  We used historical stock price data to estimate the expected volatility.  We determined that the recipients of stock appreciation rights can be combined into one employee group that has similar historical exercise behavior and we used our historical pattern of award exercises to estimate the expected life of the awards for the employee group.  The risk-free interest rate was based on the zero-coupon U.S. Treasury yield curve with a maturity equal to the expected life of the awards at the time of grant.

[0001069202-19-000008:notes:163]
The fair value of the stock appreciation rights granted in 2018, 2017 and 2016 were estimated on the date of grant using the following assumptions:

[0001069202-19-000008:notes:164]
|  | 2018 |  | 2017 |  | 2016 |
| Expected dividend yield | 1.76 | % |  | 1.47 | % |  | 1.62 | % |
| Risk-free interest rate | 2.71 | % |  | 2.02 | % |  | 1.66 | % |
| Expected volatility | 20.60 | % |  | 19.97 | % |  | 19.60 | % |
| Expected life (in years) | 3.93 |  |  | 3.95 |  |  | 3.99 |  |

[0001069202-19-000008:notes:165]
A summary of our stock appreciation rights as of December 31, 2018, and changes during the year then ended, is presented below (in millions, except per share data):

[0001069202-19-000008:notes:166]
|  | Shares (1) |  | Weighted-Average Exercise Price per Share |
| Outstanding stock appreciation rights as of December 31, 2017 | 1.1 |  |  | $ | 121.63 |  |
| Granted | 0.2 |  |  | 214.63 |  |
| Exercised | (0.3 | ) |  | 74.51 |  |
| Forfeited | — |  |  | — |  |
| Outstanding stock appreciation rights as of December 31, 2018 | 0.9 |  |  | $ | 148.98 |  |
| Exercisable stock appreciation rights as of December 31, 2018 | 0.6 |  |  | $ | 120.52 |  |

[0001069202-19-000008:notes:167]
(1) Share amounts are rounded but the balance of undistributed performance share units as of December 31, 2018 accurately reflects actual units undistributed.

[0001069202-19-000008:notes:168]
As of December 31, 2018, we had $9.7 million of unrecognized compensation cost related to non-vested stock appreciation rights that is expected to be recognized over a weighted-average period of 2.3 years. Our estimated forfeiture rate for stock appreciation rights was 12.9% as of December 31, 2018.

[0001069202-19-000008:notes:169]
Employee Stock Purchase Plan

[0001069202-19-000008:notes:170]
Under the 2012 Employee Stock Purchase Plan (“ESPP”), all employees who meet certain service requirements are eligible to purchase our common stock through payroll deductions at the end of three month offering periods.  The purchase price for such shares is 95% of the fair market value of the stock on the last day of the offering period.  A maximum of 2.5 million shares is authorized for purchase until the ESPP plan termination date of May 10, 2022, unless terminated earlier at the discretion of the Board of Directors.  Employees purchased approximately 15,000 shares under the ESPP during the year ended December 31, 2018.  Approximately 2.4 million shares remain available for purchase under the ESPP as of December 31, 2018.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001069202-19-000008:notes:171]
During the first quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia and Asia business except for the Milperra property.  The Milperra property was sold to another purchaser during the second quarter of 2018. We completed the sale to Beijer Ref AB in the second quarter of 2018 with the final post-completion adjustment being recorded in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000008:notes:172]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 82.9 |  |
| Net assets sold (1) | (87.2 | ) |
| AOCL reclassification adjustments, primarily foreign currency translation | (3.2 | ) |
| Direct costs to sell | (5.8 | ) |
| Loss on sale of business | $ | (13.3 | ) |

[0001069202-19-000008:notes:173]
(1) Includes $10.3 million of net assets that were written down during the quarter ended March 31, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our Australia and Asia business.

[0001069202-19-000008:notes:174]
The Milperra property was sold during the quarter ended June 30, 2018. We received net cash proceeds of $37.2 million net of direct costs to sell of $1.5 million. The net gain recognized in connection with this sale was $23.8 million.

[0001069202-19-000008:notes:175]
South America Divestiture

[0001069202-19-000008:notes:176]
During the second quarter of 2018, we obtained Board of Directors’ approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business. The sale was subject to Brazilian antitrust approval.  We obtained antitrust approval and completed the sale to Elgin SA in the third quarter of 2018. The following table summarizes the net loss recognized in connection with this divestiture:

[0001069202-19-000008:notes:177]
| (Amounts in millions) | For the Year Ended December 31, 2018 |
| Cash received from the buyer | $ | 4.2 |  |
| Net assets sold (2) | (14.1 | ) |
| AOCL reclassification adjustments, primarily foreign currency translation | (24.7 | ) |
| Direct costs to sell | (2.9 | ) |
| Loss on sale of business | $ | (37.5 | ) |

[0001069202-19-000008:notes:178]
(2) Includes $1.2 million of net assets that were written down during the quarter ended June 30, 2018 based on the expected proceeds from the sale, net of selling costs for the sale for our South America business.

[0001069202-19-000008:notes:179]
The total Loss (gain), net on sale of businesses and related property in our Consolidated Statements of Operations of $27.0 million  is comprised of the $13.3 million loss on the sale of our Australia and Asia business, the $23.8 million gain on the sale of our Milperra property, and the $37.5 million loss on the sale of our South America business.


## us-gaap:EarningsPerShareTextBlock

[0001069202-19-000008:notes:180]
Earnings Per Share:

[0001069202-19-000008:notes:181]
Basic earnings per share are computed by dividing net income by the weighted-average number of common shares outstanding during the period.  Diluted earnings per share are computed by dividing net income by the sum of the weighted-average number of shares and the number of equivalent shares assumed outstanding, if dilutive, under our stock-based compensation plans.

[0001069202-19-000008:notes:182]
The computations of basic and diluted earnings per share for Income from continuing operations were as follows (in millions, except per share data):

[0001069202-19-000008:notes:183]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net income | $ | 359.0 |  |  | $ | 305.7 |  |  | $ | 277.8 |  |
| Add: Loss from discontinued operations | 1.3 |  |  | 1.4 |  |  | 0.8 |  |
| Income from continuing operations | $ | 360.3 |  |  | $ | 307.1 |  |  | $ | 278.6 |  |
| Weighted-average shares outstanding – basic | 40.6 |  |  | 42.2 |  |  | 43.4 |  |
| Add: Potential effect of diluted securities attributable to stock-based payments | 0.5 |  |  | 0.6 |  |  | 0.6 |  |
| Weighted-average shares outstanding – diluted | 41.1 |  |  | 42.8 |  |  | 44.0 |  |
| Earnings per share - Basic: |  |  |  |  |  |
| Income from continuing operations | $ | 8.87 |  |  | $ | 7.28 |  |  | $ | 6.41 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.03 | ) |  | (0.02 | ) |
| Net income | $ | 8.84 |  |  | $ | 7.25 |  |  | $ | 6.39 |  |
| Earnings per share - Diluted: |  |  |  |  |  |
| Income from continuing operations | $ | 8.77 |  |  | $ | 7.17 |  |  | $ | 6.34 |  |
| Loss from discontinued operations | (0.03 | ) |  | (0.03 | ) |  | (0.02 | ) |
| Net income | $ | 8.74 |  |  | $ | 7.14 |  |  | $ | 6.32 |  |

[0001069202-19-000008:notes:184]
An insignificant number of stock appreciation rights were outstanding but not included in the diluted earnings per share calculation because the assumed exercise of such rights would have been anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001069202-19-000008:notes:185]
Joint Ventures and Other Equity Investments:

[0001069202-19-000008:notes:186]
We participate in two joint ventures, the largest located in the U.S. and the other in Mexico, that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our respective 25% and 50% ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.

[0001069202-19-000008:notes:187]
The combined balance of equity method investments included in Other assets, net totaled (in millions):

[0001069202-19-000008:notes:188]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Equity method investments | $ | 36.6 |  |  | $ | 33.3 |  |

[0001069202-19-000008:notes:189]
We purchase compressors from our U.S. joint venture for use in certain of our products.  The amounts of purchases included in Cost of goods sold in the Consolidated Statements of Operations were as follows (in millions):

[0001069202-19-000008:notes:190]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Purchases of compressors from joint venture | $ | 103.1 |  |  | $ | 106.4 |  |  | $ | 97.7 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001069202-19-000008:notes:191]
The fair values of our pension plan assets, by asset category, are as follows (in millions):

[0001069202-19-000008:notes:192]
|  | Fair Value Measurements as of December 31, 2018 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 7.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.2 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 62.7 |  |  | — |  |  | 62.7 |  |
| International equity (2) | — |  |  | 39.5 |  |  | — |  |  | 39.5 |  |
| Fixed income (3) | — |  |  | 146.2 |  |  | — |  |  | 146.2 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| Fixed income | — |  |  | 12.0 |  |  | — |  |  | 12.0 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Fixed income (6) | — |  |  | 8.9 |  |  | — |  |  | 8.9 |  |
| Blend (7) | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |
| Total | $ | 7.2 |  |  | $ | 283.8 |  |  | $ | — |  |  | $ | 291.0 |  |

[0001069202-19-000008:notes:193]
|  | Fair Value Measurements as of December 31, 2017 |
|  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | Total |
| Asset Category: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.9 |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |  |  |
| U.S. equity (1) | — |  |  | 34.7 |  |  | — |  |  | 34.7 |  |
| International equity (2) | — |  |  | 42.2 |  |  | — |  |  | 42.2 |  |
| Fixed income (3) | — |  |  | 197.9 |  |  | — |  |  | 197.9 |  |
| Balanced pension trust: (4) |  |  |  |  |  |  |  |
| International equity | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| Fixed income | — |  |  | 13.6 |  |  | — |  |  | 13.6 |  |
| Pension fund: |  |  |  |  |  |  |  |
| International equity (5) | — |  |  | 3.3 |  |  | — |  |  | 3.3 |  |
| Fixed income (6) | — |  |  | 5.9 |  |  | — |  |  | 5.9 |  |
| Blend (7) | — |  |  | 12.5 |  |  | — |  |  | 12.5 |  |
| Total | $ | 3.9 |  |  | $ | 314.7 |  |  | $ | — |  |  | $ | 318.6 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001069202-19-000008:notes:194]
The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):

[0001069202-19-000008:notes:195]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Quoted Prices in Active Markets for Similar Instruments (Level 2): |  |  |  |
| Senior unsecured notes | $ | 302.9 |  |  | $ | 308.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001069202-19-000008:notes:196]
Fair Value Measurements:

[0001069202-19-000008:notes:197]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  Fair value is based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date and requires consideration of our creditworthiness when valuing certain liabilities.  Our framework for measuring fair value is based on the following three-level hierarchy for fair value measurements:

[0001069202-19-000008:notes:198]
Level 1 -     Quoted prices for identical instruments in active markets at the measurement date.

[0001069202-19-000008:notes:199]
| Level 2 - | Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets at the measurement date and for the anticipated term of the instrument. |

[0001069202-19-000008:notes:200]
| Level 3 - | Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable inputs that reflect the reporting entity’s own assumptions about the assumptions market participants would use in pricing the asset or liability developed based on the best information available in the circumstances. |

[0001069202-19-000008:notes:201]
Where available, the fair values were based upon quoted prices in active markets. However, if quoted prices were not available, then the fair values were based upon quoted prices for similar assets or liabilities or independently sourced market parameters, such as credit default swap spreads, yield curves, reported trades, broker/dealer quotes, interest rates and benchmark securities. For assets and liabilities without observable market activity, if any, the fair values were based upon discounted cash flow methodologies incorporating assumptions that, in our judgment, reflect the assumptions a marketplace participant would use.  Valuation adjustments to reflect either party’s creditworthiness and ability to pay were incorporated into our valuations, where appropriate, as of December 31, 2018 and 2017, the measurement dates.  The methodologies used to determine the fair value of our financial assets and liabilities as of December 31, 2018 were the same as those used as of December 31, 2017.

[0001069202-19-000008:notes:202]
Fair values are estimates and are not necessarily indicative of amounts for which we could settle such instruments currently nor indicative of our intent or ability to dispose of or liquidate them.

[0001069202-19-000008:notes:203]
Assets and Liabilities Carried at Fair Value on a Recurring Basis

[0001069202-19-000008:notes:204]
Derivatives, classified as Level 2, were primarily valued using estimated future cash flows based on observed prices from exchange-traded derivatives.  We also considered the counterparty’s creditworthiness, or our own creditworthiness, as appropriate.  Adjustments were recorded to reflect the risk of credit default, but they were insignificant to the overall value of the derivatives.  Refer to Note 9 for more information related to our derivative instruments.

[0001069202-19-000008:notes:205]
Marketable Equity Securities

[0001069202-19-000008:notes:206]
The following table presents the fair values of an investment in marketable equity securities, related to publicly traded stock of a non-U.S. company, recorded in Other assets, net in the accompanying Consolidated Balance Sheets (in millions).This investment was sold as part of the divestiture of our Australia and Asia business. Refer to Note 17 for details regarding divestiture of the business.

[0001069202-19-000008:notes:207]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Quoted Prices in Active Markets for Identical Assets (Level 1): |  |  |  |
| Investment in marketable equity securities | $ | — |  |  | $ | 4.1 |  |

[0001069202-19-000008:notes:208]
Other Fair Value Disclosures

[0001069202-19-000008:notes:209]
The carrying amounts of Cash and cash equivalents, Accounts and notes receivable, net, Accounts payable, Other current liabilities, and Short-term debt approximate fair value due to the short maturities of these instruments.  The carrying amount of our Domestic Credit Facility in Long-term debt also approximates fair value due to its variable-rate characteristics.

[0001069202-19-000008:notes:210]
The fair value of our senior unsecured notes in Long-term debt was based on the amount of future cash flows using current market rates for debt instruments of similar maturities and credit risk.  The following table presents the fair value for our senior unsecured notes in Long-term debt (in millions):


## us-gaap:FairValueInvestmentsEntitiesThatCalculateNetAssetValuePerShareTableTextBlock

[0001069202-19-000008:notes:211]
Additional information about assets measured at Net Asset Value (“NAV”) per share (in millions):

[0001069202-19-000008:notes:212]
|  | As of December 31, 2018 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 62.7 |  |  | Daily |  | 5 days |
| International equity (2) | 39.5 |  |  | Daily |  | 5 days |
| Fixed income (3) | 146.2 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.0 |  |  | Daily |  | 3-5 days |
| Fixed income | 12.0 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 2.7 |  |  | Daily |  | 1-3 days |
| Fixed income (6) | 8.9 |  |  | Daily |  | 1-3 days |
| Blend (7) | 7.8 |  |  | Daily |  | 1-3 days |
| Total | $ | 283.8 |  |  |  |  |  |

[0001069202-19-000008:notes:213]
|  | As of December 31, 2017 |
|  | Fair Value |  | Redemption Frequency (if currently eligible) |  | Redemption Notice Period |
| Asset Category: |  |  |  |  |  |
| Commingled pools / Collective Trusts: |  |  |  |  |  |
| U.S. equity (1) | $ | 34.7 |  |  | Daily |  | 5 days |
| International equity (2) | 42.2 |  |  | Daily |  | 5 days |
| Fixed income (3) | 197.9 |  |  | Daily |  | 5-15 days |
| Balanced pension trust: (4) |  |  |  |  |  |
| International equity | 4.6 |  |  | Daily |  | 3-5 days |
| Fixed income | 13.6 |  |  | Daily |  | 3-5 days |
| Pension fund: |  |  |  |  |  |
| International equity (5) | 3.3 |  |  | Daily |  | 1-3 days |
| Fixed income (6) | 5.9 |  |  | Daily |  | 1-7 days |
| Blend (7) | 12.5 |  |  | Daily |  | 1-3 days |
| Total | $ | 314.7 |  |  |  |  |  |

[0001069202-19-000008:notes:214]
| (1) | This category includes investments primarily in U.S. equity securities that include large, mid and small capitalization companies. |
| (2) | This category includes investments primarily in international equity securities that include large, mid and small capitalization companies in large developed markets as well as emerging markets equities. |
| (3) | This category includes investments in U.S. investment grade and high yield fixed income securities, international fixed income securities and emerging markets fixed income securities. |
| (4) | The investment objectives of the plan are to provide long-term capital growth and income by investing primarily in a well-diversified, balanced portfolio of Canadian common stocks, bonds and money market securities. The plan also holds a portion of its assets in international equities, a portion of which may be invested in U.S. securities. |
| (5) | This category includes investments in international equity securities, a portion of which may be invested in U.S. securities and aims to provide returns consistent with the markets in which it invests and provide broad exposure to countries around the world. |
| (6) | This category includes investments in U.K. government index-linked securities (index-linked gilts) that have maturity periods of 5 years or longer with a derivatives overlay and investment grade corporate bonds denominated in sterling. |
| (7) | This category includes investments in pooled funds where the fund manager has discretion for the asset allocation and can invest in a wide range of international and US asset classes including equity, credit markets, sovereign debt and alternative assets (including derivative-based strategies). |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001069202-19-000008:notes:215]
Translation of Foreign Currencies

[0001069202-19-000008:notes:216]
All assets and liabilities of foreign subsidiaries and joint ventures are translated into U.S. dollars using rates of exchange in effect at the balance sheet date.  Revenue and expenses are translated at weighted average exchange rates during the year.  Unrealized translation gains and losses are included in AOCL in the accompanying Consolidated Balance Sheets.  Transaction gains and losses are included in Losses (gains) and other expenses, net in the accompanying Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001069202-19-000008:notes:217]
Goodwill:

[0001069202-19-000008:notes:218]
Goodwill

[0001069202-19-000008:notes:219]
The changes in the carrying amount of goodwill in 2018 and 2017, in total and by segment, are summarized in the table below (in millions):

[0001069202-19-000008:notes:220]
| Segment: | Balance at December 31, 2016 (1) |  | Changes in foreign currency translation rates |  | Balance at December 31, 2017 |  | Write-off due to divested businesses |  | Changes in foreign currency translation rates |  | Balance at December 31, 2018 |
| Residential Heating & Cooling | $ | 26.1 |  |  | $ | — |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.1 |  |
| Commercial Heating & Cooling | 60.1 |  |  | 2.1 |  |  | 62.2 |  |  | — |  |  | (0.8 | ) |  | 61.4 |  |
| Refrigeration | 108.9 |  |  | 3.3 |  |  | 112.2 |  |  | (11.5 | ) |  | (1.6 | ) |  | 99.1 |  |
|  | $ | 195.1 |  |  | $ | 5.4 |  |  | $ | 200.5 |  |  | $ | (11.5 | ) |  | $ | (2.4 | ) |  | $ | 186.6 |  |

[0001069202-19-000008:notes:221]
(1) The goodwill balances in the table above are presented net of accumulated impairment charges of $21.2 million, all of which relate to impairments in periods prior to 2016.

[0001069202-19-000008:notes:222]
We reviewed our reporting unit structure as part of our annual goodwill impairment testing.  We identified several components one level below our operating segments which were determined to be reporting units.  We then performed our analysis to determine the proper aggregation of our reporting units, which considered similar economic and other characteristics, including product types, gross profits, production processes, customer types, distribution processes, and regulatory environments.  Our analysis incorporated qualitative and quantitative measures to evaluate economic similarity  and concluded that our reporting units continue to be equivalent to our operating segments except for our North America supermarket display cases and systems business which is a separate reporting unit within the Refrigeration segment.

[0001069202-19-000008:notes:223]
A qualitative review of impairment indicators was performed in 2018 for the Residential Heating & Cooling, the Commercial Heating & Cooling, and the Refrigeration segments and we determined that it was not more likely than not that the fair values of our reporting units, individually or collectively, were less than their carrying values.  Accordingly, a quantitative impairment analysis was not performed for these segments.  In the current year, we wrote off $11.5 million of goodwill as a part of the completed sales of our Australia, Asia and South America businesses (discussed further in Note 17 of the Notes to the Consolidated Financial Statements). We did not record any goodwill impairments related to continuing operations in 2017 and 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001069202-19-000008:notes:224]
Income Taxes:

[0001069202-19-000008:notes:225]
Our Provision for income taxes from continuing operations consisted of the following (in millions):

[0001069202-19-000008:notes:226]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Current: |  |  |  |  |  |
| Federal | $ | 59.5 |  |  | $ | 86.1 |  |  | $ | 106.0 |  |
| State | 17.8 |  |  | 12.5 |  |  | 14.5 |  |
| Foreign | 4.6 |  |  | 15.0 |  |  | 9.7 |  |
| Total current | 81.9 |  |  | 113.6 |  |  | 130.2 |  |
| Deferred: |  |  |  |  |  |
| Federal | 23.2 |  |  | 43.8 |  |  | (4.5 | ) |
| State | 1.0 |  |  | 0.9 |  |  | (1.2 | ) |
| Foreign | 1.5 |  |  | (1.4 | ) |  | (0.4 | ) |
| Total deferred | 25.7 |  |  | 43.3 |  |  | (6.1 | ) |
| Total provision for income taxes | $ | 107.6 |  |  | $ | 156.9 |  |  | $ | 124.1 |  |

[0001069202-19-000008:notes:227]
Income from continuing operations before income taxes was comprised of the following (in millions):

[0001069202-19-000008:notes:228]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Domestic | $ | 428.7 |  |  | $ | 402.5 |  |  | $ | 374.8 |  |
| Foreign | 39.2 |  |  | 61.5 |  |  | 27.9 |  |
| Total | $ | 467.9 |  |  | $ | 464.0 |  |  | $ | 402.7 |  |

[0001069202-19-000008:notes:229]
The difference between the income tax provision from continuing operations computed at the statutory federal income tax rate and the financial statement Provision for income taxes is summarized as follows (in millions):

[0001069202-19-000008:notes:230]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Provision at the U.S. statutory rate of 21% (35% for 2017, 2016) | $ | 98.3 |  |  | $ | 162.4 |  |  | $ | 141.0 |  |
| Increase (reduction) in tax expense resulting from: |  |  |  |  |  |
| State income tax, net of federal income tax benefit | 15.5 |  |  | 9.2 |  |  | 12.8 |  |
| Domestic manufacturing deduction | — |  |  | (9.6 | ) |  | (9.2 | ) |
| Tax credits, net of unrecognized tax benefits | (2.5 | ) |  | (8.6 | ) |  | (27.9 | ) |
| Change in unrecognized tax benefits | 0.4 |  |  | (0.1 | ) |  | (0.3 | ) |
| Change in valuation allowance | 5.0 |  |  | 6.4 |  |  | (4.3 | ) |
| Foreign taxes at rates other than U.S. statutory rate | (3.2 | ) |  | (9.0 | ) |  | (1.3 | ) |
| Deemed inclusions | 3.9 |  |  | 0.3 |  |  | 16.9 |  |
| Change in rates from the Tax Act & other law changes | 1.9 |  |  | 31.8 |  |  | (0.6 | ) |
| Excess tax benefits from stock-based compensation | (10.5 | ) |  | (23.6 | ) |  | — |  |
| Miscellaneous other | (1.2 | ) |  | (2.3 | ) |  | (3.0 | ) |
| Total provision for income taxes | $ | 107.6 |  |  | $ | 156.9 |  |  | $ | 124.1 |  |

[0001069202-19-000008:notes:231]
The SEC staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provided guidance on the provisional accounting for the tax effects of the Tax Act in fiscal 2017.  Our accounting for the following elements of the Tax Act was completed in fiscal 2018.

[0001069202-19-000008:notes:232]
| • | The Tax Act reduced the corporate tax rate to 21 percent, effective January 1, 2018. For our net federal deferred tax assets (“DTA”), we recorded a provisional decrease of $32.1 million, with a corresponding net adjustment to deferred income tax expense of $32.1 million for the year ended December 31, 2017. This adjustment was based on a reasonable estimate of the impact of the reduction in the corporate tax rate on our DTA’s as of December 22, 2017. Due to the Tax Act, several applications for changes in accounting method were filed with the IRS to accelerate deductions into the 2017 U.S. federal income tax return. Primarily on the basis of finalized calculations for accounting method changes that were completed during the reporting period, we recognized a deferred income tax benefit of $4.5 million for the year ended December 31, 2018. |

[0001069202-19-000008:notes:233]
| • | The Deemed Repatriation Transition Tax (Transition Tax) is a tax on previously untaxed accumulated and current earnings and profits “(E&P)” of certain of our foreign subsidiaries. To assess the amount of the Transition Tax, we must determine, in addition to other factors, the amount of post-1986 E&P of the relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings. We were able to make a reasonable estimate of the Transition Tax and determined that we would not have a Transition Tax obligation for the year ended December 31, 2017. However, on the basis of revised E&P computations that were completed during the reporting period, we recognized an additional measurement-period adjustment of $2.8 million of Transition Tax obligation for federal and state taxes. The Transition Tax has now been determined to be complete. |

[0001069202-19-000008:notes:234]
| • | For the year ended December 31, 2017, we were able to reasonably assess whether our valuation allowance analyses were affected by various aspects of the Tax Act (e.g., deemed repatriation of deferred foreign income, global intangible low-taxed income (“GILTI”) inclusions, new categories of foreign tax credits (“FTCs”), and share-based compensation) and recorded provisional amounts related to certain portions of the Tax Act. Due to the limitation on the utilization of future foreign tax credits, we recorded a provisional valuation allowance against our FTC carryforwards of $4.3 million. On the basis of finalized calculations that were completed during the reporting period and 2018 divestiture activity, it is now expected that the foreign tax credits will be realized and no valuation allowance is needed. For the year ended December 31, 2018, the FTC carryforward valuation allowance is zero. |

[0001069202-19-000008:notes:235]
| • | Based on the intent to fully expense all qualifying depreciable asset expenditures allowed under the Tax Act, we recorded a provisional benefit of $4.1 million for the year ended December 31, 2017. This resulted in a decrease of approximately $1.4 million to our current income tax payable and a corresponding increase in our deferred tax liabilities (“DTLs”) of approximately $0.9 million (after considering the effects of the reduction in income tax rates). On the basis of finalized computations that were completed during the reporting period, we recognized an additional measurement-period adjustment of $0.1 million decrease in our DTL. |

[0001069202-19-000008:notes:236]
The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, the new global intangible low-taxed income (“GILTI”) tax rules. Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  For the year ended December 31, 2017, we were not able to reasonably estimate the effect of the new GILTI tax rules on future U.S. inclusions in taxable income as the expected future impact of this provision of the Tax Act depends on our current structure and business.  Therefore, we did not make any adjustments related to potential GILTI tax in our financial statements and did not make a policy decision regarding whether to record deferred taxes on GILTI.  Based, in part, on the analysis completed during the recording period of our global income and whether we expect to have future U.S. inclusions in taxable income related to GILTI, we have chosen to treat taxes due on future U.S. inclusions in taxable income related to GILTI as a current period expense when incurred (the “period cost method”).

[0001069202-19-000008:notes:237]
During the year ended December 31, 2017, the effect of the tax rate change for items originally recognized in other comprehensive income was properly recorded in tax expense from continuing operations.  This resulted in stranded tax effects in accumulated other comprehensive income at December 31, 2017.  On February 14, 2018, the FASB issued ASU No. 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits companies to reclassify stranded tax effects caused by 2017 tax reform between accumulated other comprehensive loss (“AOCL”) and retained earnings.  We elected to adopt ASU 2018-02 to reclassify the income tax effects of the 2017 Act from AOCL to retained earnings for the period ending March 31, 2018.  Accordingly, we recorded a $22.7 million increase to opening retained earnings in the period ending March 31, 2018 to reclassify the effect of the change in the U.S. federal corporate income tax rate, including the reduction in the federal benefit associated with state taxes, on the gross deferred tax amounts and related valuation allowances at the date of enactment of the Tax Cuts and Jobs Act related to items remaining in AOCL.

[0001069202-19-000008:notes:238]
On October 24, 2016, the FASB issued ASU No. 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory, which requires companies to recognize the income tax effects of intercompany sales and transfers of assets other than inventory in the period in which the transfer occurs.  Prior to ASU 2016-16, companies were required to defer the income tax effects of intercompany transfers of assets until the asset had been sold to an outside party or otherwise recognized.  The new guidance is effective for public business entities for annual periods beginning after December 15, 2017 and interim periods within those annual periods.  The guidance requires companies to apply a modified retrospective approach with a cumulative catch-up adjustment to opening retained earnings in the period of adoption.  Accordingly, we recorded a $5.1 million decrease to opening retained earnings in the period ending March 31, 2018.

[0001069202-19-000008:notes:239]
Deferred income taxes reflect the tax consequences on future years of temporary differences between the tax basis of assets and liabilities and their financial reporting basis and depending on the classification of the asset or liability generating the deferred tax.  The deferred tax provision for the periods shown represents the effect of changes in the amounts of temporary differences during those periods.

[0001069202-19-000008:notes:240]
Deferred tax assets (liabilities) were comprised of the following (in millions):

[0001069202-19-000008:notes:241]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Gross deferred tax assets: |  |  |  |
| Warranties | $ | 27.8 |  |  | $ | 27.3 |  |
| Loss carryforwards (foreign, U.S. and state) | 23.1 |  |  | 21.0 |  |
| Post-retirement and pension benefits | 21.3 |  |  | 23.3 |  |
| Inventory reserves | 9.3 |  |  | 7.5 |  |
| Receivables allowance | 3.4 |  |  | 3.5 |  |
| Compensation liabilities | 7.9 |  |  | 11.1 |  |
| Insurance liabilities | 2.9 |  |  | 5.1 |  |
| Legal reserves | 7.4 |  |  | 7.6 |  |
| Tax credits, net of federal effect | 11.0 |  |  | 21.3 |  |
| Other | 8.1 |  |  | 8.2 |  |
| Total deferred tax assets | 122.2 |  |  | 135.9 |  |
| Valuation allowance | (25.4 | ) |  | (24.9 | ) |
| Total deferred tax assets, net of valuation allowance | 96.8 |  |  | 111.0 |  |
| Gross deferred tax liabilities: |  |  |  |
| Depreciation | (22.1 | ) |  | (5.9 | ) |
| Intangibles | (5.4 | ) |  | (4.9 | ) |
| Other | (2.3 | ) |  | (5.8 | ) |
| Total deferred tax liabilities | (29.8 | ) |  | (16.6 | ) |
| Net deferred tax assets | $ | 67.0 |  |  | $ | 94.4 |  |

[0001069202-19-000008:notes:242]
As of December 31, 2018 and 2017, we had $0.6 million and $0.8 million in tax-effected state net operating loss carryforwards, respectively, and $12.6 million and $19.8 million  in tax-effected foreign net operating loss carryforwards, respectively.  The state and foreign net operating loss carryforwards began expiring in 2014.  The deferred tax asset valuation allowance relates primarily to the operating loss carryforwards in European tax jurisdictions. In addition, we have $9.0 million of valuation allowance related to federal capital loss carryforwards that will expire in 2023. The remainder of the valuation allowance relates to state tax credits.

[0001069202-19-000008:notes:243]
In assessing whether a deferred tax asset will be realized, we consider whether it is more likely than not that some portion or all of the deferred tax asset will not be realized.  We consider the reversal of existing taxable temporary differences, projected future taxable income and tax planning strategies in making this assessment.  Based upon the level of historical taxable income and projections for future taxable income over the periods in which the deferred tax assets are deductible, we believe it is more likely than not we will realize the benefits of these deductible differences, net of the existing valuation allowances, as of  December 31, 2018.

[0001069202-19-000008:notes:244]
No provision was made for income taxes which may become payable upon distribution of our foreign subsidiaries’ earnings.  These earnings were approximately $27.1 million as of December 31, 2018.  An actual repatriation in the future from our non-U.S. subsidiaries could still be subject to foreign withholding taxes and U.S. state taxes.

[0001069202-19-000008:notes:245]
We are currently under examination for our U.S. federal income taxes for 2018 and 2017 and are subject to examination by numerous other taxing authorities in the U.S. and foreign jurisdictions.  We are generally no longer subject to U.S., state and local or non-U.S. income tax examinations by taxing authorities for years before 2011.


## us-gaap:IncomeTaxPolicyTextBlock

[0001069202-19-000008:notes:246]
Income Taxes

[0001069202-19-000008:notes:247]
We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carry forwards.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.  Unrecognized tax benefits are accounted for as required by the Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 740. See Note 10 for more information related to income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0001069202-19-000008:notes:248]
Inventories:

[0001069202-19-000008:notes:249]
The components of inventories are as follows (in millions):

[0001069202-19-000008:notes:250]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Finished goods | $ | 330.5 |  |  | $ | 331.9 |  |
| Work in process | 10.0 |  |  | 5.5 |  |
| Raw materials and parts | 229.1 |  |  | 199.2 |  |
| Total | 569.6 |  |  | 536.6 |  |
| Excess of current cost over last-in, first-out cost | (59.8 | ) |  | (52.4 | ) |
| Total inventories, net | $ | 509.8 |  |  | $ | 484.2 |  |

[0001069202-19-000008:notes:251]
The Company recorded no pre-tax loss in 2018 or in 2017 and pre-tax loss of $0.2 million in 2016 from LIFO inventory liquidations.   Reserve balances, primarily related to obsolete and slow-moving inventories, were $16.5 million and $20.1 million at December 31, 2018 and December 31, 2017, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001069202-19-000008:notes:252]
Inventories

[0001069202-19-000008:notes:253]
Inventory costs include material, labor, depreciation and plant overhead.  Inventories of $343.5 million and $291.0 million as of December 31, 2018 and 2017, respectively, were valued at the lower of cost or net realizable value using the last-in, first-out (“LIFO”) cost method.  The remainder of inventory is valued at the lower of cost or net realizable value with cost determined primarily using either the first-in, first-out (“FIFO”) or average cost methods.

[0001069202-19-000008:notes:254]
We elected to use the LIFO cost method for our domestic manufacturing companies in 1974 and continued to elect the LIFO cost method for new operations through the late 1980s.  The types of inventory costs that use LIFO include raw materials, purchased components, work-in-process, repair parts and finished goods.  Since the late 1990s, we have adopted the FIFO cost method for all new domestic manufacturing operations (primarily acquisitions). Our operating entities with a previous LIFO election continue to use the LIFO cost method.  We use the FIFO cost method for our foreign-based manufacturing facilities.  See Note 4 for more information on our inventories.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001069202-19-000008:notes:255]
Recently Adopted Accounting Guidance

[0001069202-19-000008:notes:256]
In August 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-15, Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU clarify the classification for eight different types of activities, including debt prepayment and extinguishment costs, proceeds from insurance claims and distributions from equity method investees. For public business entities, the standard is effective for financial statements issued for fiscal years beginning after December 15, 2017. This standard did not have a material impact on our consolidated financial statements.

[0001069202-19-000008:notes:257]
We also adopted other new accounting standards during the first quarter of 2018. The impact of these additional standards are discussed in their respective Notes to the Consolidated Financial Statements.

[0001069202-19-000008:notes:258]
Recent Accounting Pronouncements

[0001069202-19-000008:notes:259]
On February 25, 2016, the FASB issued ASU No. 2016-02, Leases (ASC 842). Lessees will need to recognize almost all leases on their balance sheet as a right-of-use asset and a lease liability.  For income statement purposes, the FASB retained a dual model, requiring leases to be classified as either operating or finance. Classification will be based on criteria that are largely similar to those applied in current lease accounting, but without explicit bright lines.  ASU 2016-02 is effective for public companies for annual reporting periods beginning after December 15, 2018, and interim periods within those fiscal years. As a result of the new standard, all of our leases greater than one year in duration will be recognized in our Consolidated Balance Sheets as both operating lease liabilities and right-of-use assets upon adoption of the standard.  We will adopt the standard using the prospective approach.  We have completed a qualitative and quantitative assessment of our lease portfolio and are in the process of finalizing the testing of our new lease accounting system and implementing new processes and controls to account for our leases in accordance with the new standard. Upon adoption, we expect to record right-of-use assets and operating lease liabilities between $130 million and $160 million in our Consolidated Balance Sheet.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001069202-19-000008:notes:260]
Losses (Gains) and Other Expenses, net:

[0001069202-19-000008:notes:261]
Losses (gains) and other expenses, net in our Consolidated Statements of Operations were as follows (in millions):

[0001069202-19-000008:notes:262]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Realized (gains) losses on settled futures contracts | $ | (0.4 | ) |  | $ | (1.7 | ) |  | $ | 1.1 |  |
| Foreign currency exchange losses (gains) | 1.7 |  |  | (1.8 | ) |  | 2.2 |  |
| Losses on disposal of fixed assets | 0.7 |  |  | 0.2 |  |  | 0.5 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts | 1.5 |  |  | 0.9 |  |  | (3.6 | ) |
| Asbestos-related litigation | 4.0 |  |  | 3.5 |  |  | 6.3 |  |
| Special legal contingency charges | 1.9 |  |  | 3.7 |  |  | 1.9 |  |
| Environmental liabilities | 2.2 |  |  | 2.2 |  |  | 1.9 |  |
| Contractor tax payments | — |  |  | 0.1 |  |  | 0.6 |  |
| Other items, net | 1.8 |  |  | — |  |  | 0.4 |  |
| Losses (gains) and other expenses, net | $ | 13.4 |  |  | $ | 7.1 |  |  | $ | 11.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001069202-19-000008:notes:263]
Employee Benefit Plans:

[0001069202-19-000008:notes:264]
Over the past several years, we have frozen many of our defined benefit pension and profit sharing plans and replaced them with defined contribution plans.  We have a liability for the benefits earned under these inactive plans prior to the date the benefits were frozen.  We also have several active defined benefit plans that provide benefits based on years of service.  Our defined contribution plans generally include both company and employee contributions which are based on predetermined percentages of compensation earned by the employee.

[0001069202-19-000008:notes:265]
In addition to freezing the benefits of our defined benefit pension plans, we have also eliminated nearly all of our post-retirement medical benefits.  In 2012, we amended the post-retirement benefit plan to shift pre-65 medical coverage for the employees of our largest manufacturing plant so that by 2016, retirees would pay 100% of the cost of post-retirement medical coverage.  This change resulted in a significant reduction in the projected benefit obligation for post-retirement medical benefits in 2012.

[0001069202-19-000008:notes:266]
Effective for fiscal year 2016, we adopted the full yield curve approach for estimating the service cost and interest cost components of expense for plans that use a yield curve to determine the discount rate. The new method applies the specific spot rates along the yield curve used in the most recent measurement of the benefit obligation, resulting in a more precise estimate of expense. The impact for fiscal year 2016 was a decrease in expense of approximately $3.2 million.

[0001069202-19-000008:notes:267]
In 2016, we offered certain former employees with vested pension benefits a lump sum payout in an effort to reduce our long-term pension obligations.  As a result, for 2016, the net periodic benefit cost for our pension plans included a non-cash settlement charge of $31.4 million and the projected benefit obligation decreased by $50.6 million. We did not have similar funding of pension buyout activity in 2018 and 2017.

[0001069202-19-000008:notes:268]
On March 10, 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  ASU 2017-07 changes the income statement presentation of defined benefit plan expense by requiring separation between operating expense (service cost component) and non-operating expense (all other components, including interest cost, amortization of prior service cost, curtailments and settlements, etc.). The operating expense component is reported with similar compensation costs while the non-operating components are reported in Other expense (income), net in the Statement of Operations. In addition, only the service cost component is eligible for capitalization as part of an asset such as inventory or property, plant and equipment. We elected the practical expedient to use the prior year’s disclosure as a basis for the retroactive adoption of the ASU.  The ASU did not have a material impact on our financial results.

[0001069202-19-000008:notes:269]
Defined Contribution Plans

[0001069202-19-000008:notes:270]
We recorded the following contributions to the defined contribution plans (in millions):

[0001069202-19-000008:notes:271]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Contributions to defined contribution plans | $ | 18.8 |  |  | $ | 18.1 |  |  | $ | 16.3 |  |

[0001069202-19-000008:notes:272]
Pension and Post-retirement Benefit Plans

[0001069202-19-000008:notes:273]
The following tables set forth amounts recognized in our financial statements and the plans’ funded status for our pension and post-retirement benefit plans (dollars in millions):

[0001069202-19-000008:notes:274]
|  | Pension Benefits |
|  | 2018 |  | 2017 |
| Accumulated benefit obligation | $ | 368.0 |  |  | $ | 401.5 |  |
| Changes in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 405.5 |  |  | $ | 381.6 |  |
| Service cost | 5.3 |  |  | 5.0 |  |
| Interest cost | 12.3 |  |  | 12.6 |  |
| Other | 0.3 |  |  | — |  |
| Actuarial (gain) loss | (26.4 | ) |  | 22.1 |  |
| Effect of exchange rates | (2.7 | ) |  | 4.3 |  |
| Settlements and curtailments | (1.3 | ) |  | (1.3 | ) |
| Benefits paid | (21.1 | ) |  | (18.8 | ) |
| Benefit obligation at end of year | $ | 371.9 |  |  | $ | 405.5 |  |
| Changes in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 318.6 |  |  | $ | 292.5 |  |
| Actual (loss) gain return on plan assets | (23.3 | ) |  | 39.8 |  |
| Employer contribution | 20.6 |  |  | 3.5 |  |
| Effect of exchange rates | (2.5 | ) |  | 2.9 |  |
| Plan settlements | (1.3 | ) |  | (1.3 | ) |
| Benefits paid | (21.1 | ) |  | (18.8 | ) |
| Fair value of plan assets at end of year | 291.0 |  |  | 318.6 |  |
| Funded status / net amount recognized | $ | (80.9 | ) |  | $ | (86.9 | ) |
| Net amount recognized consists of: |  |  |  |
| Non-current assets | $ | 3.3 |  |  | $ | 1.6 |  |
| Current liability | (1.4 | ) |  | (4.0 | ) |
| Non-current liability | (82.8 | ) |  | (84.5 | ) |
| Net amount recognized | $ | (80.9 | ) |  | $ | (86.9 | ) |

[0001069202-19-000008:notes:275]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |
| Pension plans with a benefit obligation in excess of plan assets: |  |  |  |
| Projected benefit obligation | $ | 357.2 |  |  | $ | 394.4 |  |
| Accumulated benefit obligation | 353.4 |  |  | 390.4 |  |
| Fair value of plan assets | 275.0 |  |  | 305.9 |  |

[0001069202-19-000008:notes:276]
Our U.S.-based pension plans comprised approximately 89%  of the projected benefit obligation and 88% of plan assets as of December 31, 2018.

[0001069202-19-000008:notes:277]
|  | Pension Benefits |
|  | 2018 |  | 2017 |  | 2016 |
| Components of net periodic benefit cost as of December 31: |  |  |  |  |  |
| Service cost | $ | 5.3 |  |  | $ | 5.0 |  |  | $ | 4.4 |  |
| Interest cost | 12.3 |  |  | 12.6 |  |  | 15.3 |  |
| Expected return on plan assets | (18.8 | ) |  | (21.3 | ) |  | (21.5 | ) |
| Amortization of prior service cost | 0.1 |  |  | 0.2 |  |  | 0.3 |  |
| Recognized actuarial loss | 9.2 |  |  | 8.1 |  |  | 7.6 |  |
| Settlements and curtailments(1) | 0.7 |  |  | 0.7 |  |  | 31.6 |  |
| Net periodic benefit cost | $ | 8.8 |  |  | $ | 5.3 |  |  | $ | 37.7 |  |

[0001069202-19-000008:notes:278]
(1)  The Consolidated Statements of Operations includes $31.4 million related to pension settlement charges that represent the lump-sum payments made in the fourth quarter of 2016.

[0001069202-19-000008:notes:279]
The following table sets forth amounts recognized in AOCL and Other comprehensive income (loss) in our financial statements for 2018 and 2017 (in millions):

[0001069202-19-000008:notes:280]
|  | Pension Benefits |
|  | 2018 |  | 2017 |
| Amounts recognized in AOCL: |  |  |  |
| Prior service costs | $ | (0.9 | ) |  | $ | (0.8 | ) |
| Actuarial loss | (199.4 | ) |  | (194.6 | ) |
| Subtotal | (200.3 | ) |  | (195.4 | ) |
| Deferred taxes | 49.5 |  |  | 71.2 |  |
| Net amount recognized | $ | (150.8 | ) |  | $ | (124.2 | ) |
| Changes recognized in other comprehensive income (loss): |  |  |  |
| Current year prior service costs | 0.3 |  |  | 0.1 |  |
| Current year actuarial (gain) loss | 15.7 |  |  | 3.7 |  |
| Effect of exchange rates | (1.1 | ) |  | 1.7 |  |
| Amortization of prior service (costs) credits | (0.1 | ) |  | (0.2 | ) |
| Amortization of actuarial loss | (9.9 | ) |  | (8.8 | ) |
| Total recognized in other comprehensive income (loss) | $ | 4.9 |  |  | $ | (3.5 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) | $ | 13.7 |  |  | $ | 1.8 |  |

[0001069202-19-000008:notes:281]
The estimated prior service (costs) credits and actuarial losses that will be amortized from AOCL in 2019 are $(0.1) million  and $(7.9) million, respectively, for pension benefits.

[0001069202-19-000008:notes:282]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the U.S.-based plans in 2018 and 2017:

[0001069202-19-000008:notes:283]
|  | Pension Benefits |
|  | 2018 |  | 2017 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 4.32 | % |  | 3.66 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |

[0001069202-19-000008:notes:284]
|  | Pension Benefits |
|  | 2018 |  | 2017 |  | 2016 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 3.48 | % |  | 3.96 | % |  | 4.30 | % |
| Discount rate - interest cost | 3.22 | % |  | 3.51 | % |  | 3.76 | % |
| Expected long-term return on plan assets | 6.50 | % |  | 7.50 | % |  | 7.50 | % |
| Rate of compensation increase | 4.23 | % |  | 4.23 | % |  | 4.23 | % |

[0001069202-19-000008:notes:285]
The following tables set forth the weighted-average assumptions used to determine Benefit obligations and Net periodic benefit cost for the non-U.S.-based plans in 2018 and 2017:

[0001069202-19-000008:notes:286]
|  | Pension Benefits |
|  | 2018 |  | 2017 |
| Weighted-average assumptions used to determine benefit obligations as of December 31: |  |  |  |
| Discount rate | 2.93 | % |  | 2.58 | % |
| Rate of compensation increase | 3.77 | % |  | 3.63 | % |

[0001069202-19-000008:notes:287]
|  | Pension Benefits |
|  | 2018 |  | 2017 |  | 2016 |
| Weighted-average assumptions used to determine net periodic benefit cost for the years ended December 31: |  |  |  |  |  |
| Discount rate - service cost | 1.32 | % |  | 1.34 | % |  | 2.04 | % |
| Discount rate - interest cost | 2.67 | % |  | 2.75 | % |  | 3.45 | % |
| Expected long-term return on plan assets | 4.19 | % |  | 4.40 | % |  | 4.87 | % |
| Rate of compensation increase | 3.62 | % |  | 3.78 | % |  | 3.70 | % |

[0001069202-19-000008:notes:288]
To develop the expected long-term rate of return on assets assumption for the U.S. plans, we considered the historical returns for each asset category, as well as the target asset allocation of the pension portfolio and the effect of periodic balancing.  These results were adjusted for the payment of reasonable expenses of the plan from plan assets.  This resulted in the selection of the 6.50% long-term rate of return on assets assumption.  A similar process was followed for the non-U.S.-based plans.

[0001069202-19-000008:notes:289]
To select a discount rate for the purpose of valuing the plan obligations for the U.S. plans, we performed an analysis in which the projected cash flows from defined benefit and retiree healthcare plans was matched with a yield curve based on the appropriate universe of high-quality corporate bonds that were available. We used the results of the yield curve analysis to select the discount rate for each plan. The analysis was completed separately for each U.S. pension and OPEB plan. A similar process was followed for the non-U.S.-based plans with sufficient corporate bond information. In other countries, the discount rate was selected based on the approximate duration of plan obligations.

[0001069202-19-000008:notes:290]
Assumed health care cost trend rates have an effect on the amounts reported for our healthcare plan.  The following table sets forth the healthcare trend rate assumptions used:

[0001069202-19-000008:notes:291]
|  | 2018 |  | 2017 |
| Assumed health care cost trend rates as of December 31: |  |  |  |
| Health care cost trend rate assumed for next year | 6.50 | % |  | 6.50 | % |
| Rate to which the cost rate is assumed to decline (the ultimate trend rate) | 5.00 | % |  | 5.00 | % |
| Year that the rate reaches the ultimate trend rate | 2022 |  |  | 2021 |  |

[0001069202-19-000008:notes:292]
Expected future benefit payments are shown in the table below (in millions):

[0001069202-19-000008:notes:293]
|  | For the Years Ended December 31, |
|  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024-2028 |
| Pension benefits | $ | 19.3 |  |  | $ | 19.9 |  |  | $ | 25.8 |  |  | $ | 20.7 |  |  | $ | 23.5 |  |  | $ | 147.1 |  |

[0001069202-19-000008:notes:294]
Pension Plan Assets

[0001069202-19-000008:notes:295]
We believe asset returns can be optimized at an acceptable level of risk by adequately diversifying the plan assets between equity and fixed income.  In the second quarter of 2018, we changed the targeted allocations for our plan assets. The targeted allocation for fixed income and cash investments was changed to 60%, and the targeted allocation for equity investments was changed to 40%. Our targeted exposure to International equity including emerging markets was changed to 15.0% of total assets and our exposure to domestic equity was changed to 25.0%. Our U.S. pension plan represents 87%, our Canadian pension plan 6%, and our United Kingdom (“U.K.”) pension plan 7% of the total fair value of our plan assets as of December 31, 2018.

[0001069202-19-000008:notes:296]
Our U.S. pension plans’ weighted-average asset allocations as of December 31, 2018 and 2017, by asset category, are as follows:

[0001069202-19-000008:notes:297]
|  | Plan Assets as of December 31, |
| Asset Category: | 2018 |  | 2017 |
| U.S. equity | 24.6 | % |  | 12.5 | % |
| International equity | 15.5 | % |  | 15.1 | % |
| Fixed income | 57.2 | % |  | 71.1 | % |
| Money market/cash | 2.7 | % |  | 1.3 | % |
| Total | 100.0 | % |  | 100.0 | % |

[0001069202-19-000008:notes:298]
Our Canadian pension plans were invested approximately 75% in Canadian bonds and 25% in international equities. Our U.K. pension plan was invested in a broad mix of assets consisting of U.K. and international equities, and U.K. fixed income securities, including corporate and government bonds.

[0001069202-19-000008:notes:299]
The majority of our commingled pool/collective trusts, mutual funds, balanced pension trusts and pension funds are managed by professional investment advisors.  The NAVs per share are furnished in monthly and/or quarterly statements received from the investment advisors and reflect valuations based upon their pricing policies.  We assessed the fair value classification of these investments as Level 2 for commingled pool/collective trusts, balanced pension trusts and pension funds based on an examination of their pricing policies and the related controls and procedures.  The fair values we report are based on the pool, trust or fund’s NAV per share.  The NAVs per share are calculated periodically (daily or no less than one time per month) as the aggregate value of each pool or trust’s underlying assets divided by the number of units owned.  See Note 21 for information about our fair value hierarchies and valuation techniques.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001069202-19-000008:notes:300]
Property, Plant and Equipment:

[0001069202-19-000008:notes:301]
Components of Property, plant and equipment, net were as follows (in millions):

[0001069202-19-000008:notes:302]
|  | As of December 31, |
|  | 2018 |  | 2017 |
| Land | $ | 25.5 |  |  | $ | 35.7 |  |
| Buildings and improvements | 210.9 |  |  | 234.4 |  |
| Machinery and equipment | 838.6 |  |  | 804.4 |  |
| Capital leases | 49.9 |  |  | 27.5 |  |
| Construction in progress and equipment not yet in service | 61.9 |  |  | 70.0 |  |
| Total | 1,186.8 |  |  | 1,172.0 |  |
| Less accumulated depreciation | (778.5 | ) |  | (774.2 | ) |
| Property, plant and equipment, net | $ | 408.3 |  |  | $ | 397.8 |  |

[0001069202-19-000008:notes:303]
We wrote off $4 million of property, plant and equipment related at our Marshalltown facility that was damaged by the tornado in 2018.  Refer to Note 11 in the Notes to the Consolidated Financial Statements for more information on the damage to our Marshalltown facility.  No impairment charges were recorded in 2017 or 2016.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001069202-19-000008:notes:304]
Property, Plant and Equipment

[0001069202-19-000008:notes:305]
Property, plant and equipment is stated at cost, net of accumulated depreciation.  Expenditures that increase the utility or extend the useful lives of fixed assets are capitalized while expenditures for maintenance and repairs are charged to expense as incurred.

[0001069202-19-000008:notes:306]
Depreciation is computed using the straight-line method over the following estimated useful lives:

[0001069202-19-000008:notes:307]
| Buildings and improvements: |  |
| Buildings and improvements | 2 to 33 years |
| Leasehold improvements | 1 to 39 years |
| Machinery and equipment: |  |
| Computer hardware | 3 to 5 years |
| Computer software | 3 to 10 years |
| Factory machinery and equipment | 1 to 15 years |
| Research and development equipment | 3 to 10 years |
| Vehicles | 2 to 8 years |

[0001069202-19-000008:notes:308]
We periodically review long-lived assets for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  To assess recoverability, we compare the estimated expected future undiscounted cash flows identified with each long-lived asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  See Note 6 for additional information on our property, plant and equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001069202-19-000008:notes:309]
Selected Quarterly Financial Information (unaudited):

[0001069202-19-000008:notes:310]
The following tables provide information on Net sales, Gross profit, Net income, Earnings per share and Cash dividends declared per share by quarter (in millions, except per share data):

[0001069202-19-000008:notes:311]
|  | Net Sales (1) |  | Gross Profit (1) |  | Net Income (1) |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| First Quarter | $ | 834.8 |  |  | $ | 793.4 |  |  | $ | 223.2 |  |  | $ | 210.9 |  |  | $ | 37.9 |  |  | $ | 43.5 |  |
| Second Quarter | 1,175.4 |  |  | 1,102.1 |  |  | 361.6 |  |  | 340.8 |  |  | 137.6 |  |  | 115.5 |  |
| Third Quarter | 1,030.2 |  |  | 1,052.3 |  |  | 301.9 |  |  | 313.7 |  |  | 108.0 |  |  | 103.5 |  |
| Fourth Quarter | 843.6 |  |  | 891.8 |  |  | 224.5 |  |  | 259.8 |  |  | 75.6 |  |  | 43.1 |  |

[0001069202-19-000008:notes:312]
|  | Basic Earnings per Share (2) |  | Diluted Earnings per Share (2) |  | Cash Dividends per Common Share |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| First Quarter | $ | 0.91 |  |  | $ | 1.02 |  |  | $ | 0.90 |  |  | $ | 1.00 |  |  | $ | 0.51 |  |  | $ | 0.43 |  |
| Second Quarter | 3.38 |  |  | 2.73 |  |  | 3.35 |  |  | 2.69 |  |  | 0.64 |  |  | 0.51 |  |
| Third Quarter | 2.68 |  |  | 2.47 |  |  | 2.65 |  |  | 2.44 |  |  | 0.64 |  |  | 0.51 |  |
| Fourth Quarter | 1.89 |  |  | 1.03 |  |  | 1.87 |  |  | 1.02 |  |  | 0.64 |  |  | 0.51 |  |

[0001069202-19-000008:notes:313]
(1)  The sum of the quarterly results for each of the four quarters may not equal the full year results due to rounding.

[0001069202-19-000008:notes:314]
(2)  EPS for each quarter is computed using the weighted-average number of shares outstanding during that quarter, while EPS for the fiscal year is computed using the weighted-average number of shares outstanding during the year. Thus, the sum of the EPS for each of the four quarters may not equal the EPS for the fiscal year.

[0001069202-19-000008:notes:315]
Summary of 2018 Quarterly Results

[0001069202-19-000008:notes:316]
The following unusual or infrequent pre-tax items were included in the 2018 quarterly results:

[0001069202-19-000008:notes:317]
1st Quarter.  During the first quarter of 2018, we obtained board approval and signed an agreement with Beijer Ref AB, a Stockholm Stock Exchange-listed company, for the sale of our Australia and Asia business.

[0001069202-19-000008:notes:318]
2nd Quarter.   We completed the sale to Beijer Ref AB of our Australia and Asia business and sold our Milperra property. We obtained board approval and signed an agreement with Elgin SA, a private Brazilian company, for the sale of our South America business.  Refer to Note 17 for details regarding the divestiture.

[0001069202-19-000008:notes:319]
3rd Quarter.  We completed the sale to Elgin SA of our South America business. Our manufacturing facility in Marshalltown, Iowa was severely damaged by a tornado. Refer to Note 17 for details regarding the divestiture and Note 11 for details related to the tornado damage.

[0001069202-19-000008:notes:320]
4th Quarter.  We recorded gains from insurance recoveries related to our Marshalltown facility, refer to Note 11 for further details.

[0001069202-19-000008:notes:321]
Summary of 2017 Quarterly Results

[0001069202-19-000008:notes:322]
The following unusual or infrequent pre-tax items were included in the 2017 quarterly results:

[0001069202-19-000008:notes:323]
1st Quarter.  No significant unusual or infrequent items.

[0001069202-19-000008:notes:324]
2nd Quarter.  No significant unusual or infrequent items.

[0001069202-19-000008:notes:325]
3rd Quarter.   No significant unusual or infrequent items.

[0001069202-19-000008:notes:326]
4th Quarter. As a result of recent tax legislation, we recorded a one-time charge of $31.8 million in the fourth quarter to revalue our deferred tax assets and liabilities.


## us-gaap:ReceivablesPolicyTextBlock

[0001069202-19-000008:notes:327]
Accounts and Notes Receivable

[0001069202-19-000008:notes:328]
Accounts and notes receivable are shown in the accompanying Consolidated Balance Sheets, net of allowance for doubtful accounts.  The allowance for doubtful accounts is generally established during the period in which receivables are recognized and is based on the age of the receivables and management’s judgment on our ability to collect.  Management considers the historical trends of write-offs and recoveries of previously written-off accounts, the financial strength of customers and projected economic and market conditions.  We determine the delinquency status of receivables predominantly based on contractual terms and we write-off uncollectible receivables after management’s review of our ability to collect, as noted above.  We have no significant concentrations of credit risk within our accounts and notes receivable.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001069202-19-000008:notes:329]
Total assets by segment are shown below (in millions):

[0001069202-19-000008:notes:330]
|  | As of December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Total Assets: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 837.4 |  |  | $ | 771.3 |  |  | $ | 673.4 |  |
| Commercial Heating & Cooling | 457.2 |  |  | 443.9 |  |  | 385.8 |  |
| Refrigeration | 355.2 |  |  | 506.9 |  |  | 442.8 |  |
| Corporate and other | 167.4 |  |  | 169.4 |  |  | 258.3 |  |
| Total assets | $ | 1,817.2 |  |  | $ | 1,891.5 |  |  | $ | 1,760.3 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001069202-19-000008:notes:331]
Net sales and segment profit (loss) by segment, along with a reconciliation of segment profit (loss) to Operating income, are shown below (in millions):

[0001069202-19-000008:notes:332]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net Sales (1) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 2,225.0 |  |  | $ | 2,140.4 |  |  | $ | 2,000.8 |  |
| Commercial Heating & Cooling | 1,043.5 |  |  | 973.8 |  |  | 917.9 |  |
| Refrigeration | 615.4 |  |  | 725.4 |  |  | 722.9 |  |
|  | $ | 3,883.9 |  |  | $ | 3,839.6 |  |  | $ | 3,641.6 |  |
| Segment profit (loss) (2) |  |  |  |  |  |
| Residential Heating & Cooling | $ | 399.4 |  |  | $ | 373.9 |  |  | $ | 348.8 |  |
| Commercial Heating & Cooling | 159.5 |  |  | 157.3 |  |  | 149.3 |  |
| Refrigeration | 66.1 |  |  | 72.6 |  |  | 68.9 |  |
| Corporate and other | (84.4 | ) |  | (89.2 | ) |  | (97.4 | ) |
| Total segment profit | 540.6 |  |  | 514.6 |  |  | 469.6 |  |
| Reconciliation to Operating income: |  |  |  |  |  |
| Special inventory write down | 0.2 |  |  | — |  |  | — |  |
| Special product quality adjustments | — |  |  | 5.4 |  |  | (0.4 | ) |
| Loss (gain), net on sale of businesses and related property | 27.0 |  |  | 1.1 |  |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (10.9 | ) |  | — |  |  | — |  |
| Pension settlement | 0.4 |  |  | — |  |  | 31.4 |  |
| Items in (Gains) Losses and other expenses, net that are excluded from segment profit (loss) (2) | 11.4 |  |  | 10.4 |  |  | 7.4 |  |
| Restructuring charges | 3.0 |  |  | 3.2 |  |  | 1.8 |  |
| Operating income | $ | 509.5 |  |  | $ | 494.5 |  |  | $ | 429.4 |  |

[0001069202-19-000008:notes:333]
(1) On a consolidated basis, no revenue from transactions with a single customer were 10% or greater of our consolidated net sales for any of the periods presented.

[0001069202-19-000008:notes:334]
(2)


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001069202-19-000008:notes:335]
Total capital expenditures by segment are shown below (in millions):

[0001069202-19-000008:notes:336]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Capital Expenditures: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 45.2 |  |  | $ | 38.9 |  |  | $ | 36.7 |  |
| Commercial Heating & Cooling | 14.0 |  |  | 18.5 |  |  | 11.5 |  |
| Refrigeration | 7.8 |  |  | 8.0 |  |  | 12.1 |  |
| Corporate and other | 28.2 |  |  | 32.9 |  |  | 24.0 |  |
| Total capital expenditures (1) | $ | 95.2 |  |  | $ | 98.3 |  |  | $ | 84.3 |  |

[0001069202-19-000008:notes:337]
(1) Includes amounts recorded under capital leases. There were no significant new capital leases in 2018, 2017 or 2016.

[0001069202-19-000008:notes:338]
Depreciation and amortization expenses by segment are shown below (in millions):

[0001069202-19-000008:notes:339]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Depreciation and Amortization: |  |  |  |  |  |
| Residential Heating & Cooling | $ | 26.6 |  |  | $ | 24.9 |  |  | $ | 21.0 |  |
| Commercial Heating & Cooling | 10.4 |  |  | 10.1 |  |  | 9.8 |  |
| Refrigeration | 7.1 |  |  | 9.9 |  |  | 9.7 |  |
| Corporate and other | 21.9 |  |  | 19.7 |  |  | 17.6 |  |
| Total depreciation and amortization | $ | 66.0 |  |  | $ | 64.6 |  |  | $ | 58.1 |  |

[0001069202-19-000008:notes:340]
The equity method investments are shown below (in millions):

[0001069202-19-000008:notes:341]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Income from Equity Method Investments: |  |  |  |  |  |
| Refrigeration | $ | 2.1 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |
| Residential | 8.5 |  |  | 11.7 |  |  | 11.5 |  |
| Commercial | 1.4 |  |  | 2.8 |  |  | 2.9 |  |
| Total income from equity method investments | $ | 12.0 |  |  | $ | 18.4 |  |  | $ | 18.4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001069202-19-000008:notes:342]
Restructuring Charges:

[0001069202-19-000008:notes:343]
We record restructuring charges associated with management-approved restructuring plans to reorganize or to remove duplicative headcount and infrastructure within our businesses.  Restructuring charges include severance costs to eliminate a specified number of employees, infrastructure charges to vacate facilities and consolidate operations, contract cancellation costs and other related activities.  The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over a multi-year period.  Restructuring charges are not included in our calculation of segment profit (loss), as more fully explained in Note 20.

[0001069202-19-000008:notes:344]
Restructuring Activities in 2018

[0001069202-19-000008:notes:345]
Information regarding the restructuring charges for all ongoing activities are presented in the table below (in millions):

[0001069202-19-000008:notes:346]
|  | Incurred in 2018 |  | Incurred to Date |  | Total Expected to be Incurred |
| Severance and related expense | $ | 1.7 |  |  | $ | 13.0 |  |  | $ | 13.8 |  |
| Asset write-offs and accelerated depreciation | — |  |  | 3.2 |  |  | 3.2 |  |
| Lease termination | 0.7 |  |  | 0.9 |  |  | 0.9 |  |
| Other | 0.6 |  |  | 4.7 |  |  | 4.7 |  |
| Total | $ | 3.0 |  |  | $ | 21.8 |  |  | $ | 22.6 |  |

[0001069202-19-000008:notes:347]
While restructuring charges are excluded from our calculation of segment profit (loss), the table below presents the restructuring charges associated with each segment (in millions):

[0001069202-19-000008:notes:348]
|  | Incurred in 2018 |  | Incurred to Date |  | Total Expected to be Incurred |
| Residential Heating & Cooling | $ | 0.6 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |
| Commercial Heating & Cooling | 1.1 |  |  | 3.1 |  |  | 3.1 |  |
| Refrigeration | 1.3 |  |  | 14.4 |  |  | 15.2 |  |
| Corporate & Other | — |  |  | 2.3 |  |  | 2.3 |  |
| Total | $ | 3.0 |  |  | $ | 21.8 |  |  | $ | 22.6 |  |

[0001069202-19-000008:notes:349]
Restructuring accruals are included in Accrued expenses in the accompanying Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001069202-19-000008:notes:350]
On January 1, 2018, we adopted the new accounting standard ASC 606, Revenue from Contracts with Customers and all the related amendments (“the new revenue standard”) and applied it to all contracts using the modified retrospective method.  We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to the opening balance of retained earnings.  The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.  We expect the impact of the adoption of the new standard to be immaterial to our net income on an ongoing basis.

[0001069202-19-000008:notes:351]
The cumulative effect of the changes made to our consolidated January 1, 2018 balance sheet for the adoption of the new revenue standard was as follows (in millions):

[0001069202-19-000008:notes:352]
| BALANCE SHEET | Balance at December 31, 2017 |  | Adjustments Due to ASC 606 |  | Balance at January 1, 2018 |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 506.5 |  |  | $ | 8.3 |  |  | $ | 514.8 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |  |  |  |  |  |
| Accounts payable | 348.6 |  |  | 9.3 |  |  | 357.9 |  |
| Retained earnings | 1,575.9 |  |  | (1.0 | ) |  | 1,574.9 |  |

[0001069202-19-000008:notes:353]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption on our Consolidated Balance Sheet and Consolidated Statement of Operations was as follows (in millions):

[0001069202-19-000008:notes:354]
|  | December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| BALANCE SHEET |  |  |  |  |  |
| ASSETS |  |  |  |  |  |
| Accounts and notes receivable, net | $ | 472.7 |  |  | $ | 465.9 |  |  | $ | 6.8 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |  |  |  |  |
| Accounts payable | 433.3 |  |  | 424.9 |  |  | 8.4 |  |
| Retained earnings | 1,855.0 |  |  | 1,856.6 |  |  | (1.6 | ) |

[0001069202-19-000008:notes:355]
|  | For the Year Ended December 31, 2018 |
|  | As Reported |  | Activity Without Adoption of ASC 606 |  | Effect of Change Higher/(Lower) |
| STATEMENT OF OPERATIONS |  |  |  |  |  |
| Net sales | $ | 3,883.9 |  |  | $ | 3,884.1 |  |  | $ | (0.2 | ) |
| Net income | 359.0 |  |  | 359.1 |  |  | (0.1 | ) |

[0001069202-19-000008:notes:356]
The following table disaggregates our revenue by business segment by geography which provides information as to the major sources of revenue.  See Note 20 for additional description of our reportable business segments and the products and services being sold in each segment.

[0001069202-19-000008:notes:357]
|  | For the Year Ended December 31, 2018 |
| Primary Geographic Markets | Residential Heating & Cooling |  | Commercial Heating & Cooling |  | Refrigeration |  | Consolidated |
| United States | $ | 2,066.7 |  |  | $ | 806.0 |  |  | $ | 403.2 |  |  | $ | 3,275.9 |  |
| Canada | 158.3 |  |  | 92.1 |  |  | 4.4 |  |  | 254.8 |  |
| International | — |  |  | 145.4 |  |  | 207.8 |  |  | 353.2 |  |
| Total | $ | 2,225.0 |  |  | 1,043.5 |  |  | 615.4 |  |  | 3,883.9 |  |

[0001069202-19-000008:notes:358]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.

[0001069202-19-000008:notes:359]
For our businesses that provide services, revenue is recognized at the time services are completed.  Our Commercial Heating & Cooling segment also provides sales, installation, maintenance and repair services under fixed-price contracts.  Revenue for services is recognized as the services are performed under the contract based on the relative fair value of the services provided.  We allocate a portion of the revenue for extended labor warranty obligations and recognize the revenue over the term of the extended warranty.  See Note 11 for more information on product warranties.

[0001069202-19-000008:notes:360]
Residential Heating & Cooling - We manufacture and market a broad range of furnaces, air conditioners, heat pumps, packaged heating and cooling systems, equipment and accessories to improve indoor air quality, comfort control products, replacement parts and supplies and related products for both the residential replacement and new construction markets in North America.  These products are sold under various brand names and are sold either through direct sales to a network of independent installing dealers, including through our network of Lennox PartsPlus stores or to independent distributors. For the segment, for the year ended December 31, 2018, direct sales represent approximately $1,698.7 million of revenues and sales to independent distributors represent approximately $526.3 million of revenues. Given the nature of our business, customer product orders are fulfilled at a point in time and not over a period of time.

[0001069202-19-000008:notes:361]
Commercial Heating & Cooling - In North America, we manufacture and sell unitary heating and cooling equipment used in light commercial applications, such as low-rise office buildings, restaurants, retail centers, churches and schools.  These products are distributed primarily through commercial contractors and directly to national account customers in the planned replacement, emergency replacement and new construction markets.  Revenue for the products sold is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  Lennox National Account Service provides installation, service and preventive maintenance for commercial HVAC national account customers in the United States and Canada.  Revenue related to service contracts is recognized as the services are performed under the contract based on the relative fair value of the services provided.  In Europe, we manufacture and sell unitary products and applied systems.  For the segment, for the year ended December 31, 2018, equipment sales represent approximately $917.1 million of revenues while $126.4 million of our revenue is generated from our service business.

[0001069202-19-000008:notes:362]
Refrigeration - We manufacture and market equipment for the global commercial refrigeration markets under the Heatcraft Worldwide Refrigeration name.  Our products are used in the food retail, food service, cold storage as well as non-food refrigeration markets.  We sell these products to distributors, installing contractors, engineering design firms, original equipment manufacturers and end-users.  Revenue for the products sold is $605.2 million for the year ended December 31, 2018 and is recognized at a point in time when control transfers to the customer, which is generally at time of shipment.  The remaining segment revenue relates to service revenues related to start-up and commissioning activities.

[0001069202-19-000008:notes:363]
Variable Consideration - We engage in cooperative advertising, customer rebate, and other miscellaneous programs that result in payments or credits being issued to our customers.  We record these customer discounts and incentives as a reduction of sales when the sales are recorded.  For certain cooperative advertising programs, we also receive an identifiable benefit (goods or services) in exchange for the consideration given, and, accordingly, record a ratable portion of the expenditure to SG&A expenses.  All other advertising, promotions and marketing costs are expensed as incurred.

[0001069202-19-000008:notes:364]
Other Judgments and Assumptions - We apply the practical expedient in ASC 606-10-50-14 and do not disclose information about remaining performance obligations that have original expected durations of one year or less.  Applying the practical expedient in ASC 340-40-25-4, we recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  These costs are included in SG&A expenses.  ASC 606-10-32-18 allows us to not adjust the amount of consideration to be received in a contract for any significant financing component if we expect to receive payment within twelve months of transfer of control of goods or services. We have elected this expedient as we expect all consideration to be received in one year or less at contract inception.  We have also elected not to provide the remaining performance obligations disclosures related to service contracts in accordance with the practical expedient in ASC 606-10-55-18.  We recognize revenue in the amount to which the entity has a right to invoice and have adopted this election to not provide the remaining performance obligations related to service contracts.

[0001069202-19-000008:notes:365]
Contract Assets - We do not have material amounts of contract assets since revenue is recognized as control of goods is transferred or as services are performed.  There are a small number of installation services that may occur over a period of time, but that period of time is generally very short in duration and right of payment does not exist until the installation is completed.  Any contract assets that may arise are recorded in Other assets in our Consolidated Balance Sheet.

[0001069202-19-000008:notes:366]
Contract Liabilities - Our contract liabilities consist of advance payments and deferred revenue.  Our contract liabilities are reported in a net position on a contract-by-contract basis at the end of each reporting period. We classify advance payments and deferred revenue as current or noncurrent based on the timing of when we expect to recognize revenue. Generally all contract liabilities are expected to be recognized within one year and are included in Accounts payable in our Consolidated Balance Sheet.  The noncurrent portion of deferred revenue is included in Other liabilities in our Consolidated Balance Sheet.

[0001069202-19-000008:notes:367]
For the year ended December 31, 2018, we recognized revenue of $4.8 million related to our contract liabilities at January 1, 2018.   Impairment losses recognized in our receivables and contract assets were de minimis in fiscal 2018.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001069202-19-000008:notes:368]
Revenue Recognition

[0001069202-19-000008:notes:369]
Our revenue recognition practices for the sale of goods depend upon the shipping terms for each transaction.  Shipping terms are primarily FOB Shipping Point and, therefore, revenue is recognized for these transactions when products are shipped to customers and title and control passes.  Certain customers in our smaller operations, primarily outside of North America, have shipping terms where risks and rewards of ownership do not transfer until the product is delivered to the customer.  For these transactions, revenue is recognized on the date that the product is received and accepted by such customers.  We experience returns for miscellaneous reasons and record a reserve for these returns at the time we recognize revenue based on historical experience.  Our historical rates of return are insignificant as a percentage of sales.  We also recognize revenue net of sales taxes.  We have elected to recognize the revenue and cost for freight and shipping when control over the sale of goods passes to our customers.  See Note 3 for more information on our revenue recognition practices.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001069202-19-000008:notes:370]
The following table summarizes the net loss recognized in connection with this divestiture:


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001069202-19-000008:notes:371]
Property, plant and equipment, net for each major geographic area in which we operate, based on the domicile of our operations, are shown below (in millions):

[0001069202-19-000008:notes:372]
|  | As of December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Property, Plant and Equipment, net: |  |  |  |  |  |
| United States | $ | 293.3 |  |  | $ | 257.6 |  |  | $ | 237.6 |  |
| Mexico | 86.7 |  |  | 79.8 |  |  | 69.4 |  |
| Canada | 1.7 |  |  | 1.7 |  |  | 1.4 |  |
| International | 26.6 |  |  | 58.7 |  |  | 53.0 |  |
| Total Property, plant and equipment, net | $ | 408.3 |  |  | $ | 397.8 |  |  | $ | 361.4 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001069202-19-000008:notes:373]
We amortize intangible assets and other assets with finite lives over their respective estimated useful lives to their estimated residual values, as follows:

[0001069202-19-000008:notes:374]
| Asset | Useful Life |
| Deferred financing costs | Effective interest method |
| Customer relationships | Straight-line method up to 12 years |
| Patents and others | Straight-line method up to 20 years |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001069202-19-000008:notes:375]
Net sales for each major geographic area in which we operate are shown below (in millions):

[0001069202-19-000008:notes:376]
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Net Sales to External Customers by Point of Shipment: |  |  |  |  |  |
| United States | $ | 3,275.9 |  |  | $ | 3,128.7 |  |  | $ | 2,966.8 |  |
| Canada | 254.8 |  |  | 237.8 |  |  | 218.8 |  |
| International | 353.2 |  |  | 473.1 |  |  | 456.0 |  |
| Total net sales to external customers | $ | 3,883.9 |  |  | $ | 3,839.6 |  |  | $ | 3,641.6 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001069202-19-000008:notes:377]
We operate in three reportable business segments of the heating, ventilation, air conditioning and refrigeration (“HVACR”) industry.  Our segments are organized primarily by the nature of the products and services we provide.  The following table describes each segment:

[0001069202-19-000008:notes:378]
| Segment |  | Products or Services |  | Markets Served |  | Geographic Areas |
| Residential Heating & Cooling |  | Furnaces, air conditioners, heat pumps, packaged heating and cooling systems, indoor air quality equipment, comfort control products, replacement parts and supplies |  | Residential Replacement;Residential New Construction |  | United StatesCanada |
| Commercial Heating & Cooling |  | Unitary heating and air conditioning equipment, applied systems, controls, installation and service of commercial heating and cooling equipment, variable refrigerant flow commercial products |  | Light Commercial |  | United StatesCanadaEurope |
| Refrigeration |  | Condensing units, unit coolers, fluid coolers, air- cooled condensers, air handlers, process chillers, controls, compressorized racks, supermarket display cases and systems |  | Light Commercial; Food Preservation; Non-Food/Industrial |  | United StatesCanadaEuropeAsia Pacific*South America*Central America |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001069202-19-000008:notes:379]
Reportable Business Segments:

[0001069202-19-000008:notes:380]
Description of Segments

[0001069202-19-000008:notes:381]
*Our businesses in Australia, Asia and South America were sold in the second and third quarters of 2018, respectively. Refer to Note 17 for details regarding the divestiture of the businesses.

[0001069202-19-000008:notes:382]
Segment Data

[0001069202-19-000008:notes:383]
We use segment profit or loss as the primary measure of profitability to evaluate operating performance and to allocate capital resources.  We define segment profit or loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding certain items.  The reconciliation below details the items excluded.

[0001069202-19-000008:notes:384]
Our corporate costs include those costs related to corporate functions such as legal, internal audit, treasury, human resources, tax compliance and senior executive staff.  Corporate costs also include the long-term, share-based incentive awards provided to employees throughout our business.  We recorded these share-based awards as Corporate costs because they are determined at the discretion of the Board of Directors and based on the historical practice of doing so for internal reporting purposes.

[0001069202-19-000008:notes:385]
Any intercompany sales and associated profit (and any other intercompany items) are eliminated from segment results.  There were no significant intercompany eliminations included in the results presented in the table below.

[0001069202-19-000008:notes:386]
(2) We define segment profit (loss) as a segment’s operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000008:notes:387]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000008:notes:388]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000008:notes:389]
| ◦ | Special legal contingency charges, |

[0001069202-19-000008:notes:390]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000008:notes:391]
| ◦ | Environmental liabilities, |

[0001069202-19-000008:notes:392]
| ◦ | Contractor tax payments, |

[0001069202-19-000008:notes:393]
| ◦ | Other items, net, |

[0001069202-19-000008:notes:394]
| • | Special inventory write down, |

[0001069202-19-000008:notes:395]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-19-000008:notes:396]
| • | Gain from insurance recoveries, net of losses incurred |

[0001069202-19-000008:notes:397]
| • | Special product quality adjustment, |

[0001069202-19-000008:notes:398]
| • | Pension settlement, and, |

[0001069202-19-000008:notes:399]
| • | Restructuring charges. |

[0001069202-19-000008:notes:400]
The assets in the Corporate and other segment primarily consist of cash, short-term investments and deferred tax assets.  Assets recorded in the operating segments represent those assets directly associated with those segments.

[0001069202-19-000008:notes:401]
Geographic Information


## us-gaap:SelfInsuranceReservePolicyTextBlock

[0001069202-19-000008:notes:402]
Self-insurance expense and liabilities were actuarially determined based primarily on our historical claims information, industry factors and trends.  The self-insurance liabilities as of December 31, 2018 represent the best estimate of the future payments to be made on reported and unreported losses for 2018 and prior years.  The amounts and timing of payments for claims reserved may vary depending on various factors, including the development and ultimate settlement of reported and unreported claims.  To the extent actuarial assumptions change and claims experience rates differ from historical rates, our liabilities may change.  See Note 11 for additional information on our self-insured risks and liabilities.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001069202-19-000008:notes:403]
Selling, General and Administrative Expenses

[0001069202-19-000008:notes:404]
SG&A expenses include payroll and benefit costs, advertising, commissions, research and development, information technology costs, and other selling, general and administrative related costs such as insurance, travel, non-production depreciation and rent.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001069202-19-000008:notes:405]
Summary of Significant Accounting Policies:

[0001069202-19-000008:notes:406]
Goodwill represents the excess of cost over fair value of assets from acquired businesses.  Goodwill is not amortized, but is reviewed for impairment annually and whenever events or changes in circumstances indicate the asset may be impaired (See Note 5 for additional information on our goodwill).  The annual goodwill impairment test was performed during the fourth quarter of 2018.

[0001069202-19-000008:notes:407]
The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative goodwill impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, our market capitalization, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and for each reporting unit.

[0001069202-19-000008:notes:408]
If a quantitative goodwill impairment test is determined to be necessary, we estimate reporting unit fair values using a combination of the discounted cash flow approach and a market approach. The discounted cash flows used to estimate fair value are based on assumptions regarding each reporting unit’s estimated projected future cash flows and the estimated weighted-average cost of capital that a market participant would use in evaluating the reporting unit in a purchase transaction. The estimated weighted-average cost of capital is based on the risk-free interest rate and other factors such as equity risk premiums and the ratio of total debt to equity capital. In performing these impairment tests, we take steps to ensure that appropriate and reasonable cash flow projections and assumptions are used. We reconcile our estimated enterprise value to our market capitalization and determine the reasonableness of the cost of capital used by comparing to market data. We also perform sensitivity analyses on the key assumptions used, such as the weighted-average cost of capital and terminal growth rates. The market approach is based on objective evidence of market values.

[0001069202-19-000008:notes:409]
Intangible Assets

[0001069202-19-000008:notes:410]
We periodically review intangible assets with estimable useful lives for impairment as events or changes in circumstances indicate that the carrying amount of such assets might not be recoverable.  We assess recoverability by comparing the estimated expected undiscounted future cash flows identified with each intangible asset or related asset group to the carrying amount of such assets.  If the expected future cash flows do not exceed the carrying value of the asset or assets being reviewed, an impairment loss is recognized based on the excess of the carrying amount of the impaired assets over their fair value.  In assessing the fair value of these intangible assets, we must make assumptions that a market participant would make regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  If these estimates or the related assumptions change, we may be required to record impairment charges for these assets in the future.

[0001069202-19-000008:notes:411]
We review our indefinite-lived intangible assets for impairment annually in the fourth quarter and whenever events or changes in circumstances indicate the asset may be impaired.  The provisions of the accounting standard for indefinite-lived intangible assets allow us to first assess qualitative factors to determine whether it is necessary to perform a two-step quantitative impairment test.  As part of our qualitative assessment, we monitor economic, legal, regulatory and other factors, industry trends, recent and forecasted financial performance of our reporting units and the timing and nature of our restructuring activities for LII as a whole and as they relate to the fair value of the assets.

[0001069202-19-000008:notes:412]
Product Warranties

[0001069202-19-000008:notes:413]
For some of our heating, ventilation and air conditioning (“HVAC”) products, we provide warranty terms ranging from one to 20 years to customers for certain components such as compressors or heat exchangers.  For select products, we also provide limited lifetime warranties.  A liability for estimated warranty expense is recorded on the date that revenue is recognized. Our estimates of future warranty costs are determined by product line. The number of units we expect to repair or replace is determined by applying an estimated failure rate, which is generally based on historical experience, to the number of units that were sold and are still under warranty. The estimated units to be repaired under warranty are multiplied by the average cost to repair or replace such products to determine the estimated future warranty cost.  We do not discount product warranty liabilities as the amounts are not fixed and the timing of future cash payments is neither fixed nor reliably determinable. We also provide for specifically-identified warranty obligations.  Estimated future warranty costs are subject to adjustment depending on changes in actual failure rate and cost experience.  Subsequent costs incurred for warranty claims serve to reduce the accrued product warranty liability.  See Note 11 for more information on our estimated future warranty costs.

[0001069202-19-000008:notes:414]
Pensions and Post-retirement Benefits

[0001069202-19-000008:notes:415]
We provide pension and post-retirement medical benefits to eligible domestic and foreign employees and we recognize pension and post-retirement benefit costs over the estimated service life or average life expectancy of those employees.  We also recognize the funded status of our benefit plans, as measured at year-end by the difference between plan assets at fair value and the benefit obligation, in the Consolidated Balance Sheets.  Changes in the funded status are recognized in the year in which the changes occur through accumulated other comprehensive loss (“AOCL”).  Actuarial gains or losses are amortized into net period benefit cost over the estimated service life of covered employees or average life expectancy of participants depending on the plan.

[0001069202-19-000008:notes:416]
The benefit plan assets and liabilities reflect assumptions about the long-range performance of our benefit plans.  Should actual results differ from management’s estimates, revisions to the benefit plan assets and liabilities would be required.  See Note 13 for information regarding those estimates and additional disclosures on pension and post-retirement medical benefits.

[0001069202-19-000008:notes:417]
Stock-Based Compensation

[0001069202-19-000008:notes:418]
We recognize compensation expense for stock-based arrangements over the required employee service periods. We measure stock-based compensation costs based on the estimated grant-date fair value of the stock-based awards that are expected to ultimately vest and we adjust expected vesting rates to actual rates as additional information becomes known.  For stock-based arrangements with performance conditions, we periodically adjust performance achievement rates based on our best estimates of those rates at the end of the performance period.  See Note 15 for more information.

[0001069202-19-000008:notes:419]
Use of Estimates

[0001069202-19-000008:notes:420]
The preparation of financial statements requires us to make estimates and assumptions about future events.  These estimates and the underlying assumptions affect the amounts of assets and liabilities reported, disclosures about contingent assets and liabilities, and reported amounts of revenue and expenses.  Such estimates include the valuation of accounts receivable, inventories, goodwill, intangible assets and other long-lived assets, contingencies, product warranties, guarantee obligations, indemnifications, and assumptions used in the calculation of income taxes, pension and post-retirement medical benefits, and stock-based compensation among others. These estimates and assumptions are based on our best estimates and judgment.

[0001069202-19-000008:notes:421]
We evaluate these estimates and assumptions on an ongoing basis using historical experience and other factors, including the current economic environment.  We believe these estimates and assumptions to be reasonable under the circumstances and will adjust such estimates and assumptions when facts and circumstances dictate.  Volatile equity, foreign currency and commodity markets and uncertain future economic conditions combine to increase the uncertainty inherent in such estimates and assumptions.  Future events and their effects cannot be determined with precision and actual results could differ significantly from these estimates.  Changes in these estimates resulting from continuing changes in the economic environment will be reflected in the financial statements in future periods.

[0001069202-19-000008:notes:422]
Reclassifications

[0001069202-19-000008:notes:423]
Certain amounts have been reclassified from the prior year presentation to conform to the current year presentation.


## us-gaap:TreasuryStockTextBlock

[0001069202-19-000008:notes:424]
Stock Repurchases:

[0001069202-19-000008:notes:425]
Our Board of Directors has authorized a total of $2.5 billion to repurchase of shares of our common stock (collectively referred to as the “Share Repurchase Plans”), including a $500 million share repurchase authorization in March 2018. The Share Repurchase Plans authorize open market repurchase transactions and do not have a stated expiration date. As of December 31, 2018, $446.0 million may be used to repurchase shares under the Share Repurchase Plans.

[0001069202-19-000008:notes:426]
On February 8, 2018, the Company entered into a Fixed Dollar Accelerated Share Repurchase Transaction (the “ASR Agreement”) with MUFG Securities EMEA plc (“MUFG”), to effect an accelerated stock buyback of our common stock. Under the ASR Agreement, on February 8, 2018, we paid MUFG an initial purchase price of $150.0 million, and MUFG delivered to us common stock, representing approximately 85% of the shares expected to be purchased under the ASR Agreement. The ASR was completed in April of 2018 and MUFG delivered additional shares for a total of 0.7 million shares of common stock repurchased as part of this ASR Agreement.

[0001069202-19-000008:notes:427]
We repurchased 1.0 million shares for $200.2 million in open market transactions during the second quarter of 2018 and 0.5 million shares for $100.0 million in open market transactions during the fourth quarter of 2018.

[0001069202-19-000008:notes:428]
We also repurchased 0.1 million  shares for $26.9 million and 0.1 million shares for $26.1 million for the years ended December 31, 2018 and 2017, respectively, from employees who surrendered their shares to satisfy minimum tax withholding obligation upon the vesting of stock-based compensation awards.
