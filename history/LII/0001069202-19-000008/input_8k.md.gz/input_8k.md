# LII 8-K — 0001069202-19-000005 filed 2019-02-05

## item codes, every 8-K on or before 2019-02-19

- 2019-02-05 0001069202-19-000005 — 2.02, 9.01
- 2019-01-25 0001069202-19-000002 — 1.01, 2.03, 9.01
- 2018-10-22 0001069202-18-000018 — 2.02, 9.01
- 2018-08-21 0001193125-18-253214 — 7.01, 9.01
- 2018-07-24 0001193125-18-224205 — 8.01, 9.01
- 2018-07-23 0001193125-18-223176 — 2.02, 9.01
- 2018-05-22 0001193125-18-170390 — 5.07
- 2018-04-23 0001193125-18-125935 — 2.02, 9.01
- 2018-02-06 0001193125-18-032739 — 2.02, 9.01
- 2017-11-16 0001193125-17-345550 — 1.01, 2.03, 9.01
- 2017-10-23 0001193125-17-316060 — 2.02, 9.01
- 2017-10-05 0001193125-17-304180 — 5.02, 9.01
- 2017-07-24 0001193125-17-233271 — 2.02, 9.01
- 2017-05-19 0001193125-17-176607 — 5.07
- 2017-04-24 0001193125-17-133519 — 2.02, 9.01
- 2017-04-07 0001193125-17-115301 — 5.02
- 2017-03-21 0001193125-17-090770 — 5.02
- 2017-02-16 0001193125-17-046800 — 7.01
- 2017-02-07 0001193125-17-032530 — 2.02, 9.01
- 2016-11-03 0001193125-16-758285 — 1.01, 2.03, 9.01
- 2016-10-26 0001193125-16-747917 — 8.01, 9.01
- 2016-10-17 0001193125-16-739148 — 2.02, 9.01
- 2016-09-19 0001193125-16-713607 — 5.02, 9.01
- 2016-09-02 0001193125-16-700842 — 1.01, 2.03, 9.01
- 2016-07-18 0001193125-16-649843 — 2.02, 9.01
- 2016-07-06 0001193125-16-642453 — 1.01, 2.03, 9.01
- 2016-05-13 0001193125-16-590387 — 5.07
- 2016-04-18 0001193125-16-543967 — 2.02, 9.01
- 2016-02-10 0001193125-16-457085 — 1.01, 2.03, 9.01
- 2016-02-08 0001193125-16-453117 — 2.02, 9.01
- 2015-11-18 0001193125-15-380409 — 1.01, 2.03, 9.01
- 2015-10-19 0001193125-15-346279 — 2.02, 9.01
- 2015-07-20 0001193125-15-256551 — 2.02, 9.01
- 2015-06-10 0001193125-15-219294 — 5.02, 9.01
- 2015-05-14 0001193125-15-188286 — 5.07
- 2015-04-20 0001193125-15-137041 — 2.02, 9.01
- 2015-02-02 0001193125-15-028688 — 2.02, 9.01
- 2014-12-18 0001193125-14-446884 — 1.01, 2.03, 9.01
- 2014-11-24 0001193125-14-423340 — 1.01, 2.03, 9.01
- 2014-11-14 0001193125-14-413291 — 1.01, 2.03, 9.01
- 2014-10-24 0001193125-14-381438 — 1.01, 2.03, 9.01
- 2014-10-20 0001193125-14-375643 — 2.02, 9.01
- 2014-09-08 0001193125-14-335105 — 5.02, 9.01
- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2019-02-19

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001069202-19-000005:8k_2_02:1]
EX-99.1
2
ex-991pressreleasetables20.htm
EXHIBIT 99.1

[0001069202-19-000005:8k_2_02:2]
Exhibit

[0001069202-19-000005:8k_2_02:3]
Exhibit-99.1

[0001069202-19-000005:8k_2_02:4]
Lennox International Caps Year of Record Revenue, Profit and Cash Generation in 2018 and Reiterates Outlook for Strong Growth and Profitability in 2019

[0001069202-19-000005:8k_2_02:5]
| • | 2018 GAAP revenue a record $3.88 billion, up 1%; adjusted revenue up 4% excluding the impact from divestitures; tornado impact of negative 3% on revenue growth for the full year |

[0001069202-19-000005:8k_2_02:6]
| • | 2018 GAAP EPS from continuing operations up 22% to record $8.77; adjusted EPS from continuing operations up 20% to record $9.42 |

[0001069202-19-000005:8k_2_02:7]
| • | Generated $496 million of cash from operations and $411 million of free cash flow in 2018 |

[0001069202-19-000005:8k_2_02:8]
| • | Fourth-quarter GAAP revenue down 5%; adjusted revenue up slightly excluding the impact from divestitures; tornado impact of negative 8% on revenue growth in the quarter |

[0001069202-19-000005:8k_2_02:9]
| • | Fourth-quarter GAAP EPS from continuing operations up 82% to fourth-quarter record $1.86; adjusted EPS from continuing operations up 18% to fourth-quarter record $1.93 |

[0001069202-19-000005:8k_2_02:10]
| • | Reiterating 2019 guidance for revenue growth of 3-7% |

[0001069202-19-000005:8k_2_02:11]
| • | Reiterating 2019 guidance for GAAP EPS from continuing operations of $14.30-$14.90 and adjusted EPS from continuing operations of $12.00-$12.60 |

[0001069202-19-000005:8k_2_02:12]
| • | Reiterating 2019 guidance for stock repurchases of $350 million |

[0001069202-19-000005:8k_2_02:13]
| • | Announcing plans to divest the company’s Kysor Warren refrigeration business |

[0001069202-19-000005:8k_2_02:14]
DALLAS, February 5, 2019 - Lennox International Inc. (NYSE: LII) today reported fourth-quarter and full-year 2018 results. All comparisons are to the prior-year period. The company’s tornado references relate to the July 2018 tornado damage at a Residential manufacturing facility in Iowa. Adjusted revenue and profit exclude the non-core Refrigeration businesses divested in 2018 -- Australia, Asia and South America. In 2019, the company plans to divest its Kysor Warren business within its Refrigeration segment and is currently targeting to close the sale in the first quarter.

[0001069202-19-000005:8k_2_02:15]
For the fourth quarter, GAAP and adjusted revenue was $844 million. GAAP revenue was down 5%, including the impact from divestitures and the tornado. At constant currency, GAAP revenue was down 4%. GAAP operating income was a fourth-quarter record $116 million, up 12%. GAAP earnings per share from continuing operations was a fourth-quarter record $1.86, up 82%.

[0001069202-19-000005:8k_2_02:16]
Adjusted revenue, excluding the impact from divestitures, was up slightly in the fourth quarter. At constant currency, adjusted revenue was up 1%. The tornado had a negative 8% impact on revenue growth in the quarter. Total segment profit increased 7% to a fourth-quarter record $110 million, and total segment margin expanded 70 basis points to a fourth-quarter record 13.0%. Adjusted earnings per share from continuing operations rose 18% to a fourth-quarter record $1.93.

[0001069202-19-000005:8k_2_02:17]
For the full year, revenue was a record $3.88 billion on a GAAP basis, up 1% including the impact from divestitures and the tornado. Foreign exchange was neutral to revenue. GAAP operating income was a record $510 million, up 3%. GAAP earnings per share from continuing operations was a record $8.77, up 22%.

[0001069202-19-000005:8k_2_02:18]
Adjusted revenue for the full year, excluding the impact from divestitures, was $3.81 billion, up 4%. The tornado had a negative 3% impact on revenue growth for the full year. Foreign exchange was neutral to revenue. Total segment profit increased 6% to a record $540 million, and total segment margin expanded

[0001069202-19-000005:8k_2_02:19]
30 basis points to a record 14.2%. Adjusted earnings per share from continuing operations rose 20% to a record $9.42 for the full year

[0001069202-19-000005:8k_2_02:20]
“Lennox International posted a record year for revenue, profitability, and cash generation in 2018 while working through the challenges from tornado damage at a large manufacturing facility and further focusing our business portfolio with refrigeration divestitures in Australia, Asia and South America,” said Chairman and CEO Todd Bluedorn. “We plan another divestiture in 2019 with the sale of the Kysor Warren business within our Refrigeration segment to focus on our businesses that have strong market positions and fit our growth profile.

[0001069202-19-000005:8k_2_02:21]
“In the fourth quarter, Residential reported tornado-impacted financial results of revenue down 3%, segment margin up 170 basis points to 17.7%, and segment profit up 7%. Residential revenue had $69 million of tornado impact in the fourth quarter, a 14% hit to top-line growth. Segment profit had $40 million of negative tornado impact in the fourth quarter, partially offset by $27 million of insurance proceeds received for third-quarter lost profits. We continue to expect fourth-quarter 2018 and 2019 lost profits from business interruption to be fully offset by insurance proceeds in 2019.

[0001069202-19-000005:8k_2_02:22]
“In Commercial, revenue set a new fourth-quarter high and was up 9% at constant currency on strong and broad growth in North America. Segment margin declined 240 basis points in the fourth quarter and profit was down 7%, primarily from the timing of other product costs in the quarter, as well as labor inefficiencies and lower factory productivity. We expect these factors to be largely behind us in the first quarter and segment margin to expand in 2019.

[0001069202-19-000005:8k_2_02:23]
“In Refrigeration for the fourth quarter, revenue at constant currency was up 1%, adjusted for the divestitures. Kysor Warren revenue was down significantly from the prior-year quarter, while the remainder of our North America revenue was up high-single digits. Europe revenue was up mid-teens at constant currency. Refrigeration segment margin declined 310 basis points to 9.2%, and profit was down 25% in the fourth quarter on mix and the timing of certain expenses and other products costs. As in Commercial, we expect organic margin expansion in 2019 for Refrigeration.

[0001069202-19-000005:8k_2_02:24]
“Looking ahead for the company overall, the first quarter is off to a solid start, and we reiterate guidance for 2019. The company is well-positioned for a year of strong growth and profitability, and we will continue to invest in the business to drive future performance, grow the dividend with earnings over time, and repurchase stock, with $350 million planned for 2019.”

[0001069202-19-000005:8k_2_02:25]
FOURTH QUARTER 2018 FINANCIAL HIGHLIGHTS

[0001069202-19-000005:8k_2_02:26]
Revenue: GAAP revenue for the fourth quarter was $844 million, down 5% including the impact from divestitures and the tornado. Adjusted revenue was up slightly. Foreign exchange had a negative 1% impact on revenue. Volume and mix were down, and price was up from the fourth quarter a year ago.

[0001069202-19-000005:8k_2_02:27]
Gross Profit: Including the impact from the tornado and divestitures, GAAP gross profit in the fourth quarter was $225 million, down 14%. GAAP gross margin was 26.6%, down 250 basis points. GAAP gross profit was impacted by lower volume and factory absorption, unfavorable mix, unfavorable foreign exchange, higher commodity, tariffs, freight, and other product costs, and investments in distribution. Partial offsets included higher price and sourcing and engineering-led cost reductions.

[0001069202-19-000005:8k_2_02:28]
Income from Continuing Operations: On a GAAP basis, fourth quarter income from continuing operations was $75.3 million, or $1.86 diluted earnings per share, compared to $43.1 million, or $1.02 diluted earnings per share, in the prior-year quarter.

[0001069202-19-000005:8k_2_02:29]
On an adjusted basis, fourth quarter income from continuing operations was $77.9 million, or $1.93 diluted earnings per share, compared to $69.0 million, or $1.63 diluted earnings per share, in the prior-year quarter. Adjusted income from continuing operations for the fourth quarter of 2018 excludes net after-tax charges of $2.6 million: a charge of $10.5 million for other tax items, net; a charge of $4.4 million, net, for restructuring and various other items; a gain of $8.4 million from insurance recoveries, net of losses incurred; and a benefit of $3.9 million for excess tax benefits from share-based compensation.

[0001069202-19-000005:8k_2_02:30]
FULL YEAR 2018 FINANCIAL HIGHLIGHTS

[0001069202-19-000005:8k_2_02:31]
Revenue: For the full year, GAAP revenue was $3.88 billion, up 1% including the impact from divestitures and the tornado. Adjusted revenue of $3.81 billion was up 4%. Foreign exchange was neutral to revenue. Volume and price were up, and mix was down from the prior year.

[0001069202-19-000005:8k_2_02:32]
Gross Profit: Including the impact from the tornado and divestitures, GAAP gross profit for the full year was $1.11 billion, down 1%. GAAP gross margin was 28.6%, down 70 basis points. GAAP gross profit was impacted by the tornado and divestitures, unfavorable mix, higher commodity, tariffs, freight, and other product costs, and investments in distribution. Partial offsets included higher volume, price, and sourcing and engineering-led cost reductions.

[0001069202-19-000005:8k_2_02:33]
Income from Continuing Operations: On a GAAP basis, income from continuing operations for 2018 was $360.3 million, or $8.77 diluted earnings per share, compared to $307.1 million, or $7.17 diluted earnings per share, in the prior year.

[0001069202-19-000005:8k_2_02:34]
On an adjusted basis, income from continuing operations for 2018 was $385.9 million, or $9.42 diluted earnings per share, compared to $334.0 million, or $7.83 diluted earnings per share, in the prior year. Adjusted income from continuing operations for 2018 excludes net after-tax charges of $25.6 million: a net loss of $26.0 million on sale of businesses and related property; a net charge of $5.8 million for other tax items; a net charge of $12.5 million for restructuring and various other items; a benefit of $10.5 million for excess tax benefits from share-based compensation; and a gain of $8.2 million for insurance recoveries, net of losses incurred.

[0001069202-19-000005:8k_2_02:35]
Free Cash Flow and Total Debt: For the full year, cash from operations was approximately $496 million compared to $325 million in the prior year. Capital expenditures were $95 million compared to $98 million in the prior year. Including $11 million from proceeds from damage to property, free cash flow was $411 million for the full year compared to $227 million in the prior year. In 2018, the company paid $94 million in dividends and repurchased $450 million of company stock. Ending the year, total debt was $1.04 billion, and the company’s debt-to-EBITDA ratio stood at 1.7. Total cash and cash equivalents were $46 million at the end of the year.

[0001069202-19-000005:8k_2_02:36]
BUSINESS SEGMENT FINANCIAL HIGHLIGHTS

[0001069202-19-000005:8k_2_02:37]
Residential Heating and Cooling

[0001069202-19-000005:8k_2_02:38]
| • | 4Q18 revenue $461 million, down 3%; neutral foreign exchange |

[0001069202-19-000005:8k_2_02:39]
| • | 4Q18 segment profit $82 million, up 7% |

[0001069202-19-000005:8k_2_02:40]
| • | 4Q18 segment margin a fourth-quarter record 17.7%, up 170 basis points |

[0001069202-19-000005:8k_2_02:41]
| • | 2018 revenue a record $2.23 billion, up 4%; neutral foreign exchange |

[0001069202-19-000005:8k_2_02:42]
| • | 2018 segment profit a record $399 million, up 7% |

[0001069202-19-000005:8k_2_02:43]
| • | 2018 segment margin a record 18.0%, up 50 basis points |

[0001069202-19-000005:8k_2_02:44]
Fourth-quarter results were favorably impacted by tornado insurance proceeds for third-quarter lost profits, favorable price, sourcing and engineering-led cost reductions, and factory productivity. Partial offsets included the fourth-quarter tornado impact, lower volume, unfavorable mix, unfavorable foreign exchange, higher commodity, tariff, freight and other product costs, distribution investments, and higher SG&A. Full-year results were impacted by higher volume, favorable price, sourcing and engineering-led cost reductions, factory productivity, and tornado insurance proceeds. Partial offsets included the second-half tornado impact, higher commodity, tariff, freight, warranty, and other product costs, distribution investments, higher SG&A, and unfavorable foreign exchange.

[0001069202-19-000005:8k_2_02:45]
Commercial Heating and Cooling

[0001069202-19-000005:8k_2_02:46]
| • | 4Q18 revenue a fourth-quarter record $270 million, up 8%; up 9% at constant currency |

[0001069202-19-000005:8k_2_02:47]
| • | 4Q18 segment profit $41 million, down 7% |

[0001069202-19-000005:8k_2_02:48]
| • | 4Q18 segment margin 15.0%, down 240 basis points |

[0001069202-19-000005:8k_2_02:49]
| • | 2018 revenue a record $1.04 billion, up 7%; neutral foreign exchange |

[0001069202-19-000005:8k_2_02:50]
| • | 2018 segment profit a record $160 million, up 1% |

[0001069202-19-000005:8k_2_02:51]
| • | 2018 segment margin 15.3%, down 90 basis points |

[0001069202-19-000005:8k_2_02:52]
Fourth-quarter results were impacted by the timing of other product costs, lower factory productivity, higher commodity and freight costs, and higher SG&A. Partial offsets included higher volume, favorable price, favorable mix, and sourcing and engineering-led cost reductions. Full-year results were impacted by lower factory productivity and higher other product costs, higher commodity and freight costs, distribution investments, and higher SG&A. Partial offsets included higher volume, favorable price, favorable warranty, and sourcing and engineering-led cost reductions.

[0001069202-19-000005:8k_2_02:53]
Refrigeration

[0001069202-19-000005:8k_2_02:54]
| • | 4Q18 revenue $113 million, flat; up 1% at constant currency |

[0001069202-19-000005:8k_2_02:55]
| • | 4Q18 segment profit $10 million, down 25% |

[0001069202-19-000005:8k_2_02:56]
| • | 4Q18 segment margin 9.2%, down 310 basis points |

[0001069202-19-000005:8k_2_02:57]
| • | 2018 revenue $545 million, up 1%; neutral foreign exchange |

[0001069202-19-000005:8k_2_02:58]
| • | 2018 segment profit $66 million, down 1% |

[0001069202-19-000005:8k_2_02:59]
| • | 2018 segment margin 12.0%, down 30 basis points |

[0001069202-19-000005:8k_2_02:60]
Fourth-quarter results were impacted by unfavorable mix, higher commodity, freight, distribution and other product costs, and higher SG&A. Partial offsets included higher volume, favorable price, and sourcing and engineering-led cost reductions. Full-year results were impacted by unfavorable mix, higher commodity, freight, distribution and other product costs. Partial offsets included higher volume, favorable price, sourcing and engineering-led cost reductions, lower SG&A, and favorable foreign exchange.

[0001069202-19-000005:8k_2_02:61]
2019 FULL-YEAR OUTLOOK

[0001069202-19-000005:8k_2_02:62]
The company reiterates its financial guidance for 2019:

[0001069202-19-000005:8k_2_02:63]
| • | Revenue growth of 3-7% |

[0001069202-19-000005:8k_2_02:64]
| • | GAAP EPS from continuing operations of $14.30-$14.90 |

[0001069202-19-000005:8k_2_02:65]
| • | Adjusted EPS from continuing operations of $12.00-$12.60 |

[0001069202-19-000005:8k_2_02:66]
| • | Corporate expenses of approximately $90 million |

[0001069202-19-000005:8k_2_02:67]
| • | Effective tax rate of 22-23% on an adjusted basis for the full year |

[0001069202-19-000005:8k_2_02:68]
| • | Capital expenditures of approximately $215 million, including $115 million in 2019 to complete the reconstruction of the Iowa manufacturing facility, funded by insurance proceeds |

[0001069202-19-000005:8k_2_02:69]
| • | $350 million of stock repurchases |

[0001069202-19-000005:8k_2_02:70]
A chart of the company’s current view on the tornado financial impact and insurance recovery for 2018-2019 is posted on the company’s website at www.lennoxinternational.com.

[0001069202-19-000005:8k_2_02:71]
For 2019, the company plans to shift financial reporting of the European Commercial HVAC business from the Commercial segment to the Refrigeration segment as the company will manage both its commercial HVAC and refrigeration operations in Europe together. In addition for 2019, Kysor Warren will be excluded from the 2019 adjusted financials due to the planned divestiture of that business. The company has posted on its website reclassified Commercial and Refrigeration segment revenue and profit for 2018 by quarter to reflect these changes.

[0001069202-19-000005:8k_2_02:72]
CONFERENCE CALL INFORMATION

[0001069202-19-000005:8k_2_02:73]
A conference call to discuss the company's fourth-quarter and full-year 2018 results will be held this morning at 8:30 a.m. Central time. To listen, call the conference call line at 612-234-9960 at least 10 minutes prior to the scheduled start time and use reservation number 462661. The conference call also will be webcast on Lennox International's web site at www.lennoxinternational.com. A replay will be available from 11:00 a.m. Central time on February 5 through February 19, 2019, by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 462661. The call also will be archived on the company's web site.

[0001069202-19-000005:8k_2_02:74]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is listed on the New York Stock Exchange and traded under the symbol "LII". Additional information on Lennox International is available at www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001069202-19-000005:8k_2_02:75]
FORWARD-LOOKING STATEMENTS

[0001069202-19-000005:8k_2_02:76]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Statements of Operations |
| (Amounts in millions, except per share data) | For the Three Months Ended December 31,(Unaudited) |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales | $ | 843.6 |  |  | $ | 891.8 |  |  | $ | 3,883.9 |  |  | $ | 3,839.6 |  |
| Cost of goods sold | 619.1 |  |  | 632.0 |  |  | 2,772.7 |  |  | 2,714.4 |  |
| Gross profit | 224.5 |  |  | 259.8 |  |  | 1,111.2 |  |  | 1,125.2 |  |
| Operating Expenses: |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 142.1 |  |  | 158.2 |  |  | 608.2 |  |  | 637.7 |  |
| Losses (gains) and other expenses, net | 3.3 |  |  | (1.5 | ) |  | 13.4 |  |  | 7.1 |  |
| Restructuring charges | 1.1 |  |  | 1.2 |  |  | 3.0 |  |  | 3.2 |  |
| Pension settlement | 0.4 |  |  | — |  |  | 0.4 |  |  | — |  |
| Loss (gain), net on sale of businesses and related property | 1.2 |  |  | 1.1 |  |  | 27.0 |  |  | 1.1 |  |
| Insurance proceeds for lost profits | (27.4 | ) |  | — |  |  | (27.4 | ) |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (11.2 | ) |  | — |  |  | (10.9 | ) |  | — |  |
| Income from equity method investments | (1.2 | ) |  | (2.9 | ) |  | (12.0 | ) |  | (18.4 | ) |
| Operating income | 116.2 |  |  | 103.7 |  |  | 509.5 |  |  | 494.5 |  |
| Interest expense, net | 9.8 |  |  | 7.3 |  |  | 38.3 |  |  | 30.6 |  |
| Other expense (income), net | 0.9 |  |  | — |  |  | 3.3 |  |  | (0.1 | ) |
| Income from continuing operations before income taxes | 105.5 |  |  | 96.4 |  |  | 467.9 |  |  | 464.0 |  |
| Provision for income taxes | 30.2 |  |  | 53.3 |  |  | 107.6 |  |  | 156.9 |  |
| Income from continuing operations | 75.3 |  |  | 43.1 |  |  | 360.3 |  |  | 307.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes | 0.4 |  |  | 0.1 |  |  | 0.8 |  |  | (2.2 | ) |
| Income tax expense (benefit) | 0.1 |  |  | 0.1 |  |  | 2.1 |  |  | (0.8 | ) |
| Income (loss) from discontinued operations | 0.3 |  |  | — |  |  | (1.3 | ) |  | (1.4 | ) |
| Net income | $ | 75.6 |  |  | $ | 43.1 |  |  | $ | 359.0 |  |  | $ | 305.7 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.88 |  |  | $ | 1.03 |  |  | $ | 8.87 |  |  | $ | 7.28 |  |
| Income (loss) from discontinued operations | 0.01 |  |  | — |  |  | (0.03 | ) |  | (0.03 | ) |
| Net income | $ | 1.89 |  |  | $ | 1.03 |  |  | $ | 8.84 |  |  | $ | 7.25 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 1.86 |  |  | $ | 1.02 |  |  | $ | 8.77 |  |  | $ | 7.17 |  |
| Income (loss) from discontinued operations | 0.01 |  |  | — |  |  | (0.03 | ) |  | (0.03 | ) |
| Net income | $ | 1.87 |  |  | $ | 1.02 |  |  | $ | 8.74 |  |  | $ | 7.14 |  |
| Weighted Average Number of Shares Outstanding - Basic | 40.0 |  |  | 41.8 |  |  | 40.6 |  |  | 42.2 |  |
| Weighted Average Number of Shares Outstanding - Diluted | 40.5 |  |  | 42.5 |  |  | 41.1 |  |  | 42.8 |  |
| Cash dividends declared per share | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 2.43 |  |  | $ | 1.96 |  |

[0001069202-19-000005:8k_2_02:77]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Adjusted Segment Net Sales and Profit (Loss) |

[0001069202-19-000005:8k_2_02:78]
| (Amounts in millions) | For the Three Months Ended December 31,(Unaudited) |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Adjusted Net Sales |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 460.7 |  |  | $ | 476.6 |  |  | $ | 2,225.0 |  |  | $ | 2,140.4 |  |
| Commercial Heating & Cooling | 270.0 |  |  | 250.3 |  |  | 1,043.5 |  |  | 973.8 |  |
| Refrigeration (1) | 112.9 |  |  | 112.9 |  |  | 544.5 |  |  | 538.2 |  |
|  | $ | 843.6 |  |  | $ | 839.8 |  |  | $ | 3,813.0 |  |  | $ | 3,652.4 |  |
| Adjusted Segment Profit (Loss) (2) |  |  |  |  |  |  |  |
| Residential Heating & Cooling | $ | 81.5 |  |  | $ | 76.2 |  |  | $ | 399.4 |  |  | $ | 373.9 |  |
| Commercial Heating & Cooling | 40.6 |  |  | 43.5 |  |  | 159.5 |  |  | 157.3 |  |
| Refrigeration (1) | 10.4 |  |  | 13.9 |  |  | 65.6 |  |  | 66.1 |  |
| Corporate and other | (22.5 | ) |  | (30.6 | ) |  | (84.4 | ) |  | (89.2 | ) |
| Total adjusted segment profit | 110.0 |  |  | 103.0 |  |  | 540.1 |  |  | 508.1 |  |
| Reconciliation to Operating Income: |  |  |  |  |  |  |  |
| Special inventory write down | — |  |  | — |  |  | 0.2 |  |  | — |  |
| Special product quality adjustment | — |  |  | (0.3 | ) |  | — |  |  | 5.4 |  |
| Loss (gain), net on sale of businesses and related property | 1.2 |  |  | 1.1 |  |  | 27.0 |  |  | 1.1 |  |
| Gain from insurance recoveries, net of losses incurred | (11.2 | ) |  | — |  |  | (10.9 | ) |  | — |  |
| Pension settlement | 0.4 |  |  | — |  |  | 0.4 |  |  | — |  |
| Items in losses (gains) and other expenses, net that are excluded from segment profit (loss) (2) | 2.2 |  |  | 0.3 |  |  | 11.4 |  |  | 10.4 |  |
| Restructuring charges | 1.1 |  |  | 1.2 |  |  | 3.0 |  |  | 3.2 |  |
| Operating loss (income) from non-core businesses | 0.1 |  |  | (3.0 | ) |  | (0.5 | ) |  | (6.5 | ) |
| Operating income | $ | 116.2 |  |  | $ | 103.7 |  |  | $ | 509.5 |  |  | $ | 494.5 |  |

[0001069202-19-000005:8k_2_02:79]
(1) Excludes the non-core business results related to our business operations in Australia, Asia, and South America for 2018 and 2017.

[0001069202-19-000005:8k_2_02:80]
(2)  We define segment profit (loss) as a segment's operating income included in the accompanying Consolidated Statements of Operations, excluding:

[0001069202-19-000005:8k_2_02:81]
| • | The following items in Losses (gains) and other expenses, net: |

[0001069202-19-000005:8k_2_02:82]
| ◦ | Net change in unrealized losses (gains) on unsettled futures contracts, |

[0001069202-19-000005:8k_2_02:83]
| ◦ | Special legal contingency charges, |

[0001069202-19-000005:8k_2_02:84]
| ◦ | Asbestos-related litigation, |

[0001069202-19-000005:8k_2_02:85]
| ◦ | Environmental liabilities, |

[0001069202-19-000005:8k_2_02:86]
| ◦ | Contractor tax payments, |

[0001069202-19-000005:8k_2_02:87]
| ◦ | Other items, net, |

[0001069202-19-000005:8k_2_02:88]
| • | Special inventory write down, |

[0001069202-19-000005:8k_2_02:89]
| • | Loss (gain), net on sale of businesses and related property, |

[0001069202-19-000005:8k_2_02:90]
| • | Gain from insurance recoveries, net of losses incurred, |

[0001069202-19-000005:8k_2_02:91]
| • | Special product quality adjustment, |

[0001069202-19-000005:8k_2_02:92]
| • | Pension settlement, |

[0001069202-19-000005:8k_2_02:93]
| • | Operating loss (income) from non-core businesses; and, |

[0001069202-19-000005:8k_2_02:94]
| • | Restructuring charges. |

[0001069202-19-000005:8k_2_02:95]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIESConsolidated Balance Sheets |
|  | As of December 31, |
| (Amounts in millions, except shares and par values) | 2018 |  | 2017 |
| ASSETS |  |  |  |
| Current Assets: |  |  |  |
| Cash and cash equivalents | $ | 46.3 |  |  | $ | 68.2 |  |
| Accounts and notes receivable, net of allowances of $6.3 and $5.9 in 2018 and 2017, respectively | 472.7 |  |  | 506.5 |  |
| Inventories, net | 509.8 |  |  | 484.2 |  |
| Other assets | 60.6 |  |  | 78.4 |  |
| Total current assets | 1,089.4 |  |  | 1,137.3 |  |
| Property, plant and equipment, net of accumulated depreciation of $778.5 and $774.2 in 2018 and 2017, respectively | 408.3 |  |  | 397.8 |  |
| Goodwill | 186.6 |  |  | 200.5 |  |
| Deferred income taxes | 67.0 |  |  | 94.4 |  |
| Other assets, net | 65.9 |  |  | 61.5 |  |
| Total assets | $ | 1,817.2 |  |  | $ | 1,891.5 |  |
| LIABILITIES AND STOCKHOLDERS’ (DEFICIT) EQUITY |  |  |  |
| Current Liabilities: |  |  |  |
| Short-term debt | $ | — |  |  | $ | 0.9 |  |
| Current maturities of long-term debt | 300.8 |  |  | 32.6 |  |
| Accounts payable | 433.3 |  |  | 348.6 |  |
| Accrued expenses | 272.3 |  |  | 270.3 |  |
| Income taxes payable | 2.1 |  |  | 2.1 |  |
| Total current liabilities | 1,008.5 |  |  | 654.5 |  |
| Long-term debt | 740.5 |  |  | 970.5 |  |
| Pensions | 82.8 |  |  | 84.5 |  |
| Other liabilities | 135.0 |  |  | 131.9 |  |
| Total liabilities | 1,966.8 |  |  | 1,841.4 |  |
| Commitments and contingencies |  |  |  |
| Stockholders' (deficit) equity: |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding | — |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued | 0.9 |  |  | 0.9 |  |
| Additional paid-in capital | 1,078.8 |  |  | 1,061.5 |  |
| Retained earnings | 1,855.0 |  |  | 1,575.9 |  |
| Accumulated other comprehensive loss | (188.8 | ) |  | (157.4 | ) |
| Treasury stock, at cost, shares 47,312,248 and 45,361,145 shares for 2018 and 2017, respectively | (2,895.5 | ) |  | (2,430.8 | ) |
| Total stockholders' (deficit) equity | (149.6 | ) |  | 50.1 |  |
| Total liabilities and stockholders' (deficit) equity | $ | 1,817.2 |  |  | $ | 1,891.5 |  |

[0001069202-19-000005:8k_2_02:96]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001069202-19-000005:8k_2_02:97]
Consolidated Statements of Cash Flows

[0001069202-19-000005:8k_2_02:98]
| (Amounts in millions) | For the Years Ended December 31, |
|  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 359.0 |  |  | $ | 305.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Gain on sale of real estate | (23.8 | ) |  | — |  |
| Impairment/loss on the sale of Australia business | 13.3 |  |  | — |  |
| Impairment/loss on the sale of South America business | 37.5 |  |  | — |  |
| Gain from insurance recoveries, net of losses incurred | (10.9 | ) |  | — |  |
| Income from equity method investments | (12.0 | ) |  | (18.4 | ) |
| Dividend from Affiliates | 9.6 |  |  | 14.7 |  |
| Restructuring charges, net of cash paid | 1.3 |  |  | 0.8 |  |
| Provision for bad debts | 4.7 |  |  | 3.9 |  |
| Unrealized losses (gains) on derivative contracts | 1.3 |  |  | (2.0 | ) |
| Stock-based compensation expense | 26.3 |  |  | 24.9 |  |
| Depreciation and amortization | 66.0 |  |  | 64.6 |  |
| Deferred income taxes | 25.2 |  |  | 43.3 |  |
| Pension expense | 8.8 |  |  | 5.3 |  |
| Pension contributions | (20.6 | ) |  | (3.5 | ) |
| Other items, net | 5.1 |  |  | 1.3 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |
| Accounts and notes receivable | (9.9 | ) |  | (28.4 | ) |
| Inventories | (84.2 | ) |  | (56.4 | ) |
| Other current assets | (0.2 | ) |  | (6.1 | ) |
| Accounts payable | 102.2 |  |  | (18.5 | ) |
| Accrued expenses | 5.9 |  |  | 0.3 |  |
| Income taxes payable and receivable | (5.5 | ) |  | (6.7 | ) |
| Other | (3.6 | ) |  | 0.3 |  |
| Net cash provided by operating activities | 495.5 |  |  | 325.1 |  |
| Cash flows from investing activities: |  |  |  |
| Proceeds from the disposal of property, plant and equipment | 0.1 |  |  | 0.2 |  |
| Purchases of property, plant and equipment | (95.2 | ) |  | (98.3 | ) |
| Net proceeds from sale of businesses and related property | 114.7 |  |  | — |  |
| Insurance recoveries received for property damage incurred from natural disaster | 10.9 |  |  | — |  |
| Net cash provided by (used in) investing activities | 30.5 |  |  | (98.1 | ) |
| Cash flows from financing activities: |  |  |  |
| Short-term borrowings, net | — |  |  | (1.5 | ) |
| Asset securitization borrowings | 155.0 |  |  | 315.0 |  |
| Asset securitization payments | (163.0 | ) |  | (89.0 | ) |
| Long-term debt payments | (33.0 | ) |  | (200.9 | ) |
| Borrowings from credit facility | 2,435.9 |  |  | 2,376.5 |  |
| Payments on credit facility | (2,365.0 | ) |  | (2,265.5 | ) |
| Payments of deferred financing costs | — |  |  | (0.2 | ) |
| Proceeds from employee stock purchases | 3.3 |  |  | 3.1 |  |
| Repurchases of common stock | (450.2 | ) |  | (250.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations | (26.9 | ) |  | (26.1 | ) |
| Cash dividends paid | (93.9 | ) |  | (79.7 | ) |
| Net cash used in financing activities | (537.8 | ) |  | (218.3 | ) |
| (Decrease) increase in cash and cash equivalents | (11.8 | ) |  | 8.7 |  |
| Effect of exchange rates on cash and cash equivalents | (10.1 | ) |  | 9.3 |  |
| Cash and cash equivalents, beginning of period | 68.2 |  |  | 50.2 |  |
| Cash and cash equivalents, end of period | $ | 46.3 |  |  | $ | 68.2 |  |

[0001069202-19-000005:8k_2_02:99]
| Supplemental disclosures of cash flow information: |  |  |  |
| Interest paid | $ | 38.7 |  |  | $ | 32.4 |  |
| Income taxes paid (net of refunds) | $ | 90.0 |  |  | $ | 119.3 |  |
| Insurance recoveries received | $ | 124.3 |  |  | $ | — |  |

[0001069202-19-000005:8k_2_02:100]
| LENNOX INTERNATIONAL INC. AND SUBSIDIARIES |
| Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures |
| (Unaudited, in millions, except per share and ratio data) |
| Use of Non-GAAP Financial Measures |  |  |  |  |  |  |  |
| To supplement the Company's consolidated financial statements and segment net sales and profit presented in accordance with U.S. GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis if different than the reported measures. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company's business trends and operating performance. In the first quarter of 2018, the Company announced the planned sales of its businesses in Australia, Asia, and South America. The results from operations for these businesses have been shown in the tables below as “Non-core business results”. The sale of our business in Australia and Asia and the related property was completed in the second quarter of 2018 and sale of our business in South America was completed in the third quarter of 2018. The prior period results have been updated to provide period-over-period comparability. |
| Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure |
|  | For the Three Months Ended December 31,(Unaudited) |
|  | 2018 |  | 2017 |
|  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |  | Pre-Tax |  | Tax Impact (e) |  | After Tax |  |
| Income from continuing operations, a GAAP measure | $ | 105.5 |  | $ | (30.2 | ) | $ | 75.3 |  |  | $ | 96.4 |  | $ | (53.3 | ) | $ | 43.1 |  |
| Restructuring charges | 1.1 |  | (0.2 | ) | 0.9 |  |  | 1.2 |  | (0.5 | ) | 0.7 |  |
| Pension settlement | 0.4 |  | — |  | 0.4 |  |  | — |  | — |  | — |  |
| Special product quality adjustments (b) | — |  | — |  | — |  |  | (0.3 | ) | 0.1 |  | (0.2 | ) |
| Special legal contingency charges (a) | 0.1 |  | — |  | 0.1 |  |  | — |  | — |  | — |  |
| Asbestos-related litigation (a) | 0.7 |  | (0.3 | ) | 0.4 |  |  | (0.3 | ) | 0.1 |  | (0.2 | ) |
| Net change in unrealized losses (gains) on unsettled future contracts (a) | 0.1 |  | — |  | 0.1 |  |  | (0.1 | ) | 0.1 |  | — |  |
| Environmental liabilities (a) | 0.8 |  | (0.1 | ) | 0.7 |  |  | 0.9 |  | (0.2 | ) | 0.7 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (3.9 | ) | (3.9 | ) |  | — |  | (14.0 | ) | (14.0 | ) |
| Other tax items, net (c) | — |  | 10.5 |  | 10.5 |  |  | — |  | 40.2 |  | 40.2 |  |
| Contractor tax payments (a) | — |  | — |  | — |  |  | 0.1 |  | — |  | 0.1 |  |
| Loss (gain), net on sale of businesses and related property | 1.2 |  | (1.3 | ) | (0.1 | ) |  | 1.1 |  | (0.4 | ) | 0.7 |  |
| Gain from insurance recoveries, net of losses incurred | (11.2 | ) | 2.8 |  | (8.4 | ) |  | — |  | — |  | — |  |
| Other items, net (a) | 0.5 |  | 1.3 |  | 1.8 |  |  | (0.3 | ) | 0.2 |  | (0.1 | ) |
| Non-core business results (f) | 0.1 |  | — |  | 0.1 |  |  | (3.0 | ) | 1.0 |  | (2.0 | ) |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 99.3 |  | $ | (21.4 | ) | $ | 77.9 |  |  | $ | 95.7 |  | $ | (26.7 | ) | $ | 69.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 1.86 |  |  |  |  |  |  | $ | 1.02 |  |
| Restructuring charges |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.02 |  |
| Pension settlement |  |  | 0.01 |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Special legal contingency charges (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.01 |  |  |  |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |
| Environmental liabilities (a) |  |  |  |  | 0.02 |  |  |  |  |  |  | 0.02 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.09 | ) |  |  |  |  |  | (0.33 | ) |
| Other tax items, net (c) |  |  |  |  | 0.26 |  |  |  |  |  |  | 0.95 |  |
| Contractor tax payments (a) |  |  |  |  | — |  |  |  |  |  |  | — |  |

[0001069202-19-000005:8k_2_02:101]
| Loss (gain), net on sale of businesses and related property |  |  |  |  | — |  |  |  |  |  |  | 0.02 |  |
| Gain from insurance recoveries, net of losses incurred |  |  |  |  | (0.21 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.04 |  |  |  |  |  |  | (0.01 | ) |
| Non-core business results (f) |  |  |  |  | — |  |  |  |  |  |  | (0.05 | ) |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.01 |  |  |  |  |  |  | (0.01 | ) |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  | $ | 1.93 |  |  |  |  | $ | 1.63 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
|  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |
|  | Pre-Tax |  | Tax Impact (e) | After Tax |  |  | Pre-Tax |  | Tax Impact (e) | After Tax |  |
| Income from continuing operations, a GAAP measure | $ | 467.9 |  | $ | (107.6 | ) | $ | 360.3 |  |  | $ | 464.0 |  | $ | (156.9 | ) | $ | 307.1 |  |
| Restructuring charges | 3.0 |  | (0.7 | ) | 2.3 |  |  | 3.2 |  | (1.1 | ) | 2.1 |  |
| Pension settlement | 0.4 |  | — |  | 0.4 |  |  | — |  | — |  | — |  |
| Special product quality adjustments (b) | — |  | — |  | — |  |  | 5.4 |  | (1.9 | ) | 3.5 |  |
| Special legal contingency charges (a) | 1.9 |  | (0.4 | ) | 1.5 |  |  | 3.7 |  | (0.4 | ) | 3.3 |  |
| Asbestos-related litigation (a) | 4.0 |  | (1.1 | ) | 2.9 |  |  | 3.5 |  | (1.2 | ) | 2.3 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (b) | 1.5 |  | (0.3 | ) | 1.2 |  |  | 0.9 |  | (0.3 | ) | 0.6 |  |
| Inventory write down (b) | 0.2 |  | — |  | 0.2 |  |  | — |  | — |  | — |  |
| Environmental liabilities (a) | 2.2 |  | (0.4 | ) | 1.8 |  |  | 2.2 |  | (0.6 | ) | 1.6 |  |
| Excess tax benefits from share-based compensation (c) | — |  | (10.5 | ) | (10.5 | ) |  | — |  | (23.6 | ) | (23.6 | ) |
| Other tax items, net (c) | — |  | 5.8 |  | 5.8 |  |  | — |  | 40.2 |  | 40.2 |  |
| Contractor tax payments (a) | — |  | — |  | — |  |  | 0.1 |  | — |  | 0.1 |  |
| Loss (gain), net on sale of businesses and related property | 27.0 |  | (1.0 | ) | 26.0 |  |  | 1.1 |  | (0.4 | ) | 0.7 |  |
| Gain from insurance recoveries, net of losses incurred | (10.9 | ) | 2.7 |  | (8.2 | ) |  | — |  | — |  | — |  |
| Other items, net (a) | 1.8 |  | 0.7 |  | 2.5 |  |  | — |  | — |  | — |  |
| Non-core business results (f) | (0.5 | ) | 0.2 |  | (0.3 | ) |  | (5.5 | ) | 1.7 |  | (3.9 | ) |
| Adjusted income from continuing operations, a non-GAAP measure | $ | 498.5 |  | $ | (112.6 | ) | $ | 385.9 |  |  | $ | 478.6 |  | $ | (144.5 | ) | $ | 334.0 |  |
| Earnings per share from continuing operations - diluted, a GAAP measure |  |  |  |  | $ | 8.77 |  |  |  |  |  |  | $ | 7.17 |  |
| Restructuring charges |  |  |  |  | 0.06 |  |  |  |  |  |  | 0.05 |  |
| Pension settlement |  |  | 0.01 |  |  |  |  | — |  |
| Special product quality adjustments (b) |  |  |  |  | — |  |  |  |  |  |  | 0.08 |  |
| Special legal contingency charges (a) |  |  |  |  | 0.04 |  |  |  |  |  |  | 0.08 |  |
| Asbestos-related litigation (a) |  |  |  |  | 0.07 |  |  |  |  |  |  | 0.05 |  |
| Net change in unrealized losses (gains) on unsettled future contracts (b) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.01 |  |
| Inventory write down (b) |  |  |  |  | — |  |  |  |  |  |  | — |  |

[0001069202-19-000005:8k_2_02:102]
| Environmental liabilities (a) |  |  |  |  | 0.05 |  |  |  |  |  |  | 0.04 |  |
| Excess tax benefits from share-based compensation (c) |  |  |  |  | (0.26 | ) |  |  |  |  |  | (0.55 | ) |
| Other tax items, net (c) |  |  |  |  | 0.14 |  |  |  |  |  |  | 0.94 |  |
| Loss (gain), net on sale of businesses and related property |  |  |  |  | 0.63 |  |  |  |  |  |  | 0.02 |  |
| Gain from insurance recoveries, net of losses incurred |  |  |  |  | (0.20 | ) |  |  |  |  |  | — |  |
| Other items, net (a) |  |  |  |  | 0.06 |  |  |  |  |  |  | — |  |
| Non-core business results (f) |  |  |  |  | (0.01 | ) |  |  |  |  |  | (0.09 | ) |
| Change in share counts from share-based compensation (d) |  |  |  |  | 0.03 |  |  |  |  |  |  | 0.03 |  |
| Adjusted earnings per share from continuing operations - diluted, a non-GAAP measure |  |  |  |  | $ | 9.42 |  |  |  |  |  |  | $ | 7.83 |  |
| (a) Recorded in Losses and other expenses, net in the Consolidated Statements of Operations |  |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |  |
| (c) Recorded in Provision for income taxes in the Consolidated Statements of Operations |  |
| (d) The impact of excess tax benefits from the change in share-based compensation also impacts our diluted share counts. The reconciliation of average outstanding diluted shares on a GAAP and non-GAAP basis is included in this document. |
| (e) Tax impact based on the applicable tax rate relevant to the location and nature of the adjustment. |
| (f) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |

[0001069202-19-000005:8k_2_02:103]
|  | For the Three Months Ended December 31,(Unaudited) |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Components of (Gains) Losses and other expenses, net (pre-tax): |  |  |  |  |  |  |  |
| Realized losses (gains) on settled future contracts (a) | $ | 0.1 |  |  | $ | (0.5 | ) |  | $ | (0.4 | ) |  | $ | (1.7 | ) |
| Foreign currency exchange losses (gains) (a) | 0.5 |  |  | (1.4 | ) |  | 1.7 |  |  | (1.8 | ) |
| Loss on disposal of fixed assets (a) | 0.5 |  |  | 0.1 |  |  | 0.7 |  |  | 0.2 |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) | 0.1 |  |  | (0.1 | ) |  | 1.5 |  |  | 0.9 |  |
| Special legal contingency charges (b) | 0.1 |  |  | — |  |  | 1.9 |  |  | 3.7 |  |
| Asbestos-related litigation (b) | 0.7 |  |  | (0.3 | ) |  | 4.0 |  |  | 3.5 |  |
| Environmental liabilities (b) | 0.8 |  |  | 0.9 |  |  | 2.2 |  |  | 2.2 |  |
| Contractor tax payments (b) | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Other items, net (b) | 0.5 |  |  | (0.3 | ) |  | 1.8 |  |  | — |  |
| Losses and other expenses, net (pre-tax) | $ | 3.3 |  |  | $ | (1.5 | ) |  | $ | 13.4 |  |  | $ | 7.1 |  |

[0001069202-19-000005:8k_2_02:104]
| (a) Included in both segment profit (loss) and Adjusted income from continuing operations |
| (b) Excluded from both segment profit (loss) and Adjusted income from continuing operations |

[0001069202-19-000005:8k_2_02:105]
| Reconciliation of Earnings per Share from Continuing Operations - Diluted, a GAAP measure, to Estimated Adjusted Earnings per Share from Continuing Operations - Diluted, a Non-GAAP measure |
|  |  |  |  |  | For the Year Ended December 31, 2019ESTIMATED |
| Earnings per share from continuing operations - diluted, a GAAP measure |  | $14.30 - 14.90 |  |
| Insurance recovery, net of other non-core EBIT charges, from tornado impact to damaged property |  | (2.30) |  |
| Adjusted Earnings per share from continuing operations - diluted, a Non-GAAP measure |  | $12.00 - $12.60 |  |
| Reconciliation of Average Shares Outstanding - Diluted, a GAAP measure, to Adjusted Average Shares Outstanding - Diluted, a Non-GAAP measure (shares in millions): |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Average shares outstanding - diluted, a GAAP measure | 40.5 |  |  | 42.5 |  |  | 41.1 |  |  | 42.8 |  |
| Impact on diluted shares from excess tax benefits from share-based compensation | (0.2 | ) |  | (0.2 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Adjusted average shares outstanding - diluted, a Non-GAAP measure | 40.3 |  |  | 42.3 |  |  | 41.0 |  |  | 42.6 |  |
| Reconciliation of Net Sales, a GAAP measure, to Adjusted Net Sales, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales, a GAAP measure | $ | 112.9 |  |  | $ | 164.9 |  |  | $ | 843.6 |  |  | $ | 891.8 |  |
| Net sales from non-core businesses (a) | — |  |  | 52.0 |  |  | — |  |  | 52.0 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 112.9 |  |  | $ | 112.9 |  |  | $ | 843.6 |  |  | $ | 839.8 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales, a GAAP measure | $ | 615.4 |  |  | $ | 725.4 |  |  | $ | 3,883.9 |  |  | $ | 3,839.6 |  |
| Net sales from non-core businesses (a) | 70.9 |  |  | 187.2 |  |  | 70.9 |  |  | 187.2 |  |
| Adjusted net sales, a Non-GAAP measure | $ | 544.5 |  |  | $ | 538.2 |  |  | $ | 3,813.0 |  |  | $ | 3,652.4 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Gross Profit, a GAAP measure, to Adjusted Gross Profit, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit, a GAAP measure | $ | 34.1 |  |  | $ | 50.9 |  |  | $ | 224.5 |  |  | $ | 259.8 |  |
| Non-GAAP adjustments to gross profit | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Gross profit from non-core businesses (a) | — |  |  | 15.4 |  |  | — |  |  | 15.4 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 34.1 |  |  | $ | 35.5 |  |  | $ | 224.5 |  |  | $ | 244.1 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |

[0001069202-19-000005:8k_2_02:106]
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit, a GAAP measure | $ | 181.3 |  |  | $ | 216.6 |  |  | $ | 1,111.2 |  |  | $ | 1,125.2 |  |
| Non-GAAP adjustments to gross profit | (0.2 | ) |  | — |  |  | (0.2 | ) |  | (5.4 | ) |
| Gross profit from non-core businesses (a) | 19.0 |  |  | 55.5 |  |  | 19.0 |  |  | 55.5 |  |
| Adjusted Gross profit, a Non-GAAP measure | $ | 162.5 |  |  | $ | 161.1 |  |  | $ | 1,092.4 |  |  | $ | 1,075.1 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Segment Profit, a GAAP measure, to Adjusted Segment profit, a Non-GAAP measure |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Three Months Ended December 31, |  | For the Three Months Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit, a GAAP measure | $ | 10.3 |  |  | $ | 16.9 |  |  | $ | 109.9 |  |  | $ | 106.0 |  |
| Gross (loss) profit from non-core businesses (a) | (0.1 | ) |  | 3.0 |  |  | (0.1 | ) |  | 3.0 |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 10.4 |  |  | $ | 13.9 |  |  | $ | 110.0 |  |  | $ | 103.0 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
|  | Refrigeration Segment |  | Consolidated |
|  | For the Years Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit, a GAAP measure | $ | 66.1 |  |  | $ | 72.6 |  |  | $ | 540.6 |  |  | $ | 514.6 |  |
| Gross profit from non-core businesses (a) | 0.5 |  |  | 6.5 |  |  | 0.5 |  |  | 6.5 |  |
| Adjusted Segment profit, a Non-GAAP measure | $ | 65.6 |  |  | $ | 66.1 |  |  | $ | 540.1 |  |  | $ | 508.1 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Selling, general and administrative expenses, a GAAP measure, to Adjusted Selling, general and administrative expenses, a Non-GAAP measure |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Selling, general and administrative expenses, a GAAP measure | $ | 142.1 |  |  | $ | 158.2 |  |  | $ | 608.2 |  |  | $ | 637.7 |  |
| Selling, general and administrative expenses from non-core businesses (a) | 0.1 |  |  | 12.4 |  |  | 18.8 |  |  | 49.0 |  |
| Adjusted Selling, general and administrative expenses, a Non-GAAP measure | $ | 142.0 |  |  | $ | 145.8 |  |  | $ | 589.4 |  |  | $ | 588.7 |  |
| (a) Non-Core business represent our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |  |
| Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP measure (dollars in millions) |
|  | For the Three Months Ended December 31, |  | For the Years Ended December 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net cash provided by operating activities, a GAAP measure | $ | 264.2 |  |  | $ | 196.1 |  |  | $ | 495.5 |  |  | $ | 325.1 |  |
| Purchases of property, plant and equipment | (34.3 | ) |  | (37.8 | ) |  | (95.2 | ) |  | (98.3 | ) |
| Proceeds from the disposal of property, plant and equipment | — |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Insurance recoveries received for property damage incurred from natural disaster | 6.7 |  |  | — |  |  | 10.9 |  |  | — |  |
| Free cash flow, a Non-GAAP measure | 236.6 |  |  | 158.3 |  |  | 411.3 |  |  | 227.0 |  |

[0001069202-19-000005:8k_2_02:107]
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2018 |
| Adjusted EBIT(a) (a) |  |  |  |  |  |  | $ | 540.1 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  | 65.0 |  |
| EBITDA (a + b) |  |  |  |  |  |  | $ | 605.1 |  |
| Total debt at December 31, 2018 (c) |  |  |  |  |  |  | $ | 1,041.3 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  | 1.7 |  |
| (a) Adjusted EBIT excludes the non-core business results related to our business operations in Australia, Asia, and South America. |  |  |  |  |  |  |
| Reconciliation of Adjusted EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure (dollars in millions) |
|  |  |  |  |  |  |  | Trailing Twelve Months to December 31, 2018 |
| Income from continuing operations before income taxes, a GAAP measure | $ | 467.9 |  |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit | 11.4 |  |
| Inventory write down | 0.2 |  |
| Restructuring charges | 3.0 |  |
| Interest expense, net | 38.3 |  |
| Pension settlement | 0.4 |  |
| Loss (gain), net on sale of businesses and related property | 27.0 |  |
| Gain from insurance recoveries, net of losses incurred | (10.9 | ) |
| Non-core business results (a) | (0.5 | ) |
| Other expense (income), net | 3.3 |  |
| Adjusted EBIT per above, a Non-GAAP measure | $ | 540.1 |  |
| (a) Non-core business results represent activity related to our business operations in Australia, Asia, and South America, not included elsewhere in the reconciliation. |
