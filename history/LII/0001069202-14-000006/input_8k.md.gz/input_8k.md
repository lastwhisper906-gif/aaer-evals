# LII 8-K — 0001193125-14-273500 filed 2014-07-21

## item codes, every 8-K on or before 2014-07-21

- 2014-07-21 0001193125-14-273500 — 2.02, 9.01
- 2014-05-16 0001193125-14-203045 — 5.07
- 2014-04-21 0001193125-14-149734 — 2.02, 9.01
- 2014-02-05 0001193125-14-035982 — 2.02, 9.01
- 2013-12-16 0001193125-13-474576 — 5.03, 9.01
- 2013-11-19 0001193125-13-446894 — 1.01, 2.03, 9.01
- 2013-10-21 0001193125-13-404683 — 2.02, 9.01
- 2013-07-22 0001193125-13-296557 — 2.02, 9.01
- 2013-05-21 0001193125-13-228127 — 5.07
- 2013-04-22 0001193125-13-163938 — 2.02, 9.01
- 2013-03-25 0001193125-13-124282 — 1.01, 2.03, 9.01
- 2013-03-25 0001193125-13-122494 — 8.01, 9.01
- 2013-02-05 0001193125-13-037706 — 2.02, 9.01
- 2012-12-12 0001193125-12-499333 — 7.01, 9.01
- 2012-11-20 0001193125-12-477421 — 1.01, 2.03, 9.01
- 2012-10-22 0001193125-12-429395 — 2.02, 7.01, 9.01
- 2012-10-01 0001193125-12-410282 — 5.02, 9.01
- 2012-09-21 0001193125-12-399477 — 5.03, 8.01, 9.01
- 2012-07-24 0001193125-12-311373 — 2.02, 9.01
- 2012-07-17 0001193125-12-304640 — 5.02, 9.01
- 2012-05-11 0001193125-12-228395 — 5.02, 5.07
- 2012-05-07 0001188112-12-001407 — 7.01, 9.01
- 2012-04-25 0001188112-12-001195 — 7.01, 9.01
- 2012-04-24 0001193125-12-177442 — 2.02, 9.01
- 2012-03-02 0001188112-12-000570 — 5.02
- 2012-02-02 0001188112-12-000235 — 2.02, 9.01
- 2011-12-14 0001188112-11-003476 — 7.01, 9.01
- 2011-11-25 0001193125-11-322132 — 1.01, 2.03, 9.01
- 2011-10-25 0000950123-11-091662 — 1.01, 2.02, 2.03, 9.01
- 2011-07-26 0000950123-11-068114 — 2.02, 9.01
- 2011-07-25 0000950123-11-067764 — 5.02, 9.01
- 2011-05-16 0000950123-11-050918 — 5.02, 5.07
- 2011-04-27 0000950123-11-039940 — 8.01
- 2011-04-26 0000950123-11-039024 — 2.02, 9.01
- 2011-02-03 0000950123-11-008535 — 2.02, 9.01
- 2010-12-15 0000950134-10-000020 — 7.01, 9.01
- 2010-12-13 0000950123-10-113197 — 5.02, 9.01
- 2010-11-19 0000950123-10-107488 — 1.01, 9.01
- 2010-10-26 0000950123-10-095907 — 2.02, 9.01
- 2010-07-27 0000950123-10-068344 — 2.02, 9.01
- 2010-05-26 0000950123-10-053176 — 5.02, 9.01
- 2010-05-19 0000950123-10-051306 — 5.02, 5.07, 9.01
- 2010-05-06 0000950123-10-045073 — 1.01, 2.03, 9.01
- 2010-05-03 0000950123-10-042408 — 7.01, 8.01, 9.01
- 2010-04-27 0000950123-10-038544 — 2.02, 9.01
- 2010-04-21 0000950123-10-036710 — 5.02
- 2010-03-15 0000950123-10-024750 — 5.03, 9.01
- 2010-02-24 0000950123-10-016421 — 5.02
- 2010-02-23 0000950123-10-015751 — 1.01, 9.01
- 2010-02-04 0000950123-10-008560 — 2.02, 9.01
- 2009-12-16 0000950123-09-071289 — 5.02, 9.01
- 2009-12-16 0000950123-09-071102 — 7.01
- 2009-12-02 0000950123-09-067518 — 1.01, 9.01
- 2009-10-21 0000950123-09-051777 — 2.02, 9.01
- 2009-09-03 0000950123-09-040897 — 5.02, 9.01
- 2009-07-22 0000950123-09-024157 — 2.02, 9.01
- 2009-05-18 0001362310-09-007724 — 5.02, 9.01
- 2009-04-22 0001362310-09-005635 — 2.02, 9.01
- 2009-02-05 0001362310-09-001156 — 2.02, 2.05, 9.01
- 2009-01-16 0001362310-09-000451 — 7.01
- 2008-12-17 0001362310-08-008302 — 7.01
- 2008-12-17 0001362310-08-008300 — 5.02, 9.01
- 2008-12-02 0001362310-08-007833 — 1.01, 9.01
- 2008-10-22 0001362310-08-006017 — 2.02, 9.01
- 2008-09-25 0000950134-08-017174 — 1.01, 9.01
- 2008-09-03 0001362310-08-004961 — 5.02
- 2008-07-23 0001362310-08-003760 — 2.02, 5.03, 9.01
- 2008-06-03 0001362310-08-003106 — 8.01, 9.01
- 2008-04-23 0001362310-08-002085 — 2.02, 9.01
- 2008-02-12 0001362310-08-000633 — 8.01
- 2008-02-06 0001362310-08-000477 — 2.02, 9.01
- 2007-12-18 0001362310-07-003425 — 1.01, 9.01
- 2007-12-12 0001362310-07-003353 — 7.01
- 2007-12-12 0001362310-07-003352 — 5.02, 9.01
- 2007-10-24 0000950134-07-021827 — 2.02, 9.01
- 2007-10-15 0000950134-07-021296 — 1.01, 1.02, 2.03, 9.01
- 2007-10-10 0000950134-07-021100 — 2.05, 9.01
- 2007-09-10 0000950134-07-019776 — 2.05, 9.01
- 2007-08-03 0000950134-07-016800 — 1.01, 8.01, 9.01
- 2007-07-26 0000950134-07-015850 — 5.03, 8.01, 9.01
- 2007-07-25 0000950134-07-015811 — 2.02, 9.01
- 2007-05-15 0000950134-07-011621 — 5.02
- 2007-04-24 0000950134-07-008862 — 2.02, 9.01
- 2007-03-21 0000950134-07-006304 — 3.02, 9.01
- 2007-03-19 0000950134-07-006138 — 5.02, 9.01
- 2007-02-08 0000950134-07-002390 — 2.02, 9.01
- 2006-12-20 0000950134-06-023460 — 1.01, 9.01
- 2006-12-14 0000950134-06-023144 — 5.02, 9.01
- 2006-10-26 0000950134-06-019739 — 1.01, 9.01
- 2006-10-26 0000950134-06-019709 — 8.01
- 2006-10-26 0000950134-06-019708 — 2.02, 9.01
- 2006-10-24 0000950134-06-019484 — 1.01, 8.01, 9.01
- 2006-10-18 0000950134-06-019252 — 1.01, 9.01
- 2006-10-13 0000950134-06-019051 — 8.01, 9.01
- 2006-09-25 0000950134-06-018210 — 8.01, 9.01
- 2006-08-23 0000950134-06-016672 — 1.01, 9.01
- 2006-08-15 0000950134-06-016184 — 8.01, 9.01
- 2006-07-27 0000950134-06-014007 — 2.02, 9.01
- 2006-07-13 0000950134-06-013145 — 5.02, 9.01
- 2006-06-28 0000950134-06-012302 — 1.01, 2.03, 9.01
- 2006-05-16 0000950134-06-010079 — 8.01
- 2006-04-26 0000950134-06-007946 — 2.02, 9.01
- 2006-02-21 0000950134-06-003425 — 2.02, 4.02, 9.01
- 2006-02-13 0000950134-06-002645 — 2.05, 9.01
- 2006-02-09 0000950134-06-002326 — 2.02, 9.01
- 2006-01-30 0000950134-06-001441 — 5.02, 9.01
- 2005-12-20 0000950134-05-023494 — 1.01, 9.01
- 2005-12-13 0000950134-05-023029 — 1.01, 9.01
- 2005-10-26 0000950134-05-019726 — 2.02, 9.01
- 2005-10-11 0000950134-05-019017 — 3.02, 9.01
- 2005-10-06 0000950134-05-018861 — 8.01
- 2005-09-20 0000950134-05-017960 — 8.01, 9.01
- 2005-09-07 0000950134-05-017306 — 2.04, 9.01
- 2005-08-31 0000950134-05-016985 — 1.01, 9.01
- 2005-07-28 0000950134-05-014237 — 7.01, 9.01
- 2005-07-27 0000950134-05-014104 — 2.02, 9.01
- 2005-07-12 0000950134-05-013248 — 1.01, 1.02, 2.03, 9.01
- 2005-06-08 0000950134-05-011564 — 8.01, 9.01
- 2005-06-03 0000950134-05-011303 — 8.01, 9.01
- 2005-04-28 0000950134-05-008336 — 2.02, 9.01
- 2005-04-25 0000950134-05-008032 — 8.01
- 2005-04-07 0000950134-05-007050 — 8.01, 9.01
- 2005-04-06 0000950134-05-006957 — 2.05
- 2005-02-28 0000950134-05-003897 — 5.03, 9.01
- 2005-02-10 0000950134-05-002499 — 2.02, 9.01
- 2005-02-01 0000950134-05-001758 — 8.01, 9.01
- 2004-12-21 0000950134-04-019686 — 1.01, 9.01
- 2004-12-14 0000950134-04-019217 — 5.02
- 2004-12-09 0000950134-04-018888 — 8.01
- 2004-11-09 0000950134-04-016947 — 2.02, 9.01
- 2004-11-04 0000950134-04-016350 — 8.01
- 2004-10-06 0000950134-04-014644 — 2.02, 4.02, 9.01
- 2004-08-19 0000950134-04-012550 — 12, 7
- 2004-08-11 0000950134-04-011999 — 12, 7
- 2004-07-16 0000950134-04-010136 — 5, 7
- 2004-07-09 0000950134-04-009871 — 12, 7
- 2004-05-11 0000950134-04-007214 — 12, 7
- 2004-03-30 0000950134-04-004387 — 12, 7
- 2004-03-11 0000950134-04-003294 — 12, 7
- 2004-02-05 0000950134-04-001135 — 12, 7
- 2003-10-22 0000950134-03-013764 — 12, 7
- 2003-07-23 0000950134-03-010398 — 9
- 2003-04-23 0000950134-03-006268 — 9
- 2003-02-07 0000950134-03-001809 — 9
- 2002-10-24 0000950134-02-012915 — 7, 9
- 2002-09-03 0001116320-02-000278 — 5
- 2002-08-14 0001116320-02-000272 — 5
- 2002-05-22 0001116320-02-000146 — 4
- 2002-05-07 0001116320-02-000090 — 5
- 2002-05-01 0001116320-02-000087 — 5
- 2000-07-28 0000950134-00-006023 — 5, 7
- 2000-03-01 0000950134-00-001546 — 5, 7
- 2000-02-16 0000950134-00-001283 — 2, 7 — amendment of 0000950134-00-000714
- 2000-02-04 0000950134-00-000714 — 2, 7
- 1999-11-03 0000950134-99-009418 — 5, 7
- 1999-10-29 0000950134-99-009296 — 5, 7

## late-filing notifications on or before 2014-07-21

- 2004-11-09 0000950134-04-016946 — NT 10-Q, for the period ended 2004-09-30
- 2004-08-09 0000950134-04-011774 — NT 10-Q, for the period ended 2004-06-30
- 2004-05-11 0000950134-04-007215 — NT 10-Q, for the period ended 2004-03-31
- 2004-03-15 0000950134-04-003488 — NT 10-K, for the period ended 2003-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-273500:8k_2_02:1]
EX-99.1
2
d758702dex991.htm
EX-99.1

[0001193125-14-273500:8k_2_02:2]
EX-99.1

[0001193125-14-273500:8k_2_02:3]
Exhibit 99.1

[0001193125-14-273500:8k_2_02:4]
Lennox International Reports Record Profit in Second Quarter

[0001193125-14-273500:8k_2_02:5]
| • |  | Revenue up 6% at constant currency, led by 11% Residential growth |

[0001193125-14-273500:8k_2_02:6]
| • |  | Adjusted EPS from continuing operations up 15% to $1.51 |

[0001193125-14-273500:8k_2_02:7]
| • |  | GAAP EPS from continuing operations up 19% to $1.50 |

[0001193125-14-273500:8k_2_02:8]
| • |  | Raising 2014 revenue growth guidance from 2-6% to 5-7% |

[0001193125-14-273500:8k_2_02:9]
| • |  | Narrowing 2014 adjusted EPS from continuing operations guidance from $4.20-$4.60 to $4.30-$4.50 |

[0001193125-14-273500:8k_2_02:10]
| • |  | Reiterating plans for $150 million of stock repurchases in 2014 |

[0001193125-14-273500:8k_2_02:11]
DALLAS, July 21, 2014
– Lennox International Inc. (NYSE: LII) today reported financial results for the second quarter of 2014. Financial results in prior periods have been revised to reflect sold businesses in discontinued operations.

[0001193125-14-273500:8k_2_02:12]
Revenue for the second quarter was $961 million, up 5% from the prior-year quarter. At constant currency, revenue was up 6%. Adjusted earnings per share from
continuing operations was a record $1.51, up 15% from $1.31 in the prior-year quarter. On a GAAP basis, earnings per share from continuing operations was a record $1.50, up 19% from $1.26 in the prior-year quarter.

[0001193125-14-273500:8k_2_02:13]
“The company’s record 12.3% total segment margin was driven by strong growth and margin expansion in both our Residential and Commercial businesses
in the second quarter,” said Chairman and CEO Todd Bluedorn. “Residential revenue was up 11% and segment margin expanded 220 basis points to a record 16.1%. Residential profit rose 28% to a record $85 million. Our Commercial business set
second-quarter records for revenue, margin and profit. Led by high single-digit growth in North America, Commercial segment revenue grew 5% and margin expanded 110 basis points to 16.2%. Commercial profit rose 13%.

[0001193125-14-273500:8k_2_02:14]
“The upside that we are realizing in Residential and Commercial, however, is being dampened by soft conditions in Refrigeration, where North American
supermarket and Australian wholesale businesses have been weak. Refrigeration revenue was down 7% in the second quarter, and segment margin contracted 530 basis points to 7.1%. Refrigeration profit was down 47% from the record level in the
prior-year quarter. In North America, we continue to expect supermarket business to improve in the second half of the year based on new national account business won. In Australia, with the repeal of the carbon tax and more clarity in that market,
we expect an improvement in our refrigeration equipment business; however, the repeal of the carbon tax will negatively impact the profitability of our refrigerant business, and we expect profitability for Australia to be down in the second half of
the year from the same period last year.

[0001193125-14-273500:8k_2_02:15]
“Overall, the company remains on track for strong growth and record profitability in 2014. We are raising
revenue growth guidance to 5-7% for the full year and narrowing adjusted EPS from continuing operations guidance to $4.30-$4.50, up 16-22%. Over the last year, we have made significant investments to drive organic growth. With a strong balance sheet
and cash generation, we continue to invest in the future, as well as grow dividends with earnings and repurchase stock, including plans to buy back $100 million of stock in the second half of the year.”

[0001193125-14-273500:8k_2_02:16]
FINANCIAL HIGHLIGHTS

[0001193125-14-273500:8k_2_02:17]
Revenue: Revenue for the
second quarter was $961 million, up 5% from the prior-year quarter. Foreign exchange had a negative 1 point impact on revenue growth. Volume and price/mix were up from the prior-year quarter.

[0001193125-14-273500:8k_2_02:18]
Gross Profit: Gross profit for the second quarter was $263 million, up 3% from the prior-year quarter. Gross margin was 27.3% compared to 27.8% in the
prior-year quarter. Gross profit was favorably impacted by higher volume, lower material costs and favorable price, partially offset by negative mix, foreign exchange, and investments in distribution expansion and other investments for future
growth.

[0001193125-14-273500:8k_2_02:19]
Income from Continuing Operations: Adjusted income from continuing operations in the second quarter was $74.9 million, or $1.51 per share,
compared to $66.5 million, or $1.31 per share, in the prior-year quarter. Adjusted earnings from continuing operations for the second quarter of 2014 excludes a gain of $0.5 million after-tax for the net change in unrealized gains on unsettled
future contracts, a $0.5 million after-tax charge for restructuring activities, and $0.3 million in after-tax charges for other items, net.

[0001193125-14-273500:8k_2_02:20]
On a GAAP
basis, income from continuing operations for the second quarter was $74.6 million, or $1.50 per share, compared to $64.3 million, or $1.26 per share, in the prior-year quarter.

[0001193125-14-273500:8k_2_02:21]
Free Cash Flow and Total Debt: Net cash from operations in the second quarter was $52 million compared to $49 million in the prior-year quarter. The
company invested $24 million in capital assets in the second quarter, up from $11 million in the second quarter a year ago. Free cash flow was $28 million, compared to $38 million in the prior-year quarter. Total debt at the end of the second
quarter was $607 million. Total cash and cash equivalents were $50 million at the end of the quarter. The company increased its dividend 25% to $0.30 per share quarterly and repurchased $50 million of stock in the second quarter.

[0001193125-14-273500:8k_2_02:22]
BUSINESS SEGMENT HIGHLIGHTS

[0001193125-14-273500:8k_2_02:23]
Residential Heating & Cooling

[0001193125-14-273500:8k_2_02:24]
Second quarter
2014 revenue in the Residential Heating & Cooling business segment was $528 million, up 11% from the prior-year quarter. Foreign exchange was neutral. Segment profit was a record $85 million, up 28% from the prior-year quarter. Segment
profit margin was a record 16.1%, up 220 basis points. Results were primarily impacted by higher volume, lower material costs, lower SG&A, and favorable price, with partial offsets from a less favorable warranty reserve adjustment than in the
prior-year quarter and investments in distribution expansion.

[0001193125-14-273500:8k_2_02:25]
Commercial Heating & Cooling

[0001193125-14-273500:8k_2_02:26]
Revenue in the Commercial Heating & Cooling business segment was $241 million, up 5% from the prior-year quarter. Foreign exchange was neutral.
Segment profit was $39 million, up 13% from the prior-year quarter. Segment profit margin was 16.2%, up 110 basis points. Results were primarily impacted by higher volume, favorable price/mix, and lower material costs, with partial offsets from
investments in distribution expansion and start-up costs to enter the VRF market in the third quarter of 2014.

[0001193125-14-273500:8k_2_02:27]
Refrigeration

[0001193125-14-273500:8k_2_02:28]
Revenue in the Refrigeration business segment was $192 million in the second quarter, down 7% from the prior-year quarter. Foreign exchange had a negative 1
point impact on revenue. Segment profit was $14 million, down 47% from the record level of $26 million in the prior-year quarter. Segment profit margin was 7.1%, down 530 basis points. Results were primarily impacted by lower volume, unfavorable
mix, investments to support future growth, and foreign exchange, with a partial offset from lower material costs.

[0001193125-14-273500:8k_2_02:29]
FULL-YEAR OUTLOOK

[0001193125-14-273500:8k_2_02:30]
For 2014, the company is raising revenue guidance and narrowing EPS from continuing operations guidance.

[0001193125-14-273500:8k_2_02:31]
|  | • |  | Raising revenue growth guidance from 2-6% to 5-7% for the full year; 1 point of negative impact from foreign exchange is still expected. |

[0001193125-14-273500:8k_2_02:32]
|  | • |  | Narrowing adjusted EPS from continuing operations guidance from $4.20-$4.60 to $4.30-$4.50. |

[0001193125-14-273500:8k_2_02:33]
|  | • |  | Narrowing GAAP EPS from continuing operations guidance from $4.18-$4.58 to $4.27-$4.47. |

[0001193125-14-273500:8k_2_02:34]
|  | • |  | Reiterating corporate expense guidance of approximately $70 million in 2014. |

[0001193125-14-273500:8k_2_02:35]
|  | • |  | Reiterating effective tax rate guidance of 34-35% on a full-year basis. |

[0001193125-14-273500:8k_2_02:36]
|  | • |  | Reiterating capital expenditure guidance of approximately $90 million in 2014. |

[0001193125-14-273500:8k_2_02:37]
|  | • |  | Reiterating plans for $150 million of stock repurchases in 2014. |

[0001193125-14-273500:8k_2_02:38]
CONFERENCE CALL INFORMATION

[0001193125-14-273500:8k_2_02:39]
A conference call to discuss the company’s second quarter results will be held this morning at 8:30 a.m. Central time. To listen, please call the
conference call line at 612-332-0636 at least 10 minutes prior to the scheduled start time and use reservation number 331186. The conference call will also be webcast on Lennox International’s web site at www.lennoxinternational.com. A replay
will be available from 11:00 a.m. Central time on July 21 through July 28, 2014 by dialing 800-475-6701 (U.S.) or 320-365-3844 (international) and using access code 331186. The call will also be archived on the company’s web site.

[0001193125-14-273500:8k_2_02:40]
Lennox International Inc. is a global leader in the heating, air conditioning, and refrigeration markets. Lennox International stock is traded on the New
York Stock Exchange under the symbol “LII”. Additional information is available at: www.lennoxinternational.com or by contacting Steve Harrison, Vice President, Investor Relations, at 972-497-6670.

[0001193125-14-273500:8k_2_02:41]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-273500:8k_2_02:42]
Consolidated Statements of Operations

[0001193125-14-273500:8k_2_02:43]
(Unaudited)

[0001193125-14-273500:8k_2_02:44]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Amounts in millions, except per share data) |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 960.7 |  |  | $ | 913.1 |  |  | $ | 1,656.1 |  |  | $ | 1,581.5 |  |
| Cost of goods sold |  |  | 698.1 |  |  |  | 659.1 |  |  |  | 1,225.4 |  |  |  | 1,165.5 |  |
| Gross profit |  |  | 262.6 |  |  |  | 254.0 |  |  |  | 430.7 |  |  |  | 416.0 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses |  |  | 148.9 |  |  |  | 151.3 |  |  |  | 284.5 |  |  |  | 287.0 |  |
| Losses (gains) and other expenses, net |  |  | (1.0 | ) |  |  | 2.1 |  |  |  | 1.4 |  |  |  | 3.2 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 2.4 |  |  |  | 0.3 |  |  |  | 2.9 |  |
| Income from equity method investments |  |  | (4.6 | ) |  |  | (4.2 | ) |  |  | (8.5 | ) |  |  | (7.4 | ) |
| Operational income from continuing operations |  |  | 119.1 |  |  |  | 102.4 |  |  |  | 153.0 |  |  |  | 130.3 |  |
| Interest expense, net |  |  | 3.7 |  |  |  | 3.6 |  |  |  | 7.0 |  |  |  | 7.0 |  |
| Other expense (income), net |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.1 | ) |
| Income from continuing operations before income taxes |  |  | 115.4 |  |  |  | 99.0 |  |  |  | 146.0 |  |  |  | 123.4 |  |
| Provision for income taxes |  |  | 40.8 |  |  |  | 34.7 |  |  |  | 51.5 |  |  |  | 43.3 |  |
| Income from continuing operations |  |  | 74.6 |  |  |  | 64.3 |  |  |  | 94.5 |  |  |  | 80.1 |  |
| Discontinued Operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  | (1.1 | ) |  |  | — |  |  |  | (1.1 | ) |  |  | (13.4 | ) |
| Benefit from income taxes |  |  | (0.4 | ) |  |  | — |  |  |  | (0.4 | ) |  |  | (5.6 | ) |
| Loss from discontinued operations |  |  | (0.7 | ) |  |  | — |  |  |  | (0.7 | ) |  |  | (7.8 | ) |
| Net income |  | $ | 73.9 |  |  | $ | 64.3 |  |  | $ | 93.8 |  |  | $ | 72.3 |  |
| Earnings per share – Basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.53 |  |  | $ | 1.28 |  |  | $ | 1.93 |  |  | $ | 1.60 |  |
| Loss from discontinued operations |  |  | (0.02 | ) |  |  | — |  |  |  | (0.01 | ) |  |  | (0.16 | ) |
| Net income |  | $ | 1.51 |  |  | $ | 1.28 |  |  | $ | 1.92 |  |  | $ | 1.44 |  |
| Earnings per share – Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1.50 |  |  | $ | 1.26 |  |  | $ | 1.90 |  |  | $ | 1.57 |  |
| Loss from discontinued operations |  |  | (0.01 | ) |  |  | — |  |  |  | (0.01 | ) |  |  | (0.15 | ) |
| Net income |  | $ | 1.49 |  |  | $ | 1.26 |  |  | $ | 1.89 |  |  | $ | 1.42 |  |
| Weighted Average Number of Shares Outstanding - Basic |  |  | 48.8 |  |  |  | 50.2 |  |  |  | 48.9 |  |  |  | 50.2 |  |
| Weighted Average Number of Shares Outstanding - Diluted |  |  | 49.6 |  |  |  | 50.9 |  |  |  | 49.7 |  |  |  | 51.0 |  |
| Cash dividends declared per share |  | $ | 0.30 |  |  | $ | 0.24 |  |  | $ | 0.54 |  |  | $ | 0.44 |  |

[0001193125-14-273500:8k_2_02:45]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-273500:8k_2_02:46]
Segment Net Sales and Profit (Loss)

[0001193125-14-273500:8k_2_02:47]
(Unaudited)

[0001193125-14-273500:8k_2_02:48]
|  |  | For the Three Months |  |  | For the Six Months |  |
| (Amounts in millions) |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 527.7 |  |  | $ | 476.2 |  |  | $ | 869.8 |  |  | $ | 790.7 |  |
| Commercial Heating & Cooling |  |  | 241.0 |  |  |  | 229.6 |  |  |  | 414.0 |  |  |  | 392.6 |  |
| Refrigeration |  |  | 192.0 |  |  |  | 207.3 |  |  |  | 372.3 |  |  |  | 398.2 |  |
|  |  | $ | 960.7 |  |  | $ | 913.1 |  |  | $ | 1,656.1 |  |  | $ | 1,581.5 |  |
| Segment Profit (Loss) (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential Heating & Cooling |  | $ | 85.0 |  |  | $ | 66.2 |  |  | $ | 109.4 |  |  | $ | 86.7 |  |
| Commercial Heating & Cooling |  |  | 39.0 |  |  |  | 34.6 |  |  |  | 49.2 |  |  |  | 45.7 |  |
| Refrigeration |  |  | 13.7 |  |  |  | 25.8 |  |  |  | 25.8 |  |  |  | 42.5 |  |
| Corporate and other |  |  | (19.2 | ) |  |  | (20.9 | ) |  |  | (30.6 | ) |  |  | (39.6 | ) |
| Subtotal that includes segment profit and eliminations |  |  | 118.5 |  |  |  | 105.7 |  |  |  | 153.8 |  |  |  | 135.3 |  |
| Reconciliation to income from continuing operations before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special product quality adjustments |  |  | (0.4 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | (0.1 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit (loss) (1) |  |  | (0.4 | ) |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 2.2 |  |
| Restructuring charges |  |  | 0.2 |  |  |  | 2.4 |  |  |  | 0.3 |  |  |  | 2.9 |  |
| Interest expense, net |  |  | 3.7 |  |  |  | 3.6 |  |  |  | 7.0 |  |  |  | 7.0 |  |
| Other expense (income), net |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |  | (0.1 | ) |
| Income from continuing operations before income taxes |  | $ | 115.4 |  |  | $ | 99.0 |  |  | $ | 146.0 |  |  | $ | 123.4 |  |

[0001193125-14-273500:8k_2_02:49]
| (1) | The Company defines segment profit and loss as a segment’s income or loss from continuing operations before income taxes included in the accompanying Consolidated Statements of Operations, excluding: |

[0001193125-14-273500:8k_2_02:50]
|  | • |  | Special product quality adjustments; |

[0001193125-14-273500:8k_2_02:51]
|  | • |  | The following items in Losses (gains) and other expenses, net: |

[0001193125-14-273500:8k_2_02:52]
|  | • |  | Net change in unrealized gains and/or losses on unsettled futures contracts, |

[0001193125-14-273500:8k_2_02:53]
|  | • |  | Special legal contingency charges, |

[0001193125-14-273500:8k_2_02:54]
|  | • |  | Asbestos-related litigation, and |

[0001193125-14-273500:8k_2_02:55]
|  | • |  | Other items, net; |

[0001193125-14-273500:8k_2_02:56]
|  | • |  | Restructuring charges; |

[0001193125-14-273500:8k_2_02:57]
|  | • |  | Goodwill, long-lived asset, and equity method investment impairments; |

[0001193125-14-273500:8k_2_02:58]
|  | • |  | Interest expense, net; and |

[0001193125-14-273500:8k_2_02:59]
|  | • |  | Other expense, net. |

[0001193125-14-273500:8k_2_02:60]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-273500:8k_2_02:61]
Consolidated Balance Sheets

[0001193125-14-273500:8k_2_02:62]
|  |  | As of June 30, |  |  | As of December |  |
| (Amounts in millions, except shares and par values) |  | 2014 |  |  | 31, 2013 |  |
|  |  | (unaudited) |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 49.6 |  |  | $ | 38.0 |  |
| Accounts and notes receivable, net of allowances of $9.6 and $9.8 in 2014 and 2013, respectively |  |  | 576.5 |  |  |  | 408.1 |  |
| Inventories, net |  |  | 514.9 |  |  |  | 378.8 |  |
| Deferred income taxes, net |  |  | 23.5 |  |  |  | 24.5 |  |
| Other assets |  |  | 58.2 |  |  |  | 53.0 |  |
| Total current assets |  |  | 1,222.7 |  |  |  | 902.4 |  |
| Property, plant and equipment, net of accumulated depreciation of $643.5 and $617.3 in 2014 and 2013, respectively |  |  | 350.5 |  |  |  | 335.5 |  |
| Goodwill |  |  | 219.7 |  |  |  | 216.8 |  |
| Deferred income taxes |  |  | 86.4 |  |  |  | 88.5 |  |
| Other assets, net |  |  | 90.8 |  |  |  | 83.5 |  |
| Total assets |  | $ | 1,970.1 |  |  | $ | 1,626.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt |  |  | 1.3 |  |  |  | 1.3 |  |
| Accounts payable |  |  | 400.9 |  |  |  | 283.1 |  |
| Accrued expenses |  |  | 236.6 |  |  |  | 232.1 |  |
| Income taxes payable |  |  | 22.9 |  |  |  | 31.6 |  |
| Total current liabilities |  |  | 847.3 |  |  |  | 714.0 |  |
| Long-term debt |  |  | 419.8 |  |  |  | 233.2 |  |
| Post-retirement benefits, other than pensions |  |  | 3.3 |  |  |  | 4.6 |  |
| Pensions |  |  | 60.7 |  |  |  | 70.0 |  |
| Other liabilities |  |  | 121.0 |  |  |  | 119.2 |  |
| Total liabilities |  |  | 1,452.1 |  |  |  | 1,141.0 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock, $.01 par value, 25,000,000 shares authorized, no shares issued or outstanding |  |  | — |  |  |  | — |  |
| Common stock, $.01 par value, 200,000,000 shares authorized, 87,170,197 shares issued |  |  | 0.9 |  |  |  | 0.9 |  |
| Additional paid-in capital |  |  | 927.2 |  |  |  | 912.7 |  |
| Retained earnings |  |  | 937.9 |  |  |  | 870.5 |  |
| Accumulated other comprehensive loss |  |  | (50.9 | ) |  |  | (61.1 | ) |
| Treasury stock, at cost, 38,430,840 shares and 38,066,794 shares in 2014 and 2013, respectively |  |  | (1,297.9 | ) |  |  | (1,238.1 | ) |
| Noncontrolling interests |  |  | 0.8 |  |  |  | 0.8 |  |
| Total stockholders’ equity |  |  | 518.0 |  |  |  | 485.7 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,970.1 |  |  | $ | 1,626.7 |  |

[0001193125-14-273500:8k_2_02:63]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-273500:8k_2_02:64]
Consolidated Statements of Cash Flows

[0001193125-14-273500:8k_2_02:65]
(Unaudited)

[0001193125-14-273500:8k_2_02:66]
|  |  | For the Six Months Ended |  |
| (Amounts in millions) |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93.8 |  |  | $ | 72.3 |  |
| Net loss from discontinued operations |  |  | 0.7 |  |  |  | 7.8 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Income from equity method investments |  |  | (8.5 | ) |  |  | (7.4 | ) |
| Dividends from affiliates |  |  | 1.7 |  |  |  | 1.7 |  |
| Restructuring expenses, net of cash paid |  |  | — |  |  |  | (0.5 | ) |
| Provision for bad debts |  |  | 1.3 |  |  |  | 1.9 |  |
| Unrealized losses (gains) on derivative contracts |  |  | (0.1 | ) |  |  | 2.3 |  |
| Stock-based compensation expense |  |  | 10.7 |  |  |  | 15.2 |  |
| Depreciation and amortization |  |  | 30.0 |  |  |  | 28.5 |  |
| Deferred income taxes |  |  | 0.6 |  |  |  | (1.0 | ) |
| Other items, net |  |  | 0.3 |  |  |  | 13.8 |  |
| Changes in assets and liabilities, net of effects of divestitures: |  |  |  |  |  |  |  |  |
| Accounts and notes receivable |  |  | (168.2 | ) |  |  | (177.1 | ) |
| Inventories |  |  | (133.0 | ) |  |  | (118.3 | ) |
| Other current assets |  |  | (4.2 | ) |  |  | (3.6 | ) |
| Accounts payable |  |  | 114.3 |  |  |  | 80.0 |  |
| Accrued expenses |  |  | 3.4 |  |  |  | (10.6 | ) |
| Income taxes payable and receivable |  |  | (6.0 | ) |  |  | 12.9 |  |
| Other |  |  | (9.5 | ) |  |  | 5.8 |  |
| Net cash used in discontinued operations |  |  | (0.7 | ) |  |  | (12.0 | ) |
| Net cash used in operating activities |  |  | (73.4 | ) |  |  | (88.3 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (41.2 | ) |  |  | (23.4 | ) |
| Net proceeds from sale of business |  |  | — |  |  |  | 4.8 |  |
| Net cash used in discontinued operations |  |  | — |  |  |  | (0.1 | ) |
| Net cash used in investing activities |  |  | (41.2 | ) |  |  | (18.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Short-term borrowings, net |  |  | (0.6 | ) |  |  | 1.6 |  |
| Asset securitization borrowings |  |  | 20.0 |  |  |  | 270.0 |  |
| Asset securitization payments |  |  | — |  |  |  | (180.0 | ) |
| Long-term debt payments |  |  | (0.9 | ) |  |  | (0.5 | ) |
| Borrowings from revolving credit facility |  |  | 1,018.5 |  |  |  | 700.5 |  |
| Payments on revolving credit facility |  |  | (832.5 | ) |  |  | (640.5 | ) |
| Proceeds from employee stock purchases |  |  | 1.0 |  |  |  | 1.0 |  |
| Repurchases of common stock |  |  | (50.0 | ) |  |  | (33.0 | ) |
| Repurchases of common stock to satisfy employee withholding tax obligations |  |  | (10.8 | ) |  |  | (5.8 | ) |
| Excess tax benefits related to share-based payments |  |  | 4.0 |  |  |  | 3.4 |  |
| Cash dividends paid |  |  | (23.6 | ) |  |  | (10.1 | ) |
| Net cash provided by financing activities |  |  | 125.1 |  |  |  | 106.6 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 10.5 |  |  |  | (0.4 | ) |
| Effect of exchange rates on cash and cash equivalents |  |  | 1.1 |  |  |  | (6.1 | ) |
| Cash and cash equivalents, beginning of period |  |  | 38.0 |  |  |  | 51.8 |  |
| Cash and cash equivalents, end of period |  | $ | 49.6 |  |  | $ | 45.3 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |
| Interest paid |  | $ | 7.8 |  |  | $ | 7.7 |  |
| Income taxes paid (net of refunds) |  | $ | 52.3 |  |  | $ | 22.3 |  |

[0001193125-14-273500:8k_2_02:67]
LENNOX INTERNATIONAL INC. AND SUBSIDIARIES

[0001193125-14-273500:8k_2_02:68]
Reconciliation to U.S. GAAP (Generally Accepted Accounting Principles) Measures

[0001193125-14-273500:8k_2_02:69]
(Unaudited, in millions, except per share and ratio data)

[0001193125-14-273500:8k_2_02:70]
Use of Non-GAAP Financial Measures

[0001193125-14-273500:8k_2_02:71]
To supplement the
Company’s consolidated financial statements and segment net sales and profit presented in accordance with U.S.GAAP, additional non-GAAP financial measures are provided and reconciled in the following tables. In addition to these non-GAAP
measures, the Company also provides rates of revenue change at constant currency on a consolidated and segment basis. The Company believes that these non-GAAP financial measures, when considered together with the GAAP financial measures, provide
information that is useful to investors in understanding period-over-period operating results. The Company believes that these non-GAAP financial measures enhance the ability of investors to analyze the Company’s business trends and operating
performance.

[0001193125-14-273500:8k_2_02:72]
Reconciliation of Income from Continuing Operations, a GAAP measure, to Adjusted Income from Continuing Operations, a Non-GAAP measure

[0001193125-14-273500:8k_2_02:73]
|  |  | For the Three Months |  |  | For the Six Months |  |
|  |  | Ended June 30, |  |  | Ended June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Income from continuing operations, a GAAP measure |  | $ | 74.6 |  |  | $ | 64.3 |  |  | $ | 94.5 |  |  | $ | 80.1 |  |
| Restructuring charges, after tax |  |  | 0.5 |  |  |  | 1.6 |  |  |  | 0.6 |  |  |  | 1.9 |  |
| Special product quality adjustments, after tax (b) |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Special legal contingency charges, after tax (a) |  |  | (0.1 | ) |  |  | — |  |  |  | 0.1 |  |  |  | 0.2 |  |
| Asbestos-related litigation, after tax (a) |  |  | 0.2 |  |  |  | — |  |  |  | 0.4 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | (0.5 | ) |  |  | 0.5 |  |  |  | (0.1 | ) |  |  | 1.2 |  |
| Other items, net, after tax (a) |  |  | 0.4 |  |  |  | — |  |  |  | 0.5 |  |  |  | 0.2 |  |
| Adjusted income from continuing operations, a non-GAAP measure |  | $ | 74.9 |  |  | $ | 66.5 |  |  | $ | 95.8 |  |  | $ | 83.5 |  |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 1.50 |  |  | $ | 1.26 |  |  | $ | 1.90 |  |  | $ | 1.57 |  |
| Restructuring charges, after tax |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.04 |  |
| Special product quality adjustments, after tax (b) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Special legal contingency charges, after tax (a) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Asbestos-related litigation, after tax (a) |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled future contracts, after tax (a) |  |  | (0.01 | ) |  |  | 0.01 |  |  |  | — |  |  |  | 0.02 |  |
| Other items, net, after tax (a) |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.01 |  |
| Adjusted earnings per share from continuing operations - diluted, a non- GAAP measure |  | $ | 1.51 |  |  | $ | 1.31 |  |  | $ | 1.93 |  |  | $ | 1.64 |  |
| (a) Recorded in Losses (gains) and other expenses, net in the Consolidated Statements of Operations |  |
| (b) Recorded in Cost of goods sold in the Consolidated Statements of Operations |  |
|  |  | For the Three MonthsEnded June 30, |  |  | For the Six MonthsEnded June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Components of Losses (gains) and other expenses, net (pre-tax): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized losses on settled future contracts (a) |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 0.4 |  |
| Foreign currency exchange losses (gains) (a) |  |  | (0.8 | ) |  |  | 0.9 |  |  |  | 0.1 |  |  |  | 0.6 |  |
| Gain on disposal of fixed assets (a) |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Net change in unrealized losses (gains) on unsettled futures contracts (b) |  |  | (0.8 | ) |  |  | 0.7 |  |  |  | (0.2 | ) |  |  | 1.8 |  |
| Special legal contingency charges (b) |  |  | (0.2 | ) |  |  | — |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Asbestos-related litigation (b) |  |  | 0.4 |  |  |  | — |  |  |  | 0.6 |  |  |  | — |  |
| Other items, net (b) |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Losses (gains) and other expenses, net (pre-tax) |  | $ | (1.0 | ) |  | $ | 2.1 |  |  | $ | 1.4 |  |  | $ | 3.2 |  |

[0001193125-14-273500:8k_2_02:74]
| (a) | Included in segment profit (loss) and Adjusted income from continuing operations |

[0001193125-14-273500:8k_2_02:75]
| (b) | Excluded from segment profit (loss) and Adjusted income from continuing operations |

[0001193125-14-273500:8k_2_02:76]
Reconciliation of Estimated Adjusted Income per Share from Continuing Operations - Diluted, a Non-GAAP
measure, to Income per Share from Continuing Operations - Diluted, a GAAP measure

[0001193125-14-273500:8k_2_02:77]
|  |  | For the Year |  |
|  |  | Ended |  |
|  |  | December 31, |  |
|  |  | 2014 |  |
|  |  | ESTIMATED |  |
| Adjusted income per share from continuing operations - diluted, a Non-GAAP measure |  | $ | 4.30 - $4.50 |  |
| Net change in unrealized losses on unsettled future contracts and other items |  |  | (0.03 | ) |
| Income per share from continuing operations - diluted, a GAAP measure |  | $ | 4.27 - $4.47 |  |

[0001193125-14-273500:8k_2_02:78]
Reconciliation of Net Cash Provided by (Used in) Operating Activities, a GAAP measure, to Free Cash Flow, a Non-GAAP
measure (dollars in millions)

[0001193125-14-273500:8k_2_02:79]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net cash provided by (used in) operating activities, a GAAP measure |  | $ | 51.6 |  |  | $ | 49.0 |  |  | $ | (73.4 | ) |  | $ | (88.3 | ) |
| Purchases of property, plant and equipment |  |  | (23.9 | ) |  |  | (11.3 | ) |  |  | (41.2 | ) |  |  | (23.4 | ) |
| Proceeds from the disposal of property, plant and equipment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Free cash flow, a Non-GAAP measure |  | $ | 27.7 |  |  | $ | 37.7 |  |  | $ | (114.6 | ) |  | $ | (111.7 | ) |
|  |  |  |  |  |  |  |  |  |  |  | TrailingTwelveMonths toJune 30, 2014 |  |
| Calculation of Debt to EBITDA Ratio (dollars in millions): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EBIT (a) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 319.1 |  |
| Depreciation and amortization expense (b) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 60.4 |  |
| EBITDA (a + b) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 379.5 |  |
| Total debt at June 30, 2014 (c) |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 606.7 |  |
| Total Debt to EBITDA ratio ((c / (a + b)) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1.6 |  |

[0001193125-14-273500:8k_2_02:80]
Reconciliation of EBIT, a Non-GAAP measure, to Income From Continuing Operations Before Income Taxes, a GAAP measure
(dollars in millions)

[0001193125-14-273500:8k_2_02:81]
|  |  | TrailingTwelveMonths toJune 30, 2014 |  |
| EBIT per above, a Non-GAAP measure |  | $ | 319.1 |  |
| Special product quality adjustments |  |  | (2.5 | ) |
| Items in Losses (gains) and other expenses, net that are excluded from segment profit |  |  | 7.4 |  |
| Restructuring charges |  |  | 2.4 |  |
| Interest expense, net |  |  | 14.5 |  |
| Other expenses, net |  |  | 0.5 |  |
| Income from continuing operations before income taxes, a GAAP measure |  | $ | 296.8 |  |
