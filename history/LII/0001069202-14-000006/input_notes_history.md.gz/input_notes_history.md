# LII note change history — 0001069202-14-000004 → 0001069202-14-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-21):
[0001069202-14-000006:note_history:1]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 27.9 |  |  | $ | 28.7 |  |
| Other liabilities | 57.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 85.3 |  |  | $ | 81.6 |  |
  (was, 2014-04-21, similarity 0.9741):
[0001069202-14-000004:note_history:1]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Accrued expenses | $ | 29.2 |  |  | $ | 28.7 |  |
| Other liabilities | 52.4 |  |  | 52.9 |  |
| Total warranty liability | $ | 81.6 |  |  | $ | 81.6 |  |

- changed (2014-07-21):
[0001069202-14-000006:note_history:2]
The changes in product warranty liabilities related to continuing operations for the six months ended June 30, 2014 were as follows (in millions):
  (was, 2014-04-21, similarity 0.9404):
[0001069202-14-000004:note_history:2]
The changes in product warranty liabilities related to continuing operations for the three months ended March 31, 2014 were as follows (in millions):

- changed (2014-07-21):
[0001069202-14-000006:note_history:3]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (10.3 | ) |
| Changes resulting from issuance of new warranties | 16.0 |  |
| Changes in estimates associated with pre-existing liabilities | (2.2 | ) |
| Changes in foreign currency translation rates and other | 0.2 |  |
| Total warranty liability as of June 30, 2014 | $ | 85.3 |  |
  (was, 2014-04-21, similarity 0.9741):
[0001069202-14-000004:note_history:3]
| Total warranty liability as of December 31, 2013 | $ | 81.6 |  |
| Warranty claims paid | (4.8 | ) |
| Changes resulting from issuance of new warranties | 6.6 |  |
| Changes in estimates associated with pre-existing liabilities | (1.6 | ) |
| Changes in foreign currency translation rates and other | (0.2 | ) |
| Total warranty liability as of March 31, 2014 | $ | 81.6 |  |

- changed (2014-07-21):
[0001069202-14-000006:note_history:4]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.
  (was, 2014-04-21, similarity 0.9987):
[0001069202-14-000004:note_history:4]
We may also incur costs related to our products that may not be covered under our warranties and are not covered by insurance, and, from time to time, we may repair or replace installed products experiencing quality issues in order to satisfy our customers and to protect our brand. These product quality issues may be caused by vendor-supplied components that fail to meet required specifications.

- changed (2014-07-21):
[0001069202-14-000006:note_history:5]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the six months ended June 30, 2014 were as follows (in millions):
  (was, 2014-04-21, similarity 0.9246):
[0001069202-14-000004:note_history:5]
We have liabilities for non-warranty product quality issues related to a heating and cooling product line produced in 2006 and 2007 that we believe resulted from vendor-supplied materials. The changes in the accrued product quality issues for the three months ended March 31, 2014 were as follows (in millions):

- changed (2014-07-21):
[0001069202-14-000006:note_history:6]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.4 | ) |
| Total accrued product quality issues as of June 30, 2014 | $ | 4.3 |  |
  (was, 2014-04-21, similarity 0.9819):
[0001069202-14-000004:note_history:6]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.2 | ) |
| Total accrued product quality issues as of March 31, 2014 | $ | 4.5 |  |

- changed (2014-07-21):
[0001069202-14-000006:note_history:7]
The expenses related to these product quality issues were classified in Cost of goods sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued expenses in the Consolidated Balance Sheets.  The expenses for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.
  (was, 2014-04-21, similarity 0.999):
[0001069202-14-000004:note_history:7]
The expenses related to these product quality issues were classified in Cost of Goods Sold in the Consolidated Statements of Operations and the related liabilities are included in Accrued Expenses in the Consolidated Balance Sheets.  The expense for these product quality issues, and the related liabilities, are not included in the above tables related to our estimated product warranty liabilities.  We may incur additional charges for these product quality issues in the future as more information becomes available.

- changed (2014-07-21):
[0001069202-14-000006:note_history:8]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the six months ended June 30, 2014, and 2013, expense for asbestos-related litigation was $0.6 million, and $0.5 million, net of insurance recoveries, respectively.
  (was, 2014-04-21, similarity 0.9591):
[0001069202-14-000004:note_history:8]
Some of these claims and lawsuits allege personal injury or health problems resulting from exposure to asbestos that was integrated into certain of our products.  We have never manufactured asbestos and have not incorporated asbestos-containing components into our products for several decades.  A substantial majority of asbestos-related claims have been covered by insurance or other forms of indemnity or have been dismissed without payment.  The remainder of our closed cases have been resolved for amounts that are not material, individually or in the aggregate.  Our defense costs for asbestos-related claims are generally covered by insurance; however, our insurance coverage for settlements and judgments for asbestos-related claims vary depending on several factors and are subject to policy limits.  As a result, we may have greater financial exposure for future settlements and judgments.  For the three months ended March 31, 2014, and 2013, expenses for asbestos-related litigation were $0.2 million and $0.6 million, net of insurance recoveries, respectively.

- added (2014-07-21):
[0001069202-14-000006:note_history:9]
We are the defendant in an attempted class action lawsuit which alleges that evaporator coils in certain of our residential air conditioning products are susceptible to a type of corrosion that can result in coil leaks, and asserts claims for relief.  We dispute the allegations in the lawsuit.  The outcome related to this action is uncertain and we therefore cannot reasonably estimate the amount of any potential impact.


## us-gaap:ProductLiabilityContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-21):
[0001069202-14-000006:note_history:10]
The changes in the accrued product quality issues for the six months ended June 30, 2014 were as follows (in millions):
  (was, 2014-04-21, similarity 0.9264):
[0001069202-14-000004:note_history:10]
The changes in the accrued product quality issues for the three months ended March 31, 2014 were as follows (in millions):

- changed (2014-07-21):
[0001069202-14-000006:note_history:11]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.4 | ) |
| Total accrued product quality issues as of June 30, 2014 | $ | 4.3 |  |
  (was, 2014-04-21, similarity 0.9819):
[0001069202-14-000004:note_history:11]
| Total accrued product quality issues as of December 31, 2013 | $ | 4.7 |  |
| Changes in estimates associated with pre-existing liabilities | — |  |
| Product quality claims paid | (0.2 | ) |
| Total accrued product quality issues as of March 31, 2014 | $ | 4.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-21):
[0001069202-14-000006:note_history:12]
The accompanying unaudited Consolidated Balance Sheet as of June 30, 2014, the accompanying unaudited Consolidated
  (was, 2014-04-21, similarity 0.9585):
[0001069202-14-000004:note_history:12]
The accompanying unaudited Consolidated Balance Sheet as of March 31, 2014, the accompanying unaudited Consolidated

- changed (2014-07-21):
[0001069202-14-000006:note_history:13]
Statements of Operations for the three and six months ended June 30, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three and six months ended June 30, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the six months ended June 30, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.
  (was, 2014-04-21, similarity 0.9533):
[0001069202-14-000004:note_history:13]
Statements of Operations for the three months ended March 31, 2014 and 2013, the accompanying unaudited Consolidated Statements of Comprehensive Income for the three months ended March 31, 2014 and 2013, and the accompanying unaudited Consolidated Statements of Cash Flows for the three months ended March 31, 2014 and 2013 should be read in conjunction with our audited consolidated financial statements and footnotes included in our Annual Report on Form 10-K for the year ended December 31, 2013. The accompanying unaudited consolidated financial statements have been prepared in accordance with generally accepted accounting principles (“GAAP”) for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. The accompanying consolidated financial statements contain all material adjustments, consisting principally of normal recurring adjustments, necessary for a fair presentation of our financial position, results of operations and cash flows. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to applicable rules and regulations, although we believe that the disclosures herein are adequate to make the information presented not misleading. The operating results for the interim periods are not necessarily indicative of the results that may be expected for a full year.

- changed (2014-07-21):
[0001069202-14-000006:note_history:14]
Our fiscal year ends on December 31 and each quarter is comprised of 13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.
  (was, 2014-04-21, similarity 0.9695):
[0001069202-14-000004:note_history:14]
Our fiscal year ends on December 31 and each of our quarters are comprised of 13 weeks. For convenience, throughout these financial statements, the 13 weeks comprising each quarterly period are denoted by the last day of the respective calendar quarter.


## lii:WeightedAverageBorrowingRateFacilityTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-21):
[0001069202-14-000006:note_history:15]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |
  (was, 2014-04-21, similarity 0.9538):
[0001069202-14-000004:note_history:15]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-07-21):
[0001069202-14-000006:note_history:16]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 5.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 203.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 419.8 |  |  | $ | 233.2 |  |
| Total debt | $ | 606.7 |  |  | $ | 400.4 |  |

- changed (2014-07-21):
[0001069202-14-000006:note_history:17]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $5.6 million and $5.9 million of foreign obligations as of June 30, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.
  (was, 2014-04-21, similarity 0.9856):
[0001069202-14-000004:note_history:17]
Through several of our foreign subsidiaries, we have facilities available to assist in financing seasonal borrowing needs for our foreign locations. We had $8.8 million and $5.9 million of foreign obligations as of March 31, 2014 and December 31, 2013, respectively, that were primarily borrowings under non-committed facilities.

- changed (2014-07-21):
[0001069202-14-000006:note_history:18]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less allowances, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):
  (was, 2014-04-21, similarity 0.9861):
[0001069202-14-000004:note_history:18]
The ASP provides for a maximum securitization amount ranging from $160.0 million to $220.0 million, depending on the period.  The maximum capacity under the ASP is the lesser of the maximum securitization amount or 100% of the net pool balance less reserves, as defined by the ASP.  Eligibility for securitization is limited based on the amount and quality of the qualifying accounts receivable and is calculated monthly.  The eligible amounts available and beneficial interests sold were as follows (in millions):

- changed (2014-07-21):
[0001069202-14-000006:note_history:19]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 180.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 180.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |
  (was, 2014-04-21, similarity 0.9811):
[0001069202-14-000004:note_history:19]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Eligible amount available under the ASP on qualified accounts receivable | $ | 160.0 |  |  | $ | 160.0 |  |
| Beneficial interest sold | 160.0 |  |  | 160.0 |  |
| Remaining amount available | $ | — |  |  | $ | — |  |

- added (2014-07-21):
[0001069202-14-000006:note_history:20]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for June 30, 2014 and December 31, 2013 was 0.77% and 0.78% respectively. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- changed (2014-07-21):
[0001069202-14-000006:note_history:21]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of June 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-04-21, similarity 0.9935):
[0001069202-14-000004:note_history:21]
The ASP contains certain restrictive covenants relating to the quality of our accounts receivable and certain cross-default provisions with our Fourth Amended and Restated Revolving Credit Facility Agreement ("Domestic Revolving Credit Facility"),  senior unsecured notes and any other indebtedness we may have over $75.0 million. The administrative agent under the ASP is also a participant in our Domestic Revolving Credit Facility. The participating financial institutions have investment grade credit ratings. We continue to evaluate their credit ratings and have no reason to believe they will not perform under the ASP.  As of March 31, 2014, we were in compliance with all covenant requirements.

- added (2014-07-21):
[0001069202-14-000006:note_history:22]
Under our $650.0 million Domestic Revolving Credit Facility, we had outstanding borrowings of $203.0 million as well as $27.6 million committed to standby letters of credit as of June 30, 2014. Subject to covenant limitations, $419.4 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.

- changed (2014-07-21):
[0001069202-14-000006:note_history:23]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |
  (was, 2014-04-21, similarity 0.9538):
[0001069202-14-000004:note_history:23]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Weighted average borrowing rate | 1.13 | % |  | 1.17 | % |

- changed (2014-07-21):
[0001069202-14-000006:note_history:24]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our Domestic Revolving Credit Facility could occur if:
  (was, 2014-04-21, similarity 0.9881):
[0001069202-14-000004:note_history:24]
Our Domestic Revolving Credit Facility contains customary events of default. These events of default include nonpayment of principal or interest, breach of covenants or other restrictions or requirements, default on certain other indebtedness or receivables securitizations (cross default), and bankruptcy.  A cross default under our revolving credit facility could occur if:

- changed (2014-07-21):
[0001069202-14-000006:note_history:25]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).  As of June 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-04-21, similarity 0.9954):
[0001069202-14-000004:note_history:25]
Each of our major debt agreements contains provisions by which a default under one agreement causes a default in the others (a "cross default"). If a cross default under the Domestic Revolving Credit Facility, our senior unsecured notes, the Lake Park Renewal (recorded as an operating lease), or our ASP were to occur, it could have a wider impact on our liquidity than might otherwise occur from a default of a single debt instrument or lease commitment.  If any event of default occurs and is continuing, lenders with a majority of the aggregate commitments may require the administrative agent to terminate our right to borrow under our Domestic Revolving Credit Facility and accelerate amounts due under our Domestic Revolving Credit Facility (except for a bankruptcy event of default, in which case such amounts will automatically become due and payable and the lenders’ commitments will automatically terminate).   As of March 31, 2014, we were in compliance with all covenant requirements.

- changed (2014-07-21):
[0001069202-14-000006:note_history:26]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of June 30, 2014, we were in compliance with all covenant requirements.
  (was, 2014-04-21, similarity 0.9957):
[0001069202-14-000004:note_history:26]
We issued $200.0 million of senior unsecured notes in May 2010 through a public offering. Interest is paid semiannually on May 15 and November 15 at a fixed interest rate of 4.90% per annum. These notes mature on May 15, 2017.  The notes are guaranteed, on a senior unsecured basis, by each of our domestic subsidiaries that guarantee payment by us of any indebtedness under our Domestic Revolving Credit Facility. The indenture governing the notes contains covenants that, among other things, limit our ability and the ability of the subsidiary guarantors to: create or incur certain liens; enter into certain sale and leaseback transactions; enter into certain mergers, consolidations and transfers of substantially all of our assets; and transfer certain properties. The indenture also contains a cross default provision which is triggered if we default on other debt of at least $75.0 million in principal which is then accelerated, and such acceleration is not rescinded within 30 days of the notice date.  As of March 31, 2014, we were in compliance with all covenant requirements.

- removed (2014-07-21):
[0001069202-14-000004:note_history:27]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 8.8 |  |  | 5.9 |  |
| Total short-term debt | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 177.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 394.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 564.2 |  |  | $ | 400.4 |  |

- removed (2014-07-21):
[0001069202-14-000004:note_history:28]
We pay certain discount fees to use the ASP and to have the facility available to us. These fees relate to both the used and unused portions of the securitization. The used fee is based on the beneficial interest sold and calculated on the average LIBOR rate or floating commercial paper rate determined by the purchaser of the beneficial interest, plus a program fee of 0.60%. The average rate for both March 31, 2014 and December 31, 2013 was 0.78%. The unused fee is based on 101% of the maximum available amount less the beneficial interest sold and is calculated at a 0.30% fixed rate throughout the term of the agreement.  In addition, a 0.05% unused fee is charged on incremental available amounts above $160 million during certain months of the year.  We recorded these fees in Interest expense, net in the accompanying Consolidated Statements of Operations.

- removed (2014-07-21):
[0001069202-14-000004:note_history:29]
Under our $650 million Domestic Revolving Credit Facility, we had outstanding borrowings of $177.0 million as well as $33.5 million committed to standby letters of credit as of March 31, 2014. Subject to covenant limitations, $439.5 million was available for future borrowings. The Domestic Revolving Credit Facility provides for issuance of letters of credit for the full amount of the credit facility and matures in October 2016.  Additionally, at our request and subject to certain conditions, the commitments under the Domestic Revolving Credit Facility may be increased by a maximum of $100 million as long as existing or new lenders agree to provide such additional commitments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-07-21):
[0001069202-14-000006:note_history:30]
|  | As of June 30, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 180.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 5.6 |  |  | 5.9 |  |
| Total short-term debt | $ | 185.6 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 203.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 419.8 |  |  | $ | 233.2 |  |
| Total debt | $ | 606.7 |  |  | $ | 400.4 |  |

- removed (2014-07-21):
[0001069202-14-000004:note_history:31]
|  | As of March 31, 2014 |  | As of December 31, 2013 |
| Short-Term Debt: |  |  |  |
| Asset Securitization Program | $ | 160.0 |  |  | $ | 160.0 |  |
| Foreign obligations | 8.8 |  |  | 5.9 |  |
| Total short-term debt | $ | 168.8 |  |  | $ | 165.9 |  |
| Current maturities of long-term debt: |  |  |  |
| Capital lease obligations | $ | 1.4 |  |  | $ | 1.3 |  |
| Long-Term Debt: |  |  |  |
| Capital lease obligations | $ | 17.0 |  |  | $ | 16.2 |  |
| Domestic revolving credit facility | 177.0 |  |  | 17.0 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |
| Total long-term debt | $ | 394.0 |  |  | $ | 233.2 |  |
| Total debt | $ | 564.2 |  |  | $ | 400.4 |  |
