# LII MD&A — 0001069202-14-000006


## mdna

[0001069202-14-000006:mdna:1]
[same as prior period, unchanged from 0001069202-14-000004:mdna:1]

[0001069202-14-000006:mdna:2]
[same as prior period, unchanged from 0001069202-14-000004:mdna:2]

[0001069202-14-000006:mdna:3]
[same as prior period, unchanged from 0001069202-14-000004:mdna:3]

[0001069202-14-000006:mdna:4]
[same as prior period, unchanged from 0001069202-14-000004:mdna:4]

[0001069202-14-000006:mdna:5]
[same as prior period, unchanged from 0001069202-14-000004:mdna:5]

[0001069202-14-000006:mdna:6]
[same as prior period, unchanged from 0001069202-14-000004:mdna:6]

[0001069202-14-000006:mdna:7]
[same as prior period, unchanged from 0001069202-14-000004:mdna:7]

[0001069202-14-000006:mdna:8]
| • | Net sales increased $48 million, or 5%, to $961 million in the second quarter of 2014 compared to $913 million in the second quarter of 2013. |

[0001069202-14-000006:mdna:9]
| • | Operational income from continuing operations in the second quarter of 2014 increased $17 million to $119 million from $102 million in the second quarter of 2013. |

[0001069202-14-000006:mdna:10]
| • | Net income for the second quarter of 2014 increased $10 million to $74 million from $64 million in the second quarter of 2013. |

[0001069202-14-000006:mdna:11]
| • | Diluted earnings per share from continuing operations were $1.50 per share in the second quarter of 2014 compared to $1.26 per share in the second quarter of 2013. |

[0001069202-14-000006:mdna:12]
| • | During the second quarter, we returned $12 million to shareholders through dividend payments and $50 million through share repurchases. |

[0001069202-14-000006:mdna:13]
| • | Cash used in operating activities was $73 million in the first six months of 2014 compared to $88 million in the first six months of 2013. |

[0001069202-14-000006:mdna:14]
Second Quarter of 2014 Compared to Second Quarter of 2013 - Consolidated Results

[0001069202-14-000006:mdna:15]
[same as prior period, unchanged from 0001069202-14-000004:mdna:18]

[0001069202-14-000006:mdna:16]
|  | For the Three Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 960.7 |  |  | $ | 913.1 |  |  | 5.2 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 698.1 |  |  | 659.1 |  |  | (5.9 | ) |  | 72.7 |  |  | 72.2 |  |
| Gross profit | 262.6 |  |  | 254.0 |  |  | 3.4 |  |  | 27.3 |  |  | 27.8 |  |
| Selling, general and administrative expenses | 148.9 |  |  | 151.3 |  |  | 1.6 |  |  | 15.5 |  |  | 16.6 |  |
| Losses (gains) and other expenses, net | (1.0 | ) |  | 2.1 |  |  | (147.6 | ) |  | (0.1 | ) |  | 0.2 |  |
| Restructuring charges | 0.2 |  |  | 2.4 |  |  | 91.7 |  |  | — |  |  | 0.3 |  |
| Income from equity method investments | (4.6 | ) |  | (4.2 | ) |  | 9.5 |  |  | (0.5 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 119.1 |  |  | $ | 102.4 |  |  | 16.3 | % |  | 12.4 | % |  | 11.2 | % |

[0001069202-14-000006:mdna:17]
[same as prior period, unchanged from 0001069202-14-000004:mdna:20]

[0001069202-14-000006:mdna:18]
Net sales increased 5% in the second quarter of 2014 compared to the second quarter of 2013, primarily from 5% higher sales volumes and 1% favorable price and mix, offset by a 1% unfavorable foreign currency exchange rate impact.  The Residential Heating & Cooling and Commercial Heating & Cooling segments delivered higher volume by capturing additional replacement and new construction business.

[0001069202-14-000006:mdna:19]
[same as prior period, unchanged from 0001069202-14-000004:mdna:22]

[0001069202-14-000006:mdna:20]
Gross profit margin of 27.3% in the second quarter of 2014 decreased 50 basis points ("bps") compared to the second quarter of 2013.  Lower material costs contributed 110 bps to profit margin and price contributed 30 bps. Offsetting these increases were 20 bps of unfavorable mix, 30 bps from a less favorable warranty accrual adjustment when compared to the prior year quarter, 40 bps of unfavorable foreign currency exchange rate impact, and 40 bps for investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-14-000006:mdna:21]
[same as prior period, unchanged from 0001069202-14-000004:mdna:24]

[0001069202-14-000006:mdna:22]
SG&A was $149 million in the second quarter of 2014 compared to $151 million in the second quarter of 2013, and as a percentage of net sales, declined 110 bps from 16.6% to 15.5%.  The largest driver of the decrease in SG&A as a percentage of net sales was lower incentive compensation.

[0001069202-14-000006:mdna:23]
Losses (gains) and Other Expenses, Net

[0001069202-14-000006:mdna:24]
Losses (gains) and other expenses, net for the second quarter of 2014 and 2013 included the following (in millions):

[0001069202-14-000006:mdna:25]
|  | For the Three Months Ended June 30, |
|  | 2014 |  | 2013 |
| Realized losses on settled futures contracts | $ | 0.3 |  |  | $ | 0.4 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.8 | ) |  | 0.7 |  |
| Foreign currency exchange (gains) losses | (0.8 | ) |  | 0.9 |  |
| Gain on disposal of fixed assets | (0.1 | ) |  | — |  |
| Special legal contingency charges | (0.2 | ) |  | — |  |
| Asbestos-related litigation | 0.4 |  |  | — |  |
| Other items, net | 0.2 |  |  | 0.1 |  |
| Losses (gains) and other expenses, net | $ | (1.0 | ) |  | $ | 2.1 |  |

[0001069202-14-000006:mdna:26]
The net change in unrealized (gains) losses on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange (gains) losses increased in the second quarter of 2014 primarily due to the Australian and Canadian dollar exchange rates.

[0001069202-14-000006:mdna:27]
[same as prior period, unchanged from 0001069202-14-000004:mdna:30]

[0001069202-14-000006:mdna:28]
There were no significant restructuring charges incurred in the second quarters of 2014 or 2013.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000006:mdna:29]
[same as prior period, unchanged from 0001069202-14-000004:mdna:32]

[0001069202-14-000006:mdna:30]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $5 million in the second quarter of 2014 increased slightly over the second quarter of 2013 due to improved operating results from our joint ventures.

[0001069202-14-000006:mdna:31]
[same as prior period, unchanged from 0001069202-14-000004:mdna:34]

[0001069202-14-000006:mdna:32]
Interest expense, net was $4 million in the second quarter of 2014 and was flat compared to the second quarter of 2013.  The impact of the increase in our average net borrowings was offset by a slight decline in weighted average borrowing rates over the comparable periods.

[0001069202-14-000006:mdna:33]
[same as prior period, unchanged from 0001069202-14-000004:mdna:36]

[0001069202-14-000006:mdna:34]
The Provision for income taxes was $41 million in the second quarter of 2014 compared to $35 million in the second quarter of 2013.  The effective tax rate was 35.4% for the second quarter of 2014 compared to 35.2% for the second quarter of 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000006:mdna:35]
Second Quarter of 2014 Compared to Second Quarter of 2013 - Results by Segment

[0001069202-14-000006:mdna:36]
[same as prior period, unchanged from 0001069202-14-000004:mdna:42]

[0001069202-14-000006:mdna:37]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the second quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:38]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 527.7 |  |  | $ | 476.2 |  |  | $ | 51.5 |  |  | 10.8 | % |
| Profit | $ | 85.0 |  |  | $ | 66.2 |  |  | $ | 18.8 |  |  | 28.4 | % |
| % of net sales | 16.1 | % |  | 13.9 | % |  |  |  |  |

[0001069202-14-000006:mdna:39]
Net sales increased by 11% in the second quarter of 2014 compared to the second quarter of 2013.  Volume increased by 10% due to industry growth and market share gains and favorable price and mix increased net sales by 1%.

[0001069202-14-000006:mdna:40]
Segment profit for the second quarter of 2014 increased $19 million due to $7 million in material cost savings, $7 million in higher sales volumes, $4 million from lower SG&A expenses, and $3 million from favorable price.  Partially offsetting these increases was $2 million from a less favorable warranty accrual adjustment than in the prior-year quarter, $3 million of unfavorable foreign currency exchange rates, and $2 million from investments in distribution with the balance from other cost changes.

[0001069202-14-000006:mdna:41]
[same as prior period, unchanged from 0001069202-14-000004:mdna:47]

[0001069202-14-000006:mdna:42]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the second quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:43]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 241.0 |  |  | $ | 229.6 |  |  | $ | 11.4 |  |  | 5.0 | % |
| Profit | $ | 39.0 |  |  | $ | 34.6 |  |  | $ | 4.4 |  |  | 12.7 | % |
| % of net sales | 16.2 | % |  | 15.1 | % |  |  |  |  |

[0001069202-14-000006:mdna:44]
Net sales increased 5% in the second quarter of 2014 compared to the second quarter of 2013 due to broad-based volume and share increases in our North American businesses.

[0001069202-14-000006:mdna:45]
Segment profit in the second quarter of 2014 increased $4 million compared to the second quarter of 2013.  The benefits of $3 million from higher volumes, $2 million in material cost savings, and $2 million from favorable price and mix. Partially offsetting these increases was a total of $2 million higher SG&A expenses including start-up costs to enter the VRF market, and $1 million to support distribution expansion and other cost changes.

[0001069202-14-000006:mdna:46]
[same as prior period, unchanged from 0001069202-14-000004:mdna:52]

[0001069202-14-000006:mdna:47]
The following table presents our Refrigeration segment's net sales and profit for the second quarter of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:48]
|  | For the Three Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 192.0 |  |  | $ | 207.3 |  |  | $ | (15.3 | ) |  | (7.4 | )% |
| Profit | $ | 13.7 |  |  | $ | 25.8 |  |  | $ | (12.1 | ) |  | (46.9 | )% |
| % of net sales | 7.1 | % |  | 12.4 | % |  |  |  |  |

[0001069202-14-000006:mdna:49]
Net sales declined 7% in the second quarter of 2014 compared to the second quarter of 2013 primarily due to a 6% volume decrease in North America.  Also, foreign currency exchanges rates had a 1% unfavorable impact on net sales.

[0001069202-14-000006:mdna:50]
Segment profit for the second quarter of 2014 decreased $12 million compared to the second quarter of 2013 primarily due to $4 million from unfavorable mix, $3 million from lower volume, $1 million of costs related to investments for future growth, $2 million from unfavorable foreign currency exchange rates, and $3 million from other costs partially offset from lower material costs of $2 million with the balance from other cost changes.

[0001069202-14-000006:mdna:51]
[same as prior period, unchanged from 0001069202-14-000004:mdna:58]

[0001069202-14-000006:mdna:52]
Corporate and other expenses decreased $2 million to $19 million in the second quarter of 2014 from $21 million in the second quarter of 2013 due primarily to lower incentive compensation.

[0001069202-14-000006:mdna:53]
Year-to-Date through June 30, 2014 Compared to Year-to-Date through June 30, 2013 - Consolidated Results

[0001069202-14-000006:mdna:54]
The following table provides a summary of our financial results, including information presented as a percentage of net sales:

[0001069202-14-000006:mdna:55]
|  | For the Six Months Ended June 30, |
|  | Dollars (in millions) |  | PercentChangeFav/(Unfav) |  | Percent of Sales |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net sales | $ | 1,656.1 |  |  | $ | 1,581.5 |  |  | 4.7 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of goods sold | 1,225.4 |  |  | 1,165.5 |  |  | 5.1 |  |  | 74.0 |  |  | 73.7 |  |
| Gross profit | 430.7 |  |  | 416.0 |  |  | 3.5 |  |  | 26.0 |  |  | 26.3 |  |
| Selling, general and administrative expenses | 284.5 |  |  | 287.0 |  |  | (0.9 | ) |  | 17.2 |  |  | 18.1 |  |
| Losses and other expenses, net | 1.4 |  |  | 3.2 |  |  | (56.3 | ) |  | 0.1 |  |  | 0.2 |  |
| Restructuring charges | 0.3 |  |  | 2.9 |  |  | (89.7 | ) |  | — |  |  | 0.2 |  |
| Income from equity method investments | (8.5 | ) |  | (7.4 | ) |  | 14.9 |  |  | (0.5 | ) |  | (0.5 | ) |
| Operational income from continuing operations | $ | 153.0 |  |  | $ | 130.3 |  |  | 17.4 |  |  | 9.2 | % |  | 8.2 | % |

[0001069202-14-000006:mdna:56]
Net Sales

[0001069202-14-000006:mdna:57]
Net sales increased 5% in the first half of 2014 compared to the first half of 2013, with sales volumes up 5% and price and mix up 1%.  The volume increases were driven by our Residential Heating & Cooling and Commercial Heating & Cooling segments capturing additional replacement and new construction business.  Partially offsetting these increases was a 1% decrease from unfavorable foreign currency exchange rates.

[0001069202-14-000006:mdna:58]
Gross Profit

[0001069202-14-000006:mdna:59]
Gross profit margins of 26% in the first half of 2014 decreased 30 bps compared to the first half of 2013.  Improvements of 120 bps from material cost savings and 30 bps from price. Offsetting these increases was 20 bps from a less favorable warranty accrual adjustment when compared to the prior year, 50 bps from unfavorable foreign currency exchange rates, and 50 bps for investments in distribution and other growth initiatives with the balance from other cost changes.

[0001069202-14-000006:mdna:60]
Selling, General and Administrative Expenses

[0001069202-14-000006:mdna:61]
SG&A was $285 million for the first half of 2014 compared to $287 million for the first half of 2013, and as a percentage of net sales, declined 90 bps from 18.1% to 17.2%.  The largest driver of the decrease in SG&A as a percentage of net sales was lower incentive compensation.

[0001069202-14-000006:mdna:62]
[same as prior period, unchanged from 0001069202-14-000004:mdna:26]

[0001069202-14-000006:mdna:63]
Losses and other expenses, net for the first half of 2014 and 2013 included the following (in millions):

[0001069202-14-000006:mdna:64]
|  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |
| Realized losses on settled futures contracts | $ | 0.6 |  |  | $ | 0.4 |  |
| Net change in unrealized (gains) losses on unsettled futures contracts | (0.2 | ) |  | 1.8 |  |
| Foreign currency exchange losses | 0.1 |  |  | 0.6 |  |
| Gain on disposal of fixed assets | (0.1 | ) |  | — |  |
| Special legal contingency charges | 0.2 |  |  | 0.2 |  |
| Asbestos-related litigation | 0.6 |  |  | — |  |
| Other items, net | 0.2 |  |  | 0.2 |  |
| Losses and other expenses, net | $ | 1.4 |  |  | $ | 3.2 |  |

[0001069202-14-000006:mdna:65]
The increase in realized losses on settled futures contracts in the first half of 2014 was attributable to decreases in commodity prices relative to our settled futures contract prices.  Conversely, the net change in unrealized (gains) losses on unsettled futures contracts was due to higher commodity prices relative to the unsettled futures contract prices.  For more information on our futures contracts, see Note 4 in the Notes to the Consolidated Financial Statements.  Foreign currency exchange losses decreased in the first half of 2014 primarily due to the Australian and Canadian dollar exchange rates.

[0001069202-14-000006:mdna:66]
Restructuring Charges

[0001069202-14-000006:mdna:67]
There were no significant restructuring charges incurred in the first half of 2014 or 2013.  For additional information on our restructuring activities, refer to Note 12 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000006:mdna:68]
Income from Equity Method Investments

[0001069202-14-000006:mdna:69]
We participate in two joint ventures that are engaged in the manufacture and sale of compressors, unit coolers and condensing units. We exert significant influence over these affiliates based upon our ownerships, but do not control them due to venture partner participation.  Accordingly, these joint ventures have been accounted for under the equity method and their financial position and results of operations are not consolidated.  Income from equity method investments of $9 million in the first half of 2014 increased $1 million over the first half of 2013 due to improved operating results from our joint ventures.

[0001069202-14-000006:mdna:70]
Interest Expense, net

[0001069202-14-000006:mdna:71]
Interest expense, net was $7 million in the first half of 2014 and was flat compared to the first half of 2013.  The impact of the increase in our average net borrowings was offset by a slight decline in weighted average borrowing rates over the comparable periods.

[0001069202-14-000006:mdna:72]
Income Taxes

[0001069202-14-000006:mdna:73]
The Provision for income taxes was $52 million in the first half of 2014 compared to $43 million in the first half of 2013.  The effective tax rate was 35.3% for the first half of 2014 compared to 35.2% for the first half of 2013.  Our effective tax rates differ from the statutory federal rate of 35% for certain items, including tax credits, state and local taxes, non-deductible expenses, foreign taxes at rates other than 35% and other permanent tax differences.

[0001069202-14-000006:mdna:74]
Year-to-Date through June 30, 2014 Compared to Year-to-Date through June 30, 2013 - Results by Segment

[0001069202-14-000006:mdna:75]
Residential Heating & Cooling

[0001069202-14-000006:mdna:76]
The following table presents our Residential Heating & Cooling segment's net sales and profit for the first half of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:77]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 869.8 |  |  | $ | 790.7 |  |  | $ | 79.1 |  |  | 10.0 | % |
| Profit | $ | 109.4 |  |  | $ | 86.7 |  |  | $ | 22.7 |  |  | 26.2 | % |
| % of net sales | 12.6 | % |  | 11.0 | % |  |  |  |  |

[0001069202-14-000006:mdna:78]
Net sales increased by 10%  in the first half of 2014 compared to the first half of 2013.  Sales volumes increased net sales by 9% due to industry growth and market share gains and the benefits of favorable price and mix contributed 2%.  Changes in foreign currency exchange rates unfavorably impacted net sales by 1%.

[0001069202-14-000006:mdna:79]
Segment profit for the first half of 2014 increased $23 million due to $14 million contributed by incremental volume, $15 million from material cost savings, and $3 million from favorable price with mix contributing $2 million. Partially offsetting these increases was $5 million in distribution expenses related to continued investment in distribution expansion, unfavorable foreign exchange rates of $5 million, and the balance relating to other cost changes.

[0001069202-14-000006:mdna:80]
Commercial Heating & Cooling

[0001069202-14-000006:mdna:81]
The following table presents our Commercial Heating & Cooling segment's net sales and profit for the first half of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:82]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 414.0 |  |  | $ | 392.6 |  |  | $ | 21.4 |  |  | 5.0 | % |
| Profit | $ | 49.2 |  |  | $ | 45.7 |  |  | $ | 3.5 |  |  | 7.7 | % |
| % of net sales | 11.9 | % |  | 11.6 | % |  |  |  |  |

[0001069202-14-000006:mdna:83]
Commercial Heating & Cooling net sales increased 5% in the first half of 2014 compared to the first half of 2013 due to broad-based volume increases in North America.

[0001069202-14-000006:mdna:84]
Segment profit in the first half of 2014 increased $4 million compared to the first half of 2013.  The benefits of $6 million from incremental volume and $3 million from material cost savings. Offsetting these improvements was $3 million higher SG&A expenses including start-up costs to enter the VRF market, with the balance associated with other costs including investments in distribution expansion.

[0001069202-14-000006:mdna:85]
Refrigeration

[0001069202-14-000006:mdna:86]
The following table presents our Refrigeration segment's net sales and profit for the first half of 2014 and 2013 (dollars in millions):

[0001069202-14-000006:mdna:87]
|  | For the Six Months Ended June 30, |  |  |  |  |
|  | 2014 |  | 2013 |  | Difference |  | % Change |
| Net sales | $ | 372.3 |  |  | $ | 398.2 |  |  | $ | (25.9 | ) |  | (6.5 | )% |
| Profit | $ | 25.8 |  |  | $ | 42.5 |  |  | $ | (16.7 | ) |  | (39.3 | )% |
| % of net sales | 6.9 | % |  | 10.7 | % |  |  |  |  |

[0001069202-14-000006:mdna:88]
Refrigeration net sales declined 7% in the first half of 2014 compared to the first half of 2013 primarily due to a 5% volume decline and a 2% impact from unfavorable Australian dollar exchange rates.  The North American supermarket and Australian wholesale businesses have been soft.  We continue to expect the North American supermarket business to improve in the second half of the year based on new national account business won.  In Australia, with the repeal of the carbon tax, we expect a negative impact to the profitability of our refrigerant business for the second half of the year.

[0001069202-14-000006:mdna:89]
Segment profit for the first half of 2014 decreased $17 million compared to the first half of 2013 primarily due to volume related declines of $5 million, unfavorable mix of $5 million, unfavorable foreign exchange rates of $3 million, and $2 million relating to investment in growth initiatives. Partially offsetting these unfavorable impacts were $3 million from the Australian wholesale refrigerant business which continued to benefit from one-time purchases of lower cost inventory with the balance associated with other cost changes including material cost savings.

[0001069202-14-000006:mdna:90]
Corporate and Other

[0001069202-14-000006:mdna:91]
Corporate and other expenses decreased $9 million to $31 million in the first half of 2014 from $40 million in the first half of 2013 due primarily to lower incentive compensation.

[0001069202-14-000006:mdna:92]
[same as prior period, unchanged from 0001069202-14-000004:mdna:60]

[0001069202-14-000006:mdna:93]
[same as prior period, unchanged from 0001069202-14-000004:mdna:61]

[0001069202-14-000006:mdna:94]
[same as prior period, unchanged from 0001069202-14-000004:mdna:62]

[0001069202-14-000006:mdna:95]
The following table summarizes our cash flow activity for the six months ended June 30, 2014 and 2013 (in millions):

[0001069202-14-000006:mdna:96]
|  | For the Six Months Ended June 30, |
|  | 2014 |  | 2013 |
| Net cash used in operating activities | $ | (73.4 | ) |  | $ | (88.3 | ) |
| Net cash used in investing activities | (41.2 | ) |  | (18.7 | ) |
| Net cash provided by financing activities | 125.1 |  |  | 106.6 |  |

[0001069202-14-000006:mdna:97]
Net Cash Used in Operating Activities - The net cash used in operating activities in the first six months of 2014 and 2013 reflects the seasonal increase in working capital requirements. The $15 million decrease in net cash used in operating activities  in 2014 is primarily due to higher net income.  Also, the seasonal increase in working capital requirements in 2014 was smaller than the increase in 2013.  However, that favorable cash flow impact was offset by higher income tax payments in 2014.

[0001069202-14-000006:mdna:98]
Net Cash Used in Investing Activities - Capital expenditures were $41 million and $23 million in the first six months of 2014 and 2013, respectively.  Capital expenditures in 2014 were primarily related to an expansion of manufacturing capacity for our Residential Heating & Cooling segment, investments in systems and software to support the overall enterprise and investments in our distribution network.  Net cash used in investing activities in the first half of 2013 also included net proceeds of $5 million from the sale of the Service Experts business.

[0001069202-14-000006:mdna:99]
Net Cash Provided by Financing Activities - Net cash provided by financing activities increased to $125 million in the first six months of 2014 primarily due to an increase in net borrowings and was partially offset by increases in stock repurchases and cash dividends paid.  Net borrowings were higher in 2014 to support the increased stock repurchases, dividend and tax payments.  Dividend payments increased because the fourth quarter 2012 dividend was paid in 2012, whereas the fourth quarter 2013 dividend was not paid until the first quarter of 2014.

[0001069202-14-000006:mdna:100]
[same as prior period, unchanged from 0001069202-14-000004:mdna:68]

[0001069202-14-000006:mdna:101]
The following table details our lines of credit and financing arrangements as of June 30, 2014 (in millions):

[0001069202-14-000006:mdna:102]
|  | Maximum Capacity |  | Outstanding Borrowings |  | Available for Future Borrowings |
| Short-term debt: |  |  |  |  |  |
| Foreign obligations | $ | 28.3 |  |  | $ | 5.6 |  |  | $ | 22.7 |  |
| Asset Securitization Program (1) | 180.0 |  |  | 180.0 |  |  | — |  |
| Total short-term debt | $ | 208.3 |  |  | $ | 185.6 |  |  | $ | 22.7 |  |
| Current maturities of long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | — |  |
| Long-term debt: |  |  |  |  |  |
| Capital lease obligations | $ | 16.8 |  |  | $ | 16.8 |  |  | $ | — |  |
| Domestic revolving credit facility (2) | 650.0 |  |  | 203.0 |  |  | 419.4 |  |
| Senior unsecured notes | 200.0 |  |  | 200.0 |  |  | — |  |
| Total long-term debt | 866.8 |  |  | 419.8 |  |  | 419.4 |  |
| Total debt | $ | 1,076.4 |  |  | $ | 606.7 |  |  | $ | 442.1 |  |

[0001069202-14-000006:mdna:103]
[same as prior period, unchanged from 0001069202-14-000004:mdna:71]

[0001069202-14-000006:mdna:104]
(2) The available future borrowings on our domestic revolving credit facility were reduced by the outstanding borrowings and $27.6 million in outstanding standby letters of credit.  We also had $26.4 million in outstanding standby letters of credit outside of the domestic revolving credit facility as of June 30, 2014.

[0001069202-14-000006:mdna:105]
[same as prior period, unchanged from 0001069202-14-000004:mdna:73]

[0001069202-14-000006:mdna:106]
We periodically review our capital structure to ensure the appropriate levels of leverage and liquidity.  We may access the capital markets, as necessary, based on business needs and to take advantage of favorable interest rate environments or other

[0001069202-14-000006:mdna:107]
market conditions.  We also evaluate our debt-to-capital and debt-to-EBITDA ratios to determine, among other considerations, the appropriate targets for capital expenditures and share repurchases under our share repurchase programs.  Our debt-to-total-capital ratio increased to 53.9% at June 30, 2014 from 45.2% at December 31, 2013 due to the increase in our net borrowings, as noted above.

[0001069202-14-000006:mdna:108]
[same as prior period, unchanged from 0001069202-14-000004:mdna:76]

[0001069202-14-000006:mdna:109]
We believe our cash and cash equivalents of $50 million, future cash generated from operations and available future borrowings are sufficient to fund operations, planned capital expenditures, future contractual obligations, share repurchases, anticipated dividends and other needs in the foreseeable future.  Included in our cash and cash equivalents of $50 million as of June 30, 2014 was $29.6 million of cash held in foreign locations.  Our cash held in foreign locations is used for investing and operating activities in those locations, and we currently do not have the need or intent to repatriate those funds to the United States.  If we were to repatriate this cash, we would be required to accrue and pay taxes in the United States for the amounts that were repatriated.

[0001069202-14-000006:mdna:110]
[same as prior period, unchanged from 0001069202-14-000004:mdna:78]

[0001069202-14-000006:mdna:111]
[same as prior period, unchanged from 0001069202-14-000004:mdna:79]

[0001069202-14-000006:mdna:112]
[same as prior period, unchanged from 0001069202-14-000004:mdna:80]

[0001069202-14-000006:mdna:113]
Commitments, Contingencies and Guarantees

[0001069202-14-000006:mdna:114]
For information regarding our commitments, contingencies and guarantees, see Note 6 in the Notes to the Consolidated Financial Statements.

[0001069202-14-000006:mdna:115]
Recent Accounting Pronouncements

[0001069202-14-000006:mdna:116]
On May 28, 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us on January 1, 2017. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.
